/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:48
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: csi.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csi.c -extend private-namespace.scm
   used units: library eval extras match
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[559];
static double C_possibly_force_alignment;


/* from k1483 */
static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8720)
static void C_ccall f_8720(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8720)
static void C_ccall f_8720r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8918)
static void C_ccall f_8918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8898)
static void C_ccall f_8898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8761)
static void C_fcall f_8761(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_ccall f_8777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8808)
static void C_fcall f_8808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8788)
static void C_ccall f_8788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8759)
static void C_ccall f_8759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8632)
static void C_ccall f_8632(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8632)
static void C_ccall f_8632r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8658)
static void C_fcall f_8658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8585)
static void C_ccall f_8585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8583)
static void C_ccall f_8583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8498)
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8502)
static void C_ccall f_8502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8561)
static void C_ccall f_8561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8536)
static void C_ccall f_8536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8538)
static void C_fcall f_8538(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8520)
static void C_ccall f_8520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8442)
static void C_fcall f_8442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8410)
static void C_fcall f_8410(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8215)
static void C_ccall f_8215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8367)
static void C_ccall f_8367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8365)
static void C_ccall f_8365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_ccall f_8329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8343)
static void C_fcall f_8343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8357)
static void C_ccall f_8357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8305)
static void C_ccall f_8305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8301)
static void C_ccall f_8301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8271)
static void C_ccall f_8271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8257)
static void C_ccall f_8257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8110)
static void C_ccall f_8110(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8110)
static void C_ccall f_8110r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8146)
static void C_fcall f_8146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8159)
static void C_ccall f_8159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8000)
static void C_ccall f_8000(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8000)
static void C_ccall f_8000r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8007)
static void C_ccall f_8007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8104)
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8098)
static void C_ccall f_8098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8092)
static void C_ccall f_8092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8026)
static void C_ccall f_8026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7976)
static void C_ccall f_7976(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7976)
static void C_ccall f_7976r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7714)
static void C_ccall f_7714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7718)
static void C_ccall f_7718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7936)
static void C_fcall f_7936(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7730)
static void C_ccall f_7730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7926)
static void C_ccall f_7926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7880)
static void C_fcall f_7880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_fcall f_7896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7754)
static void C_fcall f_7754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7868)
static void C_ccall f_7868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7788)
static void C_fcall f_7788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7819)
static void C_ccall f_7819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7674)
static void C_fcall f_7674(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7701)
static void C_ccall f_7701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7643)
static void C_fcall f_7643(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7664)
static void C_ccall f_7664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7607)
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7538)
static void C_ccall f_7538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7441)
static void C_ccall f_7441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_fcall f_1222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_fcall f_1238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7304)
static void C_ccall f_7304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7308)
static void C_ccall f_7308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_fcall f_7317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7331)
static void C_fcall f_7331(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7215)
static void C_ccall f_7215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7228)
static void C_fcall f_7228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7244)
static void C_ccall f_7244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_ccall f_7226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7126)
static void C_ccall f_7126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_fcall f_7139(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7137)
static void C_ccall f_7137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_fcall f_6851(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7064)
static void C_ccall f_7064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_fcall f_6924(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6988)
static void C_ccall f_6988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_fcall f_7034(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_fcall f_6637(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6599)
static void C_ccall f_6599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_fcall f_6347(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6432)
static void C_fcall f_6432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6467)
static void C_fcall f_6467(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6534)
static void C_ccall f_6534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_ccall f_6446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6086)
static void C_fcall f_6086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_fcall f_6053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_fcall f_5863(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5889)
static void C_fcall f_5889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_fcall f_5917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5662)
static void C_fcall f_5662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5519)
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5289)
static void C_fcall f_5289(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5363)
static void C_fcall f_5363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_fcall f_5299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5182)
static void C_fcall f_5182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_fcall f_5091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_fcall f_4433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_fcall f_4439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_fcall f_4600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_fcall f_4612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_fcall f_4646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_fcall f_4804(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4830)
static void C_fcall f_4830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_fcall f_4530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_fcall f_4546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_fcall f_4450(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4456)
static void C_fcall f_4456(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_fcall f_4274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_fcall f_4280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4302)
static void C_fcall f_4302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static C_word C_fcall f_4391(C_word t0);
C_noret_decl(f_4217)
static void C_fcall f_4217(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4223)
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4235)
static void C_fcall f_4235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4167)
static void C_fcall f_4167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3981)
static void C_fcall f_3981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_fcall f_4066(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_fcall f_4103(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_fcall f_4015(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_fcall f_3952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3901)
static void C_fcall f_3901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3790)
static void C_fcall f_3790(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_fcall f_3858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_fcall f_3793(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_fcall f_3457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_fcall f_3362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_fcall f_3298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_fcall f_3042(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_fcall f_3074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_fcall f_2850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_fcall f_2793(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_fcall f_2368(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2324)
static void C_fcall f_2324(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1797)
static void C_fcall f_1797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_fcall f_2614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_fcall f_1654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_fcall f_1598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static C_word C_fcall f_1517(C_word t0,C_word t1);
C_noret_decl(f_1490)
static void C_fcall f_1490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static C_word C_fcall f_1428(C_word t0);
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_ccall f_1374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8761)
static void C_fcall trf_8761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8761(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8761(t0,t1,t2,t3);}

C_noret_decl(trf_8808)
static void C_fcall trf_8808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8808(t0,t1);}

C_noret_decl(trf_8658)
static void C_fcall trf_8658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8658(t0,t1);}

C_noret_decl(trf_8538)
static void C_fcall trf_8538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8538(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8538(t0,t1,t2,t3);}

C_noret_decl(trf_8442)
static void C_fcall trf_8442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8442(t0,t1);}

C_noret_decl(trf_8410)
static void C_fcall trf_8410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8410(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8410(t0,t1);}

C_noret_decl(trf_8343)
static void C_fcall trf_8343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8343(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8343(t0,t1,t2);}

C_noret_decl(trf_8146)
static void C_fcall trf_8146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8146(t0,t1,t2);}

C_noret_decl(trf_7936)
static void C_fcall trf_7936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7936(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7936(t0,t1,t2,t3);}

C_noret_decl(trf_7880)
static void C_fcall trf_7880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7880(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7880(t0,t1,t2,t3);}

C_noret_decl(trf_7896)
static void C_fcall trf_7896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7896(t0,t1);}

C_noret_decl(trf_7754)
static void C_fcall trf_7754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7754(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7754(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7788)
static void C_fcall trf_7788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7788(t0,t1);}

C_noret_decl(trf_7674)
static void C_fcall trf_7674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7674(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7674(t0,t1,t2,t3);}

C_noret_decl(trf_7643)
static void C_fcall trf_7643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7643(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7643(t0,t1,t2,t3);}

C_noret_decl(trf_7607)
static void C_fcall trf_7607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7607(t0,t1,t2);}

C_noret_decl(trf_1222)
static void C_fcall trf_1222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1222(t0,t1);}

C_noret_decl(trf_1238)
static void C_fcall trf_1238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1238(t0,t1);}

C_noret_decl(trf_7317)
static void C_fcall trf_7317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7317(t0,t1);}

C_noret_decl(trf_7331)
static void C_fcall trf_7331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7331(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7331(t0,t1,t2);}

C_noret_decl(trf_7228)
static void C_fcall trf_7228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7228(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7228(t0,t1,t2);}

C_noret_decl(trf_7139)
static void C_fcall trf_7139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7139(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7139(t0,t1,t2);}

C_noret_decl(trf_6851)
static void C_fcall trf_6851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6851(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6851(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6924)
static void C_fcall trf_6924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6924(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6924(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7034)
static void C_fcall trf_7034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7034(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7034(t0,t1,t2);}

C_noret_decl(trf_6637)
static void C_fcall trf_6637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6637(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6637(t0,t1,t2,t3);}

C_noret_decl(trf_6347)
static void C_fcall trf_6347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6347(t0,t1,t2);}

C_noret_decl(trf_6432)
static void C_fcall trf_6432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6432(t0,t1);}

C_noret_decl(trf_6467)
static void C_fcall trf_6467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6467(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6467(t0,t1,t2,t3);}

C_noret_decl(trf_6086)
static void C_fcall trf_6086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6086(t0,t1);}

C_noret_decl(trf_6053)
static void C_fcall trf_6053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6053(t0,t1);}

C_noret_decl(trf_5863)
static void C_fcall trf_5863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5863(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5863(t0,t1,t2,t3);}

C_noret_decl(trf_5889)
static void C_fcall trf_5889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5889(t0,t1);}

C_noret_decl(trf_5917)
static void C_fcall trf_5917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5917(t0,t1);}

C_noret_decl(trf_5662)
static void C_fcall trf_5662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5662(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5662(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5519)
static void C_fcall trf_5519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5519(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5519(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5289)
static void C_fcall trf_5289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5289(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5289(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5363)
static void C_fcall trf_5363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5363(t0,t1);}

C_noret_decl(trf_5299)
static void C_fcall trf_5299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5299(t0,t1);}

C_noret_decl(trf_5182)
static void C_fcall trf_5182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5182(t0,t1);}

C_noret_decl(trf_5091)
static void C_fcall trf_5091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5091(t0,t1);}

C_noret_decl(trf_4433)
static void C_fcall trf_4433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4433(t0,t1);}

C_noret_decl(trf_4439)
static void C_fcall trf_4439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4439(t0,t1);}

C_noret_decl(trf_4600)
static void C_fcall trf_4600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4600(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4600(t0,t1);}

C_noret_decl(trf_4612)
static void C_fcall trf_4612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4612(t0,t1);}

C_noret_decl(trf_4646)
static void C_fcall trf_4646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4646(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4646(t0,t1,t2);}

C_noret_decl(trf_4804)
static void C_fcall trf_4804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4804(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4804(t0,t1);}

C_noret_decl(trf_4830)
static void C_fcall trf_4830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4830(t0,t1);}

C_noret_decl(trf_4530)
static void C_fcall trf_4530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4530(t0,t1,t2);}

C_noret_decl(trf_4546)
static void C_fcall trf_4546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4546(t0,t1,t2);}

C_noret_decl(trf_4450)
static void C_fcall trf_4450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4450(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4450(t0,t1,t2);}

C_noret_decl(trf_4456)
static void C_fcall trf_4456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4456(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4456(t0,t1,t2);}

C_noret_decl(trf_4274)
static void C_fcall trf_4274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4274(t0,t1);}

C_noret_decl(trf_4280)
static void C_fcall trf_4280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4280(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4280(t0,t1,t2);}

C_noret_decl(trf_4302)
static void C_fcall trf_4302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4302(t0,t1);}

C_noret_decl(trf_4217)
static void C_fcall trf_4217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4217(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4217(t0,t1,t2);}

C_noret_decl(trf_4223)
static void C_fcall trf_4223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4223(t0,t1,t2);}

C_noret_decl(trf_4235)
static void C_fcall trf_4235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4235(t0,t1,t2);}

C_noret_decl(trf_4167)
static void C_fcall trf_4167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4167(t0,t1,t2);}

C_noret_decl(trf_3981)
static void C_fcall trf_3981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3981(t0,t1,t2);}

C_noret_decl(trf_4066)
static void C_fcall trf_4066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4066(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4066(t0,t1,t2,t3);}

C_noret_decl(trf_4103)
static void C_fcall trf_4103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4103(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4103(t0,t1,t2);}

C_noret_decl(trf_4015)
static void C_fcall trf_4015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4015(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4015(t0,t1,t2,t3);}

C_noret_decl(trf_3952)
static void C_fcall trf_3952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3952(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3952(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3901)
static void C_fcall trf_3901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3901(t0,t1);}

C_noret_decl(trf_3896)
static void C_fcall trf_3896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3896(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3896(t0,t1,t2);}

C_noret_decl(trf_3790)
static void C_fcall trf_3790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3790(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3790(t0,t1,t2,t3);}

C_noret_decl(trf_3858)
static void C_fcall trf_3858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3858(t0,t1);}

C_noret_decl(trf_3793)
static void C_fcall trf_3793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3793(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3793(t0,t1,t2);}

C_noret_decl(trf_3618)
static void C_fcall trf_3618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3618(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3618(t0,t1,t2);}

C_noret_decl(trf_3457)
static void C_fcall trf_3457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3457(t0,t1);}

C_noret_decl(trf_3362)
static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3362(t0,t1);}

C_noret_decl(trf_3298)
static void C_fcall trf_3298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3298(t0,t1);}

C_noret_decl(trf_3042)
static void C_fcall trf_3042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3042(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3042(t0,t1,t2);}

C_noret_decl(trf_3074)
static void C_fcall trf_3074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3074(t0,t1,t2,t3);}

C_noret_decl(trf_2850)
static void C_fcall trf_2850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2850(t0,t1);}

C_noret_decl(trf_2793)
static void C_fcall trf_2793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2793(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2793(t0,t1,t2,t3);}

C_noret_decl(trf_2368)
static void C_fcall trf_2368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2368(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2368(t0,t1,t2);}

C_noret_decl(trf_2324)
static void C_fcall trf_2324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2324(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2324(t0,t1,t2);}

C_noret_decl(trf_1797)
static void C_fcall trf_1797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1797(t0,t1);}

C_noret_decl(trf_2614)
static void C_fcall trf_2614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2614(t0,t1);}

C_noret_decl(trf_1654)
static void C_fcall trf_1654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1654(t0,t1);}

C_noret_decl(trf_1598)
static void C_fcall trf_1598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1598(t0,t1,t2);}

C_noret_decl(trf_1490)
static void C_fcall trf_1490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1490(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4678)){
C_save(t1);
C_rereclaim2(4678*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,559);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],3,"map");
lf[3]=C_h_intern(&lf[3],6,"lambda");
lf[4]=C_h_intern(&lf[4],14,"\004coreundefined");
lf[5]=C_h_intern(&lf[5],20,"\003syscall-with-values");
lf[6]=C_h_intern(&lf[6],9,"\004coreset!");
lf[7]=C_h_intern(&lf[7],6,"gensym");
lf[8]=C_h_intern(&lf[8],16,"\003syscheck-syntax");
lf[9]=C_h_intern(&lf[9],25,"set!-values/define-values");
lf[10]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000C\012CHICKEN\012(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[13]=C_h_intern(&lf[13],19,"\003sysundefined-value");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[16]=C_h_intern(&lf[16],27,"\003sysrepl-print-length-limit");
lf[17]=C_h_intern(&lf[17],4,"\000csi");
lf[18]=C_h_intern(&lf[18],12,"\003sysfeatures");
lf[19]=C_h_intern(&lf[19],15,"\003csiprint-usage");
lf[20]=C_h_intern(&lf[20],7,"display");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\002\042\047\012    -b  -batch                  terminate after command-line processing\012 "
"   -w  -no-warnings            disable all warnings\012    -k  -keyword-style STYLE"
"    enable alternative keyword-syntax (none, prefix or suffix)\012    -s  -script P"
"ATHNAME        use interpreter for shell scripts\012        -ss PATHNAME           "
" shell script with `main\047 procedure\012    -R  -require-extension NAME require exte"
"nsion before executing code\012    -I  -include-path PATHNAME  add PATHNAME to incl"
"ude path\012    --                          ignore all following options\012\012");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\002\257Usage: csi {FILENAME | OPTION}\012\012  where OPTION may be one of the following:"
"\012\012    -h  -help  --help           display this text and exit\012    -v  -version   "
"             display version and exit\012        -release                print rele"
"ase number and exit\012    -i  -case-insensitive       enable case-insensitive read"
"ing\012    -e  -eval EXPRESSION        evaluate given expression\012    -p  -print EXP"
"RESSION       evaluate and print result(s)\012    -P  -pretty-print EXPRESSION  eva"
"luate and print result(s) prettily\012    -D  -feature SYMBOL         register feat"
"ure identifier\012    -q  -quiet                  do not print banner\012    -n  -no-i"
"nit                do not load initialization file `");
lf[23]=C_h_intern(&lf[23],16,"\003csiprint-banner");
lf[24]=C_h_intern(&lf[24],5,"print");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[26]=C_h_intern(&lf[26],15,"chicken-version");
lf[27]=C_h_intern(&lf[27],9,"read-char");
lf[28]=C_h_intern(&lf[28],4,"read");
lf[29]=C_h_intern(&lf[29],18,"\003sysuser-read-hook");
lf[30]=C_h_intern(&lf[30],5,"quote");
lf[31]=C_h_intern(&lf[31],17,"\003csihistory-count");
lf[32]=C_h_intern(&lf[32],15,"\003csihistory-ref");
lf[33]=C_h_intern(&lf[33],21,"\003syssharp-number-hook");
lf[35]=C_h_intern(&lf[35],9,"substring");
lf[36]=C_h_intern(&lf[36],18,"\003csichop-separator");
lf[37]=C_h_intern(&lf[37],4,"sub1");
lf[38]=C_h_intern(&lf[38],1,"@");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],13,"string-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[42]=C_h_intern(&lf[42],22,"\003csilookup-script-file");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[44]=C_h_intern(&lf[44],25,"\003syspeek-nonnull-c-string");
lf[45]=C_h_intern(&lf[45],12,"string-split");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[48]=C_h_intern(&lf[48],6,"getenv");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[50]=C_h_intern(&lf[50],16,"\003csihistory-list");
lf[51]=C_h_intern(&lf[51],13,"vector-resize");
lf[52]=C_h_intern(&lf[52],15,"\003csihistory-add");
lf[53]=C_h_intern(&lf[53],9,"\003syserror");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[55]=C_h_intern(&lf[55],14,"\003csitty-input\077");
lf[56]=C_h_intern(&lf[56],13,"\003systty-port\077");
lf[57]=C_h_intern(&lf[57],18,"\003sysstandard-input");
lf[58]=C_h_intern(&lf[58],18,"\003sysbreak-on-error");
lf[59]=C_h_intern(&lf[59],20,"\003sysread-prompt-hook");
lf[61]=C_h_intern(&lf[61],15,"hash-table-set!");
lf[62]=C_h_intern(&lf[62],16,"toplevel-command");
lf[63]=C_h_intern(&lf[63],4,"eval");
lf[64]=C_h_intern(&lf[64],12,"load-noisily");
lf[65]=C_h_intern(&lf[65],10,"singlestep");
lf[66]=C_h_intern(&lf[66],14,"hash-table-ref");
lf[67]=C_h_intern(&lf[67],15,"hash-table-walk");
lf[68]=C_h_intern(&lf[68],9,"read-line");
lf[69]=C_h_intern(&lf[69],6,"length");
lf[70]=C_h_intern(&lf[70],5,"write");
lf[71]=C_h_intern(&lf[71],6,"printf");
lf[72]=C_h_intern(&lf[72],12,"pretty-print");
lf[73]=C_h_intern(&lf[73],8,"integer\077");
lf[74]=C_h_intern(&lf[74],6,"values");
lf[75]=C_h_intern(&lf[75],18,"\003sysrepl-eval-hook");
lf[76]=C_h_intern(&lf[76],22,"\003csitrace-indent-level");
lf[77]=C_h_intern(&lf[77],4,"exit");
lf[78]=C_h_intern(&lf[78],1,"x");
lf[79]=C_h_intern(&lf[79],11,"macroexpand");
lf[80]=C_h_intern(&lf[80],1,"p");
lf[81]=C_h_intern(&lf[81],1,"d");
lf[82]=C_h_intern(&lf[82],12,"\003csidescribe");
lf[83]=C_h_intern(&lf[83],2,"du");
lf[84]=C_h_intern(&lf[84],8,"\003csidump");
lf[85]=C_h_intern(&lf[85],3,"dur");
lf[86]=C_h_intern(&lf[86],1,"r");
lf[87]=C_h_intern(&lf[87],10,"\003csireport");
lf[88]=C_h_intern(&lf[88],1,"q");
lf[89]=C_h_intern(&lf[89],1,"l");
lf[90]=C_h_intern(&lf[90],12,"\003sysfor-each");
lf[91]=C_h_intern(&lf[91],4,"load");
lf[92]=C_h_intern(&lf[92],2,"ln");
lf[93]=C_h_intern(&lf[93],6,"print*");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[95]=C_h_intern(&lf[95],8,"\000printer");
lf[96]=C_h_intern(&lf[96],1,"t");
lf[97]=C_h_intern(&lf[97],17,"\003sysdisplay-times");
lf[98]=C_h_intern(&lf[98],14,"\003sysstop-timer");
lf[99]=C_h_intern(&lf[99],15,"\003sysstart-timer");
lf[100]=C_h_intern(&lf[100],2,"tr");
lf[102]=C_h_intern(&lf[102],8,"\003syswarn");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[106]=C_h_intern(&lf[106],25,"\003csitraced-procedure-exit");
lf[107]=C_h_intern(&lf[107],26,"\003csitraced-procedure-entry");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\033can not trace non-procedure");
lf[109]=C_h_intern(&lf[109],7,"\003sysmap");
lf[110]=C_h_intern(&lf[110],14,"string->symbol");
lf[111]=C_h_intern(&lf[111],3,"utr");
lf[112]=C_h_intern(&lf[112],7,"\003csidel");
lf[113]=C_h_intern(&lf[113],3,"eq\077");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[115]=C_h_intern(&lf[115],2,"br");
lf[116]=C_h_intern(&lf[116],1,"a");
lf[117]=C_h_intern(&lf[117],15,"\003sysbreak-entry");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\047can not set breakpoint on non-procedure");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[120]=C_h_intern(&lf[120],3,"ubr");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[122]=C_h_intern(&lf[122],3,"uba");
lf[123]=C_h_intern(&lf[123],14,"do-unbreak-all");
lf[124]=C_h_intern(&lf[124],8,"breakall");
lf[125]=C_h_intern(&lf[125],19,"\003sysbreak-in-thread");
lf[126]=C_h_intern(&lf[126],9,"breakonly");
lf[127]=C_h_intern(&lf[127],4,"info");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[129]=C_h_intern(&lf[129],3,"car");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[131]=C_h_intern(&lf[131],1,"c");
lf[132]=C_h_intern(&lf[132],19,"\003syslast-breakpoint");
lf[133]=C_h_intern(&lf[133],16,"\003sysbreak-resume");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[135]=C_h_intern(&lf[135],3,"exn");
lf[136]=C_h_intern(&lf[136],18,"\003syslast-exception");
lf[137]=C_h_intern(&lf[137],4,"step");
lf[138]=C_h_intern(&lf[138],1,"s");
lf[139]=C_h_intern(&lf[139],6,"system");
lf[140]=C_h_intern(&lf[140],1,"\077");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\004TToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print macroexpanded expression EXP\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[144]=C_h_intern(&lf[144],22,"hash-table-ref/default");
lf[145]=C_h_intern(&lf[145],7,"unquote");
lf[146]=C_h_intern(&lf[146],16,"\003csitrace-indent");
lf[147]=C_h_intern(&lf[147],19,"\003syswrite-char/port");
lf[148]=C_h_intern(&lf[148],19,"\003sysstandard-output");
lf[149]=C_h_intern(&lf[149],12,"flush-output");
lf[150]=C_h_intern(&lf[150],16,"\003syswrite-char-0");
lf[151]=C_h_intern(&lf[151],4,"add1");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[153]=C_h_intern(&lf[153],23,"\003csiparse-option-string");
lf[154]=C_h_intern(&lf[154],17,"get-output-string");
lf[155]=C_h_intern(&lf[155],18,"open-output-string");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[157]=C_h_intern(&lf[157],7,"reverse");
lf[158]=C_h_intern(&lf[158],22,"with-exception-handler");
lf[159]=C_h_intern(&lf[159],30,"call-with-current-continuation");
lf[160]=C_h_intern(&lf[160],17,"open-input-string");
lf[161]=C_h_intern(&lf[161],4,"chop");
lf[162]=C_h_intern(&lf[162],4,"sort");
lf[163]=C_h_intern(&lf[163],19,"with-output-to-port");
lf[164]=C_h_intern(&lf[164],19,"current-output-port");
lf[165]=C_h_intern(&lf[165],8,"truncate");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\001\374~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbols:\011~S~%~\012                   Memory:\011heap size "
"is ~S bytes~A with ~S bytes currently in use~%~  \012                     nursery s"
"ize is ~S bytes, stack grows ~A~%");
lf[175]=C_h_intern(&lf[175],21,"\003sysinclude-pathnames");
lf[176]=C_h_intern(&lf[176],14,"build-platform");
lf[177]=C_h_intern(&lf[177],16,"software-version");
lf[178]=C_h_intern(&lf[178],13,"software-type");
lf[179]=C_h_intern(&lf[179],12,"machine-type");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[181]=C_h_intern(&lf[181],11,"make-string");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[183]=C_h_intern(&lf[183],8,"string<\077");
lf[184]=C_h_intern(&lf[184],15,"keyword->string");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[186]=C_h_intern(&lf[186],17,"memory-statistics");
lf[187]=C_h_intern(&lf[187],21,"\003syssymbol-table-info");
lf[188]=C_h_intern(&lf[188],2,"gc");
lf[189]=C_h_intern(&lf[189],19,"\003csibytevector-data");
lf[190]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[192]=C_h_intern(&lf[192],7,"sprintf");
lf[193]=C_h_intern(&lf[193],7,"fprintf");
lf[194]=C_h_intern(&lf[194],8,"list-ref");
lf[195]=C_h_intern(&lf[195],10,"string-ref");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[200]=C_h_intern(&lf[200],7,"newline");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[211]=C_h_intern(&lf[211],28,"\003sysarbitrary-unbound-symbol");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[215]=C_h_intern(&lf[215],8,"\003syssize");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[217]=C_h_intern(&lf[217],8,"\003sysslot");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol with name ~S~%");
lf[219]=C_h_intern(&lf[219],18,"\003syssymbol->string");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[222]=C_h_intern(&lf[222],32,"\003syssymbol-has-toplevel-binding\077");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[225]=C_h_intern(&lf[225],15,"describe-object");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[227]=C_h_intern(&lf[227],25,"\003syspeek-unsigned-integer");
lf[228]=C_h_intern(&lf[228],9,"\000tinyclos");
lf[229]=C_h_intern(&lf[229],19,"\010tinyclosentity-tag");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[245]=C_h_intern(&lf[245],11,"\003csihexdump");
lf[246]=C_h_intern(&lf[246],8,"\003sysbyte");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[249]=C_h_intern(&lf[249],23,"\003syslambda-info->string");
lf[250]=C_h_intern(&lf[250],10,"hash-table");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[256]=C_h_intern(&lf[256],9,"condition");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[258]=C_h_intern(&lf[258],4,"cdar");
lf[259]=C_h_intern(&lf[259],4,"caar");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[262]=C_h_intern(&lf[262],6,"unveil");
lf[263]=C_h_intern(&lf[263],6,"append");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[266]=C_h_intern(&lf[266],15,"meroon-instance");
lf[267]=C_h_intern(&lf[267],9,"provided\077");
lf[268]=C_h_intern(&lf[268],6,"meroon");
lf[269]=C_h_intern(&lf[269],15,"\003sysbytevector\077");
lf[270]=C_h_intern(&lf[270],13,"\003syslocative\077");
lf[271]=C_h_intern(&lf[271],9,"instance\077");
lf[272]=C_h_intern(&lf[272],5,"port\077");
lf[273]=C_h_intern(&lf[273],11,"\003sysnumber\077");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[275]=C_h_intern(&lf[275],17,"\003sysblock-address");
lf[276]=C_h_intern(&lf[276],14,"set-describer!");
lf[277]=C_h_intern(&lf[277],3,"min");
lf[278]=C_h_intern(&lf[278],4,"dump");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\035can not dump immediate object");
lf[280]=C_h_intern(&lf[280],13,"\003syspeek-byte");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\023can not dump object");
lf[282]=C_h_intern(&lf[282],10,"write-char");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[284]=C_h_intern(&lf[284],5,"fxmod");
lf[285]=C_h_intern(&lf[285],11,"\003csideldups");
lf[286]=C_h_intern(&lf[286],6,"equal\077");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000D\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000i\376\003\000"
"\000\002\376\377\012\000\000R\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000q\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000-\376\003\000\000\002\376\377\012\000\000I\376\003\000\000\002\376"
"\377\012\000\000p\376\003\000\000\002\376\377\012\000\000P\376\377\016");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376"
"B\000\000\006--help\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensiti"
"ve\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000"
"\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\377\016");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[298]=C_h_intern(&lf[298],16,"\003sysstring->list");
lf[299]=C_h_intern(&lf[299],7,"\003csirun");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[301]=C_h_intern(&lf[301],8,"\003syslist");
lf[302]=C_h_intern(&lf[302],6,"\000match");
lf[303]=C_h_intern(&lf[303],4,"repl");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\002-"
"s\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000\000\003-ss\376\377\016");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[313]=C_h_intern(&lf[313],22,"\004corerequire-extension");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[318]=C_h_intern(&lf[318],8,"for-each");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[321]=C_h_intern(&lf[321],4,"main");
lf[322]=C_h_intern(&lf[322],22,"command-line-arguments");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[327]=C_h_intern(&lf[327],17,"\003sysstring-append");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[329]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[331]=C_h_intern(&lf[331],13,"keyword-style");
lf[332]=C_h_intern(&lf[332],7,"\000prefix");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[334]=C_h_intern(&lf[334],5,"\000none");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[336]=C_h_intern(&lf[336],7,"\000suffix");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[338]=C_h_intern(&lf[338],7,"provide");
lf[339]=C_h_intern(&lf[339],5,"match");
lf[340]=C_h_intern(&lf[340],8,"string=\077");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[343]=C_h_intern(&lf[343],17,"register-feature!");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[346]=C_h_intern(&lf[346],14,"case-sensitive");
lf[347]=C_h_intern(&lf[347],16,"case-insensitive");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[350]=C_h_intern(&lf[350],12,"load-verbose");
lf[351]=C_h_intern(&lf[351],20,"\003syswarnings-enabled");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[357]=C_h_intern(&lf[357],20,"\003syseval-debug-level");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[364]=C_h_intern(&lf[364],20,"\003syswindows-platform");
lf[365]=C_h_intern(&lf[365],6,"script");
lf[366]=C_h_intern(&lf[366],12,"program-name");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[373]=C_h_intern(&lf[373],25,"\003sysimplicit-exit-handler");
lf[374]=C_h_intern(&lf[374],15,"make-hash-table");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[376]=C_h_intern(&lf[376],11,"repl-prompt");
lf[377]=C_h_intern(&lf[377],6,"srfi-8");
lf[378]=C_h_intern(&lf[378],7,"srfi-16");
lf[379]=C_h_intern(&lf[379],7,"srfi-26");
lf[380]=C_h_intern(&lf[380],7,"srfi-31");
lf[381]=C_h_intern(&lf[381],7,"srfi-15");
lf[382]=C_h_intern(&lf[382],7,"srfi-11");
lf[383]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[384]=C_h_intern(&lf[384],25,"\003sysenable-runtime-macros");
lf[385]=C_h_intern(&lf[385],6,"define");
lf[386]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[387]=C_h_intern(&lf[387],12,"syntax-error");
lf[388]=C_h_intern(&lf[388],17,"define-for-syntax");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[390]=C_h_intern(&lf[390],18,"\003sysregister-macro");
lf[391]=C_h_intern(&lf[391],6,"letrec");
lf[392]=C_h_intern(&lf[392],3,"rec");
lf[393]=C_h_intern(&lf[393],22,"chicken-compile-shared");
lf[394]=C_h_intern(&lf[394],3,"not");
lf[395]=C_h_intern(&lf[395],9,"compiling");
lf[396]=C_h_intern(&lf[396],4,"unit");
lf[397]=C_h_intern(&lf[397],7,"declare");
lf[398]=C_h_intern(&lf[398],4,"else");
lf[399]=C_h_intern(&lf[399],11,"cond-expand");
lf[400]=C_h_intern(&lf[400],6,"export");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[402]=C_h_intern(&lf[402],6,"static");
lf[403]=C_h_intern(&lf[403],5,"begin");
lf[404]=C_h_intern(&lf[404],7,"dynamic");
lf[405]=C_h_intern(&lf[405],16,"define-extension");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[408]=C_h_intern(&lf[408],22,"string-parse-start+end");
lf[409]=C_h_intern(&lf[409],7,"receive");
lf[410]=C_h_intern(&lf[410],28,"string-parse-final-start+end");
lf[411]=C_h_intern(&lf[411],20,"let-string-start+end");
lf[412]=C_h_intern(&lf[412],5,"apply");
lf[413]=C_h_intern(&lf[413],3,"let");
lf[414]=C_h_intern(&lf[414],10,"\003sysappend");
lf[415]=C_h_intern(&lf[415],2,"<>");
lf[416]=C_h_intern(&lf[416],5,"<...>");
lf[417]=C_h_intern(&lf[417],20,"\003sysregister-macro-2");
lf[418]=C_h_intern(&lf[418],4,"cute");
lf[419]=C_h_intern(&lf[419],3,"cut");
lf[420]=C_h_intern(&lf[420],3,"use");
lf[421]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[422]=C_h_intern(&lf[422],17,"require-extension");
lf[423]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[424]=C_h_intern(&lf[424],23,"\004corerequire-for-syntax");
lf[425]=C_h_intern(&lf[425],18,"require-for-syntax");
lf[426]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[427]=C_h_intern(&lf[427],18,"\003sysmake-structure");
lf[428]=C_h_intern(&lf[428],14,"\003sysstructure\077");
lf[429]=C_h_intern(&lf[429],15,"\000record-setters");
lf[430]=C_h_intern(&lf[430],19,"\003syscheck-structure");
lf[431]=C_h_intern(&lf[431],10,"\004corecheck");
lf[432]=C_h_intern(&lf[432],13,"\003sysblock-ref");
lf[433]=C_h_intern(&lf[433],18,"getter-with-setter");
lf[434]=C_h_intern(&lf[434],1,"y");
lf[435]=C_h_intern(&lf[435],14,"\003sysblock-set!");
lf[436]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[437]=C_h_intern(&lf[437],18,"define-record-type");
lf[438]=C_h_intern(&lf[438],3,"and");
lf[439]=C_h_intern(&lf[439],4,"memv");
lf[440]=C_h_intern(&lf[440],4,"cond");
lf[441]=C_h_intern(&lf[441],17,"handle-exceptions");
lf[442]=C_h_intern(&lf[442],10,"\003syssignal");
lf[443]=C_h_intern(&lf[443],14,"condition-case");
lf[444]=C_h_intern(&lf[444],9,"\003sysapply");
lf[445]=C_h_intern(&lf[445],10,"\003sysvalues");
lf[446]=C_h_intern(&lf[446],27,"\003sysregister-record-printer");
lf[447]=C_h_intern(&lf[447],21,"define-record-printer");
lf[448]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[449]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[450]=C_h_intern(&lf[450],2,"if");
lf[451]=C_h_intern(&lf[451],9,"split-at!");
lf[452]=C_h_intern(&lf[452],4,"take");
lf[453]=C_h_intern(&lf[453],4,"list");
lf[454]=C_h_intern(&lf[454],3,"cdr");
lf[455]=C_h_intern(&lf[455],4,"fx>=");
lf[456]=C_h_intern(&lf[456],3,"fx=");
lf[457]=C_h_intern(&lf[457],11,"case-lambda");
lf[458]=C_h_intern(&lf[458],11,"lambda-list");
lf[459]=C_h_intern(&lf[459],25,"\003sysdecompose-lambda-list");
lf[460]=C_h_intern(&lf[460],10,"fold-right");
lf[461]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[462]=C_h_intern(&lf[462],7,"require");
lf[463]=C_h_intern(&lf[463],6,"srfi-1");
lf[464]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[465]=C_h_intern(&lf[465],5,"null\077");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[467]=C_h_intern(&lf[467],14,"\004coreimmutable");
lf[468]=C_h_intern(&lf[468],14,"let-optionals*");
lf[469]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[470]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[471]=C_h_intern(&lf[471],8,"optional");
lf[472]=C_h_intern(&lf[472],9,":optional");
lf[473]=C_h_intern(&lf[473],14,"symbol->string");
lf[474]=C_h_intern(&lf[474],4,"let*");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[477]=C_h_intern(&lf[477],5,"%rest");
lf[478]=C_h_intern(&lf[478],4,"body");
lf[479]=C_h_intern(&lf[479],4,"cadr");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[481]=C_h_intern(&lf[481],13,"let-optionals");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[483]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[484]=C_h_intern(&lf[484],4,"eqv\077");
lf[485]=C_h_intern(&lf[485],6,"switch");
lf[486]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[487]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[488]=C_h_intern(&lf[488],2,"or");
lf[489]=C_h_intern(&lf[489],6,"select");
lf[490]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[491]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[492]=C_h_intern(&lf[492],21,"\003syssyntax-error-hook");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[494]=C_h_intern(&lf[494],8,"and-let*");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[496]=C_h_intern(&lf[496],20,"\004coredefine-constant");
lf[497]=C_h_intern(&lf[497],15,"define-constant");
lf[498]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[499]=C_h_intern(&lf[499],18,"\004coredefine-inline");
lf[500]=C_h_intern(&lf[500],13,"define-inline");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[502]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[503]=C_h_intern(&lf[503],9,"nth-value");
lf[504]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[505]=C_h_intern(&lf[505],13,"letrec-values");
lf[506]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[507]=C_h_intern(&lf[507],10,"let-values");
lf[508]=C_h_intern(&lf[508],11,"let*-values");
lf[509]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[510]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[511]=C_h_intern(&lf[511],13,"define-values");
lf[512]=C_h_intern(&lf[512],11,"set!-values");
lf[513]=C_h_intern(&lf[513],6,"unless");
lf[514]=C_h_intern(&lf[514],4,"when");
lf[515]=C_h_intern(&lf[515],16,"\003sysdynamic-wind");
lf[516]=C_h_intern(&lf[516],12,"parameterize");
lf[517]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[518]=C_h_intern(&lf[518],10,"\000compiling");
lf[519]=C_h_intern(&lf[519],19,"\004corecompiletimetoo");
lf[520]=C_h_intern(&lf[520],20,"\004corecompiletimeonly");
lf[521]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[522]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[523]=C_h_intern(&lf[523],8,"run-time");
lf[524]=C_h_intern(&lf[524],7,"compile");
lf[525]=C_h_intern(&lf[525],12,"compile-time");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[527]=C_h_intern(&lf[527],9,"eval-when");
lf[528]=C_h_intern(&lf[528],8,"\003sysvoid");
lf[529]=C_h_intern(&lf[529],9,"fluid-let");
lf[530]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[531]=C_h_intern(&lf[531],11,"\000type-error");
lf[532]=C_h_intern(&lf[532],15,"\003syssignal-hook");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[534]=C_h_intern(&lf[534],6,"ensure");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[536]=C_h_intern(&lf[536],6,"assert");
lf[537]=C_h_intern(&lf[537],20,"with-input-from-file");
lf[538]=C_h_intern(&lf[538],27,"\003syscurrent-source-filename");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[541]=C_h_intern(&lf[541],28,"\003sysresolve-include-filename");
lf[542]=C_h_intern(&lf[542],7,"include");
lf[543]=C_h_intern(&lf[543],12,"\004coredeclare");
lf[544]=C_h_intern(&lf[544],4,"time");
lf[545]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[546]=C_h_intern(&lf[546],3,"val");
lf[547]=C_h_intern(&lf[547],28,"\003sysstring->qualified-symbol");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[553]=C_h_intern(&lf[553],27,"\003sysqualified-symbol-prefix");
lf[554]=C_h_intern(&lf[554],13,"define-record");
lf[555]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[556]=C_h_intern(&lf[556],6,"symbol");
lf[557]=C_h_intern(&lf[557],11,"\003sysprovide");
lf[558]=C_h_intern(&lf[558],19,"chicken-more-macros");
C_register_lf2(lf,559,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1068 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1071 in k1068 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1074 in k1071 in k1068 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#provide */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[558]);}

/* k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[473]+1);
t4=*((C_word*)lf[110]+1);
t5=*((C_word*)lf[40]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8720,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[554],t6);}

/* a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8720(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8720r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8720r(t0,t1,t2,t3);}}

static void C_ccall f_8720r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[554],t2,lf[556]);}

/* k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[554],((C_word*)t0)[5],lf[555]);}

/* k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8730,2,t0,t1);}
t2=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8736,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8942,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[552],((C_word*)t0)[3]);}

/* k8940 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8922,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[427],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8898,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8918,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[551]);}

/* k8916 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8898,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[78]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8759,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_8761(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8761(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8761,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k8769 in mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8774,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8890,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[549],t1,lf[550]);}

/* k8888 in k8769 in mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8772 in k8769 in mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8777,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8886,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[548],((C_word*)t0)[2]);}

/* k8884 in k8772 in k8769 in mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8775 in k8772 in k8769 in mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8777,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[78],lf[546]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t3);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_list(&a,4,lf[435],lf[78],((C_word*)t0)[7],lf[546]);
t7=(C_word)C_a_i_list(&a,4,lf[3],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14);
t16=t9;
f_8808(t16,(C_word)C_a_i_list(&a,3,lf[433],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=t9;
f_8808(t15,(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14));}}

/* k8806 in k8775 in k8772 in k8769 in mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8808,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[403],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8788,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8761(t7,t4,t5,t6);}

/* k8786 in k8806 in k8775 in k8772 in k8769 in mapslots in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8788,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8757 in k8896 in k8920 in k8734 in k8728 in k8725 in k8722 in a8719 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8759,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8632,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[409],t3);}

/* a8631 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8632(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_8632r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8632r(t0,t1,t2,t3);}}

static void C_ccall f_8632r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t4,lf[301]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8649,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[409],t2,lf[458]);}}

/* k8647 in a8631 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[409],((C_word*)t0)[3],lf[545]);}

/* k8650 in k8647 in a8631 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_8658(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_8658(t3,C_SCHEME_FALSE);}}

/* k8656 in k8650 in k8647 in a8631 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8658,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[5],t3,t6));}}

/* k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8591,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[544],t4);}

/* a8590 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8591(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8591r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8591r(t0,t1,t2);}}

static void C_ccall f_8591r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8595,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[96]);}

/* k8593 in a8590 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8595,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[99]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,1,lf[98]);
t6=(C_word)C_a_i_list(&a,2,lf[97],t5);
t7=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t8=(C_word)C_a_i_list(&a,4,lf[3],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[5],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[403],t2,t9));}

/* k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8575,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[397],t3);}

/* a8574 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8575(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_8575r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8575r(t0,t1,t2);}}

static void C_ccall f_8575r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8583,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8585,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8584 in a8574 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8585,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k8581 in a8574 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8583,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[543],t1));}

/* k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[537]);
t4=*((C_word*)lf[28]+1);
t5=*((C_word*)lf[157]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8498,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[542],t6);}

/* a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8498,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#resolve-include-filename */
t4=C_retrieve(lf[541]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8570,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   load-verbose */
t4=C_retrieve(lf[350]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8568 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[539],((C_word*)t0)[2],lf[540]);}
else{
t2=((C_word*)t0)[3];
f_8505(2,t2,C_SCHEME_UNDEFINED);}}

/* k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8512,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a8513 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8514,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8520,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8561,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[515]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8560 in a8513 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8561,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* a8527 in a8513 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8536,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8534 in a8527 in a8513 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8536,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8538(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do38 in k8534 in a8527 in a8513 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8538(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8538,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 44   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8555,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8553 in do38 in k8534 in a8527 in a8513 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8555,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8538(t3,((C_word*)t0)[2],t1,t2);}

/* a8519 in a8513 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8520,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* k8510 in k8503 in k8500 in a8497 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8512,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[403],t1));}

/* k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8438,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[536],t3);}

/* a8437 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_8438r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8438r(t0,t1,t2,t3);}}

static void C_ccall f_8438r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8442,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[30],lf[535]);
t7=t4;
f_8442(t7,(C_word)C_a_i_list(&a,2,lf[467],t6));}
else{
t6=t4;
f_8442(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k8440 in a8437 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8442,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[431],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[53],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t2,t3,t10));}

/* k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8379,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[534],t3);}

/* a8378 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_8379r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8379r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8379r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8383,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k8381 in a8378 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8383,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8410,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_8410(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[30],lf[533]);
t8=(C_word)C_a_i_list(&a,2,lf[467],t7);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t10=t6;
f_8410(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k8408 in k8381 in a8378 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8410,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[531],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[532],t2);
t4=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8205,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[529],t4);}

/* a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_8205r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8205r(t0,t1,t2,t3);}}

static void C_ccall f_8205r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[529],t2,lf[530]);}

/* k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[3]);}

/* k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8372 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8373,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8218,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8366 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8367,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8365,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k8363 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8327 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8333,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8337,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8343,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_8343(t8,t3,t4);}

/* loop in k8327 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8343,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8357,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* csi.scm: 44   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8355 in loop in k8327 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8357,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8335 in k8327 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8331 in k8327 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8321,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a8320 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8321,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8295 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8301,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8305,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8315,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8314 in k8295 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8315,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8303 in k8295 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8305,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8299 in k8295 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8291 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8293,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[3],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8249,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8277,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t9=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8276 in k8291 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8277,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8251 in k8291 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8257,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8261,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8271,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8270 in k8251 in k8291 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8271,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8259 in k8251 in k8291 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8261,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8255 in k8251 in k8291 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8247 in k8291 in k8223 in k8216 in k8213 in k8210 in k8207 in a8204 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8249,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8110,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[527],t3);}

/* a8109 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8110(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_8110r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8110r(t0,t1,t2,t3);}}

static void C_ccall f_8110r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8117,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8146,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8146(t15,t11,t2);}

/* loop in a8109 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_8146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8146,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8159,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[63]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_8159(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[91]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[523]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_8159(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[524]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[525]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_8159(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[526],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8157 in loop in a8109 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8146(t3,((C_word*)t0)[2],t2);}

/* k8115 in a8109 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8117,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[518],C_retrieve(lf[18])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[519],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[520],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[521]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[522]));}}

/* k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[129]+1);
t4=*((C_word*)lf[479]+1);
t5=*((C_word*)lf[2]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8000,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[516],t6);}

/* a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8000(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8000r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8000r(t0,t1,t2,t3);}}

static void C_ccall f_8000r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[516],t2,lf[517]);}

/* k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8013,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8016,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8104,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8103 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8104,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8098,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8097 in k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8098,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8017 in k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8026,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8092,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[301]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k8090 in k8017 in k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8096,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[301]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8094 in k8090 in k8017 in k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8024 in k8017 in k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8062,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8064,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8063 in k8024 in k8017 in k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8064,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[96],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[6],t3,lf[96]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[413],t6,t7,t8));}

/* k8060 in k8024 in k8017 in k8014 in k8011 in k8008 in k8005 in k8002 in a7999 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8062,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[413],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t9));}

/* k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7990,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[514],t3);}

/* a7989 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_7990r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7990r(t0,t1,t2,t3);}}

static void C_ccall f_7990r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[450],t2,t4));}

/* k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7976,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[513],t3);}

/* a7975 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7976(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_7976r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7976r(t0,t1,t2,t3);}}

static void C_ccall f_7976r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],t2,t4,t5));}

/* k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1119,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1192,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[512],t3);}

/* k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t3=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7643,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7674,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7714,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t10=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[507],t9);}

/* a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7714,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[507],t2,lf[510]);}

/* k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7718,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[129]+1),t2);}

/* k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7936,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7936(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7936(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7936,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7949,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* csi.scm: 44   append */
t6=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* csi.scm: 44   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7643(t6,t5,t4,t3);}
else{
t6=t5;
f_7949(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7947 in loop in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7936(t3,((C_word*)t0)[2],t2,t1);}

/* k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7926,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7925 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7926,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7934,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7932 in a7925 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7934,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7734,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7880,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7880(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7880,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7896,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7920,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7674(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7913,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t7=((C_word*)t0)[2];
f_7734(3,t7,t6,t4);}}}

/* k7911 in loop in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7913,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7896(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7918 in loop in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7920,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7896(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7894 in loop in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7880(t3,((C_word*)t0)[2],t2,t1);}

/* k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7752,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7874,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7873 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7874,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7754,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7754(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7754,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7772,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7774,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7788,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7868,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   cdar */
t8=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7788(t7,C_SCHEME_FALSE);}}}

/* k7866 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7788(t2,(C_word)C_i_nullp(t1));}

/* k7786 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7788,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7842,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7754(t9,t5,t6,t7,t8);}}

/* k7840 in k7786 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7842,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t2));}

/* k7817 in k7786 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7819,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7799,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7754(t9,t5,t6,t7,t8);}

/* k7797 in k7817 in k7786 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7799,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* a7773 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7774,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7782,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7734(3,t4,t3,t2);}

/* k7780 in a7773 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7782,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7770 in fold in k7750 in k7743 in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7772,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7731 in k7728 in k7725 in k7716 in a7641 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7734,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7674(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7674,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7697,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* csi.scm: 44   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* csi.scm: 44   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7695 in map* in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7701,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7674(t4,t2,((C_word*)t0)[2],t3);}

/* k7699 in k7695 in map* in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7701,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7643(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7643,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7664,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7662 in append* in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7664,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1201,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7592,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[508],t3);}

/* a7591 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7592,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7596,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[508],t2,lf[509]);}

/* k7594 in a7591 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7596,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7607,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7607(t7,((C_word*)t0)[2],t2);}

/* fold in k7594 in a7591 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7607,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[413],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7632,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7630 in fold in k7594 in a7591 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[507],((C_word*)t0)[2],t1));}

/* k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1204,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7472,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[505],t3);}

/* a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7472,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7476,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[505],t2,lf[506]);}

/* k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7476,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7485,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7584,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7586,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7585 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7586,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7582 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[414]+1),t1);}

/* k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7488,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7572,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7571 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7572,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7580,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7578 in a7571 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7580,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7489,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7566,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7565 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7566,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[504]));}

/* k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7512,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7516,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7518,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7517 in k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7518,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7538,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k7536 in a7517 in k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7542,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7544,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7543 in k7536 in a7517 in k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7544,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7552,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7489(3,t4,t3,t2);}

/* k7550 in a7543 in k7536 in a7517 in k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[6],((C_word*)t0)[2],t1));}

/* k7540 in k7536 in a7517 in k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7542,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

/* k7514 in k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7510 in k7506 in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7512,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7486 in k7483 in k7474 in a7471 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7489,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7451,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[503],t3);}

/* a7450 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7451,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7455,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7453 in a7450 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7455,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[194],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[3],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}

/* k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7441,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[500],t3);}

/* a7440 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7441,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1213,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[500],t2,lf[502]);}

/* k1211 in a7440 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1222,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_1222(t9,(C_word)C_a_i_cons(&a,2,lf[3],t8));}
else{
t6=t5;
f_1222(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k1220 in k1211 in a7440 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_1222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1222,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1238(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[3],t6);
t8=t5;
f_1238(t8,(C_word)C_i_not(t7));}}

/* k1236 in k1220 in k1211 in a7440 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_1238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[500],lf[501],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1225(2,t2,C_SCHEME_UNDEFINED);}}

/* k1223 in k1220 in k1211 in a7440 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[499],t3));}

/* k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7420,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[497],t3);}

/* a7419 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7424,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[497],t2,lf[498]);}

/* k7422 in a7419 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7424,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[496],t3,t4));}

/* k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7304,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[494],t3);}

/* a7303 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7308,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[494],t2,lf[495]);}

/* k7306 in a7303 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7308,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_7317(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_7317(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k7315 in k7306 in a7303 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7317,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 44   ##sys#syntax-error-hook */
t2=C_retrieve(lf[492]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[493],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7331,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7331(t7,((C_word*)t0)[3],t2);}}

/* fold in k7315 in k7306 in a7303 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7331(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7331,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[403],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7360,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7377,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7395,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k7393 in fold in k7315 in k7306 in a7303 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7395,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t2));}

/* k7375 in fold in k7315 in k7306 in a7303 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7377,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k7358 in fold in k7315 in k7306 in a7303 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7360,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7205,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[489],t4);}

/* a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7205,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7215,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7213 in a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7215,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7226,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7228,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7228(t8,t4,((C_word*)t0)[2]);}

/* expand in k7213 in a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7228(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7228,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7244,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[489],t3,lf[490]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[491]);}}

/* k7242 in expand in k7213 in a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7244,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7281 in k7242 in expand in k7213 in a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7282,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[2],t2));}

/* k7278 in k7242 in expand in k7213 in a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[488],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7272,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7228(t6,t5,((C_word*)t0)[2]);}

/* k7270 in k7278 in k7242 in expand in k7213 in a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7272,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7224 in k7213 in a7204 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7226,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7116,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[485],t4);}

/* a7115 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7116,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7126,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7124 in a7115 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7126,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7137,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7139,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7139(t8,t4,((C_word*)t0)[2]);}

/* expand in k7124 in a7115 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7139(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7139,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7155,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[485],t3,lf[486]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[487]);}}

/* k7153 in expand in k7124 in a7115 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7155,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[403],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7183,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_7139(t9,t8,((C_word*)t0)[2]);}}

/* k7181 in k7153 in expand in k7124 in a7115 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7183,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7135 in k7124 in a7115 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7137,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6830,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[481],t3);}

/* a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6830r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6830r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7027,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[481],t3,lf[483]);}

/* k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[481],((C_word*)t0)[4],lf[482]);}

/* k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[2]);}

/* k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7034,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7049,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a7105 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7114,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7034(t3,lf[480],t2);}

/* k7112 in a7105 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[478]);}

/* k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[477]);}

/* k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7096,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a7095 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7104,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7034(t3,lf[476],t2);}

/* k7102 in a7095 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7064,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[7]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6841,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6843 in k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6847 in k6843 in k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6849,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6851,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6851(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k6847 in k6843 in k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6851(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6851,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6896,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6894 in recur in k6847 in k6843 in k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6908,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6906 in k6894 in recur in k6847 in k6843 in k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6908,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6902 in k6894 in recur in k6847 in k6843 in k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6904,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6872,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* csi.scm: 44   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_6851(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k6870 in k6902 in k6894 in recur in k6847 in k6843 in k6839 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6872,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7067,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[7]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6924,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6924(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6924(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6924,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[431],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6958,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7024,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k7022 in recur in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7024,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6988,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* csi.scm: 44   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_6924(t12,t8,t9,t10,t11);}

/* k6986 in k7022 in recur in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6988,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k6956 in recur in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6958,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[475]);
t4=(C_word)C_a_i_list(&a,2,lf[467],t3);
t5=(C_word)C_a_i_list(&a,3,lf[53],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t2,t5));}

/* k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7067,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[474],t7,t1));}

/* prefix-sym in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_7034(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7034,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7042,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7046,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   symbol->string */
t6=*((C_word*)lf[473]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k7044 in prefix-sym in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7040 in prefix-sym in k7031 in k7028 in k7025 in a6829 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string->symbol */
t2=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6773,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[471],t3);}

/* a6772 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6773,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6777,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6775 in a6772 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6777,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[465],t1);
t5=(C_word)C_a_i_list(&a,2,lf[454],t1);
t6=(C_word)C_a_i_list(&a,2,lf[465],t5);
t7=(C_word)C_a_i_list(&a,2,lf[431],t6);
t8=(C_word)C_a_i_list(&a,2,lf[129],t1);
t9=(C_word)C_a_i_list(&a,2,lf[30],lf[1]);
t10=(C_word)C_a_i_list(&a,2,lf[467],t9);
t11=(C_word)C_a_i_list(&a,3,lf[53],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[450],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[450],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[413],t3,t13));}

/* k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6767,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[472],t3);}

/* a6766 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6767,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[471],t2));}

/* k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6614,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[468],t3);}

/* a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6614r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6614r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6614r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6618,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[468],t3,lf[470]);}

/* k6616 in a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[468],((C_word*)t0)[3],lf[469]);}

/* k6619 in k6616 in a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6622 in k6619 in k6616 in a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6635,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6637,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6637(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k6622 in k6619 in k6616 in a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6637(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6637,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[465],t2);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[413],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],lf[466]);
t9=(C_word)C_a_i_list(&a,2,lf[467],t8);
t10=(C_word)C_a_i_list(&a,3,lf[53],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6687,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}}}

/* k6685 in loop in k6622 in k6619 in k6616 in a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[450],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[30],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[450],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6698,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_6637(t16,t14,t1,t15);}

/* k6696 in k6685 in loop in k6622 in k6619 in k6616 in a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6698,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6633 in k6622 in k6619 in k6616 in a6613 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6635,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6338,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[457],t3);}

/* a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6338,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6372,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[457],t2,lf[464]);}

/* k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   require */
t3=C_retrieve(lf[462]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[463]);}

/* k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6599,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6601,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6600 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6601,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6611,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a6610 in a6600 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6611,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k6597 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[277]+1),t1);}

/* k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6347,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6347(t7,t2,C_fix(0));}

/* loop in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6347,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k6359 in loop in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6365,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6347(t4,t2,t3);}

/* k6363 in k6359 in loop in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[69],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6406,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   fold-right */
t7=C_retrieve(lf[460]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[461],((C_word*)t0)[2]);}

/* a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6408,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6418,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* csi.scm: 44   ##sys#check-syntax */
t7=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[457],t6,lf[458]);}

/* k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_i_zerop(t2);
t5=t3;
f_6432(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_6432(t4,(C_word)C_a_i_list(&a,3,lf[456],((C_word*)t0)[2],t2));}}

/* k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6432,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6436,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a6447 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6448,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6467,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6467(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a6447 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6467(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6467,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[413],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6521 in build in a6447 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6534,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* csi.scm: 44   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_6467(t11,t8,t10,t1);}
else{
/* csi.scm: 44   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6467(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k6532 in k6521 in build in a6447 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6534,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6450 in a6447 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6452,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6465,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[453]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6463 in k6450 in a6447 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6465,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],t1,((C_word*)t0)[2]));}

/* a6437 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   take */
t3=C_retrieve(lf[452]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6444 in a6437 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   split-at! */
t2=C_retrieve(lf[451]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6434 in k6430 in k6420 in a6417 in a6407 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6436,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k6404 in k6392 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in a6337 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t2));}

/* k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6281,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[447],t3);}

/* a6280 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_6281r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6281r(t0,t1,t2,t3);}}

static void C_ccall f_6281r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6291,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6321,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[449]);}}

/* k6319 in a6280 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[446],t3));}

/* k6289 in a6280 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[446],t3,t6));}

/* k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6205,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[441],t3);}

/* a6204 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6205r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6205r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6209,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6207 in a6204 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6210 in k6207 in a6204 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[3],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[3],t7);
t9=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t10=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[3],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[5],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[158],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[3],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[159],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6021,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[443],t3);}

/* a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6021r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6021r(t0,t1,t2,t3);}}

static void C_ccall f_6021r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6025,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6030,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[256]);
t4=(C_word)C_a_i_list(&a,3,lf[428],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[217],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[438],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k6169 in k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6171,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[442],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[398],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k6165 in k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6167,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[440],t1);
t3=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[441],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6030,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6053,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_6053(t12,(C_word)C_a_i_cons(&a,2,lf[413],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_6053(t10,(C_word)C_a_i_cons(&a,2,lf[413],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6116,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a6117 in parse-clause in k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6118,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[439],t3,((C_word*)t0)[2]));}

/* k6114 in parse-clause in k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[438],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6086,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_6086(t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_6086(t6,(C_word)C_a_i_cons(&a,2,lf[413],t5));}}

/* k6084 in k6114 in parse-clause in k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6086,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6051 in parse-clause in k6026 in k6023 in a6020 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_6053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6053,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[398],t1));}

/* k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5831,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[437],t3);}

/* a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5831r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5831r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5831r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5838,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[129]+1),t5);}

/* k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5838,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6011 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6012,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[436]));}

/* k6008 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6010,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[427],t2);
t4=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[78]);
t6=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5863,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_5863(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k6008 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5863(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5863,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[78]);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t9);
t11=(C_word)C_a_i_list(&a,2,lf[431],t10);
t12=(C_word)C_a_i_list(&a,3,lf[432],lf[78],t3);
t13=(C_word)C_a_i_list(&a,4,lf[3],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5889,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[78],lf[434]);
t17=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t17);
t19=(C_word)C_a_i_list(&a,2,lf[431],t18);
t20=(C_word)C_a_i_list(&a,4,lf[435],lf[78],t3,lf[434]);
t21=(C_word)C_a_i_list(&a,4,lf[385],t16,t19,t20);
t22=t14;
f_5889(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_5889(t15,C_SCHEME_END_OF_LIST);}}}

/* k5887 in loop in k6008 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5889,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_5917(t6,(C_word)C_a_i_list(&a,3,lf[433],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_5917(t5,((C_word*)t0)[2]);}}

/* k5915 in k5887 in loop in k6008 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5917,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5901,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5909,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   add1 */
t6=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5907 in k5915 in k5887 in loop in k6008 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5863(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5899 in k5915 in k5887 in loop in k6008 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5901,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5859 in k6008 in k5836 in a5830 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5822,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[425],t3);}

/* a5821 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5826,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[425],t2,lf[426]);}

/* k5824 in a5821 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5826,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[424],((C_word*)t0)[2]));}

/* k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5803,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[422],t3);}

/* a5802 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5803,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5807,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[422],t2,lf[423]);}

/* k5805 in a5802 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5816,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5815 in k5805 in a5802 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5816,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5812 in k5805 in a5802 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5814,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5784,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[420],t3);}

/* a5783 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5788,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[420],t2,lf[421]);}

/* k5786 in a5783 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5797,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5796 in k5786 in a5783 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5797,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5793 in k5786 in a5783 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5795,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5656,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[419],t3);}

/* a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5656,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5662,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5662(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5662,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5672,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t7=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[415]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5743,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t9=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[416]);
if(C_truep(t8)){
/* csi.scm: 44   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* csi.scm: 44   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k5741 in loop in a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5662(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k5670 in loop in a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5675,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5673 in k5670 in loop in a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[403],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t5));}}

/* k5679 in k5673 in k5670 in loop in a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5688,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5686 in k5679 in k5673 in k5670 in loop in a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5704,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5702 in k5686 in k5679 in k5673 in k5670 in loop in a5655 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t3));}

/* k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5513,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[418],t3);}

/* a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5513,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5519(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5519,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5529,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[415]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5604,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t10=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[416]);
if(C_truep(t9)){
/* csi.scm: 44   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5631,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t11=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k5629 in loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5519(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k5602 in loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5604,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5519(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k5527 in loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5532,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5530 in k5527 in loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[3],t5));}}

/* k5536 in k5530 in k5527 in loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5549,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5547 in k5536 in k5530 in k5527 in loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5549,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5563 in k5547 in k5536 in k5530 in k5527 in loop in a5512 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5454,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[411],t3);}

/* a5453 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_5454r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5454r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5454r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[408],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[409],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[410],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[409],t10));}}

/* k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5283,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[405],t3);}

/* a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5283r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5283r(t0,t1,t2,t3);}}

static void C_ccall f_5283r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5289,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5289(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5289(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5289,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5299,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[400],t5);
t8=t6;
f_5299(t8,(C_word)C_a_i_list(&a,2,lf[397],t7));}
else{
t7=t6;
f_5299(t7,lf[401]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5363,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_5363(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_5363(t7,C_SCHEME_FALSE);}}}

/* k5361 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5363,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[405],lf[407],((C_word*)t0)[7]);}}

/* k5364 in k5361 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5366,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[402],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t5=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[404],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t6=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[400],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5424,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   cdar */
t10=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   caar */
t7=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k5437 in k5364 in k5361 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[405],lf[406],t1);}

/* k5430 in k5364 in k5361 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5422 in k5364 in k5361 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5289(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5409 in k5364 in k5361 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5411,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5289(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5388 in k5364 in k5361 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5289(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5297 in loop in a5282 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5299,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[393],t2);
t4=(C_word)C_a_i_list(&a,2,lf[394],lf[395]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[396],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[397],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[338],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[398],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[399],t3,t5,t13));}

/* k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5232,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[392],t3);}

/* a5231 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_5232r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5232r(t0,t1,t2,t3);}}

static void C_ccall f_5232r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[391],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[391],t5,t2));}}

/* k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5172,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[388],t3);}

/* a5171 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_5172r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5172r(t0,t1,t2,t3);}}

static void C_ccall f_5172r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[383]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5182,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_5182(t11,(C_word)C_a_i_cons(&a,2,lf[3],t10));}
else{
t9=t8;
f_5182(t9,(C_word)C_i_car(t5));}}

/* k5180 in a5171 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5182,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5185,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* csi.scm: 44   syntax-error */
t3=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[388],lf[389],((C_word*)t0)[2]);}}

/* k5199 in k5180 in a5171 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5185(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k5183 in k5180 in a5171 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[384]))?(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[3],((C_word*)t0)[2]):lf[386]));}

/* k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   register-feature! */
t3=C_retrieve(lf[343]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[377],lf[378],lf[379],lf[380],lf[381],lf[382]);}

/* k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=C_mutate(&lf[11],lf[12]);
t3=C_retrieve(lf[13]);
t4=C_mutate(&lf[14],lf[15]);
t5=C_set_block_item(lf[16],0,C_fix(2048));
t6=(C_word)C_a_i_cons(&a,2,lf[17],C_retrieve(lf[18]));
t7=C_mutate((C_word*)lf[18]+1,t6);
t8=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1367,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1379,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[27]+1);
t11=*((C_word*)lf[28]+1);
t12=C_retrieve(lf[29]);
t13=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1389,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1418,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[34],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1428,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[35]+1);
t17=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t18=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 144  make-string */
t20=*((C_word*)lf[181]+1);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,C_fix(256));}

/* k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1490,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[50]+1,t5);
t7=C_set_block_item(lf[31],0,C_fix(1));
t8=C_retrieve(lf[51]);
t9=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1683,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[192]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5166,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 196  repl-prompt */
t14=C_retrieve(lf[376]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t11,t13);}

/* a5165 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
/* csi.scm: 199  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[375],C_retrieve(lf[31]));}

/* k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1710,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t4=C_retrieve(lf[59]);
t5=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 211  make-hash-table */
t7=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[113]+1));}

/* k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=C_mutate(&lf[60],t1);
t3=C_retrieve(lf[61]);
t4=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_retrieve(lf[63]);
t6=C_retrieve(lf[64]);
t7=*((C_word*)lf[28]+1);
t8=C_retrieve(lf[65]);
t9=*((C_word*)lf[66]+1);
t10=C_retrieve(lf[67]);
t11=C_retrieve(lf[68]);
t12=*((C_word*)lf[69]+1);
t13=*((C_word*)lf[20]+1);
t14=*((C_word*)lf[70]+1);
t15=C_retrieve(lf[45]);
t16=C_retrieve(lf[71]);
t17=C_retrieve(lf[72]);
t18=*((C_word*)lf[73]+1);
t19=*((C_word*)lf[74]+1);
t20=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1780,a[2]=t10,a[3]=t8,a[4]=t13,a[5]=t16,a[6]=t19,a[7]=t6,a[8]=t11,a[9]=t15,a[10]=t5,a[11]=t7,a[12]=t17,tmp=(C_word)a,a+=13,tmp));
t21=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2318,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(lf[76],0,C_fix(0));
t23=lf[101]=C_SCHEME_END_OF_LIST;;
t24=lf[104]=C_SCHEME_END_OF_LIST;;
t25=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2359,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2387,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2410,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2701,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2725,tmp=(C_word)a,a+=2,tmp));
t30=C_retrieve(lf[71]);
t31=C_retrieve(lf[161]);
t32=C_retrieve(lf[162]);
t33=C_retrieve(lf[163]);
t34=*((C_word*)lf[164]+1);
t35=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=t34,a[3]=t33,a[4]=t32,a[5]=t31,a[6]=t30,tmp=(C_word)a,a+=7,tmp));
t36=C_mutate((C_word*)lf[189]+1,lf[190]);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 574  make-hash-table */
t38=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,*((C_word*)lf[113]+1));}

/* k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=C_mutate(&lf[191],t1);
t3=C_retrieve(lf[192]);
t4=C_retrieve(lf[71]);
t5=C_retrieve(lf[193]);
t6=*((C_word*)lf[69]+1);
t7=*((C_word*)lf[194]+1);
t8=*((C_word*)lf[195]+1);
t9=C_retrieve(lf[144]);
t10=C_retrieve(lf[67]);
t11=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3024,a[2]=t9,a[3]=t10,a[4]=t3,a[5]=t7,a[6]=t6,a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t12=C_retrieve(lf[61]);
t13=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3782,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3788,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[20]+1);
t16=*((C_word*)lf[40]+1);
t17=*((C_word*)lf[181]+1);
t18=*((C_word*)lf[282]+1);
t19=C_mutate((C_word*)lf[245]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3949,a[2]=t15,a[3]=t18,a[4]=t17,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t20=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4158,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[287],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4217,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[288],lf[289]);
t23=C_mutate(&lf[290],lf[291]);
t24=C_mutate(&lf[292],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4274,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4417,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 955  run */
t27=C_retrieve(lf[299]);
((C_proc2)C_retrieve_proc(t27))(2,t27,t26);}

/* k5156 in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5164,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[373]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5162 in k5156 in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5159 in k5156 in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4421,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5152,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 827  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[372]);}

/* k5150 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[371]);
/* csi.scm: 827  parse-option-string */
t3=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4424,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 828  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5146 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 828  canonicalize-args */
f_4274(((C_word*)t0)[2],t1);}

/* k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 829  member* */
f_4217(t4,lf[370],((C_word*)t3)[1]);}

/* k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 830  member* */
f_4217(t2,lf[369],((C_word*)((C_word*)t0)[4])[1]);}

/* k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5041,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5091,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5091(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5091(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5091(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5131,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 844  canonicalize-args */
f_4274(t4,((C_word*)t0)[2]);}}

/* k5142 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 844  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5129 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[368],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4433(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5089 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_5091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 835  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[367]);}
else{
t2=((C_word*)t0)[2];
f_5041(2,t2,C_SCHEME_UNDEFINED);}}

/* k5039 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 836  program-name */
t4=C_retrieve(lf[366]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5042 in k5039 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 837  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5045 in k5042 in k5039 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 838  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[365]);}

/* k5048 in k5045 in k5042 in k5039 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[364]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 841  lookup-script-file */
t6=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4433(t4,C_SCHEME_UNDEFINED);}}

/* k5057 in k5048 in k5045 in k5042 in k5039 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4433(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4433(t2,C_SCHEME_FALSE);}}

/* k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4433,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 847  member* */
f_4217(t2,lf[363],((C_word*)((C_word*)t0)[4])[1]);}

/* k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4439(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5035,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 848  member* */
f_4217(t3,lf[362],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5033 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4439(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4439,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 849  member* */
f_4217(t2,lf[361],((C_word*)((C_word*)t0)[4])[1]);}

/* k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4448,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5022,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5026,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 851  getenv */
t6=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[360]);}

/* k5024 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[358]);
/* csi.scm: 851  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[359]);}

/* k5020 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4530,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[357],0,C_fix(0));
t6=t4;
f_4600(t6,t5);}
else{
t5=t4;
f_4600(t5,C_SCHEME_UNDEFINED);}}

/* k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4600,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5011,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 874  member* */
f_4217(t3,lf[356],((C_word*)((C_word*)t0)[6])[1]);}

/* k5009 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 875  print-usage */
t3=C_retrieve(lf[19]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4603(2,t2,C_SCHEME_UNDEFINED);}}

/* k5012 in k5009 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 876  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5002,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 877  member* */
f_4217(t3,lf[355],((C_word*)((C_word*)t0)[6])[1]);}

/* k5000 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 878  print-banner */
t3=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4606(2,t2,C_SCHEME_UNDEFINED);}}

/* k5003 in k5000 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 879  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[354],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4992,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 881  chicken-version */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=t2;
f_4609(2,t3,C_SCHEME_UNDEFINED);}}

/* k4997 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 881  print */
t2=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4990 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 882  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 883  member* */
f_4217(t3,lf[353],((C_word*)((C_word*)t0)[6])[1]);}

/* k4977 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4982(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 884  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[352]);}}
else{
t2=((C_word*)t0)[3];
f_4612(t2,C_SCHEME_UNDEFINED);}}

/* k4980 in k4977 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[351],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4612(t3,t2);}

/* k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4612,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4615(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4973,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 887  load-verbose */
t4=C_retrieve(lf[350]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}

/* k4971 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 888  print-banner */
t2=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 889  member* */
f_4217(t3,lf[349],((C_word*)((C_word*)t0)[6])[1]);}

/* k4956 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4958,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4961(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 890  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[348]);}}
else{
t2=((C_word*)t0)[3];
f_4618(2,t2,C_SCHEME_UNDEFINED);}}

/* k4959 in k4956 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 891  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[347]);}

/* k4962 in k4959 in k4956 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 892  case-sensitive */
t2=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 893  collect-options */
t4=((C_word*)t0)[2];
f_4450(t4,t3,lf[345]);}

/* k4953 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4951,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 894  collect-options */
t4=((C_word*)t0)[2];
f_4450(t4,t3,lf[344]);}

/* k4949 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4931,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4947,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 897  collect-options */
t6=((C_word*)t0)[2];
f_4450(t6,t5,lf[342]);}

/* k4945 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4933 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4943,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 898  collect-options */
t4=((C_word*)t0)[2];
f_4450(t4,t3,lf[341]);}

/* k4941 in k4933 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4937 in k4933 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 897  append */
t2=*((C_word*)lf[263]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[175]),((C_word*)t0)[2]);}

/* k4929 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 896  deldups */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[340]+1));}

/* k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=C_mutate((C_word*)lf[175]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[302],C_retrieve(lf[18]));
t4=C_mutate((C_word*)lf[18]+1,t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 903  provide */
t6=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[339]);}

/* k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[330],t4))){
/* csi.scm: 908  keyword-style */
t5=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,lf[332]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[333],t5))){
/* csi.scm: 910  keyword-style */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,lf[334]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[335],t6))){
/* csi.scm: 912  keyword-style */
t7=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,lf[336]);}
else{
t7=t2;
f_4638(2,t7,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 906  ##sys#error */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[337]);}}
else{
t3=t2;
f_4638(2,t3,C_SCHEME_UNDEFINED);}}

/* k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4865,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 913  member* */
f_4217(t3,lf[329],((C_word*)((C_word*)t0)[2])[1]);}

/* k4863 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4641(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4497,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 861  ##sys#string-append */
t4=C_retrieve(lf[327]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[328],lf[14]);}}

/* k4495 in k4863 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4503,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 862  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4501 in k4495 in k4863 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 863  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4525,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 864  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[326]);}}

/* k4523 in k4501 in k4495 in k4863 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[325]);
/* csi.scm: 864  chop-separator */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4507 in k4501 in k4495 in k4863 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 865  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[324],lf[14]);}

/* k4510 in k4507 in k4501 in k4495 in k4863 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4518,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 866  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4516 in k4510 in k4507 in k4501 in k4495 in k4863 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 867  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4641(2,t2,C_SCHEME_UNDEFINED);}}

/* k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4646(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4646(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4646,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 917  repl */
t5=C_retrieve(lf[303]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_member(t4,lf[304]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4674,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_4674(2,t8,t6);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[305]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[306]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[307]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[309]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[310]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t8=(C_word)C_i_cdr(((C_word*)t3)[1]);
t9=C_set_block_item(t3,0,t8);
t10=t7;
f_4674(2,t10,t9);}
else{
t8=(C_word)C_i_string_equal_p(lf[311],t4);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(lf[312],t4));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4703,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4719,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 930  string->symbol */
t13=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,t12);}
else{
t10=(C_word)C_i_string_equal_p(lf[314],t4);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(lf[315],t4));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4735,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 933  evalstring */
f_4530(t12,t13,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_i_string_equal_p(lf[316],t4);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(lf[317],t4));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cadr(((C_word*)t3)[1]);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4765,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 936  evalstring */
f_4530(t14,t15,(C_word)C_a_i_list(&a,1,t16));}
else{
t14=(C_word)C_i_string_equal_p(lf[319],t4);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(lf[320],t4));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4781,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_cadr(((C_word*)t3)[1]);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4791,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 941  evalstring */
f_4530(t16,t17,(C_word)C_a_i_list(&a,1,t18));}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4798,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 946  load */
t17=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,t4);}}}}}}}}

/* k4796 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4804,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=t2;
f_4804(t4,(C_word)C_i_string_equal_p(lf[323],t3));}
else{
t3=t2;
f_4804(t3,C_SCHEME_FALSE);}}

/* k4802 in k4796 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4804(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4804,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4809,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4819,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 948  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4674(2,t2,C_SCHEME_UNDEFINED);}}

/* a4818 in k4802 in k4796 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4819r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4819r(t0,t1,t2);}}

static void C_ccall f_4819r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4830,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_4830(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_4830(t4,C_SCHEME_FALSE);}}

/* k4828 in a4818 in k4802 in k4796 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 950  exit */
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a4808 in k4802 in k4796 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4817,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 948  command-line-arguments */
t3=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4815 in a4808 in k4802 in k4796 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
t2=C_retrieve(lf[321]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a4790 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4791r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4791r(t0,t1,t2);}}

static void C_ccall f_4791r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),C_retrieve(lf[72]),t2);}

/* k4779 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4674(2,t4,t3);}

/* a4764 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4765r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4765r(t0,t1,t2);}}

static void C_ccall f_4765r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),*((C_word*)lf[24]+1),t2);}

/* k4753 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4674(2,t4,t3);}

/* k4733 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4674(2,t4,t3);}

/* k4717 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4719,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],t1);
t3=(C_word)C_a_i_list(&a,2,lf[313],t2);
/* csi.scm: 930  eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k4701 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4674(2,t4,t3);}

/* k4672 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4646(t3,((C_word*)t0)[2],t2);}

/* k4657 in do959 in k4639 in k4636 in k4633 in k4626 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4598 in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 918  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4530(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4530,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4534,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4534(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4577,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4534(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4577 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 869  open-input-string */
t3=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4535 in k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4542 in k4535 in k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4546(t5,((C_word*)t0)[2],t1);}

/* do945 in k4542 in k4535 in k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4546,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4567,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4569,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 872  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[301]+1));}}

/* a4568 in do945 in k4542 in k4535 in k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4569,2,t0,t1);}
/* csi.scm: 872  eval */
t2=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4565 in do945 in k4542 in k4535 in k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 872  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4554 in do945 in k4542 in k4535 in k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4561 in k4554 in do945 in k4542 in k4535 in k4532 in evalstring in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4546(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4450(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4450,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4456,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4456(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4456(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4456,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 857  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[300],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4483,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 858  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4481 in loop in collect-options in k4446 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ##csi#run in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4274(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4274,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4280(t6,t1,t2);}

/* loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4280,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[293]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[294]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[295]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[296]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4302,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[291]);
t8=t4;
f_4302(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4302(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4302(t6,C_SCHEME_FALSE);}}}}

/* k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4302,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 813  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4280(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4318,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4352,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 814  substring */
t5=*((C_word*)lf[35]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 818  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4280(t4,t2,t3);}}

/* k4357 in k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4350 in k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[298]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4316 in k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4391,tmp=(C_word)a,a+=2,tmp);
t4=f_4391(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4341,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 817  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[297],((C_word*)t0)[2]);}}

/* a4340 in k4316 in k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4341,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4329 in k4316 in k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4335,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 816  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4280(t4,t2,t3);}

/* k4333 in k4329 in k4316 in k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 816  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4316 in k4300 in loop in canonicalize-args in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static C_word C_fcall f_4391(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4217(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4217,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4223(t7,t1,t3);}

/* loop in member* in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4223,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4235,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4235(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4235,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 788  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4223(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 790  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4158r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4158r(t0,t1,t2,t3);}}

static void C_ccall f_4158r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4162,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4162(2,t5,*((C_word*)lf[286]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4162(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 776  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4160 in ##csi#deldups in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4167,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4167(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4160 in ##csi#deldups in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4167,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4183,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4196,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 781  del */
t7=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4194 in recur in k4160 in ##csi#deldups in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 781  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4167(t2,((C_word*)t0)[2],t1);}

/* k4181 in recur in k4160 in ##csi#deldups in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3949,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3981,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3981(t10,t1,C_fix(0));}

/* do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3981,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 749  justify */
t5=((C_word*)t0)[2];
f_3952(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4154 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 749  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 750  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4066(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4066(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4066,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 755  fxmod */
t7=*((C_word*)lf[284]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 760  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4125 in do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4149,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 761  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4147 in k4125 in do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  justify */
t2=((C_word*)t0)[3];
f_3952(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4143 in k4125 in do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4128 in k4125 in do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4066(t4,((C_word*)t0)[2],t2,t3);}

/* k4083 in do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4103(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* do828 in k4083 in do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4103(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4103,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4113,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 759  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[283],((C_word*)t0)[2]);}}

/* k4111 in do828 in k4083 in do821 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4103(t3,((C_word*)t0)[2],t2);}

/* k3995 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 762  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k3998 in k3995 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4015(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* do836 in k3998 in k3995 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_4015(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4015,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 766  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4026 in do836 in k3998 in k3995 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 768  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 769  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4029 in k4026 in do836 in k3998 in k3995 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4015(t4,((C_word*)t0)[2],t2,t3);}

/* k4001 in k3998 in k3995 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 770  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4004 in k4001 in k3998 in k3995 in k3992 in k3989 in do811 in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3981(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3952,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3956,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 741  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3954 in justify in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3956,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 744  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3970 in k3954 in justify in ##csi#hexdump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 744  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3788r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3788r(t0,t1,t2,t3);}}

static void C_ccall f_3788r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3790,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3896,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3901,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len786798 */
t7=t6;
f_3901(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out787796 */
t9=t5;
f_3896(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body784789 */
t11=t4;
f_3790(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len786 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3901,NULL,2,t0,t1);}
/* def-out787796 */
t2=((C_word*)t0)[2];
f_3896(t2,t1,C_SCHEME_FALSE);}

/* def-out787 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3896,NULL,3,t0,t1,t2);}
/* body784789 */
t3=((C_word*)t0)[2];
f_3790(t3,t1,t2,*((C_word*)lf[148]+1));}

/* body784 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3790(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3790,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 723  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[278],lf[279],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3815,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 724  ##sys#bytevector? */
t6=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3813 in body784 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 724  bestlen */
t4=((C_word*)t0)[2];
f_3793(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 725  bestlen */
t4=((C_word*)t0)[2];
f_3793(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_pointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 727  hexdump */
t4=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[280]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3858(t6,(C_word)C_i_assq(t5,C_retrieve(lf[189])));}
else{
t5=t4;
f_3858(t5,C_SCHEME_FALSE);}}}}}

/* k3856 in k3813 in body784 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3858,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 730  bestlen */
t5=((C_word*)t0)[2];
f_3793(t5,t3,t4);}
else{
/* csi.scm: 731  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[278],lf[281],((C_word*)t0)[5]);}}

/* k3866 in k3856 in k3813 in body784 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 730  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3837 in k3813 in body784 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 725  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3820 in k3813 in body784 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 724  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* bestlen in body784 in ##csi#dump in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3793(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3793,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 722  min */
t3=*((C_word*)lf[277]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3782,4,t0,t1,t2,t3);}
/* csi.scm: 712  hash-table-set! */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve2(lf[191],"describer-table"),t2,t3);}

/* ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3024r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3024r(t0,t1,t2,t3);}}

static void C_ccall f_3024r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3028(2,t5,*((C_word*)lf[148]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3028(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 586  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3761,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 610  ##sys#block-address */
t5=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[9]);}
else{
t4=t3;
f_3156(2,t4,C_SCHEME_UNDEFINED);}}

/* k3759 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 610  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[274],t1);}

/* k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[11]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[11]));
/* csi.scm: 613  fprintf */
t4=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[9],lf[203],((C_word*)t0)[11],t3,t3,t3);}
else{
switch(((C_word*)t0)[11]){
case C_SCHEME_TRUE:
/* csi.scm: 614  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[204]);
case C_SCHEME_FALSE:
/* csi.scm: 615  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[205]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[11]))){
/* csi.scm: 616  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[206]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[11]))){
/* csi.scm: 617  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[207]);}
else{
t3=C_retrieve(lf[13]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[11]);
if(C_truep(t4)){
/* csi.scm: 618  fprintf */
t5=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[9],lf[208]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[11]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 620  fprintf */
t6=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[9],lf[210],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11]);}
else{
t5=(C_word)C_slot(lf[211],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[11],t5);
if(C_truep(t6)){
/* csi.scm: 625  fprintf */
t7=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[9],lf[212]);}
else{
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
/* csi.scm: 626  ##sys#number? */
t8=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[11]);}}}}}}}}

/* k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 626  fprintf */
t2=((C_word*)t0)[12];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[11],((C_word*)t0)[10],lf[213],((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[9]))){
/* csi.scm: 627  descseq */
t2=((C_word*)t0)[8];
f_3030(6,t2,((C_word*)t0)[11],lf[214],*((C_word*)lf[215]+1),((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
/* csi.scm: 628  descseq */
t2=((C_word*)t0)[8];
f_3030(6,t2,((C_word*)t0)[11],lf[216],*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[9]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3285,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 630  ##sys#symbol-has-toplevel-binding? */
t4=C_retrieve(lf[222]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
/* csi.scm: 634  descseq */
t2=((C_word*)t0)[8];
f_3030(6,t2,((C_word*)t0)[11],lf[223],((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* csi.scm: 635  fprintf */
t4=((C_word*)t0)[12];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[11],((C_word*)t0)[10],lf[224],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[9]))){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[9],t4);
t6=t3;
f_3362(t6,(C_word)C_eqp(C_retrieve(lf[229]),t5));}
else{
t4=t3;
f_3362(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3362(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 645  port? */
t3=C_retrieve(lf[272]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}}}}}}}}

/* k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_truep(t2)?lf[230]:lf[231]);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3421,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 651  ##sys#peek-unsigned-integer */
t7=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
/* csi.scm: 652  instance? */
t3=C_retrieve(lf[271]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t3=t2;
f_3430(2,t3,C_SCHEME_FALSE);}}}

/* k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 653  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 654  ##sys#locative? */
t3=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 656  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
if(C_truep((C_word)C_pointerp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 669  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 670  ##sys#bytevector? */
t3=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}}}

/* k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 672  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],lf[247],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 675  ##sys#lambda-info->string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[250]))){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[253]:lf[254]);
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
/* csi.scm: 678  fprintf */
t7=((C_word*)t0)[5];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[6],lf[255],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[256]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* csi.scm: 685  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],lf[261],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[266]))){
/* csi.scm: 695  provided? */
t3=C_retrieve(lf[267]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[268]);}
else{
t3=t2;
f_3667(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3665 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3667,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 696  unveil */
t2=C_retrieve(lf[262]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[6]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 699  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[191],"describer-table"),t2,C_SCHEME_FALSE);}
else{
/* csi.scm: 706  fprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[5],lf[265]);}}}

/* k3680 in k3665 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve(lf[189]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3710,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[63]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 704  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[264],t4);}}}

/* k3719 in k3680 in k3665 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 705  descseq */
t2=((C_word*)t0)[3];
f_3030(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3708 in k3680 in k3665 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3710,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 702  append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k3704 in k3680 in k3665 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_3689 in k3680 in k3665 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3689,3,t0,t1,t2);}
/* g769770 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3598 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a3604 in k3598 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3605,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3609,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 688  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[260],t2);}

/* k3607 in a3604 in k3598 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3618(t6,((C_word*)t0)[2],t2);}

/* loop in k3607 in a3604 in k3598 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3618,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3628,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 691  caar */
t5=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k3651 in loop in k3607 in a3604 in k3598 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 692  cdar */
t4=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_3628(2,t3,C_SCHEME_UNDEFINED);}}

/* k3643 in k3651 in loop in k3607 in a3604 in k3598 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 692  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[257],t1,t2);}

/* k3626 in loop in k3607 in a3604 in k3598 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 693  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3618(t3,((C_word*)t0)[2],t2);}

/* k3562 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 680  fprintf */
t4=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],lf[252],t3);}

/* k3565 in k3562 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 681  hash-table-walk */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3571 in k3565 in k3562 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3572,4,t0,t1,t2,t3);}
/* csi.scm: 683  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[251],t2,t3);}

/* k3550 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 675  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[248],t1);}

/* k3537 in k3531 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 673  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3525 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 669  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[244],t1);}

/* k3444 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3457,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3457(t5,lf[234]);
case C_fix(1):
t5=t4;
f_3457(t5,lf[235]);
case C_fix(2):
t5=t4;
f_3457(t5,lf[236]);
case C_fix(3):
t5=t4;
f_3457(t5,lf[237]);
case C_fix(4):
t5=t4;
f_3457(t5,lf[238]);
case C_fix(5):
t5=t4;
f_3457(t5,lf[239]);
case C_fix(6):
t5=t4;
f_3457(t5,lf[240]);
case C_fix(7):
t5=t4;
f_3457(t5,lf[241]);
case C_fix(8):
t5=t4;
f_3457(t5,lf[242]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3457(t6,(C_truep(t5)?lf[243]:C_SCHEME_UNDEFINED));}}

/* k3455 in k3444 in k3437 in k3428 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 655  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[233],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3419 in k3400 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 646  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[232],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3360 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 641  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3376,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 643  ##sys#peek-unsigned-integer */
t4=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],C_fix(0));}}

/* k3374 in k3360 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 643  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[226],t1);}

/* k3370 in k3360 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 642  descseq */
t2=((C_word*)t0)[3];
f_3030(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3316 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3285(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 630  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[221],((C_word*)t0)[2]);}}

/* k3283 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3298(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3298(t4,C_SCHEME_FALSE);}}

/* k3296 in k3283 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 632  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[220],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3288(2,t2,C_SCHEME_UNDEFINED);}}

/* k3286 in k3283 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 633  ##sys#symbol->string */
t3=C_retrieve(lf[219]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3293 in k3286 in k3283 in k3253 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 633  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[218],t1);}

/* k3223 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(65536)))){
/* csi.scm: 622  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[209],t2);}
else{
t4=t3;
f_3231(2,t4,C_SCHEME_UNDEFINED);}}

/* k3229 in k3223 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 623  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* k3157 in k3154 in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3030,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3153,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 589  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 590  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[202],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3037(2,t4,C_SCHEME_UNDEFINED);}}

/* k3035 in k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3042(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3035 in k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3042(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3042,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 594  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[196],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3065,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 596  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3063 in loop1 in k3035 in k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3074(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3063 in loop1 in k3035 in k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_3074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3074,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 599  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[201],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 606  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3136 in loop2 in k3063 in loop1 in k3035 in k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 606  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3074(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 607  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3074(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3082 in loop2 in k3063 in loop1 in k3035 in k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3087,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[197]:lf[198]);
/* csi.scm: 601  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[199],t3,t5);}
else{
/* csi.scm: 604  newline */
t3=*((C_word*)lf[200]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3085 in k3082 in loop2 in k3063 in loop1 in k3035 in k3151 in descseq in k3026 in ##csi#describe in k3020 in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 605  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3042(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2828r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2828r(t0,t1,t2);}}

static void C_ccall f_2828r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2836,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_2836(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 514  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 514  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 516  gc */
t3=C_retrieve(lf[188]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 517  ##sys#symbol-table-info */
t3=C_retrieve(lf[187]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 518  memory-statistics */
t3=C_retrieve(lf[186]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2850,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 520  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[185]);}

/* k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3000,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3004,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3008,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[184]),C_retrieve(lf[18]));}

/* k3006 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[183]+1));}

/* k3002 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k2998 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2966 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2967,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2971,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 523  display */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[182]);}

/* k2969 in a2966 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2975 in k2969 in a2966 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2984,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 526  make-string */
t7=*((C_word*)lf[181]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k2982 in a2975 in k2969 in a2966 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 526  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[180],((C_word*)t0)[2],t1);}

/* k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 540  machine-type */
t4=C_retrieve(lf[179]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2894 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[168]:lf[169]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 542  software-type */
t5=C_retrieve(lf[178]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2902 in k2894 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 543  software-version */
t3=C_retrieve(lf[177]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2906 in k2902 in k2894 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 544  build-platform */
t3=C_retrieve(lf[176]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2910 in k2906 in k2902 in k2894 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 546  shorten */
f_2850(t2,t3);}

/* k2914 in k2910 in k2906 in k2902 in k2894 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2920,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 547  shorten */
f_2850(t2,t3);}

/* k2918 in k2914 in k2910 in k2906 in k2902 in k2894 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[170]:lf[171]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[172]:lf[173]);
/* csi.scm: 529  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[174],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[175]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2869 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 554  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2872 in k2869 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 555  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[167]);}
else{
t3=t2;
f_2877(2,t3,C_SCHEME_UNDEFINED);}}

/* k2875 in k2872 in k2869 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 556  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[166]);}
else{
t3=t2;
f_2880(2,t3,C_SCHEME_UNDEFINED);}}

/* k2878 in k2875 in k2872 in k2869 in k2866 in k2863 in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_2850(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2850,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2858,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 519  truncate */
t5=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2856 in shorten in k2846 in k2843 in k2840 in a2837 in k2834 in ##csi#report in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2725,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 492  open-input-string */
t4=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2734,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2754,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2757,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  call-with-current-continuation */
t6=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2759,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2765,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  with-exception-handler */
t5=C_retrieve(lf[158]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2776 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2815 in a2776 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2816r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2816r(t0,t1,t2);}}

static void C_ccall f_2816r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2821 in a2815 in a2776 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2782 in a2776 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2791,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 500  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2789 in a2782 in a2776 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2793(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do683 in k2789 in a2782 in a2776 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_2793(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2793,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 502  reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2810,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 500  read */
t5=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2808 in do683 in k2789 in a2782 in a2776 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2793(t3,((C_word*)t0)[2],t1,t2);}

/* a2764 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2765,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2770 in a2764 in a2758 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
/* csi.scm: 499  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[156],((C_word*)t0)[2]);}

/* k2755 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2752 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2733 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2734,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2744,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 496  open-output-string */
t4=C_retrieve(lf[155]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2742 in a2733 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 497  write */
t3=*((C_word*)lf[70]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2745 in k2742 in a2733 in k2727 in ##csi#parse-option-string in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 498  get-output-string */
t2=C_retrieve(lf[154]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do-unbreak-all in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2705,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2711,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}

/* a2710 in do-unbreak-all in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2711,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k2703 in do-unbreak-all in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[104]=C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[13]));}

/* ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2410,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2415,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 396  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_retrieve(lf[76]));}

/* k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 397  trace-indent */
t4=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2416 in k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 398  write */
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2419 in k2416 in k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 399  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[152]);}

/* k2422 in k2419 in k2416 in k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2435,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2434 in k2422 in k2419 in k2416 in k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2435,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 402  write */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2437 in a2434 in k2422 in k2419 in k2416 in k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[148]+1));}

/* k2425 in k2422 in k2419 in k2416 in k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 405  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2428 in k2425 in k2422 in k2419 in k2416 in k2413 in ##csi#traced-procedure-exit in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 406  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2387,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2391,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 388  trace-indent */
t5=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2389 in ##csi#traced-procedure-entry in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 389  add1 */
t3=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[76]));}

/* k2393 in k2389 in ##csi#traced-procedure-entry in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 390  write */
t5=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2396 in k2393 in k2389 in ##csi#traced-procedure-entry in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 391  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2399 in k2396 in k2393 in k2389 in ##csi#traced-procedure-entry in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 392  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#trace-indent in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2363,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[148]+1));}

/* k2361 in ##csi#trace-indent in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2368(t5,((C_word*)t0)[2],C_retrieve(lf[76]));}

/* do617 in k2361 in ##csi#trace-indent in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_2368(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2368,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2378,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[148]+1));}}

/* k2376 in do617 in k2361 in ##csi#trace-indent in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 382  sub1 */
t3=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2383 in k2376 in do617 in k2361 in ##csi#trace-indent in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2368(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2318,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2324,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2324(t8,t1,t3);}

/* loop in ##csi#del in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_2324(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2324,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 371  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2338 in loop in ##csi#del in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 373  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2324(t4,t2,t3);}}

/* k2348 in k2338 in loop in ##csi#del in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1780,3,t0,t1,t2);}
t3=C_set_block_item(lf[76],0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 239  exit */
t4=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_1797(t6,(C_word)C_eqp(lf[145],t5));}
else{
t5=t4;
f_1797(t5,C_SCHEME_FALSE);}}}

/* k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_1797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1797,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 243  hash-table-ref/default */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[60],"command-table"),t2,C_SCHEME_FALSE);}
else{
t4=t3;
f_1803(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 359  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2298 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2299r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2299r(t0,t1,t2);}}

static void C_ccall f_2299r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2303,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 360  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2301 in a2298 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2292 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2293,2,t0,t1);}
/* csi.scm: 359  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[123],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 250  read */
t4=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[80]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 254  read */
t5=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[81]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 259  read */
t6=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[83]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 263  read */
t7=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 267  read */
t8=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[86]);
if(C_truep(t7)){
/* csi.scm: 272  report */
t8=C_retrieve(lf[87]);
((C_proc2)C_retrieve_proc(t8))(2,t8,((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[88]);
if(C_truep(t8)){
/* csi.scm: 273  exit */
t9=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t9))(2,t9,((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1940,a[2]=t10,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 275  read-line */
t12=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1974,a[2]=t11,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 279  read-line */
t13=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[96]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 283  read */
t13=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[100]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=t14,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 287  read-line */
t16=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[111]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2061,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2065,a[2]=t15,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 288  read-line */
t17=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[115]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2086,a[2]=t16,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 289  read-line */
t18=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[120]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2103,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=t17,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 290  read-line */
t19=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[122]);
if(C_truep(t16)){
/* csi.scm: 291  do-unbreak-all */
t17=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t17))(2,t17,((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t17)){
t18=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[126]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2137,a[2]=t19,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 295  read */
t21=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[127]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[101],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2169,a[2]=t20,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[129]+1),C_retrieve2(lf[101],"traced-procedures"));}
else{
t21=t20;
f_2146(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[131]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[132]))){
t21=C_retrieve(lf[132]);
t22=C_set_block_item(lf[132],0,C_SCHEME_FALSE);
/* csi.scm: 305  ##sys#break-resume */
t23=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t23))(3,t23,((C_word*)t0)[15],t21);}
else{
/* csi.scm: 306  display */
t21=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[134]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[135]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[136]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[136]));
/* csi.scm: 309  history-add */
t24=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[137]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 312  read */
t24=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[138]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 316  read-line */
t25=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[140]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 321  display */
t26=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[142]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 356  printf */
t26=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[143],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2277 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2253 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2263,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 347  hash-table-walk */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[60],"command-table"),t3);}

/* a2262 in k2253 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2263,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 352  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,C_make_character(32),t4);}
else{
/* csi.scm: 353  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[141],t2);}}

/* k2256 in k2253 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2234 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 317  system */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2237 in k2234 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2242,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 318  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2240 in k2237 in k2234 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2211 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 313  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2214 in k2211 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
/* csi.scm: 314  eval */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2221 in k2214 in k2211 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 314  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2195 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 310  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[136]));}

/* k2167 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 298  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* k2144 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[104],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),C_retrieve2(lf[104],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2157 in k2144 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 300  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[128],t1);}

/* k2135 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 295  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2131 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[125]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2105 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 290  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2101 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2097 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2672,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2671 in k2097 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2672,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2676,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 473  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2674 in a2671 in k2097 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 478  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[104],"broken-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 475  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[121],t1);}}

/* k2693 in k2674 in a2671 in k2097 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[104],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2084 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 289  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2080 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2078,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2591,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2604,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2603 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2604,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 452  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2606 in a2603 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2653,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 455  ##sys#warn */
t5=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[119],t1);}
else{
t4=t3;
f_2614(t4,C_SCHEME_UNDEFINED);}}

/* k2651 in k2606 in a2603 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 457  del */
t5=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}

/* k2658 in k2651 in k2606 in a2603 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
f_2614(t3,t2);}

/* k2612 in k2606 in a2603 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_2614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2614,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[104],"broken-procedures"));
t5=C_mutate(&lf[104],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 459  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[118],((C_word*)t0)[3]);}}

/* a2634 in k2612 in k2606 in a2603 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2635r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2635r(t0,t1,t2);}}

static void C_ccall f_2635r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2639,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 465  ##sys#break-entry */
t4=C_retrieve(lf[117]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2637 in a2634 in k2612 in k2606 in a2603 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2590 in k2076 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2591,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[116]));
/* csi.scm: 449  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k2063 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 288  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2059 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2055 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2550,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2549 in k2055 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2550,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2554,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 438  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2552 in a2549 in k2055 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 443  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 440  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[114],t1);}}

/* k2571 in k2552 in a2549 in k2055 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2042 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 287  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2038 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2456,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[101],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2469,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2468 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2469,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2473,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 414  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2471 in a2468 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures")))){
/* csi.scm: 416  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[103],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures")))){
/* csi.scm: 418  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[105]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[101],"traced-procedures"));
t5=C_mutate(&lf[101],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2512,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 421  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[108],t1);}}}}

/* a2511 in k2471 in a2468 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2512r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2512r(t0,t1,t2);}}

static void C_ccall f_2512r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2516,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 427  traced-procedure-entry */
t4=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2514 in a2511 in k2471 in a2468 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 428  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2526 in k2514 in a2511 in k2471 in a2468 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2527r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2527r(t0,t1,t2);}}

static void C_ccall f_2527r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2531,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 430  traced-procedure-exit */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2529 in a2526 in k2514 in a2511 in k2471 in a2468 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2520 in k2514 in a2511 in k2471 in a2468 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2455 in k2034 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2456,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 411  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1988,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2015 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2016r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2016r(t0,t1,t2);}}

static void C_ccall f_2016r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2020,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 285  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2018 in a2015 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1987 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[99]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1990 in a1987 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2003,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2002 in k1990 in a1987 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2003r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2003r(t0,t1,t2);}}

static void C_ccall f_2003r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2012 in a2002 in k1990 in a1987 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=C_retrieve(lf[97]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2005 in a2002 in k1990 in a1987 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1996 in k1990 in a1987 in k1981 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
/* csi.scm: 284  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1972 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1947 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a1956 in k1947 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1957,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily542 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[95],t3);}

/* a1962 in a1956 in k1947 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1963,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1967,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 280  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1965 in a1962 in a1956 in k1947 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 280  print* */
t2=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[94]);}

/* k1950 in k1947 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1938 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 275  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1928 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[91]),t1);}

/* k1931 in k1928 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1889 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 268  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1892 in k1889 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 269  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1895 in k1892 in k1889 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 270  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1898 in k1895 in k1892 in k1889 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 271  dump */
t2=C_retrieve(lf[84]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1874 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 264  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1877 in k1874 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 265  dump */
t2=C_retrieve(lf[84]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1859 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 260  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1862 in k1859 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 261  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1841 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 255  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1844 in k1841 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 256  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1847 in k1844 in k1841 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1822 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1834,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 251  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1832 in k1822 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 251  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1825 in k1822 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1807 in k1801 in k1795 in ##sys#repl-eval-hook in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* toplevel-command in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1739r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1739r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1739r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1743,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1743(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1743(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1741 in toplevel-command in k1735 in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1743,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[5],lf[62]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[62]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* csi.scm: 218  hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],C_retrieve2(lf[60],"command-table"),((C_word*)t0)[5],t4);}

/* ##sys#read-prompt-hook in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1730,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 209  tty-input? */
t3=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1728 in ##sys#read-prompt-hook in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 209  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k1706 in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 202  ##sys#tty-port? */
t3=C_retrieve(lf[56]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[57]+1));}}

/* ##csi#history-ref in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1683,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[31])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[50]),t3));}
else{
/* csi.scm: 194  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[54],t2);}}

/* ##csi#history-add in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1644,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[13]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[50]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1654,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[31]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1668,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 185  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[50]),t8);}
else{
t7=t6;
f_1654(t7,C_SCHEME_UNDEFINED);}}

/* k1666 in ##csi#history-add in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=((C_word*)t0)[2];
f_1654(t3,t2);}

/* k1652 in ##csi#history-add in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_1654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[50]),C_retrieve(lf[31]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[31]),C_fix(1));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1538,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 158  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[49]);}

/* k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1542,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=f_1428(t3);
if(C_truep(t4)){
/* csi.scm: 160  addext */
f_1490(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t5=((C_word*)t0)[5];
t6=(C_word)C_block_size(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=f_1517(t7,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t12=(C_truep(t10)?(C_word)C_i_foreign_block_argumentp(t10):C_SCHEME_FALSE);
t13=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t14=(C_word)stub486(t11,t12,t13);
/* ##sys#peek-nonnull-c-string */
t15=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t9,t14,C_fix(0));}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 164  addext */
f_1490(t9,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1581 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 166  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[47],((C_word*)t0)[2]);}}

/* k1587 in k1581 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 167  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[46]);}

/* k1594 in k1587 in k1581 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1598(t5,((C_word*)t0)[2],t1);}

/* loop in k1594 in k1587 in k1581 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_1598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1598,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 169  chop-separator */
t6=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1623 in loop in k1594 in k1587 in k1581 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 169  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1606 in loop in k1594 in k1587 in k1581 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 170  addext */
f_1490(t2,t1);}

/* k1609 in k1606 in loop in k1594 in k1587 in k1581 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 171  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1598(t3,((C_word*)t0)[4],t2);}}

/* k1564 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 163  chop-separator */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1578 in k1564 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[43],((C_word*)t0)[2]);}

/* k1574 in k1564 in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  addext */
f_1490(((C_word*)t0)[2],t1);}

/* loop in k1540 in ##csi#lookup-script-file in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static C_word C_fcall f_1517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=f_1428((C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* addext in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_fcall f_1490(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1490,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1497,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 147  file-exists? */
t4=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1495 in addext in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 149  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k1498 in k1495 in addext in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1506,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 150  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1504 in k1498 in k1495 in addext in k1469 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1444,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 132  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1442 in ##csi#chop-separator in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))?f_1428(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
/* csi.scm: 135  substring */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t1);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}}

/* dirseparator? in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static C_word C_fcall f_1428(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(t1,C_make_character(92));
return((C_truep(t2)?t2:(C_word)C_eqp(t1,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1418,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 121  history-ref */
t5=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1424 in ##sys#sharp-number-hook in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##sys#user-read-hook in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1389,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[31]),C_fix(1));
/* csi.scm: 116  history-ref */
t8=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
/* csi.scm: 117  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1404 in ##sys#user-read-hook in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1406,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##csi#print-banner in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1387,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 105  chicken-version */
t3=C_retrieve(lf[26]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k1385 in ##csi#print-banner in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 105  print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[12],t1,lf[25]);}

/* ##csi#print-usage in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1371,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 75   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[22]);}

/* k1369 in ##csi#print-usage in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 90   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[14]);}

/* k1372 in k1369 in ##csi#print-usage in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1293 in k1290 in k1287 in k1284 in k1205 in k1202 in k1199 in k1196 in k1193 in k1190 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 91   display */
t2=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[21]);}

/* assign in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1119,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[9],t2,lf[10]);}

/* k1121 in assign in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[7]),((C_word*)t0)[5]);}}}

/* k1158 in k1121 in assign in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1179,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1181,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a1180 in k1158 in k1121 in assign in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1181,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k1177 in k1158 in k1121 in assign in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 in k1068 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[764] = {
{"toplevelcsi.scm",(void*)C_toplevel},
{"f_1070csi.scm",(void*)f_1070},
{"f_1073csi.scm",(void*)f_1073},
{"f_1076csi.scm",(void*)f_1076},
{"f_1079csi.scm",(void*)f_1079},
{"f_1082csi.scm",(void*)f_1082},
{"f_8720csi.scm",(void*)f_8720},
{"f_8724csi.scm",(void*)f_8724},
{"f_8727csi.scm",(void*)f_8727},
{"f_8730csi.scm",(void*)f_8730},
{"f_8736csi.scm",(void*)f_8736},
{"f_8942csi.scm",(void*)f_8942},
{"f_8922csi.scm",(void*)f_8922},
{"f_8918csi.scm",(void*)f_8918},
{"f_8898csi.scm",(void*)f_8898},
{"f_8761csi.scm",(void*)f_8761},
{"f_8771csi.scm",(void*)f_8771},
{"f_8890csi.scm",(void*)f_8890},
{"f_8774csi.scm",(void*)f_8774},
{"f_8886csi.scm",(void*)f_8886},
{"f_8777csi.scm",(void*)f_8777},
{"f_8808csi.scm",(void*)f_8808},
{"f_8788csi.scm",(void*)f_8788},
{"f_8759csi.scm",(void*)f_8759},
{"f_1085csi.scm",(void*)f_1085},
{"f_8632csi.scm",(void*)f_8632},
{"f_8649csi.scm",(void*)f_8649},
{"f_8652csi.scm",(void*)f_8652},
{"f_8658csi.scm",(void*)f_8658},
{"f_1088csi.scm",(void*)f_1088},
{"f_8591csi.scm",(void*)f_8591},
{"f_8595csi.scm",(void*)f_8595},
{"f_1091csi.scm",(void*)f_1091},
{"f_8575csi.scm",(void*)f_8575},
{"f_8585csi.scm",(void*)f_8585},
{"f_8583csi.scm",(void*)f_8583},
{"f_1094csi.scm",(void*)f_1094},
{"f_8498csi.scm",(void*)f_8498},
{"f_8502csi.scm",(void*)f_8502},
{"f_8570csi.scm",(void*)f_8570},
{"f_8505csi.scm",(void*)f_8505},
{"f_8514csi.scm",(void*)f_8514},
{"f_8561csi.scm",(void*)f_8561},
{"f_8528csi.scm",(void*)f_8528},
{"f_8536csi.scm",(void*)f_8536},
{"f_8538csi.scm",(void*)f_8538},
{"f_8555csi.scm",(void*)f_8555},
{"f_8520csi.scm",(void*)f_8520},
{"f_8512csi.scm",(void*)f_8512},
{"f_1097csi.scm",(void*)f_1097},
{"f_8438csi.scm",(void*)f_8438},
{"f_8442csi.scm",(void*)f_8442},
{"f_1100csi.scm",(void*)f_1100},
{"f_8379csi.scm",(void*)f_8379},
{"f_8383csi.scm",(void*)f_8383},
{"f_8410csi.scm",(void*)f_8410},
{"f_1103csi.scm",(void*)f_1103},
{"f_8205csi.scm",(void*)f_8205},
{"f_8209csi.scm",(void*)f_8209},
{"f_8212csi.scm",(void*)f_8212},
{"f_8373csi.scm",(void*)f_8373},
{"f_8215csi.scm",(void*)f_8215},
{"f_8367csi.scm",(void*)f_8367},
{"f_8218csi.scm",(void*)f_8218},
{"f_8365csi.scm",(void*)f_8365},
{"f_8329csi.scm",(void*)f_8329},
{"f_8343csi.scm",(void*)f_8343},
{"f_8357csi.scm",(void*)f_8357},
{"f_8337csi.scm",(void*)f_8337},
{"f_8333csi.scm",(void*)f_8333},
{"f_8225csi.scm",(void*)f_8225},
{"f_8321csi.scm",(void*)f_8321},
{"f_8297csi.scm",(void*)f_8297},
{"f_8315csi.scm",(void*)f_8315},
{"f_8305csi.scm",(void*)f_8305},
{"f_8301csi.scm",(void*)f_8301},
{"f_8293csi.scm",(void*)f_8293},
{"f_8277csi.scm",(void*)f_8277},
{"f_8253csi.scm",(void*)f_8253},
{"f_8271csi.scm",(void*)f_8271},
{"f_8261csi.scm",(void*)f_8261},
{"f_8257csi.scm",(void*)f_8257},
{"f_8249csi.scm",(void*)f_8249},
{"f_1106csi.scm",(void*)f_1106},
{"f_8110csi.scm",(void*)f_8110},
{"f_8146csi.scm",(void*)f_8146},
{"f_8159csi.scm",(void*)f_8159},
{"f_8117csi.scm",(void*)f_8117},
{"f_1109csi.scm",(void*)f_1109},
{"f_8000csi.scm",(void*)f_8000},
{"f_8004csi.scm",(void*)f_8004},
{"f_8007csi.scm",(void*)f_8007},
{"f_8010csi.scm",(void*)f_8010},
{"f_8013csi.scm",(void*)f_8013},
{"f_8104csi.scm",(void*)f_8104},
{"f_8016csi.scm",(void*)f_8016},
{"f_8098csi.scm",(void*)f_8098},
{"f_8019csi.scm",(void*)f_8019},
{"f_8092csi.scm",(void*)f_8092},
{"f_8096csi.scm",(void*)f_8096},
{"f_8026csi.scm",(void*)f_8026},
{"f_8064csi.scm",(void*)f_8064},
{"f_8062csi.scm",(void*)f_8062},
{"f_1112csi.scm",(void*)f_1112},
{"f_7990csi.scm",(void*)f_7990},
{"f_1115csi.scm",(void*)f_1115},
{"f_7976csi.scm",(void*)f_7976},
{"f_1118csi.scm",(void*)f_1118},
{"f_1192csi.scm",(void*)f_1192},
{"f_1195csi.scm",(void*)f_1195},
{"f_7714csi.scm",(void*)f_7714},
{"f_7718csi.scm",(void*)f_7718},
{"f_7727csi.scm",(void*)f_7727},
{"f_7936csi.scm",(void*)f_7936},
{"f_7949csi.scm",(void*)f_7949},
{"f_7730csi.scm",(void*)f_7730},
{"f_7926csi.scm",(void*)f_7926},
{"f_7934csi.scm",(void*)f_7934},
{"f_7733csi.scm",(void*)f_7733},
{"f_7880csi.scm",(void*)f_7880},
{"f_7913csi.scm",(void*)f_7913},
{"f_7920csi.scm",(void*)f_7920},
{"f_7896csi.scm",(void*)f_7896},
{"f_7745csi.scm",(void*)f_7745},
{"f_7874csi.scm",(void*)f_7874},
{"f_7752csi.scm",(void*)f_7752},
{"f_7754csi.scm",(void*)f_7754},
{"f_7868csi.scm",(void*)f_7868},
{"f_7788csi.scm",(void*)f_7788},
{"f_7842csi.scm",(void*)f_7842},
{"f_7819csi.scm",(void*)f_7819},
{"f_7799csi.scm",(void*)f_7799},
{"f_7774csi.scm",(void*)f_7774},
{"f_7782csi.scm",(void*)f_7782},
{"f_7772csi.scm",(void*)f_7772},
{"f_7734csi.scm",(void*)f_7734},
{"f_7674csi.scm",(void*)f_7674},
{"f_7697csi.scm",(void*)f_7697},
{"f_7701csi.scm",(void*)f_7701},
{"f_7643csi.scm",(void*)f_7643},
{"f_7664csi.scm",(void*)f_7664},
{"f_1198csi.scm",(void*)f_1198},
{"f_7592csi.scm",(void*)f_7592},
{"f_7596csi.scm",(void*)f_7596},
{"f_7607csi.scm",(void*)f_7607},
{"f_7632csi.scm",(void*)f_7632},
{"f_1201csi.scm",(void*)f_1201},
{"f_7472csi.scm",(void*)f_7472},
{"f_7476csi.scm",(void*)f_7476},
{"f_7586csi.scm",(void*)f_7586},
{"f_7584csi.scm",(void*)f_7584},
{"f_7485csi.scm",(void*)f_7485},
{"f_7572csi.scm",(void*)f_7572},
{"f_7580csi.scm",(void*)f_7580},
{"f_7488csi.scm",(void*)f_7488},
{"f_7566csi.scm",(void*)f_7566},
{"f_7508csi.scm",(void*)f_7508},
{"f_7518csi.scm",(void*)f_7518},
{"f_7538csi.scm",(void*)f_7538},
{"f_7544csi.scm",(void*)f_7544},
{"f_7552csi.scm",(void*)f_7552},
{"f_7542csi.scm",(void*)f_7542},
{"f_7516csi.scm",(void*)f_7516},
{"f_7512csi.scm",(void*)f_7512},
{"f_7489csi.scm",(void*)f_7489},
{"f_1204csi.scm",(void*)f_1204},
{"f_7451csi.scm",(void*)f_7451},
{"f_7455csi.scm",(void*)f_7455},
{"f_1207csi.scm",(void*)f_1207},
{"f_7441csi.scm",(void*)f_7441},
{"f_1213csi.scm",(void*)f_1213},
{"f_1222csi.scm",(void*)f_1222},
{"f_1238csi.scm",(void*)f_1238},
{"f_1225csi.scm",(void*)f_1225},
{"f_1286csi.scm",(void*)f_1286},
{"f_7420csi.scm",(void*)f_7420},
{"f_7424csi.scm",(void*)f_7424},
{"f_1289csi.scm",(void*)f_1289},
{"f_7304csi.scm",(void*)f_7304},
{"f_7308csi.scm",(void*)f_7308},
{"f_7317csi.scm",(void*)f_7317},
{"f_7331csi.scm",(void*)f_7331},
{"f_7395csi.scm",(void*)f_7395},
{"f_7377csi.scm",(void*)f_7377},
{"f_7360csi.scm",(void*)f_7360},
{"f_1292csi.scm",(void*)f_1292},
{"f_7205csi.scm",(void*)f_7205},
{"f_7215csi.scm",(void*)f_7215},
{"f_7228csi.scm",(void*)f_7228},
{"f_7244csi.scm",(void*)f_7244},
{"f_7282csi.scm",(void*)f_7282},
{"f_7280csi.scm",(void*)f_7280},
{"f_7272csi.scm",(void*)f_7272},
{"f_7226csi.scm",(void*)f_7226},
{"f_1295csi.scm",(void*)f_1295},
{"f_7116csi.scm",(void*)f_7116},
{"f_7126csi.scm",(void*)f_7126},
{"f_7139csi.scm",(void*)f_7139},
{"f_7155csi.scm",(void*)f_7155},
{"f_7183csi.scm",(void*)f_7183},
{"f_7137csi.scm",(void*)f_7137},
{"f_1298csi.scm",(void*)f_1298},
{"f_6830csi.scm",(void*)f_6830},
{"f_7027csi.scm",(void*)f_7027},
{"f_7030csi.scm",(void*)f_7030},
{"f_7033csi.scm",(void*)f_7033},
{"f_7106csi.scm",(void*)f_7106},
{"f_7114csi.scm",(void*)f_7114},
{"f_7049csi.scm",(void*)f_7049},
{"f_7052csi.scm",(void*)f_7052},
{"f_7055csi.scm",(void*)f_7055},
{"f_7058csi.scm",(void*)f_7058},
{"f_7096csi.scm",(void*)f_7096},
{"f_7104csi.scm",(void*)f_7104},
{"f_7061csi.scm",(void*)f_7061},
{"f_6841csi.scm",(void*)f_6841},
{"f_6845csi.scm",(void*)f_6845},
{"f_6849csi.scm",(void*)f_6849},
{"f_6851csi.scm",(void*)f_6851},
{"f_6896csi.scm",(void*)f_6896},
{"f_6908csi.scm",(void*)f_6908},
{"f_6904csi.scm",(void*)f_6904},
{"f_6872csi.scm",(void*)f_6872},
{"f_7064csi.scm",(void*)f_7064},
{"f_6924csi.scm",(void*)f_6924},
{"f_7024csi.scm",(void*)f_7024},
{"f_6988csi.scm",(void*)f_6988},
{"f_6958csi.scm",(void*)f_6958},
{"f_7067csi.scm",(void*)f_7067},
{"f_7034csi.scm",(void*)f_7034},
{"f_7046csi.scm",(void*)f_7046},
{"f_7042csi.scm",(void*)f_7042},
{"f_1301csi.scm",(void*)f_1301},
{"f_6773csi.scm",(void*)f_6773},
{"f_6777csi.scm",(void*)f_6777},
{"f_1304csi.scm",(void*)f_1304},
{"f_6767csi.scm",(void*)f_6767},
{"f_1307csi.scm",(void*)f_1307},
{"f_6614csi.scm",(void*)f_6614},
{"f_6618csi.scm",(void*)f_6618},
{"f_6621csi.scm",(void*)f_6621},
{"f_6624csi.scm",(void*)f_6624},
{"f_6637csi.scm",(void*)f_6637},
{"f_6687csi.scm",(void*)f_6687},
{"f_6698csi.scm",(void*)f_6698},
{"f_6635csi.scm",(void*)f_6635},
{"f_1310csi.scm",(void*)f_1310},
{"f_6338csi.scm",(void*)f_6338},
{"f_6372csi.scm",(void*)f_6372},
{"f_6375csi.scm",(void*)f_6375},
{"f_6601csi.scm",(void*)f_6601},
{"f_6611csi.scm",(void*)f_6611},
{"f_6599csi.scm",(void*)f_6599},
{"f_6378csi.scm",(void*)f_6378},
{"f_6347csi.scm",(void*)f_6347},
{"f_6361csi.scm",(void*)f_6361},
{"f_6365csi.scm",(void*)f_6365},
{"f_6381csi.scm",(void*)f_6381},
{"f_6384csi.scm",(void*)f_6384},
{"f_6387csi.scm",(void*)f_6387},
{"f_6394csi.scm",(void*)f_6394},
{"f_6408csi.scm",(void*)f_6408},
{"f_6418csi.scm",(void*)f_6418},
{"f_6422csi.scm",(void*)f_6422},
{"f_6432csi.scm",(void*)f_6432},
{"f_6448csi.scm",(void*)f_6448},
{"f_6467csi.scm",(void*)f_6467},
{"f_6523csi.scm",(void*)f_6523},
{"f_6534csi.scm",(void*)f_6534},
{"f_6452csi.scm",(void*)f_6452},
{"f_6465csi.scm",(void*)f_6465},
{"f_6438csi.scm",(void*)f_6438},
{"f_6446csi.scm",(void*)f_6446},
{"f_6436csi.scm",(void*)f_6436},
{"f_6406csi.scm",(void*)f_6406},
{"f_1313csi.scm",(void*)f_1313},
{"f_6281csi.scm",(void*)f_6281},
{"f_6321csi.scm",(void*)f_6321},
{"f_6291csi.scm",(void*)f_6291},
{"f_1316csi.scm",(void*)f_1316},
{"f_6205csi.scm",(void*)f_6205},
{"f_6209csi.scm",(void*)f_6209},
{"f_6212csi.scm",(void*)f_6212},
{"f_1319csi.scm",(void*)f_1319},
{"f_6021csi.scm",(void*)f_6021},
{"f_6025csi.scm",(void*)f_6025},
{"f_6028csi.scm",(void*)f_6028},
{"f_6171csi.scm",(void*)f_6171},
{"f_6167csi.scm",(void*)f_6167},
{"f_6030csi.scm",(void*)f_6030},
{"f_6118csi.scm",(void*)f_6118},
{"f_6116csi.scm",(void*)f_6116},
{"f_6086csi.scm",(void*)f_6086},
{"f_6053csi.scm",(void*)f_6053},
{"f_1322csi.scm",(void*)f_1322},
{"f_5831csi.scm",(void*)f_5831},
{"f_5838csi.scm",(void*)f_5838},
{"f_6012csi.scm",(void*)f_6012},
{"f_6010csi.scm",(void*)f_6010},
{"f_5863csi.scm",(void*)f_5863},
{"f_5889csi.scm",(void*)f_5889},
{"f_5917csi.scm",(void*)f_5917},
{"f_5909csi.scm",(void*)f_5909},
{"f_5901csi.scm",(void*)f_5901},
{"f_5861csi.scm",(void*)f_5861},
{"f_1325csi.scm",(void*)f_1325},
{"f_5822csi.scm",(void*)f_5822},
{"f_5826csi.scm",(void*)f_5826},
{"f_1328csi.scm",(void*)f_1328},
{"f_5803csi.scm",(void*)f_5803},
{"f_5807csi.scm",(void*)f_5807},
{"f_5816csi.scm",(void*)f_5816},
{"f_5814csi.scm",(void*)f_5814},
{"f_1331csi.scm",(void*)f_1331},
{"f_5784csi.scm",(void*)f_5784},
{"f_5788csi.scm",(void*)f_5788},
{"f_5797csi.scm",(void*)f_5797},
{"f_5795csi.scm",(void*)f_5795},
{"f_1334csi.scm",(void*)f_1334},
{"f_5656csi.scm",(void*)f_5656},
{"f_5662csi.scm",(void*)f_5662},
{"f_5743csi.scm",(void*)f_5743},
{"f_5672csi.scm",(void*)f_5672},
{"f_5675csi.scm",(void*)f_5675},
{"f_5681csi.scm",(void*)f_5681},
{"f_5688csi.scm",(void*)f_5688},
{"f_5704csi.scm",(void*)f_5704},
{"f_1337csi.scm",(void*)f_1337},
{"f_5513csi.scm",(void*)f_5513},
{"f_5519csi.scm",(void*)f_5519},
{"f_5631csi.scm",(void*)f_5631},
{"f_5604csi.scm",(void*)f_5604},
{"f_5529csi.scm",(void*)f_5529},
{"f_5532csi.scm",(void*)f_5532},
{"f_5538csi.scm",(void*)f_5538},
{"f_5549csi.scm",(void*)f_5549},
{"f_5565csi.scm",(void*)f_5565},
{"f_1340csi.scm",(void*)f_1340},
{"f_5454csi.scm",(void*)f_5454},
{"f_1343csi.scm",(void*)f_1343},
{"f_5283csi.scm",(void*)f_5283},
{"f_5289csi.scm",(void*)f_5289},
{"f_5363csi.scm",(void*)f_5363},
{"f_5366csi.scm",(void*)f_5366},
{"f_5439csi.scm",(void*)f_5439},
{"f_5432csi.scm",(void*)f_5432},
{"f_5424csi.scm",(void*)f_5424},
{"f_5411csi.scm",(void*)f_5411},
{"f_5390csi.scm",(void*)f_5390},
{"f_5299csi.scm",(void*)f_5299},
{"f_1346csi.scm",(void*)f_1346},
{"f_5232csi.scm",(void*)f_5232},
{"f_1349csi.scm",(void*)f_1349},
{"f_5172csi.scm",(void*)f_5172},
{"f_5182csi.scm",(void*)f_5182},
{"f_5201csi.scm",(void*)f_5201},
{"f_5185csi.scm",(void*)f_5185},
{"f_1352csi.scm",(void*)f_1352},
{"f_1355csi.scm",(void*)f_1355},
{"f_1471csi.scm",(void*)f_1471},
{"f_5166csi.scm",(void*)f_5166},
{"f_1708csi.scm",(void*)f_1708},
{"f_1737csi.scm",(void*)f_1737},
{"f_3022csi.scm",(void*)f_3022},
{"f_5158csi.scm",(void*)f_5158},
{"f_5164csi.scm",(void*)f_5164},
{"f_5161csi.scm",(void*)f_5161},
{"f_4417csi.scm",(void*)f_4417},
{"f_5152csi.scm",(void*)f_5152},
{"f_4421csi.scm",(void*)f_4421},
{"f_5148csi.scm",(void*)f_5148},
{"f_4424csi.scm",(void*)f_4424},
{"f_4427csi.scm",(void*)f_4427},
{"f_4430csi.scm",(void*)f_4430},
{"f_5144csi.scm",(void*)f_5144},
{"f_5131csi.scm",(void*)f_5131},
{"f_5091csi.scm",(void*)f_5091},
{"f_5041csi.scm",(void*)f_5041},
{"f_5044csi.scm",(void*)f_5044},
{"f_5047csi.scm",(void*)f_5047},
{"f_5050csi.scm",(void*)f_5050},
{"f_5059csi.scm",(void*)f_5059},
{"f_4433csi.scm",(void*)f_4433},
{"f_4436csi.scm",(void*)f_4436},
{"f_5035csi.scm",(void*)f_5035},
{"f_4439csi.scm",(void*)f_4439},
{"f_4442csi.scm",(void*)f_4442},
{"f_5026csi.scm",(void*)f_5026},
{"f_5022csi.scm",(void*)f_5022},
{"f_4448csi.scm",(void*)f_4448},
{"f_4600csi.scm",(void*)f_4600},
{"f_5011csi.scm",(void*)f_5011},
{"f_5014csi.scm",(void*)f_5014},
{"f_4603csi.scm",(void*)f_4603},
{"f_5002csi.scm",(void*)f_5002},
{"f_5005csi.scm",(void*)f_5005},
{"f_4606csi.scm",(void*)f_4606},
{"f_4999csi.scm",(void*)f_4999},
{"f_4992csi.scm",(void*)f_4992},
{"f_4609csi.scm",(void*)f_4609},
{"f_4979csi.scm",(void*)f_4979},
{"f_4982csi.scm",(void*)f_4982},
{"f_4612csi.scm",(void*)f_4612},
{"f_4973csi.scm",(void*)f_4973},
{"f_4615csi.scm",(void*)f_4615},
{"f_4958csi.scm",(void*)f_4958},
{"f_4961csi.scm",(void*)f_4961},
{"f_4964csi.scm",(void*)f_4964},
{"f_4618csi.scm",(void*)f_4618},
{"f_4955csi.scm",(void*)f_4955},
{"f_4621csi.scm",(void*)f_4621},
{"f_4951csi.scm",(void*)f_4951},
{"f_4624csi.scm",(void*)f_4624},
{"f_4947csi.scm",(void*)f_4947},
{"f_4935csi.scm",(void*)f_4935},
{"f_4943csi.scm",(void*)f_4943},
{"f_4939csi.scm",(void*)f_4939},
{"f_4931csi.scm",(void*)f_4931},
{"f_4628csi.scm",(void*)f_4628},
{"f_4635csi.scm",(void*)f_4635},
{"f_4638csi.scm",(void*)f_4638},
{"f_4865csi.scm",(void*)f_4865},
{"f_4497csi.scm",(void*)f_4497},
{"f_4503csi.scm",(void*)f_4503},
{"f_4525csi.scm",(void*)f_4525},
{"f_4509csi.scm",(void*)f_4509},
{"f_4512csi.scm",(void*)f_4512},
{"f_4518csi.scm",(void*)f_4518},
{"f_4641csi.scm",(void*)f_4641},
{"f_4646csi.scm",(void*)f_4646},
{"f_4798csi.scm",(void*)f_4798},
{"f_4804csi.scm",(void*)f_4804},
{"f_4819csi.scm",(void*)f_4819},
{"f_4830csi.scm",(void*)f_4830},
{"f_4809csi.scm",(void*)f_4809},
{"f_4817csi.scm",(void*)f_4817},
{"f_4791csi.scm",(void*)f_4791},
{"f_4781csi.scm",(void*)f_4781},
{"f_4765csi.scm",(void*)f_4765},
{"f_4755csi.scm",(void*)f_4755},
{"f_4735csi.scm",(void*)f_4735},
{"f_4719csi.scm",(void*)f_4719},
{"f_4703csi.scm",(void*)f_4703},
{"f_4674csi.scm",(void*)f_4674},
{"f_4659csi.scm",(void*)f_4659},
{"f_4530csi.scm",(void*)f_4530},
{"f_4577csi.scm",(void*)f_4577},
{"f_4534csi.scm",(void*)f_4534},
{"f_4537csi.scm",(void*)f_4537},
{"f_4544csi.scm",(void*)f_4544},
{"f_4546csi.scm",(void*)f_4546},
{"f_4569csi.scm",(void*)f_4569},
{"f_4567csi.scm",(void*)f_4567},
{"f_4556csi.scm",(void*)f_4556},
{"f_4563csi.scm",(void*)f_4563},
{"f_4450csi.scm",(void*)f_4450},
{"f_4456csi.scm",(void*)f_4456},
{"f_4483csi.scm",(void*)f_4483},
{"f_4274csi.scm",(void*)f_4274},
{"f_4280csi.scm",(void*)f_4280},
{"f_4302csi.scm",(void*)f_4302},
{"f_4359csi.scm",(void*)f_4359},
{"f_4352csi.scm",(void*)f_4352},
{"f_4318csi.scm",(void*)f_4318},
{"f_4341csi.scm",(void*)f_4341},
{"f_4331csi.scm",(void*)f_4331},
{"f_4335csi.scm",(void*)f_4335},
{"f_4391csi.scm",(void*)f_4391},
{"f_4217csi.scm",(void*)f_4217},
{"f_4223csi.scm",(void*)f_4223},
{"f_4235csi.scm",(void*)f_4235},
{"f_4158csi.scm",(void*)f_4158},
{"f_4162csi.scm",(void*)f_4162},
{"f_4167csi.scm",(void*)f_4167},
{"f_4196csi.scm",(void*)f_4196},
{"f_4183csi.scm",(void*)f_4183},
{"f_3949csi.scm",(void*)f_3949},
{"f_3981csi.scm",(void*)f_3981},
{"f_4156csi.scm",(void*)f_4156},
{"f_3991csi.scm",(void*)f_3991},
{"f_3994csi.scm",(void*)f_3994},
{"f_4066csi.scm",(void*)f_4066},
{"f_4127csi.scm",(void*)f_4127},
{"f_4149csi.scm",(void*)f_4149},
{"f_4145csi.scm",(void*)f_4145},
{"f_4130csi.scm",(void*)f_4130},
{"f_4085csi.scm",(void*)f_4085},
{"f_4103csi.scm",(void*)f_4103},
{"f_4113csi.scm",(void*)f_4113},
{"f_3997csi.scm",(void*)f_3997},
{"f_4000csi.scm",(void*)f_4000},
{"f_4015csi.scm",(void*)f_4015},
{"f_4028csi.scm",(void*)f_4028},
{"f_4031csi.scm",(void*)f_4031},
{"f_4003csi.scm",(void*)f_4003},
{"f_4006csi.scm",(void*)f_4006},
{"f_3952csi.scm",(void*)f_3952},
{"f_3956csi.scm",(void*)f_3956},
{"f_3972csi.scm",(void*)f_3972},
{"f_3788csi.scm",(void*)f_3788},
{"f_3901csi.scm",(void*)f_3901},
{"f_3896csi.scm",(void*)f_3896},
{"f_3790csi.scm",(void*)f_3790},
{"f_3815csi.scm",(void*)f_3815},
{"f_3858csi.scm",(void*)f_3858},
{"f_3868csi.scm",(void*)f_3868},
{"f_3839csi.scm",(void*)f_3839},
{"f_3822csi.scm",(void*)f_3822},
{"f_3793csi.scm",(void*)f_3793},
{"f_3782csi.scm",(void*)f_3782},
{"f_3024csi.scm",(void*)f_3024},
{"f_3028csi.scm",(void*)f_3028},
{"f_3761csi.scm",(void*)f_3761},
{"f_3156csi.scm",(void*)f_3156},
{"f_3255csi.scm",(void*)f_3255},
{"f_3402csi.scm",(void*)f_3402},
{"f_3430csi.scm",(void*)f_3430},
{"f_3439csi.scm",(void*)f_3439},
{"f_3533csi.scm",(void*)f_3533},
{"f_3667csi.scm",(void*)f_3667},
{"f_3682csi.scm",(void*)f_3682},
{"f_3721csi.scm",(void*)f_3721},
{"f_3710csi.scm",(void*)f_3710},
{"f_3706csi.scm",(void*)f_3706},
{"f_3689csi.scm",(void*)f_3689},
{"f_3600csi.scm",(void*)f_3600},
{"f_3605csi.scm",(void*)f_3605},
{"f_3609csi.scm",(void*)f_3609},
{"f_3618csi.scm",(void*)f_3618},
{"f_3653csi.scm",(void*)f_3653},
{"f_3645csi.scm",(void*)f_3645},
{"f_3628csi.scm",(void*)f_3628},
{"f_3564csi.scm",(void*)f_3564},
{"f_3567csi.scm",(void*)f_3567},
{"f_3572csi.scm",(void*)f_3572},
{"f_3552csi.scm",(void*)f_3552},
{"f_3539csi.scm",(void*)f_3539},
{"f_3527csi.scm",(void*)f_3527},
{"f_3446csi.scm",(void*)f_3446},
{"f_3457csi.scm",(void*)f_3457},
{"f_3421csi.scm",(void*)f_3421},
{"f_3362csi.scm",(void*)f_3362},
{"f_3376csi.scm",(void*)f_3376},
{"f_3372csi.scm",(void*)f_3372},
{"f_3318csi.scm",(void*)f_3318},
{"f_3285csi.scm",(void*)f_3285},
{"f_3298csi.scm",(void*)f_3298},
{"f_3288csi.scm",(void*)f_3288},
{"f_3295csi.scm",(void*)f_3295},
{"f_3225csi.scm",(void*)f_3225},
{"f_3231csi.scm",(void*)f_3231},
{"f_3159csi.scm",(void*)f_3159},
{"f_3030csi.scm",(void*)f_3030},
{"f_3153csi.scm",(void*)f_3153},
{"f_3037csi.scm",(void*)f_3037},
{"f_3042csi.scm",(void*)f_3042},
{"f_3065csi.scm",(void*)f_3065},
{"f_3074csi.scm",(void*)f_3074},
{"f_3138csi.scm",(void*)f_3138},
{"f_3084csi.scm",(void*)f_3084},
{"f_3087csi.scm",(void*)f_3087},
{"f_2828csi.scm",(void*)f_2828},
{"f_2836csi.scm",(void*)f_2836},
{"f_2838csi.scm",(void*)f_2838},
{"f_2842csi.scm",(void*)f_2842},
{"f_2845csi.scm",(void*)f_2845},
{"f_2848csi.scm",(void*)f_2848},
{"f_2865csi.scm",(void*)f_2865},
{"f_3008csi.scm",(void*)f_3008},
{"f_3004csi.scm",(void*)f_3004},
{"f_3000csi.scm",(void*)f_3000},
{"f_2967csi.scm",(void*)f_2967},
{"f_2971csi.scm",(void*)f_2971},
{"f_2976csi.scm",(void*)f_2976},
{"f_2984csi.scm",(void*)f_2984},
{"f_2868csi.scm",(void*)f_2868},
{"f_2896csi.scm",(void*)f_2896},
{"f_2904csi.scm",(void*)f_2904},
{"f_2908csi.scm",(void*)f_2908},
{"f_2912csi.scm",(void*)f_2912},
{"f_2916csi.scm",(void*)f_2916},
{"f_2920csi.scm",(void*)f_2920},
{"f_2871csi.scm",(void*)f_2871},
{"f_2874csi.scm",(void*)f_2874},
{"f_2877csi.scm",(void*)f_2877},
{"f_2880csi.scm",(void*)f_2880},
{"f_2850csi.scm",(void*)f_2850},
{"f_2858csi.scm",(void*)f_2858},
{"f_2725csi.scm",(void*)f_2725},
{"f_2729csi.scm",(void*)f_2729},
{"f_2759csi.scm",(void*)f_2759},
{"f_2777csi.scm",(void*)f_2777},
{"f_2816csi.scm",(void*)f_2816},
{"f_2822csi.scm",(void*)f_2822},
{"f_2783csi.scm",(void*)f_2783},
{"f_2791csi.scm",(void*)f_2791},
{"f_2793csi.scm",(void*)f_2793},
{"f_2810csi.scm",(void*)f_2810},
{"f_2765csi.scm",(void*)f_2765},
{"f_2771csi.scm",(void*)f_2771},
{"f_2757csi.scm",(void*)f_2757},
{"f_2754csi.scm",(void*)f_2754},
{"f_2734csi.scm",(void*)f_2734},
{"f_2744csi.scm",(void*)f_2744},
{"f_2747csi.scm",(void*)f_2747},
{"f_2701csi.scm",(void*)f_2701},
{"f_2711csi.scm",(void*)f_2711},
{"f_2705csi.scm",(void*)f_2705},
{"f_2410csi.scm",(void*)f_2410},
{"f_2415csi.scm",(void*)f_2415},
{"f_2418csi.scm",(void*)f_2418},
{"f_2421csi.scm",(void*)f_2421},
{"f_2424csi.scm",(void*)f_2424},
{"f_2435csi.scm",(void*)f_2435},
{"f_2439csi.scm",(void*)f_2439},
{"f_2427csi.scm",(void*)f_2427},
{"f_2430csi.scm",(void*)f_2430},
{"f_2387csi.scm",(void*)f_2387},
{"f_2391csi.scm",(void*)f_2391},
{"f_2395csi.scm",(void*)f_2395},
{"f_2398csi.scm",(void*)f_2398},
{"f_2401csi.scm",(void*)f_2401},
{"f_2359csi.scm",(void*)f_2359},
{"f_2363csi.scm",(void*)f_2363},
{"f_2368csi.scm",(void*)f_2368},
{"f_2378csi.scm",(void*)f_2378},
{"f_2385csi.scm",(void*)f_2385},
{"f_2318csi.scm",(void*)f_2318},
{"f_2324csi.scm",(void*)f_2324},
{"f_2340csi.scm",(void*)f_2340},
{"f_2350csi.scm",(void*)f_2350},
{"f_1780csi.scm",(void*)f_1780},
{"f_1797csi.scm",(void*)f_1797},
{"f_2299csi.scm",(void*)f_2299},
{"f_2303csi.scm",(void*)f_2303},
{"f_2293csi.scm",(void*)f_2293},
{"f_1803csi.scm",(void*)f_1803},
{"f_2279csi.scm",(void*)f_2279},
{"f_2255csi.scm",(void*)f_2255},
{"f_2263csi.scm",(void*)f_2263},
{"f_2258csi.scm",(void*)f_2258},
{"f_2236csi.scm",(void*)f_2236},
{"f_2239csi.scm",(void*)f_2239},
{"f_2242csi.scm",(void*)f_2242},
{"f_2213csi.scm",(void*)f_2213},
{"f_2216csi.scm",(void*)f_2216},
{"f_2223csi.scm",(void*)f_2223},
{"f_2197csi.scm",(void*)f_2197},
{"f_2169csi.scm",(void*)f_2169},
{"f_2146csi.scm",(void*)f_2146},
{"f_2159csi.scm",(void*)f_2159},
{"f_2137csi.scm",(void*)f_2137},
{"f_2133csi.scm",(void*)f_2133},
{"f_2107csi.scm",(void*)f_2107},
{"f_2103csi.scm",(void*)f_2103},
{"f_2099csi.scm",(void*)f_2099},
{"f_2672csi.scm",(void*)f_2672},
{"f_2676csi.scm",(void*)f_2676},
{"f_2695csi.scm",(void*)f_2695},
{"f_2086csi.scm",(void*)f_2086},
{"f_2082csi.scm",(void*)f_2082},
{"f_2078csi.scm",(void*)f_2078},
{"f_2604csi.scm",(void*)f_2604},
{"f_2608csi.scm",(void*)f_2608},
{"f_2653csi.scm",(void*)f_2653},
{"f_2660csi.scm",(void*)f_2660},
{"f_2614csi.scm",(void*)f_2614},
{"f_2635csi.scm",(void*)f_2635},
{"f_2639csi.scm",(void*)f_2639},
{"f_2591csi.scm",(void*)f_2591},
{"f_2065csi.scm",(void*)f_2065},
{"f_2061csi.scm",(void*)f_2061},
{"f_2057csi.scm",(void*)f_2057},
{"f_2550csi.scm",(void*)f_2550},
{"f_2554csi.scm",(void*)f_2554},
{"f_2573csi.scm",(void*)f_2573},
{"f_2044csi.scm",(void*)f_2044},
{"f_2040csi.scm",(void*)f_2040},
{"f_2036csi.scm",(void*)f_2036},
{"f_2469csi.scm",(void*)f_2469},
{"f_2473csi.scm",(void*)f_2473},
{"f_2512csi.scm",(void*)f_2512},
{"f_2516csi.scm",(void*)f_2516},
{"f_2527csi.scm",(void*)f_2527},
{"f_2531csi.scm",(void*)f_2531},
{"f_2521csi.scm",(void*)f_2521},
{"f_2456csi.scm",(void*)f_2456},
{"f_1983csi.scm",(void*)f_1983},
{"f_2016csi.scm",(void*)f_2016},
{"f_2020csi.scm",(void*)f_2020},
{"f_1988csi.scm",(void*)f_1988},
{"f_1992csi.scm",(void*)f_1992},
{"f_2003csi.scm",(void*)f_2003},
{"f_2014csi.scm",(void*)f_2014},
{"f_2007csi.scm",(void*)f_2007},
{"f_1997csi.scm",(void*)f_1997},
{"f_1974csi.scm",(void*)f_1974},
{"f_1949csi.scm",(void*)f_1949},
{"f_1957csi.scm",(void*)f_1957},
{"f_1963csi.scm",(void*)f_1963},
{"f_1967csi.scm",(void*)f_1967},
{"f_1952csi.scm",(void*)f_1952},
{"f_1940csi.scm",(void*)f_1940},
{"f_1930csi.scm",(void*)f_1930},
{"f_1933csi.scm",(void*)f_1933},
{"f_1891csi.scm",(void*)f_1891},
{"f_1894csi.scm",(void*)f_1894},
{"f_1897csi.scm",(void*)f_1897},
{"f_1900csi.scm",(void*)f_1900},
{"f_1876csi.scm",(void*)f_1876},
{"f_1879csi.scm",(void*)f_1879},
{"f_1861csi.scm",(void*)f_1861},
{"f_1864csi.scm",(void*)f_1864},
{"f_1843csi.scm",(void*)f_1843},
{"f_1846csi.scm",(void*)f_1846},
{"f_1849csi.scm",(void*)f_1849},
{"f_1824csi.scm",(void*)f_1824},
{"f_1834csi.scm",(void*)f_1834},
{"f_1827csi.scm",(void*)f_1827},
{"f_1809csi.scm",(void*)f_1809},
{"f_1739csi.scm",(void*)f_1739},
{"f_1743csi.scm",(void*)f_1743},
{"f_1723csi.scm",(void*)f_1723},
{"f_1730csi.scm",(void*)f_1730},
{"f_1710csi.scm",(void*)f_1710},
{"f_1683csi.scm",(void*)f_1683},
{"f_1644csi.scm",(void*)f_1644},
{"f_1668csi.scm",(void*)f_1668},
{"f_1654csi.scm",(void*)f_1654},
{"f_1538csi.scm",(void*)f_1538},
{"f_1542csi.scm",(void*)f_1542},
{"f_1583csi.scm",(void*)f_1583},
{"f_1589csi.scm",(void*)f_1589},
{"f_1596csi.scm",(void*)f_1596},
{"f_1598csi.scm",(void*)f_1598},
{"f_1625csi.scm",(void*)f_1625},
{"f_1608csi.scm",(void*)f_1608},
{"f_1611csi.scm",(void*)f_1611},
{"f_1566csi.scm",(void*)f_1566},
{"f_1580csi.scm",(void*)f_1580},
{"f_1576csi.scm",(void*)f_1576},
{"f_1517csi.scm",(void*)f_1517},
{"f_1490csi.scm",(void*)f_1490},
{"f_1497csi.scm",(void*)f_1497},
{"f_1500csi.scm",(void*)f_1500},
{"f_1506csi.scm",(void*)f_1506},
{"f_1440csi.scm",(void*)f_1440},
{"f_1444csi.scm",(void*)f_1444},
{"f_1428csi.scm",(void*)f_1428},
{"f_1418csi.scm",(void*)f_1418},
{"f_1426csi.scm",(void*)f_1426},
{"f_1389csi.scm",(void*)f_1389},
{"f_1406csi.scm",(void*)f_1406},
{"f_1379csi.scm",(void*)f_1379},
{"f_1387csi.scm",(void*)f_1387},
{"f_1367csi.scm",(void*)f_1367},
{"f_1371csi.scm",(void*)f_1371},
{"f_1374csi.scm",(void*)f_1374},
{"f_1119csi.scm",(void*)f_1119},
{"f_1123csi.scm",(void*)f_1123},
{"f_1160csi.scm",(void*)f_1160},
{"f_1181csi.scm",(void*)f_1181},
{"f_1179csi.scm",(void*)f_1179},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
