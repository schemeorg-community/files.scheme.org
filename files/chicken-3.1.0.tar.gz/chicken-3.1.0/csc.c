/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:48
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: csc.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csc.c
   used units: library eval extras extras srfi_1 srfi_13 utils
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif

#ifndef C_TARGET_CFLAGS
# define C_TARGET_CFLAGS  C_INSTALL_CFLAGS
#endif

#ifndef C_TARGET_LDFLAGS
# define C_TARGET_LDFLAGS  C_INSTALL_LDFLAGS
#endif

#ifndef C_TARGET_BIN_HOME
# define C_TARGET_BIN_HOME  C_INSTALL_BIN_HOME
#endif

#ifndef C_TARGET_LIB_HOME
# define C_TARGET_LIB_HOME  C_INSTALL_LIB_HOME
#endif

#ifndef C_TARGET_STATIC_LIB_HOME
# define C_TARGET_STATIC_LIB_HOME  C_INSTALL_STATIC_LIB_HOME
#endif

#ifndef C_TARGET_INCLUDE_HOME
# define C_TARGET_INCLUDE_HOME  C_INSTALL_INCLUDE_HOME
#endif

#ifndef C_TARGET_SHARE_HOME
# define C_TARGET_SHARE_HOME  C_INSTALL_SHARE_HOME
#endif

#ifndef C_TARGET_RUN_LIB_HOME
# define C_TARGET_RUN_LIB_HOME    C_TARGET_LIB_HOME
#endif

#ifndef C_CHICKEN_PROGRAM
# define C_CHICKEN_PROGRAM     "chicken"
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[370];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_fcall f_414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_472)
static void C_ccall f_472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_476)
static void C_ccall f_476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_523)
static void C_ccall f_523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_535)
static void C_ccall f_535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_540)
static void C_ccall f_540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_fcall f_578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_586)
static void C_fcall f_586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_595)
static void C_ccall f_595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_610)
static void C_fcall f_610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_708)
static void C_fcall f_708(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_fcall f_1367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_fcall f_1608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_fcall f_1611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_fcall f_1614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_fcall f_1665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_fcall f_1674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_fcall f_1900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_fcall f_1752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_fcall f_1258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1231)
static void C_ccall f_1231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_fcall f_1103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_885)
static void C_ccall f_885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_866)
static void C_ccall f_866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_718)
static void C_ccall f_718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_fcall f_803(C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_fcall f_806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_fcall f_2319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_fcall f_2264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_fcall f_2279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2187)
static void C_fcall f_2187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_fcall f_2120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_fcall f_2457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_fcall f_679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_684)
static void C_ccall f_684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_fcall f_640(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_658)
static void C_ccall f_658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_fcall f_633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_638)
static void C_ccall f_638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_fcall f_2901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_fcall f_2817(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2847)
static void C_fcall f_2847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_fcall f_2715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_fcall f_2663(C_word t0) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_fcall f_2566(C_word t0) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_fcall f_2576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_fcall f_2581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_fcall f_2622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_fcall f_2626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_fcall f_2414(C_word t0) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_458)
static void C_fcall f_458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_445)
static void C_fcall f_445(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_416)
static void C_fcall f_416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_420)
static void C_ccall f_420(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_414)
static void C_fcall trf_414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_414(t0,t1);}

C_noret_decl(trf_578)
static void C_fcall trf_578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_578(t0,t1);}

C_noret_decl(trf_586)
static void C_fcall trf_586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_586(t0,t1);}

C_noret_decl(trf_610)
static void C_fcall trf_610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_610(t0,t1);}

C_noret_decl(trf_708)
static void C_fcall trf_708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_708(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_708(t0,t1,t2);}

C_noret_decl(trf_1367)
static void C_fcall trf_1367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1367(t0,t1);}

C_noret_decl(trf_1608)
static void C_fcall trf_1608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1608(t0,t1);}

C_noret_decl(trf_1611)
static void C_fcall trf_1611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1611(t0,t1);}

C_noret_decl(trf_1614)
static void C_fcall trf_1614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1614(t0,t1);}

C_noret_decl(trf_1665)
static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1665(t0,t1);}

C_noret_decl(trf_1674)
static void C_fcall trf_1674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1674(t0,t1);}

C_noret_decl(trf_1900)
static void C_fcall trf_1900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1900(t0,t1);}

C_noret_decl(trf_1752)
static void C_fcall trf_1752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1752(t0,t1);}

C_noret_decl(trf_1258)
static void C_fcall trf_1258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1258(t0,t1);}

C_noret_decl(trf_1103)
static void C_fcall trf_1103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1103(t0,t1);}

C_noret_decl(trf_803)
static void C_fcall trf_803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_803(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_803(t0,t1);}

C_noret_decl(trf_806)
static void C_fcall trf_806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_806(t0,t1);}

C_noret_decl(trf_2319)
static void C_fcall trf_2319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2319(t0,t1);}

C_noret_decl(trf_2264)
static void C_fcall trf_2264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2264(t0,t1);}

C_noret_decl(trf_2279)
static void C_fcall trf_2279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2279(t0,t1);}

C_noret_decl(trf_2187)
static void C_fcall trf_2187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2187(t0,t1);}

C_noret_decl(trf_2120)
static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2120(t0,t1);}

C_noret_decl(trf_2457)
static void C_fcall trf_2457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2457(t0,t1);}

C_noret_decl(trf_679)
static void C_fcall trf_679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_679(t0,t1);}

C_noret_decl(trf_640)
static void C_fcall trf_640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_640(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_640(t0,t1,t2,t3);}

C_noret_decl(trf_633)
static void C_fcall trf_633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_633(t0,t1);}

C_noret_decl(trf_2901)
static void C_fcall trf_2901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2901(t0,t1);}

C_noret_decl(trf_2817)
static void C_fcall trf_2817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2817(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2817(t0,t1,t2);}

C_noret_decl(trf_2847)
static void C_fcall trf_2847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2847(t0,t1);}

C_noret_decl(trf_2715)
static void C_fcall trf_2715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2715(t0,t1);}

C_noret_decl(trf_2663)
static void C_fcall trf_2663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2663(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2663(t0);}

C_noret_decl(trf_2566)
static void C_fcall trf_2566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2566(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2566(t0);}

C_noret_decl(trf_2576)
static void C_fcall trf_2576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2576(t0,t1);}

C_noret_decl(trf_2581)
static void C_fcall trf_2581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2581(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2581(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2622)
static void C_fcall trf_2622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2622(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2622(t0,t1);}

C_noret_decl(trf_2626)
static void C_fcall trf_2626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2626(t0,t1);}

C_noret_decl(trf_2414)
static void C_fcall trf_2414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2414(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2414(t0);}

C_noret_decl(trf_458)
static void C_fcall trf_458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_458(t0,t1);}

C_noret_decl(trf_445)
static void C_fcall trf_445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_445(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_445(t0,t1,t2,t3);}

C_noret_decl(trf_416)
static void C_fcall trf_416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_416(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_416(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2488)){
C_save(t1);
C_rereclaim2(2488*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,370);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[10]=C_h_intern(&lf[10],4,"exit");
lf[11]=C_h_intern(&lf[11],7,"fprintf");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[13]=C_h_intern(&lf[13],18,"current-error-port");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[22]=C_h_intern(&lf[22],13,"string-append");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[25]=C_h_intern(&lf[25],10,"string-any");
lf[26]=C_h_intern(&lf[26],16,"char-whitespace\077");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[49]=C_h_intern(&lf[49],26,"\003sysload-dynamic-extension");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[105]=C_h_intern(&lf[105],18,"string-intersperse");
lf[106]=C_h_intern(&lf[106],7,"\003sysmap");
lf[108]=C_h_intern(&lf[108],6,"append");
lf[110]=C_h_intern(&lf[110],7,"reverse");
lf[111]=C_h_intern(&lf[111],6,"static");
lf[112]=C_h_intern(&lf[112],14,"static-options");
lf[113]=C_h_intern(&lf[113],21,"extension-information");
lf[114]=C_h_intern(&lf[114],15,"repository-path");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[119]=C_h_intern(&lf[119],9,"\003syserror");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[124]=C_h_intern(&lf[124],17,"string-translate*");
lf[125]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[126]=C_h_intern(&lf[126],16,"\003syslist->string");
lf[127]=C_h_intern(&lf[127],5,"cons*");
lf[128]=C_h_intern(&lf[128],16,"\003sysstring->list");
lf[129]=C_h_intern(&lf[129],3,"any");
lf[132]=C_h_intern(&lf[132],6,"printf");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\0006*** Shell command terminated with exit status ~S: ~A~%");
lf[134]=C_h_intern(&lf[134],6,"system");
lf[135]=C_h_intern(&lf[135],5,"print");
lf[137]=C_h_intern(&lf[137],11,"delete-file");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[139]=C_h_intern(&lf[139],25,"\003sysimplicit-exit-handler");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[148]=C_h_intern(&lf[148],12,"\003sysfor-each");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[154]=C_h_intern(&lf[154],17,"\003syspeek-c-string");
lf[155]=C_h_intern(&lf[155],7,"sprintf");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\014mv ~A ~A.old");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[159]=C_h_intern(&lf[159],26,"pathname-replace-extension");
lf[160]=C_h_intern(&lf[160],4,"last");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[162]=C_h_intern(&lf[162],5,"error");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000!invalid entry in csc control file");
lf[164]=C_h_intern(&lf[164],12,"post-process");
lf[165]=C_h_intern(&lf[165],9,"c-options");
lf[166]=C_h_intern(&lf[166],12,"link-options");
lf[167]=C_h_intern(&lf[167],9,"read-file");
lf[168]=C_h_intern(&lf[168],9,"read-line");
lf[169]=C_h_intern(&lf[169],20,"with-input-from-file");
lf[170]=C_h_intern(&lf[170],12,"file-exists\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[172]=C_h_intern(&lf[172],4,"conc");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006-uses ");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\005#%eof");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[182]=C_h_intern(&lf[182],7,"newline");
lf[183]=C_h_intern(&lf[183],6,"print*");
lf[184]=C_h_intern(&lf[184],5,"-help");
lf[185]=C_h_intern(&lf[185],6,"--help");
lf[186]=C_h_intern(&lf[186],7,"display");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\036\343Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Any Scheme, C or object\012  files and all libraries given on the comm"
"and line are translated, compiled or\012  linked as needed.\012\012  General options:\012\012  "
"  -h  -help                   display this text and exit\012    -v                 "
"         show intermediate compilation stages\012    -v2  -verbose               di"
"splay information about translation progress\012    -v3                         dis"
"play information about all compilation stages\012    -V  -version                di"
"splay Scheme compiler version and exit\012    -release                    display r"
"elease number and exit\012\012  File and pathname options:\012\012    -o -output-file FILENA"
"ME    specifies target executable name\012    -I -include-path PATHNAME   specifies"
" alternative path for included files\012    -to-stdout                  write compi"
"ler to stdout (implies -t)\012    -s -shared -dynamic         generate dynamically "
"loadable shared object file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYM"
"BOL \012                                register feature identifier\012    -c++       "
"                 Compile via a C++ source file (.cpp) \012    -objc                "
"       Compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    "
"-i -case-insensitive        don\047t preserve case of read symbols    \012    -K -keyw"
"ord-style STYLE     allow alternative keyword syntax (prefix, suffix or none)\012  "
"  -run-time-macros            macros are made available at run-time\012\012  Translati"
"on options:\012\012    -x  -explicit-use           do not use units `library\047 and `eva"
"l\047 by default\012    -P  -check-syntax           stop compilation after macro-expan"
"sion\012    -A  -analyze-only           stop compilation after first analysis pass\012"
"\012  Debugging options:\012\012    -w  -no-warnings            disable warnings\012    -dis"
"able-warning CLASS      disable specific class of warnings\012    -d0 -d1 -d2 -debu"
"g-level NUMBER\012                                set level of available debugging "
"information\012    -no-trace                   disable rudimentary debugging inform"
"ation\012    -profile                    executable emits profiling information \012  "
"  -accumulate-profile         executable emits profiling information in append m"
"ode\012    -profile-name FILENAME      name of the generated profile information fi"
"le\012    -emit-debug-info            emit additional debug-information\012    -emit-e"
"xports FILENAME      write exported toplevel variables to FILENAME\012    -G  -chec"
"k-imports          look for undefined toplevel variables\012    -import FILENAME   "
"         read externally exported symbols from FILENAME\012\012  Optimization options:"
"\012\012    -O -O1 -O2 -O3 -optimize-level NUMBER\012\011\011\011        enable certain sets of op"
"timization options\012    -optimize-leaf-routines     enable leaf routine optimizat"
"ion\012    -N  -no-usual-integrations  standard procedures may be redefined\012    -u "
" -unsafe                 disable safety checks\012    -b  -block                  e"
"nable block-compilation\012    -disable-interrupts         disable interrupts in co"
"mpiled code\012    -f  -fixnum-arithmetic      assume all numbers are fixnums\012    -"
"Ob  -benchmark-mode        equivalent to \047-block -optimize-level 3 \012            "
"                     -debug-level 0 -fixnum-arithmetic -lambda-lift \012           "
"                      -disable-interrupts\047\012    -lambda-lift                perfo"
"rm lambda-lifting\012    -unsafe-libraries           link with unsafe runtime syste"
"m\012    -disable-stack-overflow-checks  disables detection of stack-overflows\012    "
"-inline                     enable inlining\012    -inline-limit               set "
"inlining threshold\012    -disable-compiler-macros    disable expansion of compiler"
" macros\012\012  Configuration options:\012\012    -unit NAME                  compile file "
"as a library unit\012    -uses NAME                  declare library unit as used.\012"
"    -heap-size NUMBER           specifies heap-size of compiled executable\012    -"
"heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-growth "
"PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage PERCE"
"NTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-siz"
"e NUMBER\012\011\011                specifies nursery size of compiled executable\012    -X "
"-extend FILENAME         load file before compilation commences\012    -prelude EXP"
"RESSION         add expression to beginning of source file\012    -postlude EXPRESS"
"ION        add expression to end of source file\012    -prologue FILENAME          "
"include file before main source file\012    -epilogue FILENAME          include fil"
"e after main source file\012\012    -e  -embedded               compile as embedded (d"
"on\047t generate `main()\047)\012    -W  -windows                compile as Windows GUI a"
"pplication (MSVC only)\012    -R  -require-extension NAME require extension in comp"
"iled code\012    -E  -extension              compile as extension (dynamic or stati"
"c)\012    -dll -library               compile multiple units into a dynamic library"
"\012\012  Options to other passes:\012\012    -C OPTION                   pass option to C c"
"ompiler\012    -L OPTION                   pass option to linker\012    -I<DIR>       "
"              pass \042-I<DIR>\042 to C compiler (add include path)\012    -L<DIR>       "
"              pass \042-L<DIR>\042 to linker (add library path)\012    -k                "
"          keep intermediate files\012    -c                          stop after com"
"pilation to object files\012    -t                          stop after translation "
"to C\012    -cc COMPILER                select other C compiler than the default on"
"e\012    -cxx COMPILER               select other C++ compiler than the default one"
"\012    -ld COMPILER                select other linker than the default one\012    -l"
"LIBNAME                   link with given library (`libLIBNAME\047 on UNIX,\012       "
"                          `LIBNAME.lib\047 on Windows)                             "
"   \012    -static-libs                link with static CHICKEN libraries\012    -stat"
"ic                     generate completely statically linked executable\012    -sta"
"tic-extensions          link with static extensions (if available)\012    -F<DIR>  "
"                   pass \042-F<DIR>\042 to C compiler (add framework \012                "
"                 header path on Mac OS X)\012    -framework NAME             passed"
" to linker on Mac OS X\012    -rpath PATHNAME             add directory to runtime "
"library search path\012    -Wl,...                     pass linker options\012    -str"
"ip                      strip resulting binary\012\012  Inquiry options:\012\012    -home   "
"                    show home-directory (where support files go)\012    -cflags    "
"                 show required C-compiler flags and exit\012    -ldflags           "
"         show required linker flags and exit\012    -libs                       sho"
"w required libraries and exit\012    -cc-name                    show name of defau"
"lt C compiler used\012    -cxx-name                   show name of default C++ comp"
"iler used\012    -ld-name                    show name of default linker used\012    -"
"dry-run                    just show commands executed, don\047t run them \012        "
"                         (implies `-v\047)\012\012  Obscure options:\012\012    -debug MODES   "
"             display debugging output for the given modes\012    -compiler PATHNAME"
"          use other compiler than default `chicken\047\012    -disable-c-syntax-checks"
"    disable syntax checks of C code fragments\012    -raw                        do"
" not generate implicit init- and exit code\011\011\011       \012    -emit-external-prototyp"
"es-first  emit protoypes for callbacks before foreign\012                          "
"       declarations\012    -keep-shadowed-macros       do not remove shadowed macro"
"\012    -host                       compile for host when configured for cross-comp"
"iling\012\012  Options can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same a"
"s\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The contents of the environment var"
"iable CSC_OPTIONS are implicitly\012  passed to every invocation of `csc\047.\012");
lf[188]=C_h_intern(&lf[188],8,"-release");
lf[189]=C_h_intern(&lf[189],15,"chicken-version");
lf[190]=C_h_intern(&lf[190],8,"-version");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[192]=C_h_intern(&lf[192],4,"-c++");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[194]=C_h_intern(&lf[194],5,"-objc");
lf[195]=C_h_intern(&lf[195],7,"-static");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[198]=C_h_intern(&lf[198],12,"-static-libs");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[201]=C_h_intern(&lf[201],18,"-static-extensions");
lf[202]=C_h_intern(&lf[202],7,"-cflags");
lf[203]=C_h_intern(&lf[203],8,"-ldflags");
lf[204]=C_h_intern(&lf[204],8,"-cc-name");
lf[205]=C_h_intern(&lf[205],9,"-cxx-name");
lf[206]=C_h_intern(&lf[206],8,"-ld-name");
lf[207]=C_h_intern(&lf[207],5,"-home");
lf[208]=C_h_intern(&lf[208],5,"-libs");
lf[209]=C_h_intern(&lf[209],2,"-v");
lf[210]=C_h_intern(&lf[210],3,"-v2");
lf[211]=C_h_intern(&lf[211],8,"-verbose");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[213]=C_h_intern(&lf[213],2,"-w");
lf[214]=C_h_intern(&lf[214],12,"-no-warnings");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[217]=C_h_intern(&lf[217],3,"-v3");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[223]=C_h_intern(&lf[223],2,"-A");
lf[224]=C_h_intern(&lf[224],13,"-analyze-only");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[226]=C_h_intern(&lf[226],2,"-P");
lf[227]=C_h_intern(&lf[227],13,"-check-syntax");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[229]=C_h_intern(&lf[229],2,"-k");
lf[230]=C_h_intern(&lf[230],2,"-c");
lf[231]=C_h_intern(&lf[231],2,"-t");
lf[232]=C_h_intern(&lf[232],2,"-e");
lf[233]=C_h_intern(&lf[233],9,"-embedded");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[235]=C_h_intern(&lf[235],18,"-require-extension");
lf[236]=C_h_intern(&lf[236],2,"-R");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[238]=C_h_intern(&lf[238],8,"-windows");
lf[239]=C_h_intern(&lf[239],2,"-W");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[249]=C_h_intern(&lf[249],10,"-framework");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[251]=C_h_intern(&lf[251],2,"-o");
lf[252]=C_h_intern(&lf[252],2,"-O");
lf[253]=C_h_intern(&lf[253],3,"-O1");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[256]=C_h_intern(&lf[256],3,"-O2");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[259]=C_h_intern(&lf[259],3,"-O3");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[262]=C_h_intern(&lf[262],3,"-d0");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[265]=C_h_intern(&lf[265],3,"-d1");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[268]=C_h_intern(&lf[268],3,"-d2");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[271]=C_h_intern(&lf[271],8,"-dry-run");
lf[272]=C_h_intern(&lf[272],2,"-s");
lf[273]=C_h_intern(&lf[273],4,"-dll");
lf[274]=C_h_intern(&lf[274],8,"-library");
lf[275]=C_h_intern(&lf[275],9,"-compiler");
lf[276]=C_h_intern(&lf[276],3,"-cc");
lf[277]=C_h_intern(&lf[277],4,"-cxx");
lf[278]=C_h_intern(&lf[278],3,"-ld");
lf[279]=C_h_intern(&lf[279],2,"-I");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[281]=C_h_intern(&lf[281],2,"-C");
lf[282]=C_h_intern(&lf[282],12,"string-split");
lf[283]=C_h_intern(&lf[283],6,"-strip");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[285]=C_h_intern(&lf[285],2,"-L");
lf[286]=C_h_intern(&lf[286],17,"-unsafe-libraries");
lf[287]=C_h_intern(&lf[287],6,"-rpath");
lf[288]=C_h_intern(&lf[288],3,"gnu");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[290]=C_h_intern(&lf[290],14,"build-platform");
lf[291]=C_h_intern(&lf[291],5,"-host");
lf[292]=C_h_intern(&lf[292],1,"-");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-E\376\003\000\000\002\376B\000\000\012-extension\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-featu"
"re\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-"
"keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026"
"-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-G\376\003\000\000\002\376B\000\000\016-check-imports\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\020-run-time-macros\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dyna"
"mic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\020-emit-debug-info\376\003\000\000\002\376\001\000\000\016-"
"check-imports\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000"
"\012-extension\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\022-static-extensions\376\003\000\000\002\376\001\000\000\015-analyze-only"
"\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\030-disable-compiler-macros\376\377\016");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\007-import\376\003\000\000\002\376\001\000\000\031-require-static-extension\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000"
"\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap"
"-initial-size\376\003\000\000\002\376\001\000\000\015-emit-exports\376\003\000\000\002\376\001\000\000\022-compress-literals\376\377\016");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[299]=C_h_intern(&lf[299],9,"substring");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[302]=C_h_intern(&lf[302],15,"lset-difference");
lf[303]=C_h_intern(&lf[303],6,"char=\077");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000G\376\377\016");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[307]=C_h_intern(&lf[307],18,"decompose-pathname");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[322]=C_h_intern(&lf[322],15,"-optimize-level");
lf[323]=C_h_intern(&lf[323],15,"-benchmark-mode");
lf[324]=C_h_intern(&lf[324],10,"-to-stdout");
lf[325]=C_h_intern(&lf[325],7,"-unsafe");
lf[326]=C_h_intern(&lf[326],7,"-shared");
lf[327]=C_h_intern(&lf[327],8,"-dynamic");
lf[328]=C_h_intern(&lf[328],14,"string->symbol");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[330]=C_h_intern(&lf[330],6,"getenv");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\011-LIBPATH:");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[364]=C_h_intern(&lf[364],22,"command-line-arguments");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[366]=C_h_intern(&lf[366],4,"hpux");
lf[367]=C_h_intern(&lf[367],4,"hppa");
lf[368]=C_h_intern(&lf[368],12,"machine-type");
lf[369]=C_h_intern(&lf[369],16,"software-version");
C_register_lf2(lf,370,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k378 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 106  build-platform */
t3=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 107  build-platform */
t5=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 108  software-version */
t5=C_retrieve(lf[369]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3303,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 109  software-version */
t6=C_retrieve(lf[369]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3301 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[366]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 110  machine-type */
t4=C_retrieve(lf[368]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_414(t3,C_SCHEME_FALSE);}}

/* k3297 in k3301 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_414(t2,(C_word)C_eqp(t1,lf[367]));}

/* k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_414,NULL,2,t0,t1);}
t2=C_mutate(&lf[8],t1);
t3=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_416,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 116  getenv */
t5=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[365]);}

/* k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_431,2,t0,t1);}
t2=C_mutate(&lf[14],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_435,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 117  command-line-arguments */
t4=C_retrieve(lf[364]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_435,2,t0,t1);}
t2=C_mutate(&lf[15],t1);
t3=(C_word)C_i_member(lf[16],C_retrieve2(lf[15],"arguments"));
t4=C_mutate(&lf[17],t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[18],t5);
t7=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_445,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_458,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3279,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3283,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3281 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 133  prefix */
f_445(((C_word*)t0)[2],lf[362],lf[363],t1);}

/* k3277 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 132  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_472,2,t0,t1);}
t2=C_mutate(&lf[27],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_476,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3261,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3263 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3269,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3267 in k3263 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 138  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3259 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 137  prefix */
f_445(((C_word*)t0)[2],lf[360],lf[361],t1);}

/* k3255 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 136  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_476,2,t0,t1);}
t2=C_mutate(&lf[28],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_480,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3245 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 142  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_480,2,t0,t1);}
t2=C_mutate(&lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3237,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3235 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 143  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_484,2,t0,t1);}
t2=C_mutate(&lf[30],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3224(2,t5,lf[359]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* k3222 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 144  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
t2=C_mutate(&lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3211,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3211(2,t5,lf[358]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* k3209 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 145  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_492,2,t0,t1);}
t2=C_mutate(&lf[32],t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[33]:lf[34]);
t4=C_mutate(&lf[35],t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[36]:lf[37]);
t6=C_mutate(&lf[38],t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[39]:lf[40]);
t8=C_mutate(&lf[41],t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[42]:lf[43]);
t10=C_mutate(&lf[44],t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[45]:lf[46]);
t12=C_mutate(&lf[47],t11);
t13=C_mutate(&lf[48],C_retrieve(lf[49]));
t14=(C_truep(lf[3])?lf[3]:C_retrieve2(lf[5],"msvc"));
t15=(C_truep(t14)?lf[50]:lf[51]);
t16=C_mutate(&lf[52],t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[356]:lf[357]);
/* csc.scm: 156  string-append */
t19=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t18,C_retrieve2(lf[38],"library-extension"));}

/* k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_523,2,t0,t1);}
t2=C_mutate(&lf[53],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_527,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[354]:lf[355]);
/* csc.scm: 159  string-append */
t5=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[38],"library-extension"));}

/* k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_527,2,t0,t1);}
t2=C_mutate(&lf[54],t1);
t3=(C_truep(lf[3])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3195,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3190,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[55],t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3178 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 168  string-split */
t2=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_535,2,t0,t1);}
t2=C_mutate(&lf[56],t1);
t3=C_mutate(&lf[57],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3168 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 170  string-split */
t2=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_540,2,t0,t1);}
t2=C_mutate(&lf[58],t1);
t3=C_mutate(&lf[59],C_retrieve2(lf[58],"default-linking-optimization-options"));
t4=lf[60]=C_SCHEME_END_OF_LIST;;
t5=lf[61]=C_SCHEME_END_OF_LIST;;
t6=lf[62]=C_SCHEME_END_OF_LIST;;
t7=lf[63]=C_SCHEME_END_OF_LIST;;
t8=lf[64]=C_SCHEME_END_OF_LIST;;
t9=lf[65]=C_SCHEME_FALSE;;
t10=lf[66]=C_SCHEME_FALSE;;
t11=lf[67]=C_SCHEME_FALSE;;
t12=lf[68]=C_SCHEME_FALSE;;
t13=lf[69]=C_SCHEME_FALSE;;
t14=lf[70]=C_SCHEME_FALSE;;
t15=lf[71]=C_SCHEME_FALSE;;
t16=lf[72]=C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_566,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t18=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t18=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_566,2,t0,t1);}
t2=C_mutate(&lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_570,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_570,2,t0,t1);}
t2=C_mutate(&lf[74],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3136,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3140,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3142 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3148,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 241  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[353],C_retrieve2(lf[53],"default-library"));}

/* k3146 in k3142 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 239  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3138 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 238  prefix */
f_445(((C_word*)t0)[2],C_retrieve2(lf[53],"default-library"),lf[352],t1);}

/* k3134 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 237  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[75],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_578,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3128,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 243  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[350],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_578(t5,lf[351]);}}

/* k3126 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3128,2,t0,t1);}
t2=((C_word*)t0)[2];
f_578(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_578,NULL,2,t0,t1);}
t2=C_mutate(&lf[76],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3107,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3111,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3109 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 251  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[349],C_retrieve2(lf[54],"default-unsafe-library"));}

/* k3113 in k3109 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 249  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3105 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 248  prefix */
f_445(((C_word*)t0)[2],C_retrieve2(lf[54],"default-unsafe-library"),lf[348],t1);}

/* k3101 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 247  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[77],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3095,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 253  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[346],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_586(t5,lf[347]);}}

/* k3093 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
t2=((C_word*)t0)[2];
f_586(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_586,NULL,2,t0,t1);}
t2=C_mutate(&lf[78],t1);
t3=C_mutate(&lf[79],C_retrieve2(lf[75],"default-library-files"));
t4=C_mutate(&lf[80],C_retrieve2(lf[76],"default-shared-library-files"));
t5=C_mutate(&lf[81],C_retrieve2(lf[75],"default-library-files"));
t6=C_mutate(&lf[82],C_retrieve2(lf[76],"default-shared-library-files"));
t7=C_mutate(&lf[83],lf[84]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_595,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t10=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t10=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3080 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 263  prefix */
f_445(((C_word*)t0)[2],lf[344],lf[345],t1);}

/* k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[63],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_595,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[85]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[86],t3);
t5=(C_truep(C_retrieve2(lf[86],"include-dir"))?(C_word)C_a_i_list(&a,2,lf[87],C_retrieve2(lf[86],"include-dir")):C_SCHEME_END_OF_LIST);
t6=C_mutate(&lf[88],t5);
t7=C_mutate(&lf[89],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t8=C_mutate(&lf[90],C_retrieve2(lf[58],"default-linking-optimization-options"));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[7],"osx"):(C_truep(C_retrieve2(lf[8],"hpux-hppa"))?C_retrieve2(lf[8],"hpux-hppa"):lf[3]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2972,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2980,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3004,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3008,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3051,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}}}

/* k3057 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  prefix */
f_445(((C_word*)t0)[2],lf[342],lf[343],t1);}

/* k3053 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k3049 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[341],t1);}

/* k3023 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3029,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3041,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k3039 in k3023 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 295  prefix */
f_445(((C_word*)t0)[2],lf[339],lf[340],t1);}

/* k3035 in k3023 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 295  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k3031 in k3023 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 295  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[338],t1);}

/* k3027 in k3023 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
t2=((C_word*)t0)[3];
f_610(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3010 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 285  prefix */
f_445(((C_word*)t0)[2],lf[336],lf[337],t1);}

/* k3006 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 284  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k3002 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 284  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[335],t1);}

/* k2998 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=((C_word*)t0)[2];
f_610(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2982 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 279  prefix */
f_445(((C_word*)t0)[2],lf[333],lf[334],t1);}

/* k2978 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 278  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k2974 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 278  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[332],t1);}

/* k2970 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=((C_word*)t0)[2];
f_610(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_610,NULL,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=lf[92]=C_SCHEME_FALSE;;
t4=lf[93]=C_SCHEME_FALSE;;
t5=lf[94]=C_SCHEME_FALSE;;
t6=lf[95]=C_SCHEME_FALSE;;
t7=lf[96]=C_SCHEME_FALSE;;
t8=lf[97]=C_SCHEME_FALSE;;
t9=lf[98]=C_SCHEME_FALSE;;
t10=lf[99]=C_SCHEME_FALSE;;
t11=lf[100]=C_SCHEME_FALSE;;
t12=lf[101]=C_SCHEME_FALSE;;
t13=lf[102]=C_SCHEME_END_OF_LIST;;
t14=lf[103]=C_SCHEME_FALSE;;
t15=C_mutate(&lf[104],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2414,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[109],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2566,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[115],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2663,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[118],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2715,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[120],lf[121]);
t20=C_mutate(&lf[107],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2864,tmp=(C_word)a,a+=2,tmp));
t21=lf[130]=C_SCHEME_FALSE;;
t22=C_mutate(&lf[131],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2893,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[136],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2925,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2951,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 952  getenv */
t28=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,lf[331]);}

/* k2957 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[329]);
/* csc.scm: 952  string-split */
t3=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2953 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 952  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[15],"arguments"));}

/* k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_633,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_640,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_679,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_708,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_708(t8,((C_word*)t0)[2],t1);}

/* loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_708(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_708,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_718,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_840,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_873,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 501  compiler-options */
f_2414(t5);}
else{
t5=t4;
f_840(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_718(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_882,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* csc.scm: 539  string->symbol */
t8=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word ab[117],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_885,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[184]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[185]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_897,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 317  display */
t6=*((C_word*)lf[186]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[187]);}
else{
t5=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_916,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 545  chicken-version */
t8=C_retrieve(lf[189]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t6=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_925,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 548  sprintf */
t9=C_retrieve(lf[155]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[28],"translator"),lf[191]);}
else{
t7=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t7)){
t8=lf[65]=C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[193],C_retrieve2(lf[88],"compile-options"));
t10=C_mutate(&lf[88],t9);
t11=t2;
f_885(2,t11,t10);}
else{
t9=t2;
f_885(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t8)){
t9=lf[66]=C_SCHEME_TRUE;;
t10=t2;
f_885(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 556  cons* */
t11=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,lf[196],lf[197],C_retrieve2(lf[83],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 559  cons* */
t12=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[199],lf[200],C_retrieve2(lf[83],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t11)){
t12=lf[101]=C_SCHEME_TRUE;;
t13=t2;
f_885(2,t13,t12);}
else{
t12=(C_word)C_eqp(t1,lf[202]);
if(C_truep(t12)){
t13=lf[68]=C_SCHEME_TRUE;;
t14=lf[69]=C_SCHEME_TRUE;;
t15=t2;
f_885(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t13)){
t14=lf[68]=C_SCHEME_TRUE;;
t15=lf[70]=C_SCHEME_TRUE;;
t16=t2;
f_885(2,t16,t15);}
else{
t14=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 569  print */
t16=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_retrieve2(lf[29],"compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1019,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 570  print */
t17=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,C_retrieve2(lf[30],"c++-compiler"));}
else{
t16=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 571  print */
t18=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,C_retrieve2(lf[31],"linker"));}
else{
t17=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 572  print */
t19=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,C_retrieve2(lf[27],"home"));}
else{
t18=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t18)){
t19=lf[68]=C_SCHEME_TRUE;;
t20=lf[71]=C_SCHEME_TRUE;;
t21=t2;
f_885(2,t21,t20);}
else{
t19=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t19)){
t20=lf[93]=C_SCHEME_TRUE;;
t21=t2;
f_885(2,t21,t20);}
else{
t20=(C_word)C_eqp(t1,lf[210]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t1,lf[211]));
if(C_truep(t21)){
t22=lf[93]=C_SCHEME_TRUE;;
/* csc.scm: 580  t-options */
f_633(t2,(C_word)C_a_i_list(&a,1,lf[212]));}
else{
t22=(C_word)C_eqp(t1,lf[213]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[214]));
if(C_truep(t23)){
t24=(C_word)C_a_i_cons(&a,2,lf[215],C_retrieve2(lf[88],"compile-options"));
t25=C_mutate(&lf[88],t24);
/* csc.scm: 583  t-options */
f_633(t2,(C_word)C_a_i_list(&a,1,lf[216]));}
else{
t24=(C_word)C_eqp(t1,lf[217]);
if(C_truep(t24)){
t25=lf[93]=C_SCHEME_TRUE;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 586  t-options */
f_633(t26,(C_word)C_a_i_list(&a,1,lf[222]));}
else{
t25=(C_word)C_eqp(t1,lf[223]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[224]));
if(C_truep(t26)){
t27=lf[95]=C_SCHEME_TRUE;;
/* csc.scm: 592  t-options */
f_633(t2,(C_word)C_a_i_list(&a,1,lf[225]));}
else{
t27=(C_word)C_eqp(t1,lf[226]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(t1,lf[227]));
if(C_truep(t28)){
t29=lf[95]=C_SCHEME_TRUE;;
/* csc.scm: 595  t-options */
f_633(t2,(C_word)C_a_i_list(&a,1,lf[228]));}
else{
t29=(C_word)C_eqp(t1,lf[229]);
if(C_truep(t29)){
t30=lf[94]=C_SCHEME_TRUE;;
t31=t2;
f_885(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[230]);
if(C_truep(t30)){
t31=lf[96]=C_SCHEME_TRUE;;
t32=t2;
f_885(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[231]);
if(C_truep(t31)){
t32=lf[95]=C_SCHEME_TRUE;;
t33=t2;
f_885(2,t33,t32);}
else{
t32=(C_word)C_eqp(t1,lf[232]);
t33=(C_truep(t32)?t32:(C_word)C_eqp(t1,lf[233]));
if(C_truep(t33)){
t34=lf[67]=C_SCHEME_TRUE;;
t35=(C_word)C_a_i_cons(&a,2,lf[234],C_retrieve2(lf[88],"compile-options"));
t36=C_mutate(&lf[88],t35);
t37=t2;
f_885(2,t37,t36);}
else{
t34=(C_word)C_eqp(t1,lf[235]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[236]));
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 603  check */
f_640(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[238]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[239]));
if(C_truep(t37)){
t38=lf[103]=C_SCHEME_TRUE;;
if(C_truep(lf[3])){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1231,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 612  cons* */
t40=C_retrieve(lf[127]);
((C_proc7)C_retrieve_proc(t40))(7,t40,t39,lf[241],lf[242],lf[243],lf[244],C_retrieve2(lf[91],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1242,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 617  cons* */
t40=C_retrieve(lf[127]);
((C_proc6)C_retrieve_proc(t40))(6,t40,t39,lf[246],lf[247],lf[248],C_retrieve2(lf[91],"link-options"));}
else{
t39=t2;
f_885(2,t39,C_SCHEME_UNDEFINED);}}}
else{
t38=(C_word)C_eqp(t1,lf[249]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1255,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 620  check */
f_640(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[251]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1279,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 625  check */
f_640(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[252]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[253]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1300,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 629  cons* */
t43=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t43))(5,t43,t42,lf[254],lf[255],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[256]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1310,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 630  cons* */
t44=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t44))(5,t44,t43,lf[257],lf[258],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[259]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 631  cons* */
t45=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t45))(5,t45,t44,lf[260],lf[261],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[262]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1330,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 632  cons* */
t46=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t45,lf[263],lf[264],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[265]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1340,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 633  cons* */
t47=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t46,lf[266],lf[267],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[268]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1350,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 634  cons* */
t48=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t48))(5,t48,t47,lf[269],lf[270],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[271]);
if(C_truep(t47)){
t48=lf[93]=C_SCHEME_TRUE;;
t49=lf[72]=C_SCHEME_TRUE;;
t50=t2;
f_885(2,t50,t49);}
else{
t48=(C_word)C_eqp(t1,lf[272]);
t49=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t48)){
t50=t49;
f_1367(t50,t48);}
else{
t50=(C_word)C_eqp(t1,lf[326]);
t51=t49;
f_1367(t51,(C_truep(t50)?t50:(C_word)C_eqp(t1,lf[327])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1367,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 639  shared-build */
f_679(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[273]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[274]));
if(C_truep(t3)){
/* csc.scm: 641  shared-build */
f_679(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[275]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1391,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 643  check */
f_640(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[276]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1408,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 647  check */
f_640(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[277]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1425,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 651  check */
f_640(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[278]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1442,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 655  check */
f_640(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[279]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 659  check */
f_640(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[281]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 662  check */
f_640(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[283]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[284]);
/* csc.scm: 666  append */
t13=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[91],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[285]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 668  check */
f_640(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[286]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 672  t-options */
f_633(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[287]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 676  check */
f_640(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[291]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_885(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[292]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 682  make-pathname */
t17=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,C_SCHEME_FALSE,lf[294],C_retrieve2(lf[44],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[325]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[323]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[323]);
if(C_truep(t18)){
t19=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t20=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t21=t16;
f_1608(t21,t20);}
else{
t19=t16;
f_1608(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_1608(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1608,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[324]);
if(C_truep(t3)){
t4=lf[97]=C_SCHEME_TRUE;;
t5=lf[95]=C_SCHEME_TRUE;;
t6=t2;
f_1611(t6,t5);}
else{
t4=t2;
f_1611(t4,C_SCHEME_UNDEFINED);}}

/* k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1611,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[322]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[323]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[89],C_retrieve2(lf[57],"best-compilation-optimization-options"));
t5=C_mutate(&lf[90],C_retrieve2(lf[59],"best-linking-optimization-options"));
t6=t2;
f_1614(t6,t5);}
else{
t4=t2;
f_1614(t4,C_SCHEME_UNDEFINED);}}

/* k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1614,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[295]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_885(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[296]))){
/* csc.scm: 696  t-options */
f_633(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[297]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 698  check */
f_640(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1665,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 703  substring */
t6=*((C_word*)lf[299]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_1665(t5,C_SCHEME_FALSE);}}}}}

/* k1994 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1665(t2,(C_word)C_i_string_equal_p(lf[321],t1));}

/* k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1665,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 704  t-options */
f_633(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_1674(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_1674(t4,C_SCHEME_FALSE);}}}

/* k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1674,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 708  append */
t6=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve2(lf[91],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 710  append */
t8=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[91],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 712  append */
t10=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,C_retrieve2(lf[88],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 714  substring */
t11=*((C_word*)lf[299]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 717  append */
t14=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t12,C_retrieve2(lf[88],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_885(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 718  substring */
t15=*((C_word*)lf[299]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_1752(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 727  file-exists? */
t3=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 728  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 744  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[320]);}}

/* k1957 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 745  file-exists? */
t3=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1963 in k1957 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_885(2,t4,t3);}
else{
/* csc.scm: 747  quit */
f_416(((C_word*)t0)[3],lf[319],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[37],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1862,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[309]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 731  append */
t9=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve2(lf[61],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[310]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[311]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[312]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[314]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[315],C_retrieve2(lf[88],"compile-options"));
t10=C_mutate(&lf[88],t9);
t11=t8;
f_1900(t11,t10);}
else{
t9=t8;
f_1900(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[316]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[317]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[318]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[66]=C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1924,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 738  append */
t12=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,C_retrieve2(lf[61],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[35],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[38],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 741  append */
t13=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[63],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 742  append */
t13=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[60],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 729  append */
t8=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[60],"scheme-files"),t7);}}

/* k1871 in a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1947 in a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1939 in a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1922 in a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1898 in a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1900,NULL,2,t0,t1);}
t2=lf[65]=C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 735  append */
t5=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_retrieve2(lf[61],"c-files"),t4);}

/* k1903 in k1898 in a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1885 in a1861 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1855 in k1849 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
/* csc.scm: 728  decompose-pathname */
t2=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1819 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1752(t2,(C_word)C_i_string_equal_p(lf[306],t1));}

/* k1750 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1752,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 719  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[91],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->list */
t4=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 726  quit */
f_416(((C_word*)t0)[5],lf[305],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k1802 in k1750 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 722  lset-difference */
t4=C_retrieve(lf[302]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[303]+1),t2,lf[304]);}

/* k1798 in k1802 in k1750 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1785,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
/* csc.scm: 725  quit */
f_416(((C_word*)t0)[4],lf[301],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1784 in k1798 in k1802 in k1750 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1785,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* csc.scm: 724  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[300],t3);}

/* k1781 in k1798 in k1802 in k1750 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 724  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1777 in k1798 in k1802 in k1750 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1754 in k1750 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1740 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1727 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
/* csc.scm: 714  t-options */
f_633(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[298],t1));}

/* k1710 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1696 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1682 in k1672 in k1663 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1644 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1652,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 700  string->number */
C_string_to_number(3,0,t3,t2);}

/* k1650 in k1644 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 701  t-options */
f_633(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1653 in k1650 in k1644 in k1612 in k1609 in k1606 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_885(2,t4,t3);}

/* k1599 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 683  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[60],"scheme-files"),lf[293]);}

/* k1603 in k1599 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1553 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 677  build-platform */
t3=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1583 in k1553 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(C_word)C_eqp(lf[288],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1577,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 678  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[289],t5);}
else{
t3=((C_word*)t0)[2];
f_885(2,t3,C_SCHEME_UNDEFINED);}}

/* k1575 in k1583 in k1553 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1577,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 678  append */
t3=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[91],"link-options"),t2);}

/* k1563 in k1583 in k1553 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_885(2,t5,t4);}

/* k1542 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t3=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_885(2,t4,t3);}

/* k1517 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 669  string-split */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1529 in k1517 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 669  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[91],"link-options"),t1);}

/* k1521 in k1517 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_885(2,t5,t4);}

/* k1504 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1478 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 663  string-split */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1490 in k1478 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 663  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[88],"compile-options"),t1);}

/* k1482 in k1478 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_885(2,t5,t4);}

/* k1457 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 660  cons* */
t5=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[280],t3,t4);}

/* k1461 in k1457 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1440 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[31],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_885(2,t6,t5);}

/* k1423 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[30],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_885(2,t6,t5);}

/* k1406 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[29],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_885(2,t6,t5);}

/* k1389 in k1365 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_885(2,t6,t5);}

/* k1348 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1338 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1328 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1318 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1308 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1298 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_885(2,t3,t2);}

/* k1277 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[92],t2);
t6=((C_word*)t0)[2];
f_885(2,t6,t5);}

/* k1253 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 622  cons* */
t5=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,lf[250],t4,C_retrieve2(lf[91],"link-options"));}
else{
t3=t2;
f_1258(t3,C_SCHEME_UNDEFINED);}}

/* k1264 in k1253 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_1258(t3,t2);}

/* k1256 in k1253 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_885(2,t4,t3);}

/* k1240 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[245],C_retrieve2(lf[88],"compile-options"));
t4=C_mutate(&lf[88],t3);
t5=((C_word*)t0)[2];
f_885(2,t5,t4);}

/* k1229 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1231,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[240],C_retrieve2(lf[88],"compile-options"));
t4=C_mutate(&lf[88],t3);
t5=((C_word*)t0)[2];
f_885(2,t5,t4);}

/* k1189 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 604  append */
t5=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_retrieve2(lf[102],"required-extensions"),t4);}

/* k1193 in k1189 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=C_mutate(&lf[102],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 605  t-options */
f_633(t3,(C_word)C_a_i_list(&a,2,lf[237],t4));}

/* k1196 in k1193 in k1189 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_885(2,t4,t3);}

/* k1098 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t3=t2;
f_1103(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1118,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 588  cons* */
t4=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[220],lf[221],C_retrieve2(lf[88],"compile-options"));}}

/* k1116 in k1098 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
f_1103(t3,t2);}

/* k1101 in k1098 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_1103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1103,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[218]:lf[219]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[91],"link-options"));
t4=C_mutate(&lf[91],t3);
t5=((C_word*)t0)[2];
f_885(2,t5,t4);}

/* k1041 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 572  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1029 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 571  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1017 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 570  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1005 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 569  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k972 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[100]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_885(2,t4,t3);}

/* k961 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[99]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_885(2,t4,t3);}

/* k930 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 548  system */
t2=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k923 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 549  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k914 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 545  print */
t2=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k907 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 546  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k895 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 543  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k883 in k880 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 748  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_708(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k871 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 501  print* */
t2=*((C_word*)lf[183]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k838 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[70],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_866,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 502  linker-options */
f_2663(t3);}
else{
t3=t2;
f_843(2,t3,C_SCHEME_UNDEFINED);}}

/* k864 in k838 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 502  print* */
t2=*((C_word*)lf[183]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k841 in k838 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_859,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 503  linker-libraries */
f_2715(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_846(2,t3,C_SCHEME_UNDEFINED);}}

/* k857 in k841 in k838 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 503  print* */
t2=*((C_word*)lf[183]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k844 in k841 in k838 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 504  newline */
t3=*((C_word*)lf[182]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k847 in k844 in k841 in k838 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 505  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[63],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* csc.scm: 511  quit */
f_416(t3,lf[161],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_765(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_803,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[98],"shared"))?(C_word)C_i_not(C_retrieve2(lf[67],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[181],C_retrieve2(lf[83],"translate-options"));
t6=C_mutate(&lf[83],t5);
t7=t3;
f_803(t7,t6);}
else{
t5=t3;
f_803(t5,C_SCHEME_UNDEFINED);}}}

/* k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_803(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_803,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[92],"target-filename"))){
t3=t2;
f_806(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[98],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 524  pathname-replace-extension */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[48],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 525  pathname-replace-extension */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[44],"executable-extension"));}}}

/* k811 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_806(t3,t2);}

/* k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_806,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2074,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[60],"scheme-files"));}

/* a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2074,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2078,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 756  pathname-replace-extension */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[180]);}

/* k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2319,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 757  file-exists? */
t5=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2323 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2325,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 758  with-input-from-file */
t3=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_retrieve(lf[168]));}
else{
t2=((C_word*)t0)[3];
f_2319(t2,C_SCHEME_FALSE);}}

/* k2326 in k2323 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
f_2319(t3,(C_truep(t2)?t2:(C_word)C_i_string_equal_p(lf[179],t1)));}

/* k2317 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 760  $delete-file */
t2=C_retrieve2(lf[136],"$delete-file");
f_2925(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2081(2,t2,C_SCHEME_UNDEFINED);}}

/* k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_length(C_retrieve2(lf[60],"scheme-files"));
t4=(C_word)C_i_nequalp(C_fix(1),t3);
t5=(C_truep(t4)?C_retrieve2(lf[92],"target-filename"):((C_word*)t0)[2]);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?lf[176]:(C_truep(C_retrieve2(lf[66],"objc-mode"))?lf[177]:lf[178]));
/* csc.scm: 761  pathname-replace-extension */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,t5,t6);}

/* k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2087,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2248,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 771  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2260,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2264,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[97],"to-stdout"))){
t4=t3;
f_2264(t4,lf[174]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 775  cleanup-filename */
t5=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2296 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2264(t2,(C_word)C_a_i_list(&a,2,lf[175],t1));}

/* k2262 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2264,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2268,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[99],"static");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_2279(t5,t3);}
else{
t5=C_retrieve2(lf[100],"static-libs");
t6=t4;
f_2279(t6,(C_truep(t5)?t5:C_retrieve2(lf[101],"static-extensions")));}}

/* k2277 in k2262 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2279,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2284,tmp=(C_word)a,a+=2,tmp);
/* map */
t3=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[102],"required-extensions"));}
else{
t2=((C_word*)t0)[2];
f_2268(2,t2,C_SCHEME_END_OF_LIST);}}

/* a2283 in k2277 in k2262 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2284,3,t0,t1,t2);}
/* csc.scm: 777  conc */
t3=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[173],t2);}

/* k2266 in k2262 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2272,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 779  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2274 in k2266 in k2262 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[107],"quote-option"),t1);}

/* k2270 in k2266 in k2262 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 772  append */
t2=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2258 in k2254 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 771  cons* */
t2=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve2(lf[28],"translator"),((C_word*)t0)[2],t1);}

/* k2250 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 770  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[171]);}

/* k2246 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 769  $system */
t2=C_retrieve2(lf[131],"$system");
f_2893(3,t2,((C_word*)t0)[2],t1);}

/* k2242 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2087(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 781  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 782  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_retrieve2(lf[61],"c-files"));}

/* k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=C_mutate(&lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 783  append */
t5=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[62],"generated-c-files"));}

/* k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2095,2,t0,t1);}
t2=C_mutate(&lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 784  file-exists? */
t4=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2109,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 785  with-input-from-file */
t4=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2113,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 787  read-line */
t3=C_retrieve(lf[168]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2111 in a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2118,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2226,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 797  read-file */
t4=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2224 in k2111 in a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2117 in k2111 in a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2118,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2120,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(t2);
/* for-each */
t8=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,C_retrieve2(lf[131],"$system"),t7);}
else{
/* g190192 */
f_2120(t1,t2);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[165]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t8))){
t9=(C_word)C_i_cdr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* append */
t11=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,C_retrieve2(lf[88],"compile-options"),t9);}
else{
/* g190192 */
f_2120(t1,t2);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2187,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[166]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t2);
t12=t8;
f_2187(t12,(C_word)C_i_listp(t11));}
else{
t11=t8;
f_2187(t11,C_SCHEME_FALSE);}}}}
else{
/* g190192 */
f_2120(t1,t2);}}

/* k2185 in a2117 in k2111 in a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2187,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[91],"link-options"),t2);}
else{
/* g190192 */
f_2120(((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2192 in k2185 in a2117 in k2111 in a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2172 in a2117 in k2111 in a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g190 in a2117 in k2111 in a2108 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2120(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2120,NULL,2,t1,t2);}
/* csc.scm: 796  error */
t3=*((C_word*)lf[162]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[163],t2);}

/* k2102 in k2099 in k2093 in k2089 in k2085 in k2082 in k2079 in k2076 in a2073 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 798  $delete-file */
t2=C_retrieve2(lf[136],"$delete-file");
f_2925(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2064 in k804 in k801 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[94],"keep-files"))){
t2=((C_word*)t0)[2];
f_721(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[136],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k763 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[63],"object-files"):C_retrieve2(lf[61],"c-files"));
/* csc.scm: 512  last */
t5=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k766 in k763 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
if(C_truep(C_retrieve2(lf[92],"target-filename"))){
t2=((C_word*)t0)[2];
f_721(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[98],"shared"))){
/* csc.scm: 516  pathname-replace-extension */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[48],"shared-library-extension"));}
else{
/* csc.scm: 517  pathname-replace-extension */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[44],"executable-extension"));}}}

/* k773 in k766 in k763 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_721(2,t3,t2);}

/* k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
if(C_truep(C_retrieve2(lf[95],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2343,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[61],"c-files"));}}

/* a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2359,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2363,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 809  pathname-replace-extension */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_retrieve2(lf[35],"object-extension"));}

/* k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2384,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2400,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 815  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2398 in k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2412,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 816  cleanup-filename */
t4=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2410 in k2398 in k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 816  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[47],"compile-output-flag"),t1);}

/* k2402 in k2398 in k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 818  compiler-options */
f_2414(t2);}

/* k2406 in k2402 in k2398 in k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[158],t1);
/* csc.scm: 812  string-intersperse */
t3=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2386 in k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 811  $system */
t2=C_retrieve2(lf[131],"$system");
f_2893(3,t2,((C_word*)t0)[2],t1);}

/* k2382 in k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2366(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 819  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2364 in k2361 in a2358 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[64],"generated-object-files"));
t3=C_mutate(&lf[64],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2341 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 823  reverse */
t4=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2355 in k2341 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 823  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[63],"object-files"));}

/* k2345 in k2341 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
if(C_truep(C_retrieve2(lf[94],"keep-files"))){
t3=((C_word*)t0)[2];
f_727(2,t3,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t3=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[136],"$delete-file"),C_retrieve2(lf[62],"generated-c-files"));}}

/* k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
if(C_truep(C_retrieve2(lf[96],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[92],"target-filename"),C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 531  printf */
t4=C_retrieve(lf[132]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[157],C_retrieve2(lf[92],"target-filename"),C_retrieve2(lf[92],"target-filename"));}
else{
t3=t2;
f_733(2,t3,C_SCHEME_UNDEFINED);}}}

/* k740 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_759,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 533  sprintf */
t4=C_retrieve(lf[155]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[156],C_retrieve2(lf[92],"target-filename"),C_retrieve2(lf[92],"target-filename"));}

/* k757 in k740 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 533  $system */
t2=C_retrieve2(lf[131],"$system");
f_2893(3,t2,((C_word*)t0)[2],t1);}

/* k753 in k740 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_733(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 534  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2548,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2552,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2554,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2560,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 840  ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}

/* a2559 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2560r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2560r(t0,t1,t2);}}

static void C_ccall f_2560r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2553 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
/* csc.scm: 840  static-extension-info */
f_2566(t1);}

/* k2550 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 839  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[63],"object-files"),t1);}

/* k2546 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[55],"cleanup-filename"),t1);}

/* k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2442,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 841  cleanup-filename */
t3=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve2(lf[92],"target-filename"));}

/* k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2445,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2512,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2520,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[32],"c++-linker"):C_retrieve2(lf[31],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 849  string-append */
t9=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[41],"link-output-flag"),t1);}

/* k2534 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 850  linker-options */
f_2663(t2);}

/* k2538 in k2534 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 851  linker-libraries */
f_2715(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k2542 in k2538 in k2534 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 847  append */
t3=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2526 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 845  cons* */
t2=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2518 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 844  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2514 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 843  $system */
t2=C_retrieve2(lf[131],"$system");
f_2893(3,t2,((C_word*)t0)[2],t1);}

/* k2510 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2445(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 852  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[18],"cross-chicken"));
t5=t3;
f_2457(t5,(C_truep(t4)?t4:C_retrieve2(lf[17],"host-mode")));}
else{
t4=t3;
f_2457(t4,C_SCHEME_FALSE);}}

/* k2455 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2457,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2474,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2490,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_2448(2,t2,C_SCHEME_UNDEFINED);}}

/* k2488 in k2455 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 859  prefix */
f_445(((C_word*)t0)[2],lf[152],lf[153],t1);}

/* k2484 in k2455 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 858  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[151]);}

/* k2480 in k2455 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 857  quotewrap */
f_458(((C_word*)t0)[2],t1);}

/* k2476 in k2455 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 855  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[149],t1,lf[150],((C_word*)t0)[2]);}

/* k2472 in k2455 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 854  $system */
t2=C_retrieve2(lf[131],"$system");
f_2893(3,t2,((C_word*)t0)[2],t1);}

/* k2468 in k2455 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2448(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 866  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2446 in k2443 in k2440 in k2437 in k731 in k725 in k719 in k716 in loop in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[94],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[136],"$delete-file"),C_retrieve2(lf[64],"generated-object-files"));}}

/* shared-build in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_679(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_679,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_684,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 489  cons* */
t4=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[146],lf[147],C_retrieve2(lf[83],"translate-options"));}

/* k682 in shared-build in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_684,2,t0,t1);}
t2=C_mutate(&lf[83],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 490  append */
t4=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[52],"pic-options"),lf[145],C_retrieve2(lf[88],"compile-options"));}

/* k686 in k682 in shared-build in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_688,2,t0,t1);}
t2=C_mutate(&lf[88],t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?lf[141]:lf[142]):(C_truep(C_retrieve2(lf[5],"msvc"))?lf[143]:lf[144]));
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[91],"link-options"));
t5=C_mutate(&lf[91],t4);
t6=lf[98]=C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_640(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_640,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_658,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_658(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_658(2,t8,(C_word)C_i_car(t4));}
else{
/* csc.scm: 485  ##sys#error */
t8=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k656 in check in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_658,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 486  quit */
f_416(((C_word*)t0)[3],lf[140],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_633(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_633,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_638,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 482  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),t2);}

/* k636 in t-options in k2949 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2939 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[139]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2945 in k2939 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2942 in k2939 in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2925,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2929,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[93],"verbose"))){
/* csc.scm: 946  print */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[138],t2);}
else{
t4=t3;
f_2929(2,t4,C_SCHEME_UNDEFINED);}}

/* k2927 in $delete-file in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 947  delete-file */
t2=C_retrieve(lf[137]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2893,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2897,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[93],"verbose"))){
/* csc.scm: 933  print */
t4=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2897(2,t4,C_SCHEME_UNDEFINED);}}

/* k2895 in $system in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t3=t2;
f_2901(t3,C_fix(0));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2920,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 937  system */
t4=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k2918 in k2895 in $system in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_2901(t3,(C_truep(t2)?C_fix(0):C_fix(1)));}

/* k2899 in k2895 in $system in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2901,NULL,2,t0,t1);}
t2=C_mutate(&lf[130],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[130],"last-exit-code")))){
t4=t3;
f_2904(2,t4,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 941  printf */
t4=C_retrieve(lf[132]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[133],C_retrieve2(lf[130],"last-exit-code"),((C_word*)t0)[2]);}}

/* k2902 in k2899 in k2895 in $system in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[130],"last-exit-code"));}

/* quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2864,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2871,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2876,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2890,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2888 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 924  any */
t2=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2875 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2876,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[120])));}

/* k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2797,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2811,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2815,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2813 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2817(t5,((C_word*)t0)[2],t1);}

/* fold in k2813 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2817(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2817,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[120]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2840,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 915  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_2847(t6,t5);}
else{
t5=t4;
f_2847(t5,C_SCHEME_UNDEFINED);}}}}

/* k2845 in fold in k2813 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2847,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 918  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2817(t4,t2,t3);}

/* k2852 in k2845 in fold in k2813 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2838 in fold in k2813 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 915  cons* */
t2=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k2809 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2795 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 920  string-translate* */
t3=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[125]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k2805 in k2795 in k2869 in quote-option in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 920  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* linker-libraries in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2715(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2715,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2719,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2719(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2719(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2717 in linker-libraries in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2730,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2761,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2767,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 895  ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_2730(2,t4,C_SCHEME_END_OF_LIST);}}

/* a2766 in k2717 in linker-libraries in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2767r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2767r(t0,t1,t2);}}

static void C_ccall f_2767r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2760 in k2717 in linker-libraries in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
/* csc.scm: 895  static-extension-info */
f_2566(t1);}

/* k2728 in k2717 in linker-libraries in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=C_retrieve2(lf[99],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[100],"static-libs"));
t4=(C_truep(t3)?(C_truep(C_retrieve2(lf[103],"gui"))?C_retrieve2(lf[79],"gui-library-files"):C_retrieve2(lf[81],"library-files")):(C_truep(C_retrieve2(lf[103],"gui"))?C_retrieve2(lf[80],"gui-shared-library-files"):C_retrieve2(lf[82],"shared-library-files")));
t5=C_retrieve2(lf[99],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[100],"static-libs"));
t7=(C_truep(t6)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[73],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[74],"extra-shared-libraries")));
/* csc.scm: 894  append */
t8=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* k2724 in k2717 in linker-libraries in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 893  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* linker-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2663(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2663,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2671,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2697,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2703,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2709,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 889  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a2708 in linker-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2709r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2709r(t0,t1,t2);}}

static void C_ccall f_2709r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a2702 in linker-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2703,2,t0,t1);}
/* csc.scm: 889  static-extension-info */
f_2566(t1);}

/* k2699 in linker-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 888  append */
t2=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[90],"linking-optimization-options"),C_retrieve2(lf[91],"link-options"),t1);}

/* k2695 in linker-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 887  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2669 in linker-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[99],"static"))?(C_truep(lf[3])?C_SCHEME_FALSE:(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx")))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[116]:lf[117]);
/* csc.scm: 886  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2566(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2566,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2570,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 870  repository-path */
t3=C_retrieve(lf[114]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=C_retrieve2(lf[99],"static");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2576(t4,t2);}
else{
t4=C_retrieve2(lf[100],"static-libs");
t5=t3;
f_2576(t5,(C_truep(t4)?t4:C_retrieve2(lf[101],"static-extensions")));}}

/* k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2576,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2581(t5,((C_word*)t0)[2],C_retrieve2(lf[102],"required-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 883  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2581,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2595,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 874  reverse */
t6=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 875  extension-information */
t7=C_retrieve(lf[113]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k2600 in loop in k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[111],t1);
t3=(C_word)C_i_assq(lf[112],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 880  make-pathname */
t8=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_2622(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 882  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2581(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2638 in k2600 in loop in k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2622(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2620 in k2600 in loop in k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2622,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2626,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_2626(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_2626(t3,((C_word*)t0)[2]);}}

/* k2624 in k2620 in k2600 in loop in k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 879  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2581(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2593 in loop in k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2599,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 874  reverse */
t3=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2597 in k2593 in loop in k2574 in k2568 in static-extension-info in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 874  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_2414(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2414,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[99],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[100],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
/* csc.scm: 829  append */
t7=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t6,C_retrieve2(lf[89],"compilation-optimization-options"),C_retrieve2(lf[88],"compile-options"));}

/* k2424 in compiler-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[107],"quote-option"),t1);}

/* k2420 in compiler-options in k608 in k593 in k584 in k3097 in k576 in k3130 in k568 in k564 in k538 in k533 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 827  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_3190 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3190,3,t0,t1,t2);}
/* csc.scm: 165  quotewrap */
f_458(t1,t2);}

/* f_3195 in k525 in k521 in k490 in k486 in k482 in k478 in k474 in k470 in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3195,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* quotewrap in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_458(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_458,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_465,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 127  string-any */
t4=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[26]+1),t2);}

/* k463 in quotewrap in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 128  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[23],((C_word*)t0)[2],lf[24]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* prefix in k433 in k429 in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_445(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_445,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[14],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[14],"chicken-prefix"),t3);
/* csc.scm: 123  make-pathname */
t6=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_416(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_416,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_420,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_427,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 113  current-error-port */
t6=C_retrieve(lf[13]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k425 in quit in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 113  fprintf */
t2=C_retrieve(lf[11]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,lf[12],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k418 in quit in k412 in k3305 in k3309 in k3313 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 114  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[313] = {
{"toplevelcsc.scm",(void*)C_toplevel},
{"f_380csc.scm",(void*)f_380},
{"f_383csc.scm",(void*)f_383},
{"f_386csc.scm",(void*)f_386},
{"f_389csc.scm",(void*)f_389},
{"f_392csc.scm",(void*)f_392},
{"f_395csc.scm",(void*)f_395},
{"f_398csc.scm",(void*)f_398},
{"f_3315csc.scm",(void*)f_3315},
{"f_3311csc.scm",(void*)f_3311},
{"f_3307csc.scm",(void*)f_3307},
{"f_3303csc.scm",(void*)f_3303},
{"f_3299csc.scm",(void*)f_3299},
{"f_414csc.scm",(void*)f_414},
{"f_431csc.scm",(void*)f_431},
{"f_435csc.scm",(void*)f_435},
{"f_3283csc.scm",(void*)f_3283},
{"f_3279csc.scm",(void*)f_3279},
{"f_472csc.scm",(void*)f_472},
{"f_3265csc.scm",(void*)f_3265},
{"f_3269csc.scm",(void*)f_3269},
{"f_3261csc.scm",(void*)f_3261},
{"f_3257csc.scm",(void*)f_3257},
{"f_476csc.scm",(void*)f_476},
{"f_3247csc.scm",(void*)f_3247},
{"f_480csc.scm",(void*)f_480},
{"f_3237csc.scm",(void*)f_3237},
{"f_484csc.scm",(void*)f_484},
{"f_3224csc.scm",(void*)f_3224},
{"f_488csc.scm",(void*)f_488},
{"f_3211csc.scm",(void*)f_3211},
{"f_492csc.scm",(void*)f_492},
{"f_523csc.scm",(void*)f_523},
{"f_527csc.scm",(void*)f_527},
{"f_3180csc.scm",(void*)f_3180},
{"f_535csc.scm",(void*)f_535},
{"f_3170csc.scm",(void*)f_3170},
{"f_540csc.scm",(void*)f_540},
{"f_566csc.scm",(void*)f_566},
{"f_570csc.scm",(void*)f_570},
{"f_3144csc.scm",(void*)f_3144},
{"f_3148csc.scm",(void*)f_3148},
{"f_3140csc.scm",(void*)f_3140},
{"f_3136csc.scm",(void*)f_3136},
{"f_3132csc.scm",(void*)f_3132},
{"f_3128csc.scm",(void*)f_3128},
{"f_578csc.scm",(void*)f_578},
{"f_3111csc.scm",(void*)f_3111},
{"f_3115csc.scm",(void*)f_3115},
{"f_3107csc.scm",(void*)f_3107},
{"f_3103csc.scm",(void*)f_3103},
{"f_3099csc.scm",(void*)f_3099},
{"f_3095csc.scm",(void*)f_3095},
{"f_586csc.scm",(void*)f_586},
{"f_3082csc.scm",(void*)f_3082},
{"f_595csc.scm",(void*)f_595},
{"f_3059csc.scm",(void*)f_3059},
{"f_3055csc.scm",(void*)f_3055},
{"f_3051csc.scm",(void*)f_3051},
{"f_3025csc.scm",(void*)f_3025},
{"f_3041csc.scm",(void*)f_3041},
{"f_3037csc.scm",(void*)f_3037},
{"f_3033csc.scm",(void*)f_3033},
{"f_3029csc.scm",(void*)f_3029},
{"f_3012csc.scm",(void*)f_3012},
{"f_3008csc.scm",(void*)f_3008},
{"f_3004csc.scm",(void*)f_3004},
{"f_3000csc.scm",(void*)f_3000},
{"f_2984csc.scm",(void*)f_2984},
{"f_2980csc.scm",(void*)f_2980},
{"f_2976csc.scm",(void*)f_2976},
{"f_2972csc.scm",(void*)f_2972},
{"f_610csc.scm",(void*)f_610},
{"f_2959csc.scm",(void*)f_2959},
{"f_2955csc.scm",(void*)f_2955},
{"f_2951csc.scm",(void*)f_2951},
{"f_708csc.scm",(void*)f_708},
{"f_882csc.scm",(void*)f_882},
{"f_1367csc.scm",(void*)f_1367},
{"f_1608csc.scm",(void*)f_1608},
{"f_1611csc.scm",(void*)f_1611},
{"f_1614csc.scm",(void*)f_1614},
{"f_1996csc.scm",(void*)f_1996},
{"f_1665csc.scm",(void*)f_1665},
{"f_1674csc.scm",(void*)f_1674},
{"f_1851csc.scm",(void*)f_1851},
{"f_1959csc.scm",(void*)f_1959},
{"f_1965csc.scm",(void*)f_1965},
{"f_1862csc.scm",(void*)f_1862},
{"f_1873csc.scm",(void*)f_1873},
{"f_1949csc.scm",(void*)f_1949},
{"f_1941csc.scm",(void*)f_1941},
{"f_1924csc.scm",(void*)f_1924},
{"f_1900csc.scm",(void*)f_1900},
{"f_1905csc.scm",(void*)f_1905},
{"f_1887csc.scm",(void*)f_1887},
{"f_1856csc.scm",(void*)f_1856},
{"f_1821csc.scm",(void*)f_1821},
{"f_1752csc.scm",(void*)f_1752},
{"f_1804csc.scm",(void*)f_1804},
{"f_1800csc.scm",(void*)f_1800},
{"f_1785csc.scm",(void*)f_1785},
{"f_1783csc.scm",(void*)f_1783},
{"f_1779csc.scm",(void*)f_1779},
{"f_1756csc.scm",(void*)f_1756},
{"f_1742csc.scm",(void*)f_1742},
{"f_1729csc.scm",(void*)f_1729},
{"f_1712csc.scm",(void*)f_1712},
{"f_1698csc.scm",(void*)f_1698},
{"f_1684csc.scm",(void*)f_1684},
{"f_1646csc.scm",(void*)f_1646},
{"f_1652csc.scm",(void*)f_1652},
{"f_1655csc.scm",(void*)f_1655},
{"f_1601csc.scm",(void*)f_1601},
{"f_1605csc.scm",(void*)f_1605},
{"f_1555csc.scm",(void*)f_1555},
{"f_1585csc.scm",(void*)f_1585},
{"f_1577csc.scm",(void*)f_1577},
{"f_1565csc.scm",(void*)f_1565},
{"f_1544csc.scm",(void*)f_1544},
{"f_1519csc.scm",(void*)f_1519},
{"f_1531csc.scm",(void*)f_1531},
{"f_1523csc.scm",(void*)f_1523},
{"f_1506csc.scm",(void*)f_1506},
{"f_1480csc.scm",(void*)f_1480},
{"f_1492csc.scm",(void*)f_1492},
{"f_1484csc.scm",(void*)f_1484},
{"f_1459csc.scm",(void*)f_1459},
{"f_1463csc.scm",(void*)f_1463},
{"f_1442csc.scm",(void*)f_1442},
{"f_1425csc.scm",(void*)f_1425},
{"f_1408csc.scm",(void*)f_1408},
{"f_1391csc.scm",(void*)f_1391},
{"f_1350csc.scm",(void*)f_1350},
{"f_1340csc.scm",(void*)f_1340},
{"f_1330csc.scm",(void*)f_1330},
{"f_1320csc.scm",(void*)f_1320},
{"f_1310csc.scm",(void*)f_1310},
{"f_1300csc.scm",(void*)f_1300},
{"f_1279csc.scm",(void*)f_1279},
{"f_1255csc.scm",(void*)f_1255},
{"f_1266csc.scm",(void*)f_1266},
{"f_1258csc.scm",(void*)f_1258},
{"f_1242csc.scm",(void*)f_1242},
{"f_1231csc.scm",(void*)f_1231},
{"f_1191csc.scm",(void*)f_1191},
{"f_1195csc.scm",(void*)f_1195},
{"f_1198csc.scm",(void*)f_1198},
{"f_1100csc.scm",(void*)f_1100},
{"f_1118csc.scm",(void*)f_1118},
{"f_1103csc.scm",(void*)f_1103},
{"f_1043csc.scm",(void*)f_1043},
{"f_1031csc.scm",(void*)f_1031},
{"f_1019csc.scm",(void*)f_1019},
{"f_1007csc.scm",(void*)f_1007},
{"f_974csc.scm",(void*)f_974},
{"f_963csc.scm",(void*)f_963},
{"f_932csc.scm",(void*)f_932},
{"f_925csc.scm",(void*)f_925},
{"f_916csc.scm",(void*)f_916},
{"f_909csc.scm",(void*)f_909},
{"f_897csc.scm",(void*)f_897},
{"f_885csc.scm",(void*)f_885},
{"f_873csc.scm",(void*)f_873},
{"f_840csc.scm",(void*)f_840},
{"f_866csc.scm",(void*)f_866},
{"f_843csc.scm",(void*)f_843},
{"f_859csc.scm",(void*)f_859},
{"f_846csc.scm",(void*)f_846},
{"f_849csc.scm",(void*)f_849},
{"f_718csc.scm",(void*)f_718},
{"f_803csc.scm",(void*)f_803},
{"f_813csc.scm",(void*)f_813},
{"f_806csc.scm",(void*)f_806},
{"f_2074csc.scm",(void*)f_2074},
{"f_2078csc.scm",(void*)f_2078},
{"f_2325csc.scm",(void*)f_2325},
{"f_2328csc.scm",(void*)f_2328},
{"f_2319csc.scm",(void*)f_2319},
{"f_2081csc.scm",(void*)f_2081},
{"f_2084csc.scm",(void*)f_2084},
{"f_2256csc.scm",(void*)f_2256},
{"f_2298csc.scm",(void*)f_2298},
{"f_2264csc.scm",(void*)f_2264},
{"f_2279csc.scm",(void*)f_2279},
{"f_2284csc.scm",(void*)f_2284},
{"f_2268csc.scm",(void*)f_2268},
{"f_2276csc.scm",(void*)f_2276},
{"f_2272csc.scm",(void*)f_2272},
{"f_2260csc.scm",(void*)f_2260},
{"f_2252csc.scm",(void*)f_2252},
{"f_2248csc.scm",(void*)f_2248},
{"f_2244csc.scm",(void*)f_2244},
{"f_2087csc.scm",(void*)f_2087},
{"f_2091csc.scm",(void*)f_2091},
{"f_2095csc.scm",(void*)f_2095},
{"f_2101csc.scm",(void*)f_2101},
{"f_2109csc.scm",(void*)f_2109},
{"f_2113csc.scm",(void*)f_2113},
{"f_2226csc.scm",(void*)f_2226},
{"f_2118csc.scm",(void*)f_2118},
{"f_2187csc.scm",(void*)f_2187},
{"f_2194csc.scm",(void*)f_2194},
{"f_2174csc.scm",(void*)f_2174},
{"f_2120csc.scm",(void*)f_2120},
{"f_2104csc.scm",(void*)f_2104},
{"f_2066csc.scm",(void*)f_2066},
{"f_765csc.scm",(void*)f_765},
{"f_768csc.scm",(void*)f_768},
{"f_775csc.scm",(void*)f_775},
{"f_721csc.scm",(void*)f_721},
{"f_2359csc.scm",(void*)f_2359},
{"f_2363csc.scm",(void*)f_2363},
{"f_2400csc.scm",(void*)f_2400},
{"f_2412csc.scm",(void*)f_2412},
{"f_2404csc.scm",(void*)f_2404},
{"f_2408csc.scm",(void*)f_2408},
{"f_2388csc.scm",(void*)f_2388},
{"f_2384csc.scm",(void*)f_2384},
{"f_2366csc.scm",(void*)f_2366},
{"f_2343csc.scm",(void*)f_2343},
{"f_2357csc.scm",(void*)f_2357},
{"f_2347csc.scm",(void*)f_2347},
{"f_727csc.scm",(void*)f_727},
{"f_742csc.scm",(void*)f_742},
{"f_759csc.scm",(void*)f_759},
{"f_755csc.scm",(void*)f_755},
{"f_733csc.scm",(void*)f_733},
{"f_2560csc.scm",(void*)f_2560},
{"f_2554csc.scm",(void*)f_2554},
{"f_2552csc.scm",(void*)f_2552},
{"f_2548csc.scm",(void*)f_2548},
{"f_2439csc.scm",(void*)f_2439},
{"f_2442csc.scm",(void*)f_2442},
{"f_2536csc.scm",(void*)f_2536},
{"f_2540csc.scm",(void*)f_2540},
{"f_2544csc.scm",(void*)f_2544},
{"f_2528csc.scm",(void*)f_2528},
{"f_2520csc.scm",(void*)f_2520},
{"f_2516csc.scm",(void*)f_2516},
{"f_2512csc.scm",(void*)f_2512},
{"f_2445csc.scm",(void*)f_2445},
{"f_2457csc.scm",(void*)f_2457},
{"f_2490csc.scm",(void*)f_2490},
{"f_2486csc.scm",(void*)f_2486},
{"f_2482csc.scm",(void*)f_2482},
{"f_2478csc.scm",(void*)f_2478},
{"f_2474csc.scm",(void*)f_2474},
{"f_2470csc.scm",(void*)f_2470},
{"f_2448csc.scm",(void*)f_2448},
{"f_679csc.scm",(void*)f_679},
{"f_684csc.scm",(void*)f_684},
{"f_688csc.scm",(void*)f_688},
{"f_640csc.scm",(void*)f_640},
{"f_658csc.scm",(void*)f_658},
{"f_633csc.scm",(void*)f_633},
{"f_638csc.scm",(void*)f_638},
{"f_2941csc.scm",(void*)f_2941},
{"f_2947csc.scm",(void*)f_2947},
{"f_2944csc.scm",(void*)f_2944},
{"f_2925csc.scm",(void*)f_2925},
{"f_2929csc.scm",(void*)f_2929},
{"f_2893csc.scm",(void*)f_2893},
{"f_2897csc.scm",(void*)f_2897},
{"f_2920csc.scm",(void*)f_2920},
{"f_2901csc.scm",(void*)f_2901},
{"f_2904csc.scm",(void*)f_2904},
{"f_2864csc.scm",(void*)f_2864},
{"f_2890csc.scm",(void*)f_2890},
{"f_2876csc.scm",(void*)f_2876},
{"f_2871csc.scm",(void*)f_2871},
{"f_2815csc.scm",(void*)f_2815},
{"f_2817csc.scm",(void*)f_2817},
{"f_2847csc.scm",(void*)f_2847},
{"f_2854csc.scm",(void*)f_2854},
{"f_2840csc.scm",(void*)f_2840},
{"f_2811csc.scm",(void*)f_2811},
{"f_2797csc.scm",(void*)f_2797},
{"f_2807csc.scm",(void*)f_2807},
{"f_2715csc.scm",(void*)f_2715},
{"f_2719csc.scm",(void*)f_2719},
{"f_2767csc.scm",(void*)f_2767},
{"f_2761csc.scm",(void*)f_2761},
{"f_2730csc.scm",(void*)f_2730},
{"f_2726csc.scm",(void*)f_2726},
{"f_2663csc.scm",(void*)f_2663},
{"f_2709csc.scm",(void*)f_2709},
{"f_2703csc.scm",(void*)f_2703},
{"f_2701csc.scm",(void*)f_2701},
{"f_2697csc.scm",(void*)f_2697},
{"f_2671csc.scm",(void*)f_2671},
{"f_2566csc.scm",(void*)f_2566},
{"f_2570csc.scm",(void*)f_2570},
{"f_2576csc.scm",(void*)f_2576},
{"f_2581csc.scm",(void*)f_2581},
{"f_2602csc.scm",(void*)f_2602},
{"f_2640csc.scm",(void*)f_2640},
{"f_2622csc.scm",(void*)f_2622},
{"f_2626csc.scm",(void*)f_2626},
{"f_2595csc.scm",(void*)f_2595},
{"f_2599csc.scm",(void*)f_2599},
{"f_2414csc.scm",(void*)f_2414},
{"f_2426csc.scm",(void*)f_2426},
{"f_2422csc.scm",(void*)f_2422},
{"f_3190csc.scm",(void*)f_3190},
{"f_3195csc.scm",(void*)f_3195},
{"f_458csc.scm",(void*)f_458},
{"f_465csc.scm",(void*)f_465},
{"f_445csc.scm",(void*)f_445},
{"f_416csc.scm",(void*)f_416},
{"f_427csc.scm",(void*)f_427},
{"f_420csc.scm",(void*)f_420},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
