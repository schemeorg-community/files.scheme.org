/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:48
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: utils.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file uutils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[120];
static double C_possibly_force_alignment;


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_437)
static void C_ccall f_437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1981)
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_fcall f_2000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_fcall f_1946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_fcall f_1891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1833)
static void C_fcall f_1833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1801)
static void C_fcall f_1801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1777)
static void C_fcall f_1777(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_fcall f_1592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static C_word C_fcall f_1545(C_word t0);
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_fcall f_1488(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_fcall f_1213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1162)
static void C_fcall f_1162(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_fcall f_1157(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1135)
static void C_fcall f_1135(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1088)
static void C_fcall f_1088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_fcall f_1083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1074)
static void C_fcall f_1074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_fcall f_991(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_fcall f_1027(C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_fcall f_960(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_899)
static void C_fcall f_899(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_908)
static void C_fcall f_908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_fcall f_845(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_861)
static void C_fcall f_861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_808)
static void C_ccall f_808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_702)
static void C_ccall f_702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_788)
static void C_ccall f_788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_705)
static void C_ccall f_705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_714)
static void C_ccall f_714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_fcall f_756(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_766)
static void C_ccall f_766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_646)
static void C_ccall f_646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_729)
static void C_ccall f_729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_673)
static void C_fcall f_673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_683)
static void C_ccall f_683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_570)
static void C_fcall f_570(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_574)
static void C_ccall f_574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_606)
static C_word C_fcall f_606(C_word t0,C_word t1);
C_noret_decl(f_532)
static void C_ccall f_532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_532)
static void C_ccall f_532r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_505)
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_510)
static void C_ccall f_510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_515)
static void C_ccall f_515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_489)
static void C_ccall f_489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_ccall f_496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_452)
static void C_fcall f_452(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_fcall f_456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_470)
static void C_ccall f_470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_fcall f_459(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1981)
static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1981(t0,t1,t2,t3);}

C_noret_decl(trf_2000)
static void C_fcall trf_2000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2000(t0,t1);}

C_noret_decl(trf_1946)
static void C_fcall trf_1946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1946(t0,t1);}

C_noret_decl(trf_1891)
static void C_fcall trf_1891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1891(t0,t1);}

C_noret_decl(trf_1833)
static void C_fcall trf_1833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1833(t0,t1,t2);}

C_noret_decl(trf_1801)
static void C_fcall trf_1801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1801(t0,t1,t2);}

C_noret_decl(trf_1777)
static void C_fcall trf_1777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1777(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1777(t0,t1);}

C_noret_decl(trf_1592)
static void C_fcall trf_1592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1592(t0,t1);}

C_noret_decl(trf_1488)
static void C_fcall trf_1488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1488(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1488(t0,t1);}

C_noret_decl(trf_1213)
static void C_fcall trf_1213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1213(t0,t1);}

C_noret_decl(trf_1162)
static void C_fcall trf_1162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1162(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1162(t0,t1);}

C_noret_decl(trf_1157)
static void C_fcall trf_1157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1157(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1157(t0,t1,t2);}

C_noret_decl(trf_1135)
static void C_fcall trf_1135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1135(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1135(t0,t1,t2,t3);}

C_noret_decl(trf_1088)
static void C_fcall trf_1088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1088(t0,t1);}

C_noret_decl(trf_1083)
static void C_fcall trf_1083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1083(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1083(t0,t1,t2);}

C_noret_decl(trf_1074)
static void C_fcall trf_1074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1074(t0,t1,t2,t3);}

C_noret_decl(trf_991)
static void C_fcall trf_991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_991(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_991(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1027)
static void C_fcall trf_1027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1027(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1027(t0,t1);}

C_noret_decl(trf_960)
static void C_fcall trf_960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_960(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_960(t0,t1,t2,t3);}

C_noret_decl(trf_899)
static void C_fcall trf_899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_899(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_899(t0,t1,t2,t3);}

C_noret_decl(trf_908)
static void C_fcall trf_908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_908(t0,t1,t2);}

C_noret_decl(trf_845)
static void C_fcall trf_845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_845(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_845(t0,t1,t2);}

C_noret_decl(trf_861)
static void C_fcall trf_861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_861(t0,t1);}

C_noret_decl(trf_756)
static void C_fcall trf_756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_756(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_756(t0,t1,t2);}

C_noret_decl(trf_673)
static void C_fcall trf_673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_673(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_673(t0,t1);}

C_noret_decl(trf_570)
static void C_fcall trf_570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_570(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_570(t0,t1,t2,t3);}

C_noret_decl(trf_452)
static void C_fcall trf_452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_452(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_452(t0,t1,t2);}

C_noret_decl(trf_456)
static void C_fcall trf_456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_456(t0,t1);}

C_noret_decl(trf_459)
static void C_fcall trf_459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_459(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(912)){
C_save(t1);
C_rereclaim2(912*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,120);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],20,"\003sysapropos-interned");
lf[4]=C_h_intern(&lf[4],18,"\003sysapropos-macros");
lf[5]=C_h_intern(&lf[5],13,"string-search");
lf[6]=C_h_intern(&lf[6],6,"regexp");
lf[7]=C_h_intern(&lf[7],13,"regexp-escape");
lf[8]=C_h_intern(&lf[8],14,"symbol->string");
lf[9]=C_h_intern(&lf[9],32,"\003syssymbol-has-toplevel-binding\077");
lf[10]=C_h_intern(&lf[10],23,"\003sysenvironment-symbols");
lf[11]=C_h_intern(&lf[11],23,"\003syshash-table-for-each");
lf[12]=C_h_intern(&lf[12],21,"\003sysmacro-environment");
lf[13]=C_h_intern(&lf[13],11,"\003sysapropos");
lf[14]=C_h_intern(&lf[14],10,"\003sysappend");
lf[15]=C_h_intern(&lf[15],12,"apropos-list");
lf[16]=C_h_intern(&lf[16],7,"apropos");
lf[17]=C_h_intern(&lf[17],8,"\000macros\077");
lf[18]=C_h_intern(&lf[18],11,"environment");
lf[19]=C_h_intern(&lf[19],15,"\003syssignal-hook");
lf[20]=C_h_intern(&lf[20],11,"\000type-error");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\0003bad argument type - not a string, symbol, or regexp");
lf[22]=C_h_intern(&lf[22],7,"regexp\077");
lf[23]=C_h_intern(&lf[23],23,"interaction-environment");
lf[24]=C_h_intern(&lf[24],8,"keyword\077");
lf[25]=C_h_intern(&lf[25],28,"\003syssymbol->qualified-string");
lf[26]=C_h_intern(&lf[26],7,"newline");
lf[27]=C_h_intern(&lf[27],7,"display");
lf[28]=C_h_intern(&lf[28],5,"macro");
lf[29]=C_h_intern(&lf[29],9,"procedure");
lf[30]=C_h_intern(&lf[30],21,"procedure-information");
lf[31]=C_h_intern(&lf[31],8,"variable");
lf[32]=C_h_intern(&lf[32],6,"macro\077");
lf[33]=C_h_intern(&lf[33],12,"\003sysfor-each");
lf[34]=C_h_intern(&lf[34],7,"sprintf");
lf[35]=C_h_intern(&lf[35],6,"system");
lf[36]=C_h_intern(&lf[36],7,"system*");
lf[37]=C_h_intern(&lf[37],9,"\003syserror");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],11,"delete-file");
lf[41]=C_h_intern(&lf[41],12,"delete-file*");
lf[42]=C_h_intern(&lf[42],12,"string-match");
lf[43]=C_h_intern(&lf[43],13,"string-append");
lf[44]=C_h_intern(&lf[44],20,"\003syswindows-platform");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\014([A-Za-z]:)\077");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[47]=C_h_intern(&lf[47],18,"absolute-pathname\077");
lf[49]=C_h_intern(&lf[49],13,"\003syssubstring");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000/\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[51]=C_h_intern(&lf[51],13,"make-pathname");
lf[52]=C_h_intern(&lf[52],22,"make-absolute-pathname");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[61]=C_h_intern(&lf[61],17,"\003sysstring-append");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[64]=C_h_intern(&lf[64],18,"decompose-pathname");
lf[65]=C_h_intern(&lf[65],18,"pathname-directory");
lf[66]=C_h_intern(&lf[66],13,"pathname-file");
lf[67]=C_h_intern(&lf[67],18,"pathname-extension");
lf[68]=C_h_intern(&lf[68],24,"pathname-strip-directory");
lf[69]=C_h_intern(&lf[69],24,"pathname-strip-extension");
lf[70]=C_h_intern(&lf[70],26,"pathname-replace-directory");
lf[71]=C_h_intern(&lf[71],21,"pathname-replace-file");
lf[72]=C_h_intern(&lf[72],26,"pathname-replace-extension");
lf[73]=C_h_intern(&lf[73],6,"getenv");
lf[74]=C_h_intern(&lf[74],21,"call-with-output-file");
lf[75]=C_h_intern(&lf[75],21,"create-temporary-file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[81]=C_h_intern(&lf[81],15,"directory-null\077");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[84]=C_h_intern(&lf[84],12,"string-split");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[86]=C_h_intern(&lf[86],9,"read-line");
lf[87]=C_h_intern(&lf[87],13,"for-each-line");
lf[88]=C_h_intern(&lf[88],18,"\003sysstandard-input");
lf[89]=C_h_intern(&lf[89],14,"\003syscheck-port");
lf[90]=C_h_intern(&lf[90],18,"for-each-argv-line");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[92]=C_h_intern(&lf[92],20,"with-input-from-file");
lf[93]=C_h_intern(&lf[93],22,"command-line-arguments");
lf[94]=C_h_intern(&lf[94],8,"read-all");
lf[95]=C_h_intern(&lf[95],20,"\003sysread-string/port");
lf[96]=C_h_intern(&lf[96],5,"port\077");
lf[97]=C_h_intern(&lf[97],6,"shift!");
lf[98]=C_h_intern(&lf[98],8,"unshift!");
lf[99]=C_h_intern(&lf[99],13,"port-for-each");
lf[100]=C_h_intern(&lf[100],7,"reverse");
lf[101]=C_h_intern(&lf[101],8,"port-map");
lf[102]=C_h_intern(&lf[102],9,"port-fold");
lf[103]=C_h_intern(&lf[103],19,"make-broadcast-port");
lf[104]=C_h_intern(&lf[104],12,"write-string");
lf[105]=C_h_intern(&lf[105],12,"flush-output");
lf[106]=C_h_intern(&lf[106],16,"make-output-port");
lf[107]=C_h_intern(&lf[107],4,"noop");
lf[108]=C_h_intern(&lf[108],22,"make-concatenated-port");
lf[109]=C_h_intern(&lf[109],18,"\003sysread-char/port");
lf[110]=C_h_intern(&lf[110],11,"char-ready\077");
lf[111]=C_h_intern(&lf[111],9,"peek-char");
lf[112]=C_h_intern(&lf[112],12,"read-string!");
lf[113]=C_h_intern(&lf[113],15,"make-input-port");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[116]=C_h_intern(&lf[116],21,"make-anchored-pattern");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\010[\134/\134\134].*");
lf[118]=C_h_intern(&lf[118],17,"register-feature!");
lf[119]=C_h_intern(&lf[119],5,"utils");
C_register_lf2(lf,120,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_437,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k435 */
static void C_ccall f_437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k438 in k435 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 69   register-feature! */
t3=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[119]);}

/* k441 in k438 in k435 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_443,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate((C_word*)lf[3]+1,t2);
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[4]+1,t4);
t6=*((C_word*)lf[5]+1);
t7=*((C_word*)lf[6]+1);
t8=*((C_word*)lf[7]+1);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_452,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_479,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_505,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_532,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[2]+1);
t14=C_mutate((C_word*)lf[15]+1,t13);
t15=*((C_word*)lf[2]+1);
t16=C_mutate((C_word*)lf[16]+1,t15);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_570,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_673,tmp=(C_word)a,a+=2,tmp);
t19=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_698,a[2]=t17,a[3]=t18,tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[34]+1);
t22=*((C_word*)lf[35]+1);
t23=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_790,a[2]=t21,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=*((C_word*)lf[39]+1);
t25=*((C_word*)lf[40]+1);
t26=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_808,a[2]=t24,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t27=*((C_word*)lf[42]+1);
t28=*((C_word*)lf[6]+1);
t29=*((C_word*)lf[43]+1);
t30=(C_truep(*((C_word*)lf[44]+1))?lf[45]:lf[46]);
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_828,a[2]=t28,a[3]=((C_word*)t0)[2],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 205  string-append */
t33=t29;
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t32,t30,lf[117]);}

/* k2028 in k441 in k438 in k435 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 205  make-anchored-pattern */
t2=*((C_word*)lf[116]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k826 in k441 in k438 in k435 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 206  regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_832,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t3=C_mutate(&lf[48],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_845,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[51]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[52]+1,t6);
t8=*((C_word*)lf[43]+1);
t9=*((C_word*)lf[47]+1);
t10=lf[53];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_899,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t14=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1072,a[2]=t12,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1133,a[2]=t12,a[3]=t9,a[4]=t10,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t16=*((C_word*)lf[42]+1);
t17=*((C_word*)lf[6]+1);
t18=*((C_word*)lf[43]+1);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1209,a[2]=t17,a[3]=((C_word*)t0)[2],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 289  regexp */
t20=t17;
((C_proc3)(void*)(*((C_word*)t20+1)))(3,t20,t19,lf[115]);}

/* k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 290  regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[114]);}

/* k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1213,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[65]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[66]+1,t6);
t8=*((C_word*)lf[2]+1);
t9=C_mutate((C_word*)lf[67]+1,t8);
t10=*((C_word*)lf[2]+1);
t11=C_mutate((C_word*)lf[68]+1,t10);
t12=*((C_word*)lf[2]+1);
t13=C_mutate((C_word*)lf[69]+1,t12);
t14=*((C_word*)lf[2]+1);
t15=C_mutate((C_word*)lf[70]+1,t14);
t16=*((C_word*)lf[2]+1);
t17=C_mutate((C_word*)lf[71]+1,t16);
t18=*((C_word*)lf[2]+1);
t19=C_mutate((C_word*)lf[72]+1,t18);
t20=*((C_word*)lf[64]+1);
t21=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1350,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1380,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1398,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1416,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t29=*((C_word*)lf[73]+1);
t30=*((C_word*)lf[51]+1);
t31=*((C_word*)lf[39]+1);
t32=*((C_word*)lf[74]+1);
t33=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1470,a[2]=t29,a[3]=t30,a[4]=t31,a[5]=t32,tmp=(C_word)a,a+=6,tmp));
t34=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1535,tmp=(C_word)a,a+=2,tmp));
t35=*((C_word*)lf[86]+1);
t36=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1580,a[2]=t35,tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1616,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1661,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1697,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1747,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1771,tmp=(C_word)a,a+=2,tmp));
t42=*((C_word*)lf[100]+1);
t43=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1795,a[2]=t42,tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1827,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1852,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1876,tmp=(C_word)a,a+=2,tmp));
t47=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t47+1)))(2,t47,C_SCHEME_UNDEFINED);}

/* make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_1876r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1876r(t0,t1,t2,t3);}}

static void C_ccall f_1876r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(17);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1920,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1975,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 483  make-input-port */
t11=*((C_word*)lf[113]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t1,t7,t8,*((C_word*)lf[107]+1),t9,t10);}

/* a1974 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1975,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1981,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_1981(t9,t1,t3,C_fix(0));}

/* loop in a1974 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1981,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[5])[1]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[5])[1]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t3);
/* utils.scm: 511  read-string! */
t7=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t2,((C_word*)t0)[2],t5,t6);}}}

/* k1995 in loop in a1974 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2000(t5,t4);}
else{
t3=t2;
f_2000(t3,C_SCHEME_UNDEFINED);}}

/* k1998 in k1995 in loop in a1974 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_2000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[5]);
/* utils.scm: 514  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1981(t4,((C_word*)t0)[2],t2,t3);}

/* a1939 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1946(t5,t1);}

/* loop in a1939 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1946,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1956,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* utils.scm: 501  peek-char */
t4=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k1954 in loop in a1939 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* utils.scm: 504  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1946(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* a1919 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1920,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* utils.scm: 495  char-ready? */
t3=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}

/* a1884 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1891,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1891(t5,t1);}

/* loop in a1884 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1891,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1901,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* read-char/port */
t4=*((C_word*)lf[109]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k1899 in loop in a1884 in make-concatenated-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* utils.scm: 491  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1891(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* make-broadcast-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1852r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1852r(t0,t1,t2);}}

static void C_ccall f_1852r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 476  make-output-port */
t5=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t3,*((C_word*)lf[107]+1),t4);}

/* a1869 in make-broadcast-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
/* for-each */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,*((C_word*)lf[105]+1),((C_word*)t0)[2]);}

/* a1857 in make-broadcast-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a1863 in a1857 in make-broadcast-port in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1864,3,t0,t1,t2);}
/* write-string */
t3=*((C_word*)lf[104]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* port-fold in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1827,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1833,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1833(t8,t1,t3);}

/* loop in port-fold in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1833,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 468  thunk */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1835 in loop in port-fold in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 471  fn */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,((C_word*)t0)[4]);}}

/* k1848 in k1835 in loop in port-fold in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 471  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1833(t2,((C_word*)t0)[2],t1);}

/* port-map in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1795,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1801,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1801(t7,t1,C_SCHEME_END_OF_LIST);}

/* loop in port-map in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1801,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 461  thunk */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1803 in loop in port-map in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
/* utils.scm: 463  reverse */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 464  fn */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* k1823 in k1803 in loop in port-map in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* utils.scm: 464  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1801(t3,((C_word*)t0)[2],t2);}

/* port-for-each in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1771,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1777,a[2]=t3,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1777(t7,t1);}

/* loop in port-for-each in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1777(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1777,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 452  thunk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1779 in loop in port-for-each in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 454  fn */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* k1788 in k1779 in loop in port-for-each in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 455  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1777(t2,((C_word*)t0)[2]);}

/* unshift! in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1747,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_pair_2(t3,lf[98]);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
t9=(C_word)C_i_setslot(t3,C_fix(0),t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t3);}

/* shift! in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1697r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1697r(t0,t1,t2,t3);}}

static void C_ccall f_1697r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_check_pair_2(t2,lf[97]);
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_check_pair_2(t8,lf[97]);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_i_setslot(t2,C_fix(1),t10);
t12=(C_word)C_slot(t8,C_fix(0));
t13=(C_word)C_i_setslot(t2,C_fix(0),t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t7);}}

/* read-all in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1661r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1661r(t0,t1,t2);}}

static void C_ccall f_1661r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?*((C_word*)lf[88]+1):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1671,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 422  port? */
t6=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1669 in read-all in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1671,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1679,tmp=(C_word)a,a+=2,tmp);
/* utils.scm: 424  with-input-from-file */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a1678 in k1669 in read-all in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[88]+1));}

/* for-each-argv-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1616,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1641,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 410  command-line-arguments */
t4=*((C_word*)lf[93]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1639 in for-each-argv-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 413  for-each-line */
t2=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a1654 in k1639 in for-each-argv-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1655,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_u_i_string_equal_p(t2,lf[91]))){
/* utils.scm: 408  for-each-line */
t4=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 409  with-input-from-file */
t5=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a1633 in a1654 in k1639 in for-each-argv-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1580r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1580r(t0,t1,t2,t3);}}

static void C_ccall f_1580r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):*((C_word*)lf[88]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1587,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 395  ##sys#check-port */
t7=*((C_word*)lf[89]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[87]);}

/* k1585 in for-each-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1592(t5,((C_word*)t0)[2]);}

/* loop in k1585 in for-each-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1592,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 397  read-line */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1594 in loop in k1585 in for-each-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 399  proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k1603 in k1594 in loop in k1585 in for-each-line in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 400  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1592(t2,((C_word*)t0)[2]);}

/* directory-null? in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1535,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1543,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_1543(2,t4,t2);}
else{
t4=(C_word)C_i_check_string_2(t2,lf[81]);
/* utils.scm: 384  string-split */
t5=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t2,lf[85],C_SCHEME_TRUE);}}

/* k1541 in directory-null? in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1545,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1545(t1));}

/* loop in k1541 in directory-null? in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static C_word C_fcall f_1545(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_i_car(t1);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[82]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[83]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1470r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1470r(t0,t1,t2);}}

static void C_ccall f_1470r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 365  getenv */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[80]);}

/* k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1477(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 365  getenv */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[79]);}}

/* k1525 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1477(2,t2,t1);}
else{
/* utils.scm: 365  getenv */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[78]);}}

/* k1475 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[6],C_fix(0)):lf[76]);
t4=(C_word)C_i_check_string_2(t3,lf[75]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1488,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_1488(t8,((C_word*)t0)[2]);}

/* loop in k1475 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1488(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1488,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1518,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 370  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k1516 in loop in k1475 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 370  ##sys#string-append */
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[77],t1);}

/* k1512 in loop in k1475 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 370  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1493 in loop in k1475 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 371  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1499 in k1493 in loop in k1475 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 372  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1488(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 373  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a1508 in k1499 in k1493 in loop in k1475 in k1472 in create-temporary-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1509,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1452,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1458,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1464,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a1463 in pathname-replace-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1464,5,t0,t1,t2,t3,t4);}
/* utils.scm: 357  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a1457 in pathname-replace-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1458,2,t0,t1);}
/* utils.scm: 356  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1434,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1440,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a1445 in pathname-replace-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1446,5,t0,t1,t2,t3,t4);}
/* utils.scm: 352  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a1439 in pathname-replace-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
/* utils.scm: 351  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1416,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1422,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1428,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a1427 in pathname-replace-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1428,5,t0,t1,t2,t3,t4);}
/* utils.scm: 347  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a1421 in pathname-replace-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1422,2,t0,t1);}
/* utils.scm: 346  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1398,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1404,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1410,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a1409 in pathname-strip-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1410,5,t0,t1,t2,t3,t4);}
/* utils.scm: 342  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a1403 in pathname-strip-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1404,2,t0,t1);}
/* utils.scm: 341  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1380,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1386,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1392,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a1391 in pathname-strip-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1392,5,t0,t1,t2,t3,t4);}
/* utils.scm: 337  make-pathname */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a1385 in pathname-strip-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1386,2,t0,t1);}
/* utils.scm: 336  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1365,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1371,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1377,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a1376 in pathname-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1377,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a1370 in pathname-extension in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1371,2,t0,t1);}
/* utils.scm: 331  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1350,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1356,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1362,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a1361 in pathname-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1362,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a1355 in pathname-file in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
/* utils.scm: 326  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1335,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1341,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1347,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a1346 in pathname-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1347,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a1340 in pathname-directory in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1341,2,t0,t1);}
/* utils.scm: 321  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1227,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[64]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* utils.scm: 300  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 301  string-match */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k1241 in decompose-pathname in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(t1);
/* utils.scm: 303  strip-pds */
f_1213(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 304  string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k1270 in k1241 in decompose-pathname in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(t1);
/* utils.scm: 306  strip-pds */
f_1213(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 307  strip-pds */
f_1213(t2,((C_word*)t0)[2]);}}

/* k1295 in k1270 in k1241 in decompose-pathname in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 307  values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k1280 in k1270 in k1241 in decompose-pathname in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* utils.scm: 306  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k1251 in k1241 in decompose-pathname in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t3=(C_word)C_u_i_cddddr(((C_word*)t0)[3]);
t4=(C_word)C_u_i_car(t3);
/* utils.scm: 303  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k1210 in k1207 in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1213(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1213,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[62]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[63]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* utils.scm: 296  chop-pds */
f_845(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr4r,(void*)f_1133r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1133r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1133r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(14);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1135,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1162,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext161172 */
t8=t7;
f_1162(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds162170 */
t10=t6;
f_1157(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body159164 */
t12=t5;
f_1135(t12,t1,t8,t10);}}}

/* def-ext161 in make-absolute-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1162,NULL,2,t0,t1);}
/* def-pds162170 */
t2=((C_word*)t0)[2];
f_1157(t2,t1,C_SCHEME_FALSE);}

/* def-pds162 in make-absolute-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1157,NULL,3,t0,t1,t2);}
/* body159164 */
t3=((C_word*)t0)[2];
f_1135(t3,t1,t2,C_SCHEME_FALSE);}

/* body159 in make-absolute-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1135(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1135,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1143,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 277  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_960(t5,t4,((C_word*)t0)[2],t3);}

/* k1141 in body159 in make-absolute-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 278  absolute-pathname? */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k1147 in k1141 in body159 in make-absolute-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1146(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
/* utils.scm: 280  ##sys#string-append */
t4=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}}

/* k1144 in k1141 in body159 in make-absolute-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 275  _make-pathname */
t2=((C_word*)t0)[6];
f_991(t2,((C_word*)t0)[5],lf[52],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_1072r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1072r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1072r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1074,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext140148 */
t8=t7;
f_1088(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds141146 */
t10=t6;
f_1083(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body138143 */
t12=t5;
f_1074(t12,t1,t8,t10);}}}

/* def-ext140 in make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1088,NULL,2,t0,t1);}
/* def-pds141146 */
t2=((C_word*)t0)[2];
f_1083(t2,t1,C_SCHEME_FALSE);}

/* def-pds141 in make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1083(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1083,NULL,3,t0,t1,t2);}
/* body138143 */
t3=((C_word*)t0)[2];
f_1074(t3,t1,t2,C_SCHEME_FALSE);}

/* body138 in make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1074,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1082,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 271  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_960(t5,t4,((C_word*)t0)[2],t3);}

/* k1080 in body138 in make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 271  _make-pathname */
t2=((C_word*)t0)[6];
f_991(t2,((C_word*)t0)[5],lf[51],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_991(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_991,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[56]);
t8=(C_truep(t4)?t4:lf[57]);
t9=(C_truep(t6)?(C_word)C_block_size(t6):C_fix(1));
t10=(C_word)C_i_check_string_2(t3,t2);
t11=(C_word)C_i_check_string_2(t8,t2);
t12=(C_word)C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?(C_word)C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1020,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_block_size(t8);
t16=(C_word)C_fixnum_greater_or_equal_p(t15,t9);
t17=(C_truep(t16)?(C_truep(t6)?(C_word)C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9):(C_word)C_u_i_memq((C_word)C_subchar(t8,C_fix(0)),lf[60])):C_SCHEME_FALSE);
if(C_truep(t17)){
t18=(C_word)C_block_size(t8);
/* utils.scm: 261  ##sys#substring */
t19=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t14,t8,t9,t18);}
else{
t18=t14;
f_1020(2,t18,t8);}}

/* k1018 in _make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1027(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_1027(t4,C_SCHEME_FALSE);}}

/* k1025 in k1018 in _make-pathname in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_1027(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[58]:lf[59]);
/* utils.scm: 255  string-append */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* canonicalize-dirs in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_960(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_960,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[55]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
/* utils.scm: 244  conc-dirs */
t7=((C_word*)t0)[2];
f_899(t7,t1,t6,t3);}
else{
/* utils.scm: 245  conc-dirs */
t6=((C_word*)t0)[2];
f_899(t6,t1,t2,t3);}}}

/* conc-dirs in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_899(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_899,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t2,lf[51]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_908(t8,t1,t2);}

/* loop in conc-dirs in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_908,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[54]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
/* utils.scm: 236  loop */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_u_i_car(t2);
/* utils.scm: 238  chop-pds */
f_845(t6,t7,((C_word*)t0)[4]);}}}

/* k936 in loop in conc-dirs in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_946,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* utils.scm: 240  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_908(t6,t4,t5);}

/* k944 in k936 in loop in conc-dirs in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 237  string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_845(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_845,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_block_size(t2);
t5=(C_truep(t3)?(C_word)C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_861,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=(C_word)C_u_fixnum_difference(t4,t5);
t8=t6;
f_861(t8,(C_word)C_substring_compare(t2,t3,t7,C_fix(0),t5));}
else{
t7=(C_word)C_u_fixnum_difference(t4,t5);
t8=(C_word)C_subchar(t2,t7);
t9=t6;
f_861(t9,(C_word)C_u_i_memq(t8,lf[50]));}}
else{
t7=t6;
f_861(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k859 in chop-pds in k829 in k826 in k441 in k438 in k435 */
static void C_fcall f_861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 220  ##sys#substring */
t3=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_832,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[47]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 209  string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k841 in absolute-pathname? in k829 in k826 in k441 in k438 in k435 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* delete-file* in k441 in k438 in k435 */
static void C_ccall f_808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_808,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_815,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 195  file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k813 in delete-file* in k441 in k438 in k435 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_821,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 195  delete-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k819 in k813 in delete-file* in k441 in k438 in k435 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* system* in k441 in k438 in k435 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_790r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_790r(t0,t1,t2,t3);}}

static void C_ccall f_790r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k792 in system* in k441 in k438 in k435 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_797,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 184  system */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k795 in k792 in system* in k441 in k438 in k435 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 186  ##sys#error */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}}

/* apropos in k441 in k438 in k435 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_698r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_698r(t0,t1,t2,t3);}}

static void C_ccall f_698r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_702,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 152  %apropos-list */
f_570(t4,lf[16],t2,t3);}

/* k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_702,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_705,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_779,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}

/* a778 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_779,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_788,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 156  symlen */
f_673(t3,t2);}

/* k786 in a778 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_710,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 160  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_717,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_777,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 161  symlen */
f_673(t3,((C_word*)t0)[4]);}

/* k775 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_756,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_756(t6,((C_word*)t0)[2],t2);}

/* do62 in k775 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_fcall f_756(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_756,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_766,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 163  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k764 in do62 in k775 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_756(t3,((C_word*)t0)[2],t2);}

/* k715 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k718 in k715 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k721 in k718 in k715 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k724 in k721 in k718 in k715 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_729,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_735,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 165  macro? */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k733 in k724 in k721 in k718 in k715 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_735,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 167  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[28]);}
else{
t2=(C_word)C_retrieve(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_646,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 135  procedure-information */
t4=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
/* utils.scm: 172  display */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[31]);}}}

/* k644 in k733 in k724 in k721 in k718 in k715 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_646,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[29],t2);
/* utils.scm: 136  display */
t4=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}
else{
if(C_truep(t1)){
/* utils.scm: 137  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}
else{
/* utils.scm: 138  display */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[29]);}}}

/* k727 in k724 in k721 in k718 in k715 in k712 in a709 in k703 in k700 in apropos in k441 in k438 in k435 */
static void C_ccall f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 173  newline */
t2=*((C_word*)lf[26]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* apropos-list in k441 in k438 in k435 */
static void C_ccall f_692(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_692r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_692r(t0,t1,t2,t3);}}

static void C_ccall f_692r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* utils.scm: 148  %apropos-list */
f_570(t1,lf[15],t2,t3);}

/* symlen in k441 in k438 in k435 */
static void C_fcall f_673(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_673,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_690,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 141  ##sys#symbol->qualified-string */
t4=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k688 in symlen in k441 in k438 in k435 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_690,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_683,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 142  keyword? */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k681 in k688 in symlen in k441 in k438 in k435 */
static void C_ccall f_683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_fixnum_difference(((C_word*)t0)[2],C_fix(2)):((C_word*)t0)[2]));}

/* %apropos-list in k441 in k438 in k435 */
static void C_fcall f_570(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_570,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_574,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 116  interaction-environment */
t6=*((C_word*)lf[23]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k572 in %apropos-list in k441 in k438 in k435 */
static void C_ccall f_574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_574,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_606,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=f_606(t6,((C_word*)t0)[5]);
t8=(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[18],((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_583,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_stringp(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_592(2,t12,t10);}
else{
t12=(C_word)C_i_symbolp(((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t11;
f_592(2,t13,t12);}
else{
/* utils.scm: 130  regexp? */
t13=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t11,((C_word*)t0)[2]);}}}

/* k590 in k572 in %apropos-list in k441 in k438 in k435 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_583(2,t2,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 131  ##sys#signal-hook */
t2=*((C_word*)lf[19]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[20],((C_word*)t0)[3],lf[21],((C_word*)t0)[2]);}}

/* k581 in k572 in %apropos-list in k441 in k438 in k435 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 132  ##sys#apropos */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k572 in %apropos-list in k441 in k438 in k435 */
static C_word C_fcall f_606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_eqp(lf[17],t2);
if(C_truep(t3)){
t4=(C_word)C_u_i_cadr(t1);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_u_i_cddr(t1);
t10=t6;
t1=t10;
goto loop;}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=(C_word)C_slot(t1,C_fix(1));
t10=t5;
t1=t10;
goto loop;}}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#apropos in k441 in k438 in k435 */
static void C_ccall f_532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_532r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_532r(t0,t1,t2,t3,t4);}}

static void C_ccall f_532r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_539,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 107  ##sys#apropos-interned */
t8=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k537 in ##sys#apropos in k441 in k438 in k435 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_539,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_549,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 109  ##sys#apropos-macros */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k547 in k537 in ##sys#apropos in k441 in k438 in k435 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 109  ##sys#append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_505,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_510,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 97   makpat */
t6=((C_word*)t0)[2];
f_452(t6,t5,((C_word*)t4)[1]);}

/* k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_510,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_513,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 99   ##sys#hash-table-for-each */
t7=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,*((C_word*)lf[12]+1));}

/* a514 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_515,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_522,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_530,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 101  symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k528 in a514 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 101  string-search */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k520 in a514 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_522,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k511 in k508 in ##sys#apropos-macros in k441 in k438 in k435 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_479,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_484,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 89   makpat */
t6=((C_word*)t0)[2];
f_452(t6,t5,((C_word*)t4)[1]);}

/* k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_484,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_489,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 90   ##sys#environment-symbols */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a488 in k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_489,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_496,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_503,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 92   symbol->string */
t5=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k501 in a488 in k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 92   string-search */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k494 in a488 in k482 in ##sys#apropos-interned in k441 in k438 in k435 */
static void C_ccall f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* utils.scm: 93   ##sys#symbol-has-toplevel-binding? */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* makpat in k441 in k438 in k435 */
static void C_fcall f_452(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_452,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 82   symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_456(t5,C_SCHEME_UNDEFINED);}}

/* k475 in makpat in k441 in k438 in k435 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_456(t3,t2);}

/* k454 in makpat in k441 in k438 in k435 */
static void C_fcall f_456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_456,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_466,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_470,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 84   regexp-escape */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_459(t3,C_SCHEME_UNDEFINED);}}

/* k468 in k454 in makpat in k441 in k438 in k435 */
static void C_ccall f_470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 84   regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k464 in k454 in makpat in k441 in k438 in k435 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_459(t3,t2);}

/* k457 in k454 in makpat in k441 in k438 in k435 */
static void C_fcall f_459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[172] = {
{"toplevelutils.scm",(void*)C_utils_toplevel},
{"f_437utils.scm",(void*)f_437},
{"f_440utils.scm",(void*)f_440},
{"f_443utils.scm",(void*)f_443},
{"f_2030utils.scm",(void*)f_2030},
{"f_828utils.scm",(void*)f_828},
{"f_831utils.scm",(void*)f_831},
{"f_1209utils.scm",(void*)f_1209},
{"f_1212utils.scm",(void*)f_1212},
{"f_1876utils.scm",(void*)f_1876},
{"f_1975utils.scm",(void*)f_1975},
{"f_1981utils.scm",(void*)f_1981},
{"f_1997utils.scm",(void*)f_1997},
{"f_2000utils.scm",(void*)f_2000},
{"f_1940utils.scm",(void*)f_1940},
{"f_1946utils.scm",(void*)f_1946},
{"f_1956utils.scm",(void*)f_1956},
{"f_1920utils.scm",(void*)f_1920},
{"f_1885utils.scm",(void*)f_1885},
{"f_1891utils.scm",(void*)f_1891},
{"f_1901utils.scm",(void*)f_1901},
{"f_1852utils.scm",(void*)f_1852},
{"f_1870utils.scm",(void*)f_1870},
{"f_1858utils.scm",(void*)f_1858},
{"f_1864utils.scm",(void*)f_1864},
{"f_1827utils.scm",(void*)f_1827},
{"f_1833utils.scm",(void*)f_1833},
{"f_1837utils.scm",(void*)f_1837},
{"f_1850utils.scm",(void*)f_1850},
{"f_1795utils.scm",(void*)f_1795},
{"f_1801utils.scm",(void*)f_1801},
{"f_1805utils.scm",(void*)f_1805},
{"f_1825utils.scm",(void*)f_1825},
{"f_1771utils.scm",(void*)f_1771},
{"f_1777utils.scm",(void*)f_1777},
{"f_1781utils.scm",(void*)f_1781},
{"f_1790utils.scm",(void*)f_1790},
{"f_1747utils.scm",(void*)f_1747},
{"f_1697utils.scm",(void*)f_1697},
{"f_1661utils.scm",(void*)f_1661},
{"f_1671utils.scm",(void*)f_1671},
{"f_1679utils.scm",(void*)f_1679},
{"f_1616utils.scm",(void*)f_1616},
{"f_1641utils.scm",(void*)f_1641},
{"f_1655utils.scm",(void*)f_1655},
{"f_1634utils.scm",(void*)f_1634},
{"f_1580utils.scm",(void*)f_1580},
{"f_1587utils.scm",(void*)f_1587},
{"f_1592utils.scm",(void*)f_1592},
{"f_1596utils.scm",(void*)f_1596},
{"f_1605utils.scm",(void*)f_1605},
{"f_1535utils.scm",(void*)f_1535},
{"f_1543utils.scm",(void*)f_1543},
{"f_1545utils.scm",(void*)f_1545},
{"f_1470utils.scm",(void*)f_1470},
{"f_1474utils.scm",(void*)f_1474},
{"f_1527utils.scm",(void*)f_1527},
{"f_1477utils.scm",(void*)f_1477},
{"f_1488utils.scm",(void*)f_1488},
{"f_1518utils.scm",(void*)f_1518},
{"f_1514utils.scm",(void*)f_1514},
{"f_1495utils.scm",(void*)f_1495},
{"f_1501utils.scm",(void*)f_1501},
{"f_1509utils.scm",(void*)f_1509},
{"f_1452utils.scm",(void*)f_1452},
{"f_1464utils.scm",(void*)f_1464},
{"f_1458utils.scm",(void*)f_1458},
{"f_1434utils.scm",(void*)f_1434},
{"f_1446utils.scm",(void*)f_1446},
{"f_1440utils.scm",(void*)f_1440},
{"f_1416utils.scm",(void*)f_1416},
{"f_1428utils.scm",(void*)f_1428},
{"f_1422utils.scm",(void*)f_1422},
{"f_1398utils.scm",(void*)f_1398},
{"f_1410utils.scm",(void*)f_1410},
{"f_1404utils.scm",(void*)f_1404},
{"f_1380utils.scm",(void*)f_1380},
{"f_1392utils.scm",(void*)f_1392},
{"f_1386utils.scm",(void*)f_1386},
{"f_1365utils.scm",(void*)f_1365},
{"f_1377utils.scm",(void*)f_1377},
{"f_1371utils.scm",(void*)f_1371},
{"f_1350utils.scm",(void*)f_1350},
{"f_1362utils.scm",(void*)f_1362},
{"f_1356utils.scm",(void*)f_1356},
{"f_1335utils.scm",(void*)f_1335},
{"f_1347utils.scm",(void*)f_1347},
{"f_1341utils.scm",(void*)f_1341},
{"f_1227utils.scm",(void*)f_1227},
{"f_1243utils.scm",(void*)f_1243},
{"f_1272utils.scm",(void*)f_1272},
{"f_1297utils.scm",(void*)f_1297},
{"f_1282utils.scm",(void*)f_1282},
{"f_1253utils.scm",(void*)f_1253},
{"f_1213utils.scm",(void*)f_1213},
{"f_1133utils.scm",(void*)f_1133},
{"f_1162utils.scm",(void*)f_1162},
{"f_1157utils.scm",(void*)f_1157},
{"f_1135utils.scm",(void*)f_1135},
{"f_1143utils.scm",(void*)f_1143},
{"f_1149utils.scm",(void*)f_1149},
{"f_1146utils.scm",(void*)f_1146},
{"f_1072utils.scm",(void*)f_1072},
{"f_1088utils.scm",(void*)f_1088},
{"f_1083utils.scm",(void*)f_1083},
{"f_1074utils.scm",(void*)f_1074},
{"f_1082utils.scm",(void*)f_1082},
{"f_991utils.scm",(void*)f_991},
{"f_1020utils.scm",(void*)f_1020},
{"f_1027utils.scm",(void*)f_1027},
{"f_960utils.scm",(void*)f_960},
{"f_899utils.scm",(void*)f_899},
{"f_908utils.scm",(void*)f_908},
{"f_938utils.scm",(void*)f_938},
{"f_946utils.scm",(void*)f_946},
{"f_845utils.scm",(void*)f_845},
{"f_861utils.scm",(void*)f_861},
{"f_832utils.scm",(void*)f_832},
{"f_843utils.scm",(void*)f_843},
{"f_808utils.scm",(void*)f_808},
{"f_815utils.scm",(void*)f_815},
{"f_821utils.scm",(void*)f_821},
{"f_790utils.scm",(void*)f_790},
{"f_794utils.scm",(void*)f_794},
{"f_797utils.scm",(void*)f_797},
{"f_698utils.scm",(void*)f_698},
{"f_702utils.scm",(void*)f_702},
{"f_779utils.scm",(void*)f_779},
{"f_788utils.scm",(void*)f_788},
{"f_705utils.scm",(void*)f_705},
{"f_710utils.scm",(void*)f_710},
{"f_714utils.scm",(void*)f_714},
{"f_777utils.scm",(void*)f_777},
{"f_756utils.scm",(void*)f_756},
{"f_766utils.scm",(void*)f_766},
{"f_717utils.scm",(void*)f_717},
{"f_720utils.scm",(void*)f_720},
{"f_723utils.scm",(void*)f_723},
{"f_726utils.scm",(void*)f_726},
{"f_735utils.scm",(void*)f_735},
{"f_646utils.scm",(void*)f_646},
{"f_729utils.scm",(void*)f_729},
{"f_692utils.scm",(void*)f_692},
{"f_673utils.scm",(void*)f_673},
{"f_690utils.scm",(void*)f_690},
{"f_683utils.scm",(void*)f_683},
{"f_570utils.scm",(void*)f_570},
{"f_574utils.scm",(void*)f_574},
{"f_592utils.scm",(void*)f_592},
{"f_583utils.scm",(void*)f_583},
{"f_606utils.scm",(void*)f_606},
{"f_532utils.scm",(void*)f_532},
{"f_539utils.scm",(void*)f_539},
{"f_549utils.scm",(void*)f_549},
{"f_505utils.scm",(void*)f_505},
{"f_510utils.scm",(void*)f_510},
{"f_515utils.scm",(void*)f_515},
{"f_530utils.scm",(void*)f_530},
{"f_522utils.scm",(void*)f_522},
{"f_513utils.scm",(void*)f_513},
{"f_479utils.scm",(void*)f_479},
{"f_484utils.scm",(void*)f_484},
{"f_489utils.scm",(void*)f_489},
{"f_503utils.scm",(void*)f_503},
{"f_496utils.scm",(void*)f_496},
{"f_452utils.scm",(void*)f_452},
{"f_477utils.scm",(void*)f_477},
{"f_456utils.scm",(void*)f_456},
{"f_470utils.scm",(void*)f_470},
{"f_466utils.scm",(void*)f_466},
{"f_459utils.scm",(void*)f_459},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
