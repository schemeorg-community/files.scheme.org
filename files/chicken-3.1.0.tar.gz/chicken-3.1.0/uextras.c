/* Generated from extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:48
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: extras.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file uextras.c -extend private-namespace.scm
   unit: extras
*/

#include "chicken.h"

#define C_hashptr(x)   C_fix(x & C_MOST_POSITIVE_FIXNUM)
#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[355];
static double C_possibly_force_alignment;


/* from srand */
static C_word C_fcall stub232(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub232(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned int t0=(unsigned int )C_num_to_unsigned_int(C_a0);
srand(t0);
return C_r;}

C_noret_decl(C_extras_toplevel)
C_externexport void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10916)
static void C_ccall f_10916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10916)
static void C_ccall f_10916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10926)
static void C_ccall f_10926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10933)
static void C_ccall f_10933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10636)
static void C_ccall f_10636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10865)
static void C_ccall f_10865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10875)
static void C_ccall f_10875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10892)
static C_word C_fcall f_10892(C_word t0);
C_noret_decl(f_10878)
static void C_fcall f_10878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10836)
static void C_ccall f_10836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10782)
static void C_ccall f_10782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10801)
static void C_fcall f_10801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10811)
static void C_ccall f_10811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10793)
static void C_ccall f_10793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10773)
static void C_ccall f_10773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10737)
static void C_ccall f_10737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10747)
static void C_ccall f_10747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10715)
static void C_fcall f_10715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10684)
static void C_ccall f_10684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10694)
static void C_ccall f_10694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10663)
static void C_ccall f_10663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10673)
static void C_ccall f_10673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10650)
static void C_ccall f_10650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10644)
static void C_ccall f_10644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10638)
static void C_ccall f_10638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10613)
static void C_ccall f_10613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10620)
static void C_ccall f_10620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10625)
static void C_ccall f_10625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10601)
static void C_ccall f_10601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10589)
static void C_ccall f_10589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10596)
static void C_ccall f_10596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10584)
static void C_ccall f_10584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10511)
static void C_ccall f_10511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10523)
static void C_fcall f_10523(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10539)
static void C_fcall f_10539(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10567)
static void C_ccall f_10567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10462)
static void C_ccall f_10462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10474)
static void C_fcall f_10474(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10493)
static void C_ccall f_10493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10484)
static void C_ccall f_10484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10397)
static void C_ccall f_10397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10412)
static void C_fcall f_10412(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10428)
static void C_fcall f_10428(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10347)
static void C_fcall f_10347(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10363)
static void C_fcall f_10363(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10304)
static void C_ccall f_10304(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10304)
static void C_ccall f_10304r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10311)
static void C_ccall f_10311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10316)
static void C_ccall f_10316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10326)
static void C_ccall f_10326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10246)
static void C_fcall f_10246(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10262)
static void C_fcall f_10262(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10215)
static void C_ccall f_10215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10229)
static void C_ccall f_10229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10203)
static void C_ccall f_10203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10136)
static void C_ccall f_10136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10148)
static void C_fcall f_10148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10171)
static void C_fcall f_10171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10197)
static void C_ccall f_10197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10158)
static void C_ccall f_10158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10040)
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10047)
static void C_ccall f_10047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10061)
static void C_fcall f_10061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10087)
static void C_fcall f_10087(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10106)
static void C_ccall f_10106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10074)
static void C_ccall f_10074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9909)
static void C_ccall f_9909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9925)
static void C_ccall f_9925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9992)
static void C_fcall f_9992(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10011)
static void C_ccall f_10011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9945)
static C_word C_fcall f_9945(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9888)
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9907)
static void C_ccall f_9907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9876)
static void C_ccall f_9876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9885)
static void C_ccall f_9885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9776)
static void C_ccall f_9776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9833)
static void C_fcall f_9833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9852)
static void C_ccall f_9852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_fcall f_9791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9758)
static void C_ccall f_9758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9754)
static void C_ccall f_9754(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9734)
static void C_ccall f_9734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9689)
static void C_fcall f_9689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9672)
static void C_fcall f_9672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9684)
static void C_ccall f_9684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9658)
static void C_fcall f_9658(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9668)
static void C_ccall f_9668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9441)
static void C_fcall f_9441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9646)
static void C_ccall f_9646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9638)
static void C_ccall f_9638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9463)
static void C_fcall f_9463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9564)
static void C_fcall f_9564(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9601)
static void C_ccall f_9601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9604)
static void C_ccall f_9604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9592)
static void C_ccall f_9592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9574)
static void C_ccall f_9574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9501)
static void C_fcall f_9501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9541)
static void C_ccall f_9541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9529)
static void C_ccall f_9529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9511)
static void C_ccall f_9511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9479)
static void C_ccall f_9479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9469)
static void C_ccall f_9469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9353)
static void C_fcall f_9353(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9376)
static void C_fcall f_9376(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9392)
static void C_ccall f_9392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9332)
static void C_ccall f_9332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_fcall f_9235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9297)
static void C_fcall f_9297(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9318)
static void C_ccall f_9318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9291)
static void C_ccall f_9291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9205)
static void C_ccall f_9205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9175)
static void C_ccall f_9175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9157)
static void C_ccall f_9157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9139)
static void C_ccall f_9139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9130)
static void C_ccall f_9130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9124)
static void C_ccall f_9124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9114)
static void C_ccall f_9114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9117)
static void C_ccall f_9117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8839)
static void C_fcall f_8839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9097)
static void C_ccall f_9097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8842)
static void C_fcall f_8842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_ccall f_9062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_ccall f_9068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8845)
static void C_fcall f_8845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8880)
static void C_fcall f_8880(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8901)
static void C_ccall f_8901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8907)
static void C_ccall f_8907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9002)
static void C_ccall f_9002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8977)
static void C_ccall f_8977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8964)
static void C_ccall f_8964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8946)
static void C_ccall f_8946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8933)
static void C_ccall f_8933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8891)
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8848)
static void C_ccall f_8848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8851)
static void C_ccall f_8851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8871)
static void C_ccall f_8871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_fcall f_8858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8763)
static C_word C_fcall f_8763(C_word t0);
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t11) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8713)
static C_word C_fcall f_8713(C_word t0,C_word t1);
C_noret_decl(f_8665)
static void C_ccall f_8665(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8665)
static void C_ccall f_8665r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8624)
static void C_ccall f_8624(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8624)
static void C_ccall f_8624r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8600)
static void C_ccall f_8600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8310)
static void C_ccall f_8310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8409)
static void C_fcall f_8409(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8560)
static void C_ccall f_8560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8539)
static void C_ccall f_8539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_ccall f_8484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8378)
static void C_fcall f_8378(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8313)
static void C_fcall f_8313(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8330)
static void C_fcall f_8330(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8258)
static void C_ccall f_8258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8048)
static void C_ccall f_8048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8015)
static void C_ccall f_8015(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8015)
static void C_ccall f_8015r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8022)
static void C_ccall f_8022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7970)
static void C_ccall f_7970(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7970)
static void C_ccall f_7970r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7947)
static void C_ccall f_7947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_fcall f_7878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7772)
static void C_fcall f_7772(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_fcall f_7786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7741)
static void C_ccall f_7741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7766)
static void C_ccall f_7766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7759)
static void C_ccall f_7759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7755)
static void C_ccall f_7755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_fcall f_7707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7611)
static void C_fcall f_7611(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7652)
static void C_fcall f_7652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7630)
static void C_ccall f_7630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7581)
static void C_ccall f_7581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_fcall f_7479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7486)
static void C_ccall f_7486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7411)
static void C_fcall f_7411(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7418)
static void C_ccall f_7418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7466)
static void C_ccall f_7466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7438)
static void C_ccall f_7438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7343)
static void C_fcall f_7343(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7295)
static void C_fcall f_7295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7305)
static void C_ccall f_7305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7256)
static void C_ccall f_7256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7231)
static void C_ccall f_7231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7211)
static void C_ccall f_7211(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7211)
static void C_ccall f_7211r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7194)
static void C_ccall f_7194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6919)
static void C_fcall f_6919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6980)
static void C_fcall f_6980(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static C_word C_fcall f_7158(C_word t0,C_word t1);
C_noret_decl(f_7113)
static void C_ccall f_7113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7095)
static void C_ccall f_7095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6935)
static void C_fcall f_6935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static C_word C_fcall f_6928(C_word t0);
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6813)
static void C_fcall f_6813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6833)
static void C_ccall f_6833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6688)
static void C_fcall f_6688(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6721)
static void C_fcall f_6721(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6760)
static void C_fcall f_6760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_fcall f_6706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_fcall f_6531(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_fcall f_6477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6488)
static C_word C_fcall f_6488(C_word t0,C_word t1);
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6384)
static void C_fcall f_6384(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static C_word C_fcall f_6399(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6272)
static void C_fcall f_6272(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6299)
static void C_fcall f_6299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_fcall f_6252(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_fcall f_6259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6171)
static void C_fcall f_6171(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_fcall f_6166(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6161)
static void C_fcall f_6161(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6156)
static void C_fcall f_6156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6127)
static void C_fcall f_6127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6057)
static void C_fcall f_6057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6047)
static void C_fcall f_6047(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6042)
static void C_fcall f_6042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6013)
static void C_fcall f_6013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5834)
static void C_fcall f_5834(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5855)
static void C_fcall f_5855(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5754)
static void C_ccall f_5754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5757)
static void C_ccall f_5757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5672)
static void C_fcall f_5672(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5697)
static void C_fcall f_5697(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5578)
static void C_fcall f_5578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5538)
static void C_fcall f_5538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5347)
static void C_fcall f_5347(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_fcall f_5350(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_fcall f_5391(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_fcall f_5432(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5270)
static void C_fcall f_5270(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5276)
static void C_fcall f_5276(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_fcall f_5261(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5233)
static void C_fcall f_5233(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5081)
static void C_fcall f_5081(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_fcall f_5016(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_fcall f_4510(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_fcall f_4749(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4756)
static void C_fcall f_4756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_fcall f_4513(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_fcall f_4540(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_fcall f_4560(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_fcall f_4491(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static C_word C_fcall f_4458(C_word t0);
C_noret_decl(f_4452)
static C_word C_fcall f_4452(C_word t0);
C_noret_decl(f_4400)
static void C_fcall f_4400(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_fcall f_4432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4273)
static void C_fcall f_4273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_fcall f_4268(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4263)
static void C_fcall f_4263(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4192)
static void C_fcall f_4192(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3881)
static void C_fcall f_3881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_fcall f_3876(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3845)
static void C_fcall f_3845(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_fcall f_3862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_fcall f_3793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3733)
static void C_fcall f_3733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_fcall f_3728(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_fcall f_3723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_fcall f_3681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3603)
static void C_fcall f_3603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_fcall f_3598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3556)
static void C_fcall f_3556(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_fcall f_3566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_fcall f_3474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_fcall f_3482(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3396)
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3240)
static void C_fcall f_3240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_fcall f_3327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3192)
static void C_fcall f_3192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3097)
static void C_fcall f_3097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3040)
static void C_fcall f_3040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_fcall f_3035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2966)
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3001)
static void C_fcall f_3001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_fcall f_2970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2923)
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_fcall f_2885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2766)
static void C_fcall f_2766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2710)
static void C_fcall f_2710(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_fcall f_2628(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2649)
static void C_fcall f_2649(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2578)
static void C_fcall f_2578(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2549)
static void C_fcall f_2549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2513)
static void C_fcall f_2513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2491)
static C_word C_fcall f_2491(C_word t0,C_word t1);
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2395)
static void C_fcall f_2395(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2329)
static void C_fcall f_2329(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2294)
static void C_fcall f_2294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2174)
static void C_fcall f_2174(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2141)
static void C_fcall f_2141(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2062)
static void C_fcall f_2062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2052)
static void C_fcall f_2052(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1992)
static void C_fcall f_1992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_fcall f_2005(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10878)
static void C_fcall trf_10878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10878(t0,t1);}

C_noret_decl(trf_10801)
static void C_fcall trf_10801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10801(t0,t1,t2);}

C_noret_decl(trf_10715)
static void C_fcall trf_10715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10715(t0,t1);}

C_noret_decl(trf_10523)
static void C_fcall trf_10523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10523(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10523(t0,t1,t2,t3);}

C_noret_decl(trf_10539)
static void C_fcall trf_10539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10539(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10539(t0,t1,t2,t3);}

C_noret_decl(trf_10474)
static void C_fcall trf_10474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10474(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10474(t0,t1,t2);}

C_noret_decl(trf_10412)
static void C_fcall trf_10412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10412(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10412(t0,t1,t2,t3);}

C_noret_decl(trf_10428)
static void C_fcall trf_10428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10428(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10428(t0,t1,t2,t3);}

C_noret_decl(trf_10347)
static void C_fcall trf_10347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10347(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10347(t0,t1,t2,t3);}

C_noret_decl(trf_10363)
static void C_fcall trf_10363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10363(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10363(t0,t1,t2,t3);}

C_noret_decl(trf_10246)
static void C_fcall trf_10246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10246(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10246(t0,t1,t2,t3);}

C_noret_decl(trf_10262)
static void C_fcall trf_10262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10262(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10262(t0,t1,t2,t3);}

C_noret_decl(trf_10148)
static void C_fcall trf_10148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10148(t0,t1,t2);}

C_noret_decl(trf_10171)
static void C_fcall trf_10171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10171(t0,t1,t2);}

C_noret_decl(trf_10061)
static void C_fcall trf_10061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10061(t0,t1,t2);}

C_noret_decl(trf_10087)
static void C_fcall trf_10087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10087(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10087(t0,t1,t2,t3);}

C_noret_decl(trf_9992)
static void C_fcall trf_9992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9992(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9992(t0,t1,t2,t3);}

C_noret_decl(trf_9833)
static void C_fcall trf_9833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9833(t0,t1,t2);}

C_noret_decl(trf_9791)
static void C_fcall trf_9791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9791(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9791(t0,t1,t2);}

C_noret_decl(trf_9689)
static void C_fcall trf_9689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9689(t0,t1);}

C_noret_decl(trf_9672)
static void C_fcall trf_9672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9672(t0,t1,t2);}

C_noret_decl(trf_9658)
static void C_fcall trf_9658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9658(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9658(t0,t1,t2,t3);}

C_noret_decl(trf_9441)
static void C_fcall trf_9441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9441(t0,t1);}

C_noret_decl(trf_9463)
static void C_fcall trf_9463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9463(t0,t1);}

C_noret_decl(trf_9564)
static void C_fcall trf_9564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9564(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9564(t0,t1,t2);}

C_noret_decl(trf_9501)
static void C_fcall trf_9501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9501(t0,t1,t2);}

C_noret_decl(trf_9353)
static void C_fcall trf_9353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9353(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9353(t0,t1,t2);}

C_noret_decl(trf_9376)
static void C_fcall trf_9376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9376(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9376(t0,t1,t2);}

C_noret_decl(trf_9235)
static void C_fcall trf_9235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9235(t0,t1,t2);}

C_noret_decl(trf_9297)
static void C_fcall trf_9297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9297(t0,t1,t2);}

C_noret_decl(trf_8839)
static void C_fcall trf_8839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8839(t0,t1);}

C_noret_decl(trf_8842)
static void C_fcall trf_8842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8842(t0,t1);}

C_noret_decl(trf_8845)
static void C_fcall trf_8845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8845(t0,t1);}

C_noret_decl(trf_8880)
static void C_fcall trf_8880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8880(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8880(t0,t1,t2);}

C_noret_decl(trf_8891)
static void C_fcall trf_8891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8891(t0,t1,t2);}

C_noret_decl(trf_8858)
static void C_fcall trf_8858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8858(t0,t1);}

C_noret_decl(trf_8409)
static void C_fcall trf_8409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8409(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8409(t0,t1,t2,t3);}

C_noret_decl(trf_8378)
static void C_fcall trf_8378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8378(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8378(t0,t1,t2,t3);}

C_noret_decl(trf_8313)
static void C_fcall trf_8313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8313(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8313(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8330)
static void C_fcall trf_8330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8330(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8330(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7878)
static void C_fcall trf_7878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7878(t0,t1);}

C_noret_decl(trf_7772)
static void C_fcall trf_7772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7772(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7772(t0,t1);}

C_noret_decl(trf_7786)
static void C_fcall trf_7786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7786(t0,t1,t2,t3);}

C_noret_decl(trf_7707)
static void C_fcall trf_7707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7707(t0,t1,t2,t3);}

C_noret_decl(trf_7611)
static void C_fcall trf_7611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7611(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7611(t0,t1,t2);}

C_noret_decl(trf_7652)
static void C_fcall trf_7652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7652(t0,t1);}

C_noret_decl(trf_7479)
static void C_fcall trf_7479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7479(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7479(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7411)
static void C_fcall trf_7411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7411(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7411(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7343)
static void C_fcall trf_7343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7343(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7343(t0,t1,t2,t3);}

C_noret_decl(trf_7295)
static void C_fcall trf_7295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7295(t0,t1,t2);}

C_noret_decl(trf_6919)
static void C_fcall trf_6919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6919(t0,t1,t2,t3);}

C_noret_decl(trf_6980)
static void C_fcall trf_6980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6980(t0,t1);}

C_noret_decl(trf_6935)
static void C_fcall trf_6935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6935(t0,t1);}

C_noret_decl(trf_6813)
static void C_fcall trf_6813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6813(t0,t1,t2,t3);}

C_noret_decl(trf_6688)
static void C_fcall trf_6688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6688(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6688(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6721)
static void C_fcall trf_6721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6721(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6721(t0,t1,t2);}

C_noret_decl(trf_6760)
static void C_fcall trf_6760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6760(t0,t1);}

C_noret_decl(trf_6706)
static void C_fcall trf_6706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6706(t0,t1);}

C_noret_decl(trf_6531)
static void C_fcall trf_6531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6531(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6531(t0,t1,t2,t3);}

C_noret_decl(trf_6477)
static void C_fcall trf_6477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6477(t0,t1);}

C_noret_decl(trf_6384)
static void C_fcall trf_6384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6384(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6384(t0,t1,t2,t3);}

C_noret_decl(trf_6272)
static void C_fcall trf_6272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6272(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6272(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6299)
static void C_fcall trf_6299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6299(t0,t1,t2);}

C_noret_decl(trf_6252)
static void C_fcall trf_6252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6252(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6252(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6259)
static void C_fcall trf_6259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6259(t0,t1);}

C_noret_decl(trf_6171)
static void C_fcall trf_6171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6171(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6171(t0,t1);}

C_noret_decl(trf_6166)
static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6166(t0,t1,t2);}

C_noret_decl(trf_6161)
static void C_fcall trf_6161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6161(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6161(t0,t1,t2,t3);}

C_noret_decl(trf_6156)
static void C_fcall trf_6156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6156(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6156(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6127)
static void C_fcall trf_6127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6127(t0,t1);}

C_noret_decl(trf_6057)
static void C_fcall trf_6057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6057(t0,t1);}

C_noret_decl(trf_6052)
static void C_fcall trf_6052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6052(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6052(t0,t1,t2);}

C_noret_decl(trf_6047)
static void C_fcall trf_6047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6047(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6047(t0,t1,t2,t3);}

C_noret_decl(trf_6042)
static void C_fcall trf_6042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6042(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6042(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6013)
static void C_fcall trf_6013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6013(t0,t1);}

C_noret_decl(trf_5834)
static void C_fcall trf_5834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5834(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5834(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5855)
static void C_fcall trf_5855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5855(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5855(t0,t1,t2,t3);}

C_noret_decl(trf_5672)
static void C_fcall trf_5672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5672(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5672(t0,t1,t2,t3);}

C_noret_decl(trf_5697)
static void C_fcall trf_5697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5697(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5697(t0,t1,t2,t3);}

C_noret_decl(trf_5013)
static void C_fcall trf_5013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5013(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5013(t0,t1,t2,t3);}

C_noret_decl(trf_5568)
static void C_fcall trf_5568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5568(t0,t1,t2);}

C_noret_decl(trf_5578)
static void C_fcall trf_5578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5578(t0,t1);}

C_noret_decl(trf_5538)
static void C_fcall trf_5538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5538(t0,t1);}

C_noret_decl(trf_5347)
static void C_fcall trf_5347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5347(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_5347(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_5350)
static void C_fcall trf_5350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5350(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5350(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5391)
static void C_fcall trf_5391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5391(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5391(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5432)
static void C_fcall trf_5432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5432(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5432(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5270)
static void C_fcall trf_5270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5270(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5270(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5276)
static void C_fcall trf_5276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5276(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5276(t0,t1,t2,t3);}

C_noret_decl(trf_5261)
static void C_fcall trf_5261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5261(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5261(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5233)
static void C_fcall trf_5233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5233(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5233(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5081)
static void C_fcall trf_5081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5081(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5081(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5049)
static void C_fcall trf_5049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5049(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5049(t0,t1,t2,t3);}

C_noret_decl(trf_5016)
static void C_fcall trf_5016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5016(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5016(t0,t1,t2,t3);}

C_noret_decl(trf_4510)
static void C_fcall trf_4510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4510(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4510(t0,t1,t2,t3);}

C_noret_decl(trf_4749)
static void C_fcall trf_4749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4749(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4749(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4756)
static void C_fcall trf_4756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4756(t0,t1);}

C_noret_decl(trf_4513)
static void C_fcall trf_4513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4513(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4513(t0,t1,t2,t3);}

C_noret_decl(trf_4540)
static void C_fcall trf_4540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4540(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4540(t0,t1,t2,t3);}

C_noret_decl(trf_4560)
static void C_fcall trf_4560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4560(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4560(t0,t1,t2,t3);}

C_noret_decl(trf_4491)
static void C_fcall trf_4491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4491(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4491(t0,t1,t2,t3);}

C_noret_decl(trf_4400)
static void C_fcall trf_4400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4400(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4400(t0,t1);}

C_noret_decl(trf_4432)
static void C_fcall trf_4432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4432(t0,t1);}

C_noret_decl(trf_4273)
static void C_fcall trf_4273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4273(t0,t1);}

C_noret_decl(trf_4268)
static void C_fcall trf_4268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4268(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4268(t0,t1,t2);}

C_noret_decl(trf_4263)
static void C_fcall trf_4263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4263(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4263(t0,t1,t2,t3);}

C_noret_decl(trf_4192)
static void C_fcall trf_4192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4192(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4192(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3881)
static void C_fcall trf_3881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3881(t0,t1);}

C_noret_decl(trf_3876)
static void C_fcall trf_3876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3876(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3876(t0,t1,t2);}

C_noret_decl(trf_3845)
static void C_fcall trf_3845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3845(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3845(t0,t1,t2,t3);}

C_noret_decl(trf_3862)
static void C_fcall trf_3862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3862(t0,t1);}

C_noret_decl(trf_3793)
static void C_fcall trf_3793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3793(t0,t1);}

C_noret_decl(trf_3733)
static void C_fcall trf_3733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3733(t0,t1);}

C_noret_decl(trf_3728)
static void C_fcall trf_3728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3728(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3728(t0,t1,t2);}

C_noret_decl(trf_3723)
static void C_fcall trf_3723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3723(t0,t1,t2);}

C_noret_decl(trf_3681)
static void C_fcall trf_3681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3681(t0,t1,t2);}

C_noret_decl(trf_3603)
static void C_fcall trf_3603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3603(t0,t1);}

C_noret_decl(trf_3598)
static void C_fcall trf_3598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3598(t0,t1,t2);}

C_noret_decl(trf_3556)
static void C_fcall trf_3556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3556(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3556(t0,t1,t2,t3);}

C_noret_decl(trf_3566)
static void C_fcall trf_3566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3566(t0,t1);}

C_noret_decl(trf_3474)
static void C_fcall trf_3474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3474(t0,t1);}

C_noret_decl(trf_3482)
static void C_fcall trf_3482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3482(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3482(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3396)
static void C_fcall trf_3396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3396(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3396(t0,t1,t2,t3);}

C_noret_decl(trf_3240)
static void C_fcall trf_3240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3240(t0,t1);}

C_noret_decl(trf_3263)
static void C_fcall trf_3263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3263(t0,t1,t2);}

C_noret_decl(trf_3327)
static void C_fcall trf_3327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3327(t0,t1);}

C_noret_decl(trf_3192)
static void C_fcall trf_3192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3192(t0,t1);}

C_noret_decl(trf_3097)
static void C_fcall trf_3097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3097(t0,t1,t2);}

C_noret_decl(trf_3040)
static void C_fcall trf_3040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3040(t0,t1);}

C_noret_decl(trf_3035)
static void C_fcall trf_3035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3035(t0,t1,t2);}

C_noret_decl(trf_2966)
static void C_fcall trf_2966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2966(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2966(t0,t1,t2,t3);}

C_noret_decl(trf_3001)
static void C_fcall trf_3001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3001(t0,t1,t2);}

C_noret_decl(trf_2970)
static void C_fcall trf_2970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2970(t0,t1);}

C_noret_decl(trf_2923)
static void C_fcall trf_2923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2923(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2923(t0,t1,t2);}

C_noret_decl(trf_2885)
static void C_fcall trf_2885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2885(t0,t1);}

C_noret_decl(trf_2766)
static void C_fcall trf_2766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2766(t0,t1,t2,t3);}

C_noret_decl(trf_2710)
static void C_fcall trf_2710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2710(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2710(t0,t1,t2);}

C_noret_decl(trf_2628)
static void C_fcall trf_2628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2628(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2628(t0,t1,t2,t3);}

C_noret_decl(trf_2649)
static void C_fcall trf_2649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2649(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2649(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2578)
static void C_fcall trf_2578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2578(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2578(t0,t1,t2,t3);}

C_noret_decl(trf_2549)
static void C_fcall trf_2549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2549(t0,t1,t2);}

C_noret_decl(trf_2513)
static void C_fcall trf_2513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2513(t0,t1,t2);}

C_noret_decl(trf_2395)
static void C_fcall trf_2395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2395(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2395(t0,t1,t2);}

C_noret_decl(trf_2329)
static void C_fcall trf_2329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2329(t0,t1,t2);}

C_noret_decl(trf_2294)
static void C_fcall trf_2294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2294(t0,t1,t2);}

C_noret_decl(trf_2174)
static void C_fcall trf_2174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2174(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2174(t0,t1,t2);}

C_noret_decl(trf_2141)
static void C_fcall trf_2141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2141(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2141(t0,t1,t2);}

C_noret_decl(trf_2062)
static void C_fcall trf_2062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2062(t0,t1);}

C_noret_decl(trf_2057)
static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2057(t0,t1,t2);}

C_noret_decl(trf_2052)
static void C_fcall trf_2052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2052(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2052(t0,t1,t2,t3);}

C_noret_decl(trf_1992)
static void C_fcall trf_1992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1992(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1992(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2005)
static void C_fcall trf_2005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2005(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2005(t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr10rv)
static void C_fcall tr10rv(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10rv(C_proc10 k){
int n;
C_word *a,t10;
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
n=C_rest_count(0);
a=C_alloc(n+1);
t10=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2833)){
C_save(t1);
C_rereclaim2(2833*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,355);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],26,"\006extrasunbound-value-thunk");
lf[4]=C_h_intern(&lf[4],28,"\003sysarbitrary-unbound-symbol");
lf[5]=C_h_intern(&lf[5],4,"read");
lf[6]=C_h_intern(&lf[6],7,"reverse");
lf[7]=C_h_intern(&lf[7],20,"call-with-input-file");
lf[8]=C_h_intern(&lf[8],9,"read-file");
lf[9]=C_h_intern(&lf[9],5,"port\077");
lf[10]=C_h_intern(&lf[10],18,"\003sysstandard-input");
lf[11]=C_h_intern(&lf[11],8,"identity");
lf[12]=C_h_intern(&lf[12],7,"project");
lf[13]=C_h_intern(&lf[13],7,"conjoin");
lf[14]=C_h_intern(&lf[14],7,"disjoin");
lf[15]=C_h_intern(&lf[15],10,"constantly");
lf[16]=C_h_intern(&lf[16],4,"flip");
lf[17]=C_h_intern(&lf[17],10,"complement");
lf[18]=C_h_intern(&lf[18],7,"compose");
lf[19]=C_h_intern(&lf[19],6,"values");
lf[20]=C_h_intern(&lf[20],1,"o");
lf[21]=C_h_intern(&lf[21],7,"list-of");
lf[22]=C_h_intern(&lf[22],4,"noop");
lf[23]=C_h_intern(&lf[23],4,"each");
lf[24]=C_h_intern(&lf[24],4,"any\077");
lf[25]=C_h_intern(&lf[25],5,"none\077");
lf[26]=C_h_intern(&lf[26],7,"always\077");
lf[27]=C_h_intern(&lf[27],6,"never\077");
lf[28]=C_h_intern(&lf[28],12,"left-section");
lf[29]=C_h_intern(&lf[29],10,"\003sysappend");
lf[30]=C_h_intern(&lf[30],17,"\003syscheck-closure");
lf[31]=C_h_intern(&lf[31],13,"right-section");
lf[32]=C_h_intern(&lf[32],5,"atom\077");
lf[33]=C_h_intern(&lf[33],5,"tail\077");
lf[34]=C_h_intern(&lf[34],11,"intersperse");
lf[35]=C_h_intern(&lf[35],7,"butlast");
lf[36]=C_h_intern(&lf[36],7,"flatten");
lf[37]=C_h_intern(&lf[37],4,"chop");
lf[38]=C_h_intern(&lf[38],9,"\003syserror");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid numeric argument");
lf[40]=C_h_intern(&lf[40],4,"join");
lf[41]=C_h_intern(&lf[41],27,"\003sysnot-a-proper-list-error");
lf[42]=C_h_intern(&lf[42],8,"compress");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000%bad argument type - not a proper list");
lf[44]=C_h_intern(&lf[44],15,"\003syssignal-hook");
lf[45]=C_h_intern(&lf[45],11,"\000type-error");
lf[46]=C_h_intern(&lf[46],7,"shuffle");
lf[47]=C_h_intern(&lf[47],7,"\003sysmap");
lf[48]=C_h_intern(&lf[48],3,"cdr");
lf[49]=C_h_intern(&lf[49],5,"sort!");
lf[50]=C_h_intern(&lf[50],6,"random");
lf[51]=C_h_intern(&lf[51],13,"alist-update!");
lf[52]=C_h_intern(&lf[52],4,"eqv\077");
lf[53]=C_h_intern(&lf[53],3,"eq\077");
lf[54]=C_h_intern(&lf[54],4,"assq");
lf[55]=C_h_intern(&lf[55],4,"assv");
lf[56]=C_h_intern(&lf[56],6,"equal\077");
lf[57]=C_h_intern(&lf[57],5,"assoc");
lf[58]=C_h_intern(&lf[58],9,"alist-ref");
lf[59]=C_h_intern(&lf[59],6,"rassoc");
lf[60]=C_h_intern(&lf[60],11,"random-seed");
lf[61]=C_h_intern(&lf[61],17,"\003syscheck-integer");
lf[62]=C_h_intern(&lf[62],15,"current-seconds");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[64]=C_h_intern(&lf[64],9,"randomize");
lf[65]=C_h_intern(&lf[65],11,"make-string");
lf[66]=C_h_intern(&lf[66],9,"read-line");
lf[67]=C_h_intern(&lf[67],13,"\003syssubstring");
lf[68]=C_h_intern(&lf[68],15,"\003sysread-char-0");
lf[69]=C_h_intern(&lf[69],9,"peek-char");
lf[70]=C_h_intern(&lf[70],17,"\003sysstring-append");
lf[71]=C_h_intern(&lf[71],15,"\003sysmake-string");
lf[72]=C_h_intern(&lf[72],14,"\003syscheck-port");
lf[73]=C_h_intern(&lf[73],10,"read-lines");
lf[74]=C_h_intern(&lf[74],16,"\003sysread-string!");
lf[75]=C_h_intern(&lf[75],12,"read-string!");
lf[76]=C_h_intern(&lf[76],18,"open-output-string");
lf[77]=C_h_intern(&lf[77],17,"get-output-string");
lf[78]=C_h_intern(&lf[78],20,"\003sysread-string/port");
lf[79]=C_h_intern(&lf[79],11,"read-string");
lf[80]=C_h_intern(&lf[80],19,"\003syswrite-char/port");
lf[81]=C_h_intern(&lf[81],10,"read-token");
lf[82]=C_h_intern(&lf[82],16,"\003syswrite-char-0");
lf[83]=C_h_intern(&lf[83],15,"\003syspeek-char-0");
lf[84]=C_h_intern(&lf[84],7,"display");
lf[85]=C_h_intern(&lf[85],12,"write-string");
lf[86]=C_h_intern(&lf[86],19,"\003sysstandard-output");
lf[87]=C_h_intern(&lf[87],7,"newline");
lf[88]=C_h_intern(&lf[88],10,"write-line");
lf[89]=C_h_intern(&lf[89],9,"read-byte");
lf[90]=C_h_intern(&lf[90],10,"write-byte");
lf[91]=C_h_intern(&lf[91],20,"with-input-from-port");
lf[92]=C_h_intern(&lf[92],16,"\003sysdynamic-wind");
lf[93]=C_h_intern(&lf[93],19,"with-output-to-port");
lf[94]=C_h_intern(&lf[94],21,"with-output-from-port");
lf[95]=C_h_intern(&lf[95],25,"with-error-output-to-port");
lf[96]=C_h_intern(&lf[96],18,"\003sysstandard-error");
lf[97]=C_h_intern(&lf[97],27,"with-error-output-from-port");
lf[98]=C_h_intern(&lf[98],17,"open-input-string");
lf[99]=C_h_intern(&lf[99],22,"call-with-input-string");
lf[100]=C_h_intern(&lf[100],23,"call-with-output-string");
lf[101]=C_h_intern(&lf[101],22,"with-input-from-string");
lf[102]=C_h_intern(&lf[102],21,"with-output-to-string");
lf[103]=C_h_intern(&lf[103],15,"make-input-port");
lf[104]=C_h_intern(&lf[104],13,"\003sysmake-port");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\010(custom)");
lf[106]=C_h_intern(&lf[106],6,"custom");
lf[107]=C_h_intern(&lf[107],6,"string");
lf[108]=C_h_intern(&lf[108],16,"make-output-port");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\010(custom)");
lf[110]=C_h_intern(&lf[110],20,"\006extrasgeneric-write");
lf[111]=C_h_intern(&lf[111],5,"quote");
lf[112]=C_h_intern(&lf[112],10,"quasiquote");
lf[113]=C_h_intern(&lf[113],7,"unquote");
lf[114]=C_h_intern(&lf[114],16,"unquote-splicing");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001`");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002,@");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\003 . ");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\002()");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[127]=C_h_intern(&lf[127],12,"vector->list");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002#t");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[130]=C_h_intern(&lf[130],18,"\003sysnumber->string");
lf[131]=C_h_intern(&lf[131],9,"\003sysprint");
lf[132]=C_h_intern(&lf[132],21,"\003sysprocedure->string");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001x");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001u");
lf[139]=C_h_intern(&lf[139],9,"char-name");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\002#\134");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\016#<unspecified>");
lf[143]=C_h_intern(&lf[143],19,"\003syspointer->string");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\020#<unbound value>");
lf[145]=C_h_intern(&lf[145],19,"\003sysuser-print-hook");
lf[146]=C_h_intern(&lf[146],13,"string-append");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\007#<port ");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\025#<static blob of size");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\017#<blob of size ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002#>");
lf[153]=C_h_intern(&lf[153],23,"\003syslambda-info->string");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\016#<lambda info ");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\025#<unprintable object>");
lf[156]=C_h_intern(&lf[156],11,"\003sysnumber\077");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[159]=C_h_intern(&lf[159],28,"\006extrasreverse-string-append");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[161]=C_h_intern(&lf[161],3,"max");
lf[162]=C_h_intern(&lf[162],28,"\003syssymbol->qualified-string");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[170]=C_h_intern(&lf[170],6,"lambda");
lf[171]=C_h_intern(&lf[171],2,"if");
lf[172]=C_h_intern(&lf[172],4,"set!");
lf[173]=C_h_intern(&lf[173],4,"cond");
lf[174]=C_h_intern(&lf[174],4,"case");
lf[175]=C_h_intern(&lf[175],3,"and");
lf[176]=C_h_intern(&lf[176],2,"or");
lf[177]=C_h_intern(&lf[177],3,"let");
lf[178]=C_h_intern(&lf[178],5,"begin");
lf[179]=C_h_intern(&lf[179],2,"do");
lf[180]=C_h_intern(&lf[180],4,"let*");
lf[181]=C_h_intern(&lf[181],6,"letrec");
lf[182]=C_h_intern(&lf[182],6,"define");
lf[183]=C_h_intern(&lf[183],18,"pretty-print-width");
lf[184]=C_h_intern(&lf[184],12,"pretty-print");
lf[185]=C_h_intern(&lf[185],19,"current-output-port");
lf[186]=C_h_intern(&lf[186],2,"pp");
lf[187]=C_h_intern(&lf[187],8,"->string");
lf[188]=C_h_intern(&lf[188],14,"symbol->string");
lf[189]=C_h_intern(&lf[189],4,"conc");
lf[190]=C_h_intern(&lf[190],19,"\003syssubstring-index");
lf[191]=C_h_intern(&lf[191],15,"substring-index");
lf[192]=C_h_intern(&lf[192],22,"\003syssubstring-index-ci");
lf[193]=C_h_intern(&lf[193],18,"substring-index-ci");
lf[194]=C_h_intern(&lf[194],15,"string-compare3");
lf[195]=C_h_intern(&lf[195],18,"string-compare3-ci");
lf[196]=C_h_intern(&lf[196],15,"\003syssubstring=\077");
lf[197]=C_h_intern(&lf[197],11,"substring=\077");
lf[198]=C_h_intern(&lf[198],18,"\003syssubstring-ci=\077");
lf[199]=C_h_intern(&lf[199],14,"substring-ci=\077");
lf[200]=C_h_intern(&lf[200],12,"string-split");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\003\011\012 ");
lf[202]=C_h_intern(&lf[202],18,"string-intersperse");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[205]=C_h_intern(&lf[205],19,"\003sysallocate-vector");
lf[206]=C_h_intern(&lf[206],12,"list->string");
lf[207]=C_h_intern(&lf[207],16,"string-translate");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid translation destination");
lf[209]=C_h_intern(&lf[209],17,"string-translate*");
lf[210]=C_h_intern(&lf[210],21,"\003sysfragments->string");
lf[211]=C_h_intern(&lf[211],11,"string-chop");
lf[212]=C_h_intern(&lf[212],12,"string-chomp");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[214]=C_h_intern(&lf[214],5,"write");
lf[215]=C_h_intern(&lf[215],15,"\006extrasfprintf0");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[217]=C_h_intern(&lf[217],16,"\003sysflush-output");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\037illegal format-string character");
lf[219]=C_h_intern(&lf[219],13,"\003systty-port\077");
lf[220]=C_h_intern(&lf[220],7,"fprintf");
lf[221]=C_h_intern(&lf[221],6,"printf");
lf[222]=C_h_intern(&lf[222],7,"sprintf");
lf[223]=C_h_intern(&lf[223],6,"format");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal destination");
lf[225]=C_h_intern(&lf[225],12,"output-port\077");
lf[226]=C_h_intern(&lf[226],7,"sorted\077");
lf[227]=C_h_intern(&lf[227],5,"merge");
lf[228]=C_h_intern(&lf[228],6,"merge!");
lf[229]=C_h_intern(&lf[229],4,"sort");
lf[230]=C_h_intern(&lf[230],12,"list->vector");
lf[231]=C_h_intern(&lf[231],6,"append");
lf[232]=C_h_intern(&lf[232],13,"binary-search");
lf[233]=C_h_intern(&lf[233],20,"\003sysnumber-hash-hook");
lf[234]=C_h_intern(&lf[234],19,"\006extras%equal\077-hash");
lf[235]=C_h_intern(&lf[235],11,"number-hash");
lf[236]=C_h_intern(&lf[236],4,"\077obj");
lf[237]=C_h_intern(&lf[237],5,"\000type");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[239]=C_h_intern(&lf[239],23,"\006extras%object-uid-hash");
lf[240]=C_h_intern(&lf[240],15,"object-uid-hash");
lf[241]=C_h_intern(&lf[241],11,"symbol-hash");
lf[242]=C_h_intern(&lf[242],11,"string-hash");
lf[243]=C_h_intern(&lf[243],17,"\003syscheck-keyword");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[245]=C_h_intern(&lf[245],8,"keyword\077");
lf[246]=C_h_intern(&lf[246],12,"keyword-hash");
lf[247]=C_h_intern(&lf[247],16,"\006extras%eq\077-hash");
lf[248]=C_h_intern(&lf[248],8,"eq\077-hash");
lf[249]=C_h_intern(&lf[249],16,"hash-by-identity");
lf[250]=C_h_intern(&lf[250],17,"\006extras%eqv\077-hash");
lf[251]=C_h_intern(&lf[251],9,"eqv\077-hash");
lf[252]=C_h_intern(&lf[252],11,"input-port\077");
lf[253]=C_h_intern(&lf[253],11,"equal\077-hash");
lf[254]=C_h_intern(&lf[254],4,"hash");
lf[255]=C_h_intern(&lf[255],14,"string-ci-hash");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[258]=C_h_intern(&lf[258],34,"\006extrashash-table-canonical-length");
lf[259]=C_h_intern(&lf[259],11,"make-vector");
lf[260]=C_h_intern(&lf[260],16,"%make-hash-table");
lf[261]=C_h_intern(&lf[261],10,"hash-table");
lf[262]=C_h_intern(&lf[262],8,"string=\077");
lf[263]=C_h_intern(&lf[263],11,"string-ci=\077");
lf[264]=C_h_intern(&lf[264],1,"=");
lf[265]=C_h_intern(&lf[265],15,"make-hash-table");
lf[266]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[267]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[268]=C_h_intern(&lf[268],7,"warning");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[270]=C_h_intern(&lf[270],5,"error");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[272]=C_h_intern(&lf[272],5,"\000test");
lf[273]=C_h_intern(&lf[273],5,"\000hash");
lf[274]=C_h_intern(&lf[274],5,"\000size");
lf[275]=C_h_intern(&lf[275],19,"hash-table-max-size");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[277]=C_h_intern(&lf[277],8,"\000initial");
lf[278]=C_h_intern(&lf[278],9,"\000min-load");
lf[279]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[280]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[282]=C_h_intern(&lf[282],17,"\003syscheck-inexact");
lf[283]=C_h_intern(&lf[283],9,"\000max-load");
lf[284]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[285]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[287]=C_h_intern(&lf[287],10,"\000weak-keys");
lf[288]=C_h_intern(&lf[288],12,"\000weak-values");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[293]=C_h_intern(&lf[293],11,"hash-table\077");
lf[294]=C_h_intern(&lf[294],15,"hash-table-size");
lf[295]=C_h_intern(&lf[295],31,"hash-table-equivalence-function");
lf[296]=C_h_intern(&lf[296],24,"hash-table-hash-function");
lf[297]=C_h_intern(&lf[297],19,"hash-table-min-load");
lf[298]=C_h_intern(&lf[298],19,"hash-table-max-load");
lf[299]=C_h_intern(&lf[299],20,"hash-table-weak-keys");
lf[300]=C_h_intern(&lf[300],22,"hash-table-weak-values");
lf[301]=C_h_intern(&lf[301],23,"hash-table-has-initial\077");
lf[302]=C_h_intern(&lf[302],18,"hash-table-initial");
lf[303]=C_h_intern(&lf[303],23,"\006extras%hash-table-copy");
lf[304]=C_h_intern(&lf[304],15,"hash-table-copy");
lf[305]=C_h_intern(&lf[305],24,"\006extrashash-table-rehash");
lf[306]=C_h_intern(&lf[306],5,"floor");
lf[307]=C_h_intern(&lf[307],26,"\006extras%hash-table-update!");
lf[308]=C_h_intern(&lf[308],18,"hash-table-update!");
lf[309]=C_h_intern(&lf[309],13,"\000access-error");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[311]=C_h_intern(&lf[311],26,"hash-table-update!/default");
lf[312]=C_h_intern(&lf[312],15,"hash-table-set!");
lf[313]=C_h_intern(&lf[313],22,"\006extras%hash-table-ref");
lf[314]=C_h_intern(&lf[314],14,"hash-table-ref");
lf[315]=C_h_intern(&lf[315],22,"hash-table-ref/default");
lf[316]=C_h_intern(&lf[316],18,"hash-table-exists\077");
lf[317]=C_h_intern(&lf[317],18,"hash-table-delete!");
lf[318]=C_h_intern(&lf[318],18,"hash-table-remove!");
lf[319]=C_h_intern(&lf[319],25,"\006extras%hash-table-merge!");
lf[320]=C_h_intern(&lf[320],17,"hash-table-merge!");
lf[321]=C_h_intern(&lf[321],16,"hash-table-merge");
lf[322]=C_h_intern(&lf[322],17,"hash-table->alist");
lf[323]=C_h_intern(&lf[323],17,"alist->hash-table");
lf[324]=C_h_intern(&lf[324],12,"\003sysfor-each");
lf[325]=C_h_intern(&lf[325],15,"hash-table-keys");
lf[326]=C_h_intern(&lf[326],17,"hash-table-values");
lf[327]=C_h_intern(&lf[327],27,"\006extras%hash-table-for-each");
lf[328]=C_h_intern(&lf[328],23,"\006extras%hash-table-fold");
lf[329]=C_h_intern(&lf[329],15,"hash-table-fold");
lf[330]=C_h_intern(&lf[330],19,"hash-table-for-each");
lf[331]=C_h_intern(&lf[331],15,"hash-table-walk");
lf[332]=C_h_intern(&lf[332],14,"hash-table-map");
lf[333]=C_h_intern(&lf[333],10,"make-queue");
lf[334]=C_h_intern(&lf[334],5,"queue");
lf[335]=C_h_intern(&lf[335],6,"queue\077");
lf[336]=C_h_intern(&lf[336],12,"queue-empty\077");
lf[337]=C_h_intern(&lf[337],11,"queue-first");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[339]=C_h_intern(&lf[339],10,"queue-last");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[341]=C_h_intern(&lf[341],10,"queue-add!");
lf[342]=C_h_intern(&lf[342],13,"queue-remove!");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[344]=C_h_intern(&lf[344],11,"queue->list");
lf[345]=C_h_intern(&lf[345],11,"list->queue");
lf[346]=C_h_intern(&lf[346],16,"queue-push-back!");
lf[347]=C_h_intern(&lf[347],21,"queue-push-back-list!");
lf[348]=C_h_intern(&lf[348],17,"register-feature!");
lf[349]=C_h_intern(&lf[349],7,"srfi-69");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[351]=C_h_intern(&lf[351],18,"getter-with-setter");
lf[352]=C_h_intern(&lf[352],7,"srfi-28");
lf[353]=C_h_intern(&lf[353],14,"make-parameter");
lf[354]=C_h_intern(&lf[354],6,"extras");
C_register_lf2(lf,355,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=*((C_word*)lf[2]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1982,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 102  register-feature! */
t5=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[354]);}

/* k1980 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word ab[142],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1984,tmp=(C_word)a,a+=2,tmp));
t3=*((C_word*)lf[5]+1);
t4=*((C_word*)lf[6]+1);
t5=*((C_word*)lf[7]+1);
t6=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1990,a[2]=t3,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t7=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2122,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2125,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2133,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2166,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2203,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2226,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2234,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2246,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2282,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2321,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2361,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2367,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2423,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2426,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2429,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2432,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2435,tmp=(C_word)a,a+=2,tmp));
t24=*((C_word*)lf[6]+1);
t25=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2476,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2479,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2507,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2540,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2572,tmp=(C_word)a,a+=2,tmp));
t31=*((C_word*)lf[6]+1);
t32=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2613,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2698,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2757,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2837,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2878,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2964,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3085,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3137,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3175,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3187,tmp=(C_word)a,a+=2,tmp));
t42=*((C_word*)lf[65]+1);
t43=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=t42,tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[66]+1);
t45=*((C_word*)lf[7]+1);
t46=*((C_word*)lf[6]+1);
t47=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3374,a[2]=t45,a[3]=t44,a[4]=t46,tmp=(C_word)a,a+=5,tmp));
t48=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3464,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3554,tmp=(C_word)a,a+=2,tmp));
t50=*((C_word*)lf[76]+1);
t51=*((C_word*)lf[77]+1);
t52=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3648,a[2]=t50,a[3]=t51,tmp=(C_word)a,a+=4,tmp));
t53=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3721,tmp=(C_word)a,a+=2,tmp));
t54=*((C_word*)lf[76]+1);
t55=*((C_word*)lf[77]+1);
t56=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3778,a[2]=t54,a[3]=t55,tmp=(C_word)a,a+=4,tmp));
t57=*((C_word*)lf[84]+1);
t58=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=t57,tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[84]+1);
t60=*((C_word*)lf[87]+1);
t61=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3926,a[2]=t59,a[3]=t60,tmp=(C_word)a,a+=4,tmp));
t62=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3947,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3980,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4011,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4042,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4073,tmp=(C_word)a,a+=2,tmp));
t67=*((C_word*)lf[98]+1);
t68=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4104,a[2]=t67,tmp=(C_word)a,a+=3,tmp));
t69=*((C_word*)lf[76]+1);
t70=*((C_word*)lf[77]+1);
t71=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4113,a[2]=t69,a[3]=t70,tmp=(C_word)a,a+=4,tmp));
t72=*((C_word*)lf[98]+1);
t73=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4125,a[2]=t72,tmp=(C_word)a,a+=3,tmp));
t74=*((C_word*)lf[76]+1);
t75=*((C_word*)lf[77]+1);
t76=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=t74,a[3]=t75,tmp=(C_word)a,a+=4,tmp));
t77=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4190,tmp=(C_word)a,a+=2,tmp));
t78=*((C_word*)lf[107]+1);
t79=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4333,a[2]=t78,tmp=(C_word)a,a+=3,tmp));
t80=*((C_word*)lf[76]+1);
t81=*((C_word*)lf[77]+1);
t82=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4397,a[2]=t80,a[3]=t81,tmp=(C_word)a,a+=4,tmp));
t83=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5669,tmp=(C_word)a,a+=2,tmp));
t84=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1040 make-parameter */
t85=*((C_word*)lf[353]+1);
((C_proc3)(void*)(*((C_word*)t85+1)))(3,t85,t84,C_fix(79));}

/* k5746 in k1980 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word ab[70],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5748,2,t0,t1);}
t2=C_mutate((C_word*)lf[183]+1,t1);
t3=C_mutate((C_word*)lf[184]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5750,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[186]+1,*((C_word*)lf[184]+1));
t5=*((C_word*)lf[76]+1);
t6=*((C_word*)lf[84]+1);
t7=*((C_word*)lf[107]+1);
t8=*((C_word*)lf[77]+1);
t9=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5779,a[2]=t5,a[3]=t6,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t10=*((C_word*)lf[146]+1);
t11=C_mutate((C_word*)lf[189]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5824,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5834,tmp=(C_word)a,a+=2,tmp);
t13=C_mutate((C_word*)lf[190]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5881,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[192]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5890,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[191]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5899,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[193]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5920,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5941,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[195]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5972,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6003,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[197]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6040,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6117,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[199]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6154,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6231,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6366,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[65]+1);
t26=*((C_word*)lf[206]+1);
t27=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6474,a[2]=t26,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6676,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6798,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6862,tmp=(C_word)a,a+=2,tmp));
t31=*((C_word*)lf[214]+1);
t32=*((C_word*)lf[87]+1);
t33=*((C_word*)lf[84]+1);
t34=*((C_word*)lf[76]+1);
t35=*((C_word*)lf[77]+1);
t36=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6907,a[2]=t34,a[3]=t32,a[4]=t33,a[5]=t31,a[6]=t35,tmp=(C_word)a,a+=7,tmp));
t37=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7205,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7211,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7217,tmp=(C_word)a,a+=2,tmp));
t40=*((C_word*)lf[220]+1);
t41=*((C_word*)lf[222]+1);
t42=*((C_word*)lf[221]+1);
t43=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7223,a[2]=t40,a[3]=t41,a[4]=t42,tmp=(C_word)a,a+=5,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1416 register-feature! */
t45=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t45+1)))(3,t45,t44,lf[352]);}

/* k7264 in k5746 in k1980 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word ab[101],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7266,2,t0,t1);}
t2=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7268,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7377,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7476,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7608,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7741,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[230]+1);
t8=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7768,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7851,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7857,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7923,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7929,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[241]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7970,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[243]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8015,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8041,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[247]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8086,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[248]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8147,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[249]+1,*((C_word*)lf[248]+1));
t19=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8189,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8269,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8310,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[253]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8582,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[254]+1,*((C_word*)lf[253]+1));
t24=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8624,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[255]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8665,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate(&lf[256],lf[257]);
t27=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8707,tmp=(C_word)a,a+=2,tmp));
t28=*((C_word*)lf[259]+1);
t29=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8737,a[2]=t28,tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[53]+1);
t31=*((C_word*)lf[52]+1);
t32=*((C_word*)lf[56]+1);
t33=*((C_word*)lf[262]+1);
t34=*((C_word*)lf[263]+1);
t35=*((C_word*)lf[264]+1);
t36=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8761,a[2]=t35,a[3]=t34,a[4]=t33,a[5]=t32,a[6]=t31,a[7]=t30,tmp=(C_word)a,a+=8,tmp));
t37=C_mutate((C_word*)lf[293]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9124,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[294]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9130,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[295]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9139,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9148,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9157,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9166,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9175,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9184,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9193,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9205,tmp=(C_word)a,a+=2,tmp));
t47=*((C_word*)lf[259]+1);
t48=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9220,a[2]=t47,tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9332,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[305]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9341,tmp=(C_word)a,a+=2,tmp));
t51=*((C_word*)lf[53]+1);
t52=*((C_word*)lf[306]+1);
t53=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9420,a[2]=t52,a[3]=t51,tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9656,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9734,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9749,tmp=(C_word)a,a+=2,tmp));
t57=*((C_word*)lf[53]+1);
t58=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9763,a[2]=t57,tmp=(C_word)a,a+=3,tmp));
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9874,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t60=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10916,tmp=(C_word)a,a+=2,tmp);
/* extras.scm: 2238 getter-with-setter */
t61=*((C_word*)lf[351]+1);
((C_proc4)(void*)(*((C_word*)t61+1)))(4,t61,t59,t60,*((C_word*)lf[312]+1));}

/* a10915 in k7264 in k5746 in k1980 */
static void C_ccall f_10916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4rv,(void*)f_10916r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_10916r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10933,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_structure_2(t2,lf[261],lf[314]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10926,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 2244 ##sys#check-closure */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,lf[314]);}

/* k10924 in a10915 in k7264 in k5746 in k1980 */
static void C_ccall f_10926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2245 %hash-table-ref */
t2=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_10933 in a10915 in k7264 in k5746 in k1980 */
static void C_ccall f_10933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10933,2,t0,t1);}
/* extras.scm: 2240 ##sys#signal-hook */
t2=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[309],lf[314],lf[350],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_9874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9874,2,t0,t1);}
t2=C_mutate((C_word*)lf[314]+1,t1);
t3=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9876,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[316]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9888,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[53]+1);
t6=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9909,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10040,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[319]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10136,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10203,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10215,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10231,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[265]+1);
t13=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10304,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10332,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10397,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10462,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10511,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10577,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10589,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10601,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10613,tmp=(C_word)a,a+=2,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 2455 register-feature! */
t23=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t22,lf[349]);}

/* k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10636,2,t0,t1);}
t2=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10638,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10644,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10650,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10663,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10684,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[341]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10705,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10737,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10773,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10782,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10836,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[347]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10865,tmp=(C_word)a,a+=2,tmp));
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}

/* queue-push-back-list! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10865,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[334],lf[347]);
t5=(C_word)C_i_check_list_2(t3,lf[347]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10875,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 2562 append */
t8=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t3,t7);}

/* k10873 in queue-push-back-list! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10878,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_10878(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10892,tmp=(C_word)a,a+=2,tmp);
t5=t2;
f_10878(t5,f_10892(t1));}}

/* do1805 in k10873 in queue-push-back-list! in k10634 in k9872 in k7264 in k5746 in k1980 */
static C_word C_fcall f_10892(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* k10876 in k10873 in queue-push-back-list! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1));}

/* queue-push-back! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10836,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[334],lf[346]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_i_setslot(t2,C_fix(1),t6);
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?(C_word)C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED));}

/* list->queue in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10782,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[345]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10793,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_10793(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10801,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10801(t9,t4,t2);}}

/* do1788 in list->queue in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10801,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10811,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* extras.scm: 2538 ##sys#not-a-proper-list-error */
t8=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[345]);}
else{
t8=t5;
f_10811(2,t8,C_SCHEME_UNDEFINED);}}}

/* k10809 in do1788 in list->queue in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10801(t3,((C_word*)t0)[2],t2);}

/* k10791 in list->queue in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10793,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[334],((C_word*)t0)[2],t1));}

/* queue->list in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10773,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[334],lf[344]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10737,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[334],lf[342]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10747,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 2516 ##sys#error */
t7=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[342],lf[343],t2);}
else{
t7=t5;
f_10747(2,t7,C_SCHEME_UNDEFINED);}}

/* k10745 in queue-remove! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(((C_word*)t0)[4],C_fix(0)));}

/* queue-add! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10705,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[334],lf[341]);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10715,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t7);
if(C_truep(t8)){
t9=t6;
f_10715(t9,(C_word)C_i_setslot(t2,C_fix(1),t5));}
else{
t9=(C_word)C_slot(t2,C_fix(2));
t10=t6;
f_10715(t10,(C_word)C_i_setslot(t9,C_fix(1),t5));}}

/* k10713 in queue-add! in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10684,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[334],lf[339]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10694,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 2497 ##sys#error */
t7=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[339],lf[340],t2);}
else{
t7=t5;
f_10694(2,t7,C_SCHEME_UNDEFINED);}}

/* k10692 in queue-last in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-first in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10663,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[334],lf[337]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10673,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 2486 ##sys#error */
t7=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[337],lf[338],t2);}
else{
t7=t5;
f_10673(2,t7,C_SCHEME_UNDEFINED);}}

/* k10671 in queue-first in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-empty? in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10650,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[334],lf[336]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* queue? in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10644,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[334]));}

/* make-queue in k10634 in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10638,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[334],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* hash-table-map in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10613,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[332]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10620,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 2450 ##sys#check-closure */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[332]);}

/* k10618 in hash-table-map in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10625,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 2451 %hash-table-fold */
t3=*((C_word*)lf[328]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a10624 in k10618 in hash-table-map in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10625,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10633,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 2451 func */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k10631 in a10624 in k10618 in hash-table-map in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10633,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10601,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[331]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10608,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 2445 ##sys#check-closure */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[331]);}

/* k10606 in hash-table-walk in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2446 %hash-table-for-each */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10589,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[330]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10596,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 2440 ##sys#check-closure */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[330]);}

/* k10594 in hash-table-for-each in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2441 %hash-table-for-each */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10577,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[261],lf[329]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10584,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 2435 ##sys#check-closure */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[329]);}

/* k10582 in hash-table-fold in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2436 %hash-table-fold */
t2=*((C_word*)lf[328]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##extras#%hash-table-fold in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10511,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10523,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_10523(t10,t1,C_fix(0),t4);}

/* loop in ##extras#%hash-table-fold in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10523(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10523,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10539,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_10539(t8,t1,t4,t3);}}

/* fold2 in loop in ##extras#%hash-table-fold in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10539(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10539,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 2428 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10523(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10567,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* extras.scm: 2431 func */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t7,t8,t3);}}

/* k10565 in fold2 in loop in ##extras#%hash-table-fold in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2430 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10539(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##extras#%hash-table-for-each in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10462,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10474,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_10474(t9,t1,C_fix(0));}

/* do1721 in ##extras#%hash-table-for-each in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10474(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10474,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10484,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10493,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* extras.scm: 2415 ##sys#for-each */
t6=*((C_word*)lf[324]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a10492 in do1721 in ##extras#%hash-table-for-each in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10493,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 2416 proc */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k10482 in do1721 in ##extras#%hash-table-for-each in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10474(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10397,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[326]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10412,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10412(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10412(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10412,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10428,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_10428(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10428(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10428,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 2398 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10412(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 2399 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10332,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[325]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10347,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10347(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10347(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10347,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10363,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_10363(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10363(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10363,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 2383 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10347(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 2384 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10304(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_10304r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_10304r(t0,t1,t2,t3);}}

static void C_ccall f_10304r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[323]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10311,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k10309 in alist->hash-table in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10314,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10316,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[324]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10315 in k10309 in alist->hash-table in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10316,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10326,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 2366 %hash-table-update! */
t5=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,((C_word*)t0)[2],t3,*((C_word*)lf[11]+1),t4);}

/* a10325 in a10315 in k10309 in alist->hash-table in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10326,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k10312 in k10309 in alist->hash-table in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10231,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[322]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10246,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10246(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10246(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10246,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10262,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_10262(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10262(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10262,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 2355 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10246(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* extras.scm: 2356 loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10215,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[321]);
t5=(C_word)C_i_check_structure_2(t3,lf[261],lf[321]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10229,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 2341 %hash-table-copy */
t7=*((C_word*)lf[303]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k10227 in hash-table-merge in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2341 %hash-table-merge! */
t2=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10203,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[320]);
t5=(C_word)C_i_check_structure_2(t3,lf[261],lf[320]);
/* extras.scm: 2336 %hash-table-merge! */
t6=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}

/* ##extras#%hash-table-merge! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10136,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10148,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_10148(t9,t1,C_fix(0));}

/* do1652 in ##extras#%hash-table-merge! in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10148,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10158,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10171,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10171(t8,t3,t4);}}

/* do1655 in do1652 in ##extras#%hash-table-merge! in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10171,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10184,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10197,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 2330 %hash-table-update! */
t7=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[11]+1),t6);}}

/* a10196 in do1655 in do1652 in ##extras#%hash-table-merge! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10197,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k10182 in do1655 in do1652 in ##extras#%hash-table-merge! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10171(t3,((C_word*)t0)[2],t2);}

/* k10156 in do1652 in ##extras#%hash-table-merge! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10148(t3,((C_word*)t0)[2],t2);}

/* hash-table-remove! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10040,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[318]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10047,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 2301 ##sys#check-closure */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[318]);}

/* k10045 in hash-table-remove! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10047,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10061,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_10061(t10,((C_word*)t0)[2],C_fix(0));}

/* do1633 in k10045 in hash-table-remove! in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10061,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10074,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10087,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_10087(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in do1633 in k10045 in hash-table-remove! in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_10087(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10087,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10106,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* extras.scm: 2311 func */
t9=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* k10104 in loop in do1633 in k10045 in hash-table-remove! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* extras.scm: 2318 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10087(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k10072 in do1633 in k10045 in hash-table-remove! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10061(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_9909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9909,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[317]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9925,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 2265 hash */
t9=t7;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,t6);}

/* k9923 in hash-table-delete! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_9925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9925,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9945,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_9945(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9992,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_9992(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k9923 in hash-table-delete! in k9872 in k7264 in k5746 in k1980 */
static void C_fcall f_9992(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9992,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10011,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 2288 test */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k10009 in loop in k9923 in hash-table-delete! in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_10011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* extras.scm: 2295 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9992(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k9923 in hash-table-delete! in k9872 in k7264 in k5746 in k1980 */
static C_word C_fcall f_9945(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9888,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[261],lf[316]);
t5=(C_word)C_slot(lf[4],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9907,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 2254 %hash-table-ref */
t7=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t3,*((C_word*)lf[3]+1));}

/* k9905 in hash-table-exists? in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_9907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}

/* hash-table-ref/default in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_9876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9876,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[261],lf[315]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9885,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 2250 %hash-table-ref */
t7=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t3,t6);}

/* a9884 in hash-table-ref/default in k9872 in k7264 in k5746 in k1980 */
static void C_ccall f_9885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9885,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##extras#%hash-table-ref in k7264 in k5746 in k1980 */
static void C_ccall f_9763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9763,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9776,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_block_size(t5);
/* extras.scm: 2218 hash */
t10=t7;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t3,t9);}

/* k9774 in ##extras#%hash-table-ref in k7264 in k5746 in k1980 */
static void C_ccall f_9776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9776,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9791,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9791(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_9833(t7,((C_word*)t0)[2],t3);}}

/* loop in k9774 in ##extras#%hash-table-ref in k7264 in k5746 in k1980 */
static void C_fcall f_9833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9833,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 2231 def */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9852,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 2233 test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k9850 in loop in k9774 in ##extras#%hash-table-ref in k7264 in k5746 in k1980 */
static void C_ccall f_9852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 2235 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9833(t3,((C_word*)t0)[5],t2);}}

/* loop in k9774 in ##extras#%hash-table-ref in k7264 in k5746 in k1980 */
static void C_fcall f_9791(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9791,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 2223 def */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 2227 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* hash-table-set! in k7264 in k5746 in k1980 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9749,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[261],lf[312]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9754,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9758,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 2207 %hash-table-update! */
t8=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,t2,t3,t6,t6);}

/* k9756 in hash-table-set! in k7264 in k5746 in k1980 */
static void C_ccall f_9758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* thunk in hash-table-set! in k7264 in k5746 in k1980 */
static void C_ccall f_9754(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9754,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update!/default in k7264 in k5746 in k1980 */
static void C_ccall f_9734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9734,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[261],lf[311]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9741,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 2201 ##sys#check-closure */
t8=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[311]);}

/* k9739 in hash-table-update!/default in k7264 in k5746 in k1980 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9746,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 2202 %hash-table-update! */
t3=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a9745 in k9739 in hash-table-update!/default in k7264 in k5746 in k1980 */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9746,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_9656r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9656r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9656r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9658,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9672,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9689,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func15371551 */
t8=t7;
f_9689(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk15381546 */
t10=t6;
f_9672(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body15351540 */
t12=t5;
f_9658(t12,t1,t8,t10);}}}

/* def-func1537 in hash-table-update! in k7264 in k5746 in k1980 */
static void C_fcall f_9689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9689,NULL,2,t0,t1);}
/* def-thunk15381546 */
t2=((C_word*)t0)[2];
f_9672(t2,t1,*((C_word*)lf[11]+1));}

/* def-thunk1538 in hash-table-update! in k7264 in k5746 in k1980 */
static void C_fcall f_9672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9672,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
/* body15351540 */
t5=((C_word*)t0)[2];
f_9658(t5,t1,t2,t4);}

/* f_9684 in def-thunk1538 in hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9684,2,t0,t1);}
/* extras.scm: 2191 ##sys#signal-hook */
t2=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[309],lf[308],lf[310],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body1535 in hash-table-update! in k7264 in k5746 in k1980 */
static void C_fcall f_9658(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9658,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[261],lf[308]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9665,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 2195 ##sys#check-closure */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[308]);}

/* k9663 in body1535 in hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 2196 ##sys#check-closure */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[308]);}

/* k9666 in k9663 in body1535 in hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2197 %hash-table-update! */
t2=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9420,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(4));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_u_fixnum_plus(t8,C_fix(1));
t10=(C_word)C_slot(t2,C_fix(5));
t11=(C_word)C_slot(t2,C_fix(6));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9441,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=t5,a[6]=t4,a[7]=t9,a[8]=t3,a[9]=t7,a[10]=((C_word*)t0)[3],a[11]=t6,a[12]=t13,a[13]=t2,tmp=(C_word)a,a+=14,tmp));
t15=((C_word*)t13)[1];
f_9441(t15,t1);}

/* re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_fcall f_9441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9441,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_a_i_times(&a,2,t3,((C_word*)t0)[2]);
/* extras.scm: 2136 floor */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9646,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9638,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[10],((C_word*)t0)[3]);
/* extras.scm: 2137 floor */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9638,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9457,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* extras.scm: 2138 hash */
t4=((C_word*)t0)[10];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[9]);}

/* k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[10],C_fix(1073741823)))){
t3=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[6]);
t4=t2;
f_9463(t4,(C_truep(t3)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_9463(t3,C_SCHEME_FALSE);}}

/* k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_fcall f_9463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[37],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9463,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9479,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_times(((C_word*)t0)[9],C_fix(2));
t5=(C_word)C_i_fixnum_min(C_fix(1073741823),t4);
/* extras.scm: 2144 hash-table-canonical-length */
t6=*((C_word*)lf[258]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[256],t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],((C_word*)t0)[8]);
t3=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9501,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_9501(t7,((C_word*)t0)[12],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9564,a[2]=((C_word*)t0)[6],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_9564(t7,((C_word*)t0)[12],t2);}}}

/* loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_fcall f_9564(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9564,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9574,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9592,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 2172 thunk */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9601,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 2178 test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k9599 in loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9601,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9604,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 2179 func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 2182 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9564(t3,((C_word*)t0)[5],t2);}}

/* k9602 in k9599 in loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k9590 in loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2172 func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9572 in loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_fcall f_9501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9501,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9511,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9529,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 2158 thunk */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9541,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 2165 func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 2168 loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k9539 in loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k9527 in loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2158 func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9509 in loop in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9511,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k9477 in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2143 make-vector */
t2=*((C_word*)lf[259]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9464 in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 2149 hash-table-rehash */
t3=*((C_word*)lf[305]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9467 in k9464 in k9461 in k9455 in k9636 in k9644 in re-enter in ##extras#%hash-table-update! in k7264 in k5746 in k1980 */
static void C_ccall f_9469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]);
/* extras.scm: 2151 re-enter */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9441(t3,((C_word*)t0)[2]);}

/* ##extras#hash-table-rehash in k7264 in k5746 in k1980 */
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9341,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t2);
t6=(C_word)C_block_size(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9353,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t8,a[7]=t5,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_9353(t10,t1,C_fix(0));}

/* do1477 in ##extras#hash-table-rehash in k7264 in k5746 in k1980 */
static void C_fcall f_9353(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9353,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9363,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_9376(t8,t3,t4);}}

/* loop in do1477 in ##extras#hash-table-rehash in k7264 in k5746 in k1980 */
static void C_fcall f_9376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9376,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9392,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 2118 hash */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k9390 in loop in do1477 in ##extras#hash-table-rehash in k7264 in k5746 in k1980 */
static void C_ccall f_9392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9392,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 2122 loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_9376(t8,((C_word*)t0)[2],t7);}

/* k9361 in do1477 in ##extras#hash-table-rehash in k7264 in k5746 in k1980 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9353(t3,((C_word*)t0)[2],t2);}

/* hash-table-copy in k7264 in k5746 in k1980 */
static void C_ccall f_9332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9332,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[304]);
/* extras.scm: 2102 %hash-table-copy */
t4=*((C_word*)lf[303]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* ##extras#%hash-table-copy in k7264 in k5746 in k1980 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9220,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9230,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 2082 make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k9228 in ##extras#%hash-table-copy in k7264 in k5746 in k1980 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9230,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9235,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_9235(t5,((C_word*)t0)[2],C_fix(0));}

/* do1461 in k9228 in ##extras#%hash-table-copy in k7264 in k5746 in k1980 */
static void C_fcall f_9235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9235,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* extras.scm: 2085 %make-hash-table */
t11=*((C_word*)lf[260]+1);
((C_proc11)(void*)(*((C_word*)t11+1)))(11,t11,t1,t3,t4,t5,t6,t7,t8,t9,t10,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9291,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9297,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9297(t8,t3,t4);}}

/* copy-loop in do1461 in k9228 in ##extras#%hash-table-copy in k7264 in k5746 in k1980 */
static void C_fcall f_9297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9297,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9318,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 2098 copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k9316 in copy-loop in do1461 in k9228 in ##extras#%hash-table-copy in k7264 in k5746 in k1980 */
static void C_ccall f_9318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9318,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9289 in do1461 in k9228 in ##extras#%hash-table-copy in k7264 in k5746 in k1980 */
static void C_ccall f_9291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_9235(t4,((C_word*)t0)[2],t3);}

/* hash-table-initial in k7264 in k5746 in k1980 */
static void C_ccall f_9205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9205,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[302]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* extras.scm: 2073 thunk */
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k7264 in k5746 in k1980 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9193,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[301]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k7264 in k5746 in k1980 */
static void C_ccall f_9184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9184,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[300]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k7264 in k5746 in k1980 */
static void C_ccall f_9175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9175,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[299]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k7264 in k5746 in k1980 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9166,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[298]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k7264 in k5746 in k1980 */
static void C_ccall f_9157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9157,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[297]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k7264 in k5746 in k1980 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9148,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[296]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k7264 in k5746 in k1980 */
static void C_ccall f_9139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9139,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[295]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k7264 in k5746 in k1980 */
static void C_ccall f_9130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9130,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[261],lf[294]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k7264 in k5746 in k1980 */
static void C_ccall f_9124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9124,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[261]));}

/* make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8761(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+47)){
C_save_and_reclaim((void*)tr2r,(void*)f_8761r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8761r(t0,t1,t2);}}

static void C_ccall f_8761r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a=C_alloc(47);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[56]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[266];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[267];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t22=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8839,a[2]=t4,a[3]=t2,a[4]=t21,a[5]=t12,a[6]=t20,a[7]=t18,a[8]=t16,a[9]=t14,a[10]=t8,a[11]=t6,a[12]=t1,a[13]=t10,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t23=t22;
f_8839(t23,C_SCHEME_UNDEFINED);}
else{
t23=(C_word)C_u_i_car(((C_word*)t4)[1]);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9114,a[2]=t4,a[3]=t23,a[4]=t6,a[5]=t22,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1952 keyword? */
t25=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,t23);}}

/* k9112 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_9114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9114,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_8839(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1953 ##sys#check-closure */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[265]);}}

/* k9115 in k9112 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_9117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_8839(t5,t4);}

/* k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_fcall f_8839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8839,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_8842(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9094,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1958 keyword? */
t5=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k9092 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9094,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_8842(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9097,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1959 ##sys#check-closure */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[265]);}}

/* k9095 in k9092 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_9097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_8842(t5,t4);}

/* k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_fcall f_8842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8842,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_8845(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1964 keyword? */
t5=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k9060 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_9062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9062,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_8845(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[265]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9068,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_9068(2,t4,C_SCHEME_UNDEFINED);}
else{
/* extras.scm: 1967 error */
t4=*((C_word*)lf[270]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[265],lf[292],((C_word*)t0)[4]);}}}

/* k9066 in k9060 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_9068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[275]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_8845(t6,t5);}

/* k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_fcall f_8845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8845,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8848,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8880,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t4,a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp));
t6=((C_word*)t4)[1];
f_8880(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_fcall f_8880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8880,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8891,a[2]=((C_word*)t0)[11],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8901,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* extras.scm: 1977 keyword? */
t6=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8901,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_8907(2,t4,(C_word)C_u_i_car(t2));}
else{
/* extras.scm: 1981 invarg-err */
t4=((C_word*)t0)[2];
f_8891(t4,t3,lf[290]);}}
else{
/* extras.scm: 2013 invarg-err */
t2=((C_word*)t0)[2];
f_8891(t2,((C_word*)t0)[12],lf[291]);}}

/* k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8910,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[272]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8923,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1984 ##sys#check-closure */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[265]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[273]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8933,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1987 ##sys#check-closure */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[265]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[274]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[265]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8946,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_8946(2,t8,C_SCHEME_UNDEFINED);}
else{
/* extras.scm: 1992 error */
t8=*((C_word*)lf[270]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[265],lf[276],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[277]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8964,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t8=t2;
f_8910(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[278]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8974,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1997 ##sys#check-inexact */
t9=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[265]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[283]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8999,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 2002 ##sys#check-inexact */
t10=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[265]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[287]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t2;
f_8910(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[288]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_mutate(((C_word *)((C_word*)t0)[3])+1,t11);
t13=t2;
f_8910(2,t13,t12);}
else{
/* extras.scm: 2011 invarg-err */
t11=((C_word*)t0)[2];
f_8891(t11,t2,lf[289]);}}}}}}}}}

/* k8997 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[284],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[285]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_9002(2,t5,C_SCHEME_UNDEFINED);}
else{
/* extras.scm: 2004 error */
t5=*((C_word*)lf[270]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[265],lf[286],((C_word*)t0)[3]);}}

/* k9000 in k8997 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_9002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_8910(2,t3,t2);}

/* k8972 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[279],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[280]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_8977(2,t5,C_SCHEME_UNDEFINED);}
else{
/* extras.scm: 1999 error */
t5=*((C_word*)lf[270]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[265],lf[281],((C_word*)t0)[3]);}}

/* k8975 in k8972 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_8910(2,t3,t2);}

/* f_8964 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8964,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8944 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[275]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_8910(2,t4,t3);}

/* k8931 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_8910(2,t3,t2);}

/* k8921 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_8910(2,t3,t2);}

/* k8908 in k8905 in k8899 in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 2012 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8880(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8891,NULL,3,t0,t1,t2);}
/* extras.scm: 1976 error */
t3=*((C_word*)lf[270]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[265],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8846 in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]))){
/* extras.scm: 2016 error */
t3=*((C_word*)lf[270]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[265],lf[271],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=t2;
f_8851(2,t3,C_SCHEME_UNDEFINED);}}

/* k8849 in k8846 in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* extras.scm: 2018 hash-table-canonical-length */
t3=*((C_word*)lf[258]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[256],((C_word*)((C_word*)t0)[11])[1]);}

/* k8853 in k8849 in k8846 in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8855,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=t3;
f_8858(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_8763(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[8])+1,t4);
t6=t3;
f_8858(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8871,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 2025 warning */
t6=*((C_word*)lf[268]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[265],lf[269]);}}}

/* k8869 in k8853 in k8849 in k8846 in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[253]+1));
t3=((C_word*)t0)[2];
f_8858(t3,t2);}

/* k8856 in k8853 in k8849 in k8846 in k8843 in k8840 in k8837 in make-hash-table in k7264 in k5746 in k1980 */
static void C_fcall f_8858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 2028 %make-hash-table */
t2=*((C_word*)lf[260]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* hash-for-test in make-hash-table in k7264 in k5746 in k1980 */
static C_word C_fcall f_8763(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[53]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[248]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[52]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[251]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[56]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[253]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[262]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[242]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[263]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[255]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[264]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[235]+1):C_SCHEME_FALSE));}}}}}}

/* %make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...){
C_word tmp;
C_word t10;
va_list v;
C_word *a,c2=c;
C_save_rest(t9,c2,10);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr10rv,(void*)f_8737r,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
else{
a=C_alloc((c-10)*3);
t10=C_restore_rest_vector(a,C_rest_count(0));
f_8737r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}}

static void C_ccall f_8737r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8741,a[2]=t9,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_vemptyp(t10))){
/* extras.scm: 1900 make-vector */
t12=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t4,C_SCHEME_END_OF_LIST);}
else{
t12=t11;
f_8741(2,t12,(C_word)C_slot(t10,C_fix(0)));}}

/* k8739 in %make-hash-table in k7264 in k5746 in k1980 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8741,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[261],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* ##extras#hash-table-canonical-length in k7264 in k5746 in k1980 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8707,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_8713(t4,t2));}

/* loop in ##extras#hash-table-canonical-length in k7264 in k5746 in k1980 */
static C_word C_fcall f_8713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8665(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8665r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8665r(t0,t1,t2,t3);}}

static void C_ccall f_8665r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[255]);
t7=(C_word)C_i_check_exact_2(t5,lf[255]);
t8=(C_word)C_hash_string_ci(t2);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?(C_word)C_u_fixnum_negate(t8):t8);
t11=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_fixnum_modulo(t11,t5));}

/* string-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8624(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8624r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8624r(t0,t1,t2,t3);}}

static void C_ccall f_8624r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[242]);
t7=(C_word)C_i_check_exact_2(t5,lf[242]);
t8=(C_word)C_hash_string(t2);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?(C_word)C_u_fixnum_negate(t8):t8);
t11=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_fixnum_modulo(t11,t5));}

/* equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8582r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8582r(t0,t1,t2,t3);}}

static void C_ccall f_8582r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[254]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8600,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1840 %equal?-hash */
t8=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k8598 in equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8310,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8313,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8378,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8409,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
/* extras.scm: 1836 recursive-hash */
t12=((C_word*)t8)[1];
f_8409(t12,t1,t2,C_fix(0));}

/* recursive-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_fcall f_8409(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8409,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_hash_string(t4));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(t2)));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1826 ##sys#number-hash-hook */
t5=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t2));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8510,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1829 recursive-atomic-hash */
t7=((C_word*)((C_word*)t0)[3])[1];
f_8378(t7,t5,t6,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8539,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1830 recursive-atomic-hash */
t6=((C_word*)((C_word*)t0)[3])[1];
f_8378(t6,t4,t5,t3);}
else{
if(C_truep((C_word)C_portp(t2))){
t4=(C_word)C_peek_fixnum(t2,C_fix(0));
t5=(C_word)C_fixnum_shift_left(t4,C_fix(4));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8560,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1831 input-port? */
t7=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_specialp(t2))){
t4=(C_word)C_peek_fixnum(t2,C_fix(0));
/* extras.scm: 1832 vector-hash */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8313(t5,t1,t2,t4,t3,C_fix(1));}
else{
/* extras.scm: 1833 vector-hash */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8313(t4,t1,t2,C_fix(0),t3,C_fix(0));}}}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(262));}}}}}}}}}}

/* k8558 in recursive-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

/* k8537 in recursive-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8539,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8531,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1830 recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8378(t5,t3,t4,((C_word*)t0)[2]);}

/* k8529 in k8537 in recursive-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k8508 in recursive-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k8482 in recursive-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_fcall f_8378(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8378,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_numberp(t2));
t7=(C_truep(t6)?t6:(C_word)C_byteblockp(t2));
if(C_truep(t7)){
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* extras.scm: 1810 recursive-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_8409(t9,t1,t2,t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(99));}}

/* vector-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_fcall f_8313(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8313,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_u_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8330,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8330(t13,t1,t7,t5,t9);}

/* loop in vector-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_fcall f_8330(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8330,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8364,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1802 recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_8409(t10,t7,t8,t9);}}

/* k8362 in loop in vector-hash in ##extras#%equal?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1800 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_8330(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8269r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8269r(t0,t1,t2,t3);}}

static void C_ccall f_8269r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[251]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8287,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1762 %eqv?-hash */
t8=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k8285 in eqv?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##extras#%eqv?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8189,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(256));
case C_SCHEME_FALSE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t3));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(t2)));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8258,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1756 ##sys#number-hash-hook */
t4=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
/* extras.scm: 1758 %object-uid-hash */
t3=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(262));}}}}}}}}}

/* k8256 in ##extras#%eqv?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* eq?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8147(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8147r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8147r(t0,t1,t2,t3);}}

static void C_ccall f_8147r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[248]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8165,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1736 %eq?-hash */
t8=*((C_word*)lf[247]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k8163 in eq?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##extras#%eq?-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8086,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(256));
case C_SCHEME_FALSE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t3));}
else{
if(C_truep((C_word)C_blockp(t2))){
/* extras.scm: 1732 %object-uid-hash */
t3=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(262));}}}}}}}}

/* keyword-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8041r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8041r(t0,t1,t2,t3);}}

static void C_ccall f_8041r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8048,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1709 ##sys#check-keyword */
t7=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[246]);}

/* k8046 in keyword-hash in k7264 in k5746 in k1980 */
static void C_ccall f_8048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[246]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_hash_string(t3);
t5=(C_word)C_fixnum_lessp(t4,C_fix(0));
t6=(C_truep(t5)?(C_word)C_u_fixnum_negate(t4):t4);
t7=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_modulo(t7,((C_word*)t0)[4]));}

/* ##sys#check-keyword in k7264 in k5746 in k1980 */
static void C_ccall f_8015(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8015r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8015r(t0,t1,t2,t3);}}

static void C_ccall f_8015r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8022,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1696 keyword? */
t5=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8020 in ##sys#check-keyword in k7264 in k5746 in k1980 */
static void C_ccall f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));
/* extras.scm: 1697 ##sys#signal-hook */
t4=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[45],t3,lf[244],((C_word*)t0)[2]);}}

/* symbol-hash in k7264 in k5746 in k1980 */
static void C_ccall f_7970(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7970r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7970r(t0,t1,t2,t3);}}

static void C_ccall f_7970r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_symbol_2(t2,lf[241]);
t7=(C_word)C_i_check_exact_2(t5,lf[242]);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_hash_string(t8);
t10=(C_word)C_fixnum_lessp(t9,C_fix(0));
t11=(C_truep(t10)?(C_word)C_u_fixnum_negate(t9):t9);
t12=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_fixnum_modulo(t12,t5));}

/* object-uid-hash in k7264 in k5746 in k1980 */
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7929r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7929r(t0,t1,t2,t3);}}

static void C_ccall f_7929r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[240]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7947,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1677 %object-uid-hash */
t8=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k7945 in object-uid-hash in k7264 in k5746 in k1980 */
static void C_ccall f_7947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##extras#%object-uid-hash in k7264 in k5746 in k1980 */
static void C_ccall f_7923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7923,3,t0,t1,t2);}
/* extras.scm: 1673 %equal?-hash */
t3=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* number-hash in k7264 in k5746 in k1980 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7857r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7857r(t0,t1,t2,t3);}}

static void C_ccall f_7857r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7864,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t7=t6;
f_7864(2,t7,C_SCHEME_UNDEFINED);}
else{
/* extras.scm: 1662 ##sys#signal-hook */
t7=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[237],lf[235],lf[238],t2);}}

/* k7862 in number-hash in k7264 in k5746 in k1980 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7864,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[235]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t4=t3;
f_7878(t4,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_flonump(((C_word*)t0)[2]))){
t4=t3;
f_7878(t4,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(*((C_word*)lf[236]+1))));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7903,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1664 ##sys#number-hash-hook */
t5=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,*((C_word*)lf[236]+1));}}}

/* k7901 in k7862 in number-hash in k7264 in k5746 in k1980 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7878(t2,(C_word)C_fix(t1));}

/* k7876 in k7862 in number-hash in k7264 in k5746 in k1980 */
static void C_fcall f_7878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##sys#number-hash-hook in k7264 in k5746 in k1980 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7851,3,t0,t1,t2);}
/* extras.scm: 1650 %equal?-hash */
t3=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* binary-search in k7264 in k5746 in k1980 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7768,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7772,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7846,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1576 list->vector */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_7772(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[232]));}}

/* k7844 in binary-search in k7264 in k5746 in k1980 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7772(t3,t2);}

/* k7770 in binary-search in k7264 in k5746 in k1980 */
static void C_fcall f_7772(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7772,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7786,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7786(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k7770 in binary-search in k7264 in k5746 in k1980 */
static void C_fcall f_7786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7786,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_divide(t4,C_fix(2));
t6=(C_word)C_u_fixnum_plus(t2,t5);
t7=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7796,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1584 proc */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}

/* k7794 in loop in k7770 in binary-search in k7264 in k5746 in k1980 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1586 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7786(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1587 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7786(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k7264 in k5746 in k1980 */
static void C_ccall f_7741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7741,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7755,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7759,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1566 vector->list */
t6=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7766,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1567 append */
t5=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k7764 in sort in k7264 in k5746 in k1980 */
static void C_ccall f_7766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1567 sort! */
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7757 in sort in k7264 in k5746 in k1980 */
static void C_ccall f_7759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1566 sort! */
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7753 in sort in k7264 in k5746 in k1980 */
static void C_ccall f_7755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1566 list->vector */
t2=*((C_word*)lf[230]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k7264 in k5746 in k1980 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7608,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7611,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_fix((C_word)C_header_size(((C_word*)t4)[1]));
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7698,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1549 vector->list */
t11=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* extras.scm: 1555 step */
t9=((C_word*)t6)[1];
f_7611(t9,t1,t8);}}

/* k7696 in sort! in k7264 in k5746 in k1980 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7698,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1550 step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7611(t4,t3,((C_word*)t0)[2]);}

/* k7703 in k7696 in sort! in k7264 in k5746 in k1980 */
static void C_ccall f_7705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7705,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7707,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7707(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* do1204 in k7703 in k7696 in sort! in k7264 in k5746 in k1980 */
static void C_fcall f_7707(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7707,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_setslot(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k7264 in k5746 in k1980 */
static void C_fcall f_7611(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7611,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_u_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_u_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7652,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7662,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1534 less? */
t10=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_i_slot(t3,C_fix(1),C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k7660 in step in sort! in k7264 in k5746 in k1980 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(0),((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[3];
f_7652(t4,(C_word)C_i_setslot(t3,C_fix(0),((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_7652(t2,C_SCHEME_UNDEFINED);}}

/* k7650 in step in sort! in k7264 in k5746 in k1980 */
static void C_fcall f_7652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_i_set_i_slot(t2,C_fix(1),C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k7619 in step in sort! in k7264 in k5746 in k1980 */
static void C_ccall f_7621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1525 step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7611(t3,t2,t1);}

/* k7622 in k7619 in step in sort! in k7264 in k5746 in k1980 */
static void C_ccall f_7624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7624,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7630,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1527 step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7611(t4,t3,t2);}

/* k7628 in k7622 in k7619 in step in sort! in k7264 in k5746 in k1980 */
static void C_ccall f_7630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1528 merge! */
t2=*((C_word*)lf[228]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k7264 in k5746 in k1980 */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7476,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7479,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7558,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_u_i_car(t3);
t10=(C_word)C_u_i_car(t2);
/* extras.scm: 1502 less? */
t11=t4;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}}}

/* k7556 in merge! in k7264 in k5746 in k1980 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7558,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7561,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_7561(2,t4,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1505 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7479(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_7581(2,t4,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[4]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1510 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7479(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k7579 in k7556 in merge! in k7264 in k5746 in k1980 */
static void C_ccall f_7581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7559 in k7556 in merge! in k7264 in k5746 in k1980 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k7264 in k5746 in k1980 */
static void C_fcall f_7479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7479,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7486,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_u_i_car(t3);
/* extras.scm: 1487 less? */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k7484 in loop in merge! in k7264 in k5746 in k1980 */
static void C_ccall f_7486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[3]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1492 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7479(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[5]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1498 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7479(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k7264 in k5746 in k1980 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7377,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7411,a[2]=t4,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_7411(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k7264 in k5746 in k1980 */
static void C_fcall f_7411(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7411,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7418,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1470 less? */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,t2);}

/* k7416 in loop in merge in k7264 in k5746 in k1980 */
static void C_ccall f_7418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7418,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1473 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7411(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1477 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7411(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k7464 in k7416 in loop in merge in k7264 in k5746 in k1980 */
static void C_ccall f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7466,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7436 in k7416 in loop in merge in k7264 in k5746 in k1980 */
static void C_ccall f_7438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7438,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k7264 in k5746 in k1980 */
static void C_ccall f_7268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7268,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7295,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7295(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7343,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_7343(t9,t1,t4,t5);}}}

/* loop in sorted? in k7264 in k5746 in k1980 */
static void C_fcall f_7343(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7343,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7371,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t3);
/* extras.scm: 1453 less? */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* k7369 in loop in sorted? in k7264 in k5746 in k1980 */
static void C_ccall f_7371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1454 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7343(t4,((C_word*)t0)[4],t2,t3);}}

/* do1151 in sorted? in k7264 in k5746 in k1980 */
static void C_fcall f_7295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7295,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7305,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7305(2,t5,t3);}
else{
t5=(C_word)C_slot(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[3],t6);
/* extras.scm: 1447 less? */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t5,t7);}}

/* k7303 in do1151 in sorted? in k7264 in k5746 in k1980 */
static void C_ccall f_7305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7305,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_7295(t3,((C_word*)t0)[5],t2);}}

/* format in k5746 in k1980 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_7223r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7223r(t0,t1,t2,t3);}}

static void C_ccall f_7223r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(15);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7231,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
if(C_truep(t6)){
if(C_truep((C_word)C_booleanp(t2))){
t7=t5;
f_7231(2,t7,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_7231(2,t9,((C_word*)t0)[3]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7256,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1411 output-port? */
t8=*((C_word*)lf[225]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}}
else{
t7=t5;
f_7231(2,t7,((C_word*)t0)[3]);}}

/* k7254 in format in k5746 in k1980 */
static void C_ccall f_7256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7256,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_7231(2,t4,((C_word*)t0)[2]);}
else{
/* extras.scm: 1413 ##sys#error */
t2=*((C_word*)lf[38]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[223],lf[224],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}}

/* k7229 in format in k5746 in k1980 */
static void C_ccall f_7231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* sprintf in k5746 in k1980 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_7217r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7217r(t0,t1,t2,t3);}}

static void C_ccall f_7217r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 1401 fprintf0 */
t4=*((C_word*)lf[215]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[222],C_SCHEME_FALSE,t2,t3);}

/* printf in k5746 in k1980 */
static void C_ccall f_7211(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_7211r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7211r(t0,t1,t2,t3);}}

static void C_ccall f_7211r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 1398 fprintf0 */
t4=*((C_word*)lf[215]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[221],*((C_word*)lf[86]+1),t2,t3);}

/* fprintf in k5746 in k1980 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_7205r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7205r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* extras.scm: 1395 fprintf0 */
t5=*((C_word*)lf[215]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[220],t2,t3,t4);}

/* ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6907,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6911,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
/* extras.scm: 1345 ##sys#check-port */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,t2);}
else{
t7=t6;
f_6911(2,t7,C_SCHEME_UNDEFINED);}}

/* k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[10])){
/* extras.scm: 1346 ##sys#tty-port? */
t4=*((C_word*)lf[219]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}
else{
t4=t3;
f_7194(2,t4,C_SCHEME_FALSE);}}

/* k7192 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6914(2,t2,((C_word*)t0)[3]);}
else{
/* extras.scm: 1346 open-output-string */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6914,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6919,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6919(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_fcall f_6919(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6919,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_string_2(t2,((C_word*)t0)[9]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6928,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6935,a[2]=((C_word*)t0)[9],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6952,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=t13,a[10]=t9,a[11]=t8,a[12]=t7,tmp=(C_word)a,a+=13,tmp));
t15=((C_word*)t13)[1];
f_6980(t15,t11);}

/* loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_fcall f_6980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6980,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_6928(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6993,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
t5=(C_truep(t4)?(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=f_6928(((C_word*)t0)[10]);
t7=(C_word)C_u_i_char_upcase(t6);
switch(t7){
case C_make_character(83):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7018,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1367 next */
t9=((C_word*)t0)[6];
f_6935(t9,t8);
case C_make_character(65):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7031,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1368 next */
t9=((C_word*)t0)[6];
f_6935(t9,t8);
case C_make_character(67):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7044,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1369 next */
t9=((C_word*)t0)[6];
f_6935(t9,t8);
case C_make_character(66):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7057,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7061,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1370 next */
t10=((C_word*)t0)[6];
f_6935(t10,t9);
case C_make_character(79):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7078,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1371 next */
t10=((C_word*)t0)[6];
f_6935(t10,t9);
case C_make_character(88):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7095,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1372 next */
t10=((C_word*)t0)[6];
f_6935(t10,t9);
case C_make_character(33):
/* extras.scm: 1373 ##sys#flush-output */
t8=*((C_word*)lf[217]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t3,((C_word*)t0)[7]);
case C_make_character(63):
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7113,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1375 next */
t9=((C_word*)t0)[6];
f_6935(t9,t8);
case C_make_character(126):
/* extras.scm: 1379 ##sys#write-char-0 */
t8=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,C_make_character(126),((C_word*)t0)[7]);
default:
t8=(C_word)C_eqp(t7,C_make_character(37));
t9=(C_truep(t8)?t8:(C_word)C_eqp(t7,C_make_character(78)));
if(C_truep(t9)){
/* extras.scm: 1380 newline */
t10=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t6))){
t10=f_6928(((C_word*)t0)[10]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t12=t3;
f_6993(2,t12,f_7158(t11,t10));}
else{
/* extras.scm: 1387 ##sys#error */
t10=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t3,((C_word*)t0)[4],lf[218],t6);}}}}
else{
/* extras.scm: 1388 ##sys#write-char-0 */
t6=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t2,((C_word*)t0)[7]);}}}

/* skip in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static C_word C_fcall f_7158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_6928(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k7111 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7116,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1376 next */
t3=((C_word*)t0)[2];
f_6935(t3,t2);}

/* k7114 in k7111 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[5]);
/* extras.scm: 1378 rec */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6919(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7093 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1372 ##sys#number->string */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(16));}

/* k7089 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1372 display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7076 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1371 ##sys#number->string */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(8));}

/* k7072 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1371 display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7059 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1370 ##sys#number->string */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(2));}

/* k7055 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1370 display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7042 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1369 ##sys#write-char-0 */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7029 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1368 display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7016 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1367 write */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6991 in loop in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1389 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6980(t2,((C_word*)t0)[2]);}

/* k6950 in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6952,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1392 get-output-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}}
else{
/* extras.scm: 1390 get-output-string */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k6972 in k6950 in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1392 ##sys#print */
t2=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* next in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static void C_fcall f_6935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6935,NULL,2,t0,t1);}
if(C_truep((C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST))){
/* extras.scm: 1357 ##sys#error */
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],lf[216]);}
else{
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(0));
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in rec in k6912 in k6909 in ##extras#fprintf0 in k5746 in k1980 */
static C_word C_fcall f_6928(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* string-chomp in k5746 in k1980 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6862r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6862r(t0,t1,t2,t3);}}

static void C_ccall f_6862r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[213]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[212]);
t7=(C_word)C_i_check_string_2(t5,lf[212]);
t8=(C_word)C_block_size(t2);
t9=(C_word)C_block_size(t5);
t10=(C_word)C_u_fixnum_difference(t8,t9);
t11=(C_word)C_fixnum_greater_or_equal_p(t8,t9);
t12=(C_truep(t11)?(C_word)C_substring_compare(t2,t5,t10,C_fix(0),t9):C_SCHEME_FALSE);
if(C_truep(t12)){
/* extras.scm: 1332 ##sys#substring */
t13=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t1,t2,C_fix(0),t10);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t2);}}

/* string-chop in k5746 in k1980 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6798,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[211]);
t5=(C_word)C_i_check_exact_2(t3,lf[211]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6813,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_6813(t10,t1,t6,C_fix(0));}

/* loop in string-chop in k5746 in k1980 */
static void C_fcall f_6813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6813,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6833,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_fixnum_plus(t3,t2);
/* extras.scm: 1318 ##sys#substring */
t6=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6844,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
/* extras.scm: 1319 ##sys#substring */
t6=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k6842 in loop in string-chop in k5746 in k1980 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6848,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* extras.scm: 1319 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6813(t5,t2,t3,t4);}

/* k6846 in k6842 in loop in string-chop in k5746 in k1980 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6831 in loop in string-chop in k5746 in k1980 */
static void C_ccall f_6833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6833,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k5746 in k1980 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6676,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[209]);
t5=(C_word)C_i_check_list_2(t3,lf[209]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6688,a[2]=t3,a[3]=t8,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
/* extras.scm: 1307 collect */
t10=((C_word*)t8)[1];
f_6688(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k5746 in k1980 */
static void C_fcall f_6688(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6688,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6702,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6706,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6716,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1289 ##sys#substring */
t10=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_6706(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6721,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_6721(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k5746 in k1980 */
static void C_fcall f_6721(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6721,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1293 collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_6688(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6760,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6786,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1301 ##sys#substring */
t10=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_6760(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1306 loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k6784 in loop in collect in string-translate* in k5746 in k1980 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6786,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6760(t4,t3);}

/* k6758 in loop in collect in string-translate* in k5746 in k1980 */
static void C_fcall f_6760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6760,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* extras.scm: 1302 collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6688(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k6714 in collect in string-translate* in k5746 in k1980 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6716,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6706(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k6704 in collect in string-translate* in k5746 in k1980 */
static void C_fcall f_6706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1287 reverse */
t2=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6700 in collect in string-translate* in k5746 in k1980 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1285 ##sys#fragments->string */
t2=*((C_word*)lf[210]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k5746 in k1980 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_6474r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6474r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6477,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_6511(2,t7,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6651,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6668,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1243 list->string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_check_string_2(t3,lf[207]);
/* extras.scm: 1246 instring */
f_6477(t6,t3);}}}

/* k6666 in string-translate in k5746 in k1980 */
static void C_ccall f_6668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1243 instring */
f_6477(((C_word*)t0)[2],t1);}

/* f_6651 in string-translate in k5746 in k1980 */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6651,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k6509 in string-translate in k5746 in k1980 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_6514(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* extras.scm: 1251 list->string */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t4=(C_word)C_i_check_string_2(t3,lf[207]);
t5=t2;
f_6514(2,t5,t3);}}}
else{
t3=t2;
f_6514(2,t3,C_SCHEME_FALSE);}}

/* k6512 in k6509 in string-translate in k5746 in k1980 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[207]);
t5=(C_word)C_block_size(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1258 make-string */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k6524 in k6512 in k6509 in string-translate in k5746 in k1980 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6526,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6531(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k6524 in k6512 in k6509 in string-translate in k5746 in k1980 */
static void C_fcall f_6531(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6531,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* extras.scm: 1262 ##sys#substring */
t4=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[7],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[6],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6550,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 1265 from */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k6548 in loop in k6524 in k6512 in k6509 in string-translate in k5746 in k1980 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[9];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1272 loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6531(t7,((C_word*)t0)[4],t5,t6);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
/* extras.scm: 1274 ##sys#error */
t4=*((C_word*)lf[38]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[207],lf[208],((C_word*)t0)[6],((C_word*)t0)[9]);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],(C_word)C_subchar(((C_word*)t0)[9],t1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1277 loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6531(t7,((C_word*)t0)[4],t5,t6);}}}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1269 loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_6531(t5,((C_word*)t0)[4],t4,((C_word*)t0)[7]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1268 loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_6531(t6,((C_word*)t0)[4],t4,t5);}}

/* instring in string-translate in k5746 in k1980 */
static void C_fcall f_6477(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6477,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6482,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_6482 in instring in string-translate in k5746 in k1980 */
static void C_ccall f_6482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6482,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6488(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_6488(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k5746 in k1980 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6366r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6366r(t0,t1,t2,t3);}}

static void C_ccall f_6366r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[203]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_list_2(t2,lf[202]);
t7=(C_word)C_i_check_string_2(t5,lf[202]);
t8=(C_word)C_block_size(t5);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6384,a[2]=t10,a[3]=t8,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6384(t12,t1,t2,C_fix(0));}

/* loop1 in string-intersperse in k5746 in k1980 */
static void C_fcall f_6384(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6384,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[204]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6394,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[3]);
/* extras.scm: 1206 ##sys#allocate-vector */
t6=*((C_word*)lf[205]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_i_check_string_2(t5,lf[202]);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t5);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t3);
t10=(C_word)C_u_fixnum_plus(t8,t9);
/* extras.scm: 1221 loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* extras.scm: 1223 ##sys#not-a-proper-list-error */
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k6392 in loop1 in string-intersperse in k5746 in k1980 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_6399(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k6392 in loop1 in string-intersperse in k5746 in k1980 */
static C_word C_fcall f_6399(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_u_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_u_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k5746 in k1980 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6231r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6231r(t0,t1,t2,t3);}}

static void C_ccall f_6231r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(18);
t4=(C_word)C_i_check_string_2(t2,lf[200]);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?lf[201]:(C_word)C_slot(t3,C_fix(0)));
t7=(C_word)C_block_size(t3);
t8=(C_word)C_eqp(t7,C_fix(2));
t9=(C_truep(t8)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_string_2(t6,lf[200]);
t12=(C_word)C_block_size(t6);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6252,a[2]=t2,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6272,a[2]=t6,a[3]=t17,a[4]=t12,a[5]=t2,a[6]=t15,a[7]=t9,a[8]=t14,a[9]=t10,tmp=(C_word)a,a+=10,tmp));
t19=((C_word*)t17)[1];
f_6272(t19,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k5746 in k1980 */
static void C_fcall f_6272(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6272,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* extras.scm: 1182 add */
t8=((C_word*)t0)[6];
f_6252(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_6282(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6299,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp));
t9=((C_word*)t7)[1];
f_6299(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k5746 in k1980 */
static void C_fcall f_6299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6299,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* extras.scm: 1187 loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_6272(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6338,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1191 add */
t8=((C_word*)t0)[3];
f_6252(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* extras.scm: 1192 loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_6272(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* extras.scm: 1193 scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k6336 in scan in loop in string-split in k5746 in k1980 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1191 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6272(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k6280 in loop in string-split in k5746 in k1980 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k5746 in k1980 */
static void C_fcall f_6252(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6252,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6267,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1175 ##sys#substring */
t6=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k6265 in add in string-split in k5746 in k1980 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6267,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6259,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_6259(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_6259(t5,t4);}}

/* k6257 in k6265 in add in string-split in k5746 in k1980 */
static void C_fcall f_6259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k5746 in k1980 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_6154r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6154r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6156,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6161,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6166,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6171,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1941954 */
t9=t8;
f_6171(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2942952 */
t11=t7;
f_6166(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len943949 */
t13=t6;
f_6161(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body939945 */
t15=t5;
f_6156(t15,t1,t9,t11,t13);}}}}

/* def-start1941 in substring-ci=? in k5746 in k1980 */
static void C_fcall f_6171(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6171,NULL,2,t0,t1);}
/* def-start2942952 */
t2=((C_word*)t0)[2];
f_6166(t2,t1,C_fix(0));}

/* def-start2942 in substring-ci=? in k5746 in k1980 */
static void C_fcall f_6166(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6166,NULL,3,t0,t1,t2);}
/* def-len943949 */
t3=((C_word*)t0)[2];
f_6161(t3,t1,t2,C_fix(0));}

/* def-len943 in substring-ci=? in k5746 in k1980 */
static void C_fcall f_6161(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6161,NULL,4,t0,t1,t2,t3);}
/* body939945 */
t4=((C_word*)t0)[2];
f_6156(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body939 in substring-ci=? in k5746 in k1980 */
static void C_fcall f_6156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6156,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 1160 ##sys#substring-ci=? */
t5=*((C_word*)lf[198]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring-ci=? in k5746 in k1980 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6117,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[199]);
t8=(C_word)C_i_check_string_2(t3,lf[199]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6127,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_6127(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_u_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_u_fixnum_difference(t12,t5);
t14=t9;
f_6127(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k6125 in ##sys#substring-ci=? in k5746 in k1980 */
static void C_fcall f_6127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[199]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[199]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* substring=? in k5746 in k1980 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_6040r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6040r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6040r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6042,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6047,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6052,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6057,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1900913 */
t9=t8;
f_6057(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2901911 */
t11=t7;
f_6052(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len902908 */
t13=t6;
f_6047(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body898904 */
t15=t5;
f_6042(t15,t1,t9,t11,t13);}}}}

/* def-start1900 in substring=? in k5746 in k1980 */
static void C_fcall f_6057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6057,NULL,2,t0,t1);}
/* def-start2901911 */
t2=((C_word*)t0)[2];
f_6052(t2,t1,C_fix(0));}

/* def-start2901 in substring=? in k5746 in k1980 */
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6052,NULL,3,t0,t1,t2);}
/* def-len902908 */
t3=((C_word*)t0)[2];
f_6047(t3,t1,t2,C_fix(0));}

/* def-len902 in substring=? in k5746 in k1980 */
static void C_fcall f_6047(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6047,NULL,4,t0,t1,t2,t3);}
/* body898904 */
t4=((C_word*)t0)[2];
f_6042(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body898 in substring=? in k5746 in k1980 */
static void C_fcall f_6042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6042,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 1146 ##sys#substring=? */
t5=*((C_word*)lf[196]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring=? in k5746 in k1980 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6003,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[197]);
t8=(C_word)C_i_check_string_2(t3,lf[197]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6013,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_6013(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_u_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_u_fixnum_difference(t12,t5);
t14=t9;
f_6013(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k6011 in ##sys#substring=? in k5746 in k1980 */
static void C_fcall f_6013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[197]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[197]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* string-compare3-ci in k5746 in k1980 */
static void C_ccall f_5972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5972,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[195]);
t5=(C_word)C_i_check_string_2(t3,lf[195]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_u_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_string_compare_case_insensitive(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* string-compare3 in k5746 in k1980 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5941,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[194]);
t5=(C_word)C_i_check_string_2(t3,lf[194]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_u_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_mem_compare(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* substring-index-ci in k5746 in k1980 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5920r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5920r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5920r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
/* extras.scm: 1105 ##sys#substring-index-ci */
t7=*((C_word*)lf[192]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t3,t6);}

/* substring-index in k5746 in k1980 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5899r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5899r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5899r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
/* extras.scm: 1102 ##sys#substring-index */
t7=*((C_word*)lf[190]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t3,t6);}

/* ##sys#substring-index-ci in k5746 in k1980 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5890,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5896,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1096 traverse */
f_5834(t1,t2,t3,t4,t5,lf[193]);}

/* a5895 in ##sys#substring-index-ci in k5746 in k1980 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5896,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* ##sys#substring-index in k5746 in k1980 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5881,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5887,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1090 traverse */
f_5834(t1,t2,t3,t4,t5,lf[191]);}

/* a5886 in ##sys#substring-index in k5746 in k1980 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5887,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k5746 in k1980 */
static void C_fcall f_5834(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5834,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,t6);
t8=(C_word)C_i_check_string_2(t3,t6);
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_exact_2(t4,t6);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5855,a[2]=t10,a[3]=t5,a[4]=t13,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_5855(t15,t1,t4,t10);}

/* loop in traverse in k5746 in k1980 */
static void C_fcall f_5855(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5855,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1084 test */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k5866 in loop in traverse in k5746 in k1980 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1086 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5855(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k5746 in k1980 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5824r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5824r(t0,t1,t2);}}

static void C_ccall f_5824r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5832,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[187]+1),t2);}

/* k5830 in conc in k5746 in k1980 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k5746 in k1980 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5779,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* extras.scm: 1059 symbol->string */
t3=*((C_word*)lf[188]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
/* extras.scm: 1060 string */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* extras.scm: 1061 ##sys#number->string */
t3=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5816,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1063 open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}}}

/* k5814 in ->string in k5746 in k1980 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5819,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1064 display */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5817 in k5814 in ->string in k5746 in k1980 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1065 get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pretty-print in k5746 in k1980 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5750r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5750r(t0,t1,t2,t3);}}

static void C_ccall f_5750r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5754,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_5754(2,t5,(C_word)C_slot(t3,C_fix(0)));}
else{
/* extras.scm: 1043 current-output-port */
t5=*((C_word*)lf[185]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5752 in pretty-print in k5746 in k1980 */
static void C_ccall f_5754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5757,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1044 pretty-print-width */
t4=*((C_word*)lf[183]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5759 in k5752 in pretty-print in k5746 in k1980 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5763,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1044 generic-write */
t3=*((C_word*)lf[110]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a5762 in k5759 in k5752 in pretty-print in k5746 in k1980 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5763,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5767,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1044 display */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k5765 in a5762 in k5759 in k5752 in pretty-print in k5746 in k1980 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k5755 in k5752 in pretty-print in k5746 in k1980 */
static void C_ccall f_5757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##extras#reverse-string-append in k1980 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5669,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5672,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
/* extras.scm: 1035 rev-string-append */
t6=((C_word*)t4)[1];
f_5672(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##extras#reverse-string-append in k1980 */
static void C_fcall f_5672(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5672,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5688,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* extras.scm: 1026 rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* extras.scm: 1033 make-string */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k5686 in rev-string-append in ##extras#reverse-string-append in k1980 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5697,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5697(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k5686 in rev-string-append in ##extras#reverse-string-append in k1980 */
static void C_fcall f_5697(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5697,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_subchar(((C_word*)t0)[4],t2);
t5=(C_word)C_setsubchar(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* extras.scm: 1031 loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* ##extras#generic-write in k1980 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4397,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4400,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4452,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4458,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4491,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4510,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t9,a[9]=t11,tmp=(C_word)a,a+=10,tmp));
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5013,a[2]=t6,a[3]=t8,a[4]=t7,a[5]=t11,a[6]=t4,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5660,a[2]=t2,a[3]=t13,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1015 make-string */
t15=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(1),C_make_character(10));}
else{
/* extras.scm: 1016 wr */
t14=((C_word*)t11)[1];
f_4510(t14,t1,t2,C_fix(0));}}

/* k5658 in ##extras#generic-write in k1980 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5664,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1015 pp */
t3=((C_word*)t0)[3];
f_5013(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5662 in k5658 in ##extras#generic-write in k1980 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1015 out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in ##extras#generic-write in k1980 */
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[133],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5013,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[8],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[8],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t41=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5168,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp));
t42=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5233,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t43=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[8],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t44=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5270,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t45=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t9,a[6]=t17,tmp=(C_word)a,a+=7,tmp));
t46=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5495,a[2]=t11,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t47=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5501,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t48=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=t11,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t49=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5513,a[2]=t21,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t50=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5519,a[2]=t21,a[3]=t11,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t51=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5525,a[2]=t11,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t52=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5531,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t53=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5553,a[2]=t11,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t54=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5559,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t55=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5568,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,tmp=(C_word)a,a+=10,tmp));
/* extras.scm: 1012 pr */
t56=((C_word*)t9)[1];
f_5081(t56,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5568,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[170]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_5578(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[180]);
if(C_truep(t5)){
t6=t4;
f_5578(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[181]);
t7=t4;
f_5578(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[182])));}}}

/* k5576 in style in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[171]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[172]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[173]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[174]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[176]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[178]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[179]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5559,5,t0,t1,t2,t3,t4);}
/* extras.scm: 990  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5347(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5553,5,t0,t1,t2,t3,t4);}
/* extras.scm: 987  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5347(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5531,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_u_i_car(t5);
t8=t6;
f_5538(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5538(t7,C_SCHEME_FALSE);}}

/* k5536 in pp-let in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 984  pp-general */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5347(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-and in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5525,5,t0,t1,t2,t3,t4);}
/* extras.scm: 979  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5233(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5519,5,t0,t1,t2,t3,t4);}
/* extras.scm: 976  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5347(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5513,5,t0,t1,t2,t3,t4);}
/* extras.scm: 973  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5233(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5507,5,t0,t1,t2,t3,t4);}
/* extras.scm: 970  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5347(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5501,5,t0,t1,t2,t3,t4);}
/* extras.scm: 967  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5347(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5495,5,t0,t1,t2,t3,t4);}
/* extras.scm: 964  pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5261(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5347(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5347,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5432,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5391,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,a[5]=t4,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_u_i_car(t2);
t13=(C_word)C_slot(t2,C_fix(1));
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,a[6]=t3,a[7]=t13,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5493,a[2]=t12,a[3]=t14,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 955  out */
t16=((C_word*)t0)[2];
f_4491(t16,t15,lf[169],t3);}

/* k5491 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 955  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4510(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5443 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5460,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5475,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 959  out */
t7=((C_word*)t0)[2];
f_4491(t7,t6,lf[168],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 961  tail1 */
t5=((C_word*)t0)[5];
f_5350(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k5473 in k5443 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 959  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4510(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5458 in k5443 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5460,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 960  tail1 */
t4=((C_word*)t0)[4];
f_5350(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail1 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5350(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5350,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5373,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 939  indent */
t13=((C_word*)t0)[2];
f_5049(t13,t12,t5,t4);}
else{
/* extras.scm: 940  tail2 */
t7=((C_word*)t0)[4];
f_5391(t7,t1,t2,t3,t4,t5);}}

/* k5375 in tail1 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 939  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5081(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5371 in tail1 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 939  tail2 */
t2=((C_word*)t0)[6];
f_5391(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5391(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5391,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5414,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 947  indent */
t13=((C_word*)t0)[2];
f_5049(t13,t12,t5,t4);}
else{
/* extras.scm: 948  tail3 */
t7=((C_word*)t0)[4];
f_5432(t7,t1,t2,t3,t4);}}

/* k5416 in tail2 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 947  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5081(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5412 in tail2 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 947  tail3 */
t2=((C_word*)t0)[5];
f_5432(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail3 in pp-general in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5432(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5432,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 951  pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5270(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-down in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5270(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5270,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5276,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_5276(t10,t1,t2,t3);}

/* loop in pp-down in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5276(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5276,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5299,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_u_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 922  indent */
t10=((C_word*)t0)[4];
f_5049(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 924  out */
t4=((C_word*)t0)[2];
f_4491(t4,t1,lf[165],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5329,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5345,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 928  indent */
t8=((C_word*)t0)[4];
f_5049(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5343 in loop in pp-down in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 928  out */
t2=((C_word*)t0)[3];
f_4491(t2,((C_word*)t0)[2],lf[167],t1);}

/* k5339 in loop in pp-down in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 928  indent */
t2=((C_word*)t0)[4];
f_5049(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5331 in loop in pp-down in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm: 927  pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5081(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5327 in loop in pp-down in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 926  out */
t2=((C_word*)t0)[3];
f_4491(t2,((C_word*)t0)[2],lf[166],t1);}

/* k5305 in loop in pp-down in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 922  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5081(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5297 in loop in pp-down in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 921  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5276(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5261(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5261,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5265,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 912  out */
t7=((C_word*)t0)[2];
f_4491(t7,t6,lf[164],t3);}

/* k5263 in pp-list in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 913  pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5270(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5233(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5233,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5237,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_u_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5259,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 904  out */
t9=((C_word*)t0)[2];
f_4491(t9,t8,lf[163],t3);}

/* k5257 in pp-call in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 904  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4510(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5235 in pp-call in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5237,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 906  pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5270(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5168,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* extras.scm: 884  read-macro? */
f_4400(t5,t2);}

/* k5173 in pp-expr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
if(C_truep(t1)){
t2=f_4452(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t4=f_4458(((C_word*)t0)[13]);
/* extras.scm: 886  out */
t5=((C_word*)t0)[7];
f_4491(t5,t3,t4,((C_word*)t0)[6]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5202,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 891  style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5568(t4,t3,t2);}
else{
/* extras.scm: 898  pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5261(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k5200 in k5173 in pp-expr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm: 893  proc */
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 894  ##sys#symbol->qualified-string */
t3=*((C_word*)lf[162]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k5226 in k5200 in k5173 in pp-expr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
/* extras.scm: 896  pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_5347(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm: 897  pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5233(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k5184 in k5173 in pp-expr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 885  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5081(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5081(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5081,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5094,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm: 870  max */
t14=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t13,C_fix(50));}
else{
/* extras.scm: 881  wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4510(t8,t1,t2,t3);}}

/* k5092 in pr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5094,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5132,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 871  generic-write */
t6=*((C_word*)lf[110]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a5131 in k5092 in pr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5132,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k5095 in k5092 in pr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5097,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5110,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 877  reverse-string-append */
t3=*((C_word*)lf[159]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm: 879  pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 880  vector->list */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k5124 in k5095 in k5092 in pr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 880  out */
t3=((C_word*)t0)[3];
f_4491(t3,t2,lf[160],((C_word*)t0)[2]);}

/* k5128 in k5124 in k5095 in k5092 in pr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 880  pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5261(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k5108 in k5095 in k5092 in pr in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 877  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5049,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5065,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5072,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 864  make-string */
t6=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
/* extras.scm: 865  spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5016(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5070 in indent in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 864  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5063 in indent in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 864  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5016(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in ##extras#generic-write in k1980 */
static void C_fcall f_5016(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5016,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5040,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 857  out */
t6=((C_word*)t0)[2];
f_4491(t6,t5,lf[157],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5047,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 858  ##sys#substring */
t5=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[158],C_fix(0),t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5045 in spaces in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 858  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5038 in spaces in pp in ##extras#generic-write in k1980 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 857  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5016(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in ##extras#generic-write in k1980 */
static void C_fcall f_4510(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4510,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
/* extras.scm: 790  wr-expr */
t6=t5;
f_4513(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 791  wr-lst */
t6=t4;
f_4540(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
/* extras.scm: 792  out */
t6=((C_word*)t0)[8];
f_4491(t6,t1,lf[125],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4666,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 793  vector->list */
t7=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=(C_truep(t2)?lf[128]:lf[129]);
/* extras.scm: 794  out */
t7=((C_word*)t0)[8];
f_4491(t7,t1,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 795  ##sys#number? */
t7=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}}}}}

/* k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4696,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 795  ##sys#number->string */
t3=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 797  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 800  ##sys#procedure->string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 802  out */
t2=((C_word*)t0)[8];
f_4491(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 803  out */
t3=((C_word*)t0)[8];
f_4491(t3,t2,lf[135],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 817  make-string */
t3=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 819  out */
t4=((C_word*)t0)[8];
f_4491(t4,t3,lf[140],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
/* extras.scm: 830  out */
t2=((C_word*)t0)[8];
f_4491(t2,((C_word*)t0)[7],lf[141],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
/* extras.scm: 831  out */
t2=((C_word*)t0)[8];
f_4491(t2,((C_word*)t0)[7],lf[142],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 832  ##sys#pointer->string */
t3=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(lf[4],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* extras.scm: 834  out */
t4=((C_word*)t0)[8];
f_4491(t4,((C_word*)t0)[7],lf[144],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 836  open-output-string */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 839  port? */
t5=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}}}}}}}}}}

/* k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4955,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm: 839  string-append */
t4=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[147],t3,lf[148]);}
else{
if(C_truep((C_word)C_bytevectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[2]))){
/* extras.scm: 842  out */
t3=((C_word*)t0)[5];
f_4491(t3,t2,lf[150],((C_word*)t0)[3]);}
else{
/* extras.scm: 843  out */
t3=((C_word*)t0)[5];
f_4491(t3,t2,lf[151],((C_word*)t0)[3]);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 847  out */
t3=((C_word*)t0)[5];
f_4491(t3,t2,lf[154],((C_word*)t0)[3]);}
else{
/* extras.scm: 850  out */
t2=((C_word*)t0)[5];
f_4491(t2,((C_word*)t0)[4],lf[155],((C_word*)t0)[3]);}}}}

/* k4992 in k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 848  ##sys#lambda-info->string */
t4=*((C_word*)lf[153]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5002 in k4992 in k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 848  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4995 in k4992 in k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 849  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],lf[152],((C_word*)t0)[2]);}

/* k4970 in k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 844  number->string */
C_number_to_string(3,0,t3,(C_word)C_block_size(((C_word*)t0)[2]));}

/* k4980 in k4970 in k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 844  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4973 in k4970 in k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 845  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],lf[149],((C_word*)t0)[2]);}

/* k4960 in k4953 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 839  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4937 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4942,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 837  ##sys#user-print-hook */
t3=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k4940 in k4937 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 838  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4947 in k4940 in k4937 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 838  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4919 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 832  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4835 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 820  char-name */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4838 in k4835 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
/* extras.scm: 822  out */
t3=((C_word*)t0)[6];
f_4491(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 824  out */
t3=((C_word*)t0)[6];
f_4491(t3,t2,lf[136],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535));
t4=(C_truep(t3)?lf[137]:lf[138]);
/* extras.scm: 827  out */
t5=((C_word*)t0)[6];
f_4491(t5,t2,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 829  make-string */
t3=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k4894 in k4838 in k4835 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 829  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4873 in k4838 in k4835 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 828  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k4880 in k4873 in k4838 in k4835 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 828  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4857 in k4838 in k4835 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 825  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k4864 in k4857 in k4838 in k4835 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 825  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4829 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 817  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4749,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4749(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_fcall f_4749(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4749,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4756,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t7=t5;
f_4756(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_4756(t6,C_SCHEME_FALSE);}}

/* k4754 in loop in k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_fcall f_4756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4756,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_subchar(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4779,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4783,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 811  ##sys#substring */
t9=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm: 813  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4749(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4804,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 815  ##sys#substring */
t4=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k4806 in k4754 in loop in k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 815  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4802 in k4754 in loop in k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 814  out */
t2=((C_word*)t0)[3];
f_4491(t2,((C_word*)t0)[2],lf[134],t1);}

/* k4785 in k4754 in loop in k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 811  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4781 in k4754 in loop in k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 810  out */
t2=((C_word*)t0)[3];
f_4491(t2,((C_word*)t0)[2],lf[133],t1);}

/* k4777 in k4754 in loop in k4745 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 808  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4749(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4726 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 800  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4703 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4708,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 798  ##sys#print */
t3=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k4706 in k4703 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 799  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4713 in k4706 in k4703 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 799  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4694 in k4687 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 795  out */
t2=((C_word*)t0)[4];
f_4491(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4664 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4670,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 793  out */
t3=((C_word*)t0)[3];
f_4491(t3,t2,lf[126],((C_word*)t0)[2]);}

/* k4668 in k4664 in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 793  wr-lst */
t2=((C_word*)t0)[4];
f_4540(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in ##extras#generic-write in k1980 */
static void C_fcall f_4513(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4513,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 775  read-macro? */
f_4400(t4,t2);}

/* k4518 in wr-expr in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
if(C_truep(t1)){
t2=f_4452(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4531,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=f_4458(((C_word*)t0)[8]);
/* extras.scm: 776  out */
t5=((C_word*)t0)[4];
f_4491(t5,t3,t4,((C_word*)t0)[3]);}
else{
/* extras.scm: 777  wr-lst */
t2=((C_word*)t0)[2];
f_4540(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k4529 in k4518 in wr-expr in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 776  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4510(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in ##extras#generic-write in k1980 */
static void C_fcall f_4540(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4540,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4558,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4623,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 782  out */
t8=((C_word*)t0)[2];
f_4491(t8,t7,lf[123],t3);}
else{
t6=t5;
f_4558(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm: 788  out */
t4=((C_word*)t0)[2];
f_4491(t4,t1,lf[124],t3);}}

/* k4621 in wr-lst in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 782  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4510(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4556 in wr-lst in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4560(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4556 in wr-lst in wr in ##extras#generic-write in k1980 */
static void C_fcall f_4560(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4560,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4584,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4592,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 785  out */
t9=((C_word*)t0)[2];
f_4491(t9,t8,lf[119],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 786  out */
t5=((C_word*)t0)[2];
f_4491(t5,t1,lf[120],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4612,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 787  out */
t7=((C_word*)t0)[2];
f_4491(t7,t6,lf[122],t3);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* k4610 in loop in k4556 in wr-lst in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 787  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4510(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4606 in loop in k4556 in wr-lst in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 787  out */
t2=((C_word*)t0)[3];
f_4491(t2,((C_word*)t0)[2],lf[121],t1);}

/* k4590 in loop in k4556 in wr-lst in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 785  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4510(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4582 in loop in k4556 in wr-lst in wr in ##extras#generic-write in k1980 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 785  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4560(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in ##extras#generic-write in k1980 */
static void C_fcall f_4491(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4491,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4501,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 770  output */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4499 in out in ##extras#generic-write in k1980 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4501,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in ##extras#generic-write in k1980 */
static C_word C_fcall f_4458(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_eqp(t2,lf[111]);
if(C_truep(t4)){
return(lf[115]);}
else{
t5=(C_word)C_eqp(t2,lf[112]);
if(C_truep(t5)){
return(lf[116]);}
else{
t6=(C_word)C_eqp(t2,lf[113]);
if(C_truep(t6)){
return(lf[117]);}
else{
t7=(C_word)C_eqp(t2,lf[114]);
return((C_truep(t7)?lf[118]:C_SCHEME_UNDEFINED));}}}}

/* read-macro-body in ##extras#generic-write in k1980 */
static C_word C_fcall f_4452(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_u_i_cadr(t1));}

/* read-macro? in ##extras#generic-write in k1980 */
static void C_fcall f_4400(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4400,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(t3,lf[111]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4432,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_4432(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[112]);
if(C_truep(t7)){
t8=t6;
f_4432(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[113]);
t9=t6;
f_4432(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[114])));}}}

/* k4430 in read-macro? in ##extras#generic-write in k1980 */
static void C_fcall f_4432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* make-output-port in k1980 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+29)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4333r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4333r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4333r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(29);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4361,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4367,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4376,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_vector(&a,9,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,t8,t9,t10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t12=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4346,a[2]=t1,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 732  ##sys#make-port */
t14=*((C_word*)lf[104]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,C_SCHEME_FALSE,t11,lf[109],lf[106]);}

/* k4344 in make-output-port in k1980 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4375 in make-output-port in k1980 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4376,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 727  flush */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a4366 in make-output-port in k1980 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4367,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 724  close */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4369 in a4366 in make-output-port in k1980 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a4360 in make-output-port in k1980 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4361,4,t0,t1,t2,t3);}
/* extras.scm: 722  write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a4350 in make-output-port in k1980 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4351,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 720  string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k4357 in a4350 in make-output-port in k1980 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 720  write */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-input-port in k1980 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr5r,(void*)f_4190r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4190r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(14);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4192,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4263,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4268,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4273,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-peek500527 */
t10=t9;
f_4273(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-read-string501525 */
t12=t8;
f_4268(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-read-line502522 */
t14=t7;
f_4263(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body498504 */
t16=t6;
f_4192(t16,t1,t10,t12,t14);}}}}

/* def-peek500 in make-input-port in k1980 */
static void C_fcall f_4273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4273,NULL,2,t0,t1);}
/* def-read-string501525 */
t2=((C_word*)t0)[2];
f_4268(t2,t1,C_SCHEME_FALSE);}

/* def-read-string501 in make-input-port in k1980 */
static void C_fcall f_4268(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4268,NULL,3,t0,t1,t2);}
/* def-read-line502522 */
t3=((C_word*)t0)[2];
f_4263(t3,t1,t2,C_SCHEME_FALSE);}

/* def-read-line502 in make-input-port in k1980 */
static void C_fcall f_4263(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4263,NULL,4,t0,t1,t2,t3);}
/* body498504 */
t4=((C_word*)t0)[2];
f_4192(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body498 in make-input-port in k1980 */
static void C_fcall f_4192(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4192,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4258,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_vector(&a,9,t5,t6,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,C_SCHEME_FALSE,t8,t3,t4);
t10=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4202,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 708  ##sys#make-port */
t12=*((C_word*)lf[104]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t11,C_SCHEME_TRUE,t9,lf[105],lf[106]);}

/* k4200 in body498 in make-input-port in k1980 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4257 in body498 in make-input-port in k1980 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4258,3,t0,t1,t2);}
/* extras.scm: 704  ready? */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4248 in body498 in make-input-port in k1980 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4249,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4253,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 700  close */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4251 in a4248 in body498 in make-input-port in k1980 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a4227 in body498 in make-input-port in k1980 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4228,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 691  peek */
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4244,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 694  read */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

/* k4242 in a4227 in body498 in make-input-port in k1980 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(10),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4206 in body498 in make-input-port in k1980 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4207,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 684  read */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=(C_word)C_i_set_i_slot(t2,C_fix(10),C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* extras.scm: 688  read */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}}}

/* with-output-to-string in k1980 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4156,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4160,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 667  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4158 in with-output-to-string in k1980 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4182,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a4181 in k4158 in with-output-to-string in k1980 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[86]+1));
t3=C_mutate((C_word*)lf[86]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a4172 in k4158 in with-output-to-string in k1980 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4177,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 668  thunk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4175 in a4172 in k4158 in with-output-to-string in k1980 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 669  get-output-string */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[86]+1));}

/* a4164 in k4158 in with-output-to-string in k1980 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[86]+1));
t3=C_mutate((C_word*)lf[86]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* with-input-from-string in k1980 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4125,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 660  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4127 in with-input-from-string in k1980 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4134,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4148,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a4147 in k4127 in with-input-from-string in k1980 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[10]+1));
t3=C_mutate((C_word*)lf[10]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a4141 in k4127 in with-input-from-string in k1980 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
/* extras.scm: 661  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a4133 in k4127 in with-input-from-string in k1980 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[10]+1));
t3=C_mutate((C_word*)lf[10]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* call-with-output-string in k1980 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4113,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4117,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 653  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4115 in call-with-output-string in k1980 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4120,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 654  proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4118 in k4115 in call-with-output-string in k1980 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 655  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-input-string in k1980 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4104,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4108,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 646  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4106 in call-with-input-string in k1980 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 647  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* with-error-output-to-port in k1980 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4073,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4077,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 636  ##sys#check-port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[97]);}

/* k4075 in with-error-output-to-port in k1980 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4082,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4096,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 637  ##sys#dynamic-wind */
t9=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a4095 in k4075 in with-error-output-to-port in k1980 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[96]+1));
t3=C_mutate((C_word*)lf[96]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a4089 in k4075 in with-error-output-to-port in k1980 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
/* extras.scm: 638  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a4081 in k4075 in with-error-output-to-port in k1980 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[96]+1));
t3=C_mutate((C_word*)lf[96]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* with-output-to-port in k1980 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4042,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4046,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 631  ##sys#check-port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[94]);}

/* k4044 in with-output-to-port in k1980 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4051,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4065,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 632  ##sys#dynamic-wind */
t9=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a4064 in k4044 in with-output-to-port in k1980 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[86]+1));
t3=C_mutate((C_word*)lf[86]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a4058 in k4044 in with-output-to-port in k1980 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
/* extras.scm: 633  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a4050 in k4044 in with-output-to-port in k1980 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[86]+1));
t3=C_mutate((C_word*)lf[86]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* with-input-from-port in k1980 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4011,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4015,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 626  ##sys#check-port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[91]);}

/* k4013 in with-input-from-port in k1980 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4034,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 627  ##sys#dynamic-wind */
t9=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a4033 in k4013 in with-input-from-port in k1980 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[10]+1));
t3=C_mutate((C_word*)lf[10]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a4027 in k4013 in with-input-from-port in k1980 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
/* extras.scm: 628  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a4019 in k4013 in with-input-from-port in k1980 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[10]+1));
t3=C_mutate((C_word*)lf[10]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* write-byte in k1980 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3980r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3980r(t0,t1,t2,t3);}}

static void C_ccall f_3980r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[86]+1):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t2,lf[90]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3990,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 619  ##sys#check-port */
t8=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,lf[90]);}

/* k3988 in write-byte in k1980 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[4]));
/* extras.scm: 620  ##sys#write-char-0 */
t3=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* read-byte in k1980 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3947r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3947r(t0,t1,t2);}}

static void C_ccall f_3947r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?*((C_word*)lf[10]+1):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 611  ##sys#check-port */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[89]);}

/* k3952 in read-byte in k1980 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 612  ##sys#read-char-0 */
t3=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3955 in k3952 in read-byte in k1980 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t1:(C_word)C_fix((C_word)C_character_code(t1))));}

/* write-line in k1980 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3926r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3926r(t0,t1,t2,t3);}}

static void C_ccall f_3926r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[86]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 602  ##sys#check-port */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[88]);}

/* k3931 in write-line in k1980 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[88]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 604  display */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k3937 in k3931 in write-line in k1980 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 605  newline */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k1980 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3840r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3840r(t0,t1,t2,t3);}}

static void C_ccall f_3840r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[85]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3845,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3876,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* extras.scm: 586  def-n386 */
t8=t7;
f_3881(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* extras.scm: 586  def-port387 */
t10=t6;
f_3876(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* extras.scm: 586  body384 */
t12=t5;
f_3845(t12,t1,t8,t10);}}}

/* def-n386 in write-string in k1980 */
static void C_fcall f_3881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3881,NULL,2,t0,t1);}
/* extras.scm: 586  def-port387 */
t2=((C_word*)t0)[2];
f_3876(t2,t1,C_SCHEME_FALSE);}

/* def-port387 in write-string in k1980 */
static void C_fcall f_3876(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3876,NULL,3,t0,t1,t2);}
/* extras.scm: 586  body384 */
t3=((C_word*)t0)[2];
f_3845(t3,t1,t2,*((C_word*)lf[86]+1));}

/* body384 in write-string in k1980 */
static void C_fcall f_3845(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3845,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 587  ##sys#check-port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[85]);}

/* k3847 in body384 in write-string in k1980 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[85]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3862,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(C_word)C_block_size(((C_word*)t0)[2]);
t6=t4;
f_3862(t6,(C_word)C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_3862(t5,C_SCHEME_FALSE);}}

/* k3860 in k3847 in body384 in write-string in k1980 */
static void C_fcall f_3862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 591  ##sys#substring */
t2=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3859(2,t2,((C_word*)t0)[3]);}}

/* k3857 in k3847 in body384 in write-string in k1980 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 589  display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k1980 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3778r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3778r(t0,t1,t2,t3);}}

static void C_ccall f_3778r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[10]+1):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3785,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 572  ##sys#check-port */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[81]);}

/* k3783 in read-token in k1980 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 573  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3786 in k3783 in read-token in k1980 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3793(t5,((C_word*)t0)[2]);}

/* loop in k3786 in k3783 in read-token in k1980 */
static void C_fcall f_3793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3793,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 575  ##sys#peek-char-0 */
t3=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k3795 in loop in k3786 in k3783 in read-token in k1980 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_3803(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm: 576  pred */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k3801 in k3795 in loop in k3786 in k3783 in read-token in k1980 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3803,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 578  ##sys#read-char-0 */
t4=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* extras.scm: 580  get-output-string */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k3811 in k3801 in k3795 in loop in k3786 in k3783 in read-token in k1980 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 578  ##sys#write-char-0 */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3804 in k3801 in k3795 in loop in k3786 in k3783 in read-token in k1980 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 579  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3793(t2,((C_word*)t0)[2]);}

/* read-string in k1980 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_3721r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3721r(t0,t1,t2);}}

static void C_ccall f_3721r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3723,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3733,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n353361 */
t6=t5;
f_3733(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-port354359 */
t8=t4;
f_3728(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body351356 */
f_3723(t1,t6,t8);}}}

/* def-n353 in read-string in k1980 */
static void C_fcall f_3733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3733,NULL,2,t0,t1);}
/* def-port354359 */
t2=((C_word*)t0)[2];
f_3728(t2,t1,C_SCHEME_FALSE);}

/* def-port354 in read-string in k1980 */
static void C_fcall f_3728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3728,NULL,3,t0,t1,t2);}
/* body351356 */
f_3723(t1,t2,*((C_word*)lf[10]+1));}

/* body351 in read-string in k1980 */
static void C_fcall f_3723(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3723,NULL,3,t1,t2,t3);}
/* extras.scm: 565  ##sys#read-string/port */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##sys#read-string/port in k1980 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3648,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 546  ##sys#check-port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[79]);}

/* k3650 in ##sys#read-string/port in k1980 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3652,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[79]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 548  ##sys#make-string */
t4=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 554  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3674 in k3650 in ##sys#read-string/port in k1980 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3681(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k3674 in k3650 in ##sys#read-string/port in k1980 */
static void C_fcall f_3681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3681,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 556  get-output-string */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,((C_word*)t0)[4]);}
else{
t5=t3;
f_3685(2,t5,C_SCHEME_FALSE);}}

/* k3683 in loop in k3674 in k3650 in ##sys#read-string/port in k1980 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 557  ##sys#read-char-0 */
t3=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3689 in k3683 in loop in k3674 in k3650 in ##sys#read-string/port in k1980 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 559  get-output-string */
t2=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 561  ##sys#write-char/port */
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[4]);}}

/* k3701 in k3689 in k3683 in loop in k3674 in k3650 in ##sys#read-string/port in k1980 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
/* extras.scm: 562  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3681(t3,((C_word*)t0)[2],t2);}

/* k3659 in k3650 in ##sys#read-string/port in k1980 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3664,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 549  ##sys#read-string! */
t3=*((C_word*)lf[74]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[2],C_fix(0));}

/* k3662 in k3659 in k3650 in ##sys#read-string/port in k1980 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 552  ##sys#substring */
t3=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* read-string! in k1980 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3554r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3554r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3554r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3556,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3598,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3603,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port313326 */
t9=t8;
f_3603(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start314324 */
t11=t7;
f_3598(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body311316 */
t13=t6;
f_3556(t13,t1,t9,t11);}}}

/* def-port313 in read-string! in k1980 */
static void C_fcall f_3603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3603,NULL,2,t0,t1);}
/* def-start314324 */
t2=((C_word*)t0)[2];
f_3598(t2,t1,*((C_word*)lf[10]+1));}

/* def-start314 in read-string! in k1980 */
static void C_fcall f_3598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3598,NULL,3,t0,t1,t2);}
/* body311316 */
t3=((C_word*)t0)[2];
f_3556(t3,t1,t2,C_fix(0));}

/* body311 in read-string! in k1980 */
static void C_fcall f_3556(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3556,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3560,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 533  ##sys#check-port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[75]);}

/* k3558 in body311 in read-string! in k1980 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[75]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[75]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
t6=(C_word)C_block_size(((C_word*)t0)[6]);
if(C_truep((C_word)C_fixnum_greaterp(t5,t6))){
t7=(C_word)C_block_size(((C_word*)t0)[6]);
t8=(C_word)C_u_fixnum_difference(t7,((C_word*)t0)[5]);
t9=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t10=t3;
f_3566(t10,t9);}
else{
t7=t3;
f_3566(t7,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3566(t4,C_SCHEME_UNDEFINED);}}

/* k3564 in k3558 in body311 in read-string! in k1980 */
static void C_fcall f_3566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[75]);
/* extras.scm: 540  ##sys#read-string! */
t3=*((C_word*)lf[74]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* ##sys#read-string! in k1980 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3464,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3474,a[2]=t2,a[3]=t6,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(t4,C_fix(6)))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3548,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 515  ##sys#read-char-0 */
t10=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t8;
f_3474(t9,C_SCHEME_UNDEFINED);}}}

/* k3546 in ##sys#read-string! in k1980 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3474(t5,t4);}

/* k3472 in ##sys#read-string! in k1980 */
static void C_fcall f_3474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3474,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(7));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3482(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}

/* loop in k3472 in ##sys#read-string! in k1980 */
static void C_fcall f_3482(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3482,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
/* extras.scm: 520  rdstring */
t6=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,((C_word*)t0)[3],t3,((C_word*)t0)[2],t2);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3531,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 521  ##sys#read-char-0 */
t7=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}}

/* k3529 in loop in k3472 in ##sys#read-string! in k1980 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
f_3486(2,t2,C_fix(0));}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[4];
f_3486(2,t3,C_fix(1));}}

/* k3484 in loop in k3472 in ##sys#read-string! in k1980 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_i_not(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_u_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
/* extras.scm: 529  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3482(t8,((C_word*)t0)[6],t5,t6,t7);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[5]));}}}

/* read-lines in k1980 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_3374r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3374r(t0,t1,t2);}}

static void C_ccall f_3374r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[10]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
/* extras.scm: 503  call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3441,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 505  ##sys#check-port */
t11=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t4,lf[73]);}}

/* k3439 in read-lines in k1980 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 506  doread */
t2=((C_word*)t0)[4];
f_3386(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k1980 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3386,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(1000000000));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3396,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3396(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in doread in read-lines in k1980 */
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3396,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 497  reverse */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 498  read-line */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3407 in loop in doread in read-lines in k1980 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 500  reverse */
t2=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 501  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3396(t4,((C_word*)t0)[5],t2,t3);}}

/* read-line in k1980 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3230r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3230r(t0,t1,t2);}}

static void C_ccall f_3230r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_car(t2):*((C_word*)lf[10]+1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_3240(t8,(C_truep(t7)?(C_word)C_u_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_3240(t6,C_SCHEME_FALSE);}}

/* k3238 in read-line in k1980 */
static void C_fcall f_3240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3240,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 457  ##sys#check-port */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[66]);}

/* k3241 in k3238 in read-line in k1980 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(8));
if(C_truep(t3)){
/* extras.scm: 458  rl */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t4=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_fix(256));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 461  ##sys#make-string */
t8=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t6)[1]);}}

/* k3256 in k3241 in k3238 in read-line in k1980 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_3263(t7,((C_word*)t0)[2],C_fix(0));}

/* loop in k3256 in k3241 in k3238 in read-line in k1980 */
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3263,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[7])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* extras.scm: 464  ##sys#substring */
t4=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 465  ##sys#read-char-0 */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}

/* k3274 in loop in k3256 in k3241 in k3238 in read-line in k1980 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* extras.scm: 469  ##sys#substring */
t3=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);}}
else{
switch(t1){
case C_make_character(10):
/* extras.scm: 471  ##sys#substring */
t2=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3309,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 473  peek-char */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[8],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3341,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 480  make-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_3327(t3,C_SCHEME_UNDEFINED);}}}}

/* k3347 in k3274 in loop in k3256 in k3241 in k3238 in read-line in k1980 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 480  ##sys#string-append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3339 in k3274 in loop in k3256 in k3241 in k3238 in read-line in k1980 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3327(t5,t4);}

/* k3325 in k3274 in loop in k3256 in k3241 in k3238 in read-line in k1980 */
static void C_fcall f_3327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 483  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3263(t4,((C_word*)t0)[2],t3);}

/* k3307 in k3274 in loop in k3256 in k3241 in k3238 in read-line in k1980 */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3309,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 475  ##sys#read-char-0 */
t4=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 477  ##sys#substring */
t3=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}}

/* k3316 in k3307 in k3274 in loop in k3256 in k3241 in k3238 in read-line in k1980 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 476  ##sys#substring */
t2=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],C_fix(0),((C_word*)t0)[2]);}

/* randomize in k1980 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3187r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3187r(t0,t1,t2);}}

static void C_ccall f_3187r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3192,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t3;
f_3192(t4,(C_word)C_fudge(C_fix(2)));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[64]);
t6=t3;
f_3192(t6,t4);}}

/* k3190 in randomize in k1980 */
static void C_fcall f_3192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_randomize(t1));}

/* random in k1980 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3175,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[50]);
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_fix(0):(C_word)C_random_fixnum(t2)));}

/* random-seed in k1980 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3137r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3137r(t0,t1,t2);}}

static void C_ccall f_3137r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_block_size(t2);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(1)))){
t5=(C_word)C_block_size(t2);
/* extras.scm: 420  ##sys#error */
t6=*((C_word*)lf[38]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t3,lf[60],lf[63],t5,C_fix(1));}
else{
t5=t3;
f_3141(2,t5,C_SCHEME_FALSE);}}

/* k3139 in random-seed in k1980 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(((C_word*)t0)[2]))){
/* extras.scm: 422  current-seconds */
t3=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_3144(2,t3,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}}

/* k3142 in k3139 in random-seed in k1980 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3147,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 424  ##sys#check-integer */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[60]);}

/* k3145 in k3142 in k3139 in random-seed in k1980 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub232(C_SCHEME_UNDEFINED,t3));}

/* rassoc in k1980 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3085r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3085r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3085r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_list_2(t3,lf[59]);
t6=(C_word)C_notvemptyp(t4);
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):*((C_word*)lf[52]+1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3097,a[2]=t2,a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3097(t11,t1,t3);}

/* loop in rassoc in k1980 */
static void C_fcall f_3097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3097,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[59]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3116,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 409  tst */
t7=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3114 in loop in rassoc in k1980 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 411  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3097(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k1980 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2964r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2964r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2964r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2966,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3035,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp199215 */
t8=t7;
f_3040(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default200213 */
t10=t6;
f_3035(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body197202 */
t12=t5;
f_2966(t12,t1,t8,t10);}}}

/* def-cmp199 in alist-ref in k1980 */
static void C_fcall f_3040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3040,NULL,2,t0,t1);}
/* def-default200213 */
t2=((C_word*)t0)[2];
f_3035(t2,t1,*((C_word*)lf[52]+1));}

/* def-default200 in alist-ref in k1980 */
static void C_fcall f_3035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3035,NULL,3,t0,t1,t2);}
/* body197202 */
t3=((C_word*)t0)[2];
f_2966(t3,t1,t2,C_SCHEME_FALSE);}

/* body197 in alist-ref in k1980 */
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2966,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[53]+1),t2);
if(C_truep(t5)){
t6=t4;
f_2970(t6,*((C_word*)lf[54]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[52]+1),t2);
if(C_truep(t6)){
t7=t4;
f_2970(t7,*((C_word*)lf[55]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[56]+1),t2);
t8=t4;
f_2970(t8,(C_truep(t7)?*((C_word*)lf[57]+1):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}}

/* f_2995 in body197 in alist-ref in k1980 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2995,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3001,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3001(t7,t1,t3);}

/* loop */
static void C_fcall f_3001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3001,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 394  cmp */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_3017(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3015 in loop */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 396  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3001(t3,((C_word*)t0)[5],t2);}}

/* k2968 in body197 in alist-ref in k1980 */
static void C_fcall f_2970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2970,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 397  aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2971 in k2968 in body197 in alist-ref in k1980 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k1980 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2878r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2878r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2878r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):*((C_word*)lf[52]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2885,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[53]+1),t7);
if(C_truep(t9)){
t10=t8;
f_2885(t10,*((C_word*)lf[54]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[52]+1),t7);
if(C_truep(t10)){
t11=t8;
f_2885(t11,*((C_word*)lf[55]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[56]+1),t7);
t12=t8;
f_2885(t12,(C_truep(t11)?*((C_word*)lf[57]+1):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2917,a[2]=t7,tmp=(C_word)a,a+=3,tmp)));}}}

/* f_2917 in alist-update! in k1980 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2917,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2923,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2923(t7,t1,t3);}

/* loop */
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2923,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 375  cmp */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2939(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2937 in loop */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 377  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2923(t3,((C_word*)t0)[5],t2);}}

/* k2883 in alist-update! in k1980 */
static void C_fcall f_2885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2885,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 378  aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2886 in k2883 in alist-update! in k1980 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k1980 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2837,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2852,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2868,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a2867 in shuffle in k1980 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2868,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2876,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 359  random */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2874 in a2867 in shuffle in k1980 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2850 in shuffle in k1980 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2854,tmp=(C_word)a,a+=2,tmp);
/* extras.scm: 359  sort! */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2853 in k2850 in shuffle in k1980 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2854,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k2846 in shuffle in k1980 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[48]+1),t1);}

/* compress in k1980 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2757,4,t0,t1,t2,t3);}
t4=lf[43];
t5=(C_word)C_i_check_list_2(t3,lf[42]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2766,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2766(t9,t1,t2,t3);}

/* loop in compress in k1980 */
static void C_fcall f_2766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2766,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 351  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 352  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
/* extras.scm: 350  ##sys#signal-hook */
t4=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[45],lf[42],((C_word*)t0)[2],t3);}}
else{
/* extras.scm: 348  ##sys#signal-hook */
t4=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[45],lf[42],((C_word*)t0)[2],t2);}}}

/* k2806 in loop in compress in k1980 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k1980 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2698r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2698r(t0,t1,t2,t3);}}

static void C_ccall f_2698r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[40]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2710,a[2]=t8,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_2710(t10,t1,t2);}

/* loop in join in k1980 */
static void C_fcall f_2710(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2710,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 339  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}
else{
/* extras.scm: 333  ##sys#not-a-proper-list-error */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}}

/* k2743 in loop in join in k1980 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 339  ##sys#append */
t2=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k1980 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2613,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[37]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2620,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* extras.scm: 314  ##sys#error */
t6=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[37],lf[39],t3);}
else{
t6=t5;
f_2620(2,t6,C_SCHEME_UNDEFINED);}}

/* k2618 in chop in k1980 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2628(t6,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* loop in k2618 in chop in k1980 */
static void C_fcall f_2628(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2628,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2649,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2649(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* do146 in loop in k2618 in chop in k1980 */
static void C_fcall f_2649(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2649,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2663,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 325  reverse */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k2661 in do146 in loop in k2618 in chop in k1980 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2667,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* extras.scm: 325  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2628(t4,t2,((C_word*)t0)[2],t3);}

/* k2665 in k2661 in do146 in loop in k2618 in chop in k1980 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k1980 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2572r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2572r(t0,t1,t2);}}

static void C_ccall f_2572r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2578,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2578(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k1980 */
static void C_fcall f_2578(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2578,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2604,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 306  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 307  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k2609 in loop in flatten in k1980 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2602 in loop in flatten in k1980 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 306  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2578(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k1980 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2540,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2549,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2549(t7,t1,t2);}

/* loop in butlast in k1980 */
static void C_fcall f_2549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2549,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2570,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 296  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2568 in loop in butlast in k1980 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k1980 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2507,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2513(t7,t1,t2);}

/* loop in intersperse in k1980 */
static void C_fcall f_2513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2513,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2538,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 289  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k2536 in loop in intersperse in k1980 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k1980 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2479,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[33]);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_2491(t6,t3));}}

/* loop in tail? in k1980 */
static C_word C_fcall f_2491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k1980 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2476,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* right-section in k1980 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2450r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2450r(t0,t1,t2,t3);}}

static void C_ccall f_2450r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2454,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 263  ##sys#check-closure */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[31]);}

/* k2452 in right-section in k1980 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 264  ##sys#reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2455 in k2452 in right-section in k1980 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2457,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2458,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_2458 in k2455 in k2452 in right-section in k1980 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_2458r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2458r(t0,t1,t2);}}

static void C_ccall f_2458r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2470,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 266  ##sys#reverse */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2472 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 266  ##sys#append */
t2=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2468 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 266  ##sys#reverse */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2464 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* left-section in k1980 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2435r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2435r(t0,t1,t2,t3);}}

static void C_ccall f_2435r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 256  ##sys#check-closure */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[28]);}

/* k2437 in left-section in k1980 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));}

/* f_2440 in k2437 in left-section in k1980 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2440r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2440r(t0,t1,t2);}}

static void C_ccall f_2440r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 258  ##sys#append */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2446 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* never? in k1980 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* always? in k1980 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2429,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* none? in k1980 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2426,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* any? in k1980 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2423,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* each in k1980 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2367r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2367r(t0,t1,t2);}}

static void C_ccall f_2367r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2375,tmp=(C_word)a,a+=2,tmp));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2389,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_2389 in each in k1980 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2389r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2389r(t0,t1,t2);}}

static void C_ccall f_2389r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2395(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_2395(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2395,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
C_apply(4,0,t1,t3,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,t3,((C_word*)t0)[3]);}}

/* k2412 in loop */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 245  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2395(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_2375 in each in k1980 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* noop in k1980 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2361,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* list-of in k1980 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2321,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2323,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_2323 in list-of in k1980 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2323,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2329(t6,t1,t2);}

/* loop */
static void C_fcall f_2329(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2329,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2348,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 228  pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}}

/* k2346 in loop */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 228  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2329(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* o in k1980 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2282r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2282r(t0,t1,t2);}}

static void C_ccall f_2282r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[11]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2294,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2294(t6,t1,t2);}}

/* loop in o in k1980 */
static void C_fcall f_2294(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2294,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2308,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp)));}

/* f_2308 in loop in o in k1980 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2316,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2319,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 221  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2294(t5,t4,((C_word*)t0)[2]);}

/* k2317 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2314 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 221  h */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* compose in k1980 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2246r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2246r(t0,t1,t2);}}

static void C_ccall f_2246r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2249,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[19]+1));}
else{
C_apply(4,0,t1,((C_word*)t4)[1],t2);}}

/* rec in compose in k1980 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2249r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2249r(t0,t1,t2,t3);}}

static void C_ccall f_2249r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2257,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp)));}

/* f_2257 in rec in compose in k1980 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2257r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2257r(t0,t1,t2);}}

static void C_ccall f_2257r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 206  call-with-values */
C_u_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a2262 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2269 in a2262 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k1980 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2234,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_2236 in complement in k1980 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2236r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2236r(t0,t1,t2);}}

static void C_ccall f_2236r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k2242 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k1980 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2226,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_2228 in flip in k1980 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2228,4,t0,t1,t2,t3);}
/* extras.scm: 195  proc */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* constantly in k1980 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2203r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2203r(t0,t1,t2);}}

static void C_ccall f_2203r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2214,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}}

/* f_2216 in constantly in k1980 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_2214 in constantly in k1980 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k1980 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2166r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2166r(t0,t1,t2);}}

static void C_ccall f_2166r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(3);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_2168 in disjoin in k1980 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2168,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2174,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2174(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_2174(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2174,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,((C_word*)t0)[2]);}}

/* k2182 in loop */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 187  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2174(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k1980 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2133r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2133r(t0,t1,t2);}}

static void C_ccall f_2133r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(3);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2135,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_2135 in conjoin in k1980 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2135,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2141,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2141(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_2141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2141,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2154,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k2152 in loop */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 180  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2141(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k1980 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2125,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2127,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_2127 in project in k1980 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2127r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2127r(t0,t1,t2);}}

static void C_ccall f_2127r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,((C_word*)t0)[2]));}

/* identity in k1980 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2122,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* read-file in k1980 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_1990r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1990r(t0,t1,t2);}}

static void C_ccall f_1990r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-port1135 */
t7=t6;
f_2062(t7,t1);}
else{
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-reader1233 */
t9=t5;
f_2057(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-max1330 */
t11=t4;
f_2052(t11,t1,t7,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body915 */
t13=t3;
f_1992(t13,t1,t7,t9,t11);}}}}

/* def-port11 in read-file in k1980 */
static void C_fcall f_2062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2062,NULL,2,t0,t1);}
/* def-reader1233 */
t2=((C_word*)t0)[2];
f_2057(t2,t1,*((C_word*)lf[10]+1));}

/* def-reader12 in read-file in k1980 */
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2057,NULL,3,t0,t1,t2);}
/* def-max1330 */
t3=((C_word*)t0)[3];
f_2052(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max13 in read-file in k1980 */
static void C_fcall f_2052(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2052,NULL,4,t0,t1,t2,t3);}
/* body915 */
t4=((C_word*)t0)[2];
f_1992(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body9 in read-file in k1980 */
static void C_fcall f_1992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1992,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1995,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 163  port? */
t7=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2043 in body9 in read-file in k1980 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 164  slurp */
t2=((C_word*)t0)[5];
f_1995(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm: 165  call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body9 in read-file in k1980 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1995,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2003,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 159  reader */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2001 in slurp in body9 in read-file in k1980 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2005(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* do21 in k2001 in slurp in body9 in read-file in k1980 */
static void C_fcall f_2005(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2005,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm: 162  reverse */
t7=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2025,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 159  reader */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}}

/* k2023 in do21 in k2001 in slurp in body9 in read-file in k1980 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2005(t4,((C_word*)t0)[2],t1,t2,t3);}

/* ##extras#unbound-value-thunk in k1980 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(lf[4],C_fix(0)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[703] = {
{"toplevelextras.scm",(void*)C_extras_toplevel},
{"f_1982extras.scm",(void*)f_1982},
{"f_5748extras.scm",(void*)f_5748},
{"f_7266extras.scm",(void*)f_7266},
{"f_10916extras.scm",(void*)f_10916},
{"f_10926extras.scm",(void*)f_10926},
{"f_10933extras.scm",(void*)f_10933},
{"f_9874extras.scm",(void*)f_9874},
{"f_10636extras.scm",(void*)f_10636},
{"f_10865extras.scm",(void*)f_10865},
{"f_10875extras.scm",(void*)f_10875},
{"f_10892extras.scm",(void*)f_10892},
{"f_10878extras.scm",(void*)f_10878},
{"f_10836extras.scm",(void*)f_10836},
{"f_10782extras.scm",(void*)f_10782},
{"f_10801extras.scm",(void*)f_10801},
{"f_10811extras.scm",(void*)f_10811},
{"f_10793extras.scm",(void*)f_10793},
{"f_10773extras.scm",(void*)f_10773},
{"f_10737extras.scm",(void*)f_10737},
{"f_10747extras.scm",(void*)f_10747},
{"f_10705extras.scm",(void*)f_10705},
{"f_10715extras.scm",(void*)f_10715},
{"f_10684extras.scm",(void*)f_10684},
{"f_10694extras.scm",(void*)f_10694},
{"f_10663extras.scm",(void*)f_10663},
{"f_10673extras.scm",(void*)f_10673},
{"f_10650extras.scm",(void*)f_10650},
{"f_10644extras.scm",(void*)f_10644},
{"f_10638extras.scm",(void*)f_10638},
{"f_10613extras.scm",(void*)f_10613},
{"f_10620extras.scm",(void*)f_10620},
{"f_10625extras.scm",(void*)f_10625},
{"f_10633extras.scm",(void*)f_10633},
{"f_10601extras.scm",(void*)f_10601},
{"f_10608extras.scm",(void*)f_10608},
{"f_10589extras.scm",(void*)f_10589},
{"f_10596extras.scm",(void*)f_10596},
{"f_10577extras.scm",(void*)f_10577},
{"f_10584extras.scm",(void*)f_10584},
{"f_10511extras.scm",(void*)f_10511},
{"f_10523extras.scm",(void*)f_10523},
{"f_10539extras.scm",(void*)f_10539},
{"f_10567extras.scm",(void*)f_10567},
{"f_10462extras.scm",(void*)f_10462},
{"f_10474extras.scm",(void*)f_10474},
{"f_10493extras.scm",(void*)f_10493},
{"f_10484extras.scm",(void*)f_10484},
{"f_10397extras.scm",(void*)f_10397},
{"f_10412extras.scm",(void*)f_10412},
{"f_10428extras.scm",(void*)f_10428},
{"f_10332extras.scm",(void*)f_10332},
{"f_10347extras.scm",(void*)f_10347},
{"f_10363extras.scm",(void*)f_10363},
{"f_10304extras.scm",(void*)f_10304},
{"f_10311extras.scm",(void*)f_10311},
{"f_10316extras.scm",(void*)f_10316},
{"f_10326extras.scm",(void*)f_10326},
{"f_10314extras.scm",(void*)f_10314},
{"f_10231extras.scm",(void*)f_10231},
{"f_10246extras.scm",(void*)f_10246},
{"f_10262extras.scm",(void*)f_10262},
{"f_10215extras.scm",(void*)f_10215},
{"f_10229extras.scm",(void*)f_10229},
{"f_10203extras.scm",(void*)f_10203},
{"f_10136extras.scm",(void*)f_10136},
{"f_10148extras.scm",(void*)f_10148},
{"f_10171extras.scm",(void*)f_10171},
{"f_10197extras.scm",(void*)f_10197},
{"f_10184extras.scm",(void*)f_10184},
{"f_10158extras.scm",(void*)f_10158},
{"f_10040extras.scm",(void*)f_10040},
{"f_10047extras.scm",(void*)f_10047},
{"f_10061extras.scm",(void*)f_10061},
{"f_10087extras.scm",(void*)f_10087},
{"f_10106extras.scm",(void*)f_10106},
{"f_10074extras.scm",(void*)f_10074},
{"f_9909extras.scm",(void*)f_9909},
{"f_9925extras.scm",(void*)f_9925},
{"f_9992extras.scm",(void*)f_9992},
{"f_10011extras.scm",(void*)f_10011},
{"f_9945extras.scm",(void*)f_9945},
{"f_9888extras.scm",(void*)f_9888},
{"f_9907extras.scm",(void*)f_9907},
{"f_9876extras.scm",(void*)f_9876},
{"f_9885extras.scm",(void*)f_9885},
{"f_9763extras.scm",(void*)f_9763},
{"f_9776extras.scm",(void*)f_9776},
{"f_9833extras.scm",(void*)f_9833},
{"f_9852extras.scm",(void*)f_9852},
{"f_9791extras.scm",(void*)f_9791},
{"f_9749extras.scm",(void*)f_9749},
{"f_9758extras.scm",(void*)f_9758},
{"f_9754extras.scm",(void*)f_9754},
{"f_9734extras.scm",(void*)f_9734},
{"f_9741extras.scm",(void*)f_9741},
{"f_9746extras.scm",(void*)f_9746},
{"f_9656extras.scm",(void*)f_9656},
{"f_9689extras.scm",(void*)f_9689},
{"f_9672extras.scm",(void*)f_9672},
{"f_9684extras.scm",(void*)f_9684},
{"f_9658extras.scm",(void*)f_9658},
{"f_9665extras.scm",(void*)f_9665},
{"f_9668extras.scm",(void*)f_9668},
{"f_9420extras.scm",(void*)f_9420},
{"f_9441extras.scm",(void*)f_9441},
{"f_9646extras.scm",(void*)f_9646},
{"f_9638extras.scm",(void*)f_9638},
{"f_9457extras.scm",(void*)f_9457},
{"f_9463extras.scm",(void*)f_9463},
{"f_9564extras.scm",(void*)f_9564},
{"f_9601extras.scm",(void*)f_9601},
{"f_9604extras.scm",(void*)f_9604},
{"f_9592extras.scm",(void*)f_9592},
{"f_9574extras.scm",(void*)f_9574},
{"f_9501extras.scm",(void*)f_9501},
{"f_9541extras.scm",(void*)f_9541},
{"f_9529extras.scm",(void*)f_9529},
{"f_9511extras.scm",(void*)f_9511},
{"f_9479extras.scm",(void*)f_9479},
{"f_9466extras.scm",(void*)f_9466},
{"f_9469extras.scm",(void*)f_9469},
{"f_9341extras.scm",(void*)f_9341},
{"f_9353extras.scm",(void*)f_9353},
{"f_9376extras.scm",(void*)f_9376},
{"f_9392extras.scm",(void*)f_9392},
{"f_9363extras.scm",(void*)f_9363},
{"f_9332extras.scm",(void*)f_9332},
{"f_9220extras.scm",(void*)f_9220},
{"f_9230extras.scm",(void*)f_9230},
{"f_9235extras.scm",(void*)f_9235},
{"f_9297extras.scm",(void*)f_9297},
{"f_9318extras.scm",(void*)f_9318},
{"f_9291extras.scm",(void*)f_9291},
{"f_9205extras.scm",(void*)f_9205},
{"f_9193extras.scm",(void*)f_9193},
{"f_9184extras.scm",(void*)f_9184},
{"f_9175extras.scm",(void*)f_9175},
{"f_9166extras.scm",(void*)f_9166},
{"f_9157extras.scm",(void*)f_9157},
{"f_9148extras.scm",(void*)f_9148},
{"f_9139extras.scm",(void*)f_9139},
{"f_9130extras.scm",(void*)f_9130},
{"f_9124extras.scm",(void*)f_9124},
{"f_8761extras.scm",(void*)f_8761},
{"f_9114extras.scm",(void*)f_9114},
{"f_9117extras.scm",(void*)f_9117},
{"f_8839extras.scm",(void*)f_8839},
{"f_9094extras.scm",(void*)f_9094},
{"f_9097extras.scm",(void*)f_9097},
{"f_8842extras.scm",(void*)f_8842},
{"f_9062extras.scm",(void*)f_9062},
{"f_9068extras.scm",(void*)f_9068},
{"f_8845extras.scm",(void*)f_8845},
{"f_8880extras.scm",(void*)f_8880},
{"f_8901extras.scm",(void*)f_8901},
{"f_8907extras.scm",(void*)f_8907},
{"f_8999extras.scm",(void*)f_8999},
{"f_9002extras.scm",(void*)f_9002},
{"f_8974extras.scm",(void*)f_8974},
{"f_8977extras.scm",(void*)f_8977},
{"f_8964extras.scm",(void*)f_8964},
{"f_8946extras.scm",(void*)f_8946},
{"f_8933extras.scm",(void*)f_8933},
{"f_8923extras.scm",(void*)f_8923},
{"f_8910extras.scm",(void*)f_8910},
{"f_8891extras.scm",(void*)f_8891},
{"f_8848extras.scm",(void*)f_8848},
{"f_8851extras.scm",(void*)f_8851},
{"f_8855extras.scm",(void*)f_8855},
{"f_8871extras.scm",(void*)f_8871},
{"f_8858extras.scm",(void*)f_8858},
{"f_8763extras.scm",(void*)f_8763},
{"f_8737extras.scm",(void*)f_8737},
{"f_8741extras.scm",(void*)f_8741},
{"f_8707extras.scm",(void*)f_8707},
{"f_8713extras.scm",(void*)f_8713},
{"f_8665extras.scm",(void*)f_8665},
{"f_8624extras.scm",(void*)f_8624},
{"f_8582extras.scm",(void*)f_8582},
{"f_8600extras.scm",(void*)f_8600},
{"f_8310extras.scm",(void*)f_8310},
{"f_8409extras.scm",(void*)f_8409},
{"f_8560extras.scm",(void*)f_8560},
{"f_8539extras.scm",(void*)f_8539},
{"f_8531extras.scm",(void*)f_8531},
{"f_8510extras.scm",(void*)f_8510},
{"f_8484extras.scm",(void*)f_8484},
{"f_8378extras.scm",(void*)f_8378},
{"f_8313extras.scm",(void*)f_8313},
{"f_8330extras.scm",(void*)f_8330},
{"f_8364extras.scm",(void*)f_8364},
{"f_8269extras.scm",(void*)f_8269},
{"f_8287extras.scm",(void*)f_8287},
{"f_8189extras.scm",(void*)f_8189},
{"f_8258extras.scm",(void*)f_8258},
{"f_8147extras.scm",(void*)f_8147},
{"f_8165extras.scm",(void*)f_8165},
{"f_8086extras.scm",(void*)f_8086},
{"f_8041extras.scm",(void*)f_8041},
{"f_8048extras.scm",(void*)f_8048},
{"f_8015extras.scm",(void*)f_8015},
{"f_8022extras.scm",(void*)f_8022},
{"f_7970extras.scm",(void*)f_7970},
{"f_7929extras.scm",(void*)f_7929},
{"f_7947extras.scm",(void*)f_7947},
{"f_7923extras.scm",(void*)f_7923},
{"f_7857extras.scm",(void*)f_7857},
{"f_7864extras.scm",(void*)f_7864},
{"f_7903extras.scm",(void*)f_7903},
{"f_7878extras.scm",(void*)f_7878},
{"f_7851extras.scm",(void*)f_7851},
{"f_7768extras.scm",(void*)f_7768},
{"f_7846extras.scm",(void*)f_7846},
{"f_7772extras.scm",(void*)f_7772},
{"f_7786extras.scm",(void*)f_7786},
{"f_7796extras.scm",(void*)f_7796},
{"f_7741extras.scm",(void*)f_7741},
{"f_7766extras.scm",(void*)f_7766},
{"f_7759extras.scm",(void*)f_7759},
{"f_7755extras.scm",(void*)f_7755},
{"f_7608extras.scm",(void*)f_7608},
{"f_7698extras.scm",(void*)f_7698},
{"f_7705extras.scm",(void*)f_7705},
{"f_7707extras.scm",(void*)f_7707},
{"f_7611extras.scm",(void*)f_7611},
{"f_7662extras.scm",(void*)f_7662},
{"f_7652extras.scm",(void*)f_7652},
{"f_7621extras.scm",(void*)f_7621},
{"f_7624extras.scm",(void*)f_7624},
{"f_7630extras.scm",(void*)f_7630},
{"f_7476extras.scm",(void*)f_7476},
{"f_7558extras.scm",(void*)f_7558},
{"f_7581extras.scm",(void*)f_7581},
{"f_7561extras.scm",(void*)f_7561},
{"f_7479extras.scm",(void*)f_7479},
{"f_7486extras.scm",(void*)f_7486},
{"f_7377extras.scm",(void*)f_7377},
{"f_7411extras.scm",(void*)f_7411},
{"f_7418extras.scm",(void*)f_7418},
{"f_7466extras.scm",(void*)f_7466},
{"f_7438extras.scm",(void*)f_7438},
{"f_7268extras.scm",(void*)f_7268},
{"f_7343extras.scm",(void*)f_7343},
{"f_7371extras.scm",(void*)f_7371},
{"f_7295extras.scm",(void*)f_7295},
{"f_7305extras.scm",(void*)f_7305},
{"f_7223extras.scm",(void*)f_7223},
{"f_7256extras.scm",(void*)f_7256},
{"f_7231extras.scm",(void*)f_7231},
{"f_7217extras.scm",(void*)f_7217},
{"f_7211extras.scm",(void*)f_7211},
{"f_7205extras.scm",(void*)f_7205},
{"f_6907extras.scm",(void*)f_6907},
{"f_6911extras.scm",(void*)f_6911},
{"f_7194extras.scm",(void*)f_7194},
{"f_6914extras.scm",(void*)f_6914},
{"f_6919extras.scm",(void*)f_6919},
{"f_6980extras.scm",(void*)f_6980},
{"f_7158extras.scm",(void*)f_7158},
{"f_7113extras.scm",(void*)f_7113},
{"f_7116extras.scm",(void*)f_7116},
{"f_7095extras.scm",(void*)f_7095},
{"f_7091extras.scm",(void*)f_7091},
{"f_7078extras.scm",(void*)f_7078},
{"f_7074extras.scm",(void*)f_7074},
{"f_7061extras.scm",(void*)f_7061},
{"f_7057extras.scm",(void*)f_7057},
{"f_7044extras.scm",(void*)f_7044},
{"f_7031extras.scm",(void*)f_7031},
{"f_7018extras.scm",(void*)f_7018},
{"f_6993extras.scm",(void*)f_6993},
{"f_6952extras.scm",(void*)f_6952},
{"f_6974extras.scm",(void*)f_6974},
{"f_6935extras.scm",(void*)f_6935},
{"f_6928extras.scm",(void*)f_6928},
{"f_6862extras.scm",(void*)f_6862},
{"f_6798extras.scm",(void*)f_6798},
{"f_6813extras.scm",(void*)f_6813},
{"f_6844extras.scm",(void*)f_6844},
{"f_6848extras.scm",(void*)f_6848},
{"f_6833extras.scm",(void*)f_6833},
{"f_6676extras.scm",(void*)f_6676},
{"f_6688extras.scm",(void*)f_6688},
{"f_6721extras.scm",(void*)f_6721},
{"f_6786extras.scm",(void*)f_6786},
{"f_6760extras.scm",(void*)f_6760},
{"f_6716extras.scm",(void*)f_6716},
{"f_6706extras.scm",(void*)f_6706},
{"f_6702extras.scm",(void*)f_6702},
{"f_6474extras.scm",(void*)f_6474},
{"f_6668extras.scm",(void*)f_6668},
{"f_6651extras.scm",(void*)f_6651},
{"f_6511extras.scm",(void*)f_6511},
{"f_6514extras.scm",(void*)f_6514},
{"f_6526extras.scm",(void*)f_6526},
{"f_6531extras.scm",(void*)f_6531},
{"f_6550extras.scm",(void*)f_6550},
{"f_6477extras.scm",(void*)f_6477},
{"f_6482extras.scm",(void*)f_6482},
{"f_6488extras.scm",(void*)f_6488},
{"f_6366extras.scm",(void*)f_6366},
{"f_6384extras.scm",(void*)f_6384},
{"f_6394extras.scm",(void*)f_6394},
{"f_6399extras.scm",(void*)f_6399},
{"f_6231extras.scm",(void*)f_6231},
{"f_6272extras.scm",(void*)f_6272},
{"f_6299extras.scm",(void*)f_6299},
{"f_6338extras.scm",(void*)f_6338},
{"f_6282extras.scm",(void*)f_6282},
{"f_6252extras.scm",(void*)f_6252},
{"f_6267extras.scm",(void*)f_6267},
{"f_6259extras.scm",(void*)f_6259},
{"f_6154extras.scm",(void*)f_6154},
{"f_6171extras.scm",(void*)f_6171},
{"f_6166extras.scm",(void*)f_6166},
{"f_6161extras.scm",(void*)f_6161},
{"f_6156extras.scm",(void*)f_6156},
{"f_6117extras.scm",(void*)f_6117},
{"f_6127extras.scm",(void*)f_6127},
{"f_6040extras.scm",(void*)f_6040},
{"f_6057extras.scm",(void*)f_6057},
{"f_6052extras.scm",(void*)f_6052},
{"f_6047extras.scm",(void*)f_6047},
{"f_6042extras.scm",(void*)f_6042},
{"f_6003extras.scm",(void*)f_6003},
{"f_6013extras.scm",(void*)f_6013},
{"f_5972extras.scm",(void*)f_5972},
{"f_5941extras.scm",(void*)f_5941},
{"f_5920extras.scm",(void*)f_5920},
{"f_5899extras.scm",(void*)f_5899},
{"f_5890extras.scm",(void*)f_5890},
{"f_5896extras.scm",(void*)f_5896},
{"f_5881extras.scm",(void*)f_5881},
{"f_5887extras.scm",(void*)f_5887},
{"f_5834extras.scm",(void*)f_5834},
{"f_5855extras.scm",(void*)f_5855},
{"f_5868extras.scm",(void*)f_5868},
{"f_5824extras.scm",(void*)f_5824},
{"f_5832extras.scm",(void*)f_5832},
{"f_5779extras.scm",(void*)f_5779},
{"f_5816extras.scm",(void*)f_5816},
{"f_5819extras.scm",(void*)f_5819},
{"f_5750extras.scm",(void*)f_5750},
{"f_5754extras.scm",(void*)f_5754},
{"f_5761extras.scm",(void*)f_5761},
{"f_5763extras.scm",(void*)f_5763},
{"f_5767extras.scm",(void*)f_5767},
{"f_5757extras.scm",(void*)f_5757},
{"f_5669extras.scm",(void*)f_5669},
{"f_5672extras.scm",(void*)f_5672},
{"f_5688extras.scm",(void*)f_5688},
{"f_5697extras.scm",(void*)f_5697},
{"f_4397extras.scm",(void*)f_4397},
{"f_5660extras.scm",(void*)f_5660},
{"f_5664extras.scm",(void*)f_5664},
{"f_5013extras.scm",(void*)f_5013},
{"f_5568extras.scm",(void*)f_5568},
{"f_5578extras.scm",(void*)f_5578},
{"f_5559extras.scm",(void*)f_5559},
{"f_5553extras.scm",(void*)f_5553},
{"f_5531extras.scm",(void*)f_5531},
{"f_5538extras.scm",(void*)f_5538},
{"f_5525extras.scm",(void*)f_5525},
{"f_5519extras.scm",(void*)f_5519},
{"f_5513extras.scm",(void*)f_5513},
{"f_5507extras.scm",(void*)f_5507},
{"f_5501extras.scm",(void*)f_5501},
{"f_5495extras.scm",(void*)f_5495},
{"f_5347extras.scm",(void*)f_5347},
{"f_5493extras.scm",(void*)f_5493},
{"f_5445extras.scm",(void*)f_5445},
{"f_5475extras.scm",(void*)f_5475},
{"f_5460extras.scm",(void*)f_5460},
{"f_5350extras.scm",(void*)f_5350},
{"f_5377extras.scm",(void*)f_5377},
{"f_5373extras.scm",(void*)f_5373},
{"f_5391extras.scm",(void*)f_5391},
{"f_5418extras.scm",(void*)f_5418},
{"f_5414extras.scm",(void*)f_5414},
{"f_5432extras.scm",(void*)f_5432},
{"f_5270extras.scm",(void*)f_5270},
{"f_5276extras.scm",(void*)f_5276},
{"f_5345extras.scm",(void*)f_5345},
{"f_5341extras.scm",(void*)f_5341},
{"f_5333extras.scm",(void*)f_5333},
{"f_5329extras.scm",(void*)f_5329},
{"f_5307extras.scm",(void*)f_5307},
{"f_5299extras.scm",(void*)f_5299},
{"f_5261extras.scm",(void*)f_5261},
{"f_5265extras.scm",(void*)f_5265},
{"f_5233extras.scm",(void*)f_5233},
{"f_5259extras.scm",(void*)f_5259},
{"f_5237extras.scm",(void*)f_5237},
{"f_5168extras.scm",(void*)f_5168},
{"f_5175extras.scm",(void*)f_5175},
{"f_5202extras.scm",(void*)f_5202},
{"f_5228extras.scm",(void*)f_5228},
{"f_5186extras.scm",(void*)f_5186},
{"f_5081extras.scm",(void*)f_5081},
{"f_5094extras.scm",(void*)f_5094},
{"f_5132extras.scm",(void*)f_5132},
{"f_5097extras.scm",(void*)f_5097},
{"f_5126extras.scm",(void*)f_5126},
{"f_5130extras.scm",(void*)f_5130},
{"f_5110extras.scm",(void*)f_5110},
{"f_5049extras.scm",(void*)f_5049},
{"f_5072extras.scm",(void*)f_5072},
{"f_5065extras.scm",(void*)f_5065},
{"f_5016extras.scm",(void*)f_5016},
{"f_5047extras.scm",(void*)f_5047},
{"f_5040extras.scm",(void*)f_5040},
{"f_4510extras.scm",(void*)f_4510},
{"f_4689extras.scm",(void*)f_4689},
{"f_4955extras.scm",(void*)f_4955},
{"f_4994extras.scm",(void*)f_4994},
{"f_5004extras.scm",(void*)f_5004},
{"f_4997extras.scm",(void*)f_4997},
{"f_4972extras.scm",(void*)f_4972},
{"f_4982extras.scm",(void*)f_4982},
{"f_4975extras.scm",(void*)f_4975},
{"f_4962extras.scm",(void*)f_4962},
{"f_4939extras.scm",(void*)f_4939},
{"f_4942extras.scm",(void*)f_4942},
{"f_4949extras.scm",(void*)f_4949},
{"f_4921extras.scm",(void*)f_4921},
{"f_4837extras.scm",(void*)f_4837},
{"f_4840extras.scm",(void*)f_4840},
{"f_4896extras.scm",(void*)f_4896},
{"f_4875extras.scm",(void*)f_4875},
{"f_4882extras.scm",(void*)f_4882},
{"f_4859extras.scm",(void*)f_4859},
{"f_4866extras.scm",(void*)f_4866},
{"f_4831extras.scm",(void*)f_4831},
{"f_4747extras.scm",(void*)f_4747},
{"f_4749extras.scm",(void*)f_4749},
{"f_4756extras.scm",(void*)f_4756},
{"f_4808extras.scm",(void*)f_4808},
{"f_4804extras.scm",(void*)f_4804},
{"f_4787extras.scm",(void*)f_4787},
{"f_4783extras.scm",(void*)f_4783},
{"f_4779extras.scm",(void*)f_4779},
{"f_4728extras.scm",(void*)f_4728},
{"f_4705extras.scm",(void*)f_4705},
{"f_4708extras.scm",(void*)f_4708},
{"f_4715extras.scm",(void*)f_4715},
{"f_4696extras.scm",(void*)f_4696},
{"f_4666extras.scm",(void*)f_4666},
{"f_4670extras.scm",(void*)f_4670},
{"f_4513extras.scm",(void*)f_4513},
{"f_4520extras.scm",(void*)f_4520},
{"f_4531extras.scm",(void*)f_4531},
{"f_4540extras.scm",(void*)f_4540},
{"f_4623extras.scm",(void*)f_4623},
{"f_4558extras.scm",(void*)f_4558},
{"f_4560extras.scm",(void*)f_4560},
{"f_4612extras.scm",(void*)f_4612},
{"f_4608extras.scm",(void*)f_4608},
{"f_4592extras.scm",(void*)f_4592},
{"f_4584extras.scm",(void*)f_4584},
{"f_4491extras.scm",(void*)f_4491},
{"f_4501extras.scm",(void*)f_4501},
{"f_4458extras.scm",(void*)f_4458},
{"f_4452extras.scm",(void*)f_4452},
{"f_4400extras.scm",(void*)f_4400},
{"f_4432extras.scm",(void*)f_4432},
{"f_4333extras.scm",(void*)f_4333},
{"f_4346extras.scm",(void*)f_4346},
{"f_4376extras.scm",(void*)f_4376},
{"f_4367extras.scm",(void*)f_4367},
{"f_4371extras.scm",(void*)f_4371},
{"f_4361extras.scm",(void*)f_4361},
{"f_4351extras.scm",(void*)f_4351},
{"f_4359extras.scm",(void*)f_4359},
{"f_4190extras.scm",(void*)f_4190},
{"f_4273extras.scm",(void*)f_4273},
{"f_4268extras.scm",(void*)f_4268},
{"f_4263extras.scm",(void*)f_4263},
{"f_4192extras.scm",(void*)f_4192},
{"f_4202extras.scm",(void*)f_4202},
{"f_4258extras.scm",(void*)f_4258},
{"f_4249extras.scm",(void*)f_4249},
{"f_4253extras.scm",(void*)f_4253},
{"f_4228extras.scm",(void*)f_4228},
{"f_4244extras.scm",(void*)f_4244},
{"f_4207extras.scm",(void*)f_4207},
{"f_4156extras.scm",(void*)f_4156},
{"f_4160extras.scm",(void*)f_4160},
{"f_4182extras.scm",(void*)f_4182},
{"f_4173extras.scm",(void*)f_4173},
{"f_4177extras.scm",(void*)f_4177},
{"f_4165extras.scm",(void*)f_4165},
{"f_4125extras.scm",(void*)f_4125},
{"f_4129extras.scm",(void*)f_4129},
{"f_4148extras.scm",(void*)f_4148},
{"f_4142extras.scm",(void*)f_4142},
{"f_4134extras.scm",(void*)f_4134},
{"f_4113extras.scm",(void*)f_4113},
{"f_4117extras.scm",(void*)f_4117},
{"f_4120extras.scm",(void*)f_4120},
{"f_4104extras.scm",(void*)f_4104},
{"f_4108extras.scm",(void*)f_4108},
{"f_4073extras.scm",(void*)f_4073},
{"f_4077extras.scm",(void*)f_4077},
{"f_4096extras.scm",(void*)f_4096},
{"f_4090extras.scm",(void*)f_4090},
{"f_4082extras.scm",(void*)f_4082},
{"f_4042extras.scm",(void*)f_4042},
{"f_4046extras.scm",(void*)f_4046},
{"f_4065extras.scm",(void*)f_4065},
{"f_4059extras.scm",(void*)f_4059},
{"f_4051extras.scm",(void*)f_4051},
{"f_4011extras.scm",(void*)f_4011},
{"f_4015extras.scm",(void*)f_4015},
{"f_4034extras.scm",(void*)f_4034},
{"f_4028extras.scm",(void*)f_4028},
{"f_4020extras.scm",(void*)f_4020},
{"f_3980extras.scm",(void*)f_3980},
{"f_3990extras.scm",(void*)f_3990},
{"f_3947extras.scm",(void*)f_3947},
{"f_3954extras.scm",(void*)f_3954},
{"f_3957extras.scm",(void*)f_3957},
{"f_3926extras.scm",(void*)f_3926},
{"f_3933extras.scm",(void*)f_3933},
{"f_3939extras.scm",(void*)f_3939},
{"f_3840extras.scm",(void*)f_3840},
{"f_3881extras.scm",(void*)f_3881},
{"f_3876extras.scm",(void*)f_3876},
{"f_3845extras.scm",(void*)f_3845},
{"f_3849extras.scm",(void*)f_3849},
{"f_3862extras.scm",(void*)f_3862},
{"f_3859extras.scm",(void*)f_3859},
{"f_3778extras.scm",(void*)f_3778},
{"f_3785extras.scm",(void*)f_3785},
{"f_3788extras.scm",(void*)f_3788},
{"f_3793extras.scm",(void*)f_3793},
{"f_3797extras.scm",(void*)f_3797},
{"f_3803extras.scm",(void*)f_3803},
{"f_3813extras.scm",(void*)f_3813},
{"f_3806extras.scm",(void*)f_3806},
{"f_3721extras.scm",(void*)f_3721},
{"f_3733extras.scm",(void*)f_3733},
{"f_3728extras.scm",(void*)f_3728},
{"f_3723extras.scm",(void*)f_3723},
{"f_3648extras.scm",(void*)f_3648},
{"f_3652extras.scm",(void*)f_3652},
{"f_3676extras.scm",(void*)f_3676},
{"f_3681extras.scm",(void*)f_3681},
{"f_3685extras.scm",(void*)f_3685},
{"f_3691extras.scm",(void*)f_3691},
{"f_3703extras.scm",(void*)f_3703},
{"f_3661extras.scm",(void*)f_3661},
{"f_3664extras.scm",(void*)f_3664},
{"f_3554extras.scm",(void*)f_3554},
{"f_3603extras.scm",(void*)f_3603},
{"f_3598extras.scm",(void*)f_3598},
{"f_3556extras.scm",(void*)f_3556},
{"f_3560extras.scm",(void*)f_3560},
{"f_3566extras.scm",(void*)f_3566},
{"f_3464extras.scm",(void*)f_3464},
{"f_3548extras.scm",(void*)f_3548},
{"f_3474extras.scm",(void*)f_3474},
{"f_3482extras.scm",(void*)f_3482},
{"f_3531extras.scm",(void*)f_3531},
{"f_3486extras.scm",(void*)f_3486},
{"f_3374extras.scm",(void*)f_3374},
{"f_3441extras.scm",(void*)f_3441},
{"f_3386extras.scm",(void*)f_3386},
{"f_3396extras.scm",(void*)f_3396},
{"f_3409extras.scm",(void*)f_3409},
{"f_3230extras.scm",(void*)f_3230},
{"f_3240extras.scm",(void*)f_3240},
{"f_3243extras.scm",(void*)f_3243},
{"f_3258extras.scm",(void*)f_3258},
{"f_3263extras.scm",(void*)f_3263},
{"f_3276extras.scm",(void*)f_3276},
{"f_3349extras.scm",(void*)f_3349},
{"f_3341extras.scm",(void*)f_3341},
{"f_3327extras.scm",(void*)f_3327},
{"f_3309extras.scm",(void*)f_3309},
{"f_3318extras.scm",(void*)f_3318},
{"f_3187extras.scm",(void*)f_3187},
{"f_3192extras.scm",(void*)f_3192},
{"f_3175extras.scm",(void*)f_3175},
{"f_3137extras.scm",(void*)f_3137},
{"f_3141extras.scm",(void*)f_3141},
{"f_3144extras.scm",(void*)f_3144},
{"f_3147extras.scm",(void*)f_3147},
{"f_3085extras.scm",(void*)f_3085},
{"f_3097extras.scm",(void*)f_3097},
{"f_3116extras.scm",(void*)f_3116},
{"f_2964extras.scm",(void*)f_2964},
{"f_3040extras.scm",(void*)f_3040},
{"f_3035extras.scm",(void*)f_3035},
{"f_2966extras.scm",(void*)f_2966},
{"f_2995extras.scm",(void*)f_2995},
{"f_3001extras.scm",(void*)f_3001},
{"f_3017extras.scm",(void*)f_3017},
{"f_2970extras.scm",(void*)f_2970},
{"f_2973extras.scm",(void*)f_2973},
{"f_2878extras.scm",(void*)f_2878},
{"f_2917extras.scm",(void*)f_2917},
{"f_2923extras.scm",(void*)f_2923},
{"f_2939extras.scm",(void*)f_2939},
{"f_2885extras.scm",(void*)f_2885},
{"f_2888extras.scm",(void*)f_2888},
{"f_2837extras.scm",(void*)f_2837},
{"f_2868extras.scm",(void*)f_2868},
{"f_2876extras.scm",(void*)f_2876},
{"f_2852extras.scm",(void*)f_2852},
{"f_2854extras.scm",(void*)f_2854},
{"f_2848extras.scm",(void*)f_2848},
{"f_2757extras.scm",(void*)f_2757},
{"f_2766extras.scm",(void*)f_2766},
{"f_2808extras.scm",(void*)f_2808},
{"f_2698extras.scm",(void*)f_2698},
{"f_2710extras.scm",(void*)f_2710},
{"f_2745extras.scm",(void*)f_2745},
{"f_2613extras.scm",(void*)f_2613},
{"f_2620extras.scm",(void*)f_2620},
{"f_2628extras.scm",(void*)f_2628},
{"f_2649extras.scm",(void*)f_2649},
{"f_2663extras.scm",(void*)f_2663},
{"f_2667extras.scm",(void*)f_2667},
{"f_2572extras.scm",(void*)f_2572},
{"f_2578extras.scm",(void*)f_2578},
{"f_2611extras.scm",(void*)f_2611},
{"f_2604extras.scm",(void*)f_2604},
{"f_2540extras.scm",(void*)f_2540},
{"f_2549extras.scm",(void*)f_2549},
{"f_2570extras.scm",(void*)f_2570},
{"f_2507extras.scm",(void*)f_2507},
{"f_2513extras.scm",(void*)f_2513},
{"f_2538extras.scm",(void*)f_2538},
{"f_2479extras.scm",(void*)f_2479},
{"f_2491extras.scm",(void*)f_2491},
{"f_2476extras.scm",(void*)f_2476},
{"f_2450extras.scm",(void*)f_2450},
{"f_2454extras.scm",(void*)f_2454},
{"f_2457extras.scm",(void*)f_2457},
{"f_2458extras.scm",(void*)f_2458},
{"f_2474extras.scm",(void*)f_2474},
{"f_2470extras.scm",(void*)f_2470},
{"f_2466extras.scm",(void*)f_2466},
{"f_2435extras.scm",(void*)f_2435},
{"f_2439extras.scm",(void*)f_2439},
{"f_2440extras.scm",(void*)f_2440},
{"f_2448extras.scm",(void*)f_2448},
{"f_2432extras.scm",(void*)f_2432},
{"f_2429extras.scm",(void*)f_2429},
{"f_2426extras.scm",(void*)f_2426},
{"f_2423extras.scm",(void*)f_2423},
{"f_2367extras.scm",(void*)f_2367},
{"f_2389extras.scm",(void*)f_2389},
{"f_2395extras.scm",(void*)f_2395},
{"f_2414extras.scm",(void*)f_2414},
{"f_2375extras.scm",(void*)f_2375},
{"f_2361extras.scm",(void*)f_2361},
{"f_2321extras.scm",(void*)f_2321},
{"f_2323extras.scm",(void*)f_2323},
{"f_2329extras.scm",(void*)f_2329},
{"f_2348extras.scm",(void*)f_2348},
{"f_2282extras.scm",(void*)f_2282},
{"f_2294extras.scm",(void*)f_2294},
{"f_2308extras.scm",(void*)f_2308},
{"f_2319extras.scm",(void*)f_2319},
{"f_2316extras.scm",(void*)f_2316},
{"f_2246extras.scm",(void*)f_2246},
{"f_2249extras.scm",(void*)f_2249},
{"f_2257extras.scm",(void*)f_2257},
{"f_2263extras.scm",(void*)f_2263},
{"f_2271extras.scm",(void*)f_2271},
{"f_2234extras.scm",(void*)f_2234},
{"f_2236extras.scm",(void*)f_2236},
{"f_2244extras.scm",(void*)f_2244},
{"f_2226extras.scm",(void*)f_2226},
{"f_2228extras.scm",(void*)f_2228},
{"f_2203extras.scm",(void*)f_2203},
{"f_2216extras.scm",(void*)f_2216},
{"f_2214extras.scm",(void*)f_2214},
{"f_2166extras.scm",(void*)f_2166},
{"f_2168extras.scm",(void*)f_2168},
{"f_2174extras.scm",(void*)f_2174},
{"f_2184extras.scm",(void*)f_2184},
{"f_2133extras.scm",(void*)f_2133},
{"f_2135extras.scm",(void*)f_2135},
{"f_2141extras.scm",(void*)f_2141},
{"f_2154extras.scm",(void*)f_2154},
{"f_2125extras.scm",(void*)f_2125},
{"f_2127extras.scm",(void*)f_2127},
{"f_2122extras.scm",(void*)f_2122},
{"f_1990extras.scm",(void*)f_1990},
{"f_2062extras.scm",(void*)f_2062},
{"f_2057extras.scm",(void*)f_2057},
{"f_2052extras.scm",(void*)f_2052},
{"f_1992extras.scm",(void*)f_1992},
{"f_2045extras.scm",(void*)f_2045},
{"f_1995extras.scm",(void*)f_1995},
{"f_2003extras.scm",(void*)f_2003},
{"f_2005extras.scm",(void*)f_2005},
{"f_2025extras.scm",(void*)f_2025},
{"f_1984extras.scm",(void*)f_1984},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
