/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:48
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: posixunix.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file uposixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set_9(v) \
        (C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)))

#define C_tm_get_08(v) \
        (C_set_block_item(v, 0, C_fix(C_tm.tm_sec)), \
        C_set_block_item(v, 1, C_fix(C_tm.tm_min)), \
        C_set_block_item(v, 2, C_fix(C_tm.tm_hour)), \
        C_set_block_item(v, 3, C_fix(C_tm.tm_mday)), \
        C_set_block_item(v, 4, C_fix(C_tm.tm_mon)), \
        C_set_block_item(v, 5, C_fix(C_tm.tm_year)), \
        C_set_block_item(v, 6, C_fix(C_tm.tm_wday)), \
        C_set_block_item(v, 7, C_fix(C_tm.tm_yday)), \
        C_set_block_item(v, 8, (C_tm.tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define C_tm_get_9(v) \
        (C_set_block_item(v, 9, C_fix(C_tm.tm_gmtoff)))

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  return v;
}

#else

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  C_tm_set_9 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  C_tm_get_9 (v);
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[461];
static double C_possibly_force_alignment;


/* from k7109 in set-root-directory! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1353(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1353(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from sleep in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1126(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1126(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1123(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1123(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1121(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1121(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub1052(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1052(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k6064 */
static C_word C_fcall stub1045(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1045(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub1040(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1040(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k6056 */
static C_word C_fcall stub1033(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1033(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from f_6041 in k6035 in process-fork in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1021(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1021(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub1016(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1016(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub976(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub976(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k5853 */
static C_word C_fcall stub962(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub962(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from ttyname */
static C_word C_fcall stub952(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub952(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from set-alarm! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub932(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub932(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from ex0 */
static C_word C_fcall stub927(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub927(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub922(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub922(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub903(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub903(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub882(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub882(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub876(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub876(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub867(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub867(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k5423 */
static C_word C_fcall stub848(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub848(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k5365 */
static C_word C_fcall stub823(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub823(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from get */
static C_word C_fcall stub805(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub805(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k4066 in k4062 in file-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub529(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub529(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k3786 in initialize-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub469(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub469(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from _ensure-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub442(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub442(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from _get-groups */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub438(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub438(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from group-member */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub421(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub421(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a7155 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub408(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub408(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a7173 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub406(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub406(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a7176 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub400(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub400(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a7194 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub398(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub398(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from fd_test in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from fd_set in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from fd_zero in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub81(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from fcntl */
static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from ##sys#file-select-one in k1622 in k1619 in k1616 in k1613 in k1610 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub17(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub17(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from ##sys#file-nonblocking! in k1622 in k1619 in k1616 in k1613 in k1610 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub13(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from strerror */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7211)
static void C_ccall f_7211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7177)
static void C_ccall f_7177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7174)
static void C_ccall f_7174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7159)
static void C_ccall f_7159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7138)
static void C_ccall f_7138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7145)
static void C_ccall f_7145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7040)
static void C_fcall f_7040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7035)
static void C_fcall f_7035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7030)
static void C_fcall f_7030(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6859)
static void C_fcall f_6859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6866)
static void C_fcall f_6866(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6878)
static void C_fcall f_6878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6985)
static void C_ccall f_6985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6969)
static void C_ccall f_6969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6812)
static void C_fcall f_6812(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_fcall f_6807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6802)
static void C_fcall f_6802(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6755)
static void C_fcall f_6755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6750)
static void C_fcall f_6750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6745)
static void C_fcall f_6745(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6682)
static void C_fcall f_6682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_fcall f_6684(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6653)
static void C_ccall f_6653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_fcall f_6607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6596)
static void C_fcall f_6596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6551)
static void C_fcall f_6551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static C_word C_fcall f_6535(C_word *a,C_word t0);
C_noret_decl(f_6518)
static void C_fcall f_6518(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_fcall f_6504(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_fcall f_6484(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6447)
static void C_fcall f_6447(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6385)
static void C_ccall f_6385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6349)
static void C_ccall f_6349(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6349)
static void C_ccall f_6349r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6248)
static void C_ccall f_6248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6203)
static void C_fcall f_6203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_fcall f_6198(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6071)
static void C_fcall f_6071(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6089)
static void C_fcall f_6089(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6135)
static C_word C_fcall f_6135(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6102)
static void C_fcall f_6102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6105)
static void C_ccall f_6105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6061)
static C_word C_fcall f_6061(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6053)
static C_word C_fcall f_6053(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5909)
static void C_fcall f_5909(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5940)
static void C_ccall f_5940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_fcall f_5949(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_fcall f_5810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_fcall f_5294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_fcall f_5306(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5194)
static void C_fcall f_5194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_fcall f_5089(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5018)
static void C_fcall f_5018(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_fcall f_5043(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4919)
static void C_fcall f_4919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_fcall f_4914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4909)
static void C_fcall f_4909(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4725)
static void C_fcall f_4725(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4853)
static void C_fcall f_4853(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4777)
static void C_fcall f_4777(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_fcall f_4731(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4648)
static void C_fcall f_4648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_fcall f_4643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4638)
static void C_fcall f_4638(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4633)
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4254)
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4512)
static void C_fcall f_4512(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4438)
static void C_fcall f_4438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_fcall f_4440(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_fcall f_4288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_fcall f_4300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static C_word C_fcall f_4280(C_word t0);
C_noret_decl(f_4265)
static void C_fcall f_4265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4232)
static void C_fcall f_4232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_fcall f_4137(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_fcall f_4100(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3913)
static void C_fcall f_3913(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static C_word C_fcall f_3660(C_word t0);
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_fcall f_3592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_fcall f_3615(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_fcall f_3498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3342)
static void C_fcall f_3342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_fcall f_3034(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_fcall f_3028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static C_word C_fcall f_3016(C_word t0);
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_fcall f_2826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_fcall f_2845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_fcall f_2889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_fcall f_2715(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_fcall f_2783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_fcall f_2643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static C_word C_fcall f_2632(C_word t0);
C_noret_decl(f_2627)
static void C_fcall f_2627(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2514)
static void C_fcall f_2514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_fcall f_2509(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2411)
static void C_fcall f_2411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_fcall f_2442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_fcall f_2464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_fcall f_2096(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_fcall f_1929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_fcall f_1968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_fcall f_1972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static C_word C_fcall f_1902(C_word t0,C_word t1);
C_noret_decl(f_1900)
static C_word C_fcall f_1900(C_word t0,C_word t1);
C_noret_decl(f_1898)
static C_word C_fcall f_1898(C_word t0);
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7040)
static void C_fcall trf_7040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7040(t0,t1);}

C_noret_decl(trf_7035)
static void C_fcall trf_7035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7035(t0,t1,t2);}

C_noret_decl(trf_7030)
static void C_fcall trf_7030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7030(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7030(t0,t1,t2,t3);}

C_noret_decl(trf_6859)
static void C_fcall trf_6859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6859(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6859(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6866)
static void C_fcall trf_6866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6866(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6866(t0,t1);}

C_noret_decl(trf_6878)
static void C_fcall trf_6878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6878(t0,t1,t2,t3);}

C_noret_decl(trf_6812)
static void C_fcall trf_6812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6812(t0,t1);}

C_noret_decl(trf_6807)
static void C_fcall trf_6807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6807(t0,t1,t2);}

C_noret_decl(trf_6802)
static void C_fcall trf_6802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6802(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6802(t0,t1,t2,t3);}

C_noret_decl(trf_6755)
static void C_fcall trf_6755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6755(t0,t1);}

C_noret_decl(trf_6750)
static void C_fcall trf_6750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6750(t0,t1,t2);}

C_noret_decl(trf_6745)
static void C_fcall trf_6745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6745(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6745(t0,t1,t2,t3);}

C_noret_decl(trf_6682)
static void C_fcall trf_6682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6682(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6682(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6684)
static void C_fcall trf_6684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6684(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6684(t0,t1,t2);}

C_noret_decl(trf_6607)
static void C_fcall trf_6607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6607(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6607(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6596)
static void C_fcall trf_6596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6596(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6596(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6551)
static void C_fcall trf_6551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6551(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6551(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6518)
static void C_fcall trf_6518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6518(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6518(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6504)
static void C_fcall trf_6504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6504(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6504(t0,t1,t2,t3);}

C_noret_decl(trf_6484)
static void C_fcall trf_6484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6484(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6484(t0,t1,t2);}

C_noret_decl(trf_6447)
static void C_fcall trf_6447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6447(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6447(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6203)
static void C_fcall trf_6203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6203(t0,t1);}

C_noret_decl(trf_6198)
static void C_fcall trf_6198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6198(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6198(t0,t1,t2);}

C_noret_decl(trf_6071)
static void C_fcall trf_6071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6071(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6071(t0,t1,t2,t3);}

C_noret_decl(trf_6089)
static void C_fcall trf_6089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6089(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6089(t0,t1,t2,t3);}

C_noret_decl(trf_6102)
static void C_fcall trf_6102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6102(t0,t1);}

C_noret_decl(trf_5909)
static void C_fcall trf_5909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5909(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5909(t0,t1,t2);}

C_noret_decl(trf_5949)
static void C_fcall trf_5949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5949(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5949(t0,t1,t2);}

C_noret_decl(trf_5810)
static void C_fcall trf_5810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5810(t0,t1,t2);}

C_noret_decl(trf_5294)
static void C_fcall trf_5294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5294(t0,t1,t2);}

C_noret_decl(trf_5306)
static void C_fcall trf_5306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5306(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5306(t0,t1,t2);}

C_noret_decl(trf_5194)
static void C_fcall trf_5194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5194(t0,t1);}

C_noret_decl(trf_5089)
static void C_fcall trf_5089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5089(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5089(t0,t1,t2,t3);}

C_noret_decl(trf_5018)
static void C_fcall trf_5018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5018(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5018(t0,t1,t2,t3);}

C_noret_decl(trf_5043)
static void C_fcall trf_5043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5043(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5043(t0,t1);}

C_noret_decl(trf_4919)
static void C_fcall trf_4919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4919(t0,t1);}

C_noret_decl(trf_4914)
static void C_fcall trf_4914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4914(t0,t1,t2);}

C_noret_decl(trf_4909)
static void C_fcall trf_4909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4909(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4909(t0,t1,t2,t3);}

C_noret_decl(trf_4725)
static void C_fcall trf_4725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4725(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4725(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4853)
static void C_fcall trf_4853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4853(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4853(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4777)
static void C_fcall trf_4777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4777(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4777(t0,t1);}

C_noret_decl(trf_4731)
static void C_fcall trf_4731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4731(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4731(t0,t1,t2,t3);}

C_noret_decl(trf_4648)
static void C_fcall trf_4648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4648(t0,t1);}

C_noret_decl(trf_4643)
static void C_fcall trf_4643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4643(t0,t1,t2);}

C_noret_decl(trf_4638)
static void C_fcall trf_4638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4638(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4638(t0,t1,t2,t3);}

C_noret_decl(trf_4633)
static void C_fcall trf_4633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4633(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4633(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4254)
static void C_fcall trf_4254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4254(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4254(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4512)
static void C_fcall trf_4512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4512(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4512(t0,t1,t2);}

C_noret_decl(trf_4438)
static void C_fcall trf_4438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4438(t0,t1);}

C_noret_decl(trf_4440)
static void C_fcall trf_4440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4440(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4440(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4288)
static void C_fcall trf_4288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4288(t0,t1);}

C_noret_decl(trf_4300)
static void C_fcall trf_4300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4300(t0,t1);}

C_noret_decl(trf_4265)
static void C_fcall trf_4265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4265(t0,t1);}

C_noret_decl(trf_4232)
static void C_fcall trf_4232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4232(t0,t1);}

C_noret_decl(trf_4137)
static void C_fcall trf_4137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4137(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4137(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4100)
static void C_fcall trf_4100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4100(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4100(t0,t1,t2);}

C_noret_decl(trf_3913)
static void C_fcall trf_3913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3913(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3913(t0,t1,t2,t3);}

C_noret_decl(trf_3735)
static void C_fcall trf_3735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3735(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3735(t0,t1,t2,t3);}

C_noret_decl(trf_3678)
static void C_fcall trf_3678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3678(t0,t1,t2);}

C_noret_decl(trf_3592)
static void C_fcall trf_3592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3592(t0,t1);}

C_noret_decl(trf_3615)
static void C_fcall trf_3615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3615(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3615(t0,t1,t2);}

C_noret_decl(trf_3498)
static void C_fcall trf_3498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3498(t0,t1);}

C_noret_decl(trf_3342)
static void C_fcall trf_3342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3342(t0,t1,t2,t3);}

C_noret_decl(trf_3034)
static void C_fcall trf_3034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3034(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3034(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3028)
static void C_fcall trf_3028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3028(t0,t1);}

C_noret_decl(trf_2826)
static void C_fcall trf_2826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2826(t0,t1);}

C_noret_decl(trf_2845)
static void C_fcall trf_2845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2845(t0,t1);}

C_noret_decl(trf_2889)
static void C_fcall trf_2889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2889(t0,t1);}

C_noret_decl(trf_2715)
static void C_fcall trf_2715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2715(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2715(t0,t1,t2,t3);}

C_noret_decl(trf_2783)
static void C_fcall trf_2783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2783(t0,t1);}

C_noret_decl(trf_2643)
static void C_fcall trf_2643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2643(t0,t1);}

C_noret_decl(trf_2627)
static void C_fcall trf_2627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2627(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2627(t0,t1);}

C_noret_decl(trf_2514)
static void C_fcall trf_2514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2514(t0,t1);}

C_noret_decl(trf_2509)
static void C_fcall trf_2509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2509(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2509(t0,t1,t2);}

C_noret_decl(trf_2411)
static void C_fcall trf_2411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2411(t0,t1,t2,t3);}

C_noret_decl(trf_2442)
static void C_fcall trf_2442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2442(t0,t1);}

C_noret_decl(trf_2464)
static void C_fcall trf_2464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2464(t0,t1);}

C_noret_decl(trf_2096)
static void C_fcall trf_2096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2096(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2096(t0,t1,t2,t3);}

C_noret_decl(trf_1929)
static void C_fcall trf_1929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1929(t0,t1);}

C_noret_decl(trf_1968)
static void C_fcall trf_1968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1968(t0,t1);}

C_noret_decl(trf_1972)
static void C_fcall trf_1972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1972(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3340)){
C_save(t1);
C_rereclaim2(3340*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,461);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"file-open");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[52]=C_h_intern(&lf[52],17,"\003sysmake-c-string");
lf[53]=C_h_intern(&lf[53],20,"\003sysexpand-home-path");
lf[54]=C_h_intern(&lf[54],10,"file-close");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[56]=C_h_intern(&lf[56],11,"make-string");
lf[57]=C_h_intern(&lf[57],9,"file-read");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[59]=C_h_intern(&lf[59],11,"\000type-error");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[61]=C_h_intern(&lf[61],10,"file-write");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[64]=C_h_intern(&lf[64],12,"file-mkstemp");
lf[65]=C_h_intern(&lf[65],13,"\003syssubstring");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[67]=C_h_intern(&lf[67],11,"file-select");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[69]=C_h_intern(&lf[69],12,"\003sysfor-each");
lf[70]=C_h_intern(&lf[70],8,"seek/set");
lf[71]=C_h_intern(&lf[71],8,"seek/end");
lf[72]=C_h_intern(&lf[72],8,"seek/cur");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[76]=C_h_intern(&lf[76],9,"file-stat");
lf[77]=C_h_intern(&lf[77],9,"file-size");
lf[78]=C_h_intern(&lf[78],22,"file-modification-time");
lf[79]=C_h_intern(&lf[79],16,"file-access-time");
lf[80]=C_h_intern(&lf[80],16,"file-change-time");
lf[81]=C_h_intern(&lf[81],10,"file-owner");
lf[82]=C_h_intern(&lf[82],16,"file-permissions");
lf[83]=C_h_intern(&lf[83],13,"regular-file\077");
lf[84]=C_h_intern(&lf[84],14,"symbolic-link\077");
lf[85]=C_h_intern(&lf[85],13,"stat-regular\077");
lf[86]=C_h_intern(&lf[86],15,"stat-directory\077");
lf[87]=C_h_intern(&lf[87],17,"stat-char-device\077");
lf[88]=C_h_intern(&lf[88],18,"stat-block-device\077");
lf[89]=C_h_intern(&lf[89],10,"stat-fifo\077");
lf[90]=C_h_intern(&lf[90],13,"stat-symlink\077");
lf[91]=C_h_intern(&lf[91],12,"stat-socket\077");
lf[92]=C_h_intern(&lf[92],18,"set-file-position!");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[94]=C_h_intern(&lf[94],6,"stream");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[96]=C_h_intern(&lf[96],5,"port\077");
lf[97]=C_h_intern(&lf[97],13,"\000bounds-error");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[99]=C_h_intern(&lf[99],13,"file-position");
lf[100]=C_h_intern(&lf[100],16,"create-directory");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[102]=C_h_intern(&lf[102],16,"change-directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[104]=C_h_intern(&lf[104],16,"delete-directory");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[106]=C_h_intern(&lf[106],10,"string-ref");
lf[107]=C_h_intern(&lf[107],6,"string");
lf[108]=C_h_intern(&lf[108],9,"directory");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[110]=C_h_intern(&lf[110],16,"\003sysmake-pointer");
lf[111]=C_h_intern(&lf[111],17,"current-directory");
lf[112]=C_h_intern(&lf[112],10,"directory\077");
lf[113]=C_h_intern(&lf[113],13,"\003sysfile-info");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[115]=C_h_intern(&lf[115],5,"null\077");
lf[116]=C_h_intern(&lf[116],6,"char=\077");
lf[117]=C_h_intern(&lf[117],8,"string=\077");
lf[118]=C_h_intern(&lf[118],16,"char-alphabetic\077");
lf[119]=C_h_intern(&lf[119],18,"string-intersperse");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[121]=C_h_intern(&lf[121],6,"getenv");
lf[122]=C_h_intern(&lf[122],17,"current-user-name");
lf[123]=C_h_intern(&lf[123],9,"condition");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[125]=C_h_intern(&lf[125],22,"with-exception-handler");
lf[126]=C_h_intern(&lf[126],30,"call-with-current-continuation");
lf[127]=C_h_intern(&lf[127],14,"canonical-path");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[131]=C_h_intern(&lf[131],7,"reverse");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[135]=C_h_intern(&lf[135],12,"string-split");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_h_intern(&lf[143],5,"\000text");
lf[144]=C_h_intern(&lf[144],9,"\003syserror");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[147]=C_h_intern(&lf[147],13,"\003sysmake-port");
lf[148]=C_h_intern(&lf[148],21,"\003sysstream-port-class");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[150]=C_h_intern(&lf[150],15,"open-input-pipe");
lf[151]=C_h_intern(&lf[151],7,"\000binary");
lf[152]=C_h_intern(&lf[152],16,"open-output-pipe");
lf[153]=C_h_intern(&lf[153],16,"close-input-pipe");
lf[154]=C_h_intern(&lf[154],23,"close-input/output-pipe");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[156]=C_h_intern(&lf[156],14,"\003syscheck-port");
lf[157]=C_h_intern(&lf[157],17,"close-output-pipe");
lf[158]=C_h_intern(&lf[158],20,"call-with-input-pipe");
lf[159]=C_h_intern(&lf[159],21,"call-with-output-pipe");
lf[160]=C_h_intern(&lf[160],20,"with-input-from-pipe");
lf[161]=C_h_intern(&lf[161],18,"\003sysstandard-input");
lf[162]=C_h_intern(&lf[162],19,"with-output-to-pipe");
lf[163]=C_h_intern(&lf[163],19,"\003sysstandard-output");
lf[164]=C_h_intern(&lf[164],11,"create-pipe");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[166]=C_h_intern(&lf[166],11,"signal/term");
lf[167]=C_h_intern(&lf[167],11,"signal/kill");
lf[168]=C_h_intern(&lf[168],10,"signal/int");
lf[169]=C_h_intern(&lf[169],10,"signal/hup");
lf[170]=C_h_intern(&lf[170],10,"signal/fpe");
lf[171]=C_h_intern(&lf[171],10,"signal/ill");
lf[172]=C_h_intern(&lf[172],11,"signal/segv");
lf[173]=C_h_intern(&lf[173],11,"signal/abrt");
lf[174]=C_h_intern(&lf[174],11,"signal/trap");
lf[175]=C_h_intern(&lf[175],11,"signal/quit");
lf[176]=C_h_intern(&lf[176],11,"signal/alrm");
lf[177]=C_h_intern(&lf[177],13,"signal/vtalrm");
lf[178]=C_h_intern(&lf[178],11,"signal/prof");
lf[179]=C_h_intern(&lf[179],9,"signal/io");
lf[180]=C_h_intern(&lf[180],10,"signal/urg");
lf[181]=C_h_intern(&lf[181],11,"signal/chld");
lf[182]=C_h_intern(&lf[182],11,"signal/cont");
lf[183]=C_h_intern(&lf[183],11,"signal/stop");
lf[184]=C_h_intern(&lf[184],11,"signal/tstp");
lf[185]=C_h_intern(&lf[185],11,"signal/pipe");
lf[186]=C_h_intern(&lf[186],11,"signal/xcpu");
lf[187]=C_h_intern(&lf[187],11,"signal/xfsz");
lf[188]=C_h_intern(&lf[188],11,"signal/usr1");
lf[189]=C_h_intern(&lf[189],11,"signal/usr2");
lf[190]=C_h_intern(&lf[190],12,"signal/winch");
lf[191]=C_h_intern(&lf[191],12,"signals-list");
lf[192]=C_h_intern(&lf[192],18,"\003sysinterrupt-hook");
lf[193]=C_h_intern(&lf[193],14,"signal-handler");
lf[194]=C_h_intern(&lf[194],19,"set-signal-handler!");
lf[195]=C_h_intern(&lf[195],16,"set-signal-mask!");
lf[196]=C_h_intern(&lf[196],14,"\000process-error");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[198]=C_h_intern(&lf[198],11,"signal-mask");
lf[199]=C_h_intern(&lf[199],14,"signal-masked\077");
lf[200]=C_h_intern(&lf[200],12,"signal-mask!");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[202]=C_h_intern(&lf[202],14,"signal-unmask!");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[204]=C_h_intern(&lf[204],18,"system-information");
lf[205]=C_h_intern(&lf[205],25,"\003syspeek-nonnull-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[207]=C_h_intern(&lf[207],12,"set-user-id!");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[209]=C_h_intern(&lf[209],15,"current-user-id");
lf[210]=C_h_intern(&lf[210],25,"current-effective-user-id");
lf[211]=C_h_intern(&lf[211],13,"set-group-id!");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[213]=C_h_intern(&lf[213],16,"current-group-id");
lf[214]=C_h_intern(&lf[214],26,"current-effective-group-id");
lf[215]=C_h_intern(&lf[215],16,"user-information");
lf[216]=C_h_intern(&lf[216],6,"vector");
lf[217]=C_h_intern(&lf[217],4,"list");
lf[218]=C_h_intern(&lf[218],27,"current-effective-user-name");
lf[219]=C_h_intern(&lf[219],17,"group-information");
lf[221]=C_h_intern(&lf[221],10,"get-groups");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[225]=C_h_intern(&lf[225],11,"set-groups!");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[228]=C_h_intern(&lf[228],17,"initialize-groups");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[230]=C_h_intern(&lf[230],10,"errno/perm");
lf[231]=C_h_intern(&lf[231],11,"errno/noent");
lf[232]=C_h_intern(&lf[232],10,"errno/srch");
lf[233]=C_h_intern(&lf[233],10,"errno/intr");
lf[234]=C_h_intern(&lf[234],8,"errno/io");
lf[235]=C_h_intern(&lf[235],12,"errno/noexec");
lf[236]=C_h_intern(&lf[236],10,"errno/badf");
lf[237]=C_h_intern(&lf[237],11,"errno/child");
lf[238]=C_h_intern(&lf[238],11,"errno/nomem");
lf[239]=C_h_intern(&lf[239],11,"errno/acces");
lf[240]=C_h_intern(&lf[240],11,"errno/fault");
lf[241]=C_h_intern(&lf[241],10,"errno/busy");
lf[242]=C_h_intern(&lf[242],12,"errno/notdir");
lf[243]=C_h_intern(&lf[243],11,"errno/isdir");
lf[244]=C_h_intern(&lf[244],11,"errno/inval");
lf[245]=C_h_intern(&lf[245],11,"errno/mfile");
lf[246]=C_h_intern(&lf[246],11,"errno/nospc");
lf[247]=C_h_intern(&lf[247],11,"errno/spipe");
lf[248]=C_h_intern(&lf[248],10,"errno/pipe");
lf[249]=C_h_intern(&lf[249],11,"errno/again");
lf[250]=C_h_intern(&lf[250],10,"errno/rofs");
lf[251]=C_h_intern(&lf[251],11,"errno/exist");
lf[252]=C_h_intern(&lf[252],16,"errno/wouldblock");
lf[253]=C_h_intern(&lf[253],10,"errno/2big");
lf[254]=C_h_intern(&lf[254],12,"errno/deadlk");
lf[255]=C_h_intern(&lf[255],9,"errno/dom");
lf[256]=C_h_intern(&lf[256],10,"errno/fbig");
lf[257]=C_h_intern(&lf[257],11,"errno/ilseq");
lf[258]=C_h_intern(&lf[258],11,"errno/mlink");
lf[259]=C_h_intern(&lf[259],17,"errno/nametoolong");
lf[260]=C_h_intern(&lf[260],11,"errno/nfile");
lf[261]=C_h_intern(&lf[261],11,"errno/nodev");
lf[262]=C_h_intern(&lf[262],11,"errno/nolck");
lf[263]=C_h_intern(&lf[263],11,"errno/nosys");
lf[264]=C_h_intern(&lf[264],14,"errno/notempty");
lf[265]=C_h_intern(&lf[265],11,"errno/notty");
lf[266]=C_h_intern(&lf[266],10,"errno/nxio");
lf[267]=C_h_intern(&lf[267],11,"errno/range");
lf[268]=C_h_intern(&lf[268],10,"errno/xdev");
lf[269]=C_h_intern(&lf[269],16,"change-file-mode");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[271]=C_h_intern(&lf[271],17,"change-file-owner");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[273]=C_h_intern(&lf[273],17,"file-read-access\077");
lf[274]=C_h_intern(&lf[274],18,"file-write-access\077");
lf[275]=C_h_intern(&lf[275],20,"file-execute-access\077");
lf[276]=C_h_intern(&lf[276],14,"create-session");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[278]=C_h_intern(&lf[278],21,"set-process-group-id!");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[280]=C_h_intern(&lf[280],16,"process-group-id");
lf[281]=C_h_intern(&lf[281],20,"create-symbolic-link");
lf[282]=C_h_intern(&lf[282],18,"create-symbol-link");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[284]=C_h_intern(&lf[284],9,"substring");
lf[285]=C_h_intern(&lf[285],18,"read-symbolic-link");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[287]=C_h_intern(&lf[287],9,"file-link");
lf[288]=C_h_intern(&lf[288],9,"hard-link");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[290]=C_h_intern(&lf[290],12,"fileno/stdin");
lf[291]=C_h_intern(&lf[291],13,"fileno/stdout");
lf[292]=C_h_intern(&lf[292],13,"fileno/stderr");
lf[293]=C_h_intern(&lf[293],7,"\000append");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[301]=C_h_intern(&lf[301],16,"open-input-file*");
lf[302]=C_h_intern(&lf[302],17,"open-output-file*");
lf[303]=C_h_intern(&lf[303],12,"port->fileno");
lf[304]=C_h_intern(&lf[304],6,"socket");
lf[305]=C_h_intern(&lf[305],20,"\003systcp-port->fileno");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[308]=C_h_intern(&lf[308],25,"\003syspeek-unsigned-integer");
lf[309]=C_h_intern(&lf[309],16,"duplicate-fileno");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[311]=C_h_intern(&lf[311],15,"make-input-port");
lf[312]=C_h_intern(&lf[312],14,"set-port-name!");
lf[313]=C_h_intern(&lf[313],21,"\003syscustom-input-port");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[315]=C_h_intern(&lf[315],17,"\003systhread-yield!");
lf[316]=C_h_intern(&lf[316],25,"\003systhread-block-for-i/o!");
lf[317]=C_h_intern(&lf[317],18,"\003syscurrent-thread");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[322]=C_h_intern(&lf[322],17,"\003sysstring-append");
lf[323]=C_h_intern(&lf[323],15,"\003sysmake-string");
lf[324]=C_h_intern(&lf[324],20,"\003sysscan-buffer-line");
lf[325]=C_h_intern(&lf[325],4,"noop");
lf[326]=C_h_intern(&lf[326],16,"make-output-port");
lf[327]=C_h_intern(&lf[327],22,"\003syscustom-output-port");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[330]=C_h_intern(&lf[330],13,"file-truncate");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[333]=C_h_intern(&lf[333],4,"lock");
lf[334]=C_h_intern(&lf[334],9,"file-lock");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[336]=C_h_intern(&lf[336],18,"file-lock/blocking");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[338]=C_h_intern(&lf[338],14,"file-test-lock");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[340]=C_h_intern(&lf[340],11,"file-unlock");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[342]=C_h_intern(&lf[342],11,"create-fifo");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[344]=C_h_intern(&lf[344],5,"fifo\077");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[346]=C_h_intern(&lf[346],6,"setenv");
lf[347]=C_h_intern(&lf[347],8,"unsetenv");
lf[348]=C_h_intern(&lf[348],19,"current-environment");
lf[349]=C_h_intern(&lf[349],9,"prot/read");
lf[350]=C_h_intern(&lf[350],10,"prot/write");
lf[351]=C_h_intern(&lf[351],9,"prot/exec");
lf[352]=C_h_intern(&lf[352],9,"prot/none");
lf[353]=C_h_intern(&lf[353],9,"map/fixed");
lf[354]=C_h_intern(&lf[354],10,"map/shared");
lf[355]=C_h_intern(&lf[355],11,"map/private");
lf[356]=C_h_intern(&lf[356],13,"map/anonymous");
lf[357]=C_h_intern(&lf[357],8,"map/file");
lf[358]=C_h_intern(&lf[358],18,"map-file-to-memory");
lf[359]=C_h_intern(&lf[359],4,"mmap");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[361]=C_h_intern(&lf[361],20,"\003syspointer->address");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[363]=C_h_intern(&lf[363],16,"\003sysnull-pointer");
lf[364]=C_h_intern(&lf[364],22,"unmap-file-from-memory");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[366]=C_h_intern(&lf[366],26,"memory-mapped-file-pointer");
lf[367]=C_h_intern(&lf[367],19,"memory-mapped-file\077");
lf[368]=C_h_intern(&lf[368],19,"seconds->local-time");
lf[369]=C_h_intern(&lf[369],18,"\003sysdecode-seconds");
lf[370]=C_h_intern(&lf[370],17,"seconds->utc-time");
lf[371]=C_h_intern(&lf[371],15,"seconds->string");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[373]=C_h_intern(&lf[373],12,"time->string");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[377]=C_h_intern(&lf[377],12,"string->time");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[379]=C_h_intern(&lf[379],19,"local-time->seconds");
lf[380]=C_h_intern(&lf[380],15,"\003syscons-flonum");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[383]=C_h_intern(&lf[383],17,"utc-time->seconds");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[386]=C_h_intern(&lf[386],27,"local-timezone-abbreviation");
lf[387]=C_h_intern(&lf[387],5,"_exit");
lf[388]=C_h_intern(&lf[388],10,"set-alarm!");
lf[389]=C_h_intern(&lf[389],19,"set-buffering-mode!");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[391]=C_h_intern(&lf[391],5,"\000full");
lf[392]=C_h_intern(&lf[392],5,"\000line");
lf[393]=C_h_intern(&lf[393],5,"\000none");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[395]=C_h_intern(&lf[395],14,"terminal-port\077");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[398]=C_h_intern(&lf[398],13,"terminal-name");
lf[399]=C_h_intern(&lf[399],13,"terminal-size");
lf[400]=C_h_intern(&lf[400],6,"\000error");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[402]=C_h_intern(&lf[402],17,"\003sysmake-locative");
lf[403]=C_h_intern(&lf[403],8,"location");
lf[404]=C_h_intern(&lf[404],13,"get-host-name");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[406]=C_h_intern(&lf[406],6,"regexp");
lf[407]=C_h_intern(&lf[407],21,"make-anchored-pattern");
lf[408]=C_h_intern(&lf[408],12,"string-match");
lf[409]=C_h_intern(&lf[409],12,"glob->regexp");
lf[410]=C_h_intern(&lf[410],13,"make-pathname");
lf[411]=C_h_intern(&lf[411],18,"decompose-pathname");
lf[412]=C_h_intern(&lf[412],4,"glob");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[415]=C_h_intern(&lf[415],12,"process-fork");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[417]=C_h_intern(&lf[417],24,"pathname-strip-directory");
lf[418]=C_h_intern(&lf[418],15,"process-execute");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[420]=C_h_intern(&lf[420],16,"\003sysprocess-wait");
lf[421]=C_h_intern(&lf[421],12,"process-wait");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[423]=C_h_intern(&lf[423],18,"current-process-id");
lf[424]=C_h_intern(&lf[424],17,"parent-process-id");
lf[425]=C_h_intern(&lf[425],5,"sleep");
lf[426]=C_h_intern(&lf[426],14,"process-signal");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[428]=C_h_intern(&lf[428],17,"\003sysshell-command");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[431]=C_h_intern(&lf[431],27,"\003sysshell-command-arguments");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[433]=C_h_intern(&lf[433],11,"process-run");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[435]=C_h_intern(&lf[435],11,"\003sysprocess");
lf[436]=C_h_intern(&lf[436],19,"\003sysundefined-value");
lf[437]=C_h_intern(&lf[437],7,"process");
lf[438]=C_h_intern(&lf[438],8,"process*");
lf[439]=C_h_intern(&lf[439],10,"find-files");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[443]=C_h_intern(&lf[443],16,"\003sysdynamic-wind");
lf[444]=C_h_intern(&lf[444],13,"pathname-file");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[446]=C_h_intern(&lf[446],7,"regexp\077");
lf[447]=C_h_intern(&lf[447],19,"set-root-directory!");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[450]=C_h_intern(&lf[450],18,"getter-with-setter");
lf[451]=C_h_intern(&lf[451],26,"effective-group-id!-setter");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[453]=C_h_intern(&lf[453],25,"effective-user-id!-setter");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[455]=C_h_intern(&lf[455],23,"\003sysuser-interrupt-hook");
lf[456]=C_h_intern(&lf[456],11,"make-vector");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[459]=C_h_intern(&lf[459],17,"register-feature!");
lf[460]=C_h_intern(&lf[460],5,"posix");
C_register_lf2(lf,461,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1610 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1615,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1613 in k1610 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1616 in k1613 in k1610 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 502  register-feature! */
t3=*((C_word*)lf[459]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[460]);}

/* k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[81],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1,lf[3]);
t5=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1649,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1652,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1693,tmp=(C_word)a,a+=2,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1770,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[56]+1);
t49=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1827,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1866,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1898,tmp=(C_word)a,a+=2,tmp);
t53=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1900,tmp=(C_word)a,a+=2,tmp);
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1902,tmp=(C_word)a,a+=2,tmp);
t55=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1904,a[2]=t53,a[3]=t54,a[4]=t52,tmp=(C_word)a,a+=5,tmp));
t56=C_mutate((C_word*)lf[70]+1,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[71]+1,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[72]+1,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2096,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2133,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2158,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2164,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2170,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2176,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2182,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2188,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2194,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2203,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2212,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2221,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2230,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2239,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2248,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2257,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2266,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2275,tmp=(C_word)a,a+=2,tmp));
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7204,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 842  getter-with-setter */
t79=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t79+1)))(4,t79,t77,t78,*((C_word*)lf[92]+1));}

/* a7203 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7204,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7208,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7220,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 844  port? */
t5=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7218 in a7203 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[94]);
t4=((C_word*)t0)[2];
f_7208(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_7208(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 849  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[59],lf[99],lf[458],((C_word*)t0)[3]);}}}

/* k7206 in a7203 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7211,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 851  posix-error */
t3=lf[3];
f_1631(6,t3,t2,lf[48],lf[99],lf[457],((C_word*)t0)[2]);}
else{
t3=t2;
f_7211(2,t3,C_SCHEME_UNDEFINED);}}

/* k7209 in k7206 in a7203 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[150],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=C_mutate((C_word*)lf[99]+1,t1);
t3=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2337,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2361,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2385,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[106]+1);
t7=*((C_word*)lf[56]+1);
t8=*((C_word*)lf[107]+1);
t9=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2409,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2563,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[56]+1);
t12=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2586,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[115]+1);
t14=*((C_word*)lf[116]+1);
t15=*((C_word*)lf[117]+1);
t16=*((C_word*)lf[118]+1);
t17=*((C_word*)lf[106]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2627,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2632,tmp=(C_word)a,a+=2,tmp);
t21=*((C_word*)lf[121]+1);
t22=*((C_word*)lf[122]+1);
t23=*((C_word*)lf[111]+1);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2699,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,tmp=(C_word)a,a+=13,tmp));
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3016,tmp=(C_word)a,a+=2,tmp);
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3028,tmp=(C_word)a,a+=2,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3034,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3049,a[2]=t27,a[3]=t28,a[4]=t26,tmp=(C_word)a,a+=5,tmp));
t30=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3085,a[2]=t27,a[3]=t28,a[4]=t26,tmp=(C_word)a,a+=5,tmp));
t31=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3121,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[157]+1,*((C_word*)lf[153]+1));
t33=*((C_word*)lf[150]+1);
t34=*((C_word*)lf[152]+1);
t35=*((C_word*)lf[153]+1);
t36=*((C_word*)lf[157]+1);
t37=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t38=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3185,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3205,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3225,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[166]+1,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[167]+1,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[168]+1,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[169]+1,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[170]+1,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[171]+1,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[172]+1,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[173]+1,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[174]+1,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[175]+1,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[176]+1,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[177]+1,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[178]+1,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[179]+1,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[180]+1,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[181]+1,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[182]+1,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[183]+1,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[184]+1,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[185]+1,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[186]+1,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[187]+1,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[188]+1,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[189]+1,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[190]+1,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1));
t68=C_mutate((C_word*)lf[191]+1,t67);
t69=*((C_word*)lf[192]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1145 make-vector */
t71=*((C_word*)lf[456]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=C_mutate((C_word*)lf[193]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[192]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[195]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3312,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3336,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[199]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3368,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3374,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3389,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7198,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1201 set-signal-handler! */
t12=*((C_word*)lf[194]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,*((C_word*)lf[168]+1),t11);}

/* a7197 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7198,3,t0,t1,t2);}
/* posixunix.scm: 1203 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[455]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3407,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3445,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7195,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1233 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[207]+1));}

/* a7194 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub398(C_SCHEME_UNDEFINED));}

/* k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7177,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7180,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1238 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7179 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7180,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7190,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1242 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7188 in a7179 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1243 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[453],lf[454],((C_word*)t0)[2]);}

/* a7176 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7177,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub400(C_SCHEME_UNDEFINED));}

/* k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1,t1);
t3=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3468,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7174,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1253 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[211]+1));}

/* a7173 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7174,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub406(C_SCHEME_UNDEFINED));}

/* k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
t2=C_mutate((C_word*)lf[213]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7156,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7159,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1258 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7158 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7159,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7169,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1262 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7167 in a7158 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1263 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[451],lf[452],((C_word*)t0)[2]);}

/* a7155 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7156,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub408(C_SCHEME_UNDEFINED));}

/* k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3489,2,t0,t1);}
t2=C_mutate((C_word*)lf[214]+1,t1);
t3=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3491,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3551,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3565,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3585,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[220],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3660,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3663,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3726,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3792,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[230]+1,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[231]+1,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[232]+1,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[233]+1,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[234]+1,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[235]+1,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[236]+1,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[237]+1,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[238]+1,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[239]+1,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[240]+1,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[241]+1,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[242]+1,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[243]+1,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[244]+1,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[245]+1,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[246]+1,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[247]+1,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[248]+1,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[249]+1,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[250]+1,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[251]+1,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[252]+1,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[253],0,C_fix(0));
t35=C_set_block_item(lf[254],0,C_fix(0));
t36=C_set_block_item(lf[255],0,C_fix(0));
t37=C_set_block_item(lf[256],0,C_fix(0));
t38=C_set_block_item(lf[257],0,C_fix(0));
t39=C_set_block_item(lf[258],0,C_fix(0));
t40=C_set_block_item(lf[259],0,C_fix(0));
t41=C_set_block_item(lf[260],0,C_fix(0));
t42=C_set_block_item(lf[261],0,C_fix(0));
t43=C_set_block_item(lf[262],0,C_fix(0));
t44=C_set_block_item(lf[263],0,C_fix(0));
t45=C_set_block_item(lf[264],0,C_fix(0));
t46=C_set_block_item(lf[265],0,C_fix(0));
t47=C_set_block_item(lf[266],0,C_fix(0));
t48=C_set_block_item(lf[267],0,C_fix(0));
t49=C_set_block_item(lf[268],0,C_fix(0));
t50=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3856,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3883,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3913,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3937,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3943,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3949,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3955,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3970,tmp=(C_word)a,a+=2,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7138,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1485 getter-with-setter */
t60=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t60+1)))(4,t60,t58,t59,*((C_word*)lf[278]+1));}

/* a7137 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7138,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[280]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7145,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7151,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1490 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_7145(2,t6,C_SCHEME_UNDEFINED);}}

/* k7149 in a7137 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1491 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[280],lf[449],((C_word*)t0)[2]);}

/* k7143 in a7137 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=C_mutate((C_word*)lf[280]+1,t1);
t3=C_mutate((C_word*)lf[281]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3995,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[284]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_u_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1512 make-string */
t7=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word ab[189],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4075,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[290]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[291]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[292]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4100,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4137,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4166,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4180,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4225,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[311]+1);
t14=*((C_word*)lf[312]+1);
t15=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4252,a[2]=t13,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[326]+1);
t17=*((C_word*)lf[312]+1);
t18=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4723,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4979,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5018,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5089,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5137,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5159,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5187,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5230,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5256,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[347]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5273,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[348]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5288,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[349]+1,C_fix((C_word)PROT_READ));
t32=C_mutate((C_word*)lf[350]+1,C_fix((C_word)PROT_WRITE));
t33=C_mutate((C_word*)lf[351]+1,C_fix((C_word)PROT_EXEC));
t34=C_mutate((C_word*)lf[352]+1,C_fix((C_word)PROT_NONE));
t35=C_mutate((C_word*)lf[353]+1,C_fix((C_word)MAP_FIXED));
t36=C_mutate((C_word*)lf[354]+1,C_fix((C_word)MAP_SHARED));
t37=C_mutate((C_word*)lf[355]+1,C_fix((C_word)MAP_PRIVATE));
t38=C_mutate((C_word*)lf[356]+1,C_fix((C_word)MAP_ANON));
t39=C_mutate((C_word*)lf[357]+1,C_fix((C_word)MAP_FILE));
t40=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5371,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5429,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5464,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5473,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5479,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5488,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5502,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5535,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5610,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5649,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5677,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[386]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5705,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5713,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5729,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[389]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5732,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5791,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate(&lf[396],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5810,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[398]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5837,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[399]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5856,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5891,tmp=(C_word)a,a+=2,tmp));
t60=*((C_word*)lf[406]+1);
t61=*((C_word*)lf[407]+1);
t62=*((C_word*)lf[408]+1);
t63=*((C_word*)lf[409]+1);
t64=*((C_word*)lf[108]+1);
t65=*((C_word*)lf[410]+1);
t66=*((C_word*)lf[411]+1);
t67=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5903,a[2]=t63,a[3]=t61,a[4]=t60,a[5]=t64,a[6]=t62,a[7]=t65,a[8]=t66,tmp=(C_word)a,a+=9,tmp));
t68=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6015,tmp=(C_word)a,a+=2,tmp));
t69=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6053,tmp=(C_word)a,a+=2,tmp);
t70=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6061,tmp=(C_word)a,a+=2,tmp);
t71=*((C_word*)lf[417]+1);
t72=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6069,a[2]=t71,a[3]=t70,a[4]=t69,tmp=(C_word)a,a+=5,tmp));
t73=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6248,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6265,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6340,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6343,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[425]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6346,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[426]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6349,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[428]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6376,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[431]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6385,tmp=(C_word)a,a+=2,tmp));
t81=*((C_word*)lf[415]+1);
t82=*((C_word*)lf[418]+1);
t83=*((C_word*)lf[121]+1);
t84=C_mutate((C_word*)lf[433]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6391,a[2]=t81,a[3]=t82,tmp=(C_word)a,a+=4,tmp));
t85=*((C_word*)lf[164]+1);
t86=*((C_word*)lf[421]+1);
t87=*((C_word*)lf[415]+1);
t88=*((C_word*)lf[418]+1);
t89=*((C_word*)lf[309]+1);
t90=*((C_word*)lf[54]+1);
t91=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6447,a[2]=t86,tmp=(C_word)a,a+=3,tmp);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6484,a[2]=t85,tmp=(C_word)a,a+=3,tmp);
t93=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6504,a[2]=t90,tmp=(C_word)a,a+=3,tmp);
t94=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6518,a[2]=t90,tmp=(C_word)a,a+=3,tmp);
t95=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6535,tmp=(C_word)a,a+=2,tmp);
t96=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6551,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=t95,tmp=(C_word)a,a+=7,tmp);
t97=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6596,a[2]=t93,tmp=(C_word)a,a+=3,tmp);
t98=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6607,a[2]=t93,tmp=(C_word)a,a+=3,tmp);
t99=C_mutate((C_word*)lf[435]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6618,a[2]=t98,a[3]=t91,a[4]=t97,a[5]=t96,tmp=(C_word)a,a+=6,tmp));
t100=*((C_word*)lf[436]+1);
t101=C_mutate((C_word*)lf[437]+1,t100);
t102=*((C_word*)lf[436]+1);
t103=C_mutate((C_word*)lf[438]+1,t102);
t104=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6682,tmp=(C_word)a,a+=2,tmp);
t105=C_mutate((C_word*)lf[437]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6743,a[2]=t104,tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6800,a[2]=t104,tmp=(C_word)a,a+=3,tmp));
t107=*((C_word*)lf[412]+1);
t108=*((C_word*)lf[408]+1);
t109=*((C_word*)lf[410]+1);
t110=*((C_word*)lf[112]+1);
t111=C_mutate((C_word*)lf[439]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6857,a[2]=t110,a[3]=t109,a[4]=t107,a[5]=t108,tmp=(C_word)a,a+=6,tmp));
t112=C_mutate((C_word*)lf[447]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7115,tmp=(C_word)a,a+=2,tmp));
t113=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t113+1)))(2,t113,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7115,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[447]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7111,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* ##sys#make-c-string */
t6=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t6=t5;
f_7111(2,t6,C_SCHEME_FALSE);}}

/* k7109 in set-root-directory! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1353(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2365 posix-error */
t3=lf[3];
f_1631(6,t3,((C_word*)t0)[3],lf[48],lf[447],lf[448],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_6857r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6857r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6857r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7030,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7035,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7040,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action13061342 */
t9=t8;
f_7040(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id13071340 */
t11=t7;
f_7035(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit13081337 */
t13=t6;
f_7030(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body13041310 */
t15=t5;
f_6859(t15,t1,t9,t11,t13);}}}}

/* def-action1306 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7040,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7046,tmp=(C_word)a,a+=2,tmp);
/* def-id13071340 */
t3=((C_word*)t0)[2];
f_7035(t3,t1,t2);}

/* a7045 in def-action1306 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7046,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1307 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7035,NULL,3,t0,t1,t2);}
/* def-limit13081337 */
t3=((C_word*)t0)[2];
f_7030(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1308 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7030(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7030,NULL,4,t0,t1,t2,t3);}
/* body13041310 */
t4=((C_word*)t0)[2];
f_6859(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6859,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[439]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6866(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7025,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_6866(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7017,tmp=(C_word)a,a+=2,tmp));}}

/* f_7017 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_7025 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7025,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6866(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6866,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_7005(2,t4,t2);}
else{
/* posixunix.scm: 2337 regexp? */
t4=*((C_word*)lf[446]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}

/* k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7005,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7006,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6999,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2340 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[445]);}

/* k6997 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2340 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6876,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6878,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6878(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6878(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6878,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2346 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6897,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2347 pathname-file */
t3=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6985,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2354 pproc */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6983 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6985,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6992,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2354 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2355 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6878(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6990 in k6983 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2354 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6878(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6979,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[440]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[441]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2347 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_6878(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2348 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6912,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6922,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6924,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6956,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2350 ##sys#dynamic-wind */
t11=*((C_word*)lf[443]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6969,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2353 pproc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k6970 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2353 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6969(2,t2,((C_word*)t0)[2]);}}

/* k6967 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2353 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6878(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6955 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6956,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[436]+1));}

/* a6931 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6940,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6954,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2351 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[442]);}

/* k6952 in a6931 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2351 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6938 in a6931 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6944,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2352 pproc */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k6945 in k6938 in a6931 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2352 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6944(2,t2,((C_word*)t0)[2]);}}

/* k6942 in k6938 in a6931 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2351 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6878(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6923 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[436]+1));}

/* k6920 in k6910 in k6977 in k6895 in loop in k6874 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2349 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6878(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7006 in k7003 in k6864 in body1304 in find-files in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7006,3,t0,t1,t2);}
/* posixunix.scm: 2338 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_6800r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6800r(t0,t1,t2,t3);}}

static void C_ccall f_6800r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6802,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6807,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6812,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args12801288 */
t7=t6;
f_6812(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env12811286 */
t9=t5;
f_6807(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body12781283 */
t11=t4;
f_6802(t11,t1,t7,t9);}}}

/* def-args1280 in process* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6812,NULL,2,t0,t1);}
/* def-env12811286 */
t2=((C_word*)t0)[2];
f_6807(t2,t1,C_SCHEME_FALSE);}

/* def-env1281 in process* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6807,NULL,3,t0,t1,t2);}
/* body12781283 */
t3=((C_word*)t0)[2];
f_6802(t3,t1,t2,C_SCHEME_FALSE);}

/* body1278 in process* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6802(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6802,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2315 %process */
f_6682(t1,lf[438],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6743(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_6743r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6743r(t0,t1,t2,t3);}}

static void C_ccall f_6743r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6745,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6750,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6755,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args12601268 */
t7=t6;
f_6755(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env12611266 */
t9=t5;
f_6750(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body12581263 */
t11=t4;
f_6745(t11,t1,t7,t9);}}}

/* def-args1260 in process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6755,NULL,2,t0,t1);}
/* def-env12611266 */
t2=((C_word*)t0)[2];
f_6750(t2,t1,C_SCHEME_FALSE);}

/* def-env1261 in process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6750,NULL,3,t0,t1,t2);}
/* body12581263 */
t3=((C_word*)t0)[2];
f_6745(t3,t1,t2,C_SCHEME_FALSE);}

/* body1258 in process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6745(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6745,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2312 %process */
f_6682(t1,lf[437],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6682(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6682,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6684,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6703,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2301 chkstrlst */
t12=t9;
f_6684(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6737,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2303 ##sys#shell-command-arguments */
t13=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t7)[1]);}}

/* k6735 in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6737,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2304 ##sys#shell-command */
t4=*((C_word*)lf[428]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6739 in k6735 in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6703(2,t3,t2);}

/* k6701 in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2305 chkstrlst */
t3=((C_word*)t0)[2];
f_6684(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6706(2,t3,C_SCHEME_UNDEFINED);}}

/* k6704 in k6701 in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2306 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6716 in k6704 in k6701 in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6717,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2308 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2309 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6710 in k6704 in k6701 in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6711,2,t0,t1);}
/* posixunix.scm: 2306 ##sys#process */
t2=*((C_word*)lf[435]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6684(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6684,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6692 in chkstrlst in %process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6693,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6618,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6624,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a6629 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6630,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6641,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6661,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2282 make-on-close */
t12=((C_word*)t0)[3];
f_6447(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k6659 in a6629 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2281 input-port */
t2=((C_word*)t0)[7];
f_6596(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6639 in a6629 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6645,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2284 make-on-close */
t4=((C_word*)t0)[6];
f_6447(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k6655 in k6639 in a6629 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2283 output-port */
t2=((C_word*)t0)[7];
f_6607(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6643 in k6639 in a6629 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6653,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2287 make-on-close */
t4=((C_word*)t0)[3];
f_6447(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k6651 in k6643 in k6639 in a6629 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2286 input-port */
t2=((C_word*)t0)[7];
f_6596(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6647 in k6643 in k6639 in a6629 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2280 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6623 in ##sys#process in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
/* posixunix.scm: 2275 spawn */
t2=((C_word*)t0)[8];
f_6551(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6607,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6611,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2271 connect-parent */
t8=((C_word*)t0)[2];
f_6504(t8,t7,t4,t5);}

/* k6609 in output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2272 ##sys#custom-output-port */
t2=*((C_word*)lf[327]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6596,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6600,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2267 connect-parent */
t8=((C_word*)t0)[2];
f_6504(t8,t7,t4,t5);}

/* k6598 in input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2268 ##sys#custom-input-port */
t2=*((C_word*)lf[313]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6551,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2254 needed-pipe */
t9=((C_word*)t0)[2];
f_6484(t9,t8,t6);}

/* k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2255 needed-pipe */
t3=((C_word*)t0)[2];
f_6484(t3,t2,((C_word*)t0)[5]);}

/* k6556 in k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2256 needed-pipe */
t3=((C_word*)t0)[2];
f_6484(t3,t2,((C_word*)t0)[6]);}

/* k6559 in k6556 in k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=f_6535(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6572,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2259 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6573 in k6559 in k6556 in k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6578,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2261 connect-child */
t3=((C_word*)t0)[7];
f_6518(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[290]+1));}

/* k6576 in a6573 in k6559 in k6556 in k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6581,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_6535(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2262 connect-child */
t4=((C_word*)t0)[5];
f_6518(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[291]+1));}

/* k6579 in k6576 in a6573 in k6559 in k6556 in k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_6535(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2263 connect-child */
t4=((C_word*)t0)[3];
f_6518(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[292]+1));}

/* k6582 in k6579 in k6576 in a6573 in k6559 in k6556 in k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2264 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6570 in k6559 in k6556 in k6553 in spawn in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2257 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6535(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_u_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6518(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6518,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6531,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2245 file-close */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k6529 in connect-child in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6531,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6443,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2219 duplicate-fileno */
t6=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k6441 in k6529 in connect-child in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2220 file-close */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6504(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6504,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6517,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2239 file-close */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6515 in connect-parent in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6484(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6484,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6499,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 2234 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a6498 in needed-pipe in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6499,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a6492 in needed-pipe in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6493,2,t0,t1);}
/* posixunix.scm: 2234 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* make-on-close in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6447(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6447,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6449,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,tmp=(C_word)a,a+=9,tmp));}

/* f_6449 in make-on-close in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6449,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2227 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a6469 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6470,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2229 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[196],((C_word*)t0)[3],lf[434],((C_word*)t0)[2],t4);}}

/* a6463 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6464,2,t0,t1);}
/* posixunix.scm: 2227 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6391r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6391r(t0,t1,t2,t3);}}

static void C_ccall f_6391r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6398,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2183 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k6396 in process-run in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2185 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2187 ##sys#shell-command */
t4=*((C_word*)lf[428]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k6415 in k6396 in process-run in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6421,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2187 ##sys#shell-command-arguments */
t3=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6419 in k6415 in k6396 in process-run in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2187 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6385,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[432],t2));}

/* ##sys#shell-command in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6380,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2172 getenv */
t3=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[430]);}

/* k6378 in ##sys#shell-command in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[429]));}

/* process-signal in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6349(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6349r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6349r(t0,t1,t2,t3);}}

static void C_ccall f_6349r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[426]);
t7=(C_word)C_i_check_exact_2(t5,lf[426]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2169 posix-error */
t10=lf[3];
f_1631(7,t10,t1,lf[196],lf[426],lf[427],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6346,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1126(C_SCHEME_UNDEFINED,t2));}

/* parent-process-id in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1123(C_SCHEME_UNDEFINED));}

/* current-process-id in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6340,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1121(C_SCHEME_UNDEFINED));}

/* process-wait in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6265(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6265r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6265r(t0,t1,t2);}}

static void C_ccall f_6265r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t2,C_fix(1)));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[421]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6292,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6298,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2153 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t13,t14);}

/* a6297 in process-wait in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6298,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2155 posix-error */
t6=lf[3];
f_1631(6,t6,t1,lf[196],lf[421],lf[422],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2156 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6291 in process-wait in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6292,2,t0,t1);}
/* posixunix.scm: 2153 ##sys#process-wait */
t2=*((C_word*)lf[420]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6248,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2140 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_6069r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6069r(t0,t1,t2,t3);}}

static void C_ccall f_6069r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6198,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6203,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist10611096 */
t7=t6;
f_6203(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist10621094 */
t9=t5;
f_6198(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body10591064 */
t11=t4;
f_6071(t11,t1,t7,t9);}}}

/* def-arglist1061 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6203,NULL,2,t0,t1);}
/* def-envlist10621094 */
t2=((C_word*)t0)[2];
f_6198(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist1062 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6198(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6198,NULL,3,t0,t1,t2);}
/* body10591064 */
t3=((C_word*)t0)[2];
f_6071(t3,t1,t2,C_SCHEME_FALSE);}

/* body1059 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6071(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6071,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[418]);
t5=(C_word)C_i_check_list_2(t2,lf[418]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6081,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2108 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}

/* k6079 in body1059 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_6053(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6089,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_6089(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do1068 in k6079 in body1059 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6089(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6089,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_6053(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6102,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[418]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=t5;
f_6102(t8,f_6135(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_6102(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[418]);
t6=(C_word)C_block_size(t4);
t7=f_6053(t3,t4,t6);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* do1072 in do1068 in k6079 in body1059 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(f_6061(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[418]);
t5=(C_word)C_block_size(t3);
t6=f_6061(t2,t3,t5);
t7=(C_word)C_slot(t1,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k6100 in do1068 in k6079 in body1059 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6102,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6127,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2122 ##sys#expand-home-path */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k6125 in k6100 in do1068 in k6079 in body1059 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2122 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6103 in k6100 in do1068 in k6079 in body1059 in process-execute in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub1040(C_SCHEME_UNDEFINED);
t5=(C_word)stub1052(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2129 posix-error */
t6=lf[3];
f_1631(6,t6,((C_word*)t0)[3],lf[196],lf[418],lf[419],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6061(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub1045(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* setarg in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6053(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub1033(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* process-fork in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6015r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6015r(t0,t1,t2);}}

static void C_ccall f_6015r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub1016(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2093 posix-error */
t5=lf[3];
f_1631(5,t5,t1,lf[196],lf[415],lf[416]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6037,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k6035 in process-fork in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6041,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_6041 in k6035 in process-fork in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6041,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1021(C_SCHEME_UNDEFINED,t2));}

/* glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_5903r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5903r(t0,t1,t2);}}

static void C_ccall f_5903r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_5909(t6,t1,t2);}

/* conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5909(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5909,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5924,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5930,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6007,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[414]);
/* posixunix.scm: 2077 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k6005 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2077 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 2078 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k5935 in k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2079 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k5938 in k5935 in k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[413]);
/* posixunix.scm: 2080 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5945 in k5938 in k5935 in k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5949(t5,((C_word*)t0)[2],t1);}

/* loop in k5945 in k5938 in k5935 in k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5949(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5949,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixunix.scm: 2081 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5909(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixunix.scm: 2082 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5964 in loop in k5945 in k5938 in k5935 in k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5966,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixunix.scm: 2083 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixunix.scm: 2084 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5949(t3,((C_word*)t0)[6],t2);}}

/* k5974 in k5964 in loop in k5945 in k5938 in k5935 in k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5980,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 2083 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5949(t4,t2,t3);}

/* k5978 in k5974 in k5964 in loop in k5945 in k5938 in k5935 in k5932 in a5929 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a5923 in conc-loop in glob in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5924,2,t0,t1);}
/* posixunix.scm: 2076 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5895,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub976(t3),C_fix(0));}

/* k5893 in get-host-name in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5898,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_5898(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2057 posix-error */
t3=lf[3];
f_1631(5,t3,t2,lf[400],lf[404],lf[405]);}}

/* k5896 in k5893 in get-host-name in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5856,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5860,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2038 ##sys#terminal-check */
f_5810(t3,lf[399],t2);}

/* k5858 in terminal-size in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5860,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5880,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[402]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[403]);}

/* k5878 in k5858 in terminal-size in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[402]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[403]);}

/* k5882 in k5878 in k5858 in terminal-size in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_pointer_argumentp(t3);
t5=(C_word)C_i_foreign_pointer_argumentp(t1);
t6=(C_word)stub962(C_SCHEME_UNDEFINED,t2,t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* posixunix.scm: 2045 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2046 posix-error */
t8=lf[3];
f_1631(6,t8,((C_word*)t0)[4],lf[400],lf[399],lf[401],((C_word*)t0)[6]);}}

/* terminal-name in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5837,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5841,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2030 ##sys#terminal-check */
f_5810(t3,lf[398],t2);}

/* k5839 in terminal-name in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t5=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub952(t4,t3),C_fix(0));}

/* ##sys#terminal-check in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5810(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5810,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5814,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2022 ##sys#check-port */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k5812 in ##sys#terminal-check in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[94],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2025 ##sys#error */
t5=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[397],((C_word*)t0)[4]);}}

/* terminal-port? in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5791,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5795,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2017 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[395]);}

/* k5793 in terminal-port? in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2018 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5796 in k5793 in terminal-port? in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5732r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5732r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5736,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2002 ##sys#check-port */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[389]);}

/* k5734 in set-buffering-mode! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[391]);
if(C_truep(t6)){
t7=t5;
f_5742(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[392]);
if(C_truep(t7)){
t8=t5;
f_5742(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[393]);
if(C_truep(t8)){
t9=t5;
f_5742(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2008 ##sys#error */
t9=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[389],lf[394],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k5740 in k5734 in set-buffering-mode! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[389]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[94],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2014 ##sys#error */
t6=*((C_word*)lf[144]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[389],lf[390],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5729,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub932(C_SCHEME_UNDEFINED,t2));}

/* _exit in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5713r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5713r(t0,t1,t2);}}

static void C_ccall f_5713r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub927(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub922(t2),C_fix(0));}

/* utc-time->seconds in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5677,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[383]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5684,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1970 ##sys#error */
t6=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[383],lf[385],t2);}
else{
t6=t4;
f_5684(2,t6,C_SCHEME_UNDEFINED);}}

/* k5682 in utc-time->seconds in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 1972 ##sys#cons-flonum */
t2=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1973 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[383],lf[384],((C_word*)t0)[3]);}}

/* local-time->seconds in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5649,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[379]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5656,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1963 ##sys#error */
t6=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[379],lf[382],t2);}
else{
t6=t4;
f_5656(2,t6,C_SCHEME_UNDEFINED);}}

/* k5654 in local-time->seconds in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1965 ##sys#cons-flonum */
t2=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1966 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[379],lf[381],((C_word*)t0)[3]);}}

/* string->time in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5610r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5610r(t0,t1,t2,t3);}}

static void C_ccall f_5610r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[378]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[377]);
t7=(C_word)C_i_check_string_2(t5,lf[377]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5627,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1959 ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k5625 in string->time in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5631,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1959 ##sys#make-c-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5629 in k5625 in string->time in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub903(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5535r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5535r(t0,t1,t2,t3);}}

static void C_ccall f_5535r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_vector_2(t2,lf[373]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5545,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(10)))){
/* posixunix.scm: 1943 ##sys#error */
t9=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,lf[373],lf[376],t2);}
else{
t9=t7;
f_5545(2,t9,C_SCHEME_UNDEFINED);}}

/* k5543 in time->string in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[373]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5564,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1947 ##sys#make-c-string */
t5=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub876(t4,t3),C_fix(0));}}

/* k5565 in k5543 in time->string in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1951 ##sys#substring */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1952 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[373],lf[375],((C_word*)t0)[2]);}}

/* k5562 in k5543 in time->string in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5564,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub882(t3,t2,t1),C_fix(0));}

/* k5552 in k5543 in time->string in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1948 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[373],lf[374],((C_word*)t0)[2]);}}

/* seconds->string in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5502,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5506,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub867(t5,t4),C_fix(0));}

/* k5504 in seconds->string in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1935 ##sys#substring */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1936 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[371],lf[372],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5488,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[370]);
/* posixunix.scm: 1928 ##sys#decode-seconds */
t4=*((C_word*)lf[369]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5479,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[368]);
/* posixunix.scm: 1924 ##sys#decode-seconds */
t4=*((C_word*)lf[369]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5473,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[359]));}

/* memory-mapped-file-pointer in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5464,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[359],lf[366]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5429r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5429r(t0,t1,t2,t3);}}

static void C_ccall f_5429r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_i_check_structure_2(t2,lf[359],lf[364]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)stub848(C_SCHEME_UNDEFINED,t8,t6);
t10=(C_word)C_eqp(C_fix(0),t9);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1911 posix-error */
t11=lf[3];
f_1631(7,t11,t1,lf[48],lf[364],lf[365],t2,t6);}}

/* map-file-to-memory in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_5371r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_5371r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_5371r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5375,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_5375(2,t10,t2);}
else{
/* posixunix.scm: 1896 ##sys#null-pointer */
t10=*((C_word*)lf[363]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k5373 in map-file-to-memory in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5375,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5381,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5381(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1899 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[59],lf[358],lf[362],t1);}}

/* k5379 in k5373 in map-file-to-memory in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5381,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)stub823(t7,t8,t3,t4,t5,t6,((C_word*)t0)[3]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5387,a[2]=((C_word*)t0)[7],a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1901 ##sys#pointer->address */
t12=*((C_word*)lf[361]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t9);}

/* k5398 in k5379 in k5373 in map-file-to-memory in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1902 posix-error */
t3=lf[3];
f_1631(11,t3,((C_word*)t0)[8],lf[48],lf[358],lf[360],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_5387(2,t3,C_SCHEME_UNDEFINED);}}

/* k5385 in k5379 in k5373 in map-file-to-memory in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[359],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5288,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5294,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5294(t5,t1,C_fix(0));}

/* loop in current-environment in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5294(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5294,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5298,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub805(t5,t4),C_fix(0));}

/* k5296 in loop in current-environment in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5298,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5306,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5306(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k5296 in loop in current-environment in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5306(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5306,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1863 ##sys#substring */
t5=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1866 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k5330 in scan in k5296 in loop in current-environment in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1864 ##sys#substring */
t5=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k5334 in k5330 in scan in k5296 in loop in current-environment in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5324,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1865 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5294(t5,t3,t4);}

/* k5322 in k5334 in k5330 in scan in k5296 in loop in current-environment in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5273,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[347]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5281,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1852 ##sys#make-c-string */
t5=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5279 in unsetenv in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5256,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[346]);
t5=(C_word)C_i_check_string_2(t3,lf[346]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5267,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1847 ##sys#make-c-string */
t7=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5265 in setenv in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1847 ##sys#make-c-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5269 in k5265 in setenv in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5230,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[344]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5237,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5254,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1836 ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5252 in fifo? in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1836 ##sys#file-info */
t2=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5235 in fifo? in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1839 posix-error */
t2=lf[3];
f_1631(6,t2,((C_word*)t0)[3],lf[48],lf[344],lf[345],((C_word*)t0)[2]);}}

/* create-fifo in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5187r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5187r(t0,t1,t2,t3);}}

static void C_ccall f_5187r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[342]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5194,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_5194(t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_5194(t7,(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k5192 in create-fifo in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5194,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[342]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5215,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1830 ##sys#expand-home-path */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k5213 in k5192 in create-fifo in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1830 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5209 in k5192 in create-fifo in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1831 posix-error */
t3=lf[3];
f_1631(7,t3,((C_word*)t0)[3],lf[48],lf[342],lf[343],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5159,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[333],lf[340]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1820 posix-error */
t9=lf[3];
f_1631(6,t9,t1,lf[48],lf[340],lf[341],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5137r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5137r(t0,t1,t2,t3);}}

static void C_ccall f_5137r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1811 setup */
f_5018(t4,t2,t3,lf[338]);}

/* k5139 in file-test-lock in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1813 err */
f_5089(((C_word*)t0)[3],lf[339],t1,lf[338]);}}

/* file-lock/blocking in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5122r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5122r(t0,t1,t2,t3);}}

static void C_ccall f_5122r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5126,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1805 setup */
f_5018(t4,t2,t3,lf[336]);}

/* k5124 in file-lock/blocking in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1807 err */
f_5089(((C_word*)t0)[2],lf[337],t1,lf[336]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5107r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5107r(t0,t1,t2,t3);}}

static void C_ccall f_5107r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5111,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1799 setup */
f_5018(t4,t2,t3,lf[334]);}

/* k5109 in file-lock in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1801 err */
f_5089(((C_word*)t0)[2],lf[335],t1,lf[334]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5089(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5089,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1796 posix-error */
t8=lf[3];
f_1631(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5018(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5018,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_u_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_u_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t8,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5037,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1788 ##sys#check-port */
t16=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}

/* k5035 in setup in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5037,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_5043(t6,t5);}
else{
t5=t3;
f_5043(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k5041 in k5035 in setup in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5043(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5043,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[333],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4979,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[330]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4996,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5003,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5007,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1771 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_4996(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1773 ##sys#error */
t6=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[330],lf[332],t2);}}}

/* k5005 in file-truncate in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1771 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5001 in file-truncate in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4996(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k4994 in file-truncate in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1775 posix-error */
t2=lf[3];
f_1631(7,t2,((C_word*)t0)[4],lf[48],lf[330],lf[331],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr5r,(void*)f_4723r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4723r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4723r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4914,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4919,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?697738 */
t10=t9;
f_4919(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi698736 */
t12=t8;
f_4914(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close699733 */
t14=t7;
f_4909(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body695701 */
t16=t6;
f_4725(t16,t1,t10,t12,t14);}}}}

/* def-nonblocking?697 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4919,NULL,2,t0,t1);}
/* def-bufi698736 */
t2=((C_word*)t0)[2];
f_4914(t2,t1,C_SCHEME_FALSE);}

/* def-bufi698 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4914,NULL,3,t0,t1,t2);}
/* def-on-close699733 */
t3=((C_word*)t0)[2];
f_4909(t3,t1,t2,C_fix(0));}

/* def-on-close699 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4909(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4909,NULL,4,t0,t1,t2,t3);}
/* body695701 */
t4=((C_word*)t0)[2];
f_4725(t4,t1,t2,t3,*((C_word*)lf[325]+1));}

/* body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4725(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4725,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1713 ##sys#file-nonblocking! */
t6=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_4729(2,t6,C_SCHEME_UNDEFINED);}}

/* k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4729,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_4777(t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4821,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4835,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1732 ##sys#make-string */
t12=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_4835(2,t12,((C_word*)t0)[6]);}}}

/* k4833 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_4777(t4,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4836,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));}

/* f_4836 in k4833 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4836,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4853,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_4853(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1748 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4731(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_4853(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4853,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4863,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1738 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4731(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_difference(t4,t2);
/* posixunix.scm: 1743 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k4861 in loop */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1740 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4853(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_4821 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4821,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1731 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4731(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4775 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4777(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4777,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4786,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4792,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1751 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}

/* a4812 in k4775 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
/* posixunix.scm: 1761 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* a4791 in k4775 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4792,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1758 posix-error */
t3=lf[3];
f_1631(7,t3,t2,lf[48],((C_word*)t0)[3],lf[329],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4802(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4800 in a4791 in k4775 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1759 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4785 in k4775 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4786,3,t0,t1,t2);}
/* posixunix.scm: 1753 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k4779 in k4775 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1762 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4782 in k4779 in k4775 in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4731(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4731,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4747,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1721 ##sys#thread-yield! */
t8=*((C_word*)lf[315]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1723 posix-error */
t7=lf[3];
f_1631(7,t7,t1,((C_word*)t0)[3],lf[48],lf[328],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4766,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1725 ##sys#substring */
t7=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4764 in poke in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1725 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4731(t3,((C_word*)t0)[2],t1,t2);}

/* k4745 in poke in k4727 in body695 in ##sys#custom-output-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1722 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4731(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_4252r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4252r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(19);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4633,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4638,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4643,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4648,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?587676 */
t11=t10;
f_4648(t11,t1);}
else{
t11=(C_word)C_u_i_car(t5);
t12=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi588674 */
t13=t9;
f_4643(t13,t1,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close589671 */
t15=t8;
f_4638(t15,t1,t11,t13);}
else{
t15=(C_word)C_u_i_car(t14);
t16=(C_word)C_slot(t14,C_fix(1));
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?590667 */
t17=t7;
f_4633(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_u_i_car(t16);
t18=(C_word)C_slot(t16,C_fix(1));
/* body585592 */
t19=t6;
f_4254(t19,t1,t11,t13,t15,t17);}}}}}

/* def-nonblocking?587 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4648,NULL,2,t0,t1);}
/* def-bufi588674 */
t2=((C_word*)t0)[2];
f_4643(t2,t1,C_SCHEME_FALSE);}

/* def-bufi588 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4643,NULL,3,t0,t1,t2);}
/* def-on-close589671 */
t3=((C_word*)t0)[2];
f_4638(t3,t1,t2,C_fix(1));}

/* def-on-close589 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4638(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4638,NULL,4,t0,t1,t2,t3);}
/* def-more?590667 */
t4=((C_word*)t0)[2];
f_4633(t4,t1,t2,t3,*((C_word*)lf[325]+1));}

/* def-more?590 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4633,NULL,5,t0,t1,t2,t3,t4);}
/* body585592 */
t5=((C_word*)t0)[2];
f_4254(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4254,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4258,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1591 ##sys#file-nonblocking! */
t7=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_4258(2,t7,C_SCHEME_UNDEFINED);}}

/* k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1593 ##sys#make-string */
t5=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_4264(2,t5,((C_word*)t0)[10]);}}

/* k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4280,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4375,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4388,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4421,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4506,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1637 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t18+1)))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4506,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4512,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_4512(t7,t1,C_SCHEME_FALSE);}

/* loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4512(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4512,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4592,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1696 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4608,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1702 fetch */
t5=((C_word*)t0)[5];
f_4288(t5,t4);}}

/* k4606 in loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1704 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4512(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a4597 in loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4598,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1699 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4512(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4591 in loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
/* posixunix.scm: 1697 ##sys#scan-buffer-line */
t2=*((C_word*)lf[324]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4514,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_4521(2,t8,(C_truep(t7)?t7:lf[321]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4564,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1679 ##sys#make-string */
t8=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k4562 in bumper in loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1685 ##sys#string-append */
t6=*((C_word*)lf[322]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_4521(2,t6,t1);}}

/* k4519 in bumper in loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4531,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1689 fetch */
t5=((C_word*)t0)[3];
f_4288(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_u_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1694 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k4529 in k4519 in bumper in loop in a4505 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1690 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4429 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4430,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4438,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_4438(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_4438(t8,(C_word)C_u_fixnum_difference(t7,t5));}}

/* k4436 in a4429 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4438,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4440(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k4436 in a4429 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4440(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4440,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* posixunix.scm: 1665 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4488,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1667 fetch */
t7=((C_word*)t0)[2];
f_4288(t7,t6);}}}

/* k4486 in loop in k4436 in a4429 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1670 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4440(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a4420 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1655 fetch */
t3=((C_word*)t0)[2];
f_4288(t3,t2);}

/* k4423 in a4420 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1656 peek */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4280(((C_word*)t0)[2]));}

/* a4399 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1652 posix-error */
t3=lf[3];
f_1631(7,t3,t2,lf[48],((C_word*)t0)[3],lf[320],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4410(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4408 in a4399 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1653 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4387 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1647 ready? */
t3=((C_word*)t0)[2];
f_4265(t3,t1);}}

/* a4374 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4379,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1639 fetch */
t3=((C_word*)t0)[2];
f_4288(t3,t2);}

/* k4377 in a4374 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_4280(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k4368 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1706 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4371 in k4368 in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4288,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4300(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4300,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4316,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1614 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[317]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1617 posix-error */
t5=lf[3];
f_1631(7,t5,t1,lf[48],((C_word*)t0)[6],lf[318],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1621 more? */
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k4335 in loop in fetch in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1623 ##sys#thread-yield! */
t3=*((C_word*)lf[315]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_4346(2,t8,t7);}
else{
/* posixunix.scm: 1629 posix-error */
t7=lf[3];
f_1631(7,t7,t4,lf[48],((C_word*)t0)[3],lf[319],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_4346(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4344 in k4335 in loop in fetch in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4338 in k4335 in loop in fetch in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1624 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4300(t2,((C_word*)t0)[2]);}

/* k4314 in loop in fetch in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1615 ##sys#thread-yield! */
t3=*((C_word*)lf[315]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4317 in k4314 in loop in fetch in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1616 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4300(t2,((C_word*)t0)[2]);}

/* peek in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_4280(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4265,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1599 ##sys#file-select-one */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4277 in ready? in k4262 in k4256 in body585 in ##sys#custom-input-port in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1600 posix-error */
t3=lf[3];
f_1631(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[314],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4225r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4225r(t0,t1,t2,t3);}}

static void C_ccall f_4225r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[309]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4232,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4232(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[309]);
t8=t5;
f_4232(t8,(C_word)C_dup2(t2,t6));}}

/* k4230 in duplicate-fileno in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4232,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4235,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1584 posix-error */
t3=lf[3];
f_1631(6,t3,t2,lf[48],lf[309],lf[310],((C_word*)t0)[2]);}
else{
t3=t2;
f_4235(2,t3,C_SCHEME_UNDEFINED);}}

/* k4233 in k4230 in duplicate-fileno in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4180,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4184,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1566 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[303]);}

/* k4182 in port->fileno in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[304],t2);
if(C_truep(t3)){
/* posixunix.scm: 1567 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[305]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1568 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k4217 in k4182 in port->fileno in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4219,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1573 posix-error */
t2=lf[3];
f_1631(6,t2,((C_word*)t0)[3],lf[59],lf[303],lf[306],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4202,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1571 posix-error */
t4=lf[3];
f_1631(6,t4,t3,lf[48],lf[303],lf[307],((C_word*)t0)[2]);}
else{
t4=t3;
f_4202(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4200 in k4217 in k4182 in port->fileno in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4166r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4166r(t0,t1,t2,t3);}}

static void C_ccall f_4166r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[302]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4178,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1562 mode */
f_4100(t5,C_SCHEME_FALSE,t3);}

/* k4176 in open-output-file* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1562 check */
f_4137(((C_word*)t0)[2],lf[302],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4152r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4152r(t0,t1,t2,t3);}}

static void C_ccall f_4152r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[301]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4164,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1558 mode */
f_4100(t5,C_SCHEME_TRUE,t3);}

/* k4162 in open-input-file* in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1558 check */
f_4137(((C_word*)t0)[2],lf[301],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4137(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4137,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1551 posix-error */
t6=lf[3];
f_1631(6,t6,t1,lf[48],t2,lf[299],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4150,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1552 ##sys#make-port */
t7=*((C_word*)lf[147]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[148]+1),lf[300],lf[94]);}}

/* k4148 in check in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4100(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4100,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[293]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1545 ##sys#error */
t8=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[294],t5);}
else{
t8=t4;
f_4108(2,t8,lf[295]);}}
else{
/* posixunix.scm: 1546 ##sys#error */
t7=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[296],t5);}}
else{
t5=t4;
f_4108(2,t5,(C_truep(t2)?lf[297]:lf[298]));}}

/* k4106 in mode in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1541 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4075,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[287]);
t5=(C_word)C_i_check_string_2(t3,lf[287]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_4064(2,t9,C_SCHEME_FALSE);}}

/* k4062 in file-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_4068(2,t3,C_SCHEME_FALSE);}}

/* k4066 in k4062 in file-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub529(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1526 posix-error */
t3=lf[3];
f_1631(7,t3,((C_word*)t0)[4],lf[48],lf[288],lf[289],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4033,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[285]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4041,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4057,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1515 ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4055 in read-symbolic-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4039 in read-symbolic-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4044,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1517 posix-error */
t4=lf[3];
f_1631(6,t4,t3,lf[48],lf[285],lf[286],((C_word*)t0)[2]);}
else{
t4=t3;
f_4044(2,t4,C_SCHEME_UNDEFINED);}}

/* k4042 in k4039 in read-symbolic-link in k4030 in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1518 substring */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3995,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[281]);
t5=(C_word)C_i_check_string_2(t3,lf[281]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4016,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4028,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1503 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4026 in create-symbolic-link in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1503 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4014 in create-symbolic-link in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1504 ##sys#expand-home-path */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4022 in k4014 in create-symbolic-link in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1504 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4018 in k4014 in create-symbolic-link in k3991 in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1506 posix-error */
t3=lf[3];
f_1631(7,t3,((C_word*)t0)[4],lf[48],lf[282],lf[283],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3970,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[278]);
t5=(C_word)C_i_check_exact_2(t3,lf[278]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3986,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1481 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k3984 in set-process-group-id! in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1482 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[278],lf[279],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-session in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3959,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1473 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3959(2,t4,C_SCHEME_UNDEFINED);}}

/* k3963 in create-session in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1474 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[276],lf[277]);}

/* k3957 in create-session in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3949,3,t0,t1,t2);}
/* posixunix.scm: 1468 check */
f_3913(t1,t2,C_fix((C_word)X_OK),lf[275]);}

/* file-write-access? in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3943,3,t0,t1,t2);}
/* posixunix.scm: 1467 check */
f_3913(t1,t2,C_fix((C_word)W_OK),lf[274]);}

/* file-read-access? in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3937,3,t0,t1,t2);}
/* posixunix.scm: 1466 check */
f_3913(t1,t2,C_fix((C_word)R_OK),lf[273]);}

/* check in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3913(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3913,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3931,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3935,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1463 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3933 in check in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1463 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3929 in check in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3923,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3923(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1464 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3921 in k3929 in check in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3883,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[271]);
t6=(C_word)C_i_check_exact_2(t3,lf[271]);
t7=(C_word)C_i_check_exact_2(t4,lf[271]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3907,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3911,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1453 ##sys#expand-home-path */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k3909 in change-file-owner in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1453 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3905 in change-file-owner in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1454 posix-error */
t3=lf[3];
f_1631(8,t3,((C_word*)t0)[3],lf[48],lf[271],lf[272],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3856,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[269]);
t5=(C_word)C_i_check_exact_2(t3,lf[269]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3877,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1445 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3879 in change-file-mode in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1445 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3875 in change-file-mode in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1446 posix-error */
t3=lf[3];
f_1631(7,t3,((C_word*)t0)[3],lf[48],lf[269],lf[270],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3792,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[228]);
t5=(C_word)C_i_check_exact_2(t3,lf[228]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3788,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_3788(2,t9,C_SCHEME_FALSE);}}

/* k3786 in initialize-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=(C_word)stub469(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1366 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3806 in k3786 in initialize-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1367 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[228],lf[229],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3726,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3730,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_3660(t4);
if(C_truep(t5)){
t6=t3;
f_3730(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1349 ##sys#error */
t6=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[225],lf[227]);}}

/* k3728 in set-groups! in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3735,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3735(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do456 in k3728 in set-groups! in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3735,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1354 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[225]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k3749 in do456 in k3728 in set-groups! in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1355 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[225],lf[226],((C_word*)t0)[2]);}

/* get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3663,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3667,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1335 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3667(2,t4,C_SCHEME_UNDEFINED);}}

/* k3719 in get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1336 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[221],lf[224]);}

/* k3665 in get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_3660(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_3670(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1338 ##sys#error */
t4=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[221],lf[223]);}}

/* k3668 in k3665 in get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)stub438(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3702,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1340 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_3673(2,t4,C_SCHEME_UNDEFINED);}}

/* k3700 in k3668 in k3665 in get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1341 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[221],lf[222]);}

/* k3671 in k3668 in k3665 in get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3678,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3678(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3671 in k3668 in k3665 in get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3678,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3692,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1345 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3690 in loop in k3671 in k3668 in k3665 in get-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_3660(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub442(C_SCHEME_UNDEFINED,t1));}

/* group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3585r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3585r(t0,t1,t2,t3);}}

static void C_ccall f_3585r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3592,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_3592(t7,(C_word)C_getgrgid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[219]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3643,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1309 ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k3641 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3592(t2,(C_word)C_getgrnam(t1));}

/* k3590 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3592,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3600 in k3590 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3606,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k3604 in k3600 in k3590 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3610,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3615(t6,t2,C_fix(0));}

/* loop in k3604 in k3600 in k3590 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3615(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3615,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub421(t5,t4),C_fix(0));}

/* k3617 in loop in k3604 in k3600 in k3590 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3629,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1318 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3615(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k3627 in k3617 in loop in k3604 in k3600 in k3590 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3629,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3608 in k3604 in k3600 in k3590 in group-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[216]+1):*((C_word*)lf[217]+1));
t3=t2;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3573,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1294 current-effective-user-id */
t4=*((C_word*)lf[210]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3575 in current-effective-user-name in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1294 user-information */
t2=*((C_word*)lf[215]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3571 in current-effective-user-name in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1291 current-user-id */
t4=*((C_word*)lf[209]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3561 in current-user-name in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1291 user-information */
t2=*((C_word*)lf[215]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3557 in current-user-name in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3491r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3491r(t0,t1,t2,t3);}}

static void C_ccall f_3491r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3498,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_3498(t7,(C_word)C_getpwuid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[215]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1279 ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k3535 in user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3498(t2,(C_word)C_getpwnam(t1));}

/* k3496 in user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3498(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3498,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3506 in k3496 in user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3512,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k3510 in k3506 in k3496 in user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3516,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k3514 in k3510 in k3506 in k3496 in user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3520,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k3518 in k3514 in k3510 in k3506 in k3496 in user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3524,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k3522 in k3518 in k3514 in k3510 in k3506 in k3496 in user-information in k3487 in k3483 in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[216]+1):*((C_word*)lf[217]+1));
t3=t2;
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-group-id! in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3468,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3478,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1249 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3476 in set-group-id! in k3464 in k3460 in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1250 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[207],lf[212],((C_word*)t0)[2]);}

/* set-user-id! in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3445,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1229 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3453 in set-user-id! in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1230 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[207],lf[208],((C_word*)t0)[2]);}

/* system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1218 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3411(2,t3,C_SCHEME_UNDEFINED);}}

/* k3438 in system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1219 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[204],lf[206]);}

/* k3409 in system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k3416 in k3409 in system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3422,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k3420 in k3416 in k3409 in system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3426,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k3424 in k3420 in k3416 in k3409 in system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3430,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k3428 in k3424 in k3420 in k3416 in k3409 in system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3434,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k3432 in k3428 in k3424 in k3420 in k3416 in k3409 in system-information in k3403 in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3389,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1197 posix-error */
t5=lf[3];
f_1631(5,t5,t1,lf[196],lf[202],lf[203]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3374,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[200]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1191 posix-error */
t5=lf[3];
f_1631(5,t5,t1,lf[196],lf[200],lf[201]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3368,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3336,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3342,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3342(t5,t1,*((C_word*)lf[191]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3342(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3342,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1181 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3312,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[195]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3330,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a3329 in set-signal-mask! in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3330,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k3317 in set-signal-mask! in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1174 posix-error */
t2=lf[3];
f_1631(5,t2,((C_word*)t0)[2],lf[196],lf[195],lf[197]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3294,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3304,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1160 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1162 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k3302 in ##sys#interrupt-hook in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1161 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3281,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[194]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k3268 in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3272,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[193]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1077 posix-error */
t3=lf[3];
f_1631(5,t3,t2,lf[48],lf[164],lf[165]);}
else{
t3=t2;
f_3229(2,t3,C_SCHEME_UNDEFINED);}}

/* k3227 in create-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1078 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3205r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3205r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3205r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[163]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3209,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3207 in with-output-to-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3215,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1065 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3214 in k3207 in with-output-to-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3215r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3215r(t0,t1,t2);}}

static void C_ccall f_3215r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3219,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1067 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3217 in a3214 in k3207 in with-output-to-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[163]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3185r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3185r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3185r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[161]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3189,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3187 in with-input-from-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3195,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1055 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3194 in k3187 in with-input-from-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3195r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3195r(t0,t1,t2);}}

static void C_ccall f_3195r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3199,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1057 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3197 in a3194 in k3187 in with-input-from-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[161]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3161r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3161r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3161r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3165,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3163 in call-with-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3170,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3176,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1045 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3175 in k3163 in call-with-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3176r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3176r(t0,t1,t2);}}

static void C_ccall f_3176r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3180,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1048 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3178 in a3175 in k3163 in call-with-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3169 in k3163 in call-with-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3170,2,t0,t1);}
/* posixunix.scm: 1046 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3137r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3137r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3137r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3141,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3139 in call-with-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1037 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3151 in k3139 in call-with-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3152r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3152r(t0,t1,t2);}}

static void C_ccall f_3152r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3156,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1040 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3154 in a3151 in k3139 in call-with-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3145 in k3139 in call-with-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
/* posixunix.scm: 1038 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3121,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3125,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1024 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[153]);}

/* k3123 in close-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3128,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1026 posix-error */
t5=lf[3];
f_1631(6,t5,t3,lf[48],lf[154],lf[155],((C_word*)t0)[3]);}
else{
t5=t3;
f_3128(2,t5,C_SCHEME_UNDEFINED);}}

/* k3126 in k3123 in close-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3085r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3085r(t0,t1,t2,t3);}}

static void C_ccall f_3085r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=f_3016(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3099,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1019 ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3116,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1020 ##sys#make-c-string */
t10=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1021 badmode */
f_3028(t6,t5);}}}

/* k3114 in open-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3099(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k3104 in open-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3099(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k3097 in open-output-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1015 check */
f_3034(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3049r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3049r(t0,t1,t2,t3);}}

static void C_ccall f_3049r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[150]);
t5=f_3016(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3063,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3070,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1008 ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1009 ##sys#make-c-string */
t10=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1010 badmode */
f_3028(t6,t5);}}}

/* k3078 in open-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3080,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3063(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k3068 in open-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3063(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k3061 in open-input-pipe in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 check */
f_3034(((C_word*)t0)[3],lf[150],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3034(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3034,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 996  posix-error */
t6=lf[3];
f_1631(6,t6,t1,lf[48],t2,lf[146],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3047,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 997  ##sys#make-port */
t7=*((C_word*)lf[147]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[148]+1),lf[149],lf[94]);}}

/* k3045 in check in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3028(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3028,NULL,2,t1,t2);}
/* posixunix.scm: 993  ##sys#error */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[145],t2);}

/* mode in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_3016(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[143]));}

/* canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2699,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[127]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2706,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2820,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 941  cwd */
t8=((C_word*)t0)[6];
f_2643(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 943  sref */
t10=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_2826(t9,C_SCHEME_FALSE);}}}

/* k3004 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 943  sep? */
t2=((C_word*)t0)[3];
f_2826(t2,f_2632(t1));}

/* k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2826,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_2706(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 946  cwd */
t5=((C_word*)t0)[8];
f_2643(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2992,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 947  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k2990 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 947  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k2979 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 948  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2845(t2,C_SCHEME_FALSE);}}

/* k2986 in k2979 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 948  sep? */
t2=((C_word*)t0)[3];
f_2845(t2,f_2632(t1));}

/* k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2845,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 950  getenv */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[140]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 955  cwd */
t5=((C_word*)t0)[6];
f_2643(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 956  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k2972 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 956  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2951 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2970,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 957  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_2889(t2,C_SCHEME_FALSE);}}

/* k2968 in k2951 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 957  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2957 in k2951 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 958  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_2889(t2,C_SCHEME_FALSE);}}

/* k2964 in k2957 in k2951 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 958  sep? */
t2=((C_word*)t0)[3];
f_2889(t2,f_2632(t1));}

/* k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2889,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 959  ##sys#substring */
t3=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 960  sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k2948 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 960  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k2927 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2929,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2946,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 961  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2902(2,t2,C_SCHEME_FALSE);}}

/* k2944 in k2927 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 961  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2933 in k2927 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 962  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_2902(2,t2,C_SCHEME_FALSE);}}

/* k2940 in k2933 in k2927 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 962  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2900 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2902,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 963  ##sys#substring */
t3=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 964  sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k2924 in k2900 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=f_2632(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_2706(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 967  cwd */
t4=((C_word*)t0)[2];
f_2643(t4,t3);}}

/* k2920 in k2924 in k2900 in k2887 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 967  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[142],((C_word*)t0)[2]);}

/* k2881 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 955  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[141],((C_word*)t0)[2]);}

/* k2850 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2855(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 951  user */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2868 in k2850 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 951  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k2853 in k2850 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2859,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 952  ##sys#substring */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k2857 in k2853 in k2850 in k2843 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 949  sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2837 in k2824 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 946  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k2818 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 941  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[137]);}

/* k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[136]);}

/* k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2715(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2715(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2715,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 970  null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 971  null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2783,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 982  string=? */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[134],t5);}}

/* k2784 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2783(t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 984  string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[133],t3);}}

/* k2793 in k2784 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2783(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_2783(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k2781 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 980  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2715(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2726 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2728,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[128]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 973  sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k2762 in k2726 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
t2=f_2632(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2745,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[130],((C_word*)t0)[2]);
/* posixunix.scm: 976  reverse */
t6=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2760,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 979  reverse */
t5=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2758 in k2762 in k2726 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 979  isperse */
f_2627(((C_word*)t0)[2],t1);}

/* k2754 in k2762 in k2726 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[132],t1);}

/* k2743 in k2762 in k2726 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  isperse */
f_2627(((C_word*)t0)[2],t1);}

/* k2739 in k2762 in k2726 in k2720 in loop in k2711 in k2704 in canonical-path in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[129],t1);}

/* cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2643,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[126]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a2651 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2652,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2658,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2676,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a2675 in a2651 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a2687 in a2675 in a2651 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2688r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2688r(t0,t1,t2);}}

static void C_ccall f_2688r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2694,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g273275 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2693 in a2687 in a2675 in a2651 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2681 in a2675 in a2651 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
/* posixunix.scm: 936  cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a2657 in a2651 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2658,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g273275 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2663 in a2657 in a2651 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[123]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[124]);}

/* k2648 in cwd in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* sep? in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_2632(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2627(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2627,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[120]);}

/* current-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2586r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2586r(t0,t1,t2);}}

static void C_ccall f_2586r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixunix.scm: 914  change-directory */
t5=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 915  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k2597 in current-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 918  ##sys#substring */
t3=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 919  posix-error */
t3=lf[3];
f_1631(5,t3,((C_word*)t0)[2],lf[48],lf[111],lf[114]);}}

/* directory? in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2563,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[112]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2570,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2584,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 907  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2582 in directory? in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 907  ##sys#file-info */
t2=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2568 in directory? in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_2409r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2409r(t0,t1,t2);}}

static void C_ccall f_2409r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec210235 */
t6=t5;
f_2514(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?211233 */
t8=t4;
f_2509(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body208213 */
t10=t3;
f_2411(t10,t1,t6,t8);}}}

/* def-spec210 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2514,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2522,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 880  current-directory */
t3=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2520 in def-spec210 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?211233 */
t2=((C_word*)t0)[3];
f_2509(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?211 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2509(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2509,NULL,3,t0,t1,t2);}
/* body208213 */
t3=((C_word*)t0)[2];
f_2411(t3,t1,t2,C_SCHEME_FALSE);}

/* body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2411,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[108]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 882  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 883  ##sys#make-pointer */
t3=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 884  ##sys#make-pointer */
t3=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 885  ##sys#expand-home-path */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k2506 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 885  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2426 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 887  posix-error */
t3=lf[3];
f_1631(6,t3,((C_word*)t0)[7],lf[48],lf[108],lf[109],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2442(t6,((C_word*)t0)[7]);}}

/* loop in k2426 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2442,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 895  ##sys#substring */
t5=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k2450 in loop in k2426 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 896  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k2453 in k2450 in loop in k2426 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 897  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_2458(2,t3,C_SCHEME_FALSE);}}

/* k2456 in k2453 in k2450 in loop in k2426 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_2464(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_2464(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_2464(t4,C_SCHEME_FALSE);}}

/* k2462 in k2456 in k2453 in k2450 in loop in k2426 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2464,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 902  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2442(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 903  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2442(t3,t2);}}

/* k2472 in k2462 in k2456 in k2453 in k2450 in loop in k2426 in k2422 in k2419 in k2416 in body208 in directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2385,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 873  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2405 in delete-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 873  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2401 in delete-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 874  posix-error */
t3=lf[3];
f_1631(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[105],((C_word*)t0)[2]);}}

/* change-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2361,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[102]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2383,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 867  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2381 in change-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 867  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2377 in change-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 868  posix-error */
t3=lf[3];
f_1631(6,t3,((C_word*)t0)[3],lf[48],lf[102],lf[103],((C_word*)t0)[2]);}}

/* create-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2337,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2355,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 861  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2357 in create-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 861  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2353 in create-directory in k2333 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 862  posix-error */
t3=lf[3];
f_1631(6,t3,((C_word*)t0)[3],lf[48],lf[100],lf[101],((C_word*)t0)[2]);}}

/* set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2275r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2275r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2275r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[92]);
t8=(C_word)C_i_check_exact_2(t6,lf[92]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2288,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 833  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[97],lf[92],lf[98],t3,t2);}
else{
t10=t9;
f_2288(2,t10,C_SCHEME_UNDEFINED);}}

/* k2286 in set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 834  port? */
t4=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2298 in k2286 in set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[94]);
t4=((C_word*)t0)[4];
f_2294(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_2294(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 838  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[59],lf[92],lf[95],((C_word*)t0)[5]);}}}

/* k2292 in k2286 in set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 839  posix-error */
t2=lf[3];
f_1631(7,t2,((C_word*)t0)[4],lf[48],lf[92],lf[93],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* stat-socket? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2266,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2273,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 825  ##sys#stat */
f_2096(t4,t2,C_SCHEME_FALSE,lf[91]);}

/* k2271 in stat-socket? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2257,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2264,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 820  ##sys#stat */
f_2096(t4,t2,C_SCHEME_TRUE,lf[90]);}

/* k2262 in stat-symlink? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2248,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 815  ##sys#stat */
f_2096(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k2253 in stat-fifo? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2239,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 810  ##sys#stat */
f_2096(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k2244 in stat-block-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2230,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 805  ##sys#stat */
f_2096(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k2235 in stat-char-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2221,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 800  ##sys#stat */
f_2096(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k2226 in stat-directory? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2212,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2219,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 795  ##sys#stat */
f_2096(t4,t2,C_SCHEME_FALSE,lf[85]);}

/* k2217 in stat-regular? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2203,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 790  ##sys#stat */
f_2096(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k2208 in symbolic-link? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2194,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 785  ##sys#stat */
f_2096(t4,t2,C_SCHEME_TRUE,lf[83]);}

/* k2199 in regular-file? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2188,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2192,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 781  ##sys#stat */
f_2096(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k2190 in file-permissions in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2182,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_2096(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k2184 in file-owner in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_2096(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k2178 in file-change-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2170,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_2096(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k2172 in file-access-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2164,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_2096(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k2166 in file-modification-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2158,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2162,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_2096(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k2160 in file-size in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2133r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2133r(t0,t1,t2,t3);}}

static void C_ccall f_2133r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2137,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* posixunix.scm: 769  ##sys#stat */
f_2096(t4,t2,t6,lf[76]);}

/* k2135 in file-stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2096(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2096,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2100,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_2100(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 760  ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 764  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[59],lf[75],t2);}}}

/* k2126 in ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 760  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2119 in ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2100(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k2098 in ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 766  posix-error */
t2=lf[3];
f_1631(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[74],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1904r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1904r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1904r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(15);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1898(C_fix(0));
t10=f_1898(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1920(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 689  fd_set */
t14=t12;
f_1920(2,t14,f_1900(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[67]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a2076 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2077,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[67]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 696  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1900(C_fix(0),t2));}

/* k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1920,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1926(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 701  fd_set */
t5=t3;
f_1926(2,t5,f_1900(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[67]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a2050 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2051,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[67]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 708  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1900(C_fix(1),t2));}

/* k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[67]);
t4=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_1929(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1929(t4,(C_word)C_C_select(t3));}}

/* k1927 in k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_1929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1929,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 715  posix-error */
t2=lf[3];
f_1631(7,t2,((C_word*)t0)[5],lf[48],lf[67],lf[68],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 716  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 721  fd_test */
t4=t3;
f_1968(t4,f_1902(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2009,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2011,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t8=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_1968(t4,C_SCHEME_FALSE);}}}}

/* a2010 in k1927 in k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2011,3,t0,t1,t2);}
t3=f_1902(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2007 in k1927 in k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1968(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1966 in k1927 in k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_1968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1968,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1972,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 727  fd_test */
t3=t2;
f_1972(t3,f_1902(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_1972(t3,C_SCHEME_FALSE);}}

/* a1985 in k1966 in k1927 in k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1986,3,t0,t1,t2);}
t3=f_1902(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1982 in k1966 in k1927 in k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1972(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1970 in k1966 in k1927 in k1924 in k1918 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_1972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 718  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_1902(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub92(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_set in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_1900(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub86(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_zero in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_1898(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub81(C_SCHEME_UNDEFINED,t1));}

/* file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1866,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[64]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1873,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 667  ##sys#make-c-string */
t5=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1871 in file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1879,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 671  posix-error */
t6=lf[3];
f_1631(6,t6,t4,lf[48],lf[64],lf[66],((C_word*)t0)[2]);}
else{
t6=t4;
f_1879(2,t6,C_SCHEME_UNDEFINED);}}

/* k1877 in k1871 in file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 672  ##sys#substring */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1884 in k1877 in k1871 in file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 672  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1827r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1827r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1827r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[61]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1834,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1834(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 656  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[59],lf[61],lf[63],t3);}}

/* k1832 in file-write in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[61]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1843,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 661  posix-error */
t8=lf[3];
f_1631(7,t8,t6,lf[48],lf[61],lf[62],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_1843(2,t8,C_SCHEME_UNDEFINED);}}

/* k1841 in k1832 in file-write in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1785r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1785r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[57]);
t6=(C_word)C_i_check_exact_2(t3,lf[57]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1795,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1795(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixunix.scm: 644  make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k1793 in file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1798(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 646  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[59],lf[57],lf[60],t1);}}

/* k1796 in k1793 in file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1801,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 649  posix-error */
t5=lf[3];
f_1631(7,t5,t3,lf[48],lf[57],lf[58],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_1801(2,t5,C_SCHEME_UNDEFINED);}}

/* k1799 in k1796 in k1793 in file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1770,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[54]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 637  posix-error */
t4=lf[3];
f_1631(6,t4,t1,lf[48],lf[54],lf[55],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1732r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1732r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[50]);
t8=(C_word)C_i_check_exact_2(t3,lf[50]);
t9=(C_word)C_i_check_exact_2(t6,lf[50]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1749,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1762,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 628  ##sys#expand-home-path */
t12=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1760 in file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 628  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1747 in file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1752,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 630  posix-error */
t5=lf[3];
f_1631(8,t5,t3,lf[48],lf[50],lf[51],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_1752(2,t5,C_SCHEME_UNDEFINED);}}

/* k1750 in k1747 in file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1693r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1693r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1693r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_exact_2(t2,lf[47]);
t8=(C_word)C_i_check_exact_2(t3,lf[47]);
t9=t2;
t10=t3;
t11=(C_word)stub24(C_SCHEME_UNDEFINED,t9,t10,t6);
t12=(C_word)C_eqp(t11,C_fix(-1));
if(C_truep(t12)){
/* posixunix.scm: 618  posix-error */
t13=lf[3];
f_1631(7,t13,t1,lf[48],lf[47],lf[49],t2,t3);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t11);}}

/* ##sys#file-select-one in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1652,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub17(C_SCHEME_UNDEFINED,t2));}

/* ##sys#file-nonblocking! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1649,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub13(C_SCHEME_UNDEFINED,t2));}

/* posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1631r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1631r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1631r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1635,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 508  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1633 in posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub3(t4,t1),C_fix(0));}

/* k1644 in k1633 in posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 509  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1640 in k1633 in posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[600] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_1612posixunix.scm",(void*)f_1612},
{"f_1615posixunix.scm",(void*)f_1615},
{"f_1618posixunix.scm",(void*)f_1618},
{"f_1621posixunix.scm",(void*)f_1621},
{"f_1624posixunix.scm",(void*)f_1624},
{"f_7204posixunix.scm",(void*)f_7204},
{"f_7220posixunix.scm",(void*)f_7220},
{"f_7208posixunix.scm",(void*)f_7208},
{"f_7211posixunix.scm",(void*)f_7211},
{"f_2335posixunix.scm",(void*)f_2335},
{"f_3270posixunix.scm",(void*)f_3270},
{"f_7198posixunix.scm",(void*)f_7198},
{"f_3405posixunix.scm",(void*)f_3405},
{"f_7195posixunix.scm",(void*)f_7195},
{"f_3462posixunix.scm",(void*)f_3462},
{"f_7180posixunix.scm",(void*)f_7180},
{"f_7190posixunix.scm",(void*)f_7190},
{"f_7177posixunix.scm",(void*)f_7177},
{"f_3466posixunix.scm",(void*)f_3466},
{"f_7174posixunix.scm",(void*)f_7174},
{"f_3485posixunix.scm",(void*)f_3485},
{"f_7159posixunix.scm",(void*)f_7159},
{"f_7169posixunix.scm",(void*)f_7169},
{"f_7156posixunix.scm",(void*)f_7156},
{"f_3489posixunix.scm",(void*)f_3489},
{"f_7138posixunix.scm",(void*)f_7138},
{"f_7151posixunix.scm",(void*)f_7151},
{"f_7145posixunix.scm",(void*)f_7145},
{"f_3993posixunix.scm",(void*)f_3993},
{"f_4032posixunix.scm",(void*)f_4032},
{"f_7115posixunix.scm",(void*)f_7115},
{"f_7111posixunix.scm",(void*)f_7111},
{"f_6857posixunix.scm",(void*)f_6857},
{"f_7040posixunix.scm",(void*)f_7040},
{"f_7046posixunix.scm",(void*)f_7046},
{"f_7035posixunix.scm",(void*)f_7035},
{"f_7030posixunix.scm",(void*)f_7030},
{"f_6859posixunix.scm",(void*)f_6859},
{"f_7017posixunix.scm",(void*)f_7017},
{"f_7025posixunix.scm",(void*)f_7025},
{"f_6866posixunix.scm",(void*)f_6866},
{"f_7005posixunix.scm",(void*)f_7005},
{"f_6999posixunix.scm",(void*)f_6999},
{"f_6876posixunix.scm",(void*)f_6876},
{"f_6878posixunix.scm",(void*)f_6878},
{"f_6897posixunix.scm",(void*)f_6897},
{"f_6985posixunix.scm",(void*)f_6985},
{"f_6992posixunix.scm",(void*)f_6992},
{"f_6979posixunix.scm",(void*)f_6979},
{"f_6912posixunix.scm",(void*)f_6912},
{"f_6972posixunix.scm",(void*)f_6972},
{"f_6969posixunix.scm",(void*)f_6969},
{"f_6956posixunix.scm",(void*)f_6956},
{"f_6932posixunix.scm",(void*)f_6932},
{"f_6954posixunix.scm",(void*)f_6954},
{"f_6940posixunix.scm",(void*)f_6940},
{"f_6947posixunix.scm",(void*)f_6947},
{"f_6944posixunix.scm",(void*)f_6944},
{"f_6924posixunix.scm",(void*)f_6924},
{"f_6922posixunix.scm",(void*)f_6922},
{"f_7006posixunix.scm",(void*)f_7006},
{"f_6800posixunix.scm",(void*)f_6800},
{"f_6812posixunix.scm",(void*)f_6812},
{"f_6807posixunix.scm",(void*)f_6807},
{"f_6802posixunix.scm",(void*)f_6802},
{"f_6743posixunix.scm",(void*)f_6743},
{"f_6755posixunix.scm",(void*)f_6755},
{"f_6750posixunix.scm",(void*)f_6750},
{"f_6745posixunix.scm",(void*)f_6745},
{"f_6682posixunix.scm",(void*)f_6682},
{"f_6737posixunix.scm",(void*)f_6737},
{"f_6741posixunix.scm",(void*)f_6741},
{"f_6703posixunix.scm",(void*)f_6703},
{"f_6706posixunix.scm",(void*)f_6706},
{"f_6717posixunix.scm",(void*)f_6717},
{"f_6711posixunix.scm",(void*)f_6711},
{"f_6684posixunix.scm",(void*)f_6684},
{"f_6693posixunix.scm",(void*)f_6693},
{"f_6618posixunix.scm",(void*)f_6618},
{"f_6630posixunix.scm",(void*)f_6630},
{"f_6661posixunix.scm",(void*)f_6661},
{"f_6641posixunix.scm",(void*)f_6641},
{"f_6657posixunix.scm",(void*)f_6657},
{"f_6645posixunix.scm",(void*)f_6645},
{"f_6653posixunix.scm",(void*)f_6653},
{"f_6649posixunix.scm",(void*)f_6649},
{"f_6624posixunix.scm",(void*)f_6624},
{"f_6607posixunix.scm",(void*)f_6607},
{"f_6611posixunix.scm",(void*)f_6611},
{"f_6596posixunix.scm",(void*)f_6596},
{"f_6600posixunix.scm",(void*)f_6600},
{"f_6551posixunix.scm",(void*)f_6551},
{"f_6555posixunix.scm",(void*)f_6555},
{"f_6558posixunix.scm",(void*)f_6558},
{"f_6561posixunix.scm",(void*)f_6561},
{"f_6574posixunix.scm",(void*)f_6574},
{"f_6578posixunix.scm",(void*)f_6578},
{"f_6581posixunix.scm",(void*)f_6581},
{"f_6584posixunix.scm",(void*)f_6584},
{"f_6572posixunix.scm",(void*)f_6572},
{"f_6535posixunix.scm",(void*)f_6535},
{"f_6518posixunix.scm",(void*)f_6518},
{"f_6531posixunix.scm",(void*)f_6531},
{"f_6443posixunix.scm",(void*)f_6443},
{"f_6504posixunix.scm",(void*)f_6504},
{"f_6517posixunix.scm",(void*)f_6517},
{"f_6484posixunix.scm",(void*)f_6484},
{"f_6499posixunix.scm",(void*)f_6499},
{"f_6493posixunix.scm",(void*)f_6493},
{"f_6447posixunix.scm",(void*)f_6447},
{"f_6449posixunix.scm",(void*)f_6449},
{"f_6470posixunix.scm",(void*)f_6470},
{"f_6464posixunix.scm",(void*)f_6464},
{"f_6391posixunix.scm",(void*)f_6391},
{"f_6398posixunix.scm",(void*)f_6398},
{"f_6417posixunix.scm",(void*)f_6417},
{"f_6421posixunix.scm",(void*)f_6421},
{"f_6385posixunix.scm",(void*)f_6385},
{"f_6376posixunix.scm",(void*)f_6376},
{"f_6380posixunix.scm",(void*)f_6380},
{"f_6349posixunix.scm",(void*)f_6349},
{"f_6346posixunix.scm",(void*)f_6346},
{"f_6343posixunix.scm",(void*)f_6343},
{"f_6340posixunix.scm",(void*)f_6340},
{"f_6265posixunix.scm",(void*)f_6265},
{"f_6298posixunix.scm",(void*)f_6298},
{"f_6292posixunix.scm",(void*)f_6292},
{"f_6248posixunix.scm",(void*)f_6248},
{"f_6069posixunix.scm",(void*)f_6069},
{"f_6203posixunix.scm",(void*)f_6203},
{"f_6198posixunix.scm",(void*)f_6198},
{"f_6071posixunix.scm",(void*)f_6071},
{"f_6081posixunix.scm",(void*)f_6081},
{"f_6089posixunix.scm",(void*)f_6089},
{"f_6135posixunix.scm",(void*)f_6135},
{"f_6102posixunix.scm",(void*)f_6102},
{"f_6127posixunix.scm",(void*)f_6127},
{"f_6105posixunix.scm",(void*)f_6105},
{"f_6061posixunix.scm",(void*)f_6061},
{"f_6053posixunix.scm",(void*)f_6053},
{"f_6015posixunix.scm",(void*)f_6015},
{"f_6037posixunix.scm",(void*)f_6037},
{"f_6041posixunix.scm",(void*)f_6041},
{"f_5903posixunix.scm",(void*)f_5903},
{"f_5909posixunix.scm",(void*)f_5909},
{"f_5930posixunix.scm",(void*)f_5930},
{"f_6007posixunix.scm",(void*)f_6007},
{"f_5934posixunix.scm",(void*)f_5934},
{"f_5937posixunix.scm",(void*)f_5937},
{"f_5940posixunix.scm",(void*)f_5940},
{"f_5947posixunix.scm",(void*)f_5947},
{"f_5949posixunix.scm",(void*)f_5949},
{"f_5966posixunix.scm",(void*)f_5966},
{"f_5976posixunix.scm",(void*)f_5976},
{"f_5980posixunix.scm",(void*)f_5980},
{"f_5924posixunix.scm",(void*)f_5924},
{"f_5891posixunix.scm",(void*)f_5891},
{"f_5895posixunix.scm",(void*)f_5895},
{"f_5898posixunix.scm",(void*)f_5898},
{"f_5856posixunix.scm",(void*)f_5856},
{"f_5860posixunix.scm",(void*)f_5860},
{"f_5880posixunix.scm",(void*)f_5880},
{"f_5884posixunix.scm",(void*)f_5884},
{"f_5837posixunix.scm",(void*)f_5837},
{"f_5841posixunix.scm",(void*)f_5841},
{"f_5810posixunix.scm",(void*)f_5810},
{"f_5814posixunix.scm",(void*)f_5814},
{"f_5791posixunix.scm",(void*)f_5791},
{"f_5795posixunix.scm",(void*)f_5795},
{"f_5798posixunix.scm",(void*)f_5798},
{"f_5732posixunix.scm",(void*)f_5732},
{"f_5736posixunix.scm",(void*)f_5736},
{"f_5742posixunix.scm",(void*)f_5742},
{"f_5729posixunix.scm",(void*)f_5729},
{"f_5713posixunix.scm",(void*)f_5713},
{"f_5705posixunix.scm",(void*)f_5705},
{"f_5677posixunix.scm",(void*)f_5677},
{"f_5684posixunix.scm",(void*)f_5684},
{"f_5649posixunix.scm",(void*)f_5649},
{"f_5656posixunix.scm",(void*)f_5656},
{"f_5610posixunix.scm",(void*)f_5610},
{"f_5627posixunix.scm",(void*)f_5627},
{"f_5631posixunix.scm",(void*)f_5631},
{"f_5535posixunix.scm",(void*)f_5535},
{"f_5545posixunix.scm",(void*)f_5545},
{"f_5567posixunix.scm",(void*)f_5567},
{"f_5564posixunix.scm",(void*)f_5564},
{"f_5554posixunix.scm",(void*)f_5554},
{"f_5502posixunix.scm",(void*)f_5502},
{"f_5506posixunix.scm",(void*)f_5506},
{"f_5488posixunix.scm",(void*)f_5488},
{"f_5479posixunix.scm",(void*)f_5479},
{"f_5473posixunix.scm",(void*)f_5473},
{"f_5464posixunix.scm",(void*)f_5464},
{"f_5429posixunix.scm",(void*)f_5429},
{"f_5371posixunix.scm",(void*)f_5371},
{"f_5375posixunix.scm",(void*)f_5375},
{"f_5381posixunix.scm",(void*)f_5381},
{"f_5400posixunix.scm",(void*)f_5400},
{"f_5387posixunix.scm",(void*)f_5387},
{"f_5288posixunix.scm",(void*)f_5288},
{"f_5294posixunix.scm",(void*)f_5294},
{"f_5298posixunix.scm",(void*)f_5298},
{"f_5306posixunix.scm",(void*)f_5306},
{"f_5332posixunix.scm",(void*)f_5332},
{"f_5336posixunix.scm",(void*)f_5336},
{"f_5324posixunix.scm",(void*)f_5324},
{"f_5273posixunix.scm",(void*)f_5273},
{"f_5281posixunix.scm",(void*)f_5281},
{"f_5256posixunix.scm",(void*)f_5256},
{"f_5267posixunix.scm",(void*)f_5267},
{"f_5271posixunix.scm",(void*)f_5271},
{"f_5230posixunix.scm",(void*)f_5230},
{"f_5254posixunix.scm",(void*)f_5254},
{"f_5237posixunix.scm",(void*)f_5237},
{"f_5187posixunix.scm",(void*)f_5187},
{"f_5194posixunix.scm",(void*)f_5194},
{"f_5215posixunix.scm",(void*)f_5215},
{"f_5211posixunix.scm",(void*)f_5211},
{"f_5159posixunix.scm",(void*)f_5159},
{"f_5137posixunix.scm",(void*)f_5137},
{"f_5141posixunix.scm",(void*)f_5141},
{"f_5122posixunix.scm",(void*)f_5122},
{"f_5126posixunix.scm",(void*)f_5126},
{"f_5107posixunix.scm",(void*)f_5107},
{"f_5111posixunix.scm",(void*)f_5111},
{"f_5089posixunix.scm",(void*)f_5089},
{"f_5018posixunix.scm",(void*)f_5018},
{"f_5037posixunix.scm",(void*)f_5037},
{"f_5043posixunix.scm",(void*)f_5043},
{"f_4979posixunix.scm",(void*)f_4979},
{"f_5007posixunix.scm",(void*)f_5007},
{"f_5003posixunix.scm",(void*)f_5003},
{"f_4996posixunix.scm",(void*)f_4996},
{"f_4723posixunix.scm",(void*)f_4723},
{"f_4919posixunix.scm",(void*)f_4919},
{"f_4914posixunix.scm",(void*)f_4914},
{"f_4909posixunix.scm",(void*)f_4909},
{"f_4725posixunix.scm",(void*)f_4725},
{"f_4729posixunix.scm",(void*)f_4729},
{"f_4835posixunix.scm",(void*)f_4835},
{"f_4836posixunix.scm",(void*)f_4836},
{"f_4853posixunix.scm",(void*)f_4853},
{"f_4863posixunix.scm",(void*)f_4863},
{"f_4821posixunix.scm",(void*)f_4821},
{"f_4777posixunix.scm",(void*)f_4777},
{"f_4813posixunix.scm",(void*)f_4813},
{"f_4792posixunix.scm",(void*)f_4792},
{"f_4802posixunix.scm",(void*)f_4802},
{"f_4786posixunix.scm",(void*)f_4786},
{"f_4781posixunix.scm",(void*)f_4781},
{"f_4784posixunix.scm",(void*)f_4784},
{"f_4731posixunix.scm",(void*)f_4731},
{"f_4766posixunix.scm",(void*)f_4766},
{"f_4747posixunix.scm",(void*)f_4747},
{"f_4252posixunix.scm",(void*)f_4252},
{"f_4648posixunix.scm",(void*)f_4648},
{"f_4643posixunix.scm",(void*)f_4643},
{"f_4638posixunix.scm",(void*)f_4638},
{"f_4633posixunix.scm",(void*)f_4633},
{"f_4254posixunix.scm",(void*)f_4254},
{"f_4258posixunix.scm",(void*)f_4258},
{"f_4264posixunix.scm",(void*)f_4264},
{"f_4506posixunix.scm",(void*)f_4506},
{"f_4512posixunix.scm",(void*)f_4512},
{"f_4608posixunix.scm",(void*)f_4608},
{"f_4598posixunix.scm",(void*)f_4598},
{"f_4592posixunix.scm",(void*)f_4592},
{"f_4514posixunix.scm",(void*)f_4514},
{"f_4564posixunix.scm",(void*)f_4564},
{"f_4521posixunix.scm",(void*)f_4521},
{"f_4531posixunix.scm",(void*)f_4531},
{"f_4430posixunix.scm",(void*)f_4430},
{"f_4438posixunix.scm",(void*)f_4438},
{"f_4440posixunix.scm",(void*)f_4440},
{"f_4488posixunix.scm",(void*)f_4488},
{"f_4421posixunix.scm",(void*)f_4421},
{"f_4425posixunix.scm",(void*)f_4425},
{"f_4400posixunix.scm",(void*)f_4400},
{"f_4410posixunix.scm",(void*)f_4410},
{"f_4388posixunix.scm",(void*)f_4388},
{"f_4375posixunix.scm",(void*)f_4375},
{"f_4379posixunix.scm",(void*)f_4379},
{"f_4370posixunix.scm",(void*)f_4370},
{"f_4373posixunix.scm",(void*)f_4373},
{"f_4288posixunix.scm",(void*)f_4288},
{"f_4300posixunix.scm",(void*)f_4300},
{"f_4337posixunix.scm",(void*)f_4337},
{"f_4346posixunix.scm",(void*)f_4346},
{"f_4340posixunix.scm",(void*)f_4340},
{"f_4316posixunix.scm",(void*)f_4316},
{"f_4319posixunix.scm",(void*)f_4319},
{"f_4280posixunix.scm",(void*)f_4280},
{"f_4265posixunix.scm",(void*)f_4265},
{"f_4279posixunix.scm",(void*)f_4279},
{"f_4225posixunix.scm",(void*)f_4225},
{"f_4232posixunix.scm",(void*)f_4232},
{"f_4235posixunix.scm",(void*)f_4235},
{"f_4180posixunix.scm",(void*)f_4180},
{"f_4184posixunix.scm",(void*)f_4184},
{"f_4219posixunix.scm",(void*)f_4219},
{"f_4202posixunix.scm",(void*)f_4202},
{"f_4166posixunix.scm",(void*)f_4166},
{"f_4178posixunix.scm",(void*)f_4178},
{"f_4152posixunix.scm",(void*)f_4152},
{"f_4164posixunix.scm",(void*)f_4164},
{"f_4137posixunix.scm",(void*)f_4137},
{"f_4150posixunix.scm",(void*)f_4150},
{"f_4100posixunix.scm",(void*)f_4100},
{"f_4108posixunix.scm",(void*)f_4108},
{"f_4075posixunix.scm",(void*)f_4075},
{"f_4064posixunix.scm",(void*)f_4064},
{"f_4068posixunix.scm",(void*)f_4068},
{"f_4033posixunix.scm",(void*)f_4033},
{"f_4057posixunix.scm",(void*)f_4057},
{"f_4041posixunix.scm",(void*)f_4041},
{"f_4044posixunix.scm",(void*)f_4044},
{"f_3995posixunix.scm",(void*)f_3995},
{"f_4028posixunix.scm",(void*)f_4028},
{"f_4016posixunix.scm",(void*)f_4016},
{"f_4024posixunix.scm",(void*)f_4024},
{"f_4020posixunix.scm",(void*)f_4020},
{"f_3970posixunix.scm",(void*)f_3970},
{"f_3986posixunix.scm",(void*)f_3986},
{"f_3955posixunix.scm",(void*)f_3955},
{"f_3965posixunix.scm",(void*)f_3965},
{"f_3959posixunix.scm",(void*)f_3959},
{"f_3949posixunix.scm",(void*)f_3949},
{"f_3943posixunix.scm",(void*)f_3943},
{"f_3937posixunix.scm",(void*)f_3937},
{"f_3913posixunix.scm",(void*)f_3913},
{"f_3935posixunix.scm",(void*)f_3935},
{"f_3931posixunix.scm",(void*)f_3931},
{"f_3923posixunix.scm",(void*)f_3923},
{"f_3883posixunix.scm",(void*)f_3883},
{"f_3911posixunix.scm",(void*)f_3911},
{"f_3907posixunix.scm",(void*)f_3907},
{"f_3856posixunix.scm",(void*)f_3856},
{"f_3881posixunix.scm",(void*)f_3881},
{"f_3877posixunix.scm",(void*)f_3877},
{"f_3792posixunix.scm",(void*)f_3792},
{"f_3788posixunix.scm",(void*)f_3788},
{"f_3808posixunix.scm",(void*)f_3808},
{"f_3726posixunix.scm",(void*)f_3726},
{"f_3730posixunix.scm",(void*)f_3730},
{"f_3735posixunix.scm",(void*)f_3735},
{"f_3751posixunix.scm",(void*)f_3751},
{"f_3663posixunix.scm",(void*)f_3663},
{"f_3721posixunix.scm",(void*)f_3721},
{"f_3667posixunix.scm",(void*)f_3667},
{"f_3670posixunix.scm",(void*)f_3670},
{"f_3702posixunix.scm",(void*)f_3702},
{"f_3673posixunix.scm",(void*)f_3673},
{"f_3678posixunix.scm",(void*)f_3678},
{"f_3692posixunix.scm",(void*)f_3692},
{"f_3660posixunix.scm",(void*)f_3660},
{"f_3585posixunix.scm",(void*)f_3585},
{"f_3643posixunix.scm",(void*)f_3643},
{"f_3592posixunix.scm",(void*)f_3592},
{"f_3602posixunix.scm",(void*)f_3602},
{"f_3606posixunix.scm",(void*)f_3606},
{"f_3615posixunix.scm",(void*)f_3615},
{"f_3619posixunix.scm",(void*)f_3619},
{"f_3629posixunix.scm",(void*)f_3629},
{"f_3610posixunix.scm",(void*)f_3610},
{"f_3565posixunix.scm",(void*)f_3565},
{"f_3577posixunix.scm",(void*)f_3577},
{"f_3573posixunix.scm",(void*)f_3573},
{"f_3551posixunix.scm",(void*)f_3551},
{"f_3563posixunix.scm",(void*)f_3563},
{"f_3559posixunix.scm",(void*)f_3559},
{"f_3491posixunix.scm",(void*)f_3491},
{"f_3537posixunix.scm",(void*)f_3537},
{"f_3498posixunix.scm",(void*)f_3498},
{"f_3508posixunix.scm",(void*)f_3508},
{"f_3512posixunix.scm",(void*)f_3512},
{"f_3516posixunix.scm",(void*)f_3516},
{"f_3520posixunix.scm",(void*)f_3520},
{"f_3524posixunix.scm",(void*)f_3524},
{"f_3468posixunix.scm",(void*)f_3468},
{"f_3478posixunix.scm",(void*)f_3478},
{"f_3445posixunix.scm",(void*)f_3445},
{"f_3455posixunix.scm",(void*)f_3455},
{"f_3407posixunix.scm",(void*)f_3407},
{"f_3440posixunix.scm",(void*)f_3440},
{"f_3411posixunix.scm",(void*)f_3411},
{"f_3418posixunix.scm",(void*)f_3418},
{"f_3422posixunix.scm",(void*)f_3422},
{"f_3426posixunix.scm",(void*)f_3426},
{"f_3430posixunix.scm",(void*)f_3430},
{"f_3434posixunix.scm",(void*)f_3434},
{"f_3389posixunix.scm",(void*)f_3389},
{"f_3374posixunix.scm",(void*)f_3374},
{"f_3368posixunix.scm",(void*)f_3368},
{"f_3336posixunix.scm",(void*)f_3336},
{"f_3342posixunix.scm",(void*)f_3342},
{"f_3312posixunix.scm",(void*)f_3312},
{"f_3330posixunix.scm",(void*)f_3330},
{"f_3319posixunix.scm",(void*)f_3319},
{"f_3294posixunix.scm",(void*)f_3294},
{"f_3304posixunix.scm",(void*)f_3304},
{"f_3281posixunix.scm",(void*)f_3281},
{"f_3272posixunix.scm",(void*)f_3272},
{"f_3225posixunix.scm",(void*)f_3225},
{"f_3229posixunix.scm",(void*)f_3229},
{"f_3205posixunix.scm",(void*)f_3205},
{"f_3209posixunix.scm",(void*)f_3209},
{"f_3215posixunix.scm",(void*)f_3215},
{"f_3219posixunix.scm",(void*)f_3219},
{"f_3185posixunix.scm",(void*)f_3185},
{"f_3189posixunix.scm",(void*)f_3189},
{"f_3195posixunix.scm",(void*)f_3195},
{"f_3199posixunix.scm",(void*)f_3199},
{"f_3161posixunix.scm",(void*)f_3161},
{"f_3165posixunix.scm",(void*)f_3165},
{"f_3176posixunix.scm",(void*)f_3176},
{"f_3180posixunix.scm",(void*)f_3180},
{"f_3170posixunix.scm",(void*)f_3170},
{"f_3137posixunix.scm",(void*)f_3137},
{"f_3141posixunix.scm",(void*)f_3141},
{"f_3152posixunix.scm",(void*)f_3152},
{"f_3156posixunix.scm",(void*)f_3156},
{"f_3146posixunix.scm",(void*)f_3146},
{"f_3121posixunix.scm",(void*)f_3121},
{"f_3125posixunix.scm",(void*)f_3125},
{"f_3128posixunix.scm",(void*)f_3128},
{"f_3085posixunix.scm",(void*)f_3085},
{"f_3116posixunix.scm",(void*)f_3116},
{"f_3106posixunix.scm",(void*)f_3106},
{"f_3099posixunix.scm",(void*)f_3099},
{"f_3049posixunix.scm",(void*)f_3049},
{"f_3080posixunix.scm",(void*)f_3080},
{"f_3070posixunix.scm",(void*)f_3070},
{"f_3063posixunix.scm",(void*)f_3063},
{"f_3034posixunix.scm",(void*)f_3034},
{"f_3047posixunix.scm",(void*)f_3047},
{"f_3028posixunix.scm",(void*)f_3028},
{"f_3016posixunix.scm",(void*)f_3016},
{"f_2699posixunix.scm",(void*)f_2699},
{"f_3006posixunix.scm",(void*)f_3006},
{"f_2826posixunix.scm",(void*)f_2826},
{"f_2992posixunix.scm",(void*)f_2992},
{"f_2981posixunix.scm",(void*)f_2981},
{"f_2988posixunix.scm",(void*)f_2988},
{"f_2845posixunix.scm",(void*)f_2845},
{"f_2974posixunix.scm",(void*)f_2974},
{"f_2953posixunix.scm",(void*)f_2953},
{"f_2970posixunix.scm",(void*)f_2970},
{"f_2959posixunix.scm",(void*)f_2959},
{"f_2966posixunix.scm",(void*)f_2966},
{"f_2889posixunix.scm",(void*)f_2889},
{"f_2950posixunix.scm",(void*)f_2950},
{"f_2929posixunix.scm",(void*)f_2929},
{"f_2946posixunix.scm",(void*)f_2946},
{"f_2935posixunix.scm",(void*)f_2935},
{"f_2942posixunix.scm",(void*)f_2942},
{"f_2902posixunix.scm",(void*)f_2902},
{"f_2926posixunix.scm",(void*)f_2926},
{"f_2922posixunix.scm",(void*)f_2922},
{"f_2883posixunix.scm",(void*)f_2883},
{"f_2852posixunix.scm",(void*)f_2852},
{"f_2870posixunix.scm",(void*)f_2870},
{"f_2855posixunix.scm",(void*)f_2855},
{"f_2859posixunix.scm",(void*)f_2859},
{"f_2839posixunix.scm",(void*)f_2839},
{"f_2820posixunix.scm",(void*)f_2820},
{"f_2706posixunix.scm",(void*)f_2706},
{"f_2713posixunix.scm",(void*)f_2713},
{"f_2715posixunix.scm",(void*)f_2715},
{"f_2722posixunix.scm",(void*)f_2722},
{"f_2786posixunix.scm",(void*)f_2786},
{"f_2795posixunix.scm",(void*)f_2795},
{"f_2783posixunix.scm",(void*)f_2783},
{"f_2728posixunix.scm",(void*)f_2728},
{"f_2764posixunix.scm",(void*)f_2764},
{"f_2760posixunix.scm",(void*)f_2760},
{"f_2756posixunix.scm",(void*)f_2756},
{"f_2745posixunix.scm",(void*)f_2745},
{"f_2741posixunix.scm",(void*)f_2741},
{"f_2643posixunix.scm",(void*)f_2643},
{"f_2652posixunix.scm",(void*)f_2652},
{"f_2676posixunix.scm",(void*)f_2676},
{"f_2688posixunix.scm",(void*)f_2688},
{"f_2694posixunix.scm",(void*)f_2694},
{"f_2682posixunix.scm",(void*)f_2682},
{"f_2658posixunix.scm",(void*)f_2658},
{"f_2664posixunix.scm",(void*)f_2664},
{"f_2650posixunix.scm",(void*)f_2650},
{"f_2632posixunix.scm",(void*)f_2632},
{"f_2627posixunix.scm",(void*)f_2627},
{"f_2586posixunix.scm",(void*)f_2586},
{"f_2599posixunix.scm",(void*)f_2599},
{"f_2563posixunix.scm",(void*)f_2563},
{"f_2584posixunix.scm",(void*)f_2584},
{"f_2570posixunix.scm",(void*)f_2570},
{"f_2409posixunix.scm",(void*)f_2409},
{"f_2514posixunix.scm",(void*)f_2514},
{"f_2522posixunix.scm",(void*)f_2522},
{"f_2509posixunix.scm",(void*)f_2509},
{"f_2411posixunix.scm",(void*)f_2411},
{"f_2418posixunix.scm",(void*)f_2418},
{"f_2421posixunix.scm",(void*)f_2421},
{"f_2424posixunix.scm",(void*)f_2424},
{"f_2508posixunix.scm",(void*)f_2508},
{"f_2428posixunix.scm",(void*)f_2428},
{"f_2442posixunix.scm",(void*)f_2442},
{"f_2452posixunix.scm",(void*)f_2452},
{"f_2455posixunix.scm",(void*)f_2455},
{"f_2458posixunix.scm",(void*)f_2458},
{"f_2464posixunix.scm",(void*)f_2464},
{"f_2474posixunix.scm",(void*)f_2474},
{"f_2385posixunix.scm",(void*)f_2385},
{"f_2407posixunix.scm",(void*)f_2407},
{"f_2403posixunix.scm",(void*)f_2403},
{"f_2361posixunix.scm",(void*)f_2361},
{"f_2383posixunix.scm",(void*)f_2383},
{"f_2379posixunix.scm",(void*)f_2379},
{"f_2337posixunix.scm",(void*)f_2337},
{"f_2359posixunix.scm",(void*)f_2359},
{"f_2355posixunix.scm",(void*)f_2355},
{"f_2275posixunix.scm",(void*)f_2275},
{"f_2288posixunix.scm",(void*)f_2288},
{"f_2300posixunix.scm",(void*)f_2300},
{"f_2294posixunix.scm",(void*)f_2294},
{"f_2266posixunix.scm",(void*)f_2266},
{"f_2273posixunix.scm",(void*)f_2273},
{"f_2257posixunix.scm",(void*)f_2257},
{"f_2264posixunix.scm",(void*)f_2264},
{"f_2248posixunix.scm",(void*)f_2248},
{"f_2255posixunix.scm",(void*)f_2255},
{"f_2239posixunix.scm",(void*)f_2239},
{"f_2246posixunix.scm",(void*)f_2246},
{"f_2230posixunix.scm",(void*)f_2230},
{"f_2237posixunix.scm",(void*)f_2237},
{"f_2221posixunix.scm",(void*)f_2221},
{"f_2228posixunix.scm",(void*)f_2228},
{"f_2212posixunix.scm",(void*)f_2212},
{"f_2219posixunix.scm",(void*)f_2219},
{"f_2203posixunix.scm",(void*)f_2203},
{"f_2210posixunix.scm",(void*)f_2210},
{"f_2194posixunix.scm",(void*)f_2194},
{"f_2201posixunix.scm",(void*)f_2201},
{"f_2188posixunix.scm",(void*)f_2188},
{"f_2192posixunix.scm",(void*)f_2192},
{"f_2182posixunix.scm",(void*)f_2182},
{"f_2186posixunix.scm",(void*)f_2186},
{"f_2176posixunix.scm",(void*)f_2176},
{"f_2180posixunix.scm",(void*)f_2180},
{"f_2170posixunix.scm",(void*)f_2170},
{"f_2174posixunix.scm",(void*)f_2174},
{"f_2164posixunix.scm",(void*)f_2164},
{"f_2168posixunix.scm",(void*)f_2168},
{"f_2158posixunix.scm",(void*)f_2158},
{"f_2162posixunix.scm",(void*)f_2162},
{"f_2133posixunix.scm",(void*)f_2133},
{"f_2137posixunix.scm",(void*)f_2137},
{"f_2096posixunix.scm",(void*)f_2096},
{"f_2128posixunix.scm",(void*)f_2128},
{"f_2121posixunix.scm",(void*)f_2121},
{"f_2100posixunix.scm",(void*)f_2100},
{"f_1904posixunix.scm",(void*)f_1904},
{"f_2077posixunix.scm",(void*)f_2077},
{"f_1920posixunix.scm",(void*)f_1920},
{"f_2051posixunix.scm",(void*)f_2051},
{"f_1926posixunix.scm",(void*)f_1926},
{"f_1929posixunix.scm",(void*)f_1929},
{"f_2011posixunix.scm",(void*)f_2011},
{"f_2009posixunix.scm",(void*)f_2009},
{"f_1968posixunix.scm",(void*)f_1968},
{"f_1986posixunix.scm",(void*)f_1986},
{"f_1984posixunix.scm",(void*)f_1984},
{"f_1972posixunix.scm",(void*)f_1972},
{"f_1902posixunix.scm",(void*)f_1902},
{"f_1900posixunix.scm",(void*)f_1900},
{"f_1898posixunix.scm",(void*)f_1898},
{"f_1866posixunix.scm",(void*)f_1866},
{"f_1873posixunix.scm",(void*)f_1873},
{"f_1879posixunix.scm",(void*)f_1879},
{"f_1886posixunix.scm",(void*)f_1886},
{"f_1827posixunix.scm",(void*)f_1827},
{"f_1834posixunix.scm",(void*)f_1834},
{"f_1843posixunix.scm",(void*)f_1843},
{"f_1785posixunix.scm",(void*)f_1785},
{"f_1795posixunix.scm",(void*)f_1795},
{"f_1798posixunix.scm",(void*)f_1798},
{"f_1801posixunix.scm",(void*)f_1801},
{"f_1770posixunix.scm",(void*)f_1770},
{"f_1732posixunix.scm",(void*)f_1732},
{"f_1762posixunix.scm",(void*)f_1762},
{"f_1749posixunix.scm",(void*)f_1749},
{"f_1752posixunix.scm",(void*)f_1752},
{"f_1693posixunix.scm",(void*)f_1693},
{"f_1652posixunix.scm",(void*)f_1652},
{"f_1649posixunix.scm",(void*)f_1649},
{"f_1631posixunix.scm",(void*)f_1631},
{"f_1635posixunix.scm",(void*)f_1635},
{"f_1646posixunix.scm",(void*)f_1646},
{"f_1642posixunix.scm",(void*)f_1642},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
