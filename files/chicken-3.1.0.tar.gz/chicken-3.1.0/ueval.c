/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:48
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: eval.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[521];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static C_word C_fcall stub1347(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1347(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11348)
static void C_ccall f_11348(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11348)
static void C_ccall f_11348r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11352)
static void C_fcall f_11352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11376)
static void C_ccall f_11376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11370)
static void C_ccall f_11370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11360)
static void C_ccall f_11360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5962)
static void C_ccall f_5962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6061)
static void C_ccall f_6061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11342)
static void C_ccall f_11342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11338)
static void C_ccall f_11338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11334)
static void C_ccall f_11334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11330)
static void C_ccall f_11330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11320)
static void C_fcall f_11320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_fcall f_6660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11298)
static void C_ccall f_11298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11290)
static void C_ccall f_11290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11292)
static void C_ccall f_11292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6672)
static void C_ccall f_6672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11259)
static void C_ccall f_11259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11279)
static void C_ccall f_11279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11275)
static void C_ccall f_11275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11265)
static void C_ccall f_11265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11262)
static void C_ccall f_11262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11205)
static void C_ccall f_11205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11219)
static void C_fcall f_11219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11255)
static void C_ccall f_11255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11251)
static void C_ccall f_11251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11239)
static void C_ccall f_11239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11243)
static void C_ccall f_11243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11213)
static void C_ccall f_11213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7744)
static void C_ccall f_7744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11121)
static void C_fcall f_11121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11130)
static void C_ccall f_11130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11149)
static void C_ccall f_11149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11153)
static void C_ccall f_11153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11136)
static void C_ccall f_11136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11087)
static void C_fcall f_11087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7805)
static void C_ccall f_7805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8144)
static void C_ccall f_8144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11078)
static void C_ccall f_11078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10981)
static void C_ccall f_10981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10987)
static void C_fcall f_10987(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11041)
static void C_ccall f_11041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11044)
static void C_ccall f_11044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11031)
static void C_ccall f_11031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11038)
static void C_ccall f_11038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8834)
static void C_ccall f_8834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10953)
static void C_ccall f_10953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8837)
static void C_ccall f_8837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10932)
static void C_ccall f_10932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8840)
static void C_ccall f_8840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10719)
static void C_fcall f_10719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10735)
static void C_ccall f_10735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10811)
static void C_fcall f_10811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10868)
static void C_ccall f_10868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10814)
static void C_ccall f_10814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_ccall f_10841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10793)
static void C_ccall f_10793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8843)
static void C_ccall f_8843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10610)
static void C_ccall f_10610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10620)
static void C_ccall f_10620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10633)
static void C_fcall f_10633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10687)
static void C_ccall f_10687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10677)
static void C_ccall f_10677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10631)
static void C_ccall f_10631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10567)
static void C_ccall f_10567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10570)
static void C_ccall f_10570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10575)
static void C_fcall f_10575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10600)
static void C_ccall f_10600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10487)
static void C_ccall f_10487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10497)
static void C_ccall f_10497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10511)
static void C_ccall f_10511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10519)
static void C_ccall f_10519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10515)
static void C_ccall f_10515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8852)
static void C_ccall f_8852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10372)
static void C_ccall f_10372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10375)
static void C_ccall f_10375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10469)
static void C_ccall f_10469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10385)
static void C_ccall f_10385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10408)
static void C_fcall f_10408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10422)
static void C_ccall f_10422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10420)
static void C_ccall f_10420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10076)
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10286)
static void C_fcall f_10286(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10311)
static void C_ccall f_10311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10089)
static void C_fcall f_10089(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10277)
static void C_ccall f_10277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10281)
static void C_ccall f_10281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10260)
static void C_ccall f_10260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10264)
static void C_ccall f_10264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10241)
static void C_ccall f_10241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10230)
static void C_ccall f_10230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10196)
static void C_ccall f_10196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10150)
static void C_ccall f_10150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10107)
static void C_ccall f_10107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10079)
static void C_fcall f_10079(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10087)
static void C_ccall f_10087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8861)
static void C_ccall f_8861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9820)
static void C_ccall f_9820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9975)
static void C_fcall f_9975(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10046)
static void C_ccall f_10046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9991)
static void C_ccall f_9991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9989)
static void C_ccall f_9989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9833)
static void C_fcall f_9833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9959)
static void C_ccall f_9959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9921)
static void C_ccall f_9921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9882)
static void C_ccall f_9882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9823)
static void C_fcall f_9823(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8864)
static void C_ccall f_8864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8868)
static void C_ccall f_8868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9817)
static void C_ccall f_9817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9250)
static void C_ccall f_9250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9675)
static void C_ccall f_9675(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9675)
static void C_ccall f_9675r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9793)
static void C_ccall f_9793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9796)
static void C_ccall f_9796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9678)
static void C_fcall f_9678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9682)
static void C_fcall f_9682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9693)
static void C_fcall f_9693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9336)
static void C_ccall f_9336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9660)
static void C_ccall f_9660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9669)
static void C_ccall f_9669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9667)
static void C_ccall f_9667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9339)
static void C_ccall f_9339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9650)
static void C_ccall f_9650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9644)
static void C_ccall f_9644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9642)
static void C_ccall f_9642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9625)
static void C_ccall f_9625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9610)
static void C_ccall f_9610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9614)
static void C_ccall f_9614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9619)
static void C_ccall f_9619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9623)
static void C_ccall f_9623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9588)
static void C_ccall f_9588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9592)
static void C_ccall f_9592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9597)
static void C_ccall f_9597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9601)
static void C_ccall f_9601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9608)
static void C_ccall f_9608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9562)
static void C_ccall f_9562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9568)
static void C_ccall f_9568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9572)
static void C_ccall f_9572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9586)
static void C_ccall f_9586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9575)
static void C_ccall f_9575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9582)
static void C_ccall f_9582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9546)
static void C_ccall f_9546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9552)
static void C_ccall f_9552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9560)
static void C_ccall f_9560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9509)
static void C_ccall f_9509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9513)
static void C_ccall f_9513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9544)
static void C_ccall f_9544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9540)
static void C_ccall f_9540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9536)
static void C_ccall f_9536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9525)
static void C_ccall f_9525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9532)
static void C_ccall f_9532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9483)
static void C_ccall f_9483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9489)
static void C_ccall f_9489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9493)
static void C_ccall f_9493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9503)
static void C_ccall f_9503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9470)
static C_word C_fcall f_9470(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9444)
static void C_ccall f_9444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9448)
static void C_ccall f_9448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9453)
static void C_ccall f_9453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9464)
static void C_ccall f_9464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9428)
static void C_ccall f_9428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9434)
static void C_ccall f_9434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9442)
static void C_ccall f_9442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9416)
static void C_ccall f_9416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9422)
static void C_ccall f_9422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9426)
static void C_ccall f_9426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9407)
static void C_fcall f_9407(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9411)
static void C_ccall f_9411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9348)
static void C_fcall f_9348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9358)
static void C_ccall f_9358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9383)
static void C_ccall f_9383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9395)
static void C_ccall f_9395(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9395)
static void C_ccall f_9395r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9401)
static void C_ccall f_9401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9389)
static void C_ccall f_9389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9370)
static void C_ccall f_9370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9374)
static void C_ccall f_9374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9381)
static void C_ccall f_9381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9356)
static void C_ccall f_9356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9288)
static void C_fcall f_9288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9306)
static void C_ccall f_9306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9275)
static void C_fcall f_9275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8911)
static void C_ccall f_8911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8955)
static void C_ccall f_8955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_ccall f_8958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9239)
static void C_ccall f_9239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9243)
static void C_ccall f_9243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9040)
static void C_ccall f_9040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9046)
static void C_fcall f_9046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9224)
static void C_ccall f_9224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9053)
static void C_ccall f_9053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_ccall f_9068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9104)
static void C_fcall f_9104(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9167)
static void C_ccall f_9167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9120)
static void C_ccall f_9120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9129)
static void C_ccall f_9129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9144)
static void C_ccall f_9144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9147)
static void C_ccall f_9147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9135)
static void C_ccall f_9135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9108)
static void C_ccall f_9108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9090)
static void C_ccall f_9090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8936)
static void C_fcall f_8936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8941)
static void C_ccall f_8941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9093)
static void C_ccall f_9093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9077)
static void C_ccall f_9077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8975)
static void C_ccall f_8975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_fcall f_9010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9001)
static void C_ccall f_9001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static C_word C_fcall f_8966(C_word t0);
C_noret_decl(f_8960)
static C_word C_fcall f_8960(C_word t0);
C_noret_decl(f_8914)
static void C_fcall f_8914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8908)
static void C_ccall f_8908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8892)
static void C_ccall f_8892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8906)
static void C_ccall f_8906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8873)
static void C_ccall f_8873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8877)
static void C_ccall f_8877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8579)
static void C_fcall f_8579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8584)
static void C_fcall f_8584(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8802)
static void C_ccall f_8802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8729)
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8600)
static void C_fcall f_8600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8605)
static void C_fcall f_8605(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8624)
static void C_ccall f_8624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8550)
static void C_ccall f_8550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8556)
static C_word C_fcall f_8556(C_word t0);
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8500)
static void C_fcall f_8500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8523)
static void C_ccall f_8523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8445)
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8452)
static void C_ccall f_8452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8457)
static void C_fcall f_8457(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8461)
static void C_ccall f_8461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8486)
static void C_ccall f_8486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8468)
static void C_ccall f_8468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8344)
static void C_ccall f_8344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8348)
static void C_ccall f_8348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8354)
static void C_ccall f_8354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8357)
static void C_ccall f_8357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8366)
static void C_ccall f_8366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8323)
static void C_fcall f_8323(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8330)
static void C_ccall f_8330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8305)
static void C_fcall f_8305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8234)
static void C_ccall f_8234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8285)
static void C_ccall f_8285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8246)
static void C_fcall f_8246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8270)
static void C_ccall f_8270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8256)
static void C_ccall f_8256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_fcall f_8217(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8182)
static void C_fcall f_8182(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8157)
static void C_fcall f_8157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8161)
static void C_ccall f_8161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_fcall f_8124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8039)
static void C_ccall f_8039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7941)
static void C_fcall f_7941(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7965)
static void C_fcall f_7965(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7959)
static void C_ccall f_7959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7827)
static void C_fcall f_7827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7854)
static void C_fcall f_7854(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7749)
static void C_ccall f_7749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7753)
static void C_ccall f_7753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7761)
static void C_fcall f_7761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7781)
static void C_fcall f_7781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7306)
static void C_ccall f_7306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7581)
static void C_fcall f_7581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7590)
static void C_ccall f_7590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7618)
static void C_fcall f_7618(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7486)
static void C_ccall f_7486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7501)
static void C_fcall f_7501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_fcall f_7505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_fcall f_7434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7442)
static void C_fcall f_7442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_fcall f_7389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7352)
static void C_ccall f_7352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7372)
static void C_ccall f_7372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7355)
static void C_fcall f_7355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7309)
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7318)
static void C_ccall f_7318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7263)
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_fcall f_7280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7237)
static void C_ccall f_7237(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7173)
static void C_ccall f_7173(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7173)
static void C_ccall f_7173r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7186)
static void C_ccall f_7186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_fcall f_7109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7095)
static void C_ccall f_7095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7064)
static void C_fcall f_7064(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_fcall f_7031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6970)
static void C_fcall f_6970(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6987)
static void C_ccall f_6987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_fcall f_6892(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static C_word C_fcall f_6874(C_word t0);
C_noret_decl(f_6868)
static void C_fcall f_6868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6818)
static void C_fcall f_6818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6856)
static void C_ccall f_6856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6836)
static void C_ccall f_6836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6674)
static void C_ccall f_6674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6774)
static void C_ccall f_6774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_fcall f_6687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_fcall f_6698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_fcall f_6714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6531)
static void C_fcall f_6531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_fcall f_6526(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6191)
static void C_fcall f_6191(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_fcall f_6195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_fcall f_6477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6385)
static void C_ccall f_6385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6247)
static void C_ccall f_6247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_fcall f_6270(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6335)
static void C_ccall f_6335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_fcall f_6143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static C_word C_fcall f_6153(C_word t0,C_word t1);
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6080)
static void C_fcall f_6080(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6075)
static void C_ccall f_6075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5992)
static void C_fcall f_5992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_fcall f_5982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5710)
static void C_fcall f_5710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5844)
static void C_ccall f_5844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5684)
static C_word C_fcall f_5684(C_word t0,C_word t1);
C_noret_decl(f_3954)
static void C_fcall f_3954(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_fcall f_4113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_fcall f_5517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5364)
static void C_fcall f_5364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5316)
static void C_fcall f_5316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5651)
static void C_fcall f_5651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_fcall f_4830(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4181)
static void C_ccall f_4181(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_fcall f_4011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_fcall f_3948(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3942)
static C_word C_fcall f_3942(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3936)
static C_word C_fcall f_3936(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3883)
static void C_fcall f_3883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_fcall f_3902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_fcall f_3911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_fcall f_3771(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_fcall f_3729(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3735)
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3853)
static C_word C_fcall f_3853(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_fcall f_3631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3579)
static void C_fcall f_3579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_fcall f_3530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static C_word C_fcall f_3486(C_word t0,C_word t1);
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_fcall f_3401(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_fcall f_3310(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3262)
static void C_fcall f_3262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_fcall f_3257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_fcall f_2826(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3009)
static void C_fcall f_3009(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3015)
static void C_fcall f_3015(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_fcall f_3066(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_fcall f_2829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2860)
static void C_fcall f_2860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2327)
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2767)
static void C_fcall f_2767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_fcall f_2686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_fcall f_2640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_fcall f_2643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_fcall f_2603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_fcall f_2571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_fcall f_2513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_fcall f_2345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_fcall f_2357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_fcall f_2348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_fcall f_2308(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2268)
static void C_fcall f_2268(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2287)
static void C_fcall f_2287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2219)
static void C_fcall f_2219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2137)
static void C_fcall f_2137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_fcall f_1976(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_fcall f_2004(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_fcall f_1830(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_fcall f_1862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_fcall f_1879(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1898)
static void C_fcall f_1898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_fcall f_1859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715r(C_word t0,C_word t1,C_word t3) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9625,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9610,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9588,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9562,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9546,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9509,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9483,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9444,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9428,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9416,0));}

C_noret_decl(trf_11352)
static void C_fcall trf_11352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11352(t0,t1);}

C_noret_decl(trf_11320)
static void C_fcall trf_11320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11320(t0,t1);}

C_noret_decl(trf_6660)
static void C_fcall trf_6660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6660(t0,t1);}

C_noret_decl(trf_11219)
static void C_fcall trf_11219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11219(t0,t1,t2);}

C_noret_decl(trf_11121)
static void C_fcall trf_11121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11121(t0,t1);}

C_noret_decl(trf_11087)
static void C_fcall trf_11087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11087(t0,t1);}

C_noret_decl(trf_10987)
static void C_fcall trf_10987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10987(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10987(t0,t1,t2);}

C_noret_decl(trf_10719)
static void C_fcall trf_10719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10719(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10719(t0,t1,t2);}

C_noret_decl(trf_10811)
static void C_fcall trf_10811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10811(t0,t1);}

C_noret_decl(trf_10633)
static void C_fcall trf_10633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10633(t0,t1,t2);}

C_noret_decl(trf_10575)
static void C_fcall trf_10575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10575(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10575(t0,t1,t2);}

C_noret_decl(trf_10408)
static void C_fcall trf_10408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10408(t0,t1);}

C_noret_decl(trf_10286)
static void C_fcall trf_10286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10286(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10286(t0,t1,t2);}

C_noret_decl(trf_10089)
static void C_fcall trf_10089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10089(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10089(t0,t1,t2,t3);}

C_noret_decl(trf_10079)
static void C_fcall trf_10079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10079(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10079(t0,t1,t2,t3);}

C_noret_decl(trf_9975)
static void C_fcall trf_9975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9975(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9975(t0,t1,t2);}

C_noret_decl(trf_9833)
static void C_fcall trf_9833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9833(t0,t1,t2);}

C_noret_decl(trf_9823)
static void C_fcall trf_9823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9823(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9823(t0,t1,t2);}

C_noret_decl(trf_9678)
static void C_fcall trf_9678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9678(t0,t1,t2);}

C_noret_decl(trf_9682)
static void C_fcall trf_9682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9682(t0,t1);}

C_noret_decl(trf_9693)
static void C_fcall trf_9693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9693(t0,t1);}

C_noret_decl(trf_9407)
static void C_fcall trf_9407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9407(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9407(t0,t1,t2);}

C_noret_decl(trf_9348)
static void C_fcall trf_9348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9348(t0,t1);}

C_noret_decl(trf_9288)
static void C_fcall trf_9288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9288(t0,t1);}

C_noret_decl(trf_9275)
static void C_fcall trf_9275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9275(t0,t1);}

C_noret_decl(trf_9046)
static void C_fcall trf_9046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9046(t0,t1);}

C_noret_decl(trf_9104)
static void C_fcall trf_9104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9104(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9104(t0,t1,t2,t3);}

C_noret_decl(trf_8936)
static void C_fcall trf_8936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8936(t0,t1);}

C_noret_decl(trf_9010)
static void C_fcall trf_9010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9010(t0,t1);}

C_noret_decl(trf_8914)
static void C_fcall trf_8914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8914(t0,t1);}

C_noret_decl(trf_8579)
static void C_fcall trf_8579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8579(t0,t1);}

C_noret_decl(trf_8584)
static void C_fcall trf_8584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8584(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8584(t0,t1,t2,t3);}

C_noret_decl(trf_8600)
static void C_fcall trf_8600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8600(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8600(t0,t1);}

C_noret_decl(trf_8605)
static void C_fcall trf_8605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8605(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8605(t0,t1,t2,t3);}

C_noret_decl(trf_8500)
static void C_fcall trf_8500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8500(t0,t1,t2);}

C_noret_decl(trf_8445)
static void C_fcall trf_8445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8445(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8445(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8457)
static void C_fcall trf_8457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8457(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8457(t0,t1,t2);}

C_noret_decl(trf_8323)
static void C_fcall trf_8323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8323(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8323(t0,t1,t2,t3);}

C_noret_decl(trf_8299)
static void C_fcall trf_8299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8299(t0,t1,t2);}

C_noret_decl(trf_8305)
static void C_fcall trf_8305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8305(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8305(t0,t1,t2);}

C_noret_decl(trf_8246)
static void C_fcall trf_8246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8246(t0,t1,t2);}

C_noret_decl(trf_8217)
static void C_fcall trf_8217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8217(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8217(t0,t1,t2);}

C_noret_decl(trf_8182)
static void C_fcall trf_8182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8182(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8182(t0,t1,t2,t3);}

C_noret_decl(trf_8157)
static void C_fcall trf_8157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8157(t0,t1);}

C_noret_decl(trf_8124)
static void C_fcall trf_8124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8124(t0,t1);}

C_noret_decl(trf_7941)
static void C_fcall trf_7941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7941(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7941(t0,t1,t2,t3);}

C_noret_decl(trf_7965)
static void C_fcall trf_7965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7965(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7965(t0,t1,t2,t3);}

C_noret_decl(trf_7827)
static void C_fcall trf_7827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7827(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7827(t0,t1,t2);}

C_noret_decl(trf_7854)
static void C_fcall trf_7854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7854(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7854(t0,t1,t2);}

C_noret_decl(trf_7761)
static void C_fcall trf_7761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7761(t0,t1,t2);}

C_noret_decl(trf_7781)
static void C_fcall trf_7781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7781(t0,t1);}

C_noret_decl(trf_7581)
static void C_fcall trf_7581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7581(t0,t1);}

C_noret_decl(trf_7618)
static void C_fcall trf_7618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7618(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7618(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7330)
static void C_fcall trf_7330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7330(t0,t1,t2);}

C_noret_decl(trf_7501)
static void C_fcall trf_7501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7501(t0,t1);}

C_noret_decl(trf_7505)
static void C_fcall trf_7505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7505(t0,t1);}

C_noret_decl(trf_7434)
static void C_fcall trf_7434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7434(t0,t1);}

C_noret_decl(trf_7442)
static void C_fcall trf_7442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7442(t0,t1);}

C_noret_decl(trf_7389)
static void C_fcall trf_7389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7389(t0,t1);}

C_noret_decl(trf_7355)
static void C_fcall trf_7355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7355(t0,t1);}

C_noret_decl(trf_7309)
static void C_fcall trf_7309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7309(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7309(t0,t1,t2);}

C_noret_decl(trf_7263)
static void C_fcall trf_7263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7263(t0,t1,t2);}

C_noret_decl(trf_7280)
static void C_fcall trf_7280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7280(t0,t1);}

C_noret_decl(trf_7109)
static void C_fcall trf_7109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7109(t0,t1);}

C_noret_decl(trf_7064)
static void C_fcall trf_7064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7064(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7064(t0,t1,t2);}

C_noret_decl(trf_7031)
static void C_fcall trf_7031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7031(t0,t1,t2);}

C_noret_decl(trf_6970)
static void C_fcall trf_6970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6970(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6970(t0,t1,t2);}

C_noret_decl(trf_6892)
static void C_fcall trf_6892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6892(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6892(t0,t1,t2);}

C_noret_decl(trf_6868)
static void C_fcall trf_6868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6868(t0,t1);}

C_noret_decl(trf_6818)
static void C_fcall trf_6818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6818(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6818(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6687)
static void C_fcall trf_6687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6687(t0,t1);}

C_noret_decl(trf_6698)
static void C_fcall trf_6698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6698(t0,t1,t2);}

C_noret_decl(trf_6714)
static void C_fcall trf_6714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6714(t0,t1);}

C_noret_decl(trf_6531)
static void C_fcall trf_6531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6531(t0,t1);}

C_noret_decl(trf_6526)
static void C_fcall trf_6526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6526(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6526(t0,t1,t2);}

C_noret_decl(trf_6191)
static void C_fcall trf_6191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6191(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6191(t0,t1,t2,t3);}

C_noret_decl(trf_6195)
static void C_fcall trf_6195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6195(t0,t1);}

C_noret_decl(trf_6477)
static void C_fcall trf_6477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6477(t0,t1);}

C_noret_decl(trf_6270)
static void C_fcall trf_6270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6270(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6270(t0,t1,t2);}

C_noret_decl(trf_6143)
static void C_fcall trf_6143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6143(t0,t1);}

C_noret_decl(trf_6080)
static void C_fcall trf_6080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6080(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6080(t0,t1,t2);}

C_noret_decl(trf_5992)
static void C_fcall trf_5992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5992(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5992(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5982)
static void C_fcall trf_5982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5982(t0,t1);}

C_noret_decl(trf_5710)
static void C_fcall trf_5710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5710(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5710(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3954)
static void C_fcall trf_3954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3954(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3954(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4113)
static void C_fcall trf_4113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4113(t0,t1);}

C_noret_decl(trf_5517)
static void C_fcall trf_5517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5517(t0,t1);}

C_noret_decl(trf_5364)
static void C_fcall trf_5364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5364(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5364(t0,t1,t2);}

C_noret_decl(trf_5316)
static void C_fcall trf_5316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5316(t0,t1);}

C_noret_decl(trf_5651)
static void C_fcall trf_5651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5651(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5651(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4830)
static void C_fcall trf_4830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4830(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4830(t0,t1,t2,t3);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4016(t0,t1);}

C_noret_decl(trf_4011)
static void C_fcall trf_4011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4011(t0,t1);}

C_noret_decl(trf_3948)
static void C_fcall trf_3948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3948(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3948(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3883)
static void C_fcall trf_3883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3883(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3883(t0,t1,t2,t3);}

C_noret_decl(trf_3902)
static void C_fcall trf_3902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3902(t0,t1);}

C_noret_decl(trf_3911)
static void C_fcall trf_3911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3911(t0,t1);}

C_noret_decl(trf_3771)
static void C_fcall trf_3771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3771(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3771(t0,t1,t2,t3);}

C_noret_decl(trf_3729)
static void C_fcall trf_3729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3729(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3729(t0,t1,t2);}

C_noret_decl(trf_3735)
static void C_fcall trf_3735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3735(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3735(t0,t1,t2,t3);}

C_noret_decl(trf_3631)
static void C_fcall trf_3631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3631(t0,t1,t2);}

C_noret_decl(trf_3579)
static void C_fcall trf_3579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3579(t0,t1,t2);}

C_noret_decl(trf_3530)
static void C_fcall trf_3530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3530(t0,t1,t2);}

C_noret_decl(trf_3401)
static void C_fcall trf_3401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3401(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3401(t0,t1,t2,t3);}

C_noret_decl(trf_3310)
static void C_fcall trf_3310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3310(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3310(t0,t1,t2,t3);}

C_noret_decl(trf_3262)
static void C_fcall trf_3262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3262(t0,t1);}

C_noret_decl(trf_3257)
static void C_fcall trf_3257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3257(t0,t1,t2);}

C_noret_decl(trf_2826)
static void C_fcall trf_2826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2826(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2826(t0,t1,t2);}

C_noret_decl(trf_3009)
static void C_fcall trf_3009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3009(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3009(t0,t1,t2);}

C_noret_decl(trf_3015)
static void C_fcall trf_3015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3015(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3015(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3066)
static void C_fcall trf_3066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3066(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3066(t0,t1,t2);}

C_noret_decl(trf_2829)
static void C_fcall trf_2829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2829(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2829(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2841)
static void C_fcall trf_2841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2841(t0,t1,t2,t3);}

C_noret_decl(trf_2860)
static void C_fcall trf_2860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2860(t0,t1);}

C_noret_decl(trf_2327)
static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2327(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2767)
static void C_fcall trf_2767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2767(t0,t1);}

C_noret_decl(trf_2686)
static void C_fcall trf_2686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2686(t0,t1);}

C_noret_decl(trf_2640)
static void C_fcall trf_2640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2640(t0,t1);}

C_noret_decl(trf_2643)
static void C_fcall trf_2643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2643(t0,t1);}

C_noret_decl(trf_2603)
static void C_fcall trf_2603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2603(t0,t1);}

C_noret_decl(trf_2571)
static void C_fcall trf_2571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2571(t0,t1);}

C_noret_decl(trf_2513)
static void C_fcall trf_2513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2513(t0,t1);}

C_noret_decl(trf_2345)
static void C_fcall trf_2345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2345(t0,t1);}

C_noret_decl(trf_2357)
static void C_fcall trf_2357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2357(t0,t1);}

C_noret_decl(trf_2348)
static void C_fcall trf_2348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2348(t0,t1);}

C_noret_decl(trf_2308)
static void C_fcall trf_2308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2308(t0,t1,t2);}

C_noret_decl(trf_2268)
static void C_fcall trf_2268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2268(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2268(t0,t1,t2);}

C_noret_decl(trf_2287)
static void C_fcall trf_2287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2287(t0,t1);}

C_noret_decl(trf_2219)
static void C_fcall trf_2219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2219(t0,t1,t2);}

C_noret_decl(trf_2137)
static void C_fcall trf_2137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2137(t0,t1);}

C_noret_decl(trf_1976)
static void C_fcall trf_1976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1976(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1976(t0,t1,t2,t3);}

C_noret_decl(trf_2004)
static void C_fcall trf_2004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2004(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2004(t0,t1,t2);}

C_noret_decl(trf_1830)
static void C_fcall trf_1830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1830(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1830(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1862)
static void C_fcall trf_1862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1862(t0,t1);}

C_noret_decl(trf_1879)
static void C_fcall trf_1879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1879(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1879(t0,t1,t2);}

C_noret_decl(trf_1898)
static void C_fcall trf_1898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1898(t0,t1);}

C_noret_decl(trf_1859)
static void C_fcall trf_1859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1859(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(7636)){
C_save(t1);
C_rereclaim2(7636*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,521);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscore-library-modules");
lf[3]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000\002\376\001\000\000\005regex\376\003\000\000"
"\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005match\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4"
"\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\377\016");
lf[4]=C_h_intern(&lf[4],28,"\003sysexplicit-library-modules");
lf[6]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022chicken-ffi-macros\376\003\000\000\002\376\001\000\000\023chicken-more-macros\376\377\016");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\003\000\000\002\376\001\000\000\007srfi-69\376\377\016");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[31]=C_h_intern(&lf[31],18,"\003syschicken-prefix");
lf[32]=C_h_intern(&lf[32],17,"\003sysstring-append");
lf[33]=C_h_intern(&lf[33],6,"getenv");
lf[34]=C_h_intern(&lf[34],12,"chicken-home");
lf[35]=C_h_intern(&lf[35],17,"\003syspeek-c-string");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[37]=C_h_intern(&lf[37],21,"\003sysmacro-environment");
lf[38]=C_h_intern(&lf[38],20,"\003sysregister-macro-2");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],18,"\003sysregister-macro");
lf[41]=C_h_intern(&lf[41],14,"\003syscopy-macro");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],6,"macro\077");
lf[44]=C_h_intern(&lf[44],15,"undefine-macro!");
lf[45]=C_h_intern(&lf[45],13,"string-append");
lf[46]=C_h_intern(&lf[46],17,"\003sysmacroexpand-0");
lf[47]=C_h_intern(&lf[47],9,"\003sysabort");
lf[48]=C_h_intern(&lf[48],9,"condition");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[53]=C_h_intern(&lf[53],3,"exn");
lf[54]=C_h_intern(&lf[54],22,"with-exception-handler");
lf[55]=C_h_intern(&lf[55],30,"call-with-current-continuation");
lf[56]=C_h_intern(&lf[56],21,"\003syssyntax-error-hook");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],16,"\004coreloop-lambda");
lf[60]=C_h_intern(&lf[60],6,"letrec");
lf[61]=C_h_intern(&lf[61],8,"\004coreapp");
lf[62]=C_h_intern(&lf[62],7,"\003sysmap");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[73]=C_h_intern(&lf[73],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[74]=C_h_intern(&lf[74],23,"\003sysmacroexpand-1-local");
lf[75]=C_h_intern(&lf[75],25,"\003sysenable-runtime-macros");
lf[76]=C_h_intern(&lf[76],11,"macroexpand");
lf[77]=C_h_intern(&lf[77],13,"macroexpand-1");
lf[78]=C_h_intern(&lf[78],25,"\003sysextended-lambda-list\077");
lf[79]=C_h_intern(&lf[79],6,"#!rest");
lf[80]=C_h_intern(&lf[80],10,"#!optional");
lf[81]=C_h_intern(&lf[81],5,"#!key");
lf[82]=C_h_intern(&lf[82],7,"reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],31,"\003sysexpand-extended-lambda-list");
lf[85]=C_h_intern(&lf[85],9,":optional");
lf[86]=C_h_intern(&lf[86],13,"let-optionals");
lf[87]=C_h_intern(&lf[87],14,"let-optionals*");
lf[88]=C_h_intern(&lf[88],10,"\003sysappend");
lf[89]=C_h_intern(&lf[89],4,"let*");
lf[90]=C_h_intern(&lf[90],5,"quote");
lf[91]=C_h_intern(&lf[91],15,"\003sysget-keyword");
lf[92]=C_h_intern(&lf[92],6,"lambda");
lf[93]=C_h_intern(&lf[93],15,"string->keyword");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[104]=C_h_intern(&lf[104],3,"map");
lf[105]=C_h_intern(&lf[105],21,"\003syscanonicalize-body");
lf[106]=C_h_intern(&lf[106],5,"begin");
lf[107]=C_h_intern(&lf[107],6,"define");
lf[108]=C_h_intern(&lf[108],13,"define-values");
lf[109]=C_h_intern(&lf[109],20,"\003syscall-with-values");
lf[110]=C_h_intern(&lf[110],14,"\004coreundefined");
lf[111]=C_h_intern(&lf[111],25,"\003sysexpand-curried-define");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[119]=C_h_intern(&lf[119],20,"\003sysmatch-expression");
lf[120]=C_h_intern(&lf[120],15,"\003syshash-symbol");
lf[121]=C_h_intern(&lf[121],23,"\003syshash-table-for-each");
lf[122]=C_h_intern(&lf[122],12,"\003sysfor-each");
lf[123]=C_h_intern(&lf[123],28,"\003sysarbitrary-unbound-symbol");
lf[124]=C_h_intern(&lf[124],23,"\003syshash-table-location");
lf[125]=C_h_intern(&lf[125],20,"\003syseval-environment");
lf[126]=C_h_intern(&lf[126],26,"\003sysenvironment-is-mutable");
lf[127]=C_h_intern(&lf[127],18,"\003syseval-decorator");
lf[128]=C_h_intern(&lf[128],20,"\003sysmake-lambda-info");
lf[129]=C_h_intern(&lf[129],17,"get-output-string");
lf[130]=C_h_intern(&lf[130],5,"write");
lf[131]=C_h_intern(&lf[131],18,"open-output-string");
lf[132]=C_h_intern(&lf[132],19,"\003sysdecorate-lambda");
lf[133]=C_h_intern(&lf[133],19,"\003sysunbound-in-eval");
lf[134]=C_h_intern(&lf[134],20,"\003syseval-debug-level");
lf[135]=C_h_intern(&lf[135],21,"\003sysalias-global-hook");
lf[136]=C_h_intern(&lf[136],6,"cadadr");
lf[137]=C_h_intern(&lf[137],20,"with-input-from-file");
lf[138]=C_h_intern(&lf[138],7,"display");
lf[139]=C_h_intern(&lf[139],22,"\003syscompile-to-closure");
lf[140]=C_h_intern(&lf[140],18,"\003syscurrent-thread");
lf[141]=C_h_intern(&lf[141],9,"\003syserror");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[144]=C_h_intern(&lf[144],32,"\003syssymbol-has-toplevel-binding\077");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[146]=C_h_intern(&lf[146],15,"\004coreglobal-ref");
lf[147]=C_h_intern(&lf[147],10,"\004corecheck");
lf[148]=C_h_intern(&lf[148],14,"\004coreimmutable");
lf[149]=C_h_intern(&lf[149],2,"if");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[157]=C_h_intern(&lf[157],15,"\003sysmake-vector");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[159]=C_h_intern(&lf[159],1,"\077");
lf[160]=C_h_intern(&lf[160],10,"\003sysvector");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[162]=C_h_intern(&lf[162],25,"\003sysdecompose-lambda-list");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[164]=C_h_intern(&lf[164],17,"\004corenamed-lambda");
lf[165]=C_h_intern(&lf[165],23,"\004corerequire-for-syntax");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[167]=C_h_intern(&lf[167],11,"\003sysrequire");
lf[168]=C_h_intern(&lf[168],31,"\003syslookup-runtime-requirements");
lf[169]=C_h_intern(&lf[169],22,"\004corerequire-extension");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[171]=C_h_intern(&lf[171],22,"\003sysdo-the-right-thing");
lf[172]=C_h_intern(&lf[172],24,"\004coreelaborationtimeonly");
lf[173]=C_h_intern(&lf[173],23,"\004coreelaborationtimetoo");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[175]=C_h_intern(&lf[175],19,"\004corecompiletimetoo");
lf[176]=C_h_intern(&lf[176],20,"\004corecompiletimeonly");
lf[177]=C_h_intern(&lf[177],13,"\004corecallunit");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[179]=C_h_intern(&lf[179],12,"\004coredeclare");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[181]=C_h_intern(&lf[181],10,"\000compiling");
lf[182]=C_h_intern(&lf[182],12,"\003sysfeatures");
lf[183]=C_h_intern(&lf[183],28,"\010compilerprocess-declaration");
lf[184]=C_h_intern(&lf[184],8,"\003syswarn");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[186]=C_h_intern(&lf[186],18,"\004coredefine-inline");
lf[187]=C_h_intern(&lf[187],20,"\004coredefine-constant");
lf[188]=C_h_intern(&lf[188],14,"\004coreprimitive");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[190]=C_h_intern(&lf[190],8,"location");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[192]=C_h_intern(&lf[192],11,"\004coreinline");
lf[193]=C_h_intern(&lf[193],20,"\004coreinline_allocate");
lf[194]=C_h_intern(&lf[194],19,"\004coreforeign-lambda");
lf[195]=C_h_intern(&lf[195],28,"\004coredefine-foreign-variable");
lf[196]=C_h_intern(&lf[196],29,"\004coredefine-external-variable");
lf[197]=C_h_intern(&lf[197],17,"\004corelet-location");
lf[198]=C_h_intern(&lf[198],22,"\004coreforeign-primitive");
lf[199]=C_h_intern(&lf[199],20,"\004coreforeign-lambda*");
lf[200]=C_h_intern(&lf[200],24,"\004coredefine-foreign-type");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[202]=C_h_intern(&lf[202],11,"\003sysnumber\077");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[204]=C_h_intern(&lf[204],16,"\003syseval-handler");
lf[205]=C_h_intern(&lf[205],12,"eval-handler");
lf[206]=C_h_intern(&lf[206],4,"eval");
lf[207]=C_h_intern(&lf[207],24,"\003syssyntax-error-culprit");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[209]=C_h_intern(&lf[209],12,"load-verbose");
lf[210]=C_h_intern(&lf[210],14,"\003sysabort-load");
lf[211]=C_h_intern(&lf[211],27,"\003syscurrent-source-filename");
lf[212]=C_h_intern(&lf[212],21,"\003syscurrent-load-path");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[214]=C_h_intern(&lf[214],22,"set-dynamic-load-mode!");
lf[215]=C_h_intern(&lf[215],21,"\003sysset-dlopen-flags!");
lf[216]=C_h_intern(&lf[216],6,"global");
lf[217]=C_h_intern(&lf[217],5,"local");
lf[218]=C_h_intern(&lf[218],4,"lazy");
lf[219]=C_h_intern(&lf[219],3,"now");
lf[220]=C_h_intern(&lf[220],15,"\003syssignal-hook");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[222]=C_h_intern(&lf[222],4,"read");
lf[223]=C_h_intern(&lf[223],7,"newline");
lf[224]=C_h_intern(&lf[224],15,"open-input-file");
lf[225]=C_h_intern(&lf[225],16,"close-input-port");
lf[226]=C_h_intern(&lf[226],8,"\003sysload");
lf[227]=C_h_intern(&lf[227],31,"\003sysread-error-with-line-number");
lf[228]=C_h_intern(&lf[228],19,"\003sysundefined-value");
lf[229]=C_h_intern(&lf[229],17,"\003sysdisplay-times");
lf[230]=C_h_intern(&lf[230],14,"\003sysstop-timer");
lf[231]=C_h_intern(&lf[231],15,"\003sysstart-timer");
lf[232]=C_h_intern(&lf[232],4,"load");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[234]=C_h_intern(&lf[234],9,"peek-char");
lf[235]=C_h_intern(&lf[235],16,"\003sysdynamic-wind");
lf[236]=C_h_intern(&lf[236],13,"\003syssubstring");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[238]=C_h_intern(&lf[238],9,"\003sysdload");
lf[239]=C_h_intern(&lf[239],17,"\003sysmake-c-string");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[241]=C_h_intern(&lf[241],11,"\000file-error");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\021can not open file");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[245]=C_h_intern(&lf[245],13,"\003sysfile-info");
lf[246]=C_h_intern(&lf[246],26,"\003sysload-dynamic-extension");
lf[247]=C_h_intern(&lf[247],11,"\000type-error");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[249]=C_h_intern(&lf[249],5,"port\077");
lf[250]=C_h_intern(&lf[250],20,"\003sysexpand-home-path");
lf[251]=C_h_intern(&lf[251],13,"load-relative");
lf[252]=C_h_intern(&lf[252],12,"load-noisily");
lf[253]=C_h_intern(&lf[253],8,"\000printer");
lf[254]=C_h_intern(&lf[254],5,"\000time");
lf[255]=C_h_intern(&lf[255],10,"\000evaluator");
lf[256]=C_h_intern(&lf[256],26,"\003sysload-library-extension");
lf[257]=C_h_intern(&lf[257],6,"cygwin");
lf[258]=C_h_intern(&lf[258],34,"\003sysdefault-dynamic-load-libraries");
lf[259]=C_h_intern(&lf[259],22,"dynamic-load-libraries");
lf[260]=C_h_intern(&lf[260],16,"\003sysload-library");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[265]=C_h_intern(&lf[265],24,"\003sysstring->c-identifier");
lf[266]=C_h_intern(&lf[266],16,"\003sys->feature-id");
lf[267]=C_h_intern(&lf[267],12,"load-library");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[270]=C_h_intern(&lf[270],31,"\003syscanonicalize-extension-path");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[272]=C_h_intern(&lf[272],18,"\003syssymbol->string");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[276]=C_h_intern(&lf[276],19,"\003sysrepository-path");
lf[277]=C_h_intern(&lf[277],15,"repository-path");
lf[278]=C_h_intern(&lf[278],12,"file-exists\077");
lf[279]=C_h_intern(&lf[279],18,"\003sysfind-extension");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[281]=C_h_intern(&lf[281],21,"\003sysinclude-pathnames");
lf[282]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[283]=C_h_intern(&lf[283],21,"\003sysloaded-extensions");
lf[284]=C_h_intern(&lf[284],14,"string->symbol");
lf[285]=C_h_intern(&lf[285],18,"\003sysload-extension");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\026can not load extension");
lf[287]=C_h_intern(&lf[287],11,"\003sysprovide");
lf[288]=C_h_intern(&lf[288],7,"provide");
lf[289]=C_h_intern(&lf[289],13,"\003sysprovided\077");
lf[290]=C_h_intern(&lf[290],9,"provided\077");
lf[291]=C_h_intern(&lf[291],7,"require");
lf[292]=C_h_intern(&lf[292],25,"\003sysextension-information");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[295]=C_h_intern(&lf[295],21,"extension-information");
lf[296]=C_h_intern(&lf[296],18,"require-at-runtime");
lf[297]=C_h_intern(&lf[297],12,"vector->list");
lf[298]=C_h_intern(&lf[298],11,"lset-adjoin");
lf[299]=C_h_intern(&lf[299],3,"eq\077");
lf[300]=C_h_intern(&lf[300],18,"hash-table-update!");
lf[301]=C_h_intern(&lf[301],26,"\010compilerfile-requirements");
lf[302]=C_h_intern(&lf[302],19,"syntax-requirements");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[304]=C_h_intern(&lf[304],18,"chicken-ffi-macros");
lf[305]=C_h_intern(&lf[305],19,"chicken-more-macros");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[307]=C_h_intern(&lf[307],28,"\003sysresolve-include-filename");
lf[308]=C_h_intern(&lf[308],4,"uses");
lf[309]=C_h_intern(&lf[309],6,"syntax");
lf[310]=C_h_intern(&lf[310],17,"require-extension");
lf[311]=C_h_intern(&lf[311],12,"\003sysfeature\077");
lf[312]=C_h_intern(&lf[312],24,"\003sysextension-specifiers");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[315]=C_h_intern(&lf[315],24,"set-extension-specifier!");
lf[316]=C_h_intern(&lf[316],11,"string-copy");
lf[319]=C_h_intern(&lf[319],11,"environment");
lf[321]=C_h_intern(&lf[321],18,"\003syscopy-env-table");
lf[322]=C_h_intern(&lf[322],23,"\003sysenvironment-symbols");
lf[323]=C_h_intern(&lf[323],18,"\003syswalk-namespace");
lf[324]=C_h_intern(&lf[324],23,"interaction-environment");
lf[325]=C_h_intern(&lf[325],25,"scheme-report-environment");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[327]=C_h_intern(&lf[327],11,"make-vector");
lf[328]=C_h_intern(&lf[328],16,"null-environment");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[337]=C_h_intern(&lf[337],24,"\003sysline-number-database");
lf[338]=C_h_intern(&lf[338],13,"\000syntax-error");
lf[339]=C_h_intern(&lf[339],12,"syntax-error");
lf[340]=C_h_intern(&lf[340],15,"get-line-number");
lf[341]=C_h_intern(&lf[341],8,"keyword\077");
lf[342]=C_h_intern(&lf[342],14,"symbol->string");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[351]=C_h_intern(&lf[351],1,"_");
lf[352]=C_h_intern(&lf[352],4,"pair");
lf[353]=C_h_intern(&lf[353],5,"pair\077");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[355]=C_h_intern(&lf[355],8,"variable");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[357]=C_h_intern(&lf[357],6,"symbol");
lf[358]=C_h_intern(&lf[358],7,"symbol\077");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[360]=C_h_intern(&lf[360],4,"list");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[362]=C_h_intern(&lf[362],6,"number");
lf[363]=C_h_intern(&lf[363],7,"number\077");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[365]=C_h_intern(&lf[365],6,"string");
lf[366]=C_h_intern(&lf[366],7,"string\077");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[368]=C_h_intern(&lf[368],11,"lambda-list");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[373]=C_h_intern(&lf[373],18,"\003sysrepl-eval-hook");
lf[374]=C_h_intern(&lf[374],27,"\003sysrepl-print-length-limit");
lf[375]=C_h_intern(&lf[375],18,"\003sysrepl-read-hook");
lf[376]=C_h_intern(&lf[376],19,"\003sysrepl-print-hook");
lf[377]=C_h_intern(&lf[377],16,"\003syswrite-char-0");
lf[378]=C_h_intern(&lf[378],9,"\003sysprint");
lf[379]=C_h_intern(&lf[379],27,"\003syswith-print-length-limit");
lf[380]=C_h_intern(&lf[380],11,"repl-prompt");
lf[381]=C_h_intern(&lf[381],20,"\003sysread-prompt-hook");
lf[382]=C_h_intern(&lf[382],16,"\003sysflush-output");
lf[383]=C_h_intern(&lf[383],19,"\003sysstandard-output");
lf[384]=C_h_intern(&lf[384],22,"\003sysclear-trace-buffer");
lf[385]=C_h_intern(&lf[385],16,"print-call-chain");
lf[386]=C_h_intern(&lf[386],12,"flush-output");
lf[387]=C_h_intern(&lf[387],5,"reset");
lf[388]=C_h_intern(&lf[388],4,"repl");
lf[389]=C_h_intern(&lf[389],18,"\003sysstandard-error");
lf[390]=C_h_intern(&lf[390],18,"\003sysstandard-input");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\005Error");
lf[394]=C_h_intern(&lf[394],17,"\003syserror-handler");
lf[395]=C_h_intern(&lf[395],20,"\003syswarnings-enabled");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[399]=C_h_intern(&lf[399],15,"\003sysread-char-0");
lf[400]=C_h_intern(&lf[400],15,"\003syspeek-char-0");
lf[401]=C_h_intern(&lf[401],21,"\003sysenable-qualifiers");
lf[402]=C_h_intern(&lf[402],17,"\003sysreset-handler");
lf[403]=C_h_intern(&lf[403],28,"\003syssharp-comma-reader-ctors");
lf[404]=C_h_intern(&lf[404],18,"define-reader-ctor");
lf[405]=C_h_intern(&lf[405],18,"\003sysuser-read-hook");
lf[406]=C_h_intern(&lf[406],9,"read-char");
lf[407]=C_h_intern(&lf[407],14,"\003sysread-error");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[412]=C_h_intern(&lf[412],19,"print-error-message");
lf[414]=C_h_intern(&lf[414],6,"\003sysgc");
lf[416]=C_h_intern(&lf[416],13,"thread-yield!");
lf[419]=C_h_intern(&lf[419],17,"open-input-string");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[430]=C_h_intern(&lf[430],15,"\003sysmake-string");
lf[431]=C_h_intern(&lf[431],6,"module");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\031modules are not supported");
lf[433]=C_h_intern(&lf[433],13,"define-syntax");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\042highlevel macros are not supported");
lf[435]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[436]=C_h_intern(&lf[436],12,"define-macro");
lf[437]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[438]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[439]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[441]=C_h_intern(&lf[441],14,"make-parameter");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[443]=C_h_intern(&lf[443],11,"cond-expand");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[445]=C_h_intern(&lf[445],3,"and");
lf[446]=C_h_intern(&lf[446],2,"or");
lf[447]=C_h_intern(&lf[447],3,"not");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[449]=C_h_intern(&lf[449],4,"else");
lf[450]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[451]=C_h_intern(&lf[451],16,"\003sysmake-promise");
lf[452]=C_h_intern(&lf[452],5,"delay");
lf[453]=C_h_intern(&lf[453],16,"\003syslist->vector");
lf[454]=C_h_intern(&lf[454],7,"unquote");
lf[455]=C_h_intern(&lf[455],8,"\003syslist");
lf[456]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[457]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[458]=C_h_intern(&lf[458],10,"quasiquote");
lf[459]=C_h_intern(&lf[459],8,"\003syscons");
lf[460]=C_h_intern(&lf[460],16,"unquote-splicing");
lf[461]=C_h_intern(&lf[461],1,"a");
lf[462]=C_h_intern(&lf[462],1,"b");
lf[463]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[464]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[465]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[466]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\002do");
lf[472]=C_h_intern(&lf[472],2,"do");
lf[473]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[474]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[475]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[476]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[477]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[478]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[479]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[480]=C_h_intern(&lf[480],4,"eqv\077");
lf[481]=C_h_intern(&lf[481],4,"case");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[483]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[484]=C_h_intern(&lf[484],2,"=>");
lf[485]=C_h_intern(&lf[485],9,"\003sysapply");
lf[486]=C_h_intern(&lf[486],4,"cond");
lf[487]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[488]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[489]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[490]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[491]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[492]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[493]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[494]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[496]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[497]=C_h_intern(&lf[497],18,"\003sysnumber->string");
lf[498]=C_h_intern(&lf[498],5,"error");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[500]=C_h_intern(&lf[500],7,"version");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[502]=C_h_intern(&lf[502],9,"string>=\077");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[504]=C_h_intern(&lf[504],12,"list->vector");
lf[505]=C_h_intern(&lf[505],18,"\003sysstring->symbol");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[507]=C_h_intern(&lf[507],4,"srfi");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[509]=C_h_intern(&lf[509],14,"build-platform");
lf[510]=C_h_intern(&lf[510],7,"windows");
lf[511]=C_h_intern(&lf[511],6,"macosx");
lf[512]=C_h_intern(&lf[512],4,"hpux");
lf[513]=C_h_intern(&lf[513],4,"hppa");
lf[514]=C_h_intern(&lf[514],12,"machine-type");
lf[515]=C_h_intern(&lf[515],16,"software-version");
lf[516]=C_h_intern(&lf[516],13,"software-type");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[518]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
C_register_lf2(lf,521,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,lf[3]);
t4=C_set_block_item(lf[4],0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[5],lf[6]);
t6=C_mutate(&lf[7],lf[8]);
t7=C_mutate(&lf[9],lf[10]);
t8=C_mutate(&lf[11],lf[12]);
t9=C_mutate(&lf[13],lf[14]);
t10=C_mutate(&lf[15],lf[16]);
t11=C_mutate(&lf[17],lf[18]);
t12=C_mutate(&lf[19],lf[20]);
t13=C_mutate(&lf[21],lf[22]);
t14=C_mutate(&lf[23],lf[24]);
t15=C_mutate(&lf[25],lf[26]);
t16=C_mutate(&lf[27],lf[28]);
t17=C_mutate(&lf[29],lf[30]);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 135  getenv */
t19=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[24]);}

/* k1709 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[518]);
t7=(C_truep(t6)?lf[519]:lf[520]);
/* eval.scm: 136  ##sys#string-append */
t8=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_1714(2,t3,C_SCHEME_FALSE);}}

/* k1712 in k1709 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1715,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=*((C_word*)lf[33]+1);
t4=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1742,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 156  make-vector */
t6=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1754 in k1712 in k1709 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word ab[67],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1758,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1774,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1790,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1800,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1818,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[45]+1);
t9=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2197,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2200,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2203,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2210,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2246,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2262,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[82]+1);
t18=*((C_word*)lf[83]+1);
t19=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[82]+1);
t21=*((C_word*)lf[104]+1);
t22=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2824,a[2]=t21,a[3]=t20,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3307,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3398,tmp=(C_word)a,a+=2,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3458,a[2]=t28,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3473,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3518,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3573,tmp=(C_word)a,a+=2,tmp));
t33=(C_word)C_slot(lf[123],C_fix(0));
t34=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=t33,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t36=C_set_block_item(lf[126],0,C_SCHEME_FALSE);
t37=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3679,tmp=(C_word)a,a+=2,tmp));
t38=C_set_block_item(lf[133],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[134],0,C_fix(1));
t40=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3720,tmp=(C_word)a,a+=2,tmp));
t41=*((C_word*)lf[43]+1);
t42=*((C_word*)lf[130]+1);
t43=*((C_word*)lf[136]+1);
t44=*((C_word*)lf[82]+1);
t45=*((C_word*)lf[131]+1);
t46=*((C_word*)lf[129]+1);
t47=*((C_word*)lf[137]+1);
t48=(C_word)C_slot(lf[123],C_fix(0));
t49=*((C_word*)lf[138]+1);
t50=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3726,a[2]=t43,a[3]=t48,tmp=(C_word)a,a+=4,tmp));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11348,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1037 make-parameter */
t53=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t53+1)))(3,t53,t51,t52);}

/* a11347 in k1754 in k1712 in k1709 */
static void C_ccall f_11348(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11348r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11348r(t0,t1,t2,t3);}}

static void C_ccall f_11348r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[126]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11352,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[319]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_11352(t15,t14);}
else{
t10=t8;
f_11352(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_11352(t9,C_SCHEME_UNDEFINED);}}

/* k11350 in a11347 in k1754 in k1712 in k1709 */
static void C_fcall f_11352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11352,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11358,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11360,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11376,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1047 ##sys#dynamic-wind */
t14=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a11375 in k11350 in a11347 in k1754 in k1712 in k1709 */
static void C_ccall f_11376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11376,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[126]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[125]+1));
t4=C_mutate((C_word*)lf[126]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[125]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[228]+1));}

/* a11369 in k11350 in a11347 in k1754 in k1712 in k1709 */
static void C_ccall f_11370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11370,2,t0,t1);}
/* eval.scm: 1049 ##sys#compile-to-closure */
t2=*((C_word*)lf[139]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a11359 in k11350 in a11347 in k1754 in k1712 in k1709 */
static void C_ccall f_11360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11360,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[126]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[125]+1));
t4=C_mutate((C_word*)lf[126]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[125]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[228]+1));}

/* k11356 in k11350 in a11347 in k1754 in k1712 in k1709 */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_5962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5962,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1,t1);
t3=C_mutate((C_word*)lf[205]+1,*((C_word*)lf[204]+1));
t4=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5965,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[82]+1);
t6=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5979,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 1081 make-parameter */
t9=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6061,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1,t1);
t3=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6063,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[211],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[212]+1,lf[213]);
t6=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6068,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[222]+1);
t8=*((C_word*)lf[130]+1);
t9=*((C_word*)lf[138]+1);
t10=*((C_word*)lf[223]+1);
t11=*((C_word*)lf[206]+1);
t12=*((C_word*)lf[224]+1);
t13=*((C_word*)lf[225]+1);
t14=*((C_word*)lf[45]+1);
t15=*((C_word*)lf[209]+1);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6141,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t9,a[5]=t12,a[6]=t13,a[7]=t8,a[8]=t10,a[9]=t7,a[10]=t11,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1113 ##sys#make-c-string */
t17=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[517]);}

/* k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6143,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp));
t4=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6576,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6598,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[252]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6634,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11342,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1203 software-type */
t9=*((C_word*)lf[516]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k11340 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11342,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[510]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6660(t3,lf[12]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1204 software-version */
t4=*((C_word*)lf[515]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11336 in k11340 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11338,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[511]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6660(t3,lf[10]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11334,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1205 software-version */
t5=*((C_word*)lf[515]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11332 in k11336 in k11340 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11334,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[512]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1206 machine-type */
t4=*((C_word*)lf[514]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_11320(t3,C_SCHEME_FALSE);}}

/* k11328 in k11332 in k11336 in k11340 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11320(t2,(C_word)C_eqp(t1,lf[513]));}

/* k11318 in k11336 in k11340 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_11320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6660(t2,(C_truep(t1)?lf[14]:lf[15]));}

/* k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6660,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[256]+1,t1);
t3=C_mutate((C_word*)lf[246]+1,lf[15]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1212 build-platform */
t5=*((C_word*)lf[509]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[257]);
t3=(C_truep(t2)?lf[8]:lf[6]);
t4=C_mutate((C_word*)lf[258]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11290,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11298,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[258]+1));}

/* a11297 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11298,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[256]+1));}

/* k11288 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11292,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1217 make-parameter */
t3=*((C_word*)lf[441]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a11291 in k11288 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11292,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6672,2,t0,t1);}
t2=C_mutate((C_word*)lf[259]+1,t1);
t3=*((C_word*)lf[209]+1);
t4=*((C_word*)lf[45]+1);
t5=*((C_word*)lf[259]+1);
t6=*((C_word*)lf[138]+1);
t7=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6674,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6780,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[82]+1);
t10=C_mutate(&lf[269],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6809,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[45]+1);
t12=C_mutate((C_word*)lf[270]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6865,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11259,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1305 getenv */
t15=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[22]);}

/* k11257 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11262,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_11262(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11265,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11275,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11279,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:C_fix(3));
/* eval.scm: 1309 ##sys#number->string */
t8=*((C_word*)lf[497]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k11277 in k11257 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1307 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[508],t1);}

/* k11273 in k11257 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1306 ##sys#chicken-prefix */
t2=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11263 in k11257 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11265,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11262(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k11260 in k11257 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1304 make-parameter */
t2=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7025,2,t0,t1);}
t2=C_mutate((C_word*)lf[276]+1,t1);
t3=C_mutate((C_word*)lf[277]+1,*((C_word*)lf[276]+1));
t4=*((C_word*)lf[278]+1);
t5=*((C_word*)lf[45]+1);
t6=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7028,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[283],0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[284]+1);
t9=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7105,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7173,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[288]+1,*((C_word*)lf[287]+1));
t12=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7193,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[290]+1,*((C_word*)lf[289]+1));
t14=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7207,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[291]+1,*((C_word*)lf[167]+1));
t16=*((C_word*)lf[137]+1);
t17=*((C_word*)lf[278]+1);
t18=*((C_word*)lf[45]+1);
t19=*((C_word*)lf[222]+1);
t20=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7220,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=C_mutate((C_word*)lf[295]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7251,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[137]+1);
t23=*((C_word*)lf[222]+1);
t24=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7257,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[297]+1);
t26=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7306,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(lf[312],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7705,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[504]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11205,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1496 set-extension-specifier! */
t32=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[507],t31);}

/* a11204 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11205,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11213,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11219,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_11219(t9,t4,t5);}

/* loop in a11204 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_11219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11219,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[310]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11239,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11251,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11255,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1506 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k11253 in loop in a11204 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1506 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[506],t1);}

/* k11249 in loop in a11204 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1506 ##sys#string->symbol */
t2=*((C_word*)lf[505]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11237 in loop in a11204 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11243,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1507 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11219(t4,t2,t3);}

/* k11241 in k11237 in loop in a11204 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11243,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11211 in a11204 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1500 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11084,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1512 set-extension-specifier! */
t4=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[500],t3);}

/* a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11084,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11087,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11121,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[500]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cdddr(t2);
t11=t5;
f_11121(t11,(C_word)C_i_nullp(t10));}
else{
t10=t5;
f_11121(t10,C_SCHEME_FALSE);}}
else{
t9=t5;
f_11121(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_11121(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_11121(t6,C_SCHEME_FALSE);}}

/* k11119 in a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_11121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11121,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11130,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1522 extension-information */
t5=*((C_word*)lf[295]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[310],lf[503],((C_word*)t0)[4]);}}

/* k11128 in k11119 in a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11130,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[500],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11136,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11139,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1524 ->string */
f_11087(t5,t6);}
else{
t5=t4;
f_11139(2,t5,C_SCHEME_FALSE);}}

/* k11147 in k11128 in k11119 in a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11153,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1524 ->string */
f_11087(t2,((C_word*)t0)[2]);}

/* k11151 in k11147 in k11128 in k11119 in a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1524 string>=? */
t2=*((C_word*)lf[502]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11137 in k11128 in k11119 in a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11136(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1525 error */
t2=*((C_word*)lf[498]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[501],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11134 in k11128 in k11119 in a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ->string in a11083 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_11087(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11087,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1518 ##sys#number->string */
t3=*((C_word*)lf[497]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1519 error */
t3=*((C_word*)lf[498]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[499],t2);}}}}

/* k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7747,2,t0,t1);}
t2=*((C_word*)lf[316]+1);
t3=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7749,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1546 make-vector */
t5=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7805,2,t0,t1);}
t2=C_mutate(&lf[317],t1);
t3=lf[318]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[319],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[320],t4);
t6=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7812,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7920,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8039,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8042,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[327]+1);
t11=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8086,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8124,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8140,a[2]=t12,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11082,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1627 initb */
f_8124(t14,lf[317]);}

/* k11080 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[496]);}

/* k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1648 ##sys#copy-env-table */
t3=*((C_word*)lf[321]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[317],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8144,2,t0,t1);}
t2=C_mutate(&lf[318],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8147,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11078,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1650 initb */
f_8124(t4,lf[318]);}

/* k11076 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[495]);}

/* k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1657 chicken-home */
t3=*((C_word*)lf[34]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8151,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[281]+1,t2);
t4=*((C_word*)lf[45]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8157,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8176,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[138]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8299,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8323,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8344,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(lf[337],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8398,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[207],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[339]+1,*((C_word*)lf[56]+1));
t15=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8406,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[45]+1);
t17=*((C_word*)lf[341]+1);
t18=*((C_word*)lf[340]+1);
t19=*((C_word*)lf[342]+1);
t20=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8442,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10981,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1818 ##sys#register-macro-2 */
t23=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[107],t22);}

/* a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10981,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10987,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10987(t6,t1,t2);}

/* loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10987(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10987,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11028,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1829 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[490]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11041,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1833 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[492]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11003,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1825 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[107],t3,lf[357]);}}

/* k11001 in loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1826 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[4],lf[494]);}

/* k11004 in k11001 in loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11006,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):lf[493]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],((C_word*)t0)[2],t3));}

/* k11039 in loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1834 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[3],lf[491]);}

/* k11042 in k11039 in loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11044,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[71],t2,t5));}

/* k11026 in loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1830 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[2],lf[489]);}

/* k11029 in k11026 in loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11038,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1831 ##sys#expand-curried-define */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11036 in k11029 in k11026 in loop in a10980 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_11038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1831 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10987(t2,((C_word*)t0)[2],t1);}

/* k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10953,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1837 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[445],t3);}

/* a10952 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10953,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(C_word)C_a_i_cons(&a,2,lf[445],t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[149],t5,t7,C_SCHEME_FALSE));}}}

/* k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10910,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1848 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[446],t4);}

/* a10909 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10910,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10932,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1858 gensym */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k10930 in a10909 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10932,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[446],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,4,lf[149],t1,t1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[58],t3,t5));}

/* k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1862 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[486],t4);}

/* a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10713,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10719,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10719(t6,t1,t2);}

/* expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10719(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10719,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10735,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1871 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[486],t3,lf[487]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[488]);}}

/* k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10735,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[449],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10765,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1873 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_10719(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_eqp(lf[484],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1875 gensym */
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
t9=(C_word)C_i_length(((C_word*)t0)[6]);
t10=(C_word)C_eqp(t9,C_fix(4));
if(C_truep(t10)){
t11=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
t12=t8;
f_10811(t12,(C_word)C_eqp(lf[484],t11));}
else{
t11=t8;
f_10811(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_10811(t9,C_SCHEME_FALSE);}}}}}

/* k10809 in k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1881 gensym */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10868,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1890 expand */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10719(t6,t5,((C_word*)t0)[3]);}}

/* k10866 in k10809 in k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10868,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10812 in k10809 in k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10814,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,lf[485],t4,t1);
t6=(C_word)C_u_i_cadddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_list(&a,3,lf[485],t6,t1);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10841,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1887 expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10719(t9,t8,((C_word*)t0)[2]);}

/* k10839 in k10812 in k10809 in k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10841,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k10772 in k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10774,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,t5,t1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10793,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1879 expand */
t8=((C_word*)((C_word*)t0)[3])[1];
f_10719(t8,t7,((C_word*)t0)[2]);}

/* k10791 in k10772 in k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10793,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t2));}

/* k10763 in k10733 in expand in a10712 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10765,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[446],((C_word*)t0)[2],t1));}

/* k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10610,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1892 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[481],t4);}

/* a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10610,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10620,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1898 gensym */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10618 in a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10620,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10631,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10633,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10633(t8,t4,((C_word*)t0)[2]);}

/* expand in k10618 in a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10633(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10633,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10649,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1905 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[481],t3,lf[482]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[483]);}}

/* k10647 in expand in k10618 in a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10649,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[449],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 1908 ##sys#map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a10686 in k10647 in expand in k10618 in a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10687,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[90],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[480],((C_word*)t0)[2],t3));}

/* k10683 in k10647 in expand in k10618 in a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10685,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[446],t1);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10677,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1910 expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10633(t6,t5,((C_word*)t0)[2]);}

/* k10675 in k10683 in k10647 in expand in k10618 in a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10677,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10629 in k10618 in a10609 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10631,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10557,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1912 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[89],t3);}

/* a10556 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10557,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10567,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1917 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[89],t3,lf[479]);}

/* k10565 in a10556 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1918 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],((C_word*)t0)[4],lf[478]);}

/* k10568 in k10565 in a10556 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10570,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10575,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10575(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k10568 in k10565 in a10556 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10575,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[58],t4));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10600,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1922 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k10598 in expand in k10568 in k10565 in a10556 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10600,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10487,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1924 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[60],t3);}

/* a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10487,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10497,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1929 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],t3,lf[477]);}

/* k10495 in a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1930 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[60],((C_word*)t0)[3],lf[476]);}

/* k10498 in k10495 in a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10547,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1931 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10546 in k10498 in k10495 in a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10547,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[475]));}

/* k10509 in k10498 in k10495 in a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10515,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10519,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10533,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1932 ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10532 in k10509 in k10498 in k10495 in a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10533,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[71],t3,t4));}

/* k10517 in k10509 in k10498 in k10495 in a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10519,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k10513 in k10509 in k10498 in k10495 in a10486 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10368,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1935 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[472],t4);}

/* a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_10368r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10368r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10368r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10372,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1939 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[472],t2,lf[474]);}

/* k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1940 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[472],((C_word*)t0)[6],lf[473]);}

/* k10373 in k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10378,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1941 gensym */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[471]);}

/* k10376 in k10373 in k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10469,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1942 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a10468 in k10376 in k10373 in k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10469,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k10383 in k10376 in k10373 in k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10385,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
t5=(C_truep(t4)?lf[469]:(C_word)C_a_i_cons(&a,2,lf[106],t3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10408,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t6;
f_10408(t8,lf[470]);}
else{
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t9=t6;
f_10408(t9,(C_word)C_a_i_cons(&a,2,lf[58],t8));}}

/* k10406 in k10383 in k10376 in k10373 in k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10408,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10422,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1953 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10421 in k10406 in k10383 in k10376 in k10373 in k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10422,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_i_car(t2));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_i_car(t7));}}

/* k10418 in k10406 in k10383 in k10376 in k10373 in k10370 in a10367 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10420,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[58],((C_word*)t0)[7],((C_word*)t0)[2],t5));}

/* k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[297]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10076,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1959 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[458],t4);}

/* a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10076,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10079,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10089,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10286,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
/* eval.scm: 2020 walk */
t12=((C_word*)t4)[1];
f_10079(t12,t1,t2,C_fix(0));}

/* simplify in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10286(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10286,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10290,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2007 ##sys#match-expression */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[467],lf[468]);}

/* k10288 in simplify in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10290,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[461],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[455],t3);
/* eval.scm: 2008 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10286(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2009 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[465],lf[466]);}}

/* k10309 in k10288 in simplify in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10311,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[462],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_u_i_assq(lf[461],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[455],t7);
/* eval.scm: 2013 simplify */
t9=((C_word*)((C_word*)t0)[4])[1];
f_10286(t9,((C_word*)t0)[3],t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2016 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[463],lf[464]);}}

/* k10351 in k10309 in k10288 in simplify in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[461],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10089(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10089,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10103,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10107,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1969 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[454]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10150,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1981 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_10079(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[457]);}}
else{
t7=(C_word)C_eqp(t4,lf[458]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[458]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10177,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1986 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_10079(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[458]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10196,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1987 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_10079(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[460]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10230,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1998 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_10079(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[90],lf[460]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10249,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 2000 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_10079(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10260,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2002 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_10079(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10277,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2003 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_10079(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}

/* k10275 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10281,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2003 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10279 in k10275 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10281,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10258 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10264,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2002 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10262 in k10258 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10264,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10247 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10249,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10241,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2001 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10079(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10239 in k10247 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10241,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10228 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10230,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[88],((C_word*)t0)[2],t1));}

/* k10194 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10196,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10175 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10177,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[2],t1));}

/* k10148 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10150,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[455],lf[456],t1));}

/* k10105 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1969 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10079(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10101 in walk1 in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10103,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[453],t1));}

/* walk in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_10079(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10079,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10087,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1964 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10089(t5,t4,t2,t3);}

/* k10085 in walk in a10075 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1964 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10286(t2,((C_word*)t0)[2],t1);}

/* k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10066,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2022 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[452],t3);}

/* a10065 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10066,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[451],t3));}

/* k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8864,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9820,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2026 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[443],t3);}

/* a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9820,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9823,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9833,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9975,a[2]=t3,a[3]=t5,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_9975(t10,t1,t2);}

/* expand in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9975(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9975,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9989,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9991,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_eqp(t6,lf[449]);
if(C_truep(t7)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(t8,C_SCHEME_END_OF_LIST);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?lf[450]:(C_word)C_a_i_cons(&a,2,lf[106],t8)));}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10046,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2071 test */
t9=((C_word*)((C_word*)t0)[3])[1];
f_9833(t9,t8,t6);}}
else{
/* eval.scm: 2064 err */
t6=((C_word*)t0)[2];
f_9823(t6,t1,t4);}}
else{
/* eval.scm: 2059 err */
t4=((C_word*)t0)[2];
f_9823(t4,t1,t2);}}}

/* k10044 in expand in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_10046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10046,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[106],t2));}
else{
/* eval.scm: 2072 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9975(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a9990 in expand in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9991,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k9987 in expand in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[141]+1),lf[448],t1);}

/* test in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9833,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 2034 ##sys#feature? */
t3=*((C_word*)lf[311]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_eqp(t4,lf[445]);
if(C_truep(t5)){
t6=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9882,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2042 test */
t17=t7;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2044 err */
t7=((C_word*)t0)[2];
f_9823(t7,t1,t2);}}}
else{
t6=(C_word)C_eqp(t4,lf[446]);
if(C_truep(t6)){
t7=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9921,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2048 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2050 err */
t8=((C_word*)t0)[2];
f_9823(t8,t1,t2);}}}
else{
t7=(C_word)C_eqp(t4,lf[447]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9959,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_u_i_cadr(t2);
/* eval.scm: 2051 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2052 err */
t8=((C_word*)t0)[2];
f_9823(t8,t1,t2);}}}}
else{
/* eval.scm: 2035 err */
t3=((C_word*)t0)[2];
f_9823(t3,t1,t2);}}}

/* k9957 in test in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k9919 in test in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9921,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[446],t2);
/* eval.scm: 2049 test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9833(t4,((C_word*)t0)[4],t3);}}

/* k9880 in test in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9882,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[445],t2);
/* eval.scm: 2043 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9833(t4,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* err in a9819 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9823(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9823,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[443],((C_word*)t0)[2]);
/* eval.scm: 2031 ##sys#error */
t4=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[444],t2,t3);}

/* k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2078 append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[442],*((C_word*)lf[182]+1));}

/* k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8868,2,t0,t1);}
t2=C_mutate((C_word*)lf[182]+1,t1);
t3=C_set_block_item(lf[373],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[374],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[375],0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8873,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9817,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2092 make-parameter */
t9=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9816 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9817,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[440]);}

/* k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8890,2,t0,t1);}
t2=C_mutate((C_word*)lf[380]+1,t1);
t3=*((C_word*)lf[380]+1);
t4=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8892,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8908,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[206]+1);
t7=*((C_word*)lf[222]+1);
t8=*((C_word*)lf[55]+1);
t9=*((C_word*)lf[385]+1);
t10=*((C_word*)lf[386]+1);
t11=*((C_word*)lf[209]+1);
t12=*((C_word*)lf[387]+1);
t13=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8911,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2208 make-vector */
t15=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9250,2,t0,t1);}
t2=C_mutate((C_word*)lf[403]+1,t1);
t3=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9252,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[405]+1);
t5=*((C_word*)lf[406]+1);
t6=*((C_word*)lf[222]+1);
t7=C_mutate((C_word*)lf[405]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9261,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9675,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2237 ##sys#register-macro */
t10=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[436],t9);}

/* a9674 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9675(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_9675r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9675r(t0,t1,t2,t3);}}

static void C_ccall f_9675r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9678,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9783,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2248 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[436],t3,lf[437]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9793,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2251 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[436],t2,lf[439]);}}

/* k9791 in a9674 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2252 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[436],((C_word*)t0)[4],lf[438]);}

/* k9794 in k9791 in a9674 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9796,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
/* eval.scm: 2253 expand */
f_9678(((C_word*)t0)[2],t2,t5);}

/* k9781 in a9674 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* eval.scm: 2249 expand */
f_9678(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a9674 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9678(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9678,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9682,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(lf[92],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cadr(t3);
t9=t4;
f_9682(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_9682(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_9682(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9682(t5,C_SCHEME_FALSE);}}

/* k9680 in expand in a9674 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9682,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[75]+1))?lf[173]:lf[172]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9693,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[92],t8);
t10=t3;
f_9693(t10,(C_word)C_a_i_list(&a,3,lf[38],t4,t9));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t6=t3;
f_9693(t6,(C_word)C_a_i_list(&a,3,lf[41],t4,t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=t3;
f_9693(t5,(C_word)C_a_i_list(&a,3,lf[40],t4,((C_word*)t0)[2]));}}}

/* k9691 in k9680 in expand in a9674 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9693,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9656,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2255 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[310],t3);}

/* a9655 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9656(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9656r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9656r(t0,t1,t2);}}

static void C_ccall f_9656r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9660,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2258 ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[310],t2,lf[435]);}

/* k9658 in a9655 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9667,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9669,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9668 in k9658 in a9655 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9669,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k9665 in k9658 in a9655 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9667,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[169],t1));}

/* k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9650,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2264 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[433],t3);}

/* a9649 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9650,3,t0,t1,t2);}
/* eval.scm: 2267 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[433],lf[434]);}

/* k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9644,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2269 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[431],t3);}

/* a9643 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9644,3,t0,t1,t2);}
/* eval.scm: 2272 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[431],lf[432]);}

/* k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9345,2,t0,t1);}
t2=lf[410]=C_SCHEME_FALSE;;
t3=C_mutate(&lf[411],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9348,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[413],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9407,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[415],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9416,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[417],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9428,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[418],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9444,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[420],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9470,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[422],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9483,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[423],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9509,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[424],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9546,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[425],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9562,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[426],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9588,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[427],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9610,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[428],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9625,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9635,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9635,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9642,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2379 ##sys#make-string */
t5=*((C_word*)lf[430]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9640 in ##sys#make-lambda-info in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9625,4,t0,t1,t2,t3);}
t4=lf[410];
t5=(C_truep(t4)?t4:lf[429]);
/* eval.scm: 2372 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9470(t5,t3,t2));}

/* CHICKEN_load in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9610,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9614,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9612 in CHICKEN_load in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9619,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2369 run-safe */
f_9348(((C_word*)t0)[2],t2);}

/* a9618 in k9612 in CHICKEN_load in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9623,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2369 load */
t3=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9621 in a9618 in k9612 in CHICKEN_load in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9588,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9592,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9590 in CHICKEN_read in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9592,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9597,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2363 run-safe */
f_9348(((C_word*)t0)[2],t3);}

/* a9596 in k9590 in CHICKEN_read in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9601,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2365 open-input-string */
t3=*((C_word*)lf[419]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9599 in a9596 in k9590 in CHICKEN_read in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2366 read */
t3=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9606 in k9599 in a9596 in k9590 in CHICKEN_read in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2366 store-result */
f_9407(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9562,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9568,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2356 run-safe */
f_9348(t1,t6);}

/* a9567 in CHICKEN_apply_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2358 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9570 in a9567 in CHICKEN_apply_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9575,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9586,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9584 in k9570 in a9567 in CHICKEN_apply_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2359 write */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9573 in k9570 in a9567 in CHICKEN_apply_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2360 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9580 in k9573 in k9570 in a9567 in CHICKEN_apply_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2360 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9470(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9546,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9552,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2351 run-safe */
f_9348(t1,t5);}

/* a9551 in CHICKEN_apply in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9560,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9558 in a9551 in CHICKEN_apply in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2351 store-result */
f_9407(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9509,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9513,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9513,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9518,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2342 run-safe */
f_9348(((C_word*)t0)[2],t4);}

/* a9517 in k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2344 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9520 in a9517 in k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9525,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9536,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9540,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9544,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2345 open-input-string */
t6=*((C_word*)lf[419]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9542 in k9520 in a9517 in k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2345 read */
t2=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9538 in k9520 in a9517 in k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2345 eval */
t2=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9534 in k9520 in a9517 in k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2345 write */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9523 in k9520 in a9517 in k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2346 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9530 in k9523 in k9520 in a9517 in k9511 in CHICKEN_eval_string_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2346 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9470(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9483,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9489,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2333 run-safe */
f_9348(t1,t5);}

/* a9488 in CHICKEN_eval_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2335 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9491 in a9488 in CHICKEN_eval_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9496,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9507,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2336 eval */
t4=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9505 in k9491 in a9488 in CHICKEN_eval_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2336 write */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9494 in k9491 in a9488 in CHICKEN_eval_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2337 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9501 in k9494 in k9491 in a9488 in CHICKEN_eval_to_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2337 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9470(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static C_word C_fcall f_9470(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[410],lf[421]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9444,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9448,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9446 in CHICKEN_eval_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9448,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9453,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2314 run-safe */
f_9348(((C_word*)t0)[2],t3);}

/* a9452 in k9446 in CHICKEN_eval_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9457,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2316 open-input-string */
t3=*((C_word*)lf[419]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9455 in a9452 in k9446 in CHICKEN_eval_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2317 read */
t4=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9466 in k9455 in a9452 in k9446 in CHICKEN_eval_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2317 eval */
t2=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9462 in k9455 in a9452 in k9446 in CHICKEN_eval_string in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2317 store-result */
f_9407(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9428,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9434,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2309 run-safe */
f_9348(t1,t4);}

/* a9433 in CHICKEN_eval in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9442,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2311 eval */
t3=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9440 in a9433 in CHICKEN_eval in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2311 store-result */
f_9407(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9422,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2306 run-safe */
f_9348(t1,t2);}

/* a9421 in CHICKEN_yield in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2306 thread-yield! */
t3=*((C_word*)lf[416]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9424 in a9421 in CHICKEN_yield in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9407(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9407,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9411,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2300 ##sys#gc */
t5=*((C_word*)lf[414]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9409 in store-result in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9348(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9348,NULL,2,t1,t2);}
t3=lf[410]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9356,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2288 call-with-current-continuation */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9358,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9383,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2288 with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9382 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9389,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2288 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9394 in a9382 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9395(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9395r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9395r(t0,t1,t2);}}

static void C_ccall f_9395r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2288 g1463 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9400 in a9394 in a9382 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9401,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9388 in a9382 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9389,2,t0,t1);}
/* eval.scm: 2293 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9363 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9364,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9370,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2288 g1463 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9369 in a9363 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9374,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2289 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9372 in a9369 in a9363 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9377,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2290 print-error-message */
t3=*((C_word*)lf[412]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9375 in k9372 in a9369 in a9363 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9381,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2291 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9379 in k9375 in k9372 in a9369 in a9363 in a9357 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[410],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9354 in run-safe in k9343 in k9340 in k9337 in k9334 in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9261,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9271,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2220 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 2232 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9269 in ##sys#user-read-hook in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2221 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9272 in k9269 in ##sys#user-read-hook in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9275,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9288,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9288(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9288(t6,(C_word)C_i_not(t5));}}

/* k9286 in k9272 in k9269 in ##sys#user-read-hook in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9288,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 2224 err */
t2=((C_word*)t0)[5];
f_9275(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9306,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2228 ##sys#hash-table-ref */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[403]+1),t2);}
else{
/* eval.scm: 2227 err */
t3=((C_word*)t0)[5];
f_9275(t3,((C_word*)t0)[4]);}}}

/* k9304 in k9286 in k9272 in k9269 in ##sys#user-read-hook in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 2231 ##sys#read-error */
t2=*((C_word*)lf[407]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[409],((C_word*)t0)[2]);}}

/* err in k9272 in k9269 in ##sys#user-read-hook in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9275,NULL,2,t0,t1);}
/* eval.scm: 2222 ##sys#read-error */
t2=*((C_word*)lf[407]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[408],((C_word*)t0)[2]);}

/* define-reader-ctor in k9248 in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9252,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[404]);
/* eval.scm: 2212 ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[403]+1),t2,t3);}

/* repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8914,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[390]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[383]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[389]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8955,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 2122 ##sys#error-handler */
t10=*((C_word*)lf[394]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 2123 ##sys#reset-handler */
t3=*((C_word*)lf[402]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8958,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[133]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8960,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8966,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8975,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9040,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9235,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2137 ##sys#dynamic-wind */
t10=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9234 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9239,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2200 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9237 in a9234 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9239,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2202 ##sys#error-handler */
t4=*((C_word*)lf[394]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9241 in k9237 in a9234 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2203 ##sys#reset-handler */
t2=*((C_word*)lf[402]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9040,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9046(t5,t1);}

/* loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9046,NULL,2,t0,t1);}
t2=f_8960(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9053,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9218,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2160 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9217 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9218,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9224,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2162 ##sys#reset-handler */
t4=*((C_word*)lf[402]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9223 in a9217 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9224,2,t0,t1);}
t2=C_set_block_item(lf[227],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[401],0,C_SCHEME_TRUE);
t4=f_8966(((C_word*)t0)[3]);
/* eval.scm: 2167 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2168 ##sys#read-prompt-hook */
t3=*((C_word*)lf[381]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[375]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9059,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9068,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9213,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2171 ##sys#peek-char-0 */
t4=*((C_word*)lf[400]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[390]+1));}}

/* k9211 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 2172 ##sys#read-char-0 */
t3=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[390]+1));}
else{
t3=((C_word*)t0)[2];
f_9068(2,t3,C_SCHEME_UNDEFINED);}}

/* k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2173 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[384]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9071,2,t0,t1);}
t2=C_set_block_item(lf[133],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9077,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2175 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9086r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9086r(t0,t1,t2);}}

static void C_ccall f_9086r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9090,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[395]+1))?(C_word)C_i_pairp(*((C_word*)lf[133]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9104,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9104(t8,t3,*((C_word*)lf[133]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9090(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9104(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9104,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9108,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9120,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2180 ##sys#print */
t6=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[398],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t5=t4;
f_9108(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9167,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9167(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 2194 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[144]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9165 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9167,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 2195 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9104(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 2196 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9104(t5,((C_word*)t0)[3],t2,t4);}}

/* k9118 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9125,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9124 in k9118 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9125,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9129,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2185 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[397],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}

/* k9127 in a9124 in k9118 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 2186 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[389]+1));}

/* k9130 in k9127 in a9124 in k9118 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9135,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9144,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2188 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[396],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t3=t2;
f_9135(2,t3,C_SCHEME_UNDEFINED);}}

/* k9142 in k9130 in k9127 in a9124 in k9118 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9147,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 2189 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[389]+1));}

/* k9145 in k9142 in k9130 in k9127 in a9124 in k9118 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2190 ##sys#write-char-0 */
t2=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[389]+1));}

/* k9133 in k9130 in k9127 in a9124 in k9118 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2191 ##sys#write-char-0 */
t2=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[389]+1));}

/* k9106 in loop in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9088 in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9093,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8936,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_8936(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_8936(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k8934 in k9088 in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8936,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9093(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8941,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a8940 in k8934 in k9088 in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8941,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[376]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[383]+1));}

/* k9091 in k9088 in a9085 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2198 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9046(t2,((C_word*)t0)[2]);}

/* a9076 in k9069 in k9066 in k9057 in k9054 in k9051 in loop in a9039 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9077,2,t0,t1);}
t2=*((C_word*)lf[373]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8980,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 2139 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2140 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2141 ##sys#error-handler */
t3=*((C_word*)lf[394]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8988r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8988r(t0,t1,t2,t3);}}

static void C_ccall f_8988r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_8966(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8995,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 2144 ##sys#print */
t6=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[393],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}

/* k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9035,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2146 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[392],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t3=t2;
f_8998(2,t3,C_SCHEME_UNDEFINED);}}

/* k9033 in k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2147 ##sys#print */
t2=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}

/* k8996 in k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9001,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9010,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9010(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9010(t4,C_SCHEME_FALSE);}}

/* k9008 in k8996 in k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_9010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2150 ##sys#print */
t3=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[391],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2153 ##sys#write-char-0 */
t3=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[389]+1));}}

/* k9017 in k9008 in k8996 in k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2154 write-err */
f_8914(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9011 in k9008 in k8996 in k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2151 write-err */
f_8914(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8999 in k8996 in k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2155 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[389]+1));}

/* k9002 in k8999 in k8996 in k8993 in a8987 in k8981 in k8978 in a8974 in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2156 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[389]+1));}

/* resetports in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static C_word C_fcall f_8966(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[390]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[383]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[389]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k8956 in k8953 in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static C_word C_fcall f_8960(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[390]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[383]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[389]+1));
return(t3);}

/* write-err in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8914(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8914,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8920,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a8919 in write-err in repl in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8920,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[376]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[389]+1));}

/* ##sys#clear-trace-buffer in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8908,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1347(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8896,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8903,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8906,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2097 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8904 in ##sys#read-prompt-hook in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8901 in ##sys#read-prompt-hook in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2097 ##sys#print */
t2=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[383]+1));}

/* k8894 in ##sys#read-prompt-hook in k8888 in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2098 ##sys#flush-output */
t2=*((C_word*)lf[382]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[383]+1));}

/* ##sys#repl-print-hook in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8873,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8877,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8882,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2089 ##sys#with-print-length-limit */
t6=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[374]+1),t5);}

/* a8881 in ##sys#repl-print-hook in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8882,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k8875 in ##sys#repl-print-hook in k8866 in k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8835 in k8832 in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2090 ##sys#write-char-0 */
t2=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8442r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8442r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8442r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8457,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8445,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8550,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8579,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_slot(t5,C_fix(0));
t12=C_mutate((C_word*)lf[207]+1,t11);
t13=t10;
f_8579(t13,t12);}
else{
t11=t10;
f_8579(t11,C_SCHEME_UNDEFINED);}}

/* k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8579,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8584,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8584(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8584(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(19);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8584,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8600,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_8600(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_8600(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[351]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[352]);
if(C_truep(t7)){
/* eval.scm: 1801 test */
t8=((C_word*)t0)[4];
f_8445(t8,t1,t2,*((C_word*)lf[353]+1),lf[354]);}
else{
t8=(C_word)C_eqp(t5,lf[355]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8729,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1802 test */
t10=((C_word*)t0)[4];
f_8445(t10,t1,t2,t9,lf[356]);}
else{
t9=(C_word)C_eqp(t5,lf[357]);
if(C_truep(t9)){
/* eval.scm: 1803 test */
t10=((C_word*)t0)[4];
f_8445(t10,t1,t2,*((C_word*)lf[358]+1),lf[359]);}
else{
t10=(C_word)C_eqp(t5,lf[360]);
if(C_truep(t10)){
/* eval.scm: 1804 test */
t11=((C_word*)t0)[4];
f_8445(t11,t1,t2,((C_word*)t0)[3],lf[361]);}
else{
t11=(C_word)C_eqp(t5,lf[362]);
if(C_truep(t11)){
/* eval.scm: 1805 test */
t12=((C_word*)t0)[4];
f_8445(t12,t1,t2,*((C_word*)lf[363]+1),lf[364]);}
else{
t12=(C_word)C_eqp(t5,lf[365]);
if(C_truep(t12)){
/* eval.scm: 1806 test */
t13=((C_word*)t0)[4];
f_8445(t13,t1,t2,*((C_word*)lf[366]+1),lf[367]);}
else{
t13=(C_word)C_eqp(t5,lf[368]);
if(C_truep(t13)){
/* eval.scm: 1807 test */
t14=((C_word*)t0)[4];
f_8445(t14,t1,t2,((C_word*)t0)[2],lf[369]);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8783,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1808 test */
t15=((C_word*)t0)[4];
f_8445(t15,t1,t2,t14,lf[370]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1810 err */
t7=((C_word*)t0)[6];
f_8457(t7,t1,lf[371]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8802,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1812 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1797 err */
t6=((C_word*)t0)[6];
f_8457(t6,t1,lf[372]);}}}}

/* k8800 in walk in k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1813 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8584(t4,((C_word*)t0)[2],t2,t3);}

/* a8782 in walk in k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8783,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8728 in walk in k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8729,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k8598 in walk in k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8600,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8605(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1200 in k8598 in walk in k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8605(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8605,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1790 err */
t5=((C_word*)t0)[6];
f_8457(t5,t1,lf[348]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8624,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1792 err */
t6=((C_word*)t0)[6];
f_8457(t6,t5,lf[349]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1794 err */
t8=((C_word*)t0)[6];
f_8457(t8,t5,lf[350]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1795 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_8584(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8622 in do1200 in k8598 in walk in k8577 in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8605(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8550,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8556,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8556(t2));}

/* loop in proper-list? in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static C_word C_fcall f_8556(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8488,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8492,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1757 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8490 in lambda-list? in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8492,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8500,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_8500(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k8490 in lambda-list? in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8500,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8523,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1761 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1766 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k8521 in loop in k8490 in lambda-list? in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8445,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8452,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1745 pred */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k8450 in test in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1745 err */
t2=((C_word*)t0)[3];
f_8457(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8457(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8457,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[207]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8461,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1749 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8459 in err in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8468,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8475,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1752 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8486,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1753 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8484 in k8459 in err in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1753 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[346],t1,lf[347],((C_word*)t0)[2]);}

/* k8473 in k8459 in err in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8479,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1752 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k8477 in k8473 in k8459 in err in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1752 string-append */
t2=((C_word*)t0)[5];
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[4],lf[343],((C_word*)t0)[3],lf[344],t1,lf[345],((C_word*)t0)[2]);}

/* k8466 in k8459 in err in ##sys#check-syntax in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1750 ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8406,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[337]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8428,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1731 ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[337]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8426 in get-line-number in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_8398r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8398r(t0,t1,t2);}}

static void C_ccall f_8398r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[220]+1),lf[338],t2);}

/* ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8344,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8348,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1706 display-rj */
t5=((C_word*)t0)[2];
f_8323(t5,t3,t4,C_fix(8));}

/* k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1707 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[336]);}

/* k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1708 display-rj */
t4=((C_word*)t0)[2];
f_8323(t4,t2,t3,C_fix(8));}

/* k8352 in k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1709 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[335]);}

/* k8355 in k8352 in k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1710 display-rj */
t4=((C_word*)t0)[2];
f_8323(t4,t2,t3,C_fix(8));}

/* k8358 in k8355 in k8352 in k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1711 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[334]);}

/* k8361 in k8358 in k8355 in k8352 in k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1712 display-rj */
t4=((C_word*)t0)[2];
f_8323(t4,t2,t3,C_fix(8));}

/* k8364 in k8361 in k8358 in k8355 in k8352 in k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1713 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[333]);}

/* k8367 in k8364 in k8361 in k8358 in k8355 in k8352 in k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8372,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1714 display-rj */
t4=((C_word*)t0)[2];
f_8323(t4,t2,t3,C_fix(8));}

/* k8370 in k8367 in k8364 in k8361 in k8358 in k8355 in k8352 in k8349 in k8346 in ##sys#display-times in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1715 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[332]);}

/* display-rj in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8323(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8323,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8327,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_8327(2,t5,lf[331]);}
else{
/* eval.scm: 1701 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k8325 in display-rj in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8327,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8330,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1703 spaces */
t5=((C_word*)t0)[2];
f_8299(t5,t3,t4);}

/* k8328 in k8325 in display-rj in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1704 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8299,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8305,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8305(t6,t1,t2);}

/* do1130 in spaces in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8305,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8315,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1698 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k8313 in do1130 in spaces in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8305(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8176r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8176r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8176r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8182,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8217,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8234,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1679 test */
t12=t10;
f_8217(t12,t11,t2);}

/* k8232 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8234,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8285,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1681 ##sys#repository-path */
t4=*((C_word*)lf[276]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8244(2,t3,*((C_word*)lf[281]+1));}}}

/* k8283 in k8232 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8285,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1681 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[281]+1),t2);}

/* k8242 in k8232 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8244,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8246(t5,((C_word*)t0)[2],t1);}

/* loop in k8242 in k8232 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8246,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8256,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8270,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1684 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[330],((C_word*)t0)[5]);}}

/* k8268 in loop in k8242 in k8232 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1684 test */
t2=((C_word*)t0)[3];
f_8217(t2,((C_word*)t0)[2],t1);}

/* k8254 in loop in k8242 in k8232 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1687 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8246(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8217(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8217,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[17],*((C_word*)lf[246]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[246]+1),lf[17]));
/* eval.scm: 1674 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8182(t4,t1,t2,t3);}

/* test2 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8182(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8182,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8195,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1668 exists? */
f_8157(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8198,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1669 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8196 in test2 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1670 exists? */
f_8157(t2,t1);}

/* k8202 in k8196 in test2 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1672 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8182(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8193 in test2 in ##sys#resolve-include-filename in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8157(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8157,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8161,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1663 ##sys#file-info */
t4=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8159 in exists? in k8149 in k8145 in k8142 in k8138 in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_8124(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8124,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8126,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8126 in initb in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8126,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8130,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1624 ##sys#hash-table-location */
t4=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8128 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8086r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8086r(t0,t1,t2,t3);}}

static void C_ccall f_8086r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[328]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1615 ##sys#error */
t8=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[328],lf[329],t2);}
else{
t8=t5;
f_8093(2,t8,C_SCHEME_UNDEFINED);}}

/* k8091 in null-environment in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1618 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8098 in k8091 in null-environment in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8100,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[319],t1,t3));}

/* scheme-report-environment in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8042(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8042r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8042r(t0,t1,t2,t3);}}

static void C_ccall f_8042r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_exact_2(t2,lf[325]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8062,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1606 ##sys#copy-env-table */
t9=*((C_word*)lf[321]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[317],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8075,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1607 ##sys#copy-env-table */
t9=*((C_word*)lf[321]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[318],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1608 ##sys#error */
t8=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[325],lf[326],t2);}}

/* k8073 in scheme-report-environment in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8075,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[319],t1,((C_word*)t0)[2]));}

/* k8060 in scheme-report-environment in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8062,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[319],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8039,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[320]);}

/* ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7920r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7920r(t0,t1,t2,t3);}}

static void C_ccall f_7920r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t4=(C_word)C_i_check_structure(t2,lf[319]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7941,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_7941(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8012,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8014,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1593 ##sys#walk-namespace */
t12=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8013 in ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8014,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8024,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8024(2,t5,t3);}
else{
/* eval.scm: 1595 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8022 in a8013 in ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8024,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8010 in ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_8012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* do1061 in ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7941(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7941,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7959,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7965,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_7965(t10,t5,t6,t3);}}

/* loop in do1061 in ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7965(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7965,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7984,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_7984(2,t8,t6);}
else{
/* eval.scm: 1587 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k7982 in loop in do1061 in ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7984,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1588 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7965(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1589 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7965(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k7957 in do1061 in ##sys#environment-symbols in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_7941(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7812r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7812r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7822,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1554 ##sys#make-vector */
t10=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k7820 in ##sys#copy-env-table in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7822,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7827(t5,((C_word*)t0)[2],C_fix(0));}

/* do1044 in k7820 in ##sys#copy-env-table in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7827,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7848,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7854,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7854(t8,t3,t4);}}

/* copy in do1044 in k7820 in ##sys#copy-env-table in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7854(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7854,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7887,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1569 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1570 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k7885 in copy in do1044 in k7820 in ##sys#copy-env-table in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7887,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7846 in do1044 in k7820 in ##sys#copy-env-table in k7803 in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7827(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7749,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7753,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1535 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7751 in ##sys#string->c-identifier in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7753,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7761,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7761(t6,((C_word*)t0)[2],C_fix(0));}

/* do1029 in k7751 in ##sys#string->c-identifier in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7761,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7781,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7781(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7781(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7779 in do1029 in k7751 in ##sys#string->c-identifier in k7745 in k7742 in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7761(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7705,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[315]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[312]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7723,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7737,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[312]+1));
t9=C_mutate((C_word*)lf[312]+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7736 in set-extension-specifier! in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7737,3,t0,t1,t2);}
/* eval.scm: 1490 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7722 in set-extension-specifier! in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7723,3,t0,t1,t2);}
/* eval.scm: 1488 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7306,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7309,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7330,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7581,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
t8=t6;
f_7581(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7581(t7,C_SCHEME_FALSE);}}

/* k7579 in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7581,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[312]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1476 ##sys#error */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[313],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1478 doit */
t2=((C_word*)t0)[2];
f_7330(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1479 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[314],((C_word*)t0)[6]);}}}

/* k7588 in k7579 in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7590,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[232],t1);
/* eval.scm: 1464 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7616,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1466 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1475 ##sys#do-the-right-thing */
t2=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7614 in k7588 in k7579 in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7616,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7618,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7618(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7614 in k7588 in k7579 in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7618(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7618,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7636,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1470 reverse */
t6=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7651,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1471 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a7650 in loop in k7614 in k7588 in k7579 in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7651,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1472 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7618(t7,t1,t4,t5,t6);}

/* a7640 in loop in k7614 in k7588 in k7579 in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7641,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 1471 ##sys#do-the-right-thing */
t3=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7634 in loop in k7614 in k7588 in k7579 in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7636,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1470 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7330,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[28]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7340(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_7340(2,t5,(C_word)C_u_i_memq(t2,lf[30]));}
else{
/* eval.scm: 1417 ##sys#feature? */
t5=*((C_word*)lf[311]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7340,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1418 values */
C_values(4,0,((C_word*)t0)[5],lf[303],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[304]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[305]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1420 ##sys#->feature-id */
t4=*((C_word*)lf[266]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[2]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7389,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[308],((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,lf[90],t4);
t6=t3;
f_7389(t6,(C_word)C_a_i_list(&a,2,lf[179],t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[4]);
t5=t3;
f_7389(t5,(C_word)C_a_i_list(&a,2,lf[267],t4));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[4]+1)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1432 ##sys#extension-information */
t4=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[310]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1442 ##sys#extension-information */
t4=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[310]);}}}}}

/* k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7474,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[309],t1);
t3=(C_word)C_u_i_assq(lf[296],t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7486,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* eval.scm: 1446 add-req */
t5=((C_word*)t0)[2];
f_7309(t5,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_7486(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1458 add-req */
t3=((C_word*)t0)[2];
f_7309(t3,t2,((C_word*)t0)[3]);}}

/* k7553 in k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7555,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[167],t2);
/* eval.scm: 1459 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7484 in k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[165],t4);
t6=t3;
f_7501(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_7501(t4,C_SCHEME_END_OF_LIST);}}

/* k7499 in k7484 in k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7501,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7505,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_7505(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7521,tmp=(C_word)a,a+=2,tmp);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7520 in k7499 in k7484 in k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7521,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k7517 in k7499 in k7484 in k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7519,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[167],t1);
t3=((C_word*)t0)[2];
f_7505(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k7503 in k7499 in k7484 in k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1403 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7495 in k7484 in k7472 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1447 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7414 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7416,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[309],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7430,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[165],t5);
t7=t4;
f_7434(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_7434(t5,C_SCHEME_END_OF_LIST);}}

/* k7432 in k7414 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7434,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7442,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[308],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[90],t3);
t5=t2;
f_7442(t5,(C_word)C_a_i_list(&a,2,lf[179],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t4=t2;
f_7442(t4,(C_word)C_a_i_list(&a,2,lf[267],t3));}}

/* k7440 in k7432 in k7414 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7442,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1403 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7428 in k7414 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7430,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1434 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7387 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1426 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7350 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7355,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1)))){
t3=t2;
f_7355(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7364,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7372,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7376,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1422 ##sys#symbol->string */
t6=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k7374 in k7350 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1422 ##sys#resolve-include-filename */
t2=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7370 in k7350 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1422 ##sys#load */
t2=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7362 in k7350 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7364,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[182]+1));
t3=C_mutate((C_word*)lf[182]+1,t2);
t4=((C_word*)t0)[2];
f_7355(t4,t3);}

/* k7353 in k7350 in k7338 in doit in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1424 values */
C_values(4,0,((C_word*)t0)[2],lf[306],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7309,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7324,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1408 hash-table-update! */
t5=*((C_word*)lf[300]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,*((C_word*)lf[301]+1),lf[302],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7323 in add-req in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7324,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7317 in add-req in ##sys#do-the-right-thing in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7318,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[298]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[299]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7257,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7263,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7263(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7263,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7277,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1397 ##sys#extension-information */
t5=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7275 in loop1 in ##sys#lookup-runtime-requirements in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[296],t1);
t4=t2;
f_7280(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7280(t3,C_SCHEME_FALSE);}}

/* k7278 in k7275 in loop1 in ##sys#lookup-runtime-requirements in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7280,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7287,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1401 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7263(t5,t3,t4);}

/* k7285 in k7278 in k7275 in loop1 in ##sys#lookup-runtime-requirements in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1396 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7251,3,t0,t1,t2);}
/* eval.scm: 1387 ##sys#extension-information */
t3=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[295]);}

/* ##sys#extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7220,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1380 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k7222 in ##sys#extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7249,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1381 ##sys#repository-path */
t4=*((C_word*)lf[276]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7247 in k7222 in ##sys#extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1381 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],t1,lf[293],((C_word*)t0)[2],lf[294]);}

/* k7225 in k7222 in ##sys#extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7230,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7245,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1382 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[20]);}

/* k7243 in k7225 in k7222 in ##sys#extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1382 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7228 in k7225 in k7222 in ##sys#extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7230,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7237 in k7228 in k7225 in k7222 in ##sys#extension-information in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7237(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7237,3,t0,t1,t2);}
/* with-input-from-file934 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7207r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7207r(t0,t1,t2);}}

static void C_ccall f_7207r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7213,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7212 in ##sys#require in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7213,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[285]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[291]);}

/* ##sys#provided? in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7193,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7204,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1361 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[290]);}

/* k7202 in ##sys#provided? in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[283]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7173(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7173r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7173r(t0,t1,t2);}}

static void C_ccall f_7173r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7179,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7178 in ##sys#provide in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7179,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[288]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1354 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[288]);}

/* k7184 in a7178 in ##sys#provide in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7186,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[283]+1));
t3=C_mutate((C_word*)lf[283]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7105r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7105r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7105r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7109,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7168,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1335 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7109(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7166 in ##sys#load-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7109(t3,t2);}

/* k7107 in ##sys#load-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7109,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1337 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7110 in k7107 in ##sys#load-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[283]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[2]+1)))){
/* eval.scm: 1340 ##sys#load-library */
t3=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7130,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1342 ##sys#find-extension */
t4=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7128 in k7110 in k7107 in ##sys#load-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7130,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7136,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1344 ##sys#load */
t3=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1347 ##sys#error */
t5=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[286],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7134 in k7128 in k7110 in k7107 in ##sys#load-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[283]+1));
t3=C_mutate((C_word*)lf[283]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7028,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7031,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7062,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7102,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1323 ##sys#repository-path */
t7=*((C_word*)lf[276]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7100 in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7102,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7095,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1324 ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[281]+1),lf[282]);}
else{
t4=t3;
f_7095(2,t4,C_SCHEME_END_OF_LIST);}}

/* k7093 in k7100 in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1323 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7060 in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7062,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7064,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7064(t5,((C_word*)t0)[2],t1);}

/* loop in k7060 in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7064(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7064,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1327 check */
t5=((C_word*)t0)[2];
f_7031(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7075 in loop in k7060 in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1328 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7064(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_7031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7031,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1319 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[280],((C_word*)t0)[2]);}

/* k7033 in check in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7041,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7055,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1320 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,*((C_word*)lf[246]+1));}

/* k7053 in k7033 in check in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1320 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7039 in k7033 in check in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7044(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7051,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1321 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[17]);}}

/* k7049 in k7039 in k7033 in check in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1321 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7042 in k7039 in k7033 in check in ##sys#find-extension in k7023 in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6865,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6868,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6874,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6887,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_6887(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1280 ##sys#symbol->string */
t7=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6970,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_6970(t10,t6,t2);}
else{
t7=t6;
f_6887(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6970(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6970,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[273]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6987,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1287 ##sys#symbol->string */
t5=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_6987(2,t5,t3);}
else{
/* eval.scm: 1289 err */
t5=((C_word*)t0)[2];
f_6868(t5,t4);}}}}

/* k6985 in loop in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6987,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[274]:lf[275]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6995,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1293 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6970(t7,t5,t6);}

/* k6993 in k6985 in loop in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1285 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6885 in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6887,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6892,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6892(t5,((C_word*)t0)[2],t1);}

/* check in k6885 in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6892(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6892,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1296 err */
t5=((C_word*)t0)[4];
f_6868(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_6874(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6918,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1298 ##sys#substring */
t8=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_6874(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6931,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1300 ##sys#substring */
t12=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k6929 in check in k6885 in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1300 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6892(t2,((C_word*)t0)[2],t1);}

/* k6916 in check in k6885 in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1298 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6892(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static C_word C_fcall f_6874(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6868,NULL,2,t0,t1);}
/* eval.scm: 1277 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[271],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6809,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6818,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6818(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6818,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6836,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1265 ##sys#substring */
t6=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6856,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1268 ##sys#substring */
t8=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1269 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6854 in loop in ##sys#split-at-separator in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6856,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1268 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6818(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6834 in loop in ##sys#split-at-separator in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6836,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1265 reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6780r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6780r(t0,t1,t2,t3);}}

static void C_ccall f_6780r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[267]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6787,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1256 ##sys#load-library */
t8=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6785 in load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6795 in k6785 in load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1257 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[267],lf[268],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6674,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6678,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1229 ##sys#->feature-id */
t5=*((C_word*)lf[266]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6678,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6687,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6687(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6770,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1234 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[256]+1));}}}

/* k6768 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6774,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1235 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6772 in k6768 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6774,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6687(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6687,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6752,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1240 ##sys#string->c-identifier */
t6=*((C_word*)lf[265]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6754 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1238 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[263],t1,lf[264]);}

/* k6750 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1237 ##sys#make-c-string */
t2=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6693,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6739,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1242 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6737 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6739,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1243 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[262]);}
else{
t2=((C_word*)t0)[3];
f_6693(2,t2,C_SCHEME_UNDEFINED);}}

/* k6740 in k6737 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1244 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6743 in k6740 in k6737 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1245 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[261]);}

/* k6691 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6693,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6698,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6698(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6691 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6698(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6698,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6711,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6732,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1248 ##sys#make-c-string */
t6=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6730 in loop in k6691 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1248 ##sys#dload */
t2=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6709 in loop in k6691 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6711,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[182]+1)))){
t3=t2;
f_6714(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[182]+1));
t4=C_mutate((C_word*)lf[182]+1,t3);
t5=t2;
f_6714(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1251 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6698(t3,((C_word*)t0)[5],t2);}}

/* k6712 in k6709 in loop in k6691 in k6688 in k6685 in k6676 in ##sys#load-library in k6670 in k6663 in k6658 in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6634r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6634r(t0,t1,t2,t3);}}

static void C_ccall f_6634r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6638,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6655,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[255],t3,t5);}

/* a6654 in load-noisily in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6655,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6636 in load-noisily in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6641,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6652,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[254],((C_word*)t0)[2],t3);}

/* a6651 in k6636 in load-noisily in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6652,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6639 in k6636 in load-noisily in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6644,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6649,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[253],((C_word*)t0)[2],t3);}

/* a6648 in k6639 in k6636 in load-noisily in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6649,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6642 in k6639 in k6636 in load-noisily in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1200 ##sys#load */
t2=*((C_word*)lf[226]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6598r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6598r(t0,t1,t2,t3);}}

static void C_ccall f_6598r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6606,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_6606(2,t6,t2);}
else{
/* eval.scm: 1196 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[212]+1),t2);}}

/* k6604 in load-relative in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 1193 ##sys#load */
t5=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6576r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6576r(t0,t1,t2,t3);}}

static void C_ccall f_6576r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 1190 ##sys#load */
t6=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr5r,(void*)f_6189r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6189r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(23);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6526,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6531,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer731809 */
t10=t9;
f_6531(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer732807 */
t12=t8;
f_6526(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body729734 */
t14=t7;
f_6191(t14,t1,t10,t12);}}}

/* def-timer731 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6531,NULL,2,t0,t1);}
/* def-printer732807 */
t2=((C_word*)t0)[2];
f_6526(t2,t1,C_SCHEME_FALSE);}

/* def-printer732 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6526(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6526,NULL,3,t0,t1,t2);}
/* body729734 */
t3=((C_word*)t0)[2];
f_6191(t3,t1,t2,C_SCHEME_FALSE);}

/* body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6191(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6191,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6525,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1125 ##sys#expand-home-path */
t6=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_6195(t5,C_SCHEME_UNDEFINED);}}

/* k6523 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6195(t3,t2);}

/* k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6195,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6459,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1128 port? */
t6=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}

/* k6457 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6459,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6198(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1130 ##sys#file-info */
t3=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 1121 ##sys#signal-hook */
t3=*((C_word*)lf[220]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[247],lf[232],lf[248],t2);}}}

/* k6472 in k6457 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_6477(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6477(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6477(t3,C_SCHEME_FALSE);}}

/* k6475 in k6472 in k6457 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6477,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6198(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1136 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[246]+1));}}

/* k6478 in k6475 in k6472 in k6457 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1137 ##sys#file-info */
t3=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6484 in k6478 in k6475 in k6472 in k6457 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6486,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6198(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1139 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[17]);}}

/* k6487 in k6484 in k6478 in k6475 in k6472 in k6457 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1140 ##sys#file-info */
t3=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6493 in k6487 in k6484 in k6478 in k6475 in k6472 in k6457 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6198(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6198(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=((C_word*)t0)[17];
t3=(C_truep(t2)?t2:((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1145 ##sys#signal-hook */
t7=*((C_word*)lf[220]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[241],lf[232],lf[242],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6450,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1146 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k6448 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1147 display */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[244]);}
else{
t3=((C_word*)t0)[2];
f_6204(2,t3,C_SCHEME_UNDEFINED);}}

/* k6439 in k6448 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1148 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6442 in k6439 in k6448 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1149 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[243]);}

/* k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6426,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1151 ##sys#make-c-string */
t5=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6207(2,t3,C_SCHEME_FALSE);}}

/* k6424 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1151 ##sys#dload */
t2=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6396 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6207(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1152 has-sep? */
f_6143(t2,((C_word*)t0)[3]);}}

/* k6420 in k6396 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6207(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6418,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1153 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[240],((C_word*)t0)[2]);}}

/* k6416 in k6420 in k6396 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1153 ##sys#make-c-string */
t2=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6412 in k6420 in k6396 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1153 ##sys#dload */
t2=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6210(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1154 call-with-current-continuation */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6215,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6219,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6385,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1160 has-sep? */
f_6143(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6219(2,t8,C_SCHEME_FALSE);}}

/* k6383 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 1161 ##sys#substring */
t3=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6219(2,t2,lf[237]);}}

/* k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6219,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6220,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6229,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6370,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6369 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[227]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[211]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[212]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[210]+1));
t6=C_mutate((C_word*)lf[227]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[211]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[212]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[210]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[228]+1));}

/* a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6247,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1163 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6247(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6252,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6361,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1164 ##sys#dynamic-wind */
t5=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6360 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
/* eval.scm: 1186 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1167 peek-char */
t3=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6355,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6262(2,t4,C_SCHEME_UNDEFINED);}}

/* k6353 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1169 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[232],lf[233],((C_word*)t0)[2],t1);}

/* k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1170 read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6265,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6270(t5,((C_word*)t0)[2],t1);}

/* do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6270(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6270,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1173 printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6280(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1174 ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6325 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6326r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6326r(t0,t1,t2);}}

static void C_ccall f_6326r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6334 in a6325 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6335,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6339,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1183 write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6337 in a6334 in a6325 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1184 newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6291 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6292,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6299,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1177 ##sys#start-timer */
t3=*((C_word*)lf[231]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1178 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6297 in a6291 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6310,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1177 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6309 in k6297 in a6291 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6310r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6310r(t0,t1,t2);}}

static void C_ccall f_6310r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6314,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6321,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1177 ##sys#stop-timer */
t5=*((C_word*)lf[230]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6319 in a6309 in k6297 in a6291 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1177 ##sys#display-times */
t2=*((C_word*)lf[229]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6312 in a6309 in k6297 in a6291 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6303 in k6297 in a6291 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6304,2,t0,t1);}
/* eval.scm: 1177 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6281 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1171 read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6288 in k6281 in k6278 in do782 in k6263 in k6260 in k6257 in a6254 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6270(t2,((C_word*)t0)[2],t1);}

/* a6251 in k6245 in a6242 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6228 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6229,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[227]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[211]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[212]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[210]+1));
t6=C_mutate((C_word*)lf[227]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[211]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[212]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[210]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[228]+1));}

/* f_6220 in k6217 in a6214 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6220,2,t0,t1);}
/* eval.scm: 1162 abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6208 in k6205 in k6202 in k6196 in k6193 in body729 in ##sys#load in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6143(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6143,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6153,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6153(t5,t4));}

/* loop in has-sep? in k6139 in k6059 in k5960 in k1754 in k1712 in k1709 */
static C_word C_fcall f_6153(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6068,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6075,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6080,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6080(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_6080(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6080,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6093,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[216]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6093(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[217]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6093(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[218]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6093(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[219]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6093(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1100 ##sys#signal-hook */
t10=*((C_word*)lf[220]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[214],lf[221],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6091 in loop in set-dynamic-load-mode! in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1101 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6080(t3,((C_word*)t0)[2],t2);}

/* k6073 in set-dynamic-load-mode! in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1102 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6063 in k6059 in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6063,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5979,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5982,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5992,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5992(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_5992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5992,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6006,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1070 reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6025,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 1072 reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 1074 loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 1073 err */
t6=((C_word*)t0)[2];
f_5982(t6,t1);}}}
else{
/* eval.scm: 1071 err */
t6=((C_word*)t0)[2];
f_5982(t6,t1);}}}

/* k6023 in loop in ##sys#decompose-lambda-list in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1072 k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6004 in loop in ##sys#decompose-lambda-list in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1070 k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k5960 in k1754 in k1712 in k1709 */
static void C_fcall f_5982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5982,NULL,2,t0,t1);}
t2=C_set_block_item(lf[207],0,C_SCHEME_FALSE);
/* eval.scm: 1067 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[208],((C_word*)t0)[2]);}

/* eval in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5965r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5965r(t0,t1,t2,t3);}}

static void C_ccall f_5965r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5973,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1055 ##sys#eval-handler */
t5=*((C_word*)lf[204]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5971 in eval in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1056 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5975 in k5971 in eval in k5960 in k1754 in k1712 in k1709 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+37)){
C_save_and_reclaim((void*)tr5r,(void*)f_3726r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3726r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3726r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(37);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3729,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3771,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3883,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3936,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3942,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3948,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3954,a[2]=t9,a[3]=t13,a[4]=t7,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t15,a[8]=t17,a[9]=t12,a[10]=((C_word*)t0)[3],a[11]=t6,tmp=(C_word)a,a+=12,tmp));
t19=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=t15,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t20=(C_word)C_fixnum_greaterp(*((C_word*)lf[134]+1),C_fix(0));
t21=(C_word)C_i_nullp(t5);
t22=(C_truep(t21)?C_SCHEME_FALSE:(C_word)C_u_i_car(t5));
/* eval.scm: 1034 compile */
t23=((C_word*)t15)[1];
f_3954(t23,t1,t2,t3,C_SCHEME_FALSE,t20,t22);}

/* compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_5710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5710,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5714,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 998  compile */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3954(t8,t6,t7,t3,C_SCHEME_FALSE,t4,t5);}

/* k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5714,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5684,tmp=(C_word)a,a+=2,tmp);
t4=f_5684(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 1003 ##sys#syntax-error-hook */
t6=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[203],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5736,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5755,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1007 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3954(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5783,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1011 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3954(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1016 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3954(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1022 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3954(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5903,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1029 ##sys#map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a5926 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5927,3,t0,t1,t2);}
/* eval.scm: 1029 compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3954(t3,t1,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5901 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5904,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5904 in k5901 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5904,3,t0,t1,t2);}
t3=f_3936(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5913 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5919,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1032 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5920 in k5913 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5921,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k5917 in k5913 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5858 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1023 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3954(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5861 in k5858 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1024 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3954(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5864 in k5861 in k5858 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1025 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3954(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(3)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k5867 in k5864 in k5861 in k5858 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5869,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_5870 in k5867 in k5864 in k5861 in k5858 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5870,3,t0,t1,t2);}
t3=f_3936(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5879 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k5883 in k5879 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5887 in k5883 in k5879 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5891 in k5887 in k5883 in k5879 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5896,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5894 in k5891 in k5887 in k5883 in k5879 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5816 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1017 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3954(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5819 in k5816 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 1018 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3954(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5822 in k5819 in k5816 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5824,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_5825 in k5822 in k5819 in k5816 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5825,3,t0,t1,t2);}
t3=f_3936(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5834 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5838 in k5834 */
static void C_ccall f_5840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5842 in k5838 in k5834 */
static void C_ccall f_5844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5847,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5845 in k5842 in k5838 in k5834 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5781 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5786,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1012 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3954(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5784 in k5781 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5786,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_5787 in k5784 in k5781 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5787,3,t0,t1,t2);}
t3=f_3936(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5796 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5800 in k5796 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5805,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5803 in k5800 in k5796 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5753 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5755,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5756,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5756 in k5753 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5756,3,t0,t1,t2);}
t3=f_3936(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5767,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5765 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5770,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5768 in k5765 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5736 in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5736,3,t0,t1,t2);}
t3=f_3936(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5746,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1006 fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5744 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k5712 in compile-call in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static C_word C_fcall f_5684(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3954(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3954,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_symbolp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3966,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 647  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t7,t8);}
else{
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=t4,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[8],a[12]=t6,a[13]=t5,a[14]=((C_word*)t0)[9],a[15]=t1,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 669  ##sys#number? */
t8=*((C_word*)lf[202]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4064,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4072,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4080,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4088,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4101,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4103,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4113(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4113(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_4113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4113,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_3942(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[11],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 688  defined? */
t6=((C_word*)t0)[4];
f_3771(t6,t5,t4,((C_word*)t0)[10]);}
else{
t3=f_3942(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 979  compile-call */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5710(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[10],((C_word*)t0)[13],((C_word*)t0)[12]);}}
else{
/* eval.scm: 684  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[201],((C_word*)t0)[15]);}}}

/* k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 689  compile-call */
t2=((C_word*)((C_word*)t0)[16])[1];
f_5710(t2,((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 690  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3883(t3,t2,((C_word*)t0)[14],((C_word*)t0)[13]);}}

/* k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[121],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[90]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 695  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[90],((C_word*)t0)[15],lf[145],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[146]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
if(C_truep(*((C_word*)lf[125]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 710  ##sys#hash-table-location */
t7=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[125]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4245,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[147]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 715  compile */
t7=((C_word*)((C_word*)t0)[12])[1];
f_3954(t7,((C_word*)t0)[13],t6,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[148]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 718  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_3954(t8,((C_word*)t0)[13],t7,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[110]);
if(C_truep(t7)){
t8=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4279,tmp=(C_word)a,a+=2,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[149]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 723  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[149],((C_word*)t0)[15],lf[151],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[106]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 732  ##sys#check-syntax */
t11=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[106],((C_word*)t0)[15],lf[153],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[69]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[14],lf[71]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 748  ##sys#check-syntax */
t13=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[69],((C_word*)t0)[15],lf[156],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[58]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 772  ##sys#check-syntax */
t14=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[58],((C_word*)t0)[15],lf[158],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 822  ##sys#check-syntax */
t15=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[92],((C_word*)t0)[15],lf[163],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[59]);
if(C_truep(t14)){
t15=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t16=(C_word)C_a_i_cons(&a,2,lf[92],t15);
/* eval.scm: 916  compile */
t17=((C_word*)((C_word*)t0)[12])[1];
f_3954(t17,((C_word*)t0)[13],t16,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[164]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cddr(((C_word*)t0)[15]);
t17=(C_word)C_a_i_cons(&a,2,lf[92],t16);
t18=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 919  compile */
t19=((C_word*)((C_word*)t0)[12])[1];
f_3954(t19,((C_word*)t0)[13],t17,((C_word*)t0)[11],t18,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[165]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5303,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5334,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* map */
t20=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[169]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5358,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5364,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=((C_word*)t21)[1];
f_5364(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[172]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[14],lf[173]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5416,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 941  ##sys#compile-to-closure */
t23=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t23+1)))(6,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t20)){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 945  compile */
t22=((C_word*)((C_word*)t0)[12])[1];
f_3954(t22,((C_word*)t0)[13],t21,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[176]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[14],lf[177]));
if(C_truep(t22)){
/* eval.scm: 948  compile */
t23=((C_word*)((C_word*)t0)[12])[1];
f_3954(t23,((C_word*)t0)[13],lf[178],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[179]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[181],*((C_word*)lf[182]+1)))){
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5465,tmp=(C_word)a,a+=2,tmp);
t26=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* for-each */
t27=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 953  ##sys#warn */
t25=*((C_word*)lf[184]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[185],((C_word*)t0)[15]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[186]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[14],lf[187]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 957  cadadr */
t27=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,((C_word*)t0)[15]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[14],lf[188]);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t26)){
t28=t27;
f_5517(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[14],lf[192]);
if(C_truep(t28)){
t29=t27;
f_5517(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[14],lf[193]);
if(C_truep(t29)){
t30=t27;
f_5517(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[14],lf[194]);
if(C_truep(t30)){
t31=t27;
f_5517(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[14],lf[195]);
if(C_truep(t31)){
t32=t27;
f_5517(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[14],lf[196]);
if(C_truep(t32)){
t33=t27;
f_5517(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[14],lf[197]);
if(C_truep(t33)){
t34=t27;
f_5517(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[14],lf[198]);
if(C_truep(t34)){
t35=t27;
f_5517(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[14],lf[199]);
t36=t27;
f_5517(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[14],lf[200])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 975  compile */
t3=((C_word*)((C_word*)t0)[12])[1];
f_3954(t3,((C_word*)t0)[13],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5515 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_5517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 964  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[189],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[61]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 967  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5710(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[190]);
if(C_truep(t3)){
/* eval.scm: 971  ##sys#syntax-error-hook */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[8],lf[191],((C_word*)t0)[7]);}
else{
/* eval.scm: 973  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5710(t4,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5502 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5504,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[69],t3);
/* eval.scm: 957  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3954(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5464 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5465,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
/* eval.scm: 952  ##compiler#process-declaration */
t4=*((C_word*)lf[183]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k5452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 954  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3954(t2,((C_word*)t0)[5],lf[180],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5414 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5408 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 942  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3954(t2,((C_word*)t0)[5],lf[174],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_5364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5364,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[170]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5376,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 936  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5385 in loop in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5386,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5394,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 937  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5364(t6,t4,t5);}

/* k5392 in a5385 in loop in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[2],t1));}

/* a5375 in loop in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5376,2,t0,t1);}
t2=(C_word)C_u_i_cadar(((C_word*)t0)[2]);
/* eval.scm: 936  ##sys#do-the-right-thing */
t3=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* k5356 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 932  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3954(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5333 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5341,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 922  ##sys#compile-to-closure */
t4=*((C_word*)lf[139]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5339 in a5333 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5301 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5306,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_apply(4,0,t2,*((C_word*)lf[167]+1),t1);}

/* k5304 in k5301 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 924  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[168]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5307 in k5304 in k5301 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5316(t3,lf[166]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5326,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5328,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5327 in k5307 in k5304 in k5301 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5328,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k5324 in k5307 in k5304 in k5301 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5316(t2,(C_word)C_a_i_cons(&a,2,lf[167],t1));}

/* k5314 in k5307 in k5304 in k5301 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_5316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 925  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3954(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[8];
t9=(C_truep(t8)?t8:lf[159]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4913,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=t10,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5238,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 826  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5236 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5238,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 827  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4913(2,t2,C_SCHEME_UNDEFINED);}}

/* a5248 in k5236 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5249,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5242 in k5236 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5243,2,t0,t1);}
/* eval.scm: 829  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[56]+1));}

/* k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 832  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4918,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5227,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[6];
t10=(C_truep(t9)?t9:((C_word*)t0)[5]);
/* eval.scm: 838  ##sys#canonicalize-body */
t11=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4],t10);}

/* a5226 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5227,3,t0,t1,t2);}
/* defined?306 */
t3=((C_word*)t0)[3];
f_3771(t3,t1,t2,((C_word*)t0)[2]);}

/* k5219 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 837  ##sys#compile-to-closure */
t4=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[86],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5183 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5183,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 907  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5188 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5189r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5189r(t0,t1,t2);}}

static void C_ccall f_5189r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5213,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[160]+1),t2);}
else{
/* eval.scm: 911  ##sys#error */
t5=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[161],((C_word*)t0)[4],t3);}}

/* k5211 in a5188 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5213,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5160 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5160,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 900  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5165 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr2r,(void*)f_5166r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5166r(t0,t1,t2);}}

static void C_ccall f_5166r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(17);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5178,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5182,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5182(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5651,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5651(t9,t4,t5,t2,C_SCHEME_FALSE);}}

/* do596 in a5165 */
static void C_fcall f_5651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5651,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,1,t3);
t7=(C_word)C_i_setslot(t4,C_fix(1),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
t11=t1;
t12=t6;
t13=t7;
t14=t3;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k5180 in a5165 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[160]+1),t1);}

/* k5176 in a5165 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5178,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5138 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5138,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 893  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5143 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5144,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 895  ##sys#vector */
t7=*((C_word*)lf[160]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5154 in a5143 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5119 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5119,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 888  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5124 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5125r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5125r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5125r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5091 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5091,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 882  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5096 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5097,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5072 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5072,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 877  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5077 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5078r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5078r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5078r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5044 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5044,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 871  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5049 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5050,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5025 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5025,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5031,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 866  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5030 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5031r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5031r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4997 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4997,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 860  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5002 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5003,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_4978 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4978,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 855  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4983 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_4984r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4984r(t0,t1,t2,t3);}}

static void C_ccall f_4984r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4954 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4954,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 850  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4959 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_4935 in k4923 in a4917 in k4911 in k4899 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4935,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4941,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 845  decorate */
f_3948(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4940 */
static void C_ccall f_4941(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4941r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4941r(t0,t1,t2);}}

static void C_ccall f_4941r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[10]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4888,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4887 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4888,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4882,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 778  ##sys#canonicalize-body */
t7=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,((C_word*)t0)[4],((C_word*)t0)[6]);}

/* a4881 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4882,3,t0,t1,t2);}
/* defined?306 */
t3=((C_word*)t0)[3];
f_3771(t3,t1,t2,((C_word*)t0)[2]);}

/* k4874 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 777  ##sys#compile-to-closure */
t2=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 783  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3954(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 786  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3954(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 790  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3954(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 798  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3954(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4859 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4860,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 812  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3954(t5,t1,t3,((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4811 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4814,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4814 in k4811 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4814,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 814  ##sys#make-vector */
t4=*((C_word*)lf[157]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4816 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4821,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4830(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do478 in k4816 */
static void C_fcall f_4830(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4830,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4855,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4853 in do478 in k4816 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4830(t5,((C_word*)t0)[2],t3,t4);}

/* k4819 in k4816 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4735 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 799  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4796 in k4735 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 799  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3954(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4738 in k4735 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4740,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4746,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 801  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3954(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4744 in k4738 in k4735 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4749,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 802  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4780 in k4744 in k4738 in k4735 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 802  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3954(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4747 in k4744 in k4738 in k4735 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4749,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4750 in k4747 in k4744 in k4738 in k4735 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4750,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4764 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4768 in k4764 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4772 in k4768 in k4764 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4776 in k4772 in k4768 in k4764 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4668 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 791  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4714 in k4668 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 791  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3954(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4671 in k4668 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4673,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 793  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3954(t6,t3,t4,((C_word*)t0)[4],t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4677 in k4671 in k4668 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4679,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4680 in k4677 in k4671 in k4668 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4680,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4694 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4698 in k4694 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4702 in k4698 in k4694 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4619 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4624,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 787  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4647 in k4619 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 787  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3954(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4622 in k4619 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4625 in k4622 in k4619 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4625,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4639 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4643 in k4639 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4585 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4588 in k4585 in k4576 in k4570 in k4561 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4604,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4602 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4468,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 751  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3954(t6,t4,t5,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4529,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4542,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4481,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 753  ##sys#alias-global-hook */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k4479 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
if(C_truep(*((C_word*)lf[125]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4487,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 755  ##sys#hash-table-location */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[125]+1),t1,*((C_word*)lf[126]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4514 in k4479 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4514,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4522,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4520 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4485 in k4479 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4490(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 759  ##sys#error */
t3=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[155],((C_word*)t0)[2]);}}

/* k4488 in k4485 in k4479 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4506 in k4488 in k4485 in k4479 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4506,2,t0,t1);}
/* eval.scm: 762  ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[154],((C_word*)t0)[2]);}

/* f_4497 in k4488 in k4485 in k4479 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4497,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4503 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4542 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4542,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4548 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4529 in k4470 in a4467 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4529,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4539 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4461 in k4452 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
/* eval.scm: 750  lookup */
f_3729(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 736  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3954(t4,((C_word*)t0)[5],lf[152],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 737  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3954(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 738  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3954(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 742  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3954(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4403 in k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 743  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3954(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4406 in k4403 in k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,lf[106],t4);
/* eval.scm: 744  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3954(t6,t2,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4409 in k4406 in k4403 in k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4412 in k4409 in k4406 in k4403 in k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4414 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4417 in k4414 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4381 in k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4386,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 739  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3954(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4384 in k4381 in k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4387 in k4384 in k4381 in k4344 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4387,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4391,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4389 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4287 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 724  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3954(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4290 in k4287 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 725  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3954(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4293 in k4290 in k4287 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4298,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[6]);
/* eval.scm: 727  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3954(t5,t2,t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 728  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3954(t4,t2,lf[150],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4296 in k4293 in k4290 in k4287 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4299 in k4296 in k4293 in k4290 in k4287 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4299,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4304 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4279 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4279,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4245 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4237 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4240,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4240 in k4237 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4173,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4181,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4189,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4197,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4205,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4213,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4221,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4223,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4223 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4221 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4213 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4205 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4197 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4189 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4181 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4181(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4181,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4173 in k4161 in k4146 in k4140 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4173,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4114 in k4111 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4103 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4103,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4101 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4090 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4088 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4080 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4072 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4064 in k4055 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3972,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4047,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 649  ##sys#alias-global-hook */
t6=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
if(C_truep(*((C_word*)lf[125]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3988,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 651  ##sys#hash-table-location */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[125]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4011,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4016,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[133]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4031,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 664  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[144]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_4016(t4,C_SCHEME_FALSE);}}}

/* k4029 in k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4016(t2,(C_word)C_i_not(t1));}

/* k4014 in k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_4016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[133]+1));
t4=C_mutate((C_word*)lf[133]+1,t3);
t5=((C_word*)t0)[2];
f_4011(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_4011(t2,C_SCHEME_UNDEFINED);}}

/* k4009 in k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_4011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4011,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_4012 in k4009 in k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3986 in k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3991(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 652  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[143],((C_word*)t0)[2]);}}

/* k3989 in k3986 in k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_3992 in k3989 in k3986 in k3980 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 659  ##sys#error */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[142],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4047 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4047,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4038 in a3971 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4038,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3965 in compile in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
/* eval.scm: 647  lookup */
f_3729(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3948(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3948,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 643  ##sys#eval-decorator */
t6=*((C_word*)lf[127]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static C_word C_fcall f_3942(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[140]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static C_word C_fcall f_3936(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[140]+1)):C_SCHEME_UNDEFINED));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3883,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 623  ##sys#macroexpand-1-local */
t5=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}

/* k3885 in macroexpand-1-checked in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,lf[58]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3934,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 626  defined? */
t6=((C_word*)t0)[2];
f_3771(t6,t5,lf[58],((C_word*)t0)[3]);}
else{
t5=t3;
f_3902(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3932 in k3885 in macroexpand-1-checked in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3902(t2,(C_word)C_i_not(t1));}

/* k3900 in k3885 in macroexpand-1-checked in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3902,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_3911(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_3911(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k3909 in k3900 in k3885 in macroexpand-1-checked in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 629  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3883(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* defined? in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3771(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3771,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3777,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3783,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3782 in defined? in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3783,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3776 in defined? in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3777,2,t0,t1);}
/* eval.scm: 598  lookup */
f_3729(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3729(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3729,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3735,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3735(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3735,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 593  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3853(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 594  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 595  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1754 in k1712 in k1709 */
static C_word C_fcall f_3853(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#alias-global-hook in k1754 in k1712 in k1709 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3720,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#eval-decorator in k1754 in k1712 in k1709 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3679,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3685,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3698,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 563  ##sys#decorate-lambda */
t8=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3697 in ##sys#eval-decorator in k1754 in k1712 in k1709 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3698,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3706,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3710,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 570  open-output-string */
t6=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3708 in a3697 in ##sys#eval-decorator in k1754 in k1712 in k1709 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 571  write */
t3=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3711 in k3708 in a3697 in ##sys#eval-decorator in k1754 in k1712 in k1709 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 572  get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3714 in k3711 in k3708 in a3697 in ##sys#eval-decorator in k1754 in k1712 in k1709 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 569  ##sys#make-lambda-info */
t2=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3704 in a3697 in ##sys#eval-decorator in k1754 in k1712 in k1709 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3684 in ##sys#eval-decorator in k1754 in k1712 in k1709 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3685,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k1754 in k1712 in k1709 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3619,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3623,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 543  ##sys#hash-symbol */
t7=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3621 in ##sys#hash-table-location in k1754 in k1712 in k1709 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3631,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3631(t6,((C_word*)t0)[2],t2);}

/* loop in k3621 in ##sys#hash-table-location in k1754 in k1712 in k1709 */
static void C_fcall f_3631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3631,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 554  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k1754 in k1712 in k1709 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3573,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3579,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3579(t8,t1,C_fix(0));}

/* do263 in ##sys#hash-table-for-each in k1754 in k1712 in k1709 */
static void C_fcall f_3579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3579,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3589,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 535  ##sys#for-each */
t6=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3597 in do263 in ##sys#hash-table-for-each in k1754 in k1712 in k1709 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3598,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 536  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3587 in do263 in ##sys#hash-table-for-each in k1754 in k1712 in k1709 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3579(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-set! in k1754 in k1712 in k1709 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3518,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3522,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 521  ##sys#hash-symbol */
t6=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3520 in ##sys#hash-table-set! in k1754 in k1712 in k1709 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3530,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3530(t6,((C_word*)t0)[2],t2);}

/* loop in k3520 in ##sys#hash-table-set! in k1754 in k1712 in k1709 */
static void C_fcall f_3530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3530,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 529  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1754 in k1712 in k1709 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3473,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3477,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 510  ##sys#hash-symbol */
t5=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3475 in ##sys#hash-table-ref in k1754 in k1712 in k1709 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3486(t3,t2));}

/* loop in k3475 in ##sys#hash-table-ref in k1754 in k1712 in k1709 */
static C_word C_fcall f_3486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1754 in k1712 in k1709 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3458,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1754 in k1712 in k1709 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3398,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3401,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3453,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 492  loop */
t10=((C_word*)t7)[1];
f_3401(t10,t9,t2,t3);}

/* k3451 in ##sys#expand-curried-define in k1754 in k1712 in k1709 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1754 in k1712 in k1709 */
static void C_fcall f_3401(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3401,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[92],t8));}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,lf[92],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* eval.scm: 491  loop */
t15=t1;
t16=t5;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* ##sys#match-expression in k1754 in k1712 in k1709 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3307,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3310,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3396,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 479  mwalk */
t11=((C_word*)t8)[1];
f_3310(t11,t10,t2,t3);}

/* k3394 in ##sys#match-expression in k1754 in k1712 in k1709 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1754 in k1712 in k1709 */
static void C_fcall f_3310(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3310,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_u_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_u_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3365,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 476  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3363 in mwalk in ##sys#match-expression in k1754 in k1712 in k1709 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 477  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3310(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2824r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2824r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2826,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-me154207 */
t8=t7;
f_3262(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-container155205 */
t10=t6;
f_3257(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body152157 */
t12=t5;
f_2826(t12,t1,t8);}}}

/* def-me154 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_3262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3262,NULL,2,t0,t1);}
/* def-container155205 */
t2=((C_word*)t0)[2];
f_3257(t2,t1,C_SCHEME_FALSE);}

/* def-container155 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_3257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3257,NULL,3,t0,t1,t2);}
/* body152157 */
t3=((C_word*)t0)[2];
f_2826(t3,t1,t2);}

/* body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_2826(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2826,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
/* eval.scm: 460  expand */
t9=((C_word*)t6)[1];
f_3009(t9,t1,((C_word*)t0)[2]);}

/* expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_3009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3009,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3015(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_3015(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3015,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 426  lookup */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t10);}
else{
t12=t11;
f_3049(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 425  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2829(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 421  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2829(t7,t1,t3,t4,t5,t6,t2);}}

/* k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 427  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2829(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[107],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 429  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[107],((C_word*)t0)[3],lf[116],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[108],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 450  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[108],((C_word*)t0)[3],lf[117],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[106],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 453  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[106],((C_word*)t0)[3],lf[118],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 456  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3219 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3221,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 458  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2829(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 459  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3015(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3205 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 454  ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3212 in k3205 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 454  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3015(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3177 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 451  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3015(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k3059 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3066(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k3059 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_3066(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3066,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3113,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 441  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[112],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 444  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[113],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 433  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[107],t2,lf[115],C_SCHEME_FALSE);}}

/* k3077 in loop2 in k3059 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_caddr(((C_word*)t0)[8]):lf[114]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 434  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3015(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3129 in loop2 in k3059 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[7]);
/* eval.scm: 445  loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3015(t9,((C_word*)t0)[5],((C_word*)t0)[4],t3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3111 in loop2 in k3059 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 442  ##sys#expand-curried-define */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3122 in k3111 in loop2 in k3059 in k3047 in loop in expand in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],t1);
/* eval.scm: 442  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3066(t3,((C_word*)t0)[2],t2);}

/* fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_2829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2829,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2841,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2841(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2911,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 405  reverse */
t10=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}

/* k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2989,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3001,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[88]+1),t1,((C_word*)t0)[3]);}

/* k2999 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 406  ##sys#map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2988 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2989,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[110]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2979,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 408  reverse */
t6=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2985 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 408  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2978 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2979,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2934,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 415  reverse */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2971 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2977,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 416  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2975 in k2971 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 409  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2939 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2940,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2944,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 410  ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[83]+1),t2);}

/* k2942 in a2939 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2963,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2965,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 414  map */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2964 in k2942 in a2939 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2965,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2961 in k2942 in a2939 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[92],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k2936 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2932 in k2928 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2924 in k2920 in k2909 in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* loop in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2841,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[107],lf[108]);
t8=t5;
f_2860(t8,(C_word)C_u_i_memq(t6,t7));}
else{
t6=t5;
f_2860(t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[106],((C_word*)t0)[2]));}}

/* k2858 in loop in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_fcall f_2860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2860,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 403  reverse */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 404  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2841(t4,((C_word*)t0)[8],t2,t3);}}

/* k2869 in k2858 in loop in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2879,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 403  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3009(t3,t2,((C_word*)t0)[2]);}

/* k2877 in k2869 in k2858 in loop in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 403  ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2865 in k2858 in loop in fini in body152 in ##sys#canonicalize-body in k1754 in k1712 in k1709 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2305,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2308,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_2327(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2327,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 321  reverse */
t9=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
/* eval.scm: 321  reverse */
t8=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 344  err */
t7=((C_word*)t0)[4];
f_2308(t7,t1,lf[94]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2571,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2571(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2571(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[80]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2603(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2622,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 356  gensym */
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[79]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2640(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2640(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 368  err */
t11=((C_word*)t0)[4];
f_2308(t11,t1,lf[97]);}}
else{
t11=(C_word)C_eqp(t7,lf[81]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2686(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2705,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 370  gensym */
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 377  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 378  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 379  err */
t13=((C_word*)t0)[4];
f_2308(t13,t1,lf[99]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 380  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2767,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2767(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2767(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 350  err */
t7=((C_word*)t0)[4];
f_2308(t7,t1,lf[103]);}}}}

/* k2765 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 383  err */
t3=((C_word*)t0)[9];
f_2308(t3,((C_word*)t0)[8],lf[100]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 384  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2327(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 385  err */
t3=((C_word*)t0)[9];
f_2308(t3,((C_word*)t0)[8],lf[101]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 386  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2327(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 387  err */
t2=((C_word*)t0)[9];
f_2308(t2,((C_word*)t0)[8],lf[102]);}}

/* k2703 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2686(t3,t2);}

/* k2684 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 372  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2327(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 373  err */
t2=((C_word*)t0)[2];
f_2308(t2,((C_word*)t0)[6],lf[98]);}}

/* k2638 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2640,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2643(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2643(t6,t5);}}
else{
/* eval.scm: 367  err */
t2=((C_word*)t0)[2];
f_2308(t2,((C_word*)t0)[6],lf[96]);}}

/* k2641 in k2638 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 366  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2327(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2620 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2603(t3,t2);}

/* k2601 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 358  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2327(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 359  err */
t3=((C_word*)t0)[2];
f_2308(t3,((C_word*)t0)[5],lf[95]);}}

/* k2569 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 348  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2327(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2548 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 321  ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2345(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2484,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 332  reverse */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}}

/* k2541 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2485 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2486,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2539,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 311  string->keyword */
t6=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2537 in a2485 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2539,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=t3;
f_2513(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t5=t3;
f_2513(t5,C_SCHEME_END_OF_LIST);}}

/* k2511 in k2537 in a2485 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2513,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t4));}

/* k2482 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[89],t2);
t4=((C_word*)t0)[2];
f_2345(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2343 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2345,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2348(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2357(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=t3;
f_2357(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2357(t5,C_SCHEME_FALSE);}}}}

/* k2355 in k2343 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2357,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(((C_word*)t0)[8]);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[85],((C_word*)((C_word*)t0)[7])[1],t3);
t5=(C_word)C_a_i_list(&a,2,t2,t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,lf[58],t7);
t9=((C_word*)t0)[5];
f_2348(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 338  reverse */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2432,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2436,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 340  reverse */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[8]);}}}

/* k2434 in k2355 in k2343 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 340  ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2430 in k2355 in k2343 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[87],t3);
t5=((C_word*)t0)[2];
f_2348(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2411 in k2355 in k2343 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[86],t3);
t5=((C_word*)t0)[2];
f_2348(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2346 in k2343 in k2339 in loop in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 320  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1754 in k1712 in k1709 */
static void C_fcall f_2308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2308,NULL,3,t0,t1,t2);}
/* eval.scm: 310  errh */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1754 in k1712 in k1709 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2262,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2268(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1754 in k1712 in k1709 */
static void C_fcall f_2268(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2268,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[79]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2287(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[80]);
t7=t5;
f_2287(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[81])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2285 in loop in ##sys#extended-lambda-list? in k1754 in k1712 in k1709 */
static void C_fcall f_2287(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 304  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2268(t3,((C_word*)t0)[4],t2);}}

/* macroexpand-1 in k1754 in k1712 in k1709 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2246r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2246r(t0,t1,t2,t3);}}

static void C_ccall f_2246r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 284  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t5);}

/* macroexpand in k1754 in k1712 in k1709 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2210r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2210r(t0,t1,t2,t3);}}

static void C_ccall f_2210r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2219,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2219(t9,t1,t2);}

/* loop in macroexpand in k1754 in k1712 in k1709 */
static void C_fcall f_2219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2219,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2230 in loop in macroexpand in k1754 in k1712 in k1709 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2231,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 280  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2219(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2224 in loop in macroexpand in k1754 in k1712 in k1709 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
/* eval.scm: 278  ##sys#macroexpand-0 */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1754 in k1712 in k1709 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2203,4,t0,t1,t2,t3);}
/* eval.scm: 265  ##sys#macroexpand-0 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1754 in k1712 in k1709 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2200,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1754 in k1712 in k1709 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2197,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1827,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[58]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2064,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 234  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[58],t7,lf[66]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2137,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_2137(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_2137(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_2137(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 257  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 258  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k2135 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_2137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2137,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 250  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[69],((C_word*)t0)[6],lf[70]);}
else{
/* eval.scm: 256  expand */
t2=((C_word*)t0)[4];
f_1976(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2141 in k2135 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 252  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t2,t5,t6,t7);}

/* k2148 in k2141 in k2135 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 251  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2062 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 237  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[58],((C_word*)t0)[4],lf[65]);}
else{
/* eval.scm: 245  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2074 in k2062 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2118,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2124,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a2123 in k2074 in k2062 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2124,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k2116 in k2074 in k2062 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2118,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[59],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[60],t6,((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 243  ##sys#map */
t9=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k2096 in k2116 in k2074 in k2062 in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
/* eval.scm: 239  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_1976(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1976,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1990,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1996,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 218  ##sys#hash-table-ref */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[37]+1),t3);}}

/* k1994 in expand in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2004,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2004(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* eval.scm: 227  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* scan in k1994 in expand in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_2004(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2004,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 224  call-handler */
t4=((C_word*)t0)[6];
f_1830(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 225  scan */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
/* eval.scm: 226  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[57],((C_word*)t0)[3]);}}}

/* k2016 in scan in k1994 in expand in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 224  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k1988 in expand in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 217  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_1830(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1830,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1839,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1845,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1952,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1951 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1963 in a1951 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1964r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1964r(t0,t1,t2);}}

static void C_ccall f_1964r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1969 in a1963 in a1951 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1957 in a1951 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
/* eval.scm: 214  handler */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1845,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1850 in a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[48]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1862(t5,(C_word)C_i_memv(lf[53],t4));}
else{
t4=t3;
f_1862(t4,C_SCHEME_FALSE);}}

/* k1860 in a1850 in a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_1862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1862,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1873,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1879,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1879(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1859(t2,((C_word*)t0)[5]);}}

/* copy in k1860 in a1850 in a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_1879(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1879,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_equalp(lf[52],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_u_i_car(t4);
t7=t5;
f_1898(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_1898(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_1898(t6,C_SCHEME_FALSE);}}}

/* k1896 in copy in k1860 in a1850 in a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_1898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1898,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 208  string-append */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[50],t3,lf[51],t4);}
else{
/* eval.scm: 212  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1879(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1907 in k1896 in copy in k1860 in a1850 in a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k1871 in k1860 in a1850 in a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1859(t2,(C_word)C_a_i_record(&a,3,lf[48],((C_word*)t0)[2],t1));}

/* k1857 in a1850 in a1844 in a1838 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_fcall f_1859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 192  ##sys#abort */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1835 in call-handler in ##sys#macroexpand-0 in k1754 in k1712 in k1709 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1754 in k1712 in k1709 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1818,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[44]);
t4=t2;
/* eval.scm: 177  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t4,C_SCHEME_FALSE);}

/* macro? in k1754 in k1712 in k1709 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[43]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 174  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1808 in macro? in k1754 in k1712 in k1709 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#copy-macro in k1754 in k1712 in k1709 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1790,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1798,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 170  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1796 in ##sys#copy-macro in k1754 in k1712 in k1709 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 170  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* ##sys#register-macro in k1754 in k1712 in k1709 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1774,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 165  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1779 in ##sys#register-macro in k1754 in k1712 in k1709 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1780,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1754 in k1712 in k1709 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1758,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1764,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 159  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1763 in ##sys#register-macro-2 in k1754 in k1712 in k1709 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1764,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 161  handler */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* chicken-home in k1712 in k1709 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 150  ##sys#chicken-prefix */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[36]);}

/* k1744 in chicken-home in k1712 in k1709 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k1712 in k1709 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1715r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1715r(t0,t1,t2);}}

static void C_ccall f_1715r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 142  ##sys#string-append */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[930] = {
{"topleveleval.scm",(void*)C_eval_toplevel},
{"f_1711eval.scm",(void*)f_1711},
{"f_1714eval.scm",(void*)f_1714},
{"f_1756eval.scm",(void*)f_1756},
{"f_11348eval.scm",(void*)f_11348},
{"f_11352eval.scm",(void*)f_11352},
{"f_11376eval.scm",(void*)f_11376},
{"f_11370eval.scm",(void*)f_11370},
{"f_11360eval.scm",(void*)f_11360},
{"f_11358eval.scm",(void*)f_11358},
{"f_5962eval.scm",(void*)f_5962},
{"f_6061eval.scm",(void*)f_6061},
{"f_6141eval.scm",(void*)f_6141},
{"f_11342eval.scm",(void*)f_11342},
{"f_11338eval.scm",(void*)f_11338},
{"f_11334eval.scm",(void*)f_11334},
{"f_11330eval.scm",(void*)f_11330},
{"f_11320eval.scm",(void*)f_11320},
{"f_6660eval.scm",(void*)f_6660},
{"f_6665eval.scm",(void*)f_6665},
{"f_11298eval.scm",(void*)f_11298},
{"f_11290eval.scm",(void*)f_11290},
{"f_11292eval.scm",(void*)f_11292},
{"f_6672eval.scm",(void*)f_6672},
{"f_11259eval.scm",(void*)f_11259},
{"f_11279eval.scm",(void*)f_11279},
{"f_11275eval.scm",(void*)f_11275},
{"f_11265eval.scm",(void*)f_11265},
{"f_11262eval.scm",(void*)f_11262},
{"f_7025eval.scm",(void*)f_7025},
{"f_11205eval.scm",(void*)f_11205},
{"f_11219eval.scm",(void*)f_11219},
{"f_11255eval.scm",(void*)f_11255},
{"f_11251eval.scm",(void*)f_11251},
{"f_11239eval.scm",(void*)f_11239},
{"f_11243eval.scm",(void*)f_11243},
{"f_11213eval.scm",(void*)f_11213},
{"f_7744eval.scm",(void*)f_7744},
{"f_11084eval.scm",(void*)f_11084},
{"f_11121eval.scm",(void*)f_11121},
{"f_11130eval.scm",(void*)f_11130},
{"f_11149eval.scm",(void*)f_11149},
{"f_11153eval.scm",(void*)f_11153},
{"f_11139eval.scm",(void*)f_11139},
{"f_11136eval.scm",(void*)f_11136},
{"f_11087eval.scm",(void*)f_11087},
{"f_7747eval.scm",(void*)f_7747},
{"f_7805eval.scm",(void*)f_7805},
{"f_11082eval.scm",(void*)f_11082},
{"f_8140eval.scm",(void*)f_8140},
{"f_8144eval.scm",(void*)f_8144},
{"f_11078eval.scm",(void*)f_11078},
{"f_8147eval.scm",(void*)f_8147},
{"f_8151eval.scm",(void*)f_8151},
{"f_10981eval.scm",(void*)f_10981},
{"f_10987eval.scm",(void*)f_10987},
{"f_11003eval.scm",(void*)f_11003},
{"f_11006eval.scm",(void*)f_11006},
{"f_11041eval.scm",(void*)f_11041},
{"f_11044eval.scm",(void*)f_11044},
{"f_11028eval.scm",(void*)f_11028},
{"f_11031eval.scm",(void*)f_11031},
{"f_11038eval.scm",(void*)f_11038},
{"f_8834eval.scm",(void*)f_8834},
{"f_10953eval.scm",(void*)f_10953},
{"f_8837eval.scm",(void*)f_8837},
{"f_10910eval.scm",(void*)f_10910},
{"f_10932eval.scm",(void*)f_10932},
{"f_8840eval.scm",(void*)f_8840},
{"f_10713eval.scm",(void*)f_10713},
{"f_10719eval.scm",(void*)f_10719},
{"f_10735eval.scm",(void*)f_10735},
{"f_10811eval.scm",(void*)f_10811},
{"f_10868eval.scm",(void*)f_10868},
{"f_10814eval.scm",(void*)f_10814},
{"f_10841eval.scm",(void*)f_10841},
{"f_10774eval.scm",(void*)f_10774},
{"f_10793eval.scm",(void*)f_10793},
{"f_10765eval.scm",(void*)f_10765},
{"f_8843eval.scm",(void*)f_8843},
{"f_10610eval.scm",(void*)f_10610},
{"f_10620eval.scm",(void*)f_10620},
{"f_10633eval.scm",(void*)f_10633},
{"f_10649eval.scm",(void*)f_10649},
{"f_10687eval.scm",(void*)f_10687},
{"f_10685eval.scm",(void*)f_10685},
{"f_10677eval.scm",(void*)f_10677},
{"f_10631eval.scm",(void*)f_10631},
{"f_8846eval.scm",(void*)f_8846},
{"f_10557eval.scm",(void*)f_10557},
{"f_10567eval.scm",(void*)f_10567},
{"f_10570eval.scm",(void*)f_10570},
{"f_10575eval.scm",(void*)f_10575},
{"f_10600eval.scm",(void*)f_10600},
{"f_8849eval.scm",(void*)f_8849},
{"f_10487eval.scm",(void*)f_10487},
{"f_10497eval.scm",(void*)f_10497},
{"f_10500eval.scm",(void*)f_10500},
{"f_10547eval.scm",(void*)f_10547},
{"f_10511eval.scm",(void*)f_10511},
{"f_10533eval.scm",(void*)f_10533},
{"f_10519eval.scm",(void*)f_10519},
{"f_10515eval.scm",(void*)f_10515},
{"f_8852eval.scm",(void*)f_8852},
{"f_10368eval.scm",(void*)f_10368},
{"f_10372eval.scm",(void*)f_10372},
{"f_10375eval.scm",(void*)f_10375},
{"f_10378eval.scm",(void*)f_10378},
{"f_10469eval.scm",(void*)f_10469},
{"f_10385eval.scm",(void*)f_10385},
{"f_10408eval.scm",(void*)f_10408},
{"f_10422eval.scm",(void*)f_10422},
{"f_10420eval.scm",(void*)f_10420},
{"f_8855eval.scm",(void*)f_8855},
{"f_10076eval.scm",(void*)f_10076},
{"f_10286eval.scm",(void*)f_10286},
{"f_10290eval.scm",(void*)f_10290},
{"f_10311eval.scm",(void*)f_10311},
{"f_10353eval.scm",(void*)f_10353},
{"f_10089eval.scm",(void*)f_10089},
{"f_10277eval.scm",(void*)f_10277},
{"f_10281eval.scm",(void*)f_10281},
{"f_10260eval.scm",(void*)f_10260},
{"f_10264eval.scm",(void*)f_10264},
{"f_10249eval.scm",(void*)f_10249},
{"f_10241eval.scm",(void*)f_10241},
{"f_10230eval.scm",(void*)f_10230},
{"f_10196eval.scm",(void*)f_10196},
{"f_10177eval.scm",(void*)f_10177},
{"f_10150eval.scm",(void*)f_10150},
{"f_10107eval.scm",(void*)f_10107},
{"f_10103eval.scm",(void*)f_10103},
{"f_10079eval.scm",(void*)f_10079},
{"f_10087eval.scm",(void*)f_10087},
{"f_8858eval.scm",(void*)f_8858},
{"f_10066eval.scm",(void*)f_10066},
{"f_8861eval.scm",(void*)f_8861},
{"f_9820eval.scm",(void*)f_9820},
{"f_9975eval.scm",(void*)f_9975},
{"f_10046eval.scm",(void*)f_10046},
{"f_9991eval.scm",(void*)f_9991},
{"f_9989eval.scm",(void*)f_9989},
{"f_9833eval.scm",(void*)f_9833},
{"f_9959eval.scm",(void*)f_9959},
{"f_9921eval.scm",(void*)f_9921},
{"f_9882eval.scm",(void*)f_9882},
{"f_9823eval.scm",(void*)f_9823},
{"f_8864eval.scm",(void*)f_8864},
{"f_8868eval.scm",(void*)f_8868},
{"f_9817eval.scm",(void*)f_9817},
{"f_8890eval.scm",(void*)f_8890},
{"f_9250eval.scm",(void*)f_9250},
{"f_9675eval.scm",(void*)f_9675},
{"f_9793eval.scm",(void*)f_9793},
{"f_9796eval.scm",(void*)f_9796},
{"f_9783eval.scm",(void*)f_9783},
{"f_9678eval.scm",(void*)f_9678},
{"f_9682eval.scm",(void*)f_9682},
{"f_9693eval.scm",(void*)f_9693},
{"f_9336eval.scm",(void*)f_9336},
{"f_9656eval.scm",(void*)f_9656},
{"f_9660eval.scm",(void*)f_9660},
{"f_9669eval.scm",(void*)f_9669},
{"f_9667eval.scm",(void*)f_9667},
{"f_9339eval.scm",(void*)f_9339},
{"f_9650eval.scm",(void*)f_9650},
{"f_9342eval.scm",(void*)f_9342},
{"f_9644eval.scm",(void*)f_9644},
{"f_9345eval.scm",(void*)f_9345},
{"f_9635eval.scm",(void*)f_9635},
{"f_9642eval.scm",(void*)f_9642},
{"f_9625eval.scm",(void*)f_9625},
{"f_9610eval.scm",(void*)f_9610},
{"f_9614eval.scm",(void*)f_9614},
{"f_9619eval.scm",(void*)f_9619},
{"f_9623eval.scm",(void*)f_9623},
{"f_9588eval.scm",(void*)f_9588},
{"f_9592eval.scm",(void*)f_9592},
{"f_9597eval.scm",(void*)f_9597},
{"f_9601eval.scm",(void*)f_9601},
{"f_9608eval.scm",(void*)f_9608},
{"f_9562eval.scm",(void*)f_9562},
{"f_9568eval.scm",(void*)f_9568},
{"f_9572eval.scm",(void*)f_9572},
{"f_9586eval.scm",(void*)f_9586},
{"f_9575eval.scm",(void*)f_9575},
{"f_9582eval.scm",(void*)f_9582},
{"f_9546eval.scm",(void*)f_9546},
{"f_9552eval.scm",(void*)f_9552},
{"f_9560eval.scm",(void*)f_9560},
{"f_9509eval.scm",(void*)f_9509},
{"f_9513eval.scm",(void*)f_9513},
{"f_9518eval.scm",(void*)f_9518},
{"f_9522eval.scm",(void*)f_9522},
{"f_9544eval.scm",(void*)f_9544},
{"f_9540eval.scm",(void*)f_9540},
{"f_9536eval.scm",(void*)f_9536},
{"f_9525eval.scm",(void*)f_9525},
{"f_9532eval.scm",(void*)f_9532},
{"f_9483eval.scm",(void*)f_9483},
{"f_9489eval.scm",(void*)f_9489},
{"f_9493eval.scm",(void*)f_9493},
{"f_9507eval.scm",(void*)f_9507},
{"f_9496eval.scm",(void*)f_9496},
{"f_9503eval.scm",(void*)f_9503},
{"f_9470eval.scm",(void*)f_9470},
{"f_9444eval.scm",(void*)f_9444},
{"f_9448eval.scm",(void*)f_9448},
{"f_9453eval.scm",(void*)f_9453},
{"f_9457eval.scm",(void*)f_9457},
{"f_9468eval.scm",(void*)f_9468},
{"f_9464eval.scm",(void*)f_9464},
{"f_9428eval.scm",(void*)f_9428},
{"f_9434eval.scm",(void*)f_9434},
{"f_9442eval.scm",(void*)f_9442},
{"f_9416eval.scm",(void*)f_9416},
{"f_9422eval.scm",(void*)f_9422},
{"f_9426eval.scm",(void*)f_9426},
{"f_9407eval.scm",(void*)f_9407},
{"f_9411eval.scm",(void*)f_9411},
{"f_9348eval.scm",(void*)f_9348},
{"f_9358eval.scm",(void*)f_9358},
{"f_9383eval.scm",(void*)f_9383},
{"f_9395eval.scm",(void*)f_9395},
{"f_9401eval.scm",(void*)f_9401},
{"f_9389eval.scm",(void*)f_9389},
{"f_9364eval.scm",(void*)f_9364},
{"f_9370eval.scm",(void*)f_9370},
{"f_9374eval.scm",(void*)f_9374},
{"f_9377eval.scm",(void*)f_9377},
{"f_9381eval.scm",(void*)f_9381},
{"f_9356eval.scm",(void*)f_9356},
{"f_9261eval.scm",(void*)f_9261},
{"f_9271eval.scm",(void*)f_9271},
{"f_9274eval.scm",(void*)f_9274},
{"f_9288eval.scm",(void*)f_9288},
{"f_9306eval.scm",(void*)f_9306},
{"f_9275eval.scm",(void*)f_9275},
{"f_9252eval.scm",(void*)f_9252},
{"f_8911eval.scm",(void*)f_8911},
{"f_8955eval.scm",(void*)f_8955},
{"f_8958eval.scm",(void*)f_8958},
{"f_9235eval.scm",(void*)f_9235},
{"f_9239eval.scm",(void*)f_9239},
{"f_9243eval.scm",(void*)f_9243},
{"f_9040eval.scm",(void*)f_9040},
{"f_9046eval.scm",(void*)f_9046},
{"f_9218eval.scm",(void*)f_9218},
{"f_9224eval.scm",(void*)f_9224},
{"f_9053eval.scm",(void*)f_9053},
{"f_9056eval.scm",(void*)f_9056},
{"f_9059eval.scm",(void*)f_9059},
{"f_9213eval.scm",(void*)f_9213},
{"f_9068eval.scm",(void*)f_9068},
{"f_9071eval.scm",(void*)f_9071},
{"f_9086eval.scm",(void*)f_9086},
{"f_9104eval.scm",(void*)f_9104},
{"f_9167eval.scm",(void*)f_9167},
{"f_9120eval.scm",(void*)f_9120},
{"f_9125eval.scm",(void*)f_9125},
{"f_9129eval.scm",(void*)f_9129},
{"f_9132eval.scm",(void*)f_9132},
{"f_9144eval.scm",(void*)f_9144},
{"f_9147eval.scm",(void*)f_9147},
{"f_9135eval.scm",(void*)f_9135},
{"f_9108eval.scm",(void*)f_9108},
{"f_9090eval.scm",(void*)f_9090},
{"f_8936eval.scm",(void*)f_8936},
{"f_8941eval.scm",(void*)f_8941},
{"f_9093eval.scm",(void*)f_9093},
{"f_9077eval.scm",(void*)f_9077},
{"f_8975eval.scm",(void*)f_8975},
{"f_8980eval.scm",(void*)f_8980},
{"f_8983eval.scm",(void*)f_8983},
{"f_8988eval.scm",(void*)f_8988},
{"f_8995eval.scm",(void*)f_8995},
{"f_9035eval.scm",(void*)f_9035},
{"f_8998eval.scm",(void*)f_8998},
{"f_9010eval.scm",(void*)f_9010},
{"f_9019eval.scm",(void*)f_9019},
{"f_9013eval.scm",(void*)f_9013},
{"f_9001eval.scm",(void*)f_9001},
{"f_9004eval.scm",(void*)f_9004},
{"f_8966eval.scm",(void*)f_8966},
{"f_8960eval.scm",(void*)f_8960},
{"f_8914eval.scm",(void*)f_8914},
{"f_8920eval.scm",(void*)f_8920},
{"f_8908eval.scm",(void*)f_8908},
{"f_8892eval.scm",(void*)f_8892},
{"f_8906eval.scm",(void*)f_8906},
{"f_8903eval.scm",(void*)f_8903},
{"f_8896eval.scm",(void*)f_8896},
{"f_8873eval.scm",(void*)f_8873},
{"f_8882eval.scm",(void*)f_8882},
{"f_8877eval.scm",(void*)f_8877},
{"f_8442eval.scm",(void*)f_8442},
{"f_8579eval.scm",(void*)f_8579},
{"f_8584eval.scm",(void*)f_8584},
{"f_8802eval.scm",(void*)f_8802},
{"f_8783eval.scm",(void*)f_8783},
{"f_8729eval.scm",(void*)f_8729},
{"f_8600eval.scm",(void*)f_8600},
{"f_8605eval.scm",(void*)f_8605},
{"f_8624eval.scm",(void*)f_8624},
{"f_8550eval.scm",(void*)f_8550},
{"f_8556eval.scm",(void*)f_8556},
{"f_8488eval.scm",(void*)f_8488},
{"f_8492eval.scm",(void*)f_8492},
{"f_8500eval.scm",(void*)f_8500},
{"f_8523eval.scm",(void*)f_8523},
{"f_8445eval.scm",(void*)f_8445},
{"f_8452eval.scm",(void*)f_8452},
{"f_8457eval.scm",(void*)f_8457},
{"f_8461eval.scm",(void*)f_8461},
{"f_8486eval.scm",(void*)f_8486},
{"f_8475eval.scm",(void*)f_8475},
{"f_8479eval.scm",(void*)f_8479},
{"f_8468eval.scm",(void*)f_8468},
{"f_8406eval.scm",(void*)f_8406},
{"f_8428eval.scm",(void*)f_8428},
{"f_8398eval.scm",(void*)f_8398},
{"f_8344eval.scm",(void*)f_8344},
{"f_8348eval.scm",(void*)f_8348},
{"f_8351eval.scm",(void*)f_8351},
{"f_8354eval.scm",(void*)f_8354},
{"f_8357eval.scm",(void*)f_8357},
{"f_8360eval.scm",(void*)f_8360},
{"f_8363eval.scm",(void*)f_8363},
{"f_8366eval.scm",(void*)f_8366},
{"f_8369eval.scm",(void*)f_8369},
{"f_8372eval.scm",(void*)f_8372},
{"f_8323eval.scm",(void*)f_8323},
{"f_8327eval.scm",(void*)f_8327},
{"f_8330eval.scm",(void*)f_8330},
{"f_8299eval.scm",(void*)f_8299},
{"f_8305eval.scm",(void*)f_8305},
{"f_8315eval.scm",(void*)f_8315},
{"f_8176eval.scm",(void*)f_8176},
{"f_8234eval.scm",(void*)f_8234},
{"f_8285eval.scm",(void*)f_8285},
{"f_8244eval.scm",(void*)f_8244},
{"f_8246eval.scm",(void*)f_8246},
{"f_8270eval.scm",(void*)f_8270},
{"f_8256eval.scm",(void*)f_8256},
{"f_8217eval.scm",(void*)f_8217},
{"f_8182eval.scm",(void*)f_8182},
{"f_8198eval.scm",(void*)f_8198},
{"f_8204eval.scm",(void*)f_8204},
{"f_8195eval.scm",(void*)f_8195},
{"f_8157eval.scm",(void*)f_8157},
{"f_8161eval.scm",(void*)f_8161},
{"f_8124eval.scm",(void*)f_8124},
{"f_8126eval.scm",(void*)f_8126},
{"f_8130eval.scm",(void*)f_8130},
{"f_8086eval.scm",(void*)f_8086},
{"f_8093eval.scm",(void*)f_8093},
{"f_8100eval.scm",(void*)f_8100},
{"f_8042eval.scm",(void*)f_8042},
{"f_8075eval.scm",(void*)f_8075},
{"f_8062eval.scm",(void*)f_8062},
{"f_8039eval.scm",(void*)f_8039},
{"f_7920eval.scm",(void*)f_7920},
{"f_8014eval.scm",(void*)f_8014},
{"f_8024eval.scm",(void*)f_8024},
{"f_8012eval.scm",(void*)f_8012},
{"f_7941eval.scm",(void*)f_7941},
{"f_7965eval.scm",(void*)f_7965},
{"f_7984eval.scm",(void*)f_7984},
{"f_7959eval.scm",(void*)f_7959},
{"f_7812eval.scm",(void*)f_7812},
{"f_7822eval.scm",(void*)f_7822},
{"f_7827eval.scm",(void*)f_7827},
{"f_7854eval.scm",(void*)f_7854},
{"f_7887eval.scm",(void*)f_7887},
{"f_7848eval.scm",(void*)f_7848},
{"f_7749eval.scm",(void*)f_7749},
{"f_7753eval.scm",(void*)f_7753},
{"f_7761eval.scm",(void*)f_7761},
{"f_7781eval.scm",(void*)f_7781},
{"f_7705eval.scm",(void*)f_7705},
{"f_7737eval.scm",(void*)f_7737},
{"f_7723eval.scm",(void*)f_7723},
{"f_7306eval.scm",(void*)f_7306},
{"f_7581eval.scm",(void*)f_7581},
{"f_7590eval.scm",(void*)f_7590},
{"f_7616eval.scm",(void*)f_7616},
{"f_7618eval.scm",(void*)f_7618},
{"f_7651eval.scm",(void*)f_7651},
{"f_7641eval.scm",(void*)f_7641},
{"f_7636eval.scm",(void*)f_7636},
{"f_7330eval.scm",(void*)f_7330},
{"f_7340eval.scm",(void*)f_7340},
{"f_7474eval.scm",(void*)f_7474},
{"f_7555eval.scm",(void*)f_7555},
{"f_7486eval.scm",(void*)f_7486},
{"f_7501eval.scm",(void*)f_7501},
{"f_7521eval.scm",(void*)f_7521},
{"f_7519eval.scm",(void*)f_7519},
{"f_7505eval.scm",(void*)f_7505},
{"f_7497eval.scm",(void*)f_7497},
{"f_7416eval.scm",(void*)f_7416},
{"f_7434eval.scm",(void*)f_7434},
{"f_7442eval.scm",(void*)f_7442},
{"f_7430eval.scm",(void*)f_7430},
{"f_7389eval.scm",(void*)f_7389},
{"f_7352eval.scm",(void*)f_7352},
{"f_7376eval.scm",(void*)f_7376},
{"f_7372eval.scm",(void*)f_7372},
{"f_7364eval.scm",(void*)f_7364},
{"f_7355eval.scm",(void*)f_7355},
{"f_7309eval.scm",(void*)f_7309},
{"f_7324eval.scm",(void*)f_7324},
{"f_7318eval.scm",(void*)f_7318},
{"f_7257eval.scm",(void*)f_7257},
{"f_7263eval.scm",(void*)f_7263},
{"f_7277eval.scm",(void*)f_7277},
{"f_7280eval.scm",(void*)f_7280},
{"f_7287eval.scm",(void*)f_7287},
{"f_7251eval.scm",(void*)f_7251},
{"f_7220eval.scm",(void*)f_7220},
{"f_7224eval.scm",(void*)f_7224},
{"f_7249eval.scm",(void*)f_7249},
{"f_7227eval.scm",(void*)f_7227},
{"f_7245eval.scm",(void*)f_7245},
{"f_7230eval.scm",(void*)f_7230},
{"f_7237eval.scm",(void*)f_7237},
{"f_7207eval.scm",(void*)f_7207},
{"f_7213eval.scm",(void*)f_7213},
{"f_7193eval.scm",(void*)f_7193},
{"f_7204eval.scm",(void*)f_7204},
{"f_7173eval.scm",(void*)f_7173},
{"f_7179eval.scm",(void*)f_7179},
{"f_7186eval.scm",(void*)f_7186},
{"f_7105eval.scm",(void*)f_7105},
{"f_7168eval.scm",(void*)f_7168},
{"f_7109eval.scm",(void*)f_7109},
{"f_7112eval.scm",(void*)f_7112},
{"f_7130eval.scm",(void*)f_7130},
{"f_7136eval.scm",(void*)f_7136},
{"f_7028eval.scm",(void*)f_7028},
{"f_7102eval.scm",(void*)f_7102},
{"f_7095eval.scm",(void*)f_7095},
{"f_7062eval.scm",(void*)f_7062},
{"f_7064eval.scm",(void*)f_7064},
{"f_7077eval.scm",(void*)f_7077},
{"f_7031eval.scm",(void*)f_7031},
{"f_7035eval.scm",(void*)f_7035},
{"f_7055eval.scm",(void*)f_7055},
{"f_7041eval.scm",(void*)f_7041},
{"f_7051eval.scm",(void*)f_7051},
{"f_7044eval.scm",(void*)f_7044},
{"f_6865eval.scm",(void*)f_6865},
{"f_6970eval.scm",(void*)f_6970},
{"f_6987eval.scm",(void*)f_6987},
{"f_6995eval.scm",(void*)f_6995},
{"f_6887eval.scm",(void*)f_6887},
{"f_6892eval.scm",(void*)f_6892},
{"f_6931eval.scm",(void*)f_6931},
{"f_6918eval.scm",(void*)f_6918},
{"f_6874eval.scm",(void*)f_6874},
{"f_6868eval.scm",(void*)f_6868},
{"f_6809eval.scm",(void*)f_6809},
{"f_6818eval.scm",(void*)f_6818},
{"f_6856eval.scm",(void*)f_6856},
{"f_6836eval.scm",(void*)f_6836},
{"f_6780eval.scm",(void*)f_6780},
{"f_6787eval.scm",(void*)f_6787},
{"f_6797eval.scm",(void*)f_6797},
{"f_6674eval.scm",(void*)f_6674},
{"f_6678eval.scm",(void*)f_6678},
{"f_6770eval.scm",(void*)f_6770},
{"f_6774eval.scm",(void*)f_6774},
{"f_6687eval.scm",(void*)f_6687},
{"f_6756eval.scm",(void*)f_6756},
{"f_6752eval.scm",(void*)f_6752},
{"f_6690eval.scm",(void*)f_6690},
{"f_6739eval.scm",(void*)f_6739},
{"f_6742eval.scm",(void*)f_6742},
{"f_6745eval.scm",(void*)f_6745},
{"f_6693eval.scm",(void*)f_6693},
{"f_6698eval.scm",(void*)f_6698},
{"f_6732eval.scm",(void*)f_6732},
{"f_6711eval.scm",(void*)f_6711},
{"f_6714eval.scm",(void*)f_6714},
{"f_6634eval.scm",(void*)f_6634},
{"f_6655eval.scm",(void*)f_6655},
{"f_6638eval.scm",(void*)f_6638},
{"f_6652eval.scm",(void*)f_6652},
{"f_6641eval.scm",(void*)f_6641},
{"f_6649eval.scm",(void*)f_6649},
{"f_6644eval.scm",(void*)f_6644},
{"f_6598eval.scm",(void*)f_6598},
{"f_6606eval.scm",(void*)f_6606},
{"f_6576eval.scm",(void*)f_6576},
{"f_6189eval.scm",(void*)f_6189},
{"f_6531eval.scm",(void*)f_6531},
{"f_6526eval.scm",(void*)f_6526},
{"f_6191eval.scm",(void*)f_6191},
{"f_6525eval.scm",(void*)f_6525},
{"f_6195eval.scm",(void*)f_6195},
{"f_6459eval.scm",(void*)f_6459},
{"f_6474eval.scm",(void*)f_6474},
{"f_6477eval.scm",(void*)f_6477},
{"f_6480eval.scm",(void*)f_6480},
{"f_6486eval.scm",(void*)f_6486},
{"f_6489eval.scm",(void*)f_6489},
{"f_6495eval.scm",(void*)f_6495},
{"f_6198eval.scm",(void*)f_6198},
{"f_6450eval.scm",(void*)f_6450},
{"f_6441eval.scm",(void*)f_6441},
{"f_6444eval.scm",(void*)f_6444},
{"f_6204eval.scm",(void*)f_6204},
{"f_6426eval.scm",(void*)f_6426},
{"f_6398eval.scm",(void*)f_6398},
{"f_6422eval.scm",(void*)f_6422},
{"f_6418eval.scm",(void*)f_6418},
{"f_6414eval.scm",(void*)f_6414},
{"f_6207eval.scm",(void*)f_6207},
{"f_6215eval.scm",(void*)f_6215},
{"f_6385eval.scm",(void*)f_6385},
{"f_6219eval.scm",(void*)f_6219},
{"f_6370eval.scm",(void*)f_6370},
{"f_6243eval.scm",(void*)f_6243},
{"f_6247eval.scm",(void*)f_6247},
{"f_6361eval.scm",(void*)f_6361},
{"f_6255eval.scm",(void*)f_6255},
{"f_6259eval.scm",(void*)f_6259},
{"f_6355eval.scm",(void*)f_6355},
{"f_6262eval.scm",(void*)f_6262},
{"f_6265eval.scm",(void*)f_6265},
{"f_6270eval.scm",(void*)f_6270},
{"f_6280eval.scm",(void*)f_6280},
{"f_6326eval.scm",(void*)f_6326},
{"f_6335eval.scm",(void*)f_6335},
{"f_6339eval.scm",(void*)f_6339},
{"f_6292eval.scm",(void*)f_6292},
{"f_6299eval.scm",(void*)f_6299},
{"f_6310eval.scm",(void*)f_6310},
{"f_6321eval.scm",(void*)f_6321},
{"f_6314eval.scm",(void*)f_6314},
{"f_6304eval.scm",(void*)f_6304},
{"f_6283eval.scm",(void*)f_6283},
{"f_6290eval.scm",(void*)f_6290},
{"f_6252eval.scm",(void*)f_6252},
{"f_6229eval.scm",(void*)f_6229},
{"f_6220eval.scm",(void*)f_6220},
{"f_6210eval.scm",(void*)f_6210},
{"f_6143eval.scm",(void*)f_6143},
{"f_6153eval.scm",(void*)f_6153},
{"f_6068eval.scm",(void*)f_6068},
{"f_6080eval.scm",(void*)f_6080},
{"f_6093eval.scm",(void*)f_6093},
{"f_6075eval.scm",(void*)f_6075},
{"f_6063eval.scm",(void*)f_6063},
{"f_5979eval.scm",(void*)f_5979},
{"f_5992eval.scm",(void*)f_5992},
{"f_6025eval.scm",(void*)f_6025},
{"f_6006eval.scm",(void*)f_6006},
{"f_5982eval.scm",(void*)f_5982},
{"f_5965eval.scm",(void*)f_5965},
{"f_5973eval.scm",(void*)f_5973},
{"f_5977eval.scm",(void*)f_5977},
{"f_3726eval.scm",(void*)f_3726},
{"f_5710eval.scm",(void*)f_5710},
{"f_5714eval.scm",(void*)f_5714},
{"f_5927eval.scm",(void*)f_5927},
{"f_5903eval.scm",(void*)f_5903},
{"f_5904eval.scm",(void*)f_5904},
{"f_5915eval.scm",(void*)f_5915},
{"f_5921eval.scm",(void*)f_5921},
{"f_5919eval.scm",(void*)f_5919},
{"f_5860eval.scm",(void*)f_5860},
{"f_5863eval.scm",(void*)f_5863},
{"f_5866eval.scm",(void*)f_5866},
{"f_5869eval.scm",(void*)f_5869},
{"f_5870eval.scm",(void*)f_5870},
{"f_5881eval.scm",(void*)f_5881},
{"f_5885eval.scm",(void*)f_5885},
{"f_5889eval.scm",(void*)f_5889},
{"f_5893eval.scm",(void*)f_5893},
{"f_5896eval.scm",(void*)f_5896},
{"f_5818eval.scm",(void*)f_5818},
{"f_5821eval.scm",(void*)f_5821},
{"f_5824eval.scm",(void*)f_5824},
{"f_5825eval.scm",(void*)f_5825},
{"f_5836eval.scm",(void*)f_5836},
{"f_5840eval.scm",(void*)f_5840},
{"f_5844eval.scm",(void*)f_5844},
{"f_5847eval.scm",(void*)f_5847},
{"f_5783eval.scm",(void*)f_5783},
{"f_5786eval.scm",(void*)f_5786},
{"f_5787eval.scm",(void*)f_5787},
{"f_5798eval.scm",(void*)f_5798},
{"f_5802eval.scm",(void*)f_5802},
{"f_5805eval.scm",(void*)f_5805},
{"f_5755eval.scm",(void*)f_5755},
{"f_5756eval.scm",(void*)f_5756},
{"f_5767eval.scm",(void*)f_5767},
{"f_5770eval.scm",(void*)f_5770},
{"f_5736eval.scm",(void*)f_5736},
{"f_5746eval.scm",(void*)f_5746},
{"f_5684eval.scm",(void*)f_5684},
{"f_3954eval.scm",(void*)f_3954},
{"f_4057eval.scm",(void*)f_4057},
{"f_4113eval.scm",(void*)f_4113},
{"f_4142eval.scm",(void*)f_4142},
{"f_4148eval.scm",(void*)f_4148},
{"f_5517eval.scm",(void*)f_5517},
{"f_5504eval.scm",(void*)f_5504},
{"f_5465eval.scm",(void*)f_5465},
{"f_5454eval.scm",(void*)f_5454},
{"f_5416eval.scm",(void*)f_5416},
{"f_5410eval.scm",(void*)f_5410},
{"f_5364eval.scm",(void*)f_5364},
{"f_5386eval.scm",(void*)f_5386},
{"f_5394eval.scm",(void*)f_5394},
{"f_5376eval.scm",(void*)f_5376},
{"f_5358eval.scm",(void*)f_5358},
{"f_5334eval.scm",(void*)f_5334},
{"f_5341eval.scm",(void*)f_5341},
{"f_5303eval.scm",(void*)f_5303},
{"f_5306eval.scm",(void*)f_5306},
{"f_5309eval.scm",(void*)f_5309},
{"f_5328eval.scm",(void*)f_5328},
{"f_5326eval.scm",(void*)f_5326},
{"f_5316eval.scm",(void*)f_5316},
{"f_4901eval.scm",(void*)f_4901},
{"f_5238eval.scm",(void*)f_5238},
{"f_5249eval.scm",(void*)f_5249},
{"f_5243eval.scm",(void*)f_5243},
{"f_4913eval.scm",(void*)f_4913},
{"f_4918eval.scm",(void*)f_4918},
{"f_5227eval.scm",(void*)f_5227},
{"f_5221eval.scm",(void*)f_5221},
{"f_4925eval.scm",(void*)f_4925},
{"f_5183eval.scm",(void*)f_5183},
{"f_5189eval.scm",(void*)f_5189},
{"f_5213eval.scm",(void*)f_5213},
{"f_5160eval.scm",(void*)f_5160},
{"f_5166eval.scm",(void*)f_5166},
{"f_5651eval.scm",(void*)f_5651},
{"f_5182eval.scm",(void*)f_5182},
{"f_5178eval.scm",(void*)f_5178},
{"f_5138eval.scm",(void*)f_5138},
{"f_5144eval.scm",(void*)f_5144},
{"f_5156eval.scm",(void*)f_5156},
{"f_5119eval.scm",(void*)f_5119},
{"f_5125eval.scm",(void*)f_5125},
{"f_5091eval.scm",(void*)f_5091},
{"f_5097eval.scm",(void*)f_5097},
{"f_5072eval.scm",(void*)f_5072},
{"f_5078eval.scm",(void*)f_5078},
{"f_5044eval.scm",(void*)f_5044},
{"f_5050eval.scm",(void*)f_5050},
{"f_5025eval.scm",(void*)f_5025},
{"f_5031eval.scm",(void*)f_5031},
{"f_4997eval.scm",(void*)f_4997},
{"f_5003eval.scm",(void*)f_5003},
{"f_4978eval.scm",(void*)f_4978},
{"f_4984eval.scm",(void*)f_4984},
{"f_4954eval.scm",(void*)f_4954},
{"f_4960eval.scm",(void*)f_4960},
{"f_4935eval.scm",(void*)f_4935},
{"f_4941eval.scm",(void*)f_4941},
{"f_4563eval.scm",(void*)f_4563},
{"f_4888eval.scm",(void*)f_4888},
{"f_4572eval.scm",(void*)f_4572},
{"f_4882eval.scm",(void*)f_4882},
{"f_4876eval.scm",(void*)f_4876},
{"f_4578eval.scm",(void*)f_4578},
{"f_4860eval.scm",(void*)f_4860},
{"f_4813eval.scm",(void*)f_4813},
{"f_4814eval.scm",(void*)f_4814},
{"f_4818eval.scm",(void*)f_4818},
{"f_4830eval.scm",(void*)f_4830},
{"f_4855eval.scm",(void*)f_4855},
{"f_4821eval.scm",(void*)f_4821},
{"f_4737eval.scm",(void*)f_4737},
{"f_4798eval.scm",(void*)f_4798},
{"f_4740eval.scm",(void*)f_4740},
{"f_4746eval.scm",(void*)f_4746},
{"f_4782eval.scm",(void*)f_4782},
{"f_4749eval.scm",(void*)f_4749},
{"f_4750eval.scm",(void*)f_4750},
{"f_4766eval.scm",(void*)f_4766},
{"f_4770eval.scm",(void*)f_4770},
{"f_4774eval.scm",(void*)f_4774},
{"f_4778eval.scm",(void*)f_4778},
{"f_4670eval.scm",(void*)f_4670},
{"f_4716eval.scm",(void*)f_4716},
{"f_4673eval.scm",(void*)f_4673},
{"f_4679eval.scm",(void*)f_4679},
{"f_4680eval.scm",(void*)f_4680},
{"f_4696eval.scm",(void*)f_4696},
{"f_4700eval.scm",(void*)f_4700},
{"f_4704eval.scm",(void*)f_4704},
{"f_4621eval.scm",(void*)f_4621},
{"f_4649eval.scm",(void*)f_4649},
{"f_4624eval.scm",(void*)f_4624},
{"f_4625eval.scm",(void*)f_4625},
{"f_4641eval.scm",(void*)f_4641},
{"f_4645eval.scm",(void*)f_4645},
{"f_4587eval.scm",(void*)f_4587},
{"f_4588eval.scm",(void*)f_4588},
{"f_4604eval.scm",(void*)f_4604},
{"f_4454eval.scm",(void*)f_4454},
{"f_4468eval.scm",(void*)f_4468},
{"f_4472eval.scm",(void*)f_4472},
{"f_4481eval.scm",(void*)f_4481},
{"f_4514eval.scm",(void*)f_4514},
{"f_4522eval.scm",(void*)f_4522},
{"f_4487eval.scm",(void*)f_4487},
{"f_4490eval.scm",(void*)f_4490},
{"f_4506eval.scm",(void*)f_4506},
{"f_4497eval.scm",(void*)f_4497},
{"f_4505eval.scm",(void*)f_4505},
{"f_4542eval.scm",(void*)f_4542},
{"f_4550eval.scm",(void*)f_4550},
{"f_4529eval.scm",(void*)f_4529},
{"f_4541eval.scm",(void*)f_4541},
{"f_4462eval.scm",(void*)f_4462},
{"f_4346eval.scm",(void*)f_4346},
{"f_4405eval.scm",(void*)f_4405},
{"f_4408eval.scm",(void*)f_4408},
{"f_4411eval.scm",(void*)f_4411},
{"f_4412eval.scm",(void*)f_4412},
{"f_4416eval.scm",(void*)f_4416},
{"f_4419eval.scm",(void*)f_4419},
{"f_4383eval.scm",(void*)f_4383},
{"f_4386eval.scm",(void*)f_4386},
{"f_4387eval.scm",(void*)f_4387},
{"f_4391eval.scm",(void*)f_4391},
{"f_4289eval.scm",(void*)f_4289},
{"f_4292eval.scm",(void*)f_4292},
{"f_4295eval.scm",(void*)f_4295},
{"f_4298eval.scm",(void*)f_4298},
{"f_4299eval.scm",(void*)f_4299},
{"f_4306eval.scm",(void*)f_4306},
{"f_4279eval.scm",(void*)f_4279},
{"f_4245eval.scm",(void*)f_4245},
{"f_4239eval.scm",(void*)f_4239},
{"f_4240eval.scm",(void*)f_4240},
{"f_4163eval.scm",(void*)f_4163},
{"f_4223eval.scm",(void*)f_4223},
{"f_4221eval.scm",(void*)f_4221},
{"f_4213eval.scm",(void*)f_4213},
{"f_4205eval.scm",(void*)f_4205},
{"f_4197eval.scm",(void*)f_4197},
{"f_4189eval.scm",(void*)f_4189},
{"f_4181eval.scm",(void*)f_4181},
{"f_4173eval.scm",(void*)f_4173},
{"f_4114eval.scm",(void*)f_4114},
{"f_4103eval.scm",(void*)f_4103},
{"f_4101eval.scm",(void*)f_4101},
{"f_4090eval.scm",(void*)f_4090},
{"f_4088eval.scm",(void*)f_4088},
{"f_4080eval.scm",(void*)f_4080},
{"f_4072eval.scm",(void*)f_4072},
{"f_4064eval.scm",(void*)f_4064},
{"f_3972eval.scm",(void*)f_3972},
{"f_3982eval.scm",(void*)f_3982},
{"f_4031eval.scm",(void*)f_4031},
{"f_4016eval.scm",(void*)f_4016},
{"f_4011eval.scm",(void*)f_4011},
{"f_4012eval.scm",(void*)f_4012},
{"f_3988eval.scm",(void*)f_3988},
{"f_3991eval.scm",(void*)f_3991},
{"f_3992eval.scm",(void*)f_3992},
{"f_4047eval.scm",(void*)f_4047},
{"f_4038eval.scm",(void*)f_4038},
{"f_3966eval.scm",(void*)f_3966},
{"f_3948eval.scm",(void*)f_3948},
{"f_3942eval.scm",(void*)f_3942},
{"f_3936eval.scm",(void*)f_3936},
{"f_3883eval.scm",(void*)f_3883},
{"f_3887eval.scm",(void*)f_3887},
{"f_3934eval.scm",(void*)f_3934},
{"f_3902eval.scm",(void*)f_3902},
{"f_3911eval.scm",(void*)f_3911},
{"f_3771eval.scm",(void*)f_3771},
{"f_3783eval.scm",(void*)f_3783},
{"f_3777eval.scm",(void*)f_3777},
{"f_3729eval.scm",(void*)f_3729},
{"f_3735eval.scm",(void*)f_3735},
{"f_3853eval.scm",(void*)f_3853},
{"f_3720eval.scm",(void*)f_3720},
{"f_3679eval.scm",(void*)f_3679},
{"f_3698eval.scm",(void*)f_3698},
{"f_3710eval.scm",(void*)f_3710},
{"f_3713eval.scm",(void*)f_3713},
{"f_3716eval.scm",(void*)f_3716},
{"f_3706eval.scm",(void*)f_3706},
{"f_3685eval.scm",(void*)f_3685},
{"f_3619eval.scm",(void*)f_3619},
{"f_3623eval.scm",(void*)f_3623},
{"f_3631eval.scm",(void*)f_3631},
{"f_3573eval.scm",(void*)f_3573},
{"f_3579eval.scm",(void*)f_3579},
{"f_3598eval.scm",(void*)f_3598},
{"f_3589eval.scm",(void*)f_3589},
{"f_3518eval.scm",(void*)f_3518},
{"f_3522eval.scm",(void*)f_3522},
{"f_3530eval.scm",(void*)f_3530},
{"f_3473eval.scm",(void*)f_3473},
{"f_3477eval.scm",(void*)f_3477},
{"f_3486eval.scm",(void*)f_3486},
{"f_3458eval.scm",(void*)f_3458},
{"f_3398eval.scm",(void*)f_3398},
{"f_3453eval.scm",(void*)f_3453},
{"f_3401eval.scm",(void*)f_3401},
{"f_3307eval.scm",(void*)f_3307},
{"f_3396eval.scm",(void*)f_3396},
{"f_3310eval.scm",(void*)f_3310},
{"f_3365eval.scm",(void*)f_3365},
{"f_2824eval.scm",(void*)f_2824},
{"f_3262eval.scm",(void*)f_3262},
{"f_3257eval.scm",(void*)f_3257},
{"f_2826eval.scm",(void*)f_2826},
{"f_3009eval.scm",(void*)f_3009},
{"f_3015eval.scm",(void*)f_3015},
{"f_3049eval.scm",(void*)f_3049},
{"f_3221eval.scm",(void*)f_3221},
{"f_3207eval.scm",(void*)f_3207},
{"f_3214eval.scm",(void*)f_3214},
{"f_3179eval.scm",(void*)f_3179},
{"f_3061eval.scm",(void*)f_3061},
{"f_3066eval.scm",(void*)f_3066},
{"f_3079eval.scm",(void*)f_3079},
{"f_3131eval.scm",(void*)f_3131},
{"f_3113eval.scm",(void*)f_3113},
{"f_3124eval.scm",(void*)f_3124},
{"f_2829eval.scm",(void*)f_2829},
{"f_2911eval.scm",(void*)f_2911},
{"f_3001eval.scm",(void*)f_3001},
{"f_2989eval.scm",(void*)f_2989},
{"f_2922eval.scm",(void*)f_2922},
{"f_2987eval.scm",(void*)f_2987},
{"f_2979eval.scm",(void*)f_2979},
{"f_2930eval.scm",(void*)f_2930},
{"f_2973eval.scm",(void*)f_2973},
{"f_2977eval.scm",(void*)f_2977},
{"f_2940eval.scm",(void*)f_2940},
{"f_2944eval.scm",(void*)f_2944},
{"f_2965eval.scm",(void*)f_2965},
{"f_2963eval.scm",(void*)f_2963},
{"f_2938eval.scm",(void*)f_2938},
{"f_2934eval.scm",(void*)f_2934},
{"f_2926eval.scm",(void*)f_2926},
{"f_2841eval.scm",(void*)f_2841},
{"f_2860eval.scm",(void*)f_2860},
{"f_2871eval.scm",(void*)f_2871},
{"f_2879eval.scm",(void*)f_2879},
{"f_2867eval.scm",(void*)f_2867},
{"f_2305eval.scm",(void*)f_2305},
{"f_2327eval.scm",(void*)f_2327},
{"f_2767eval.scm",(void*)f_2767},
{"f_2705eval.scm",(void*)f_2705},
{"f_2686eval.scm",(void*)f_2686},
{"f_2640eval.scm",(void*)f_2640},
{"f_2643eval.scm",(void*)f_2643},
{"f_2622eval.scm",(void*)f_2622},
{"f_2603eval.scm",(void*)f_2603},
{"f_2571eval.scm",(void*)f_2571},
{"f_2550eval.scm",(void*)f_2550},
{"f_2341eval.scm",(void*)f_2341},
{"f_2543eval.scm",(void*)f_2543},
{"f_2486eval.scm",(void*)f_2486},
{"f_2539eval.scm",(void*)f_2539},
{"f_2513eval.scm",(void*)f_2513},
{"f_2484eval.scm",(void*)f_2484},
{"f_2345eval.scm",(void*)f_2345},
{"f_2357eval.scm",(void*)f_2357},
{"f_2436eval.scm",(void*)f_2436},
{"f_2432eval.scm",(void*)f_2432},
{"f_2413eval.scm",(void*)f_2413},
{"f_2348eval.scm",(void*)f_2348},
{"f_2308eval.scm",(void*)f_2308},
{"f_2262eval.scm",(void*)f_2262},
{"f_2268eval.scm",(void*)f_2268},
{"f_2287eval.scm",(void*)f_2287},
{"f_2246eval.scm",(void*)f_2246},
{"f_2210eval.scm",(void*)f_2210},
{"f_2219eval.scm",(void*)f_2219},
{"f_2231eval.scm",(void*)f_2231},
{"f_2225eval.scm",(void*)f_2225},
{"f_2203eval.scm",(void*)f_2203},
{"f_2200eval.scm",(void*)f_2200},
{"f_2197eval.scm",(void*)f_2197},
{"f_1827eval.scm",(void*)f_1827},
{"f_2137eval.scm",(void*)f_2137},
{"f_2143eval.scm",(void*)f_2143},
{"f_2150eval.scm",(void*)f_2150},
{"f_2064eval.scm",(void*)f_2064},
{"f_2076eval.scm",(void*)f_2076},
{"f_2124eval.scm",(void*)f_2124},
{"f_2118eval.scm",(void*)f_2118},
{"f_2098eval.scm",(void*)f_2098},
{"f_1976eval.scm",(void*)f_1976},
{"f_1996eval.scm",(void*)f_1996},
{"f_2004eval.scm",(void*)f_2004},
{"f_2018eval.scm",(void*)f_2018},
{"f_1990eval.scm",(void*)f_1990},
{"f_1830eval.scm",(void*)f_1830},
{"f_1839eval.scm",(void*)f_1839},
{"f_1952eval.scm",(void*)f_1952},
{"f_1964eval.scm",(void*)f_1964},
{"f_1970eval.scm",(void*)f_1970},
{"f_1958eval.scm",(void*)f_1958},
{"f_1845eval.scm",(void*)f_1845},
{"f_1851eval.scm",(void*)f_1851},
{"f_1862eval.scm",(void*)f_1862},
{"f_1879eval.scm",(void*)f_1879},
{"f_1898eval.scm",(void*)f_1898},
{"f_1909eval.scm",(void*)f_1909},
{"f_1873eval.scm",(void*)f_1873},
{"f_1859eval.scm",(void*)f_1859},
{"f_1837eval.scm",(void*)f_1837},
{"f_1818eval.scm",(void*)f_1818},
{"f_1800eval.scm",(void*)f_1800},
{"f_1810eval.scm",(void*)f_1810},
{"f_1790eval.scm",(void*)f_1790},
{"f_1798eval.scm",(void*)f_1798},
{"f_1774eval.scm",(void*)f_1774},
{"f_1780eval.scm",(void*)f_1780},
{"f_1758eval.scm",(void*)f_1758},
{"f_1764eval.scm",(void*)f_1764},
{"f_1742eval.scm",(void*)f_1742},
{"f_1746eval.scm",(void*)f_1746},
{"f_1715eval.scm",(void*)f_1715},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
