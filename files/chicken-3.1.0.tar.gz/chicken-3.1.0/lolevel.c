/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:47
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: lolevel.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_pointer_to_object(ptr)   ((C_word*)C_block_item(ptr, 0))
#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[164];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,5),40,101,114,114,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,10),40,120,101,114,114,32,120,57,48,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,110,32,110,57,49,32,110,109,97,120,57,50,32,111,102,102,57,51,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,110,50,32,110,57,52,32,110,109,97,120,57,53,32,110,109,97,120,50,57,54,32,111,102,102,49,57,55,32,111,102,102,50,57,56,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,49,48,48,32,116,111,49,48,49,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,32),40,98,111,100,121,55,54,32,110,56,51,32,102,111,102,102,115,101,116,56,52,32,116,111,102,102,115,101,116,56,53,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,37),40,100,101,102,45,116,111,102,102,115,101,116,56,48,32,37,110,55,51,49,50,57,32,37,102,111,102,102,115,101,116,55,52,49,51,48,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,102,111,102,102,115,101,116,55,57,32,37,110,55,51,49,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,9),40,100,101,102,45,110,55,56,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,34),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,55,48,32,116,111,55,49,32,46,32,103,54,57,55,50,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,112,116,114,49,52,49,32,108,111,99,49,52,50,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,49,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,49,53,48,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,49,53,50,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,49,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,102,95,49,50,52,52,32,97,49,53,55,49,54,48,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,49,54,50,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,49,54,52,32,112,50,49,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,49,54,56,49,55,49,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,49,55,51,49,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,108,105,103,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,49,56,53,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,32),40,112,111,105,110,116,101,114,45,111,102,102,115,101,116,32,97,49,56,55,49,57,49,32,97,49,56,54,49,57,50,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,97,49,57,54,50,48,48,32,97,49,57,53,50,48,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,97,50,48,52,50,48,56,32,97,50,48,51,50,48,57,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,97,50,49,50,50,49,54,32,97,50,49,49,50,49,55,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,97,50,50,48,50,50,52,32,97,50,49,57,50,50,53,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,97,50,50,56,50,51,50,32,97,50,50,55,50,51,51,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,97,50,51,54,50,52,48,32,97,50,51,53,50,52,49,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,97,50,52,52,50,52,56,32,97,50,52,51,50,52,57,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,97,50,53,50,50,53,54,32,97,50,53,49,50,53,55,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,51,49,49,32,116,97,103,51,49,50,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,51,49,53,32,116,97,103,51,49,54,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,51,49,55,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,49,53,51,54,32,120,51,50,48,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,17),40,97,49,53,53,50,32,120,51,50,49,32,105,51,50,50,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,51,49,56,32,100,97,116,97,51,49,57,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,49,53,56,48,32,120,51,50,54,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,51,50,53,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,12),40,97,49,54,49,52,32,120,51,50,57,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,51,50,55,41,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,51,51,49,32,120,51,51,50,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,100,111,51,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,30),40,98,121,116,101,45,118,101,99,116,111,114,45,102,105,108,108,33,32,98,118,51,51,52,32,110,51,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,36),40,109,97,107,101,45,98,121,116,101,45,118,101,99,116,111,114,32,115,105,122,101,51,52,52,32,46,32,105,110,105,116,51,52,53,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,100,111,51,53,49,32,98,121,116,101,115,51,53,52,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,98,121,116,101,45,118,101,99,116,111,114,32,46,32,98,121,116,101,115,51,52,56,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,34),40,98,121,116,101,45,118,101,99,116,111,114,45,115,101,116,33,32,98,118,51,53,55,32,105,51,53,56,32,120,51,53,57,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,55,54,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,25),40,98,121,116,101,45,118,101,99,116,111,114,45,62,108,105,115,116,32,98,118,51,55,51,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,17),40,100,111,51,56,50,32,112,51,56,52,32,105,51,56,53,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,26),40,108,105,115,116,45,62,98,121,116,101,45,118,101,99,116,111,114,32,108,115,116,51,55,57,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,43),40,109,97,107,101,45,115,116,97,116,105,99,45,98,121,116,101,45,118,101,99,116,111,114,32,115,105,122,101,52,48,52,32,46,32,105,110,105,116,52,48,53,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,35),40,115,116,97,116,105,99,45,98,121,116,101,45,118,101,99,116,111,114,45,62,112,111,105,110,116,101,114,32,98,118,52,48,55,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,70),40,98,121,116,101,45,118,101,99,116,111,114,45,109,111,118,101,33,32,115,114,99,52,49,49,32,115,114,99,45,115,116,97,114,116,52,49,50,32,115,114,99,45,101,110,100,52,49,51,32,100,115,116,52,49,52,32,100,115,116,45,115,116,97,114,116,52,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,32),40,97,112,112,101,110,100,45,114,101,115,116,45,97,116,32,105,52,50,48,32,118,101,99,116,111,114,115,52,50,49,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,33),40,98,121,116,101,45,118,101,99,116,111,114,45,97,112,112,101,110,100,32,46,32,118,101,99,116,111,114,115,52,49,56,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,52,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,52,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,52,51,52,32,46,32,97,114,103,115,52,51,53,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,23),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,52,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,7),40,100,111,52,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,52,51,56,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,12),40,100,111,52,53,53,32,105,52,53,55,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,52,52,57,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,52,52,55,41,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,52,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,16),40,102,95,50,50,57,49,32,97,52,54,55,52,55,48,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,12),40,100,111,52,55,57,32,105,52,56,49,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,52,55,51,41,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,52,54,51,32,46,32,97,108,108,111,99,97,116,111,114,52,54,52,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,16),40,102,95,50,51,56,48,32,97,52,57,52,52,57,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,12),40,100,111,53,48,51,32,105,53,48,53,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,53,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,52,57,48,32,46,32,114,101,108,101,97,115,101,114,52,57,49,41,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,12),40,100,111,53,50,56,32,105,53,51,48,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,53,50,49,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,53,49,49,32,112,116,114,53,49,50,32,46,32,108,105,109,105,116,53,49,51,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,12),40,100,111,53,52,56,32,105,53,53,48,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,53,52,53,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,53,52,50,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,12),40,100,111,53,55,55,32,105,53,55,57,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,53,54,56,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,31),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,53,53,57,32,46,32,103,53,53,56,53,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,53,56,56,41,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,23),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,108,115,116,53,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,33),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,53,57,56,32,112,114,111,99,53,57,57,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,54,48,53,32,46,32,105,110,100,101,120,54,48,54,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,54,48,57,32,46,32,105,110,100,101,120,54,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,54,49,51,32,121,54,49,52,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,54,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,54,49,54,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,111,111,107,32,46,32,97,114,103,115,54,49,56,41,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,45),40,115,101,116,45,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,97,110,100,108,101,114,33,32,112,114,111,99,54,49,55,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,33),40,117,110,98,111,117,110,100,45,118,97,114,105,97,98,108,101,45,118,97,108,117,101,32,46,32,118,97,108,54,50,49,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,54,50,50,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,25),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,54,50,52,32,120,54,50,53,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,22),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,54,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,29),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,54,50,57,41,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,18),40,97,51,48,50,52,32,98,118,51,54,54,32,105,51,54,55,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,15),40,97,51,48,53,52,32,97,51,48,52,51,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,15),40,97,51,48,54,52,32,97,50,57,55,51,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,15),40,97,51,48,55,52,32,97,50,57,48,50,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,15),40,97,51,48,56,52,32,97,50,56,51,50,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,15),40,97,51,48,57,52,32,97,50,55,55,50,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,15),40,97,51,49,48,52,32,97,50,55,49,50,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,15),40,97,51,49,49,52,32,97,50,54,53,50,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,97,51,49,50,52,32,97,50,53,57,50,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0};


/* from k2383 */
static C_word C_fcall stub495(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub495(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2294 */
static C_word C_fcall stub468(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub468(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1870 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub393(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub393(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int size=(int )C_unfix(C_a0);
char *bv;
           if((bv = (char *)C_malloc(size + 3 + sizeof(C_header))) == NULL) return(C_SCHEME_FALSE);
           bv = (char *)C_align((C_word)bv);
           ((C_SCHEME_BLOCK *)bv)->header = C_BYTEVECTOR_TYPE | size;
           return((C_word)bv);
C_ret:
#undef return

return C_r;}

/* from k3058 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub305(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub305(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3068 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub298(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub298(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3078 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub291(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub291(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3088 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub284(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub284(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3098 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub278(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub278(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3108 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub272(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub272(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3118 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub266(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub266(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_ret:
#undef return

return C_r;}

/* from k3128 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub260(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub260(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k1436 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1422 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1408 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub237(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub237(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1394 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub229(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub229(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1380 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub221(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub221(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1366 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub213(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub213(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1352 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub205(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub205(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1338 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1324 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from k1282 */
static C_word C_fcall stub181(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub181(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1272 */
static C_word C_fcall stub174(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub174(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1265 */
static C_word C_fcall stub169(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub169(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from f_1244 in object->pointer in k724 in k721 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k831 */
static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k803 */
static C_word C_fcall stub42(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub42(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k775 */
static C_word C_fcall stub26(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub26(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k747 */
static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2975)
static void C_fcall f_2975(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2791)
static void C_fcall f_2791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_fcall f_2662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_fcall f_2733(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_fcall f_2569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_fcall f_2397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_fcall f_2411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2352)
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_fcall f_2199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_fcall f_2240(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2109)
static void C_fcall f_2109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_fcall f_2154(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static C_word C_fcall f_2067(C_word t0,C_word t1);
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2004)
static void C_fcall f_2004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1951)
static void C_fcall f_1951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_fcall f_1827(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1788)
static void C_fcall f_1788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static C_word C_fcall f_1712(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1662)
static C_word C_fcall f_1662(C_word t0,C_word t1);
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static C_word C_fcall f_1279(C_word *a,C_word t0);
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1262)
static void C_ccall f_1262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1244)
static void C_ccall f_1244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1174)
static void C_fcall f_1174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1104)
static void C_fcall f_1104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_fcall f_1099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1094)
static void C_fcall f_1094(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_842)
static void C_fcall f_842(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_902)
static void C_fcall f_902(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_fcall f_873(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_880)
static void C_fcall f_880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_fcall f_857(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_851)
static void C_fcall f_851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_fcall f_845(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2975)
static void C_fcall trf_2975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2975(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2975(t0,t1);}

C_noret_decl(trf_2791)
static void C_fcall trf_2791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2791(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2791(t0,t1,t2);}

C_noret_decl(trf_2662)
static void C_fcall trf_2662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2662(t0,t1,t2);}

C_noret_decl(trf_2733)
static void C_fcall trf_2733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2733(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2733(t0,t1,t2);}

C_noret_decl(trf_2569)
static void C_fcall trf_2569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2569(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2569(t0,t1,t2);}

C_noret_decl(trf_2603)
static void C_fcall trf_2603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2603(t0,t1,t2);}

C_noret_decl(trf_2397)
static void C_fcall trf_2397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2397(t0,t1);}

C_noret_decl(trf_2411)
static void C_fcall trf_2411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2411(t0,t1,t2);}

C_noret_decl(trf_2454)
static void C_fcall trf_2454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2454(t0,t1,t2);}

C_noret_decl(trf_2307)
static void C_fcall trf_2307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2307(t0,t1,t2);}

C_noret_decl(trf_2352)
static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2352(t0,t1,t2);}

C_noret_decl(trf_2199)
static void C_fcall trf_2199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2199(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2199(t0,t1,t2);}

C_noret_decl(trf_2240)
static void C_fcall trf_2240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2240(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2240(t0,t1,t2);}

C_noret_decl(trf_2109)
static void C_fcall trf_2109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2109(t0,t1,t2);}

C_noret_decl(trf_2154)
static void C_fcall trf_2154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2154(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2154(t0,t1,t2);}

C_noret_decl(trf_2004)
static void C_fcall trf_2004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2004(t0,t1);}

C_noret_decl(trf_1951)
static void C_fcall trf_1951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1951(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1951(t0,t1,t2,t3);}

C_noret_decl(trf_1827)
static void C_fcall trf_1827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1827(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1827(t0,t1,t2,t3);}

C_noret_decl(trf_1788)
static void C_fcall trf_1788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1788(t0,t1,t2);}

C_noret_decl(trf_1174)
static void C_fcall trf_1174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1174(t0,t1);}

C_noret_decl(trf_1104)
static void C_fcall trf_1104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1104(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1104(t0,t1);}

C_noret_decl(trf_1099)
static void C_fcall trf_1099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1099(t0,t1,t2);}

C_noret_decl(trf_1094)
static void C_fcall trf_1094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1094(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1094(t0,t1,t2,t3);}

C_noret_decl(trf_842)
static void C_fcall trf_842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_842(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_842(t0,t1,t2,t3,t4);}

C_noret_decl(trf_902)
static void C_fcall trf_902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_902(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_902(t0,t1,t2,t3);}

C_noret_decl(trf_873)
static void C_fcall trf_873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_873(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_873(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_880)
static void C_fcall trf_880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_880(t0,t1);}

C_noret_decl(trf_857)
static void C_fcall trf_857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_857(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_857(t0,t1,t2,t3,t4);}

C_noret_decl(trf_851)
static void C_fcall trf_851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_851(t0,t1);}

C_noret_decl(trf_845)
static void C_fcall trf_845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_845(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1447)){
C_save(t1);
C_rereclaim2(1447*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,164);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[3]=C_h_intern(&lf[3],12,"move-memory!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],11,"\000type-error");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid argument type");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[11]=C_h_intern(&lf[11],15,"\003sysbytevector\077");
lf[12]=C_h_intern(&lf[12],13,"\003syslocative\077");
lf[13]=C_h_intern(&lf[13],17,"\003syscheck-pointer");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[15]=C_h_intern(&lf[15],12,"null-pointer");
lf[16]=C_h_intern(&lf[16],16,"\003sysnull-pointer");
lf[17]=C_h_intern(&lf[17],8,"pointer\077");
lf[18]=C_h_intern(&lf[18],16,"address->pointer");
lf[19]=C_h_intern(&lf[19],20,"\003sysaddress->pointer");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\042bad argument type - not an integer");
lf[21]=C_h_intern(&lf[21],16,"pointer->address");
lf[22]=C_h_intern(&lf[22],20,"\003syspointer->address");
lf[23]=C_h_intern(&lf[23],17,"\003syscheck-special");
lf[24]=C_h_intern(&lf[24],13,"null-pointer\077");
lf[25]=C_h_intern(&lf[25],15,"object->pointer");
lf[26]=C_h_intern(&lf[26],15,"pointer->object");
lf[27]=C_h_intern(&lf[27],9,"pointer=\077");
lf[28]=C_h_intern(&lf[28],8,"allocate");
lf[29]=C_h_intern(&lf[29],4,"free");
lf[30]=C_h_intern(&lf[30],13,"align-to-word");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000+bad argument type - not a pointer or fixnum");
lf[32]=C_h_intern(&lf[32],14,"pointer-offset");
lf[33]=C_h_intern(&lf[33],15,"pointer-u8-set!");
lf[34]=C_h_intern(&lf[34],15,"pointer-s8-set!");
lf[35]=C_h_intern(&lf[35],16,"pointer-u16-set!");
lf[36]=C_h_intern(&lf[36],16,"pointer-s16-set!");
lf[37]=C_h_intern(&lf[37],16,"pointer-u32-set!");
lf[38]=C_h_intern(&lf[38],16,"pointer-s32-set!");
lf[39]=C_h_intern(&lf[39],16,"pointer-f32-set!");
lf[40]=C_h_intern(&lf[40],16,"pointer-f64-set!");
lf[41]=C_h_intern(&lf[41],14,"pointer-u8-ref");
lf[42]=C_h_intern(&lf[42],14,"pointer-s8-ref");
lf[43]=C_h_intern(&lf[43],15,"pointer-u16-ref");
lf[44]=C_h_intern(&lf[44],15,"pointer-s16-ref");
lf[45]=C_h_intern(&lf[45],15,"pointer-u32-ref");
lf[46]=C_h_intern(&lf[46],15,"pointer-s32-ref");
lf[47]=C_h_intern(&lf[47],15,"pointer-f32-ref");
lf[48]=C_h_intern(&lf[48],15,"pointer-f64-ref");
lf[49]=C_h_intern(&lf[49],11,"tag-pointer");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[51]=C_h_intern(&lf[51],23,"\003sysmake-tagged-pointer");
lf[52]=C_h_intern(&lf[52],15,"tagged-pointer\077");
lf[53]=C_h_intern(&lf[53],11,"pointer-tag");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[55]=C_h_intern(&lf[55],8,"extended");
lf[57]=C_h_intern(&lf[57],16,"extend-procedure");
lf[58]=C_h_intern(&lf[58],19,"\003sysdecorate-lambda");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[60]=C_h_intern(&lf[60],19,"extended-procedure\077");
lf[61]=C_h_intern(&lf[61],21,"\003syslambda-decoration");
lf[62]=C_h_intern(&lf[62],14,"procedure-data");
lf[63]=C_h_intern(&lf[63],19,"set-procedure-data!");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[65]=C_h_intern(&lf[65],12,"byte-vector\077");
lf[66]=C_h_intern(&lf[66],5,"blob\077");
lf[67]=C_h_intern(&lf[67],17,"byte-vector-fill!");
lf[68]=C_h_intern(&lf[68],16,"make-byte-vector");
lf[69]=C_h_intern(&lf[69],9,"make-blob");
lf[70]=C_h_intern(&lf[70],11,"byte-vector");
lf[71]=C_h_intern(&lf[71],16,"byte-vector-set!");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\014out of range");
lf[73]=C_h_intern(&lf[73],15,"byte-vector-ref");
lf[74]=C_h_intern(&lf[74],17,"byte-vector->list");
lf[75]=C_h_intern(&lf[75],17,"list->byte-vector");
lf[76]=C_h_intern(&lf[76],27,"\003sysnot-a-proper-list-error");
lf[77]=C_h_intern(&lf[77],19,"string->byte-vector");
lf[78]=C_h_intern(&lf[78],12,"string->blob");
lf[79]=C_h_intern(&lf[79],19,"byte-vector->string");
lf[80]=C_h_intern(&lf[80],12,"blob->string");
lf[81]=C_h_intern(&lf[81],18,"byte-vector-length");
lf[82]=C_h_intern(&lf[82],9,"blob-size");
lf[83]=C_h_intern(&lf[83],23,"make-static-byte-vector");
lf[84]=C_h_intern(&lf[84],13,"\000bounds-error");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\014out of range");
lf[86]=C_h_intern(&lf[86],14,"\000runtime-error");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\0000can not allocate statically allocated bytevector");
lf[88]=C_h_intern(&lf[88],27,"static-byte-vector->pointer");
lf[89]=C_h_intern(&lf[89],16,"\003sysmake-pointer");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\036can not coerce non-static blob");
lf[91]=C_h_intern(&lf[91],17,"byte-vector-move!");
lf[92]=C_h_intern(&lf[92],13,"make-locative");
lf[93]=C_h_intern(&lf[93],18,"byte-vector-append");
lf[94]=C_h_intern(&lf[94],10,"block-set!");
lf[95]=C_h_intern(&lf[95],14,"\003sysblock-set!");
lf[96]=C_h_intern(&lf[96],9,"block-ref");
lf[97]=C_h_intern(&lf[97],15,"number-of-slots");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\024slots not accessible");
lf[99]=C_h_intern(&lf[99],15,"number-of-bytes");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\0003can not compute number of bytes of immediate object");
lf[101]=C_h_intern(&lf[101],20,"make-record-instance");
lf[102]=C_h_intern(&lf[102],18,"\003sysmake-structure");
lf[103]=C_h_intern(&lf[103],16,"record-instance\077");
lf[104]=C_h_intern(&lf[104],14,"record->vector");
lf[105]=C_h_intern(&lf[105],15,"\003sysmake-vector");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a record structure");
lf[107]=C_h_intern(&lf[107],11,"make-vector");
lf[108]=C_h_intern(&lf[108],11,"object-copy");
lf[109]=C_h_intern(&lf[109],15,"object-evicted\077");
lf[110]=C_h_intern(&lf[110],12,"object-evict");
lf[111]=C_h_intern(&lf[111],15,"hash-table-set!");
lf[112]=C_h_intern(&lf[112],22,"hash-table-ref/default");
lf[113]=C_h_intern(&lf[113],15,"make-hash-table");
lf[114]=C_h_intern(&lf[114],3,"eq\077");
lf[115]=C_h_intern(&lf[115],14,"object-release");
lf[116]=C_h_intern(&lf[116],24,"object-evict-to-location");
lf[117]=C_h_intern(&lf[117],24,"\003sysset-pointer-address!");
lf[118]=C_h_intern(&lf[118],6,"signal");
lf[119]=C_h_intern(&lf[119],24,"make-composite-condition");
lf[120]=C_h_intern(&lf[120],23,"make-property-condition");
lf[121]=C_h_intern(&lf[121],5,"evict");
lf[122]=C_h_intern(&lf[122],5,"limit");
lf[123]=C_h_intern(&lf[123],3,"exn");
lf[124]=C_h_intern(&lf[124],8,"location");
lf[125]=C_h_intern(&lf[125],7,"message");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000%can not evict object - limit exceeded");
lf[127]=C_h_intern(&lf[127],9,"arguments");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[129]=C_h_intern(&lf[129],11,"object-size");
lf[130]=C_h_intern(&lf[130],14,"object-unevict");
lf[131]=C_h_intern(&lf[131],15,"\003sysmake-string");
lf[132]=C_h_intern(&lf[132],14,"object-become!");
lf[133]=C_h_intern(&lf[133],11,"\003sysbecome!");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - new item is immediate");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - old item is immediate");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not an a-list");
lf[137]=C_h_intern(&lf[137],16,"mutate-procedure");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[139]=C_h_intern(&lf[139],17,"\003sysmake-locative");
lf[140]=C_h_intern(&lf[140],18,"make-weak-locative");
lf[141]=C_h_intern(&lf[141],13,"locative-set!");
lf[142]=C_h_intern(&lf[142],12,"locative-ref");
lf[143]=C_h_intern(&lf[143],16,"locative->object");
lf[144]=C_h_intern(&lf[144],9,"locative\077");
lf[146]=C_h_intern(&lf[146],35,"set-invalid-procedure-call-handler!");
lf[147]=C_h_intern(&lf[147],31,"\003sysinvalid-procedure-call-hook");
lf[148]=C_h_intern(&lf[148],26,"\003syslast-invalid-procedure");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[150]=C_h_intern(&lf[150],22,"unbound-variable-value");
lf[151]=C_h_intern(&lf[151],31,"\003sysunbound-variable-value-hook");
lf[152]=C_h_intern(&lf[152],10,"global-ref");
lf[153]=C_h_intern(&lf[153],11,"global-set!");
lf[154]=C_h_intern(&lf[154],13,"global-bound\077");
lf[155]=C_h_intern(&lf[155],32,"\003syssymbol-has-toplevel-binding\077");
lf[156]=C_h_intern(&lf[156],20,"global-make-unbound!");
lf[157]=C_h_intern(&lf[157],28,"\003sysarbitrary-unbound-symbol");
lf[158]=C_h_intern(&lf[158],18,"getter-with-setter");
lf[159]=C_h_intern(&lf[159],13,"\003sysblock-ref");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\014out of range");
lf[161]=C_h_intern(&lf[161],15,"pointer-s6-set!");
lf[162]=C_h_intern(&lf[162],17,"register-feature!");
lf[163]=C_h_intern(&lf[163],7,"lolevel");
C_register_lf2(lf,164,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_723,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k721 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 83   register-feature! */
t3=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[163]);}

/* k724 in k721 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[74],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_726,2,t0,t1);}
t2=lf[2];
t3=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_840,a[2]=t2,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1167,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[15]+1,*((C_word*)lf[16]+1));
t6=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1223,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1253,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1262,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1269,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1285,a[2]=t15,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1317,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1387,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3125,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 203  getter-with-setter */
t28=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t28))(4,t28,t26,t27,*((C_word*)lf[33]+1));}

/* a3124 in k724 in k721 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3125,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub260(C_SCHEME_UNDEFINED,t3));}

/* k1443 in k724 in k721 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3115,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 208  getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[34]+1));}

/* a3114 in k1443 in k724 in k721 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3115,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub266(C_SCHEME_UNDEFINED,t3));}

/* k1447 in k1443 in k724 in k721 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3105,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 213  getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[35]+1));}

/* a3104 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3105,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub272(C_SCHEME_UNDEFINED,t3));}

/* k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3095,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 218  getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[161]+1));}

/* a3094 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3095,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub278(C_SCHEME_UNDEFINED,t3));}

/* k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1461,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3085,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 223  getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[37]+1));}

/* a3084 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3085,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub284(t3,t4));}

/* k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3075,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 228  getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[38]+1));}

/* a3074 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3075,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub291(t3,t4));}

/* k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 233  getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[39]+1));}

/* a3064 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3065,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub298(t3,t4));}

/* k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 238  getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[40]+1));}

/* a3054 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3055,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub305(t3,t4));}

/* k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1475,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1490,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1506,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t6=(C_word)C_a_i_vector(&a,1,lf[55]);
t7=C_mutate(&lf[56],t6);
t8=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1528,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1631,a[2]=t11,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t13=C_mutate((C_word*)lf[65]+1,*((C_word*)lf[66]+1));
t14=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1647,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 335  getter-with-setter */
t20=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t20))(4,t20,t18,t19,*((C_word*)lf[71]+1));}

/* a3024 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3025,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_bytevector_2(t2,lf[73]);
t5=(C_word)C_i_check_exact_2(t3,lf[73]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_lessp(t3,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t3,t6));
if(C_truep(t8)){
/* lolevel.scm: 341  ##sys#error */
t9=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[73],lf[160],t2,t3);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_subbyte(t2,t3));}}

/* k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[77]+1,*((C_word*)lf[78]+1));
t6=C_mutate((C_word*)lf[79]+1,*((C_word*)lf[80]+1));
t7=C_mutate((C_word*)lf[81]+1,*((C_word*)lf[82]+1));
t8=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[94]+1,*((C_word*)lf[95]+1));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 424  getter-with-setter */
t14=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,*((C_word*)lf[159]+1),*((C_word*)lf[95]+1));}

/* k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[58],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1,t1);
t3=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1991,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2012,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2034,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[107]+1);
t9=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2103,a[2]=t8,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2187,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2560,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2779,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2876,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 664  getter-with-setter */
t23=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,*((C_word*)lf[141]+1));}

/* k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=C_mutate((C_word*)lf[142]+1,t1);
t3=C_mutate((C_word*)lf[143]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[144]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t5=lf[145]=C_SCHEME_FALSE;;
t6=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2951,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[154]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3002,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[156]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3011,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3011,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[156]);
t4=(C_word)C_slot(lf[157],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3002,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[154]);
/* lolevel.scm: 699  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[155]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* global-set! in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2993,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[153]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2987,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[152]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2970r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2970r(t0,t1,t2);}}

static void C_ccall f_2970r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2975,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_2975(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_2975(t4,C_SCHEME_FALSE);}}

/* k2973 in unbound-variable-value in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2975(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[151]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* set-invalid-procedure-call-handler! in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2951,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2955,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t4=t3;
f_2955(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 675  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[146],lf[149],t2);}}

/* k2953 in set-invalid-procedure-call-handler! in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=C_mutate(&lf[145],((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[147]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k2953 in set-invalid-procedure-call-handler! in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2958r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2958r(t0,t1,t2);}}

static void C_ccall f_2958r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 679  ipc-hook-0 */
t3=lf[145];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,*((C_word*)lf[148]+1),t2);}

/* locative? in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2944,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k2937 in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2941,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2934,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2905r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2905r(t0,t1,t2,t3);}}

static void C_ccall f_2905r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2913,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2913(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2913(2,t6,(C_word)C_i_car(t3));}
else{
/* lolevel.scm: 661  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2911 in make-weak-locative in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 661  ##sys#make-locative */
t2=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[140]);}

/* make-locative in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2876r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2876r(t0,t1,t2,t3);}}

static void C_ccall f_2876r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2884,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2884(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2884(2,t6,(C_word)C_i_car(t3));}
else{
/* lolevel.scm: 658  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2882 in make-locative in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 658  ##sys#make-locative */
t2=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[92]);}

/* mutate-procedure in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2842,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2846,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t5=t4;
f_2846(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 647  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[137],lf[138],t2);}}

/* k2844 in mutate-procedure in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 650  make-vector */
t5=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2851 in k2844 in mutate-procedure in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2856,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2868,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 651  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2866 in k2851 in k2844 in mutate-procedure in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 651  ##sys#become! */
t4=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k2854 in k2851 in k2844 in mutate-procedure in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2779,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[132]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2786,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2791,a[2]=t6,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2791(t8,t4,t2);}

/* loop in object-become! in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2791(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2791,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_pair_2(t4,lf[132]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2813,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
if(C_truep((C_word)C_blockp(t7))){
t8=t6;
f_2813(2,t8,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 638  ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[7],lf[132],lf[135],t4);}}
else{
/* lolevel.scm: 642  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[7],lf[132],lf[136]);}}}

/* k2811 in loop in object-become! in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_blockp(t3))){
t4=t2;
f_2816(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 640  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[132],lf[134],((C_word*)t0)[2]);}}

/* k2814 in k2811 in loop in object-become! in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 641  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2791(t3,((C_word*)t0)[2],t2);}

/* k2784 in object-become! in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 643  ##sys#become! */
t2=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2644r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2644r(t0,t1,t2,t3);}}

static void C_ccall f_2644r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2648,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2648(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2648(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 599  make-hash-table */
t3=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[114]+1));}

/* k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2662,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2662(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2662,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 603  hash-table-ref/default */
t4=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 606  ##sys#make-string */
t4=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 611  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 616  make-vector */
t4=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2719 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 617  hash-table-set! */
t4=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2722 in k2719 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li82),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2733(t7,t2,t3);}

/* do577 in k2722 in k2719 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2733(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2733,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2754,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 620  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2662(t5,t3,t4);}}

/* k2752 in do577 in k2722 in k2719 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2733(t4,((C_word*)t0)[2],t3);}

/* k2725 in k2722 in k2719 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2705 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2710,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 612  hash-table-set! */
t3=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2708 in k2705 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2689 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2691,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 607  hash-table-set! */
t4=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2692 in k2689 in k2676 in copy in k2655 in k2646 in object-unevict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2564,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 576  make-hash-table */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[114]+1));}

/* k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2569,a[2]=t1,a[3]=t3,a[4]=((C_word)li80),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2569(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2569(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2569,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 579  hash-table-ref/default */
t4=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2580 in evict in k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 583  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2639(2,t4,(C_word)C_bytes(t2));}}}

/* k2637 in k2580 in evict in k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 585  hash-table-set! */
t6=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2589 in k2637 in k2580 in evict in k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2594(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li79),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2603(t9,t2,t5);}}

/* do548 in k2589 in k2637 in k2580 in evict in k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2603,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2625,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 592  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2569(t5,t3,t4);}}

/* k2623 in do548 in k2589 in k2637 in k2580 in evict in k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2603(t5,((C_word*)t0)[2],t4);}

/* k2592 in k2589 in k2637 in k2580 in evict in k2562 in object-size in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2390r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2390r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2390r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2394,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_2394(2,t7,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 531  ##sys#signal-hook */
t7=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[7],lf[116],lf[128],t3);}}

/* k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[116]);
t5=t2;
f_2397(t5,t3);}
else{
t3=t2;
f_2397(t3,C_SCHEME_FALSE);}}

/* k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2397,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 539  ##sys#pointer->address */
t6=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2537 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 539  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 540  make-hash-table */
t3=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[114]+1));}

/* k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li77),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2411(t6,t2,((C_word*)t0)[2]);}

/* evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2411,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 544  hash-table-ref/default */
t4=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 548  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2532(2,t4,(C_word)C_bytes(t2));}}}

/* k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2433,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 555  make-property-condition */
t9=*((C_word*)lf[120]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[123],lf[124],lf[116],lf[125],lf[126],lf[127],t8);}
else{
t6=t3;
f_2433(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2433(2,t4,C_SCHEME_UNDEFINED);}}

/* k2518 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2524,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 559  make-property-condition */
t3=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[121],lf[122],((C_word*)((C_word*)t0)[2])[1]);}

/* k2522 in k2518 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 554  make-composite-condition */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2514 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 553  signal */
t2=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2431 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[8]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 562  ##sys#pointer->address */
t7=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[7]);}

/* k2491 in k2431 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 562  ##sys#set-pointer-address! */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2437 in k2431 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 563  hash-table-set! */
t3=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2440 in k2437 in k2431 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2445(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li76),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2454(t9,t2,t5);}}

/* do528 in k2440 in k2437 in k2431 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2454,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2475,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 570  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2411(t5,t3,t4);}}

/* k2473 in do528 in k2440 in k2437 in k2431 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2454(t4,((C_word*)t0)[2],t3);}

/* k2443 in k2440 in k2437 in k2431 in k2530 in k2419 in evict in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2404 in k2401 in k2398 in k2395 in k2392 in object-evict-to-location in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 572  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-release in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2298r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2298r(t0,t1,t2,t3);}}

static void C_ccall f_2298r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2307,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2307(t11,t1,t2);}

/* release in object-release in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2307,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2336,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_2336(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li73),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2352(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* do503 in release in object-release in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2352,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2362,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 523  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2307(t5,t3,t4);}}

/* k2360 in do503 in release in object-release in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2352(t3,((C_word*)t0)[2],t2);}

/* k2334 in release in object-release in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 524  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2341 in k2334 in release in object-release in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 524  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2380 in object-release in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2380,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub495(C_SCHEME_UNDEFINED,t3));}

/* object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2187r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2187r(t0,t1,t2,t3);}}

static void C_ccall f_2187r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2194,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 490  make-hash-table */
t7=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[114]+1));}

/* k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word)li70),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2199(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2199,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 493  hash-table-ref/default */
t4=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2207 in evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 496  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2218(2,t4,(C_word)C_bytes(t2));}}}

/* k2216 in k2207 in evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 497  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2220 in k2216 in k2207 in evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2222,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(C_word)C_i_symbolp(((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 499  hash-table-set! */
t6=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2226 in k2220 in k2216 in k2207 in evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2231(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li69),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2240(t9,t2,t5);}}

/* do479 in k2226 in k2220 in k2216 in k2207 in evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2240(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2240,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2261,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 504  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2199(t5,t3,t4);}}

/* k2259 in do479 in k2226 in k2220 in k2216 in k2207 in evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2240(t4,((C_word*)t0)[2],t3);}

/* k2229 in k2226 in k2220 in k2216 in k2207 in evict in k2192 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2291 in object-evict in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2291,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub468(t3,t4));}

/* object-evicted? in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2184,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* object-copy in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2103,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2109(t6,t1,t2);}

/* copy in object-copy in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2109,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 468  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 472  make-vector */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2137 in copy in object-copy in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_2142(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_2154(t10,t3,t6);}}

/* do455 in k2137 in copy in object-copy in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2154(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2154,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2175,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 476  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2109(t5,t3,t4);}}

/* k2173 in do455 in k2137 in copy in object-copy in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2154(t4,((C_word*)t0)[2],t3);}

/* k2140 in k2137 in copy in object-copy in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* record->vector in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2049,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_structurep(t2));
if(C_truep(t4)){
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2062,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 454  ##sys#make-vector */
t7=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
/* lolevel.scm: 458  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[7],lf[104],lf[106],t2);}}

/* k2060 in record->vector in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2067(t2,C_fix(0)));}

/* do441 in k2060 in record->vector in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static C_word C_fcall f_2067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance? in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2043,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE));}

/* make-record-instance in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2034r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2034r(t0,t1,t2,t3);}}

static void C_ccall f_2034r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[101]);
C_apply(5,0,t1,*((C_word*)lf[102]+1),t2,t3);}

/* number-of-bytes in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2012,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 436  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[99],lf[100],t2);}}

/* number-of-slots in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1991,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1995,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2004(t6,t4);}
else{
t6=(C_word)C_specialp(t2);
t7=t5;
f_2004(t7,(C_truep(t6)?t6:(C_word)C_byteblockp(t2)));}}

/* k2002 in number-of-slots in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_2004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* lolevel.scm: 431  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[7],lf[97],lf[98],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1995(2,t2,C_SCHEME_UNDEFINED);}}

/* k1993 in number-of-slots in k1987 in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* byte-vector-append in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1948r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1948r(t0,t1,t2);}}

static void C_ccall f_1948r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1951,a[2]=t4,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
/* lolevel.scm: 418  append-rest-at */
t6=((C_word*)t4)[1];
f_1951(t6,t1,C_fix(0),t2);}

/* append-rest-at in byte-vector-append in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_1951(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1951,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 413  byte-vector-length */
t6=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
/* lolevel.scm: 417  make-byte-vector */
t4=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k1962 in append-rest-at in byte-vector-append in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* lolevel.scm: 414  append-rest-at */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1951(t5,t2,t3,t4);}

/* k1965 in k1962 in append-rest-at in byte-vector-append in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 415  byte-vector-move! */
t3=*((C_word*)lf[91]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1968 in k1965 in k1962 in append-rest-at in byte-vector-append in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* byte-vector-move! in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1932,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1936,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 405  make-locative */
t8=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t2,t3);}

/* k1934 in byte-vector-move! in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1939,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 406  make-locative */
t3=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1937 in k1934 in byte-vector-move! in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* lolevel.scm: 407  move-memory! */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* static-byte-vector->pointer in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1917,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[88]);
if(C_truep((C_word)C_permanentp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1927,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 399  ##sys#make-pointer */
t5=*((C_word*)lf[89]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* lolevel.scm: 402  ##sys#error */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[88],lf[90],t2);}}

/* k1925 in static-byte-vector->pointer in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_pointer_to_block(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* make-static-byte-vector in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1911r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1911r(t0,t1,t2,t3);}}

static void C_ccall f_1911r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,lf[83]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix((C_word)C_HEADER_SIZE_MASK)))){
/* lolevel.scm: 386  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[84],lf[83],lf[85],t2,C_fix((C_word)C_HEADER_SIZE_MASK));}
else{
t5=t2;
t6=(C_word)C_i_foreign_fixnum_argumentp(t5);
t7=(C_word)stub393(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
/* lolevel.scm: 389  byte-vector-fill! */
t10=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t7,t9);}
else{
t9=t8;
f_1896(2,t9,C_SCHEME_UNDEFINED);}}
else{
/* lolevel.scm: 391  ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[86],lf[87],t2);}}}

/* k1894 in make-static-byte-vector in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->byte-vector in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1812,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[75]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1822,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 358  make-byte-vector */
t6=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1820 in list->byte-vector in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1827(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do382 in k1820 in list->byte-vector in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_1827(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1827,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1837,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[75]);
t8=t5;
f_1837(2,t8,(C_word)C_setbyte(((C_word*)t0)[4],t3,t6));}
else{
/* lolevel.scm: 366  ##sys#not-a-proper-list-error */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}}

/* k1835 in do382 in k1820 in list->byte-vector in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1827(t4,((C_word*)t0)[2],t2,t3);}

/* byte-vector->list in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1776,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[74]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1788,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1788(t8,t1,C_fix(0));}

/* loop in byte-vector->list in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_fcall f_1788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1788,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_subbyte(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1806,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
/* lolevel.scm: 352  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k1804 in loop in byte-vector->list in k1772 in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* byte-vector-set! in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1739,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_bytevector_2(t2,lf[71]);
t6=(C_word)C_i_check_exact_2(t3,lf[71]);
t7=(C_word)C_i_check_exact_2(t4,lf[71]);
t8=(C_word)C_block_size(t2);
t9=(C_word)C_fixnum_lessp(t3,C_fix(0));
t10=(C_truep(t9)?t9:(C_word)C_fixnum_greater_or_equal_p(t3,t8));
if(C_truep(t10)){
/* lolevel.scm: 331  ##sys#error */
t11=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t1,lf[71],lf[72],t2,t3);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_setbyte(t2,t3,t4));}}

/* byte-vector in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1700r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1700r(t0,t1,t2);}}

static void C_ccall f_1700r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1707,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 318  make-byte-vector */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1705 in byte-vector in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1712,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1712(t2,C_fix(0),((C_word*)t0)[2]));}

/* do351 in k1705 in byte-vector in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static C_word C_fcall f_1712(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_setbyte(((C_word*)t0)[2],t1,t3);
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* make-byte-vector in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1681r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1681r(t0,t1,t2,t3);}}

static void C_ccall f_1681r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1685,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 311  make-blob */
t5=*((C_word*)lf[69]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1683 in make-byte-vector in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1688,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* lolevel.scm: 312  byte-vector-fill! */
t4=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}
else{
t3=t2;
f_1688(2,t3,C_SCHEME_UNDEFINED);}}

/* k1686 in k1683 in make-byte-vector in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* byte-vector-fill! in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1647,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_bytevector_2(t2,lf[67]);
t5=(C_word)C_i_check_exact_2(t3,lf[67]);
t6=(C_word)C_block_size(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1662,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_1662(t7,C_fix(0)));}

/* do337 in byte-vector-fill! in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static C_word C_fcall f_1662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_setbyte(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* set-procedure-data! in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1631,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1635,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 291  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k1633 in set-procedure-data! in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 294  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[7],lf[63],lf[64],((C_word*)t0)[3]);}}

/* procedure-data in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1597,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1607,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1615,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 285  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1614 in procedure-data in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1615,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1605 in procedure-data in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1566,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1581,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 279  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1580 in extended-procedure? in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1581,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1577 in extended-procedure? in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1528,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1532,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_closurep(t2))){
t5=t4;
f_1532(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 268  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[57],lf[59],t2);}}

/* k1530 in extend-procedure in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1537,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[4],a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 269  ##sys#decorate-lambda */
t4=*((C_word*)lf[58]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1552 in k1530 in extend-procedure in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1553,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[56],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a1536 in k1530 in extend-procedure in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1537,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-tag in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1506,3,t0,t1,t2);}
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 258  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[53],lf[54],t2);}}

/* tagged-pointer? in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1490,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_equalp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* tag-pointer in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1475,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1479,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 243  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1477 in tag-pointer in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1482,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_blockp(((C_word*)t0)[2]))?(C_word)C_specialp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1482(2,t4,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 246  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[49],lf[50],((C_word*)t0)[2]);}}

/* k1480 in k1477 in tag-pointer in k1471 in k1467 in k1463 in k1459 in k1455 in k1451 in k1447 in k1443 in k724 in k721 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pointer-f64-set! in k724 in k721 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1429,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub253(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-f32-set! in k724 in k721 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1415,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub245(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s32-set! in k724 in k721 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1401,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub237(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u32-set! in k724 in k721 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1387,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub229(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s16-set! in k724 in k721 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1373,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub221(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u16-set! in k724 in k721 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1359,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub213(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s8-set! in k724 in k721 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1345,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub205(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u8-set! in k724 in k721 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1331,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub197(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-offset in k724 in k721 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1317,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub188(t4,t5,t6));}

/* align-to-word in k724 in k721 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1285,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
/* lolevel.scm: 184  align */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,f_1279(C_a_i(&a,6),t2));}
else{
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1312,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 186  ##sys#pointer->address */
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* lolevel.scm: 187  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[30],lf[31],t2);}}}

/* k1310 in align-to-word in k724 in k721 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=f_1279(C_a_i(&a,6),t1);
/* lolevel.scm: 186  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k724 in k721 */
static C_word C_fcall f_1279(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
return((C_word)stub181(t2,t3));}

/* free in k724 in k721 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1269,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub174(C_SCHEME_UNDEFINED,t3));}

/* allocate in k724 in k721 */
static void C_ccall f_1262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1262,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub169(t3,t4));}

/* pointer=? in k724 in k721 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1253,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1257,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 174  ##sys#check-special */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[27]);}

/* k1255 in pointer=? in k724 in k721 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 175  ##sys#check-special */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[27]);}

/* k1258 in k1255 in pointer=? in k724 in k721 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k724 in k721 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1247,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1251,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 170  ##sys#check-pointer */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[26]);}

/* k1249 in pointer->object in k724 in k721 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k724 in k721 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1236,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1244,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1244 in object->pointer in k724 in k721 */
static void C_ccall f_1244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1244,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub158(t3,t2));}

/* null-pointer? in k724 in k721 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1223,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1227,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 160  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[24]);}

/* k1225 in null-pointer? in k724 in k721 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 161  ##sys#pointer->address */
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1232 in k1225 in null-pointer? in k724 in k721 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k724 in k721 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1214,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1218,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 156  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[21]);}

/* k1216 in pointer->address in k724 in k721 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 157  ##sys#pointer->address */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k724 in k721 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1195,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1199,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_integerp(t2))){
t4=t3;
f_1199(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 151  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[18],lf[20],t2);}}

/* k1197 in address->pointer in k724 in k721 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 153  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer? in k724 in k721 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1186,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_pointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_taggedpointerp(t2)));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#check-pointer in k724 in k721 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1167,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1174,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t2))){
t5=(C_word)C_pointerp(t2);
if(C_truep(t5)){
t6=t4;
f_1174(t6,t5);}
else{
t6=(C_word)C_swigpointerp(t2);
t7=t4;
f_1174(t7,(C_truep(t6)?t6:(C_word)C_taggedpointerp(t2)));}}
else{
t5=t4;
f_1174(t5,C_SCHEME_FALSE);}}

/* k1172 in ##sys#check-pointer in k724 in k721 */
static void C_fcall f_1174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 138  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],lf[14],((C_word*)t0)[2]);}}

/* move-memory! in k724 in k721 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_840r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_840r(t0,t1,t2,t3,t4);}}

static void C_ccall f_840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_842,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1094,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1099,a[2]=t6,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1104,a[2]=t7,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n78133 */
t9=t8;
f_1104(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset79131 */
t11=t7;
f_1099(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset80128 */
t13=t6;
f_1094(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body7682 */
t15=t5;
f_842(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n78 in move-memory! in k724 in k721 */
static void C_fcall f_1104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1104,NULL,2,t0,t1);}
/* def-foffset79131 */
t2=((C_word*)t0)[2];
f_1099(t2,t1,C_SCHEME_FALSE);}

/* def-foffset79 in move-memory! in k724 in k721 */
static void C_fcall f_1099(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1099,NULL,3,t0,t1,t2);}
/* def-toffset80128 */
t3=((C_word*)t0)[2];
f_1094(t3,t1,t2,C_fix(0));}

/* def-toffset80 in move-memory! in k724 in k721 */
static void C_fcall f_1094(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1094,NULL,4,t0,t1,t2,t3);}
/* body7682 */
t4=((C_word*)t0)[2];
f_842(t4,t1,t2,t3,C_fix(0));}

/* body76 in move-memory! in k724 in k721 */
static void C_fcall f_842(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_842,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_851,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_902,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t2,a[8]=t6,a[9]=t10,a[10]=((C_word*)t0)[2],a[11]=((C_word)li4),tmp=(C_word)a,a+=12,tmp));
t12=((C_word*)t10)[1];
f_902(t12,t1,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* move in body76 in move-memory! in k724 in k721 */
static void C_fcall f_902(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_902,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 108  move */
t11=t1;
t12=t5;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 109  xerr */
f_851(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 112  move */
t11=t1;
t12=t2;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 113  xerr */
f_851(t1,t3);}}
else{
t4=(C_word)C_pointerp(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_964(2,t6,t4);}
else{
/* lolevel.scm: 114  ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}}

/* k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_pointerp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_973(2,t4,t2);}
else{
/* lolevel.scm: 115  ##sys#locative? */
t4=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 120  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k1023 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=(C_word)C_pointerp(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_1040(2,t6,t4);}
else{
/* lolevel.scm: 122  ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 128  xerr */
f_851(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k1038 in k1023 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:((C_word*)t0)[5]);
/* lolevel.scm: 123  checkn */
t5=((C_word*)t0)[4];
f_857(t5,t2,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 124  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}}

/* k1055 in k1038 in k1023 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 125  checkn2 */
t7=((C_word*)t0)[3];
f_873(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 127  xerr */
f_851(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1065 in k1055 in k1038 in k1023 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub58(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1045 in k1038 in k1023 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub26(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k971 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_980(2,t4,t2);}
else{
/* lolevel.scm: 116  err */
t4=((C_word*)t0)[4];
f_845(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 117  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k987 in k971 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1003,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1003(2,t6,t4);}
else{
/* lolevel.scm: 118  err */
t6=((C_word*)t0)[3];
f_845(t6,t5);}}
else{
/* lolevel.scm: 119  xerr */
f_851(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1001 in k987 in k971 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 118  checkn */
t3=((C_word*)t0)[4];
f_857(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k997 in k987 in k971 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub42(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k978 in k971 in k962 in move in body76 in move-memory! in k724 in k721 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub10(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body76 in move-memory! in k724 in k721 */
static void C_fcall f_873(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_873,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_880,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_fixnum_difference(t4,t6);
t10=t7;
f_880(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_880(t9,C_SCHEME_FALSE);}}

/* k878 in checkn2 in body76 in move-memory! in k724 in k721 */
static void C_fcall f_880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* lolevel.scm: 104  ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[7],lf[3],lf[10],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* checkn in body76 in move-memory! in k724 in k721 */
static void C_fcall f_857(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_857,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 100  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t6+1)))(8,t6,t1,lf[3],lf[9],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}}

/* xerr in body76 in move-memory! in k724 in k721 */
static void C_fcall f_851(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_851,NULL,2,t1,t2);}
/* lolevel.scm: 96   ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[3],lf[8],t2);}

/* err in body76 in move-memory! in k724 in k721 */
static void C_fcall f_845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_845,NULL,2,t0,t1);}
/* lolevel.scm: 95   ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[3],lf[5],((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[225] = {
{"toplevellolevel.scm",(void*)C_lolevel_toplevel},
{"f_723lolevel.scm",(void*)f_723},
{"f_726lolevel.scm",(void*)f_726},
{"f_3125lolevel.scm",(void*)f_3125},
{"f_1445lolevel.scm",(void*)f_1445},
{"f_3115lolevel.scm",(void*)f_3115},
{"f_1449lolevel.scm",(void*)f_1449},
{"f_3105lolevel.scm",(void*)f_3105},
{"f_1453lolevel.scm",(void*)f_1453},
{"f_3095lolevel.scm",(void*)f_3095},
{"f_1457lolevel.scm",(void*)f_1457},
{"f_3085lolevel.scm",(void*)f_3085},
{"f_1461lolevel.scm",(void*)f_1461},
{"f_3075lolevel.scm",(void*)f_3075},
{"f_1465lolevel.scm",(void*)f_1465},
{"f_3065lolevel.scm",(void*)f_3065},
{"f_1469lolevel.scm",(void*)f_1469},
{"f_3055lolevel.scm",(void*)f_3055},
{"f_1473lolevel.scm",(void*)f_1473},
{"f_3025lolevel.scm",(void*)f_3025},
{"f_1774lolevel.scm",(void*)f_1774},
{"f_1989lolevel.scm",(void*)f_1989},
{"f_2939lolevel.scm",(void*)f_2939},
{"f_3011lolevel.scm",(void*)f_3011},
{"f_3002lolevel.scm",(void*)f_3002},
{"f_2993lolevel.scm",(void*)f_2993},
{"f_2987lolevel.scm",(void*)f_2987},
{"f_2970lolevel.scm",(void*)f_2970},
{"f_2975lolevel.scm",(void*)f_2975},
{"f_2951lolevel.scm",(void*)f_2951},
{"f_2955lolevel.scm",(void*)f_2955},
{"f_2958lolevel.scm",(void*)f_2958},
{"f_2944lolevel.scm",(void*)f_2944},
{"f_2941lolevel.scm",(void*)f_2941},
{"f_2934lolevel.scm",(void*)f_2934},
{"f_2905lolevel.scm",(void*)f_2905},
{"f_2913lolevel.scm",(void*)f_2913},
{"f_2876lolevel.scm",(void*)f_2876},
{"f_2884lolevel.scm",(void*)f_2884},
{"f_2842lolevel.scm",(void*)f_2842},
{"f_2846lolevel.scm",(void*)f_2846},
{"f_2853lolevel.scm",(void*)f_2853},
{"f_2868lolevel.scm",(void*)f_2868},
{"f_2856lolevel.scm",(void*)f_2856},
{"f_2779lolevel.scm",(void*)f_2779},
{"f_2791lolevel.scm",(void*)f_2791},
{"f_2813lolevel.scm",(void*)f_2813},
{"f_2816lolevel.scm",(void*)f_2816},
{"f_2786lolevel.scm",(void*)f_2786},
{"f_2644lolevel.scm",(void*)f_2644},
{"f_2648lolevel.scm",(void*)f_2648},
{"f_2657lolevel.scm",(void*)f_2657},
{"f_2662lolevel.scm",(void*)f_2662},
{"f_2678lolevel.scm",(void*)f_2678},
{"f_2721lolevel.scm",(void*)f_2721},
{"f_2724lolevel.scm",(void*)f_2724},
{"f_2733lolevel.scm",(void*)f_2733},
{"f_2754lolevel.scm",(void*)f_2754},
{"f_2727lolevel.scm",(void*)f_2727},
{"f_2707lolevel.scm",(void*)f_2707},
{"f_2710lolevel.scm",(void*)f_2710},
{"f_2691lolevel.scm",(void*)f_2691},
{"f_2694lolevel.scm",(void*)f_2694},
{"f_2560lolevel.scm",(void*)f_2560},
{"f_2564lolevel.scm",(void*)f_2564},
{"f_2569lolevel.scm",(void*)f_2569},
{"f_2582lolevel.scm",(void*)f_2582},
{"f_2639lolevel.scm",(void*)f_2639},
{"f_2591lolevel.scm",(void*)f_2591},
{"f_2603lolevel.scm",(void*)f_2603},
{"f_2625lolevel.scm",(void*)f_2625},
{"f_2594lolevel.scm",(void*)f_2594},
{"f_2390lolevel.scm",(void*)f_2390},
{"f_2394lolevel.scm",(void*)f_2394},
{"f_2397lolevel.scm",(void*)f_2397},
{"f_2539lolevel.scm",(void*)f_2539},
{"f_2400lolevel.scm",(void*)f_2400},
{"f_2403lolevel.scm",(void*)f_2403},
{"f_2411lolevel.scm",(void*)f_2411},
{"f_2421lolevel.scm",(void*)f_2421},
{"f_2532lolevel.scm",(void*)f_2532},
{"f_2520lolevel.scm",(void*)f_2520},
{"f_2524lolevel.scm",(void*)f_2524},
{"f_2516lolevel.scm",(void*)f_2516},
{"f_2433lolevel.scm",(void*)f_2433},
{"f_2493lolevel.scm",(void*)f_2493},
{"f_2439lolevel.scm",(void*)f_2439},
{"f_2442lolevel.scm",(void*)f_2442},
{"f_2454lolevel.scm",(void*)f_2454},
{"f_2475lolevel.scm",(void*)f_2475},
{"f_2445lolevel.scm",(void*)f_2445},
{"f_2406lolevel.scm",(void*)f_2406},
{"f_2298lolevel.scm",(void*)f_2298},
{"f_2307lolevel.scm",(void*)f_2307},
{"f_2352lolevel.scm",(void*)f_2352},
{"f_2362lolevel.scm",(void*)f_2362},
{"f_2336lolevel.scm",(void*)f_2336},
{"f_2343lolevel.scm",(void*)f_2343},
{"f_2380lolevel.scm",(void*)f_2380},
{"f_2187lolevel.scm",(void*)f_2187},
{"f_2194lolevel.scm",(void*)f_2194},
{"f_2199lolevel.scm",(void*)f_2199},
{"f_2209lolevel.scm",(void*)f_2209},
{"f_2218lolevel.scm",(void*)f_2218},
{"f_2222lolevel.scm",(void*)f_2222},
{"f_2228lolevel.scm",(void*)f_2228},
{"f_2240lolevel.scm",(void*)f_2240},
{"f_2261lolevel.scm",(void*)f_2261},
{"f_2231lolevel.scm",(void*)f_2231},
{"f_2291lolevel.scm",(void*)f_2291},
{"f_2184lolevel.scm",(void*)f_2184},
{"f_2103lolevel.scm",(void*)f_2103},
{"f_2109lolevel.scm",(void*)f_2109},
{"f_2139lolevel.scm",(void*)f_2139},
{"f_2154lolevel.scm",(void*)f_2154},
{"f_2175lolevel.scm",(void*)f_2175},
{"f_2142lolevel.scm",(void*)f_2142},
{"f_2049lolevel.scm",(void*)f_2049},
{"f_2062lolevel.scm",(void*)f_2062},
{"f_2067lolevel.scm",(void*)f_2067},
{"f_2043lolevel.scm",(void*)f_2043},
{"f_2034lolevel.scm",(void*)f_2034},
{"f_2012lolevel.scm",(void*)f_2012},
{"f_1991lolevel.scm",(void*)f_1991},
{"f_2004lolevel.scm",(void*)f_2004},
{"f_1995lolevel.scm",(void*)f_1995},
{"f_1948lolevel.scm",(void*)f_1948},
{"f_1951lolevel.scm",(void*)f_1951},
{"f_1964lolevel.scm",(void*)f_1964},
{"f_1967lolevel.scm",(void*)f_1967},
{"f_1970lolevel.scm",(void*)f_1970},
{"f_1932lolevel.scm",(void*)f_1932},
{"f_1936lolevel.scm",(void*)f_1936},
{"f_1939lolevel.scm",(void*)f_1939},
{"f_1917lolevel.scm",(void*)f_1917},
{"f_1927lolevel.scm",(void*)f_1927},
{"f_1911lolevel.scm",(void*)f_1911},
{"f_1896lolevel.scm",(void*)f_1896},
{"f_1812lolevel.scm",(void*)f_1812},
{"f_1822lolevel.scm",(void*)f_1822},
{"f_1827lolevel.scm",(void*)f_1827},
{"f_1837lolevel.scm",(void*)f_1837},
{"f_1776lolevel.scm",(void*)f_1776},
{"f_1788lolevel.scm",(void*)f_1788},
{"f_1806lolevel.scm",(void*)f_1806},
{"f_1739lolevel.scm",(void*)f_1739},
{"f_1700lolevel.scm",(void*)f_1700},
{"f_1707lolevel.scm",(void*)f_1707},
{"f_1712lolevel.scm",(void*)f_1712},
{"f_1681lolevel.scm",(void*)f_1681},
{"f_1685lolevel.scm",(void*)f_1685},
{"f_1688lolevel.scm",(void*)f_1688},
{"f_1647lolevel.scm",(void*)f_1647},
{"f_1662lolevel.scm",(void*)f_1662},
{"f_1631lolevel.scm",(void*)f_1631},
{"f_1635lolevel.scm",(void*)f_1635},
{"f_1597lolevel.scm",(void*)f_1597},
{"f_1615lolevel.scm",(void*)f_1615},
{"f_1607lolevel.scm",(void*)f_1607},
{"f_1566lolevel.scm",(void*)f_1566},
{"f_1581lolevel.scm",(void*)f_1581},
{"f_1579lolevel.scm",(void*)f_1579},
{"f_1528lolevel.scm",(void*)f_1528},
{"f_1532lolevel.scm",(void*)f_1532},
{"f_1553lolevel.scm",(void*)f_1553},
{"f_1537lolevel.scm",(void*)f_1537},
{"f_1506lolevel.scm",(void*)f_1506},
{"f_1490lolevel.scm",(void*)f_1490},
{"f_1475lolevel.scm",(void*)f_1475},
{"f_1479lolevel.scm",(void*)f_1479},
{"f_1482lolevel.scm",(void*)f_1482},
{"f_1429lolevel.scm",(void*)f_1429},
{"f_1415lolevel.scm",(void*)f_1415},
{"f_1401lolevel.scm",(void*)f_1401},
{"f_1387lolevel.scm",(void*)f_1387},
{"f_1373lolevel.scm",(void*)f_1373},
{"f_1359lolevel.scm",(void*)f_1359},
{"f_1345lolevel.scm",(void*)f_1345},
{"f_1331lolevel.scm",(void*)f_1331},
{"f_1317lolevel.scm",(void*)f_1317},
{"f_1285lolevel.scm",(void*)f_1285},
{"f_1312lolevel.scm",(void*)f_1312},
{"f_1279lolevel.scm",(void*)f_1279},
{"f_1269lolevel.scm",(void*)f_1269},
{"f_1262lolevel.scm",(void*)f_1262},
{"f_1253lolevel.scm",(void*)f_1253},
{"f_1257lolevel.scm",(void*)f_1257},
{"f_1260lolevel.scm",(void*)f_1260},
{"f_1247lolevel.scm",(void*)f_1247},
{"f_1251lolevel.scm",(void*)f_1251},
{"f_1236lolevel.scm",(void*)f_1236},
{"f_1244lolevel.scm",(void*)f_1244},
{"f_1223lolevel.scm",(void*)f_1223},
{"f_1227lolevel.scm",(void*)f_1227},
{"f_1234lolevel.scm",(void*)f_1234},
{"f_1214lolevel.scm",(void*)f_1214},
{"f_1218lolevel.scm",(void*)f_1218},
{"f_1195lolevel.scm",(void*)f_1195},
{"f_1199lolevel.scm",(void*)f_1199},
{"f_1186lolevel.scm",(void*)f_1186},
{"f_1167lolevel.scm",(void*)f_1167},
{"f_1174lolevel.scm",(void*)f_1174},
{"f_840lolevel.scm",(void*)f_840},
{"f_1104lolevel.scm",(void*)f_1104},
{"f_1099lolevel.scm",(void*)f_1099},
{"f_1094lolevel.scm",(void*)f_1094},
{"f_842lolevel.scm",(void*)f_842},
{"f_902lolevel.scm",(void*)f_902},
{"f_964lolevel.scm",(void*)f_964},
{"f_1025lolevel.scm",(void*)f_1025},
{"f_1040lolevel.scm",(void*)f_1040},
{"f_1057lolevel.scm",(void*)f_1057},
{"f_1067lolevel.scm",(void*)f_1067},
{"f_1047lolevel.scm",(void*)f_1047},
{"f_973lolevel.scm",(void*)f_973},
{"f_989lolevel.scm",(void*)f_989},
{"f_1003lolevel.scm",(void*)f_1003},
{"f_999lolevel.scm",(void*)f_999},
{"f_980lolevel.scm",(void*)f_980},
{"f_873lolevel.scm",(void*)f_873},
{"f_880lolevel.scm",(void*)f_880},
{"f_857lolevel.scm",(void*)f_857},
{"f_851lolevel.scm",(void*)f_851},
{"f_845lolevel.scm",(void*)f_845},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
