#ifndef $include-guard$
#define $include-guard$

#include <sagittarius.h>

#endif /*  $include-guard$ */
