/* Generated automatically from ../boot/compiler-aux.scm. DO NOT EDIT! */
#define LIBSAGITTARIUS_BODY 
#include <sagittarius.h>
static struct sg__rc_cgen17780Rec {
  SgObject d17804[115];
  SgWord d17805[102];
  SgCodeBuilder d17806[2];
} sg__rc_cgen17780 = {
  {  /* SgObject d17804 */
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
  },
  {  /* SgWord d17805 */
    /* ensure-library-name */0x00000045    /*   0 LREF_PUSH */,
    0x00000003    /*   1 CONST */,
    SG_WORD(SG_UNDEF) /* null */,
    0x00000020    /*   3 BNEQV */,
    SG_WORD(3),
    0x00000061    /*   5 CONST_RET */,
    SG_WORD(SG_UNDEF) /* (core) */,
    0x00000045    /*   7 LREF_PUSH */,
    0x00000003    /*   8 CONST */,
    SG_WORD(SG_UNDEF) /* sagittarius */,
    0x00000020    /*  10 BNEQV */,
    SG_WORD(3),
    0x00000061    /*  12 CONST_RET */,
    SG_WORD(SG_UNDEF) /* (sagittarius) */,
    0x00000045    /*  14 LREF_PUSH */,
    0x00000003    /*  15 CONST */,
    SG_WORD(SG_UNDEF) /* base */,
    0x00000020    /*  17 BNEQV */,
    SG_WORD(3),
    0x00000061    /*  19 CONST_RET */,
    SG_WORD(SG_UNDEF) /* (core base) */,
    0x00000045    /*  21 LREF_PUSH */,
    0x00000003    /*  22 CONST */,
    SG_WORD(SG_UNDEF) /* r6rs-script */,
    0x00000020    /*  24 BNEQV */,
    SG_WORD(3),
    0x00000061    /*  26 CONST_RET */,
    SG_WORD(SG_UNDEF) /* (r6rs-script) */,
    0x00000048    /*  28 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* ensure-library-name */,
    0x00000048    /*  30 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* invalid library tag: */,
    0x00000045    /*  32 LREF_PUSH */,
    0x0000034b    /*  33 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#sagittarius.compiler.util> */,
    0x0000002f    /*  35 RET */,
    /* #f */0x00000034    /*   0 LIBRARY */,
    SG_WORD(SG_UNDEF) /* #<library sagittarius.compiler.util> */,
    0x00000029    /*   2 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17780.d17806[0])) /* #<code-builder ensure-library-name (1 0 0)> */,
    0x00000033    /*   4 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier ensure-library-name#sagittarius.compiler.util> */,
    0x00000003    /*   6 CONST */,
    SG_WORD(SG_UNDEF) /* (($UNDEF . 0) ($DEFINE . 1) ($LREF . 2) ($LSET . 3) ($GREF . 4) ($GSET . 5) ($CONST . 6) ($IF . 7) ($LET . 8) ($LAMBDA . 9) ($RECEIVE . 10) ($LABEL . 11) ($SEQ . 12) ($CALL . 13) ($ASM . 14) ($IT . 15) ($LIST . 16) ($LIBRARY . 17)) */,
    0x00000133    /*   8 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier .intermediate-tags.#sagittarius.compiler.util> */,
    0x00000004    /*  10 CONSTI */,
    0x00000133    /*  11 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $UNDEF#sagittarius.compiler.util> */,
    0x00000104    /*  13 CONSTI */,
    0x00000133    /*  14 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $DEFINE#sagittarius.compiler.util> */,
    0x00000204    /*  16 CONSTI */,
    0x00000133    /*  17 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $LREF#sagittarius.compiler.util> */,
    0x00000304    /*  19 CONSTI */,
    0x00000133    /*  20 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $LSET#sagittarius.compiler.util> */,
    0x00000404    /*  22 CONSTI */,
    0x00000133    /*  23 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $GREF#sagittarius.compiler.util> */,
    0x00000504    /*  25 CONSTI */,
    0x00000133    /*  26 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $GSET#sagittarius.compiler.util> */,
    0x00000604    /*  28 CONSTI */,
    0x00000133    /*  29 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $CONST#sagittarius.compiler.util> */,
    0x00000704    /*  31 CONSTI */,
    0x00000133    /*  32 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $IF#sagittarius.compiler.util> */,
    0x00000804    /*  34 CONSTI */,
    0x00000133    /*  35 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $LET#sagittarius.compiler.util> */,
    0x00000904    /*  37 CONSTI */,
    0x00000133    /*  38 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $LAMBDA#sagittarius.compiler.util> */,
    0x00000a04    /*  40 CONSTI */,
    0x00000133    /*  41 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $RECEIVE#sagittarius.compiler.util> */,
    0x00000b04    /*  43 CONSTI */,
    0x00000133    /*  44 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $LABEL#sagittarius.compiler.util> */,
    0x00000c04    /*  46 CONSTI */,
    0x00000133    /*  47 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $SEQ#sagittarius.compiler.util> */,
    0x00000d04    /*  49 CONSTI */,
    0x00000133    /*  50 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $CALL#sagittarius.compiler.util> */,
    0x00000e04    /*  52 CONSTI */,
    0x00000133    /*  53 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $ASM#sagittarius.compiler.util> */,
    0x00000f04    /*  55 CONSTI */,
    0x00000133    /*  56 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $IT#sagittarius.compiler.util> */,
    0x00001004    /*  58 CONSTI */,
    0x00000133    /*  59 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $LIST#sagittarius.compiler.util> */,
    0x00001104    /*  61 CONSTI */,
    0x00000133    /*  62 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier $LIBRARY#sagittarius.compiler.util> */,
    0x00000002    /*  64 UNDEF */,
    0x0000002f    /*  65 RET */,
  },
  {  /* SgCodeBuilder d17806 */
    
    SG_STATIC_CODE_BUILDER( /* ensure-library-name */
      (SgWord *)SG_OBJ(&sg__rc_cgen17780.d17805[0]), SG_FALSE, 1, 0, 0, 14, 36),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17780.d17805[36]), SG_FALSE, 0, 0, 0, 0, 66),
  },
};
static SgCodeBuilder *G17781 = 
   SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17780.d17806[1]));
void Sg__Init_sagittarius_compiler_util() {
  SgObject save = Sg_VM()->currentLibrary;

  sg__rc_cgen17780.d17804[2] = SG_MAKE_STRING("(sagittarius compiler util)");
  sg__rc_cgen17780.d17804[1] = Sg_Intern(sg__rc_cgen17780.d17804[2]); /* (sagittarius compiler util) */
  sg__rc_cgen17780.d17804[0] = Sg_FindLibrary(SG_SYMBOL(sg__rc_cgen17780.d17804[1]), TRUE);
  sg__rc_cgen17780.d17804[4] = SG_MAKE_STRING("null");
  sg__rc_cgen17780.d17804[3] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen17780.d17804[4])); /* null */
  sg__rc_cgen17780.d17804[7] = SG_MAKE_STRING("core");
  sg__rc_cgen17780.d17804[6] = Sg_Intern(sg__rc_cgen17780.d17804[7]); /* core */
  do {
    /* (core) */ 
    SgObject G17807 = SG_NIL, G17808 = SG_NIL;
    SG_APPEND1(G17807, G17808, sg__rc_cgen17780.d17804[6]); /* core */ 
    sg__rc_cgen17780.d17804[5] = G17807;
  } while (0);
  sg__rc_cgen17780.d17804[9] = SG_MAKE_STRING("sagittarius");
  sg__rc_cgen17780.d17804[8] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen17780.d17804[9])); /* sagittarius */
  sg__rc_cgen17780.d17804[11] = Sg_Intern(sg__rc_cgen17780.d17804[9]); /* sagittarius */
  do {
    /* (sagittarius) */ 
    SgObject G17809 = SG_NIL, G17810 = SG_NIL;
    SG_APPEND1(G17809, G17810, sg__rc_cgen17780.d17804[11]); /* sagittarius */ 
    sg__rc_cgen17780.d17804[10] = G17809;
  } while (0);
  sg__rc_cgen17780.d17804[13] = SG_MAKE_STRING("base");
  sg__rc_cgen17780.d17804[12] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen17780.d17804[13])); /* base */
  sg__rc_cgen17780.d17804[15] = Sg_Intern(sg__rc_cgen17780.d17804[13]); /* base */
  do {
    /* (core base) */ 
    SgObject G17811 = SG_NIL, G17812 = SG_NIL;
    SG_APPEND1(G17811, G17812, sg__rc_cgen17780.d17804[6]); /* core */ 
    SG_APPEND1(G17811, G17812, sg__rc_cgen17780.d17804[15]); /* base */ 
    sg__rc_cgen17780.d17804[14] = G17811;
  } while (0);
  sg__rc_cgen17780.d17804[17] = SG_MAKE_STRING("r6rs-script");
  sg__rc_cgen17780.d17804[16] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen17780.d17804[17])); /* r6rs-script */
  sg__rc_cgen17780.d17804[19] = Sg_Intern(sg__rc_cgen17780.d17804[17]); /* r6rs-script */
  do {
    /* (r6rs-script) */ 
    SgObject G17813 = SG_NIL, G17814 = SG_NIL;
    SG_APPEND1(G17813, G17814, sg__rc_cgen17780.d17804[19]); /* r6rs-script */ 
    sg__rc_cgen17780.d17804[18] = G17813;
  } while (0);
  sg__rc_cgen17780.d17804[21] = SG_MAKE_STRING("ensure-library-name");
  sg__rc_cgen17780.d17804[20] = Sg_Intern(sg__rc_cgen17780.d17804[21]); /* ensure-library-name */
  sg__rc_cgen17780.d17804[22] = SG_MAKE_STRING("invalid library tag:");
  sg__rc_cgen17780.d17804[23] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17780.d17804[25] = SG_MAKE_STRING("error");
  sg__rc_cgen17780.d17804[24] = Sg_Intern(sg__rc_cgen17780.d17804[25]); /* error */
  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[23],SG_SYMBOL(sg__rc_cgen17780.d17804[24]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17780.d17806[0]))->name = sg__rc_cgen17780.d17804[20];/* ensure-library-name */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[2] = SG_WORD(sg__rc_cgen17780.d17804[3]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[6] = SG_WORD(sg__rc_cgen17780.d17804[5]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[9] = SG_WORD(sg__rc_cgen17780.d17804[8]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[13] = SG_WORD(sg__rc_cgen17780.d17804[10]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[16] = SG_WORD(sg__rc_cgen17780.d17804[12]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[20] = SG_WORD(sg__rc_cgen17780.d17804[14]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[23] = SG_WORD(sg__rc_cgen17780.d17804[16]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[27] = SG_WORD(sg__rc_cgen17780.d17804[18]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[29] = SG_WORD(sg__rc_cgen17780.d17804[20]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[31] = SG_WORD(sg__rc_cgen17780.d17804[22]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[0]))[34] = SG_WORD(sg__rc_cgen17780.d17804[23]);
  sg__rc_cgen17780.d17804[26] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[26],SG_SYMBOL(sg__rc_cgen17780.d17804[20]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* ensure-library-name */
  sg__rc_cgen17780.d17804[30] = SG_MAKE_STRING("$UNDEF");
  sg__rc_cgen17780.d17804[29] = Sg_Intern(sg__rc_cgen17780.d17804[30]); /* $UNDEF */
  do {
    /* ($UNDEF . 0) */ 
    SgObject G17815 = SG_NIL, G17816 = SG_NIL;
    SG_APPEND1(G17815, G17816, sg__rc_cgen17780.d17804[29]); /* $UNDEF */ 
    SG_SET_CDR(G17816, SG_MAKE_INT(0)); /* #<<cgen-scheme-integer> 0xfca54210> */
    sg__rc_cgen17780.d17804[28] = G17815;
  } while (0);
  sg__rc_cgen17780.d17804[33] = SG_MAKE_STRING("$DEFINE");
  sg__rc_cgen17780.d17804[32] = Sg_Intern(sg__rc_cgen17780.d17804[33]); /* $DEFINE */
  do {
    /* ($DEFINE . 1) */ 
    SgObject G17817 = SG_NIL, G17818 = SG_NIL;
    SG_APPEND1(G17817, G17818, sg__rc_cgen17780.d17804[32]); /* $DEFINE */ 
    SG_SET_CDR(G17818, SG_MAKE_INT(1U)); /* #<<cgen-scheme-integer> 0xfca57d10> */
    sg__rc_cgen17780.d17804[31] = G17817;
  } while (0);
  sg__rc_cgen17780.d17804[36] = SG_MAKE_STRING("$LREF");
  sg__rc_cgen17780.d17804[35] = Sg_Intern(sg__rc_cgen17780.d17804[36]); /* $LREF */
  do {
    /* ($LREF . 2) */ 
    SgObject G17819 = SG_NIL, G17820 = SG_NIL;
    SG_APPEND1(G17819, G17820, sg__rc_cgen17780.d17804[35]); /* $LREF */ 
    SG_SET_CDR(G17820, SG_MAKE_INT(2U)); /* #<<cgen-scheme-integer> 0xfca5a980> */
    sg__rc_cgen17780.d17804[34] = G17819;
  } while (0);
  sg__rc_cgen17780.d17804[39] = SG_MAKE_STRING("$LSET");
  sg__rc_cgen17780.d17804[38] = Sg_Intern(sg__rc_cgen17780.d17804[39]); /* $LSET */
  do {
    /* ($LSET . 3) */ 
    SgObject G17821 = SG_NIL, G17822 = SG_NIL;
    SG_APPEND1(G17821, G17822, sg__rc_cgen17780.d17804[38]); /* $LSET */ 
    SG_SET_CDR(G17822, SG_MAKE_INT(3U)); /* #<<cgen-scheme-integer> 0xfca615b0> */
    sg__rc_cgen17780.d17804[37] = G17821;
  } while (0);
  sg__rc_cgen17780.d17804[42] = SG_MAKE_STRING("$GREF");
  sg__rc_cgen17780.d17804[41] = Sg_Intern(sg__rc_cgen17780.d17804[42]); /* $GREF */
  do {
    /* ($GREF . 4) */ 
    SgObject G17823 = SG_NIL, G17824 = SG_NIL;
    SG_APPEND1(G17823, G17824, sg__rc_cgen17780.d17804[41]); /* $GREF */ 
    SG_SET_CDR(G17824, SG_MAKE_INT(4U)); /* #<<cgen-scheme-integer> 0xfca679e0> */
    sg__rc_cgen17780.d17804[40] = G17823;
  } while (0);
  sg__rc_cgen17780.d17804[45] = SG_MAKE_STRING("$GSET");
  sg__rc_cgen17780.d17804[44] = Sg_Intern(sg__rc_cgen17780.d17804[45]); /* $GSET */
  do {
    /* ($GSET . 5) */ 
    SgObject G17825 = SG_NIL, G17826 = SG_NIL;
    SG_APPEND1(G17825, G17826, sg__rc_cgen17780.d17804[44]); /* $GSET */ 
    SG_SET_CDR(G17826, SG_MAKE_INT(5U)); /* #<<cgen-scheme-integer> 0xfca69200> */
    sg__rc_cgen17780.d17804[43] = G17825;
  } while (0);
  sg__rc_cgen17780.d17804[48] = SG_MAKE_STRING("$CONST");
  sg__rc_cgen17780.d17804[47] = Sg_Intern(sg__rc_cgen17780.d17804[48]); /* $CONST */
  do {
    /* ($CONST . 6) */ 
    SgObject G17827 = SG_NIL, G17828 = SG_NIL;
    SG_APPEND1(G17827, G17828, sg__rc_cgen17780.d17804[47]); /* $CONST */ 
    SG_SET_CDR(G17828, SG_MAKE_INT(6U)); /* #<<cgen-scheme-integer> 0xfca6dda0> */
    sg__rc_cgen17780.d17804[46] = G17827;
  } while (0);
  sg__rc_cgen17780.d17804[51] = SG_MAKE_STRING("$IF");
  sg__rc_cgen17780.d17804[50] = Sg_Intern(sg__rc_cgen17780.d17804[51]); /* $IF */
  do {
    /* ($IF . 7) */ 
    SgObject G17829 = SG_NIL, G17830 = SG_NIL;
    SG_APPEND1(G17829, G17830, sg__rc_cgen17780.d17804[50]); /* $IF */ 
    SG_SET_CDR(G17830, SG_MAKE_INT(7U)); /* #<<cgen-scheme-integer> 0xfca740d0> */
    sg__rc_cgen17780.d17804[49] = G17829;
  } while (0);
  sg__rc_cgen17780.d17804[54] = SG_MAKE_STRING("$LET");
  sg__rc_cgen17780.d17804[53] = Sg_Intern(sg__rc_cgen17780.d17804[54]); /* $LET */
  do {
    /* ($LET . 8) */ 
    SgObject G17831 = SG_NIL, G17832 = SG_NIL;
    SG_APPEND1(G17831, G17832, sg__rc_cgen17780.d17804[53]); /* $LET */ 
    SG_SET_CDR(G17832, SG_MAKE_INT(8U)); /* #<<cgen-scheme-integer> 0xfca7a6a0> */
    sg__rc_cgen17780.d17804[52] = G17831;
  } while (0);
  sg__rc_cgen17780.d17804[57] = SG_MAKE_STRING("$LAMBDA");
  sg__rc_cgen17780.d17804[56] = Sg_Intern(sg__rc_cgen17780.d17804[57]); /* $LAMBDA */
  do {
    /* ($LAMBDA . 9) */ 
    SgObject G17833 = SG_NIL, G17834 = SG_NIL;
    SG_APPEND1(G17833, G17834, sg__rc_cgen17780.d17804[56]); /* $LAMBDA */ 
    SG_SET_CDR(G17834, SG_MAKE_INT(9U)); /* #<<cgen-scheme-integer> 0xfca81e60> */
    sg__rc_cgen17780.d17804[55] = G17833;
  } while (0);
  sg__rc_cgen17780.d17804[60] = SG_MAKE_STRING("$RECEIVE");
  sg__rc_cgen17780.d17804[59] = Sg_Intern(sg__rc_cgen17780.d17804[60]); /* $RECEIVE */
  do {
    /* ($RECEIVE . 10) */ 
    SgObject G17835 = SG_NIL, G17836 = SG_NIL;
    SG_APPEND1(G17835, G17836, sg__rc_cgen17780.d17804[59]); /* $RECEIVE */ 
    SG_SET_CDR(G17836, SG_MAKE_INT(10U)); /* #<<cgen-scheme-integer> 0xfca83220> */
    sg__rc_cgen17780.d17804[58] = G17835;
  } while (0);
  sg__rc_cgen17780.d17804[63] = SG_MAKE_STRING("$LABEL");
  sg__rc_cgen17780.d17804[62] = Sg_Intern(sg__rc_cgen17780.d17804[63]); /* $LABEL */
  do {
    /* ($LABEL . 11) */ 
    SgObject G17837 = SG_NIL, G17838 = SG_NIL;
    SG_APPEND1(G17837, G17838, sg__rc_cgen17780.d17804[62]); /* $LABEL */ 
    SG_SET_CDR(G17838, SG_MAKE_INT(11U)); /* #<<cgen-scheme-integer> 0xfca8c820> */
    sg__rc_cgen17780.d17804[61] = G17837;
  } while (0);
  sg__rc_cgen17780.d17804[66] = SG_MAKE_STRING("$SEQ");
  sg__rc_cgen17780.d17804[65] = Sg_Intern(sg__rc_cgen17780.d17804[66]); /* $SEQ */
  do {
    /* ($SEQ . 12) */ 
    SgObject G17839 = SG_NIL, G17840 = SG_NIL;
    SG_APPEND1(G17839, G17840, sg__rc_cgen17780.d17804[65]); /* $SEQ */ 
    SG_SET_CDR(G17840, SG_MAKE_INT(12U)); /* #<<cgen-scheme-integer> 0xfca91fd0> */
    sg__rc_cgen17780.d17804[64] = G17839;
  } while (0);
  sg__rc_cgen17780.d17804[69] = SG_MAKE_STRING("$CALL");
  sg__rc_cgen17780.d17804[68] = Sg_Intern(sg__rc_cgen17780.d17804[69]); /* $CALL */
  do {
    /* ($CALL . 13) */ 
    SgObject G17841 = SG_NIL, G17842 = SG_NIL;
    SG_APPEND1(G17841, G17842, sg__rc_cgen17780.d17804[68]); /* $CALL */ 
    SG_SET_CDR(G17842, SG_MAKE_INT(13U)); /* #<<cgen-scheme-integer> 0xfca95ad0> */
    sg__rc_cgen17780.d17804[67] = G17841;
  } while (0);
  sg__rc_cgen17780.d17804[72] = SG_MAKE_STRING("$ASM");
  sg__rc_cgen17780.d17804[71] = Sg_Intern(sg__rc_cgen17780.d17804[72]); /* $ASM */
  do {
    /* ($ASM . 14) */ 
    SgObject G17843 = SG_NIL, G17844 = SG_NIL;
    SG_APPEND1(G17843, G17844, sg__rc_cgen17780.d17804[71]); /* $ASM */ 
    SG_SET_CDR(G17844, SG_MAKE_INT(14U)); /* #<<cgen-scheme-integer> 0xfca98490> */
    sg__rc_cgen17780.d17804[70] = G17843;
  } while (0);
  sg__rc_cgen17780.d17804[75] = SG_MAKE_STRING("$IT");
  sg__rc_cgen17780.d17804[74] = Sg_Intern(sg__rc_cgen17780.d17804[75]); /* $IT */
  do {
    /* ($IT . 15) */ 
    SgObject G17845 = SG_NIL, G17846 = SG_NIL;
    SG_APPEND1(G17845, G17846, sg__rc_cgen17780.d17804[74]); /* $IT */ 
    SG_SET_CDR(G17846, SG_MAKE_INT(15U)); /* #<<cgen-scheme-integer> 0xfca9c020> */
    sg__rc_cgen17780.d17804[73] = G17845;
  } while (0);
  sg__rc_cgen17780.d17804[78] = SG_MAKE_STRING("$LIST");
  sg__rc_cgen17780.d17804[77] = Sg_Intern(sg__rc_cgen17780.d17804[78]); /* $LIST */
  do {
    /* ($LIST . 16) */ 
    SgObject G17847 = SG_NIL, G17848 = SG_NIL;
    SG_APPEND1(G17847, G17848, sg__rc_cgen17780.d17804[77]); /* $LIST */ 
    SG_SET_CDR(G17848, SG_MAKE_INT(16U)); /* #<<cgen-scheme-integer> 0xfcaa2000> */
    sg__rc_cgen17780.d17804[76] = G17847;
  } while (0);
  sg__rc_cgen17780.d17804[81] = SG_MAKE_STRING("$LIBRARY");
  sg__rc_cgen17780.d17804[80] = Sg_Intern(sg__rc_cgen17780.d17804[81]); /* $LIBRARY */
  do {
    /* ($LIBRARY . 17) */ 
    SgObject G17849 = SG_NIL, G17850 = SG_NIL;
    SG_APPEND1(G17849, G17850, sg__rc_cgen17780.d17804[80]); /* $LIBRARY */ 
    SG_SET_CDR(G17850, SG_MAKE_INT(17U)); /* #<<cgen-scheme-integer> 0xfcab45f0> */
    sg__rc_cgen17780.d17804[79] = G17849;
  } while (0);
  do {
    /* (($UNDEF . 0) ($DEFINE . 1) ($LREF . 2) ($LSET . 3) ($GREF . 4) ($GSET . 5) ($CONST . 6) ($IF . 7) ($LET . 8) ($LAMBDA . 9) ($RECEIVE . 10) ($LABEL . 11) ($SEQ . 12) ($CALL . 13) ($ASM . 14) ($IT . 15) ($LIST . 16) ($LIBRARY . 17)) */ 
    SgObject G17851 = SG_NIL, G17852 = SG_NIL;
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[28]); /* ($UNDEF . 0) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[31]); /* ($DEFINE . 1) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[34]); /* ($LREF . 2) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[37]); /* ($LSET . 3) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[40]); /* ($GREF . 4) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[43]); /* ($GSET . 5) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[46]); /* ($CONST . 6) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[49]); /* ($IF . 7) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[52]); /* ($LET . 8) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[55]); /* ($LAMBDA . 9) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[58]); /* ($RECEIVE . 10) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[61]); /* ($LABEL . 11) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[64]); /* ($SEQ . 12) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[67]); /* ($CALL . 13) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[70]); /* ($ASM . 14) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[73]); /* ($IT . 15) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[76]); /* ($LIST . 16) */ 
    SG_APPEND1(G17851, G17852, sg__rc_cgen17780.d17804[79]); /* ($LIBRARY . 17) */ 
    sg__rc_cgen17780.d17804[27] = G17851;
  } while (0);
  sg__rc_cgen17780.d17804[82] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17780.d17804[84] = SG_MAKE_STRING(".intermediate-tags.");
  sg__rc_cgen17780.d17804[83] = Sg_Intern(sg__rc_cgen17780.d17804[84]); /* .intermediate-tags. */
  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[82],SG_SYMBOL(sg__rc_cgen17780.d17804[83]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* .intermediate-tags. */
  sg__rc_cgen17780.d17804[85] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[85],SG_SYMBOL(sg__rc_cgen17780.d17804[29]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $UNDEF */
  sg__rc_cgen17780.d17804[86] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[86],SG_SYMBOL(sg__rc_cgen17780.d17804[32]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $DEFINE */
  sg__rc_cgen17780.d17804[87] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[87],SG_SYMBOL(sg__rc_cgen17780.d17804[35]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $LREF */
  sg__rc_cgen17780.d17804[88] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[88],SG_SYMBOL(sg__rc_cgen17780.d17804[38]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $LSET */
  sg__rc_cgen17780.d17804[89] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[89],SG_SYMBOL(sg__rc_cgen17780.d17804[41]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $GREF */
  sg__rc_cgen17780.d17804[90] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[90],SG_SYMBOL(sg__rc_cgen17780.d17804[44]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $GSET */
  sg__rc_cgen17780.d17804[91] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[91],SG_SYMBOL(sg__rc_cgen17780.d17804[47]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $CONST */
  sg__rc_cgen17780.d17804[92] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[92],SG_SYMBOL(sg__rc_cgen17780.d17804[50]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $IF */
  sg__rc_cgen17780.d17804[93] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[93],SG_SYMBOL(sg__rc_cgen17780.d17804[53]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $LET */
  sg__rc_cgen17780.d17804[94] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[94],SG_SYMBOL(sg__rc_cgen17780.d17804[56]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $LAMBDA */
  sg__rc_cgen17780.d17804[95] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[95],SG_SYMBOL(sg__rc_cgen17780.d17804[59]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $RECEIVE */
  sg__rc_cgen17780.d17804[96] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[96],SG_SYMBOL(sg__rc_cgen17780.d17804[62]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $LABEL */
  sg__rc_cgen17780.d17804[97] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[97],SG_SYMBOL(sg__rc_cgen17780.d17804[65]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $SEQ */
  sg__rc_cgen17780.d17804[98] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[98],SG_SYMBOL(sg__rc_cgen17780.d17804[68]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $CALL */
  sg__rc_cgen17780.d17804[99] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[99],SG_SYMBOL(sg__rc_cgen17780.d17804[71]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $ASM */
  sg__rc_cgen17780.d17804[100] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[100],SG_SYMBOL(sg__rc_cgen17780.d17804[74]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $IT */
  sg__rc_cgen17780.d17804[101] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[101],SG_SYMBOL(sg__rc_cgen17780.d17804[77]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $LIST */
  sg__rc_cgen17780.d17804[102] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17780.d17804[102],SG_SYMBOL(sg__rc_cgen17780.d17804[80]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17780.d17804[0]),FALSE); /* $LIBRARY */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[1] = SG_WORD(sg__rc_cgen17780.d17804[0]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[5] = SG_WORD(sg__rc_cgen17780.d17804[26]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[7] = SG_WORD(sg__rc_cgen17780.d17804[27]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[9] = SG_WORD(sg__rc_cgen17780.d17804[82]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[12] = SG_WORD(sg__rc_cgen17780.d17804[85]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[15] = SG_WORD(sg__rc_cgen17780.d17804[86]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[18] = SG_WORD(sg__rc_cgen17780.d17804[87]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[21] = SG_WORD(sg__rc_cgen17780.d17804[88]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[24] = SG_WORD(sg__rc_cgen17780.d17804[89]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[27] = SG_WORD(sg__rc_cgen17780.d17804[90]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[30] = SG_WORD(sg__rc_cgen17780.d17804[91]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[33] = SG_WORD(sg__rc_cgen17780.d17804[92]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[36] = SG_WORD(sg__rc_cgen17780.d17804[93]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[39] = SG_WORD(sg__rc_cgen17780.d17804[94]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[42] = SG_WORD(sg__rc_cgen17780.d17804[95]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[45] = SG_WORD(sg__rc_cgen17780.d17804[96]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[48] = SG_WORD(sg__rc_cgen17780.d17804[97]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[51] = SG_WORD(sg__rc_cgen17780.d17804[98]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[54] = SG_WORD(sg__rc_cgen17780.d17804[99]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[57] = SG_WORD(sg__rc_cgen17780.d17804[100]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[60] = SG_WORD(sg__rc_cgen17780.d17804[101]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17780.d17805[36]))[63] = SG_WORD(sg__rc_cgen17780.d17804[102]);
  sg__rc_cgen17780.d17804[104] = SG_MAKE_STRING("(core)");
  sg__rc_cgen17780.d17804[103] = Sg_Intern(sg__rc_cgen17780.d17804[104]); /* (core) */
  Sg_ImportLibrary(sg__rc_cgen17780.d17804[0], sg__rc_cgen17780.d17804[103]);

  sg__rc_cgen17780.d17804[106] = SG_MAKE_STRING("(core errors)");
  sg__rc_cgen17780.d17804[105] = Sg_Intern(sg__rc_cgen17780.d17804[106]); /* (core errors) */
  Sg_ImportLibrary(sg__rc_cgen17780.d17804[0], sg__rc_cgen17780.d17804[105]);

  sg__rc_cgen17780.d17804[108] = SG_MAKE_STRING("(sagittarius)");
  sg__rc_cgen17780.d17804[107] = Sg_Intern(sg__rc_cgen17780.d17804[108]); /* (sagittarius) */
  Sg_ImportLibrary(sg__rc_cgen17780.d17804[0], sg__rc_cgen17780.d17804[107]);

  sg__rc_cgen17780.d17804[110] = SG_MAKE_STRING("(sagittarius vm)");
  sg__rc_cgen17780.d17804[109] = Sg_Intern(sg__rc_cgen17780.d17804[110]); /* (sagittarius vm) */
  Sg_ImportLibrary(sg__rc_cgen17780.d17804[0], sg__rc_cgen17780.d17804[109]);

  sg__rc_cgen17780.d17804[114] = SG_MAKE_STRING("define-enum");
  sg__rc_cgen17780.d17804[113] = Sg_Intern(sg__rc_cgen17780.d17804[114]); /* define-enum */
  do {
    /* (ensure-library-name define-enum .intermediate-tags. $UNDEF $DEFINE $LREF $LSET $GREF $GSET $CONST $IF $LET $LAMBDA $RECEIVE $LABEL $SEQ $CALL $ASM $IT $LIST $LIBRARY) */ 
    SgObject G17853 = SG_NIL, G17854 = SG_NIL;
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[20]); /* ensure-library-name */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[113]); /* define-enum */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[83]); /* .intermediate-tags. */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[29]); /* $UNDEF */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[32]); /* $DEFINE */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[35]); /* $LREF */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[38]); /* $LSET */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[41]); /* $GREF */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[44]); /* $GSET */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[47]); /* $CONST */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[50]); /* $IF */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[53]); /* $LET */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[56]); /* $LAMBDA */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[59]); /* $RECEIVE */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[62]); /* $LABEL */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[65]); /* $SEQ */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[68]); /* $CALL */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[71]); /* $ASM */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[74]); /* $IT */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[77]); /* $LIST */ 
    SG_APPEND1(G17853, G17854, sg__rc_cgen17780.d17804[80]); /* $LIBRARY */ 
    sg__rc_cgen17780.d17804[112] = G17853;
  } while (0);
  do {
    /* ((ensure-library-name define-enum .intermediate-tags. $UNDEF $DEFINE $LREF $LSET $GREF $GSET $CONST $IF $LET $LAMBDA $RECEIVE $LABEL $SEQ $CALL $ASM $IT $LIST $LIBRARY)) */ 
    SgObject G17855 = SG_NIL, G17856 = SG_NIL;
    SG_APPEND1(G17855, G17856, sg__rc_cgen17780.d17804[112]); /* (ensure-library-name define-enum .intermediate-tags. $UNDEF $DEFINE $LREF $LSET $GREF $GSET $CONST $IF $LET $LAMBDA $RECEIVE $LABEL $SEQ $CALL $ASM $IT $LIST $LIBRARY) */ 
    sg__rc_cgen17780.d17804[111] = G17855;
  } while (0);
  Sg_LibraryExportedSet(sg__rc_cgen17780.d17804[0], sg__rc_cgen17780.d17804[111]);

  Sg_VM()->currentLibrary = sg__rc_cgen17780.d17804[0];
  Sg_VMExecute(SG_OBJ(G17781));
  Sg_VM()->currentLibrary = save;
}
