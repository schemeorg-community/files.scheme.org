/* Generated automatically from ../boot/lib/scmlib.scm. DO NOT EDIT! */
#define LIBSAGITTARIUS_BODY 
#include <sagittarius.h>
static struct sg__rc_cgen17086Rec {
  SgObject d17186[1136];
  SgWord d17187[5259];
  SgCodeBuilder d17188[105];
} sg__rc_cgen17086 = {
  {  /* SgObject d17186 */
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
  },
  {  /* SgWord d17187 */
    /* (vector-map vector-tabulate) */0x00000049    /*   0 CONSTI_PUSH */,
    0x00000048    /*   1 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000245    /*   3 LREF_PUSH */,
    0x00000005    /*   4 LREF */,
    0x0000001a    /*   5 BNNUME */,
    SG_WORD(10),
    0x00000030    /*   7 FRAME */,
    SG_WORD(4),
    0x00000345    /*   9 LREF_PUSH */,
    0x0000014a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000000b    /*  12 PUSH */,
    0x0000014b    /*  13 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier list->vector#core.base> */,
    0x0000002f    /*  15 RET */,
    0x00000205    /*  16 LREF */,
    0x0000010f    /*  17 ADDI */,
    0x0000000b    /*  18 PUSH */,
    0x00000030    /*  19 FRAME */,
    SG_WORD(4),
    0x00000245    /*  21 LREF_PUSH */,
    0x00000105    /*  22 LREF */,
    0x0000012b    /*  23 CALL */,
    0x0000000b    /*  24 PUSH */,
    0x00000305    /*  25 LREF */,
    0x00000054    /*  26 CONS_PUSH */,
    0x00200219    /*  27 SHIFTJ */,
    0x00000018    /*  28 JUMP */,
    SG_WORD(-26),
    0x0000002f    /*  30 RET */,
    /* (vector-map! vector-update!) */0x00000049    /*   0 CONSTI_PUSH */,
    0x00000345    /*   1 LREF_PUSH */,
    0x00000105    /*   2 LREF */,
    0x0000001a    /*   3 BNNUME */,
    SG_WORD(3),
    0x00000005    /*   5 LREF */,
    0x0000002f    /*   6 RET */,
    0x00000045    /*   7 LREF_PUSH */,
    0x00000345    /*   8 LREF_PUSH */,
    0x00000030    /*   9 FRAME */,
    SG_WORD(4),
    0x00000345    /*  11 LREF_PUSH */,
    0x00000205    /*  12 LREF */,
    0x0000012b    /*  13 CALL */,
    0x00000044    /*  14 VEC_SET */,
    0x00000305    /*  15 LREF */,
    0x0000010f    /*  16 ADDI */,
    0x0000000b    /*  17 PUSH */,
    0x00300119    /*  18 SHIFTJ */,
    0x00000018    /*  19 JUMP */,
    SG_WORD(-19),
    0x0000002f    /*  21 RET */,
    /* (take recur) */0x00000145    /*   0 LREF_PUSH */,
    0x00000004    /*   1 CONSTI */,
    0x0000001a    /*   2 BNNUME */,
    SG_WORD(3),
    0x00000061    /*   4 CONST_RET */,
    SG_WORD(SG_NIL) /* () */,
    0x0000005b    /*   6 LREF_CAR_PUSH */,
    0x00000030    /*   7 FRAME */,
    SG_WORD(8),
    0x0000005c    /*   9 LREF_CDR_PUSH */,
    0x00000105    /*  10 LREF */,
    -0x000000f1   /*  11 ADDI */,
    0x0000000b    /*  12 PUSH */,
    0x00000009    /*  13 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17183#core.base> */,
    0x0000022c    /*  15 LOCAL_CALL */,
    0x00000037    /*  16 CONS */,
    0x0000002f    /*  17 RET */,
    /* (for-all loop) */0x00000005    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   3 CONST_RET */,
    SG_WORD(SG_NIL) /* () */,
    0x00000005    /*   5 LREF */,
    0x00000050    /*   6 CDAR */,
    0x00000021    /*   7 BNNULL */,
    SG_WORD(6),
    0x0000005c    /*   9 LREF_CDR_PUSH */,
    0x00000009    /*  10 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17182#core.base> */,
    0x0000012e    /*  12 LOCAL_TAIL_CALL */,
    0x0000002f    /*  13 RET */,
    0x00000005    /*  14 LREF */,
    0x00000050    /*  15 CDAR */,
    0x0000000b    /*  16 PUSH */,
    0x00000030    /*  17 FRAME */,
    SG_WORD(5),
    0x0000005c    /*  19 LREF_CDR_PUSH */,
    0x00000009    /*  20 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17182#core.base> */,
    0x0000012c    /*  22 LOCAL_CALL */,
    0x00000037    /*  23 CONS */,
    0x0000002f    /*  24 RET */,
    /* (for-all collect-cdr) */0x00000163    /*   0 RESV_STACK */,
    0x00000009    /*   1 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17182#core.base> */,
    0x00000131    /*   3 INST_STACK */,
    0x00000045    /*   4 LREF_PUSH */,
    0x00000009    /*   5 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17182#core.base> */,
    0x0000012e    /*   7 LOCAL_TAIL_CALL */,
    0x0000002f    /*   8 RET */,
    /* (exists loop) */0x00000005    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   3 CONST_RET */,
    SG_WORD(SG_NIL) /* () */,
    0x00000005    /*   5 LREF */,
    0x00000050    /*   6 CDAR */,
    0x00000021    /*   7 BNNULL */,
    SG_WORD(6),
    0x0000005c    /*   9 LREF_CDR_PUSH */,
    0x00000009    /*  10 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17180#core.base> */,
    0x0000012e    /*  12 LOCAL_TAIL_CALL */,
    0x0000002f    /*  13 RET */,
    0x00000005    /*  14 LREF */,
    0x00000050    /*  15 CDAR */,
    0x0000000b    /*  16 PUSH */,
    0x00000030    /*  17 FRAME */,
    SG_WORD(5),
    0x0000005c    /*  19 LREF_CDR_PUSH */,
    0x00000009    /*  20 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17180#core.base> */,
    0x0000012c    /*  22 LOCAL_CALL */,
    0x00000037    /*  23 CONS */,
    0x0000002f    /*  24 RET */,
    /* (exists collect-cdr) */0x00000163    /*   0 RESV_STACK */,
    0x00000009    /*   1 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17180#core.base> */,
    0x00000131    /*   3 INST_STACK */,
    0x00000045    /*   4 LREF_PUSH */,
    0x00000009    /*   5 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17180#core.base> */,
    0x0000012e    /*   7 LOCAL_TAIL_CALL */,
    0x0000002f    /*   8 RET */,
    /* (list-sort merge-list!) */0x0000020c    /*   0 BOX */,
    0x0000010c    /*   1 BOX */,
    0x0000000c    /*   2 BOX */,
    0x00000030    /*   3 FRAME */,
    SG_WORD(9),
    0x00000305    /*   5 LREF */,
    0x0000000d    /*   6 UNBOX */,
    0x00000052    /*   7 CAR_PUSH */,
    0x00000205    /*   8 LREF */,
    0x0000000d    /*   9 UNBOX */,
    0x00000052    /*  10 CAR_PUSH */,
    0x00000005    /*  11 LREF */,
    0x0000022b    /*  12 CALL */,
    0x00000017    /*  13 TEST */,
    SG_WORD(30),
    0x00000405    /*  15 LREF */,
    0x0000000d    /*  16 UNBOX */,
    0x0000000b    /*  17 PUSH */,
    0x00000305    /*  18 LREF */,
    0x0000000d    /*  19 UNBOX */,
    0x0000004d    /*  20 SET_CDR */,
    0x00000305    /*  21 LREF */,
    0x0000000d    /*  22 UNBOX */,
    0x00000406    /*  23 LSET */,
    0x00000305    /*  24 LREF */,
    0x0000000d    /*  25 UNBOX */,
    0x00000053    /*  26 CDR_PUSH */,
    0x00000505    /*  27 LREF */,
    0x00000021    /*  28 BNNULL */,
    SG_WORD(9),
    0x00000305    /*  30 LREF */,
    0x0000000d    /*  31 UNBOX */,
    0x0000000b    /*  32 PUSH */,
    0x00000205    /*  33 LREF */,
    0x0000000d    /*  34 UNBOX */,
    0x0000004d    /*  35 SET_CDR */,
    0x00000156    /*  36 LREF_CDR */,
    0x0000002f    /*  37 RET */,
    0x00000505    /*  38 LREF */,
    0x00000306    /*  39 LSET */,
    0x00500019    /*  40 SHIFTJ */,
    0x00000018    /*  41 JUMP */,
    SG_WORD(-39),
    0x0000002f    /*  43 RET */,
    0x00000405    /*  44 LREF */,
    0x0000000d    /*  45 UNBOX */,
    0x0000000b    /*  46 PUSH */,
    0x00000205    /*  47 LREF */,
    0x0000000d    /*  48 UNBOX */,
    0x0000004d    /*  49 SET_CDR */,
    0x00000205    /*  50 LREF */,
    0x0000000d    /*  51 UNBOX */,
    0x00000406    /*  52 LSET */,
    0x00000205    /*  53 LREF */,
    0x0000000d    /*  54 UNBOX */,
    0x00000053    /*  55 CDR_PUSH */,
    0x00000505    /*  56 LREF */,
    0x00000021    /*  57 BNNULL */,
    SG_WORD(9),
    0x00000205    /*  59 LREF */,
    0x0000000d    /*  60 UNBOX */,
    0x0000000b    /*  61 PUSH */,
    0x00000305    /*  62 LREF */,
    0x0000000d    /*  63 UNBOX */,
    0x0000004d    /*  64 SET_CDR */,
    0x00000156    /*  65 LREF_CDR */,
    0x0000002f    /*  66 RET */,
    0x00000505    /*  67 LREF */,
    0x00000206    /*  68 LSET */,
    0x00500019    /*  69 SHIFTJ */,
    0x00000018    /*  70 JUMP */,
    SG_WORD(-68),
    0x0000002f    /*  72 RET */,
    /* (vector-sort vector-copy!) */0x00000345    /*   0 LREF_PUSH */,
    0x00000105    /*   1 LREF */,
    0x0000001c    /*   2 BNLE */,
    SG_WORD(29),
    0x00000049    /*   4 CONSTI_PUSH */,
    0x00000145    /*   5 LREF_PUSH */,
    0x00000345    /*   6 LREF_PUSH */,
    0x00000545    /*   7 LREF_PUSH */,
    0x00000405    /*   8 LREF */,
    0x0000001a    /*   9 BNNUME */,
    SG_WORD(3),
    0x00000205    /*  11 LREF */,
    0x0000002f    /*  12 RET */,
    0x00000245    /*  13 LREF_PUSH */,
    0x00000745    /*  14 LREF_PUSH */,
    0x00000045    /*  15 LREF_PUSH */,
    0x00000605    /*  16 LREF */,
    0x00000043    /*  17 VEC_REF */,
    0x00000044    /*  18 VEC_SET */,
    0x00000505    /*  19 LREF */,
    0x0000010f    /*  20 ADDI */,
    0x0000000b    /*  21 PUSH */,
    0x00000605    /*  22 LREF */,
    0x0000010f    /*  23 ADDI */,
    0x0000000b    /*  24 PUSH */,
    0x00000705    /*  25 LREF */,
    0x0000010f    /*  26 ADDI */,
    0x0000000b    /*  27 PUSH */,
    0x00500319    /*  28 SHIFTJ */,
    0x00000018    /*  29 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  31 RET */,
    0x00000049    /*  32 CONSTI_PUSH */,
    0x00000145    /*  33 LREF_PUSH */,
    0x00000405    /*  34 LREF */,
    0x0000000e    /*  35 ADD */,
    0x0000000b    /*  36 PUSH */,
    0x00000345    /*  37 LREF_PUSH */,
    0x00000405    /*  38 LREF */,
    0x0000000e    /*  39 ADD */,
    0x0000000b    /*  40 PUSH */,
    0x00000545    /*  41 LREF_PUSH */,
    0x00000405    /*  42 LREF */,
    0x0000001a    /*  43 BNNUME */,
    SG_WORD(3),
    0x00000205    /*  45 LREF */,
    0x0000002f    /*  46 RET */,
    0x00000245    /*  47 LREF_PUSH */,
    0x00000745    /*  48 LREF_PUSH */,
    0x00000045    /*  49 LREF_PUSH */,
    0x00000605    /*  50 LREF */,
    0x00000043    /*  51 VEC_REF */,
    0x00000044    /*  52 VEC_SET */,
    0x00000505    /*  53 LREF */,
    0x0000010f    /*  54 ADDI */,
    0x0000000b    /*  55 PUSH */,
    0x00000605    /*  56 LREF */,
    -0x000000f1   /*  57 ADDI */,
    0x0000000b    /*  58 PUSH */,
    0x00000705    /*  59 LREF */,
    -0x000000f1   /*  60 ADDI */,
    0x0000000b    /*  61 PUSH */,
    0x00500319    /*  62 SHIFTJ */,
    0x00000018    /*  63 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  65 RET */,
    /* hashtable-for-each */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(4),
    0x00000002    /*   7 UNDEF */,
    0x00000018    /*   8 JUMP */,
    SG_WORD(16),
    0x00000030    /*  10 FRAME */,
    SG_WORD(14),
    0x00000048    /*  12 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-for-each */,
    0x00000030    /*  14 FRAME */,
    SG_WORD(7),
    0x00000048    /*  16 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  18 LREF_PUSH */,
    0x00000149    /*  19 CONSTI_PUSH */,
    0x0000034a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  22 PUSH */,
    0x0000024a    /*  23 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  25 FRAME */,
    SG_WORD(4),
    0x00000145    /*  27 LREF_PUSH */,
    0x0000014a    /*  28 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable?#core.base> */,
    0x00000017    /*  30 TEST */,
    SG_WORD(4),
    0x00000002    /*  32 UNDEF */,
    0x00000018    /*  33 JUMP */,
    SG_WORD(16),
    0x00000030    /*  35 FRAME */,
    SG_WORD(14),
    0x00000048    /*  37 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-for-each */,
    0x00000030    /*  39 FRAME */,
    SG_WORD(7),
    0x00000048    /*  41 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable */,
    0x00000145    /*  43 LREF_PUSH */,
    0x00000249    /*  44 CONSTI_PUSH */,
    0x0000034a    /*  45 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  47 PUSH */,
    0x0000024a    /*  48 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  50 FRAME */,
    SG_WORD(4),
    0x00000145    /*  52 LREF_PUSH */,
    0x0000014a    /*  53 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier %hashtable-iter#core.base> */,
    0x0000000b    /*  55 PUSH */,
    0x00000048    /*  56 CONST_PUSH */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000003    /*  58 CONST */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000054    /*  60 CONS_PUSH */,
    0x00000030    /*  61 FRAME */,
    SG_WORD(4),
    0x00000345    /*  63 LREF_PUSH */,
    0x00000205    /*  64 LREF */,
    0x0000012b    /*  65 CALL */,
    0x00000228    /*  66 RECEIVE */,
    0x00000445    /*  67 LREF_PUSH */,
    0x00000305    /*  68 LREF */,
    0x0000001f    /*  69 BNEQ */,
    SG_WORD(3),
    0x00000002    /*  71 UNDEF */,
    0x0000002f    /*  72 RET */,
    0x00000030    /*  73 FRAME */,
    SG_WORD(5),
    0x00000445    /*  75 LREF_PUSH */,
    0x00000545    /*  76 LREF_PUSH */,
    0x00000005    /*  77 LREF */,
    0x0000022b    /*  78 CALL */,
    0x00400019    /*  79 SHIFTJ */,
    0x00000018    /*  80 JUMP */,
    SG_WORD(-20),
    0x0000002f    /*  82 RET */,
    /* hashtable-map */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(4),
    0x00000002    /*   7 UNDEF */,
    0x00000018    /*   8 JUMP */,
    SG_WORD(16),
    0x00000030    /*  10 FRAME */,
    SG_WORD(14),
    0x00000048    /*  12 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-map */,
    0x00000030    /*  14 FRAME */,
    SG_WORD(7),
    0x00000048    /*  16 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  18 LREF_PUSH */,
    0x00000149    /*  19 CONSTI_PUSH */,
    0x0000034a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  22 PUSH */,
    0x0000024a    /*  23 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  25 FRAME */,
    SG_WORD(4),
    0x00000145    /*  27 LREF_PUSH */,
    0x0000014a    /*  28 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable?#core.base> */,
    0x00000017    /*  30 TEST */,
    SG_WORD(4),
    0x00000002    /*  32 UNDEF */,
    0x00000018    /*  33 JUMP */,
    SG_WORD(16),
    0x00000030    /*  35 FRAME */,
    SG_WORD(14),
    0x00000048    /*  37 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-map */,
    0x00000030    /*  39 FRAME */,
    SG_WORD(7),
    0x00000048    /*  41 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable */,
    0x00000145    /*  43 LREF_PUSH */,
    0x00000249    /*  44 CONSTI_PUSH */,
    0x0000034a    /*  45 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  47 PUSH */,
    0x0000024a    /*  48 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  50 FRAME */,
    SG_WORD(4),
    0x00000145    /*  52 LREF_PUSH */,
    0x0000014a    /*  53 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier %hashtable-iter#core.base> */,
    0x0000000b    /*  55 PUSH */,
    0x00000048    /*  56 CONST_PUSH */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000003    /*  58 CONST */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000054    /*  60 CONS_PUSH */,
    0x00000048    /*  61 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000030    /*  63 FRAME */,
    SG_WORD(4),
    0x00000345    /*  65 LREF_PUSH */,
    0x00000205    /*  66 LREF */,
    0x0000012b    /*  67 CALL */,
    0x00000228    /*  68 RECEIVE */,
    0x00000545    /*  69 LREF_PUSH */,
    0x00000305    /*  70 LREF */,
    0x0000001f    /*  71 BNEQ */,
    SG_WORD(3),
    0x00000405    /*  73 LREF */,
    0x0000002f    /*  74 RET */,
    0x00000030    /*  75 FRAME */,
    SG_WORD(5),
    0x00000545    /*  77 LREF_PUSH */,
    0x00000645    /*  78 LREF_PUSH */,
    0x00000005    /*  79 LREF */,
    0x0000022b    /*  80 CALL */,
    0x0000000b    /*  81 PUSH */,
    0x00000405    /*  82 LREF */,
    0x00000054    /*  83 CONS_PUSH */,
    0x00400119    /*  84 SHIFTJ */,
    0x00000018    /*  85 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  87 RET */,
    /* hashtable-fold */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(4),
    0x00000002    /*   7 UNDEF */,
    0x00000018    /*   8 JUMP */,
    SG_WORD(17),
    0x00000030    /*  10 FRAME */,
    SG_WORD(15),
    0x00000048    /*  12 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-fold */,
    0x00000030    /*  14 FRAME */,
    SG_WORD(8),
    0x00000048    /*  16 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000047    /*  18 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier proc#core.base> */,
    0x00000149    /*  20 CONSTI_PUSH */,
    0x0000034a    /*  21 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  23 PUSH */,
    0x0000024a    /*  24 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  26 FRAME */,
    SG_WORD(4),
    0x00000145    /*  28 LREF_PUSH */,
    0x0000014a    /*  29 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable?#core.base> */,
    0x00000017    /*  31 TEST */,
    SG_WORD(4),
    0x00000002    /*  33 UNDEF */,
    0x00000018    /*  34 JUMP */,
    SG_WORD(16),
    0x00000030    /*  36 FRAME */,
    SG_WORD(14),
    0x00000048    /*  38 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-fold */,
    0x00000030    /*  40 FRAME */,
    SG_WORD(7),
    0x00000048    /*  42 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable */,
    0x00000145    /*  44 LREF_PUSH */,
    0x00000249    /*  45 CONSTI_PUSH */,
    0x0000034a    /*  46 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  48 PUSH */,
    0x0000024a    /*  49 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  51 FRAME */,
    SG_WORD(4),
    0x00000145    /*  53 LREF_PUSH */,
    0x0000014a    /*  54 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier %hashtable-iter#core.base> */,
    0x0000000b    /*  56 PUSH */,
    0x00000048    /*  57 CONST_PUSH */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000003    /*  59 CONST */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000054    /*  61 CONS_PUSH */,
    0x00000245    /*  62 LREF_PUSH */,
    0x00000030    /*  63 FRAME */,
    SG_WORD(4),
    0x00000445    /*  65 LREF_PUSH */,
    0x00000305    /*  66 LREF */,
    0x0000012b    /*  67 CALL */,
    0x00000228    /*  68 RECEIVE */,
    0x00000645    /*  69 LREF_PUSH */,
    0x00000405    /*  70 LREF */,
    0x0000001f    /*  71 BNEQ */,
    SG_WORD(3),
    0x00000505    /*  73 LREF */,
    0x0000002f    /*  74 RET */,
    0x00000030    /*  75 FRAME */,
    SG_WORD(6),
    0x00000645    /*  77 LREF_PUSH */,
    0x00000745    /*  78 LREF_PUSH */,
    0x00000545    /*  79 LREF_PUSH */,
    0x00000005    /*  80 LREF */,
    0x0000032b    /*  81 CALL */,
    0x0000000b    /*  82 PUSH */,
    0x00500119    /*  83 SHIFTJ */,
    0x00000018    /*  84 JUMP */,
    SG_WORD(-22),
    0x0000002f    /*  86 RET */,
    /* hashtable->alist */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier cons#core.base> */,
    0x00000045    /*   2 LREF_PUSH */,
    0x0000024b    /*   3 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-map#core.base> */,
    0x0000002f    /*   5 RET */,
    /* unique-id-list? */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier list?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(32),
    0x00000045    /*   7 LREF_PUSH */,
    0x00000105    /*   8 LREF */,
    0x0000003e    /*   9 PAIRP */,
    0x00000017    /*  10 TEST */,
    SG_WORD(25),
    0x00000030    /*  12 FRAME */,
    SG_WORD(4),
    0x0000015b    /*  14 LREF_CAR_PUSH */,
    0x0000014a    /*  15 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier variable?#core.base> */,
    0x00000022    /*  17 NOT */,
    0x00000017    /*  18 TEST */,
    SG_WORD(3),
    0x00000018    /*  20 JUMP */,
    SG_WORD(15),
    0x00000030    /*  22 FRAME */,
    SG_WORD(5),
    0x0000015b    /*  24 LREF_CAR_PUSH */,
    0x0000015c    /*  25 LREF_CDR_PUSH */,
    0x0000024a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier id-memq#core.base> */,
    0x00000017    /*  28 TEST */,
    SG_WORD(3),
    0x00000018    /*  30 JUMP */,
    SG_WORD(5),
    0x0000015c    /*  32 LREF_CDR_PUSH */,
    0x00100119    /*  33 SHIFTJ */,
    0x00000018    /*  34 JUMP */,
    SG_WORD(-27),
    0x00000132    /*  36 LEAVE */,
    0x00000022    /*  37 NOT */,
    0x0000002f    /*  38 RET */,
    /* call-with-values */0x00000030    /*   0 FRAME */,
    SG_WORD(3),
    0x00000005    /*   2 LREF */,
    0x0000002b    /*   3 CALL */,
    0x00100028    /*   4 RECEIVE */,
    0x00000145    /*   5 LREF_PUSH */,
    0x00000205    /*   6 LREF */,
    0x0010022a    /*   7 APPLY */,
    0x0000002f    /*   8 RET */,
    /* print */0x00000030    /*   0 FRAME */,
    SG_WORD(6),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier display#core.base> */,
    0x00000045    /*   4 LREF_PUSH */,
    0x0000024a    /*   5 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier for-each#core.base> */,
    0x0000004b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier newline#core.base> */,
    0x0000002f    /*   9 RET */,
    /* fold */0x00000305    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(20),
    0x00000245    /*   3 LREF_PUSH */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000405    /*   5 LREF */,
    0x00000021    /*   6 BNNULL */,
    SG_WORD(3),
    0x00000505    /*   8 LREF */,
    0x0000002f    /*   9 RET */,
    0x0000045c    /*  10 LREF_CDR_PUSH */,
    0x00000030    /*  11 FRAME */,
    SG_WORD(5),
    0x0000045b    /*  13 LREF_CAR_PUSH */,
    0x00000545    /*  14 LREF_PUSH */,
    0x00000005    /*  15 LREF */,
    0x0000022b    /*  16 CALL */,
    0x0000000b    /*  17 PUSH */,
    0x00400219    /*  18 SHIFTJ */,
    0x00000018    /*  19 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  21 RET */,
    0x00000030    /*  22 FRAME */,
    SG_WORD(6),
    0x00000047    /*  24 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose*#core.base> */,
    0x00000245    /*  26 LREF_PUSH */,
    0x00000305    /*  27 LREF */,
    0x0000032a    /*  28 APPLY */,
    0x0000000b    /*  29 PUSH */,
    0x00000145    /*  30 LREF_PUSH */,
    0x00000405    /*  31 LREF */,
    0x00000021    /*  32 BNNULL */,
    SG_WORD(3),
    0x00000505    /*  34 LREF */,
    0x0000002f    /*  35 RET */,
    0x0000045c    /*  36 LREF_CDR_PUSH */,
    0x00000030    /*  37 FRAME */,
    SG_WORD(7),
    0x00000045    /*  39 LREF_PUSH */,
    0x0000045b    /*  40 LREF_CAR_PUSH */,
    0x00000505    /*  41 LREF */,
    0x00000138    /*  42 LIST */,
    0x00000239    /*  43 APPEND */,
    0x0000022a    /*  44 APPLY */,
    0x0000000b    /*  45 PUSH */,
    0x00400219    /*  46 SHIFTJ */,
    0x00000018    /*  47 JUMP */,
    SG_WORD(-17),
    0x0000002f    /*  49 RET */,
    /* wrong-type-argument-message */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(8),
    0x00000048    /*   3 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected ~a, but got ~a */,
    0x00000045    /*   5 LREF_PUSH */,
    0x00000145    /*   6 LREF_PUSH */,
    0x0000034b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000002f    /*   9 RET */,
    0x00000048    /*  10 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected ~a, but got ~a, as argument ~a */,
    0x00000045    /*  12 LREF_PUSH */,
    0x00000145    /*  13 LREF_PUSH */,
    0x0000025b    /*  14 LREF_CAR_PUSH */,
    0x0000044b    /*  15 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000002f    /*  17 RET */,
    /* #f */0x00000146    /*   0 FREF_PUSH */,
    0x00000005    /*   1 LREF */,
    0x00000043    /*   2 VEC_REF */,
    0x0000000b    /*   3 PUSH */,
    0x00000007    /*   4 FREF */,
    0x0000012d    /*   5 TAIL_CALL */,
    0x0000002f    /*   6 RET */,
    /* #f */0x00000045    /*   0 LREF_PUSH */,
    0x00000007    /*   1 FREF */,
    0x00000043    /*   2 VEC_REF */,
    0x0000002f    /*   3 RET */,
    /* #f */0x00000146    /*   0 FREF_PUSH */,
    0x00000030    /*   1 FRAME */,
    SG_WORD(8),
    0x00000045    /*   3 LREF_PUSH */,
    0x00000029    /*   4 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[19])) /* #<code-builder #f (1 0 1)> */,
    0x0000000b    /*   6 PUSH */,
    0x00000046    /*   7 FREF_PUSH */,
    0x0000024a    /*   8 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0010022a    /*  10 APPLY */,
    0x0000002f    /*  11 RET */,
    /* vector-map */0x00000163    /*   0 RESV_STACK */,
    0x00000009    /*   1 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17185#core.base> */,
    0x00000331    /*   3 INST_STACK */,
    0x00000205    /*   4 LREF */,
    0x00000021    /*   5 BNNULL */,
    SG_WORD(13),
    0x00000105    /*   7 LREF */,
    0x00000042    /*   8 VEC_LEN */,
    0x0000000b    /*   9 PUSH */,
    0x00000145    /*  10 LREF_PUSH */,
    0x00000045    /*  11 LREF_PUSH */,
    0x00000029    /*  12 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[18])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  14 PUSH */,
    0x00000009    /*  15 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17185#core.base> */,
    0x0000022e    /*  17 LOCAL_TAIL_CALL */,
    0x0000002f    /*  18 RET */,
    0x00000145    /*  19 LREF_PUSH */,
    0x00000205    /*  20 LREF */,
    0x00000054    /*  21 CONS_PUSH */,
    0x00000030    /*  22 FRAME */,
    SG_WORD(11),
    0x00000047    /*  24 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier min#core.base> */,
    0x00000030    /*  26 FRAME */,
    SG_WORD(6),
    0x00000047    /*  28 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-length#core.base> */,
    0x00000445    /*  30 LREF_PUSH */,
    0x0000024a    /*  31 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0000022a    /*  33 APPLY */,
    0x0000000b    /*  34 PUSH */,
    0x00000045    /*  35 LREF_PUSH */,
    0x00000445    /*  36 LREF_PUSH */,
    0x00000029    /*  37 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[20])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  39 PUSH */,
    0x00000009    /*  40 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17185#core.base> */,
    0x0000022e    /*  42 LOCAL_TAIL_CALL */,
    0x0000002f    /*  43 RET */,
    /* #f */0x00000146    /*   0 FREF_PUSH */,
    0x00000005    /*   1 LREF */,
    0x00000043    /*   2 VEC_REF */,
    0x0000000b    /*   3 PUSH */,
    0x00000007    /*   4 FREF */,
    0x0000012d    /*   5 TAIL_CALL */,
    0x0000002f    /*   6 RET */,
    /* #f */0x00000045    /*   0 LREF_PUSH */,
    0x00000007    /*   1 FREF */,
    0x00000043    /*   2 VEC_REF */,
    0x0000002f    /*   3 RET */,
    /* #f */0x00000146    /*   0 FREF_PUSH */,
    0x00000030    /*   1 FRAME */,
    SG_WORD(8),
    0x00000045    /*   3 LREF_PUSH */,
    0x00000029    /*   4 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[23])) /* #<code-builder #f (1 0 1)> */,
    0x0000000b    /*   6 PUSH */,
    0x00000046    /*   7 FREF_PUSH */,
    0x0000024a    /*   8 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0010022a    /*  10 APPLY */,
    0x0000002f    /*  11 RET */,
    /* vector-map! */0x00000163    /*   0 RESV_STACK */,
    0x00000009    /*   1 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17184#core.base> */,
    0x00000331    /*   3 INST_STACK */,
    0x00000205    /*   4 LREF */,
    0x00000021    /*   5 BNNULL */,
    SG_WORD(14),
    0x00000145    /*   7 LREF_PUSH */,
    0x00000105    /*   8 LREF */,
    0x00000042    /*   9 VEC_LEN */,
    0x0000000b    /*  10 PUSH */,
    0x00000145    /*  11 LREF_PUSH */,
    0x00000045    /*  12 LREF_PUSH */,
    0x00000029    /*  13 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[22])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  15 PUSH */,
    0x00000009    /*  16 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17184#core.base> */,
    0x0000032e    /*  18 LOCAL_TAIL_CALL */,
    0x0000002f    /*  19 RET */,
    0x00000145    /*  20 LREF_PUSH */,
    0x00000205    /*  21 LREF */,
    0x00000054    /*  22 CONS_PUSH */,
    0x00000145    /*  23 LREF_PUSH */,
    0x00000030    /*  24 FRAME */,
    SG_WORD(11),
    0x00000047    /*  26 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier min#core.base> */,
    0x00000030    /*  28 FRAME */,
    SG_WORD(6),
    0x00000047    /*  30 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-length#core.base> */,
    0x00000445    /*  32 LREF_PUSH */,
    0x0000024a    /*  33 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0000022a    /*  35 APPLY */,
    0x0000000b    /*  36 PUSH */,
    0x00000045    /*  37 LREF_PUSH */,
    0x00000445    /*  38 LREF_PUSH */,
    0x00000029    /*  39 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[24])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  41 PUSH */,
    0x00000009    /*  42 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17184#core.base> */,
    0x0000032e    /*  44 LOCAL_TAIL_CALL */,
    0x0000002f    /*  45 RET */,
    /* #f */0x00000045    /*   0 LREF_PUSH */,
    0x00000007    /*   1 FREF */,
    0x00000043    /*   2 VEC_REF */,
    0x0000002f    /*   3 RET */,
    /* vector-for-each */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(26),
    0x00000105    /*   3 LREF */,
    0x00000042    /*   4 VEC_LEN */,
    0x0000000b    /*   5 PUSH */,
    0x00000049    /*   6 CONSTI_PUSH */,
    0x00000445    /*   7 LREF_PUSH */,
    0x00000305    /*   8 LREF */,
    0x0000001a    /*   9 BNNUME */,
    SG_WORD(3),
    0x00000002    /*  11 UNDEF */,
    0x0000002f    /*  12 RET */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000145    /*  15 LREF_PUSH */,
    0x00000405    /*  16 LREF */,
    0x00000043    /*  17 VEC_REF */,
    0x0000000b    /*  18 PUSH */,
    0x00000005    /*  19 LREF */,
    0x0000012b    /*  20 CALL */,
    0x00000405    /*  21 LREF */,
    0x0000010f    /*  22 ADDI */,
    0x0000000b    /*  23 PUSH */,
    0x00400119    /*  24 SHIFTJ */,
    0x00000018    /*  25 JUMP */,
    SG_WORD(-19),
    0x0000002f    /*  27 RET */,
    0x00000145    /*  28 LREF_PUSH */,
    0x00000205    /*  29 LREF */,
    0x00000054    /*  30 CONS_PUSH */,
    0x00000030    /*  31 FRAME */,
    SG_WORD(11),
    0x00000047    /*  33 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier min#core.base> */,
    0x00000030    /*  35 FRAME */,
    SG_WORD(6),
    0x00000047    /*  37 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-length#core.base> */,
    0x00000345    /*  39 LREF_PUSH */,
    0x0000024a    /*  40 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0000022a    /*  42 APPLY */,
    0x0000000b    /*  43 PUSH */,
    0x00000049    /*  44 CONSTI_PUSH */,
    0x00000545    /*  45 LREF_PUSH */,
    0x00000405    /*  46 LREF */,
    0x0000001a    /*  47 BNNUME */,
    SG_WORD(3),
    0x00000002    /*  49 UNDEF */,
    0x0000002f    /*  50 RET */,
    0x00000030    /*  51 FRAME */,
    SG_WORD(12),
    0x00000045    /*  53 LREF_PUSH */,
    0x00000030    /*  54 FRAME */,
    SG_WORD(8),
    0x00000545    /*  56 LREF_PUSH */,
    0x00000029    /*  57 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[26])) /* #<code-builder #f (1 0 1)> */,
    0x0000000b    /*  59 PUSH */,
    0x00000345    /*  60 LREF_PUSH */,
    0x0000024a    /*  61 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0000022a    /*  63 APPLY */,
    0x00000505    /*  64 LREF */,
    0x0000010f    /*  65 ADDI */,
    0x0000000b    /*  66 PUSH */,
    0x00500119    /*  67 SHIFTJ */,
    0x00000018    /*  68 JUMP */,
    SG_WORD(-24),
    0x0000002f    /*  70 RET */,
    /* #f */0x00000045    /*   0 LREF_PUSH */,
    0x00000046    /*   1 FREF_PUSH */,
    0x0000024b    /*   2 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier string-ref#core.base> */,
    0x0000002f    /*   4 RET */,
    /* string-for-each */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(32),
    0x00000030    /*   3 FRAME */,
    SG_WORD(4),
    0x00000145    /*   5 LREF_PUSH */,
    0x0000014a    /*   6 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier string-length#core.base> */,
    0x0000000b    /*   8 PUSH */,
    0x00000049    /*   9 CONSTI_PUSH */,
    0x00000445    /*  10 LREF_PUSH */,
    0x00000305    /*  11 LREF */,
    0x0000001a    /*  12 BNNUME */,
    SG_WORD(3),
    0x00000002    /*  14 UNDEF */,
    0x0000002f    /*  15 RET */,
    0x00000030    /*  16 FRAME */,
    SG_WORD(10),
    0x00000030    /*  18 FRAME */,
    SG_WORD(5),
    0x00000145    /*  20 LREF_PUSH */,
    0x00000445    /*  21 LREF_PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier string-ref#core.base> */,
    0x0000000b    /*  24 PUSH */,
    0x00000005    /*  25 LREF */,
    0x0000012b    /*  26 CALL */,
    0x00000405    /*  27 LREF */,
    0x0000010f    /*  28 ADDI */,
    0x0000000b    /*  29 PUSH */,
    0x00400119    /*  30 SHIFTJ */,
    0x00000018    /*  31 JUMP */,
    SG_WORD(-22),
    0x0000002f    /*  33 RET */,
    0x00000145    /*  34 LREF_PUSH */,
    0x00000205    /*  35 LREF */,
    0x00000054    /*  36 CONS_PUSH */,
    0x00000030    /*  37 FRAME */,
    SG_WORD(11),
    0x00000047    /*  39 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier min#core.base> */,
    0x00000030    /*  41 FRAME */,
    SG_WORD(6),
    0x00000047    /*  43 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-length#core.base> */,
    0x00000345    /*  45 LREF_PUSH */,
    0x0000024a    /*  46 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0000022a    /*  48 APPLY */,
    0x0000000b    /*  49 PUSH */,
    0x00000049    /*  50 CONSTI_PUSH */,
    0x00000545    /*  51 LREF_PUSH */,
    0x00000405    /*  52 LREF */,
    0x0000001a    /*  53 BNNUME */,
    SG_WORD(3),
    0x00000002    /*  55 UNDEF */,
    0x0000002f    /*  56 RET */,
    0x00000030    /*  57 FRAME */,
    SG_WORD(12),
    0x00000045    /*  59 LREF_PUSH */,
    0x00000030    /*  60 FRAME */,
    SG_WORD(8),
    0x00000545    /*  62 LREF_PUSH */,
    0x00000029    /*  63 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[28])) /* #<code-builder #f (1 0 1)> */,
    0x0000000b    /*  65 PUSH */,
    0x00000345    /*  66 LREF_PUSH */,
    0x0000024a    /*  67 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x0000022a    /*  69 APPLY */,
    0x00000505    /*  70 LREF */,
    0x0000010f    /*  71 ADDI */,
    0x0000000b    /*  72 PUSH */,
    0x00500119    /*  73 SHIFTJ */,
    0x00000018    /*  74 JUMP */,
    SG_WORD(-24),
    0x0000002f    /*  76 RET */,
    /* recur */0x00000005    /*   0 LREF */,
    0x0000003e    /*   1 PAIRP */,
    0x00000017    /*   2 TEST */,
    SG_WORD(11),
    0x00000246    /*   4 FREF_PUSH */,
    0x0000005b    /*   5 LREF_CAR_PUSH */,
    0x00000030    /*   6 FRAME */,
    SG_WORD(4),
    0x0000005c    /*   8 LREF_CDR_PUSH */,
    0x00000107    /*   9 FREF */,
    0x0000012c    /*  10 LOCAL_CALL */,
    0x00000037    /*  11 CONS */,
    0x00000037    /*  12 CONS */,
    0x0000002f    /*  13 RET */,
    0x00000007    /*  14 FREF */,
    0x0000002f    /*  15 RET */,
    /* buildit */0x00000163    /*   0 RESV_STACK */,
    0x00000046    /*   1 FREF_PUSH */,
    0x00000245    /*   2 LREF_PUSH */,
    0x00000145    /*   3 LREF_PUSH */,
    0x00000229    /*   4 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[30])) /* #<code-builder recur (1 0 3)> */,
    0x00000231    /*   6 INST_STACK */,
    0x00000045    /*   7 LREF_PUSH */,
    0x00000205    /*   8 LREF */,
    0x0000012e    /*   9 LOCAL_TAIL_CALL */,
    0x0000002f    /*  10 RET */,
    /* string-join */0x00000105    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(5),
    0x00000003    /*   3 CONST */,
    SG_WORD(SG_UNDEF) /*   */,
    0x00000018    /*   5 JUMP */,
    SG_WORD(2),
    0x00000155    /*   7 LREF_CAR */,
    0x0000000b    /*   8 PUSH */,
    0x00000105    /*   9 LREF */,
    0x00000021    /*  10 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  12 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x00000018    /*  14 JUMP */,
    SG_WORD(2),
    0x00000156    /*  16 LREF_CDR */,
    0x0000000b    /*  17 PUSH */,
    0x00000305    /*  18 LREF */,
    0x00000021    /*  19 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  21 CONST */,
    SG_WORD(SG_UNDEF) /* infix */,
    0x00000018    /*  23 JUMP */,
    SG_WORD(2),
    0x00000355    /*  25 LREF_CAR */,
    0x0000000b    /*  26 PUSH */,
    0x00000305    /*  27 LREF */,
    0x00000021    /*  28 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  30 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x00000018    /*  32 JUMP */,
    SG_WORD(2),
    0x00000356    /*  34 LREF_CDR */,
    0x0000000b    /*  35 PUSH */,
    0x00000505    /*  36 LREF */,
    0x00000021    /*  37 BNNULL */,
    SG_WORD(4),
    0x00000002    /*  39 UNDEF */,
    0x00000018    /*  40 JUMP */,
    SG_WORD(11),
    0x00000030    /*  42 FRAME */,
    SG_WORD(9),
    0x00000048    /*  44 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* lambda */,
    0x00000048    /*  46 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* too many argument for */,
    0x00000048    /*  48 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* ((define (buildit lis final) (let recur ((lis lis)) (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final))) (unless (string? delim) (error 'string-join Delimiter must be a string delim)) (cond ((pair? strings) (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join Illegal join grammar grammar string-join))))) ((not (null? strings)) (error 'string-join STRINGS parameter not list. strings string-join)) ((eq? grammar 'strict-infix) (error 'string-join Empty list cannot be joined with STRICT-INFIX grammar. string-join)) (else ))) */,
    0x0000034a    /*  50 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#(sagittarius compiler)> */,
    0x00000163    /*  52 RESV_STACK */,
    0x00000245    /*  53 LREF_PUSH */,
    0x00000029    /*  54 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[31])) /* #<code-builder buildit (2 0 1)> */,
    0x00000631    /*  56 INST_STACK */,
    0x00000030    /*  57 FRAME */,
    SG_WORD(4),
    0x00000245    /*  59 LREF_PUSH */,
    0x0000014a    /*  60 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier string?#core.base> */,
    0x00000017    /*  62 TEST */,
    SG_WORD(4),
    0x00000002    /*  64 UNDEF */,
    0x00000018    /*  65 JUMP */,
    SG_WORD(10),
    0x00000030    /*  67 FRAME */,
    SG_WORD(8),
    0x00000048    /*  69 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* string-join */,
    0x00000048    /*  71 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* Delimiter must be a string */,
    0x00000245    /*  73 LREF_PUSH */,
    0x0000034a    /*  74 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#core.base> */,
    0x00000005    /*  76 LREF */,
    0x0000003e    /*  77 PAIRP */,
    0x00000017    /*  78 TEST */,
    SG_WORD(67),
    0x00000030    /*  80 FRAME */,
    SG_WORD(6),
    0x00000445    /*  82 LREF_PUSH */,
    0x00000048    /*  83 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (infix strict-infix) */,
    0x0000024a    /*  85 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier memv#(sagittarius compiler)> */,
    0x00000017    /*  87 TEST */,
    SG_WORD(12),
    0x0000005b    /*  89 LREF_CAR_PUSH */,
    0x00000030    /*  90 FRAME */,
    SG_WORD(6),
    0x0000005c    /*  92 LREF_CDR_PUSH */,
    0x00000048    /*  93 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000605    /*  95 LREF */,
    0x0000022c    /*  96 LOCAL_CALL */,
    0x00000037    /*  97 CONS */,
    0x00000018    /*  98 JUMP */,
    SG_WORD(43),
    0x00000445    /* 100 LREF_PUSH */,
    0x00000003    /* 101 CONST */,
    SG_WORD(SG_UNDEF) /* prefix */,
    0x0000001f    /* 103 BNEQ */,
    SG_WORD(10),
    0x00000030    /* 105 FRAME */,
    SG_WORD(6),
    0x00000045    /* 107 LREF_PUSH */,
    0x00000048    /* 108 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000605    /* 110 LREF */,
    0x0000022c    /* 111 LOCAL_CALL */,
    0x00000018    /* 112 JUMP */,
    SG_WORD(29),
    0x00000445    /* 114 LREF_PUSH */,
    0x00000003    /* 115 CONST */,
    SG_WORD(SG_UNDEF) /* suffix */,
    0x0000001f    /* 117 BNEQ */,
    SG_WORD(13),
    0x0000005b    /* 119 LREF_CAR_PUSH */,
    0x00000030    /* 120 FRAME */,
    SG_WORD(7),
    0x0000005c    /* 122 LREF_CDR_PUSH */,
    0x00000205    /* 123 LREF */,
    0x00000138    /* 124 LIST */,
    0x0000000b    /* 125 PUSH */,
    0x00000605    /* 126 LREF */,
    0x0000022c    /* 127 LOCAL_CALL */,
    0x00000037    /* 128 CONS */,
    0x00000018    /* 129 JUMP */,
    SG_WORD(12),
    0x00000030    /* 131 FRAME */,
    SG_WORD(10),
    0x00000048    /* 133 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* string-join */,
    0x00000048    /* 135 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* Illegal join grammar */,
    0x00000445    /* 137 LREF_PUSH */,
    0x00000047    /* 138 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-join#core.base> */,
    0x0000044a    /* 140 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#core.base> */,
    0x0000000b    /* 142 PUSH */,
    0x0000014b    /* 143 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier string-concatenate#core.base> */,
    0x0000002f    /* 145 RET */,
    0x00000005    /* 146 LREF */,
    0x00000021    /* 147 BNNULL */,
    SG_WORD(17),
    0x00000445    /* 149 LREF_PUSH */,
    0x00000003    /* 150 CONST */,
    SG_WORD(SG_UNDEF) /* strict-infix */,
    0x0000001f    /* 152 BNEQ */,
    SG_WORD(10),
    0x00000048    /* 154 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* string-join */,
    0x00000048    /* 156 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* Empty list cannot be joined with STRICT-INFIX grammar. */,
    0x00000047    /* 158 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-join#core.base> */,
    0x0000034b    /* 160 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#core.base> */,
    0x0000002f    /* 162 RET */,
    0x00000061    /* 163 CONST_RET */,
    SG_WORD(SG_UNDEF) /*  */,
    0x00000048    /* 165 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* string-join */,
    0x00000048    /* 167 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* STRINGS parameter not list. */,
    0x00000045    /* 169 LREF_PUSH */,
    0x00000047    /* 170 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-join#core.base> */,
    0x0000044b    /* 172 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#core.base> */,
    0x0000002f    /* 174 RET */,
    /* null-list? */0x00000005    /*   0 LREF */,
    0x0000003e    /*   1 PAIRP */,
    0x00000017    /*   2 TEST */,
    SG_WORD(3),
    0x00000061    /*   4 CONST_RET */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000005    /*   6 LREF */,
    0x00000021    /*   7 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   9 CONST_RET */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* null-list? */,
    0x00000048    /*  13 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* argument out of domain */,
    0x00000045    /*  15 LREF_PUSH */,
    0x0000034b    /*  16 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  18 RET */,
    /* split-at */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000145    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier integer?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* split-at */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* integer */,
    0x00000145    /*  17 LREF_PUSH */,
    0x00000249    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000045    /*  24 LREF_PUSH */,
    0x00000145    /*  25 LREF_PUSH */,
    0x00000048    /*  26 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000345    /*  28 LREF_PUSH */,
    0x00000004    /*  29 CONSTI */,
    0x0000001a    /*  30 BNNUME */,
    SG_WORD(10),
    0x00000030    /*  32 FRAME */,
    SG_WORD(4),
    0x00000445    /*  34 LREF_PUSH */,
    0x0000014a    /*  35 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000000b    /*  37 PUSH */,
    0x00000205    /*  38 LREF */,
    0x0000023a    /*  39 VALUES */,
    0x0000002f    /*  40 RET */,
    0x00000205    /*  41 LREF */,
    0x00000021    /*  42 BNNULL */,
    SG_WORD(8),
    0x00000048    /*  44 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* split-at */,
    0x00000048    /*  46 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* given list it too short */,
    0x0000024b    /*  48 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#core.base> */,
    0x0000002f    /*  50 RET */,
    0x0000025c    /*  51 LREF_CDR_PUSH */,
    0x00000305    /*  52 LREF */,
    -0x000000f1   /*  53 ADDI */,
    0x0000000b    /*  54 PUSH */,
    0x0000025b    /*  55 LREF_CAR_PUSH */,
    0x00000405    /*  56 LREF */,
    0x00000054    /*  57 CONS_PUSH */,
    0x00200319    /*  58 SHIFTJ */,
    0x00000018    /*  59 JUMP */,
    SG_WORD(-32),
    0x0000002f    /*  61 RET */,
    /* find */0x00000030    /*   0 FRAME */,
    SG_WORD(5),
    0x00000045    /*   2 LREF_PUSH */,
    0x00000145    /*   3 LREF_PUSH */,
    0x0000024a    /*   4 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier find-tail#core.base> */,
    0x0000000b    /*   6 PUSH */,
    0x00000205    /*   7 LREF */,
    0x00000017    /*   8 TEST */,
    SG_WORD(2),
    0x00000255    /*  10 LREF_CAR */,
    0x0000002f    /*  11 RET */,
    /* find-tail */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* find-tail */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  17 LREF_PUSH */,
    0x00000249    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000145    /*  24 LREF_PUSH */,
    0x00000205    /*  25 LREF */,
    0x0000003d    /*  26 NULLP */,
    0x00000022    /*  27 NOT */,
    0x00000017    /*  28 TEST */,
    SG_WORD(14),
    0x00000030    /*  30 FRAME */,
    SG_WORD(4),
    0x0000025b    /*  32 LREF_CAR_PUSH */,
    0x00000005    /*  33 LREF */,
    0x0000012b    /*  34 CALL */,
    0x00000017    /*  35 TEST */,
    SG_WORD(3),
    0x00000205    /*  37 LREF */,
    0x0000002f    /*  38 RET */,
    0x0000025c    /*  39 LREF_CDR_PUSH */,
    0x00200119    /*  40 SHIFTJ */,
    0x00000018    /*  41 JUMP */,
    SG_WORD(-17),
    0x0000002f    /*  43 RET */,
    /* #f */0x00000146    /*   0 FREF_PUSH */,
    0x0000005b    /*   1 LREF_CAR_PUSH */,
    0x00000057    /*   2 FREF_CAR */,
    0x0000022d    /*   3 TAIL_CALL */,
    0x0000002f    /*   4 RET */,
    /* assoc */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000145    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier list?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* assoc */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* list */,
    0x00000145    /*  17 LREF_PUSH */,
    0x00000249    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000205    /*  24 LREF */,
    0x00000021    /*  25 BNNULL */,
    SG_WORD(8),
    0x00000045    /*  27 LREF_PUSH */,
    0x00000145    /*  28 LREF_PUSH */,
    0x00000047    /*  29 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier equal?#core.base> */,
    0x0000034b    /*  31 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assoc#core.base> */,
    0x0000002f    /*  33 RET */,
    0x00000045    /*  34 LREF_PUSH */,
    0x00000245    /*  35 LREF_PUSH */,
    0x00000029    /*  36 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[37])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  38 PUSH */,
    0x00000145    /*  39 LREF_PUSH */,
    0x0000024b    /*  40 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier find#core.base> */,
    0x0000002f    /*  42 RET */,
    /* #f */0x00000146    /*   0 FREF_PUSH */,
    0x00000045    /*   1 LREF_PUSH */,
    0x00000057    /*   2 FREF_CAR */,
    0x0000022d    /*   3 TAIL_CALL */,
    0x0000002f    /*   4 RET */,
    /* member */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(8),
    0x00000045    /*   3 LREF_PUSH */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000047    /*   5 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier equal?#core.base> */,
    0x0000034b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier member#core.base> */,
    0x0000002f    /*   9 RET */,
    0x00000045    /*  10 LREF_PUSH */,
    0x00000245    /*  11 LREF_PUSH */,
    0x00000029    /*  12 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[39])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  14 PUSH */,
    0x00000145    /*  15 LREF_PUSH */,
    0x0000024b    /*  16 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier find-tail#core.base> */,
    0x0000002f    /*  18 RET */,
    /* #f */0x00000030    /*   0 FRAME */,
    SG_WORD(5),
    0x00000146    /*   2 FREF_PUSH */,
    0x00000045    /*   3 LREF_PUSH */,
    0x00000057    /*   4 FREF_CAR */,
    0x0000022b    /*   5 CALL */,
    0x00000022    /*   6 NOT */,
    0x0000002f    /*   7 RET */,
    /* delete */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(8),
    0x00000045    /*   3 LREF_PUSH */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000047    /*   5 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier equal?#core.base> */,
    0x0000034b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier delete#core.base> */,
    0x0000002f    /*   9 RET */,
    0x00000045    /*  10 LREF_PUSH */,
    0x00000245    /*  11 LREF_PUSH */,
    0x00000029    /*  12 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[41])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  14 PUSH */,
    0x00000145    /*  15 LREF_PUSH */,
    0x0000024b    /*  16 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.base> */,
    0x0000002f    /*  18 RET */,
    /* #f */0x00000030    /*   0 FRAME */,
    SG_WORD(5),
    0x00000146    /*   2 FREF_PUSH */,
    0x00000045    /*   3 LREF_PUSH */,
    0x00000057    /*   4 FREF_CAR */,
    0x0000022b    /*   5 CALL */,
    0x00000022    /*   6 NOT */,
    0x0000002f    /*   7 RET */,
    /* delete! */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(8),
    0x00000045    /*   3 LREF_PUSH */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000047    /*   5 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier equal?#core.base> */,
    0x0000034b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier delete#core.base> */,
    0x0000002f    /*   9 RET */,
    0x00000045    /*  10 LREF_PUSH */,
    0x00000245    /*  11 LREF_PUSH */,
    0x00000029    /*  12 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[43])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  14 PUSH */,
    0x00000145    /*  15 LREF_PUSH */,
    0x0000024b    /*  16 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter!#core.base> */,
    0x0000002f    /*  18 RET */,
    /* reduce */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(17),
    0x00000030    /*   9 FRAME */,
    SG_WORD(15),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* reduce */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(8),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000047    /*  17 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier =#core.base> */,
    0x00000149    /*  19 CONSTI_PUSH */,
    0x0000034a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  22 PUSH */,
    0x0000024a    /*  23 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000205    /*  25 LREF */,
    0x00000021    /*  26 BNNULL */,
    SG_WORD(3),
    0x00000105    /*  28 LREF */,
    0x0000002f    /*  29 RET */,
    0x00000045    /*  30 LREF_PUSH */,
    0x0000025b    /*  31 LREF_CAR_PUSH */,
    0x0000025c    /*  32 LREF_CDR_PUSH */,
    0x0000034b    /*  33 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier fold#core.base> */,
    0x0000002f    /*  35 RET */,
    /* #f */0x00000045    /*   0 LREF_PUSH */,
    0x00000146    /*   1 FREF_PUSH */,
    0x00000007    /*   2 FREF */,
    0x0000022d    /*   3 TAIL_CALL */,
    0x0000002f    /*   4 RET */,
    /* #f */0x00000030    /*   0 FRAME */,
    SG_WORD(9),
    0x00000045    /*   2 LREF_PUSH */,
    0x00000046    /*   3 FREF_PUSH */,
    0x00000029    /*   4 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[46])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*   6 PUSH */,
    0x00000145    /*   7 LREF_PUSH */,
    0x0000024a    /*   8 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier exists#core.base> */,
    0x00000017    /*  10 TEST */,
    SG_WORD(3),
    0x00000105    /*  12 LREF */,
    0x0000002f    /*  13 RET */,
    0x00000045    /*  14 LREF_PUSH */,
    0x00000105    /*  15 LREF */,
    0x00000037    /*  16 CONS */,
    0x0000002f    /*  17 RET */,
    /* #f */0x00000005    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(3),
    0x00000105    /*   3 LREF */,
    0x0000002f    /*   4 RET */,
    0x00000105    /*   5 LREF */,
    0x00000021    /*   6 BNNULL */,
    SG_WORD(3),
    0x00000005    /*   8 LREF */,
    0x0000002f    /*   9 RET */,
    0x00000045    /*  10 LREF_PUSH */,
    0x00000105    /*  11 LREF */,
    0x0000001f    /*  12 BNEQ */,
    SG_WORD(3),
    0x00000105    /*  14 LREF */,
    0x0000002f    /*  15 RET */,
    0x00000046    /*  16 FREF_PUSH */,
    0x00000029    /*  17 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[47])) /* #<code-builder #f (2 0 1)> */,
    0x0000000b    /*  19 PUSH */,
    0x00000145    /*  20 LREF_PUSH */,
    0x00000045    /*  21 LREF_PUSH */,
    0x0000034b    /*  22 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier fold#core.base> */,
    0x0000002f    /*  24 RET */,
    /* lset-union */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* lset-union */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  17 LREF_PUSH */,
    0x00000149    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000045    /*  24 LREF_PUSH */,
    0x00000029    /*  25 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[48])) /* #<code-builder #f (2 0 1)> */,
    0x0000000b    /*  27 PUSH */,
    0x00000048    /*  28 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000145    /*  30 LREF_PUSH */,
    0x0000034b    /*  31 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reduce#core.base> */,
    0x0000002f    /*  33 RET */,
    /* #f */0x00000146    /*   0 FREF_PUSH */,
    0x00000045    /*   1 LREF_PUSH */,
    0x00000046    /*   2 FREF_PUSH */,
    0x0000034b    /*   3 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier member#core.base> */,
    0x0000002f    /*   5 RET */,
    /* #f */0x00000045    /*   0 LREF_PUSH */,
    0x00000146    /*   1 FREF_PUSH */,
    0x00000029    /*   2 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[50])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*   4 PUSH */,
    0x00000046    /*   5 FREF_PUSH */,
    0x0000024b    /*   6 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier for-all#core.base> */,
    0x0000002f    /*   8 RET */,
    /* lset-intersection */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* lset-intersection */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  17 LREF_PUSH */,
    0x00000149    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  24 FRAME */,
    SG_WORD(7),
    0x00000145    /*  26 LREF_PUSH */,
    0x00000245    /*  27 LREF_PUSH */,
    0x00000047    /*  28 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier eq?#core.base> */,
    0x0000034a    /*  30 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier delete#core.base> */,
    0x0000000b    /*  32 PUSH */,
    0x00000030    /*  33 FRAME */,
    SG_WORD(6),
    0x00000047    /*  35 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier null?#core.base> */,
    0x00000345    /*  37 LREF_PUSH */,
    0x0000024a    /*  38 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier exists#core.base> */,
    0x00000017    /*  40 TEST */,
    SG_WORD(3),
    0x00000061    /*  42 CONST_RET */,
    SG_WORD(SG_NIL) /* () */,
    0x00000305    /*  44 LREF */,
    0x00000021    /*  45 BNNULL */,
    SG_WORD(3),
    0x00000105    /*  47 LREF */,
    0x0000002f    /*  48 RET */,
    0x00000045    /*  49 LREF_PUSH */,
    0x00000345    /*  50 LREF_PUSH */,
    0x00000029    /*  51 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[51])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  53 PUSH */,
    0x00000145    /*  54 LREF_PUSH */,
    0x0000024b    /*  55 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.base> */,
    0x0000002f    /*  57 RET */,
    /* #f */0x00000030    /*   0 FRAME */,
    SG_WORD(6),
    0x00000146    /*   2 FREF_PUSH */,
    0x00000045    /*   3 LREF_PUSH */,
    0x00000046    /*   4 FREF_PUSH */,
    0x0000034a    /*   5 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier member#core.base> */,
    0x00000022    /*   7 NOT */,
    0x0000002f    /*   8 RET */,
    /* #f */0x00000045    /*   0 LREF_PUSH */,
    0x00000146    /*   1 FREF_PUSH */,
    0x00000029    /*   2 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[53])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*   4 PUSH */,
    0x00000046    /*   5 FREF_PUSH */,
    0x0000024b    /*   6 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier for-all#core.base> */,
    0x0000002f    /*   8 RET */,
    /* lset-difference */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* lset-difference */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  17 LREF_PUSH */,
    0x00000149    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  24 FRAME */,
    SG_WORD(6),
    0x00000047    /*  26 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier pair?#core.base> */,
    0x00000245    /*  28 LREF_PUSH */,
    0x0000024a    /*  29 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.base> */,
    0x0000000b    /*  31 PUSH */,
    0x00000305    /*  32 LREF */,
    0x00000021    /*  33 BNNULL */,
    SG_WORD(3),
    0x00000105    /*  35 LREF */,
    0x0000002f    /*  36 RET */,
    0x00000030    /*  37 FRAME */,
    SG_WORD(5),
    0x00000145    /*  39 LREF_PUSH */,
    0x00000345    /*  40 LREF_PUSH */,
    0x0000024a    /*  41 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier memq#core.base> */,
    0x00000017    /*  43 TEST */,
    SG_WORD(3),
    0x00000061    /*  45 CONST_RET */,
    SG_WORD(SG_NIL) /* () */,
    0x00000045    /*  47 LREF_PUSH */,
    0x00000345    /*  48 LREF_PUSH */,
    0x00000029    /*  49 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[54])) /* #<code-builder #f (1 0 2)> */,
    0x0000000b    /*  51 PUSH */,
    0x00000145    /*  52 LREF_PUSH */,
    0x0000024b    /*  53 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.base> */,
    0x0000002f    /*  55 RET */,
    /* take */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000145    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier integer?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* take */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* integer */,
    0x00000145    /*  17 LREF_PUSH */,
    0x00000249    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000163    /*  24 RESV_STACK */,
    0x00000009    /*  25 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17183#core.base> */,
    0x00000231    /*  27 INST_STACK */,
    0x00000045    /*  28 LREF_PUSH */,
    0x00000145    /*  29 LREF_PUSH */,
    0x00000009    /*  30 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17183#core.base> */,
    0x0000022e    /*  32 LOCAL_TAIL_CALL */,
    0x0000002f    /*  33 RET */,
    /* drop */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000145    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier integer?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(16),
    0x00000030    /*   9 FRAME */,
    SG_WORD(14),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* drop */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(7),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* integer */,
    0x00000145    /*  17 LREF_PUSH */,
    0x00000249    /*  18 CONSTI_PUSH */,
    0x0000034a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  21 PUSH */,
    0x0000024a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000045    /*  24 LREF_PUSH */,
    0x00000145    /*  25 LREF_PUSH */,
    0x00000345    /*  26 LREF_PUSH */,
    0x00000004    /*  27 CONSTI */,
    0x0000001a    /*  28 BNNUME */,
    SG_WORD(3),
    0x00000205    /*  30 LREF */,
    0x0000002f    /*  31 RET */,
    0x0000025c    /*  32 LREF_CDR_PUSH */,
    0x00000305    /*  33 LREF */,
    -0x000000f1   /*  34 ADDI */,
    0x0000000b    /*  35 PUSH */,
    0x00200219    /*  36 SHIFTJ */,
    0x00000018    /*  37 JUMP */,
    SG_WORD(-12),
    0x0000002f    /*  39 RET */,
    /* make-ci-comparison */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x00000107    /*   3 FREF */,
    0x0000012b    /*   4 CALL */,
    0x0000000b    /*   5 PUSH */,
    0x00000030    /*   6 FRAME */,
    SG_WORD(4),
    0x00000145    /*   8 LREF_PUSH */,
    0x00000107    /*   9 FREF */,
    0x0000012b    /*  10 CALL */,
    0x0000000b    /*  11 PUSH */,
    0x00000245    /*  12 LREF_PUSH */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(5),
    0x00000345    /*  15 LREF_PUSH */,
    0x00000445    /*  16 LREF_PUSH */,
    0x00000007    /*  17 FREF */,
    0x0000022b    /*  18 CALL */,
    0x00000017    /*  19 TEST */,
    SG_WORD(16),
    0x00000505    /*  21 LREF */,
    0x00000021    /*  22 BNNULL */,
    SG_WORD(2),
    0x0000002f    /*  24 RET */,
    0x00000445    /*  25 LREF_PUSH */,
    0x00000030    /*  26 FRAME */,
    SG_WORD(4),
    0x0000055b    /*  28 LREF_CAR_PUSH */,
    0x00000107    /*  29 FREF */,
    0x0000012b    /*  30 CALL */,
    0x0000000b    /*  31 PUSH */,
    0x0000055c    /*  32 LREF_CDR_PUSH */,
    0x00300319    /*  33 SHIFTJ */,
    0x00000018    /*  34 JUMP */,
    SG_WORD(-22),
    0x0000002f    /*  36 RET */,
    /* make-ci-comparison */0x00000145    /*   0 LREF_PUSH */,
    0x00000045    /*   1 LREF_PUSH */,
    0x00000029    /*   2 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[58])) /* #<code-builder make-ci-comparison (2 1 2)> */,
    0x0000002f    /*   4 RET */,
    /* bytevector-uint-ref */0x00000245    /*   0 LREF_PUSH */,
    0x00000003    /*   1 CONST */,
    SG_WORD(SG_UNDEF) /* big */,
    0x0000001f    /*   3 BNEQ */,
    SG_WORD(32),
    0x00000145    /*   5 LREF_PUSH */,
    0x00000305    /*   6 LREF */,
    0x0000000e    /*   7 ADD */,
    0x0000000b    /*   8 PUSH */,
    0x00000145    /*   9 LREF_PUSH */,
    0x00000049    /*  10 CONSTI_PUSH */,
    0x00000545    /*  11 LREF_PUSH */,
    0x00000405    /*  12 LREF */,
    0x0000001e    /*  13 BNGE */,
    SG_WORD(3),
    0x00000605    /*  15 LREF */,
    0x0000002f    /*  16 RET */,
    0x00000505    /*  17 LREF */,
    0x0000010f    /*  18 ADDI */,
    0x0000000b    /*  19 PUSH */,
    0x00010049    /*  20 CONSTI_PUSH */,
    0x00000605    /*  21 LREF */,
    0x00000012    /*  22 MUL */,
    0x0000000b    /*  23 PUSH */,
    0x00000030    /*  24 FRAME */,
    SG_WORD(5),
    0x00000045    /*  26 LREF_PUSH */,
    0x00000545    /*  27 LREF_PUSH */,
    0x0000024a    /*  28 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-u8-ref#core.base> */,
    0x0000000e    /*  30 ADD */,
    0x0000000b    /*  31 PUSH */,
    0x00500219    /*  32 SHIFTJ */,
    0x00000018    /*  33 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  35 RET */,
    0x00000245    /*  36 LREF_PUSH */,
    0x00000003    /*  37 CONST */,
    SG_WORD(SG_UNDEF) /* little */,
    0x0000001f    /*  39 BNEQ */,
    SG_WORD(32),
    0x00000145    /*  41 LREF_PUSH */,
    0x00000305    /*  42 LREF */,
    0x0000000e    /*  43 ADD */,
    -0x000000f1   /*  44 ADDI */,
    0x0000000b    /*  45 PUSH */,
    0x00000049    /*  46 CONSTI_PUSH */,
    0x00000445    /*  47 LREF_PUSH */,
    0x00000105    /*  48 LREF */,
    0x0000001b    /*  49 BNLT */,
    SG_WORD(3),
    0x00000505    /*  51 LREF */,
    0x0000002f    /*  52 RET */,
    0x00000405    /*  53 LREF */,
    -0x000000f1   /*  54 ADDI */,
    0x0000000b    /*  55 PUSH */,
    0x00010049    /*  56 CONSTI_PUSH */,
    0x00000505    /*  57 LREF */,
    0x00000012    /*  58 MUL */,
    0x0000000b    /*  59 PUSH */,
    0x00000030    /*  60 FRAME */,
    SG_WORD(5),
    0x00000045    /*  62 LREF_PUSH */,
    0x00000445    /*  63 LREF_PUSH */,
    0x0000024a    /*  64 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-u8-ref#core.base> */,
    0x0000000e    /*  66 ADD */,
    0x0000000b    /*  67 PUSH */,
    0x00400219    /*  68 SHIFTJ */,
    0x00000018    /*  69 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  71 RET */,
    0x00000048    /*  72 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* bytevector-uint-ref */,
    0x00000030    /*  74 FRAME */,
    SG_WORD(6),
    0x00000048    /*  76 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected endianness, but got ~s, as argument 3 */,
    0x00000245    /*  78 LREF_PUSH */,
    0x0000024a    /*  79 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  81 PUSH */,
    0x00000045    /*  82 LREF_PUSH */,
    0x00000145    /*  83 LREF_PUSH */,
    0x00000245    /*  84 LREF_PUSH */,
    0x00000305    /*  85 LREF */,
    0x00000438    /*  86 LIST */,
    0x0000000b    /*  87 PUSH */,
    0x0000034b    /*  88 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  90 RET */,
    /* bytevector-sint-ref */0x00000245    /*   0 LREF_PUSH */,
    0x00000003    /*   1 CONST */,
    SG_WORD(SG_UNDEF) /* big */,
    0x0000001f    /*   3 BNEQ */,
    SG_WORD(35),
    0x00000030    /*   5 FRAME */,
    SG_WORD(5),
    0x00000045    /*   7 LREF_PUSH */,
    0x00000145    /*   8 LREF_PUSH */,
    0x0000024a    /*   9 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-u8-ref#core.base> */,
    0x0000000b    /*  11 PUSH */,
    0x00007f04    /*  12 CONSTI */,
    0x0000001d    /*  13 BNGT */,
    SG_WORD(18),
    0x00000030    /*  15 FRAME */,
    SG_WORD(7),
    0x00000045    /*  17 LREF_PUSH */,
    0x00000145    /*  18 LREF_PUSH */,
    0x00000245    /*  19 LREF_PUSH */,
    0x00000345    /*  20 LREF_PUSH */,
    0x0000044a    /*  21 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-ref#core.base> */,
    0x0000000b    /*  23 PUSH */,
    0x00000030    /*  24 FRAME */,
    SG_WORD(5),
    0x00010049    /*  26 CONSTI_PUSH */,
    0x00000345    /*  27 LREF_PUSH */,
    0x0000024a    /*  28 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier expt#core.base> */,
    0x00000010    /*  30 SUB */,
    0x0000002f    /*  31 RET */,
    0x00000045    /*  32 LREF_PUSH */,
    0x00000145    /*  33 LREF_PUSH */,
    0x00000245    /*  34 LREF_PUSH */,
    0x00000345    /*  35 LREF_PUSH */,
    0x0000044b    /*  36 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-ref#core.base> */,
    0x0000002f    /*  38 RET */,
    0x00000245    /*  39 LREF_PUSH */,
    0x00000003    /*  40 CONST */,
    SG_WORD(SG_UNDEF) /* little */,
    0x0000001f    /*  42 BNEQ */,
    SG_WORD(39),
    0x00000030    /*  44 FRAME */,
    SG_WORD(9),
    0x00000045    /*  46 LREF_PUSH */,
    0x00000145    /*  47 LREF_PUSH */,
    0x00000305    /*  48 LREF */,
    0x0000000e    /*  49 ADD */,
    -0x000000f1   /*  50 ADDI */,
    0x0000000b    /*  51 PUSH */,
    0x0000024a    /*  52 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-u8-ref#core.base> */,
    0x0000000b    /*  54 PUSH */,
    0x00007f04    /*  55 CONSTI */,
    0x0000001d    /*  56 BNGT */,
    SG_WORD(18),
    0x00000030    /*  58 FRAME */,
    SG_WORD(7),
    0x00000045    /*  60 LREF_PUSH */,
    0x00000145    /*  61 LREF_PUSH */,
    0x00000245    /*  62 LREF_PUSH */,
    0x00000345    /*  63 LREF_PUSH */,
    0x0000044a    /*  64 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-ref#core.base> */,
    0x0000000b    /*  66 PUSH */,
    0x00000030    /*  67 FRAME */,
    SG_WORD(5),
    0x00010049    /*  69 CONSTI_PUSH */,
    0x00000345    /*  70 LREF_PUSH */,
    0x0000024a    /*  71 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier expt#core.base> */,
    0x00000010    /*  73 SUB */,
    0x0000002f    /*  74 RET */,
    0x00000045    /*  75 LREF_PUSH */,
    0x00000145    /*  76 LREF_PUSH */,
    0x00000245    /*  77 LREF_PUSH */,
    0x00000345    /*  78 LREF_PUSH */,
    0x0000044b    /*  79 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-ref#core.base> */,
    0x0000002f    /*  81 RET */,
    0x00000048    /*  82 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* bytevector-uint-ref */,
    0x00000030    /*  84 FRAME */,
    SG_WORD(6),
    0x00000048    /*  86 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected endianness, but got ~s, as argument 3 */,
    0x00000245    /*  88 LREF_PUSH */,
    0x0000024a    /*  89 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  91 PUSH */,
    0x00000045    /*  92 LREF_PUSH */,
    0x00000145    /*  93 LREF_PUSH */,
    0x00000245    /*  94 LREF_PUSH */,
    0x00000305    /*  95 LREF */,
    0x00000438    /*  96 LIST */,
    0x0000000b    /*  97 PUSH */,
    0x0000034b    /*  98 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /* 100 RET */,
    /* bytevector-uint-set! */0x00000245    /*   0 LREF_PUSH */,
    0x00000004    /*   1 CONSTI */,
    0x0000001a    /*   2 BNNUME */,
    SG_WORD(28),
    0x00000145    /*   4 LREF_PUSH */,
    0x00000405    /*   5 LREF */,
    0x0000000e    /*   6 ADD */,
    0x0000000b    /*   7 PUSH */,
    0x00000145    /*   8 LREF_PUSH */,
    0x00000645    /*   9 LREF_PUSH */,
    0x00000505    /*  10 LREF */,
    0x0000001e    /*  11 BNGE */,
    SG_WORD(3),
    0x00000018    /*  13 JUMP */,
    SG_WORD(14),
    0x00000030    /*  15 FRAME */,
    SG_WORD(6),
    0x00000045    /*  17 LREF_PUSH */,
    0x00000645    /*  18 LREF_PUSH */,
    0x00000049    /*  19 CONSTI_PUSH */,
    0x0000034a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-u8-set!#core.base> */,
    0x00000605    /*  22 LREF */,
    0x0000010f    /*  23 ADDI */,
    0x0000000b    /*  24 PUSH */,
    0x00600119    /*  25 SHIFTJ */,
    0x00000018    /*  26 JUMP */,
    SG_WORD(-18),
    0x00000232    /*  28 LEAVE */,
    0x00000018    /*  29 JUMP */,
    SG_WORD(133),
    0x00000030    /*  31 FRAME */,
    SG_WORD(12),
    0x00000049    /*  33 CONSTI_PUSH */,
    0x00000245    /*  34 LREF_PUSH */,
    0x00000030    /*  35 FRAME */,
    SG_WORD(5),
    0x00010049    /*  37 CONSTI_PUSH */,
    0x00000445    /*  38 LREF_PUSH */,
    0x0000024a    /*  39 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier expt#core.base> */,
    0x0000000b    /*  41 PUSH */,
    0x0000034a    /*  42 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier <#core.base> */,
    0x00000017    /*  44 TEST */,
    SG_WORD(97),
    0x00000345    /*  46 LREF_PUSH */,
    0x00000003    /*  47 CONST */,
    SG_WORD(SG_UNDEF) /* big */,
    0x0000001f    /*  49 BNEQ */,
    SG_WORD(43),
    0x00000145    /*  51 LREF_PUSH */,
    0x00000405    /*  52 LREF */,
    0x0000000e    /*  53 ADD */,
    -0x000000f1   /*  54 ADDI */,
    0x0000000b    /*  55 PUSH */,
    0x00000545    /*  56 LREF_PUSH */,
    0x00000245    /*  57 LREF_PUSH */,
    0x00000645    /*  58 LREF_PUSH */,
    0x00000105    /*  59 LREF */,
    0x0000001b    /*  60 BNLT */,
    SG_WORD(3),
    0x00000018    /*  62 JUMP */,
    SG_WORD(27),
    0x00000030    /*  64 FRAME */,
    SG_WORD(12),
    0x00000045    /*  66 LREF_PUSH */,
    0x00000645    /*  67 LREF_PUSH */,
    0x00000030    /*  68 FRAME */,
    SG_WORD(5),
    0x00000745    /*  70 LREF_PUSH */,
    0x0000ff49    /*  71 CONSTI_PUSH */,
    0x0000024a    /*  72 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bitwise-and#core.base> */,
    0x0000000b    /*  74 PUSH */,
    0x0000034a    /*  75 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-u8-set!#core.base> */,
    0x00000605    /*  77 LREF */,
    -0x000000f1   /*  78 ADDI */,
    0x0000000b    /*  79 PUSH */,
    0x00000030    /*  80 FRAME */,
    SG_WORD(5),
    0x00000745    /*  82 LREF_PUSH */,
    -0x000007b7   /*  83 CONSTI_PUSH */,
    0x0000024a    /*  84 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bitwise-arithmetic-shift#core.base> */,
    0x0000000b    /*  86 PUSH */,
    0x00600219    /*  87 SHIFTJ */,
    0x00000018    /*  88 JUMP */,
    SG_WORD(-31),
    0x00000332    /*  90 LEAVE */,
    0x00000018    /*  91 JUMP */,
    SG_WORD(48),
    0x00000345    /*  93 LREF_PUSH */,
    0x00000003    /*  94 CONST */,
    SG_WORD(SG_UNDEF) /* little */,
    0x0000001f    /*  96 BNEQ */,
    SG_WORD(42),
    0x00000145    /*  98 LREF_PUSH */,
    0x00000405    /*  99 LREF */,
    0x0000000e    /* 100 ADD */,
    0x0000000b    /* 101 PUSH */,
    0x00000145    /* 102 LREF_PUSH */,
    0x00000245    /* 103 LREF_PUSH */,
    0x00000645    /* 104 LREF_PUSH */,
    0x00000505    /* 105 LREF */,
    0x0000001e    /* 106 BNGE */,
    SG_WORD(3),
    0x00000018    /* 108 JUMP */,
    SG_WORD(27),
    0x00000030    /* 110 FRAME */,
    SG_WORD(12),
    0x00000045    /* 112 LREF_PUSH */,
    0x00000645    /* 113 LREF_PUSH */,
    0x00000030    /* 114 FRAME */,
    SG_WORD(5),
    0x00000745    /* 116 LREF_PUSH */,
    0x0000ff49    /* 117 CONSTI_PUSH */,
    0x0000024a    /* 118 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bitwise-and#core.base> */,
    0x0000000b    /* 120 PUSH */,
    0x0000034a    /* 121 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-u8-set!#core.base> */,
    0x00000605    /* 123 LREF */,
    0x0000010f    /* 124 ADDI */,
    0x0000000b    /* 125 PUSH */,
    0x00000030    /* 126 FRAME */,
    SG_WORD(5),
    0x00000745    /* 128 LREF_PUSH */,
    -0x000007b7   /* 129 CONSTI_PUSH */,
    0x0000024a    /* 130 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bitwise-arithmetic-shift#core.base> */,
    0x0000000b    /* 132 PUSH */,
    0x00600219    /* 133 SHIFTJ */,
    0x00000018    /* 134 JUMP */,
    SG_WORD(-31),
    0x00000332    /* 136 LEAVE */,
    0x00000018    /* 137 JUMP */,
    SG_WORD(2),
    0x00000002    /* 139 UNDEF */,
    0x00000018    /* 140 JUMP */,
    SG_WORD(22),
    0x00000030    /* 142 FRAME */,
    SG_WORD(20),
    0x00000048    /* 144 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* bytevector-uint-set! */,
    0x00000030    /* 146 FRAME */,
    SG_WORD(6),
    0x00000048    /* 148 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* value out of range, ~s as argument 3 */,
    0x00000245    /* 150 LREF_PUSH */,
    0x0000024a    /* 151 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /* 153 PUSH */,
    0x00000045    /* 154 LREF_PUSH */,
    0x00000145    /* 155 LREF_PUSH */,
    0x00000245    /* 156 LREF_PUSH */,
    0x00000345    /* 157 LREF_PUSH */,
    0x00000405    /* 158 LREF */,
    0x00000538    /* 159 LIST */,
    0x0000000b    /* 160 PUSH */,
    0x0000034a    /* 161 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000061    /* 163 CONST_RET */,
    SG_WORD(SG_UNDEF) /* #<unspecified> */,
    /* bytevector-sint-set! */0x00000030    /*   0 FRAME */,
    SG_WORD(9),
    0x00000249    /*   2 CONSTI_PUSH */,
    0x00000445    /*   3 LREF_PUSH */,
    0x00000804    /*   4 CONSTI */,
    0x00000012    /*   5 MUL */,
    -0x000000f1   /*   6 ADDI */,
    0x0000000b    /*   7 PUSH */,
    0x0000024a    /*   8 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier expt#core.base> */,
    0x0000000b    /*  10 PUSH */,
    0x00000505    /*  11 LREF */,
    0x0000010f    /*  12 ADDI */,
    0x00000016    /*  13 NEG */,
    0x0000000b    /*  14 PUSH */,
    0x00000030    /*  15 FRAME */,
    SG_WORD(6),
    0x00000645    /*  17 LREF_PUSH */,
    0x00000245    /*  18 LREF_PUSH */,
    0x00000545    /*  19 LREF_PUSH */,
    0x0000034a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier <#core.base> */,
    0x00000017    /*  22 TEST */,
    SG_WORD(35),
    0x00000245    /*  24 LREF_PUSH */,
    0x00000004    /*  25 CONSTI */,
    0x0000001e    /*  26 BNGE */,
    SG_WORD(12),
    0x00000030    /*  28 FRAME */,
    SG_WORD(8),
    0x00000045    /*  30 LREF_PUSH */,
    0x00000145    /*  31 LREF_PUSH */,
    0x00000245    /*  32 LREF_PUSH */,
    0x00000345    /*  33 LREF_PUSH */,
    0x00000445    /*  34 LREF_PUSH */,
    0x0000054a    /*  35 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-set!#core.base> */,
    0x00000018    /*  37 JUMP */,
    SG_WORD(18),
    0x00000030    /*  39 FRAME */,
    SG_WORD(16),
    0x00000045    /*  41 LREF_PUSH */,
    0x00000145    /*  42 LREF_PUSH */,
    0x00000245    /*  43 LREF_PUSH */,
    0x00000030    /*  44 FRAME */,
    SG_WORD(5),
    0x00010049    /*  46 CONSTI_PUSH */,
    0x00000445    /*  47 LREF_PUSH */,
    0x0000024a    /*  48 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier expt#core.base> */,
    0x0000000e    /*  50 ADD */,
    0x0000000b    /*  51 PUSH */,
    0x00000345    /*  52 LREF_PUSH */,
    0x00000445    /*  53 LREF_PUSH */,
    0x0000054a    /*  54 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-set!#core.base> */,
    0x00000018    /*  56 JUMP */,
    SG_WORD(22),
    0x00000030    /*  58 FRAME */,
    SG_WORD(20),
    0x00000048    /*  60 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* bytevector-sint-set! */,
    0x00000030    /*  62 FRAME */,
    SG_WORD(6),
    0x00000048    /*  64 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* value out of range, ~s as argument 3 */,
    0x00000245    /*  66 LREF_PUSH */,
    0x0000024a    /*  67 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  69 PUSH */,
    0x00000045    /*  70 LREF_PUSH */,
    0x00000145    /*  71 LREF_PUSH */,
    0x00000245    /*  72 LREF_PUSH */,
    0x00000345    /*  73 LREF_PUSH */,
    0x00000405    /*  74 LREF */,
    0x00000538    /*  75 LIST */,
    0x0000000b    /*  76 PUSH */,
    0x0000034a    /*  77 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000232    /*  79 LEAVE */,
    0x00000061    /*  80 CONST_RET */,
    SG_WORD(SG_UNDEF) /* #<unspecified> */,
    /* bytevector->uint-list */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-length#core.base> */,
    0x0000000b    /*   5 PUSH */,
    0x00000205    /*   6 LREF */,
    0x00000010    /*   7 SUB */,
    0x0000000b    /*   8 PUSH */,
    0x00000048    /*   9 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000345    /*  11 LREF_PUSH */,
    -0x000000fc   /*  12 CONSTI */,
    0x0000001d    /*  13 BNGT */,
    SG_WORD(20),
    0x00000345    /*  15 LREF_PUSH */,
    0x00000205    /*  16 LREF */,
    0x00000010    /*  17 SUB */,
    0x0000000b    /*  18 PUSH */,
    0x00000030    /*  19 FRAME */,
    SG_WORD(7),
    0x00000045    /*  21 LREF_PUSH */,
    0x00000345    /*  22 LREF_PUSH */,
    0x00000145    /*  23 LREF_PUSH */,
    0x00000245    /*  24 LREF_PUSH */,
    0x0000044a    /*  25 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-ref#core.base> */,
    0x0000000b    /*  27 PUSH */,
    0x00000405    /*  28 LREF */,
    0x00000054    /*  29 CONS_PUSH */,
    0x00300219    /*  30 SHIFTJ */,
    0x00000018    /*  31 JUMP */,
    SG_WORD(-21),
    0x0000002f    /*  33 RET */,
    0x00000345    /*  34 LREF_PUSH */,
    0x00000205    /*  35 LREF */,
    0x00000016    /*  36 NEG */,
    0x0000001a    /*  37 BNNUME */,
    SG_WORD(3),
    0x00000405    /*  39 LREF */,
    0x0000002f    /*  40 RET */,
    0x00000048    /*  41 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* bytevector->uint-list */,
    0x00000030    /*  43 FRAME */,
    SG_WORD(6),
    0x00000048    /*  45 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected appropriate element size as argument 3, but got ~s */,
    0x00000245    /*  47 LREF_PUSH */,
    0x0000024a    /*  48 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  50 PUSH */,
    0x00000045    /*  51 LREF_PUSH */,
    0x00000145    /*  52 LREF_PUSH */,
    0x00000205    /*  53 LREF */,
    0x00000338    /*  54 LIST */,
    0x0000000b    /*  55 PUSH */,
    0x0000034b    /*  56 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  58 RET */,
    /* bytevector->sint-list */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-length#core.base> */,
    0x0000000b    /*   5 PUSH */,
    0x00000205    /*   6 LREF */,
    0x00000010    /*   7 SUB */,
    0x0000000b    /*   8 PUSH */,
    0x00000048    /*   9 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000345    /*  11 LREF_PUSH */,
    -0x000000fc   /*  12 CONSTI */,
    0x0000001d    /*  13 BNGT */,
    SG_WORD(20),
    0x00000345    /*  15 LREF_PUSH */,
    0x00000205    /*  16 LREF */,
    0x00000010    /*  17 SUB */,
    0x0000000b    /*  18 PUSH */,
    0x00000030    /*  19 FRAME */,
    SG_WORD(7),
    0x00000045    /*  21 LREF_PUSH */,
    0x00000345    /*  22 LREF_PUSH */,
    0x00000145    /*  23 LREF_PUSH */,
    0x00000245    /*  24 LREF_PUSH */,
    0x0000044a    /*  25 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-sint-ref#core.base> */,
    0x0000000b    /*  27 PUSH */,
    0x00000405    /*  28 LREF */,
    0x00000054    /*  29 CONS_PUSH */,
    0x00300219    /*  30 SHIFTJ */,
    0x00000018    /*  31 JUMP */,
    SG_WORD(-21),
    0x0000002f    /*  33 RET */,
    0x00000345    /*  34 LREF_PUSH */,
    0x00000205    /*  35 LREF */,
    0x00000016    /*  36 NEG */,
    0x0000001a    /*  37 BNNUME */,
    SG_WORD(3),
    0x00000405    /*  39 LREF */,
    0x0000002f    /*  40 RET */,
    0x00000048    /*  41 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* bytevector->sint-list */,
    0x00000030    /*  43 FRAME */,
    SG_WORD(6),
    0x00000048    /*  45 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected appropriate element size as argument 3, but got ~s */,
    0x00000245    /*  47 LREF_PUSH */,
    0x0000024a    /*  48 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  50 PUSH */,
    0x00000045    /*  51 LREF_PUSH */,
    0x00000145    /*  52 LREF_PUSH */,
    0x00000205    /*  53 LREF */,
    0x00000338    /*  54 LIST */,
    0x0000000b    /*  55 PUSH */,
    0x0000034b    /*  56 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  58 RET */,
    /* uint-list->bytevector */0x00000030    /*   0 FRAME */,
    SG_WORD(11),
    0x00000245    /*   2 LREF_PUSH */,
    0x00000030    /*   3 FRAME */,
    SG_WORD(4),
    0x00000045    /*   5 LREF_PUSH */,
    0x0000014a    /*   6 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x00000012    /*   8 MUL */,
    0x0000000b    /*   9 PUSH */,
    0x0000014a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-bytevector#core.base> */,
    0x0000000b    /*  12 PUSH */,
    0x00000049    /*  13 CONSTI_PUSH */,
    0x00000045    /*  14 LREF_PUSH */,
    0x00000505    /*  15 LREF */,
    0x00000021    /*  16 BNNULL */,
    SG_WORD(3),
    0x00000305    /*  18 LREF */,
    0x0000002f    /*  19 RET */,
    0x00000030    /*  20 FRAME */,
    SG_WORD(8),
    0x00000345    /*  22 LREF_PUSH */,
    0x00000445    /*  23 LREF_PUSH */,
    0x0000055b    /*  24 LREF_CAR_PUSH */,
    0x00000145    /*  25 LREF_PUSH */,
    0x00000245    /*  26 LREF_PUSH */,
    0x0000054a    /*  27 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-set!#core.base> */,
    0x00000445    /*  29 LREF_PUSH */,
    0x00000205    /*  30 LREF */,
    0x0000000e    /*  31 ADD */,
    0x0000000b    /*  32 PUSH */,
    0x0000055c    /*  33 LREF_CDR_PUSH */,
    0x00400219    /*  34 SHIFTJ */,
    0x00000018    /*  35 JUMP */,
    SG_WORD(-21),
    0x0000002f    /*  37 RET */,
    /* sint-list->bytevector */0x00000030    /*   0 FRAME */,
    SG_WORD(11),
    0x00000245    /*   2 LREF_PUSH */,
    0x00000030    /*   3 FRAME */,
    SG_WORD(4),
    0x00000045    /*   5 LREF_PUSH */,
    0x0000014a    /*   6 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x00000012    /*   8 MUL */,
    0x0000000b    /*   9 PUSH */,
    0x0000014a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-bytevector#core.base> */,
    0x0000000b    /*  12 PUSH */,
    0x00000049    /*  13 CONSTI_PUSH */,
    0x00000045    /*  14 LREF_PUSH */,
    0x00000505    /*  15 LREF */,
    0x00000021    /*  16 BNNULL */,
    SG_WORD(3),
    0x00000305    /*  18 LREF */,
    0x0000002f    /*  19 RET */,
    0x00000030    /*  20 FRAME */,
    SG_WORD(8),
    0x00000345    /*  22 LREF_PUSH */,
    0x00000445    /*  23 LREF_PUSH */,
    0x0000055b    /*  24 LREF_CAR_PUSH */,
    0x00000145    /*  25 LREF_PUSH */,
    0x00000245    /*  26 LREF_PUSH */,
    0x0000054a    /*  27 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-sint-set!#core.base> */,
    0x00000445    /*  29 LREF_PUSH */,
    0x00000205    /*  30 LREF */,
    0x0000000e    /*  31 ADD */,
    0x0000000b    /*  32 PUSH */,
    0x0000055c    /*  33 LREF_CDR_PUSH */,
    0x00400219    /*  34 SHIFTJ */,
    0x00000018    /*  35 JUMP */,
    SG_WORD(-21),
    0x0000002f    /*  37 RET */,
    /* loop */0x00000005    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   3 CONST_RET */,
    SG_WORD(SG_NIL) /* () */,
    0x00000055    /*   5 LREF_CAR */,
    0x0000003e    /*   6 PAIRP */,
    0x00000017    /*   7 TEST */,
    SG_WORD(11),
    0x00000005    /*   9 LREF */,
    0x0000004e    /*  10 CAAR */,
    0x0000000b    /*  11 PUSH */,
    0x00000030    /*  12 FRAME */,
    SG_WORD(4),
    0x0000005c    /*  14 LREF_CDR_PUSH */,
    0x00000107    /*  15 FREF */,
    0x0000012c    /*  16 LOCAL_CALL */,
    0x00000037    /*  17 CONS */,
    0x0000002f    /*  18 RET */,
    0x00000048    /*  19 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* for-all */,
    0x00000030    /*  21 FRAME */,
    SG_WORD(6),
    0x00000048    /*  23 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* traversal reached to non-pair element ~s */,
    0x0000005b    /*  25 LREF_CAR_PUSH */,
    0x0000024a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  28 PUSH */,
    0x00000046    /*  29 FREF_PUSH */,
    0x0000034b    /*  30 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  32 RET */,
    /* collect-car */0x00000163    /*   0 RESV_STACK */,
    0x00000145    /*   1 LREF_PUSH */,
    0x00000046    /*   2 FREF_PUSH */,
    0x00000229    /*   3 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[68])) /* #<code-builder loop (1 0 2)> */,
    0x00000131    /*   5 INST_STACK */,
    0x00000045    /*   6 LREF_PUSH */,
    0x00000105    /*   7 LREF */,
    0x0000012e    /*   8 LOCAL_TAIL_CALL */,
    0x0000002f    /*   9 RET */,
    /* for-all */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(79),
    0x00000045    /*   3 LREF_PUSH */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000105    /*   5 LREF */,
    0x00000021    /*   6 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   8 CONST_RET */,
    SG_WORD(SG_TRUE) /* #t */,
    0x00000105    /*  10 LREF */,
    0x0000003e    /*  11 PAIRP */,
    0x00000017    /*  12 TEST */,
    SG_WORD(51),
    0x0000045b    /*  14 LREF_CAR_PUSH */,
    0x0000045c    /*  15 LREF_CDR_PUSH */,
    0x00000605    /*  16 LREF */,
    0x00000021    /*  17 BNNULL */,
    SG_WORD(5),
    0x00000545    /*  19 LREF_PUSH */,
    0x00000305    /*  20 LREF */,
    0x0000012d    /*  21 TAIL_CALL */,
    0x0000002f    /*  22 RET */,
    0x00000605    /*  23 LREF */,
    0x0000003e    /*  24 PAIRP */,
    0x00000017    /*  25 TEST */,
    SG_WORD(14),
    0x00000030    /*  27 FRAME */,
    SG_WORD(4),
    0x00000545    /*  29 LREF_PUSH */,
    0x00000305    /*  30 LREF */,
    0x0000012b    /*  31 CALL */,
    0x00000017    /*  32 TEST */,
    SG_WORD(6),
    0x0000065b    /*  34 LREF_CAR_PUSH */,
    0x0000065c    /*  35 LREF_CDR_PUSH */,
    0x00500219    /*  36 SHIFTJ */,
    0x00000018    /*  37 JUMP */,
    SG_WORD(-22),
    0x0000002f    /*  39 RET */,
    0x00000030    /*  40 FRAME */,
    SG_WORD(4),
    0x00000545    /*  42 LREF_PUSH */,
    0x00000305    /*  43 LREF */,
    0x0000012b    /*  44 CALL */,
    0x00000017    /*  45 TEST */,
    SG_WORD(17),
    0x00000048    /*  47 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* for-all */,
    0x00000030    /*  49 FRAME */,
    SG_WORD(6),
    0x00000048    /*  51 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* traversal reached to non-pair element ~s */,
    0x00000645    /*  53 LREF_PUSH */,
    0x0000024a    /*  54 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  56 PUSH */,
    0x00000345    /*  57 LREF_PUSH */,
    0x00000405    /*  58 LREF */,
    0x00000238    /*  59 LIST */,
    0x0000000b    /*  60 PUSH */,
    0x0000034b    /*  61 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  63 RET */,
    0x00000048    /*  64 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* for-all */,
    0x00000030    /*  66 FRAME */,
    SG_WORD(6),
    0x00000048    /*  68 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected chain of pairs, but got ~a, as argument 2 */,
    0x00000145    /*  70 LREF_PUSH */,
    0x0000024a    /*  71 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  73 PUSH */,
    0x00000045    /*  74 LREF_PUSH */,
    0x00000105    /*  75 LREF */,
    0x00000238    /*  76 LIST */,
    0x0000000b    /*  77 PUSH */,
    0x0000034b    /*  78 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  80 RET */,
    0x00000030    /*  81 FRAME */,
    SG_WORD(6),
    0x00000047    /*  83 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose+#core.base> */,
    0x00000145    /*  85 LREF_PUSH */,
    0x00000205    /*  86 LREF */,
    0x0000032a    /*  87 APPLY */,
    0x0000000b    /*  88 PUSH */,
    0x00000305    /*  89 LREF */,
    0x00000017    /*  90 TEST */,
    SG_WORD(29),
    0x00000045    /*  92 LREF_PUSH */,
    0x00000345    /*  93 LREF_PUSH */,
    0x00000305    /*  94 LREF */,
    0x00000021    /*  95 BNNULL */,
    SG_WORD(2),
    0x0000002f    /*  97 RET */,
    0x0000055b    /*  98 LREF_CAR_PUSH */,
    0x0000055c    /*  99 LREF_CDR_PUSH */,
    0x00000705    /* 100 LREF */,
    0x00000021    /* 101 BNNULL */,
    SG_WORD(5),
    0x00000445    /* 103 LREF_PUSH */,
    0x00000605    /* 104 LREF */,
    0x0010022a    /* 105 APPLY */,
    0x0000002f    /* 106 RET */,
    0x00000030    /* 107 FRAME */,
    SG_WORD(4),
    0x00000445    /* 109 LREF_PUSH */,
    0x00000605    /* 110 LREF */,
    0x0000022a    /* 111 APPLY */,
    0x00000017    /* 112 TEST */,
    SG_WORD(6),
    0x0000075b    /* 114 LREF_CAR_PUSH */,
    0x0000075c    /* 115 LREF_CDR_PUSH */,
    0x00600219    /* 116 SHIFTJ */,
    0x00000018    /* 117 JUMP */,
    SG_WORD(-18),
    0x0000002f    /* 119 RET */,
    0x00000045    /* 120 LREF_PUSH */,
    0x00000145    /* 121 LREF_PUSH */,
    0x00000205    /* 122 LREF */,
    0x00000054    /* 123 CONS_PUSH */,
    0x00000030    /* 124 FRAME */,
    SG_WORD(4),
    0x00000545    /* 126 LREF_PUSH */,
    0x0000014a    /* 127 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x0000000b    /* 129 PUSH */,
    0x00000263    /* 130 RESV_STACK */,
    0x00000009    /* 131 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17181#core.base> */,
    0x00000731    /* 133 INST_STACK */,
    0x00000545    /* 134 LREF_PUSH */,
    0x00000029    /* 135 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[69])) /* #<code-builder collect-car (1 0 1)> */,
    0x00000831    /* 137 INST_STACK */,
    0x00000030    /* 138 FRAME */,
    SG_WORD(4),
    0x00000545    /* 140 LREF_PUSH */,
    0x00000805    /* 141 LREF */,
    0x0000012c    /* 142 LOCAL_CALL */,
    0x0000000b    /* 143 PUSH */,
    0x00000030    /* 144 FRAME */,
    SG_WORD(5),
    0x00000545    /* 146 LREF_PUSH */,
    0x00000009    /* 147 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17181#core.base> */,
    0x0000012c    /* 149 LOCAL_CALL */,
    0x0000000b    /* 150 PUSH */,
    0x00000030    /* 151 FRAME */,
    SG_WORD(4),
    0x00000945    /* 153 LREF_PUSH */,
    0x0000014a    /* 154 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x0000000b    /* 156 PUSH */,
    0x00000605    /* 157 LREF */,
    0x0000001a    /* 158 BNNUME */,
    SG_WORD(3),
    0x00000018    /* 160 JUMP */,
    SG_WORD(10),
    0x00000030    /* 162 FRAME */,
    SG_WORD(8),
    0x00000048    /* 164 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* for-all */,
    0x00000048    /* 166 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected same length chains of pairs */,
    0x00000545    /* 168 LREF_PUSH */,
    0x0000034a    /* 169 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000a05    /* 171 LREF */,
    0x00000021    /* 172 BNNULL */,
    SG_WORD(5),
    0x00000445    /* 174 LREF_PUSH */,
    0x00000905    /* 175 LREF */,
    0x0010022a    /* 176 APPLY */,
    0x0000002f    /* 177 RET */,
    0x00000030    /* 178 FRAME */,
    SG_WORD(4),
    0x00000445    /* 180 LREF_PUSH */,
    0x00000905    /* 181 LREF */,
    0x0000022a    /* 182 APPLY */,
    0x00000017    /* 183 TEST */,
    SG_WORD(17),
    0x00000030    /* 185 FRAME */,
    SG_WORD(4),
    0x00000a45    /* 187 LREF_PUSH */,
    0x00000805    /* 188 LREF */,
    0x0000012c    /* 189 LOCAL_CALL */,
    0x0000000b    /* 190 PUSH */,
    0x00000030    /* 191 FRAME */,
    SG_WORD(5),
    0x00000a45    /* 193 LREF_PUSH */,
    0x00000009    /* 194 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17181#core.base> */,
    0x0000012c    /* 196 LOCAL_CALL */,
    0x0000000b    /* 197 PUSH */,
    0x00900219    /* 198 SHIFTJ */,
    0x00000018    /* 199 JUMP */,
    SG_WORD(-49),
    0x0000002f    /* 201 RET */,
    /* loop */0x00000005    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   3 CONST_RET */,
    SG_WORD(SG_NIL) /* () */,
    0x00000055    /*   5 LREF_CAR */,
    0x0000003e    /*   6 PAIRP */,
    0x00000017    /*   7 TEST */,
    SG_WORD(11),
    0x00000005    /*   9 LREF */,
    0x0000004e    /*  10 CAAR */,
    0x0000000b    /*  11 PUSH */,
    0x00000030    /*  12 FRAME */,
    SG_WORD(4),
    0x0000005c    /*  14 LREF_CDR_PUSH */,
    0x00000107    /*  15 FREF */,
    0x0000012c    /*  16 LOCAL_CALL */,
    0x00000037    /*  17 CONS */,
    0x0000002f    /*  18 RET */,
    0x00000048    /*  19 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* exists */,
    0x00000030    /*  21 FRAME */,
    SG_WORD(6),
    0x00000048    /*  23 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* traversal reached to non-pair element ~s */,
    0x0000005b    /*  25 LREF_CAR_PUSH */,
    0x0000024a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  28 PUSH */,
    0x00000046    /*  29 FREF_PUSH */,
    0x0000034b    /*  30 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  32 RET */,
    /* collect-car */0x00000163    /*   0 RESV_STACK */,
    0x00000145    /*   1 LREF_PUSH */,
    0x00000046    /*   2 FREF_PUSH */,
    0x00000229    /*   3 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[71])) /* #<code-builder loop (1 0 2)> */,
    0x00000131    /*   5 INST_STACK */,
    0x00000045    /*   6 LREF_PUSH */,
    0x00000105    /*   7 LREF */,
    0x0000012e    /*   8 LOCAL_TAIL_CALL */,
    0x0000002f    /*   9 RET */,
    /* exists */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(73),
    0x00000045    /*   3 LREF_PUSH */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000105    /*   5 LREF */,
    0x00000021    /*   6 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   8 CONST_RET */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000105    /*  10 LREF */,
    0x0000003e    /*  11 PAIRP */,
    0x00000017    /*  12 TEST */,
    SG_WORD(45),
    0x0000045b    /*  14 LREF_CAR_PUSH */,
    0x0000045c    /*  15 LREF_CDR_PUSH */,
    0x00000605    /*  16 LREF */,
    0x00000021    /*  17 BNNULL */,
    SG_WORD(5),
    0x00000545    /*  19 LREF_PUSH */,
    0x00000305    /*  20 LREF */,
    0x0000012d    /*  21 TAIL_CALL */,
    0x0000002f    /*  22 RET */,
    0x00000030    /*  23 FRAME */,
    SG_WORD(4),
    0x00000545    /*  25 LREF_PUSH */,
    0x00000305    /*  26 LREF */,
    0x0000012b    /*  27 CALL */,
    0x00000017    /*  28 TEST */,
    SG_WORD(2),
    0x0000002f    /*  30 RET */,
    0x00000605    /*  31 LREF */,
    0x0000003e    /*  32 PAIRP */,
    0x00000017    /*  33 TEST */,
    SG_WORD(7),
    0x0000065b    /*  35 LREF_CAR_PUSH */,
    0x0000065c    /*  36 LREF_CDR_PUSH */,
    0x00500219    /*  37 SHIFTJ */,
    0x00000018    /*  38 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  40 RET */,
    0x00000048    /*  41 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* exists */,
    0x00000030    /*  43 FRAME */,
    SG_WORD(6),
    0x00000048    /*  45 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* traversal reached to non-pair element ~s */,
    0x00000645    /*  47 LREF_PUSH */,
    0x0000024a    /*  48 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  50 PUSH */,
    0x00000345    /*  51 LREF_PUSH */,
    0x00000405    /*  52 LREF */,
    0x00000238    /*  53 LIST */,
    0x0000000b    /*  54 PUSH */,
    0x0000034b    /*  55 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  57 RET */,
    0x00000048    /*  58 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* exists */,
    0x00000030    /*  60 FRAME */,
    SG_WORD(6),
    0x00000048    /*  62 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected chain of pairs, but got ~a, as argument 2 */,
    0x00000145    /*  64 LREF_PUSH */,
    0x0000024a    /*  65 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  67 PUSH */,
    0x00000045    /*  68 LREF_PUSH */,
    0x00000105    /*  69 LREF */,
    0x00000238    /*  70 LIST */,
    0x0000000b    /*  71 PUSH */,
    0x0000034b    /*  72 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  74 RET */,
    0x00000030    /*  75 FRAME */,
    SG_WORD(6),
    0x00000047    /*  77 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose+#core.base> */,
    0x00000145    /*  79 LREF_PUSH */,
    0x00000205    /*  80 LREF */,
    0x0000032a    /*  81 APPLY */,
    0x0000000b    /*  82 PUSH */,
    0x00000305    /*  83 LREF */,
    0x00000017    /*  84 TEST */,
    SG_WORD(30),
    0x00000045    /*  86 LREF_PUSH */,
    0x00000345    /*  87 LREF_PUSH */,
    0x00000305    /*  88 LREF */,
    0x0000003e    /*  89 PAIRP */,
    0x00000017    /*  90 TEST */,
    SG_WORD(23),
    0x0000055b    /*  92 LREF_CAR_PUSH */,
    0x0000055c    /*  93 LREF_CDR_PUSH */,
    0x00000705    /*  94 LREF */,
    0x00000021    /*  95 BNNULL */,
    SG_WORD(5),
    0x00000445    /*  97 LREF_PUSH */,
    0x00000605    /*  98 LREF */,
    0x0010022a    /*  99 APPLY */,
    0x0000002f    /* 100 RET */,
    0x00000030    /* 101 FRAME */,
    SG_WORD(4),
    0x00000445    /* 103 LREF_PUSH */,
    0x00000605    /* 104 LREF */,
    0x0000022a    /* 105 APPLY */,
    0x00000017    /* 106 TEST */,
    SG_WORD(2),
    0x0000002f    /* 108 RET */,
    0x0000075b    /* 109 LREF_CAR_PUSH */,
    0x0000075c    /* 110 LREF_CDR_PUSH */,
    0x00600219    /* 111 SHIFTJ */,
    0x00000018    /* 112 JUMP */,
    SG_WORD(-19),
    0x0000002f    /* 114 RET */,
    0x00000045    /* 115 LREF_PUSH */,
    0x00000145    /* 116 LREF_PUSH */,
    0x00000205    /* 117 LREF */,
    0x00000054    /* 118 CONS_PUSH */,
    0x00000030    /* 119 FRAME */,
    SG_WORD(4),
    0x00000545    /* 121 LREF_PUSH */,
    0x0000014a    /* 122 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x0000000b    /* 124 PUSH */,
    0x00000263    /* 125 RESV_STACK */,
    0x00000009    /* 126 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17179#core.base> */,
    0x00000731    /* 128 INST_STACK */,
    0x00000545    /* 129 LREF_PUSH */,
    0x00000029    /* 130 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[72])) /* #<code-builder collect-car (1 0 1)> */,
    0x00000831    /* 132 INST_STACK */,
    0x00000030    /* 133 FRAME */,
    SG_WORD(4),
    0x00000545    /* 135 LREF_PUSH */,
    0x00000805    /* 136 LREF */,
    0x0000012c    /* 137 LOCAL_CALL */,
    0x0000000b    /* 138 PUSH */,
    0x00000030    /* 139 FRAME */,
    SG_WORD(5),
    0x00000545    /* 141 LREF_PUSH */,
    0x00000009    /* 142 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17179#core.base> */,
    0x0000012c    /* 144 LOCAL_CALL */,
    0x0000000b    /* 145 PUSH */,
    0x00000030    /* 146 FRAME */,
    SG_WORD(4),
    0x00000945    /* 148 LREF_PUSH */,
    0x0000014a    /* 149 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x0000000b    /* 151 PUSH */,
    0x00000605    /* 152 LREF */,
    0x0000001a    /* 153 BNNUME */,
    SG_WORD(3),
    0x00000018    /* 155 JUMP */,
    SG_WORD(10),
    0x00000030    /* 157 FRAME */,
    SG_WORD(8),
    0x00000048    /* 159 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* exists */,
    0x00000048    /* 161 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expected same length chains of pairs */,
    0x00000545    /* 163 LREF_PUSH */,
    0x0000034a    /* 164 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000a05    /* 166 LREF */,
    0x00000021    /* 167 BNNULL */,
    SG_WORD(5),
    0x00000445    /* 169 LREF_PUSH */,
    0x00000905    /* 170 LREF */,
    0x0010022a    /* 171 APPLY */,
    0x0000002f    /* 172 RET */,
    0x00000030    /* 173 FRAME */,
    SG_WORD(4),
    0x00000445    /* 175 LREF_PUSH */,
    0x00000905    /* 176 LREF */,
    0x0000022a    /* 177 APPLY */,
    0x00000017    /* 178 TEST */,
    SG_WORD(2),
    0x0000002f    /* 180 RET */,
    0x00000030    /* 181 FRAME */,
    SG_WORD(4),
    0x00000a45    /* 183 LREF_PUSH */,
    0x00000805    /* 184 LREF */,
    0x0000012c    /* 185 LOCAL_CALL */,
    0x0000000b    /* 186 PUSH */,
    0x00000030    /* 187 FRAME */,
    SG_WORD(5),
    0x00000a45    /* 189 LREF_PUSH */,
    0x00000009    /* 190 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17179#core.base> */,
    0x0000012c    /* 192 LOCAL_CALL */,
    0x0000000b    /* 193 PUSH */,
    0x00900219    /* 194 SHIFTJ */,
    0x00000018    /* 195 JUMP */,
    SG_WORD(-50),
    0x0000002f    /* 197 RET */,
    /* filter */0x00000145    /*   0 LREF_PUSH */,
    0x00000048    /*   1 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000205    /*   3 LREF */,
    0x00000021    /*   4 BNNULL */,
    SG_WORD(5),
    0x00000345    /*   6 LREF_PUSH */,
    0x0000014b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*   9 RET */,
    0x00000030    /*  10 FRAME */,
    SG_WORD(4),
    0x0000025b    /*  12 LREF_CAR_PUSH */,
    0x00000005    /*  13 LREF */,
    0x0000012b    /*  14 CALL */,
    0x00000017    /*  15 TEST */,
    SG_WORD(9),
    0x0000025c    /*  17 LREF_CDR_PUSH */,
    0x0000025b    /*  18 LREF_CAR_PUSH */,
    0x00000305    /*  19 LREF */,
    0x00000054    /*  20 CONS_PUSH */,
    0x00200219    /*  21 SHIFTJ */,
    0x00000018    /*  22 JUMP */,
    SG_WORD(-20),
    0x0000002f    /*  24 RET */,
    0x0000025c    /*  25 LREF_CDR_PUSH */,
    0x00000345    /*  26 LREF_PUSH */,
    0x00200219    /*  27 SHIFTJ */,
    0x00000018    /*  28 JUMP */,
    SG_WORD(-26),
    0x0000002f    /*  30 RET */,
    /* filter! */0x00000145    /*   0 LREF_PUSH */,
    0x00000205    /*   1 LREF */,
    0x00000021    /*   2 BNNULL */,
    SG_WORD(3),
    0x00000205    /*   4 LREF */,
    0x0000002f    /*   5 RET */,
    0x00000030    /*   6 FRAME */,
    SG_WORD(4),
    0x0000025b    /*   8 LREF_CAR_PUSH */,
    0x00000005    /*   9 LREF */,
    0x0000012b    /*  10 CALL */,
    0x00000017    /*  11 TEST */,
    SG_WORD(60),
    0x00000245    /*  13 LREF_PUSH */,
    0x0000025c    /*  14 LREF_CDR_PUSH */,
    0x00000405    /*  15 LREF */,
    0x0000003e    /*  16 PAIRP */,
    0x00000017    /*  17 TEST */,
    SG_WORD(50),
    0x00000030    /*  19 FRAME */,
    SG_WORD(4),
    0x0000045b    /*  21 LREF_CAR_PUSH */,
    0x00000005    /*  22 LREF */,
    0x0000012b    /*  23 CALL */,
    0x00000017    /*  24 TEST */,
    SG_WORD(8),
    0x00000445    /*  26 LREF_PUSH */,
    0x0000045c    /*  27 LREF_CDR_PUSH */,
    0x00300219    /*  28 SHIFTJ */,
    0x00000018    /*  29 JUMP */,
    SG_WORD(-15),
    0x00000018    /*  31 JUMP */,
    SG_WORD(34),
    0x0000045c    /*  33 LREF_CDR_PUSH */,
    0x00000545    /*  34 LREF_PUSH */,
    0x00000605    /*  35 LREF */,
    0x0000003e    /*  36 PAIRP */,
    0x00000017    /*  37 TEST */,
    SG_WORD(24),
    0x00000030    /*  39 FRAME */,
    SG_WORD(4),
    0x0000065b    /*  41 LREF_CAR_PUSH */,
    0x00000005    /*  42 LREF */,
    0x0000012b    /*  43 CALL */,
    0x00000017    /*  44 TEST */,
    SG_WORD(11),
    0x00000345    /*  46 LREF_PUSH */,
    0x00000605    /*  47 LREF */,
    0x0000004d    /*  48 SET_CDR */,
    0x00000645    /*  49 LREF_PUSH */,
    0x0000065c    /*  50 LREF_CDR_PUSH */,
    0x00300219    /*  51 SHIFTJ */,
    0x00000018    /*  52 JUMP */,
    SG_WORD(-38),
    0x00000018    /*  54 JUMP */,
    SG_WORD(5),
    0x0000065c    /*  56 LREF_CDR_PUSH */,
    0x00600119    /*  57 SHIFTJ */,
    0x00000018    /*  58 JUMP */,
    SG_WORD(-24),
    0x00000018    /*  60 JUMP */,
    SG_WORD(4),
    0x00000345    /*  62 LREF_PUSH */,
    0x00000605    /*  63 LREF */,
    0x0000004d    /*  64 SET_CDR */,
    0x00000232    /*  65 LEAVE */,
    0x00000018    /*  66 JUMP */,
    SG_WORD(2),
    0x00000002    /*  68 UNDEF */,
    0x00000232    /*  69 LEAVE */,
    0x00000205    /*  70 LREF */,
    0x0000002f    /*  71 RET */,
    0x0000025c    /*  72 LREF_CDR_PUSH */,
    0x00200119    /*  73 SHIFTJ */,
    0x00000018    /*  74 JUMP */,
    SG_WORD(-74),
    0x0000002f    /*  76 RET */,
    /* partition */0x00000145    /*   0 LREF_PUSH */,
    0x00000048    /*   1 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000048    /*   3 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000205    /*   5 LREF */,
    0x00000021    /*   6 BNNULL */,
    SG_WORD(14),
    0x00000030    /*   8 FRAME */,
    SG_WORD(4),
    0x00000345    /*  10 LREF_PUSH */,
    0x0000014a    /*  11 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000000b    /*  13 PUSH */,
    0x00000030    /*  14 FRAME */,
    SG_WORD(4),
    0x00000445    /*  16 LREF_PUSH */,
    0x0000014a    /*  17 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000023a    /*  19 VALUES */,
    0x0000002f    /*  20 RET */,
    0x00000030    /*  21 FRAME */,
    SG_WORD(4),
    0x0000025b    /*  23 LREF_CAR_PUSH */,
    0x00000005    /*  24 LREF */,
    0x0000012b    /*  25 CALL */,
    0x00000017    /*  26 TEST */,
    SG_WORD(10),
    0x0000025c    /*  28 LREF_CDR_PUSH */,
    0x0000025b    /*  29 LREF_CAR_PUSH */,
    0x00000305    /*  30 LREF */,
    0x00000054    /*  31 CONS_PUSH */,
    0x00000445    /*  32 LREF_PUSH */,
    0x00200319    /*  33 SHIFTJ */,
    0x00000018    /*  34 JUMP */,
    SG_WORD(-30),
    0x0000002f    /*  36 RET */,
    0x0000025c    /*  37 LREF_CDR_PUSH */,
    0x00000345    /*  38 LREF_PUSH */,
    0x0000025b    /*  39 LREF_CAR_PUSH */,
    0x00000405    /*  40 LREF */,
    0x00000054    /*  41 CONS_PUSH */,
    0x00200319    /*  42 SHIFTJ */,
    0x00000018    /*  43 JUMP */,
    SG_WORD(-39),
    0x0000002f    /*  45 RET */,
    /* map */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(47),
    0x00000145    /*   3 LREF_PUSH */,
    0x00000048    /*   4 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000305    /*   6 LREF */,
    0x0000003e    /*   7 PAIRP */,
    0x00000017    /*   8 TEST */,
    SG_WORD(14),
    0x0000035c    /*  10 LREF_CDR_PUSH */,
    0x00000030    /*  11 FRAME */,
    SG_WORD(4),
    0x0000035b    /*  13 LREF_CAR_PUSH */,
    0x00000005    /*  14 LREF */,
    0x0000012b    /*  15 CALL */,
    0x0000000b    /*  16 PUSH */,
    0x00000405    /*  17 LREF */,
    0x00000054    /*  18 CONS_PUSH */,
    0x00300219    /*  19 SHIFTJ */,
    0x00000018    /*  20 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  22 RET */,
    0x00000305    /*  23 LREF */,
    0x00000021    /*  24 BNNULL */,
    SG_WORD(5),
    0x00000445    /*  26 LREF_PUSH */,
    0x0000014b    /*  27 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*  29 RET */,
    0x00000048    /*  30 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* map */,
    0x00000030    /*  32 FRAME */,
    SG_WORD(7),
    0x00000048    /*  34 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* proper list */,
    0x00000145    /*  36 LREF_PUSH */,
    0x00000249    /*  37 CONSTI_PUSH */,
    0x0000034a    /*  38 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  40 PUSH */,
    0x00000045    /*  41 LREF_PUSH */,
    0x00000145    /*  42 LREF_PUSH */,
    0x00000205    /*  43 LREF */,
    0x00000338    /*  44 LIST */,
    0x0000000b    /*  45 PUSH */,
    0x0000034b    /*  46 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  48 RET */,
    0x00000030    /*  49 FRAME */,
    SG_WORD(6),
    0x00000047    /*  51 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose*#core.base> */,
    0x00000145    /*  53 LREF_PUSH */,
    0x00000205    /*  54 LREF */,
    0x0000032a    /*  55 APPLY */,
    0x0000000b    /*  56 PUSH */,
    0x00000048    /*  57 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000305    /*  59 LREF */,
    0x0000003e    /*  60 PAIRP */,
    0x00000017    /*  61 TEST */,
    SG_WORD(14),
    0x0000035c    /*  63 LREF_CDR_PUSH */,
    0x00000030    /*  64 FRAME */,
    SG_WORD(4),
    0x00000045    /*  66 LREF_PUSH */,
    0x00000355    /*  67 LREF_CAR */,
    0x0000022a    /*  68 APPLY */,
    0x0000000b    /*  69 PUSH */,
    0x00000405    /*  70 LREF */,
    0x00000054    /*  71 CONS_PUSH */,
    0x00300219    /*  72 SHIFTJ */,
    0x00000018    /*  73 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  75 RET */,
    0x00000305    /*  76 LREF */,
    0x00000021    /*  77 BNNULL */,
    SG_WORD(5),
    0x00000445    /*  79 LREF_PUSH */,
    0x0000014b    /*  80 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*  82 RET */,
    0x00000048    /*  83 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* map */,
    0x00000030    /*  85 FRAME */,
    SG_WORD(7),
    0x00000048    /*  87 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* proper list */,
    0x00000145    /*  89 LREF_PUSH */,
    0x00000249    /*  90 CONSTI_PUSH */,
    0x0000034a    /*  91 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  93 PUSH */,
    0x00000045    /*  94 LREF_PUSH */,
    0x00000145    /*  95 LREF_PUSH */,
    0x00000205    /*  96 LREF */,
    0x00000338    /*  97 LIST */,
    0x0000000b    /*  98 PUSH */,
    0x0000034b    /*  99 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /* 101 RET */,
    /* for-each */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(40),
    0x00000145    /*   3 LREF_PUSH */,
    0x00000305    /*   4 LREF */,
    0x0000003e    /*   5 PAIRP */,
    0x00000017    /*   6 TEST */,
    SG_WORD(11),
    0x00000030    /*   8 FRAME */,
    SG_WORD(4),
    0x0000035b    /*  10 LREF_CAR_PUSH */,
    0x00000005    /*  11 LREF */,
    0x0000012b    /*  12 CALL */,
    0x0000035c    /*  13 LREF_CDR_PUSH */,
    0x00300119    /*  14 SHIFTJ */,
    0x00000018    /*  15 JUMP */,
    SG_WORD(-12),
    0x0000002f    /*  17 RET */,
    0x00000305    /*  18 LREF */,
    0x00000021    /*  19 BNNULL */,
    SG_WORD(3),
    0x00000061    /*  21 CONST_RET */,
    SG_WORD(SG_UNDEF) /* #<unspecified> */,
    0x00000048    /*  23 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* for-each */,
    0x00000030    /*  25 FRAME */,
    SG_WORD(7),
    0x00000048    /*  27 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* proper list */,
    0x00000145    /*  29 LREF_PUSH */,
    0x00000249    /*  30 CONSTI_PUSH */,
    0x0000034a    /*  31 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  33 PUSH */,
    0x00000045    /*  34 LREF_PUSH */,
    0x00000145    /*  35 LREF_PUSH */,
    0x00000205    /*  36 LREF */,
    0x00000338    /*  37 LIST */,
    0x0000000b    /*  38 PUSH */,
    0x0000034b    /*  39 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  41 RET */,
    0x00000030    /*  42 FRAME */,
    SG_WORD(6),
    0x00000047    /*  44 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose*#core.base> */,
    0x00000145    /*  46 LREF_PUSH */,
    0x00000205    /*  47 LREF */,
    0x0000032a    /*  48 APPLY */,
    0x0000000b    /*  49 PUSH */,
    0x00000305    /*  50 LREF */,
    0x0000003e    /*  51 PAIRP */,
    0x00000017    /*  52 TEST */,
    SG_WORD(11),
    0x00000030    /*  54 FRAME */,
    SG_WORD(4),
    0x00000045    /*  56 LREF_PUSH */,
    0x00000355    /*  57 LREF_CAR */,
    0x0000022a    /*  58 APPLY */,
    0x0000035c    /*  59 LREF_CDR_PUSH */,
    0x00300119    /*  60 SHIFTJ */,
    0x00000018    /*  61 JUMP */,
    SG_WORD(-12),
    0x0000002f    /*  63 RET */,
    0x00000305    /*  64 LREF */,
    0x00000021    /*  65 BNNULL */,
    SG_WORD(3),
    0x00000061    /*  67 CONST_RET */,
    SG_WORD(SG_UNDEF) /* #<unspecified> */,
    0x00000048    /*  69 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* for-each */,
    0x00000030    /*  71 FRAME */,
    SG_WORD(7),
    0x00000048    /*  73 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* proper list */,
    0x00000145    /*  75 LREF_PUSH */,
    0x00000249    /*  76 CONSTI_PUSH */,
    0x0000034a    /*  77 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  79 PUSH */,
    0x00000045    /*  80 LREF_PUSH */,
    0x00000145    /*  81 LREF_PUSH */,
    0x00000205    /*  82 LREF */,
    0x00000338    /*  83 LIST */,
    0x0000000b    /*  84 PUSH */,
    0x0000034b    /*  85 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  87 RET */,
    /* loop */0x00000005    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(5),
    0x00000145    /*   3 LREF_PUSH */,
    0x0000014b    /*   4 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*   6 RET */,
    0x00000005    /*   7 LREF */,
    0x0000003e    /*   8 PAIRP */,
    0x00000017    /*   9 TEST */,
    SG_WORD(23),
    0x00000030    /*  11 FRAME */,
    SG_WORD(4),
    0x0000005b    /*  13 LREF_CAR_PUSH */,
    0x00000307    /*  14 FREF */,
    0x0000012b    /*  15 CALL */,
    0x0000000b    /*  16 PUSH */,
    0x00000205    /*  17 LREF */,
    0x00000017    /*  18 TEST */,
    SG_WORD(9),
    0x00000245    /*  20 LREF_PUSH */,
    0x0000005c    /*  21 LREF_CDR_PUSH */,
    0x00000345    /*  22 LREF_PUSH */,
    0x00000105    /*  23 LREF */,
    0x00000054    /*  24 CONS_PUSH */,
    0x00000207    /*  25 FREF */,
    0x0000022e    /*  26 LOCAL_TAIL_CALL */,
    0x0000002f    /*  27 RET */,
    0x0000005c    /*  28 LREF_CDR_PUSH */,
    0x00000145    /*  29 LREF_PUSH */,
    0x00000207    /*  30 FREF */,
    0x0000022e    /*  31 LOCAL_TAIL_CALL */,
    0x0000002f    /*  32 RET */,
    0x00000048    /*  33 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* filter-map */,
    0x00000030    /*  35 FRAME */,
    SG_WORD(7),
    0x00000048    /*  37 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* proper list */,
    0x00000146    /*  39 FREF_PUSH */,
    0x00000249    /*  40 CONSTI_PUSH */,
    0x0000034a    /*  41 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  43 PUSH */,
    0x00000346    /*  44 FREF_PUSH */,
    0x00000146    /*  45 FREF_PUSH */,
    0x00000007    /*  46 FREF */,
    0x00000338    /*  47 LIST */,
    0x0000000b    /*  48 PUSH */,
    0x0000034b    /*  49 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  51 RET */,
    /* loop */0x00000005    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(5),
    0x00000145    /*   3 LREF_PUSH */,
    0x0000014b    /*   4 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*   6 RET */,
    0x00000005    /*   7 LREF */,
    0x0000003e    /*   8 PAIRP */,
    0x00000017    /*   9 TEST */,
    SG_WORD(23),
    0x00000030    /*  11 FRAME */,
    SG_WORD(4),
    0x00000346    /*  13 FREF_PUSH */,
    0x00000055    /*  14 LREF_CAR */,
    0x0000022a    /*  15 APPLY */,
    0x0000000b    /*  16 PUSH */,
    0x00000205    /*  17 LREF */,
    0x00000017    /*  18 TEST */,
    SG_WORD(9),
    0x00000245    /*  20 LREF_PUSH */,
    0x0000005c    /*  21 LREF_CDR_PUSH */,
    0x00000345    /*  22 LREF_PUSH */,
    0x00000105    /*  23 LREF */,
    0x00000054    /*  24 CONS_PUSH */,
    0x00000207    /*  25 FREF */,
    0x0000022e    /*  26 LOCAL_TAIL_CALL */,
    0x0000002f    /*  27 RET */,
    0x0000005c    /*  28 LREF_CDR_PUSH */,
    0x00000145    /*  29 LREF_PUSH */,
    0x00000207    /*  30 FREF */,
    0x0000022e    /*  31 LOCAL_TAIL_CALL */,
    0x0000002f    /*  32 RET */,
    0x00000048    /*  33 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* map */,
    0x00000030    /*  35 FRAME */,
    SG_WORD(7),
    0x00000048    /*  37 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* proper list */,
    0x00000146    /*  39 FREF_PUSH */,
    0x00000249    /*  40 CONSTI_PUSH */,
    0x0000034a    /*  41 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  43 PUSH */,
    0x00000346    /*  44 FREF_PUSH */,
    0x00000146    /*  45 FREF_PUSH */,
    0x00000007    /*  46 FREF */,
    0x00000338    /*  47 LIST */,
    0x0000000b    /*  48 PUSH */,
    0x0000034b    /*  49 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x0000002f    /*  51 RET */,
    /* filter-map */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(4),
    0x00000002    /*   7 UNDEF */,
    0x00000018    /*   8 JUMP */,
    SG_WORD(21),
    0x00000030    /*  10 FRAME */,
    SG_WORD(19),
    0x00000048    /*  12 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* filter-map */,
    0x00000030    /*  14 FRAME */,
    SG_WORD(7),
    0x00000048    /*  16 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  18 LREF_PUSH */,
    0x00000149    /*  19 CONSTI_PUSH */,
    0x0000034a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  22 PUSH */,
    0x00000045    /*  23 LREF_PUSH */,
    0x00000145    /*  24 LREF_PUSH */,
    0x00000205    /*  25 LREF */,
    0x00000338    /*  26 LIST */,
    0x0000000b    /*  27 PUSH */,
    0x0000034a    /*  28 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000205    /*  30 LREF */,
    0x00000021    /*  31 BNNULL */,
    SG_WORD(15),
    0x00000163    /*  33 RESV_STACK */,
    0x00000045    /*  34 LREF_PUSH */,
    0x00000345    /*  35 LREF_PUSH */,
    0x00000145    /*  36 LREF_PUSH */,
    0x00000245    /*  37 LREF_PUSH */,
    0x00000329    /*  38 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[79])) /* #<code-builder loop (2 0 4)> */,
    0x00000331    /*  40 INST_STACK */,
    0x00000145    /*  41 LREF_PUSH */,
    0x00000048    /*  42 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000305    /*  44 LREF */,
    0x0000022e    /*  45 LOCAL_TAIL_CALL */,
    0x0000002f    /*  46 RET */,
    0x00000163    /*  47 RESV_STACK */,
    0x00000045    /*  48 LREF_PUSH */,
    0x00000345    /*  49 LREF_PUSH */,
    0x00000145    /*  50 LREF_PUSH */,
    0x00000245    /*  51 LREF_PUSH */,
    0x00000329    /*  52 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[80])) /* #<code-builder loop (2 0 4)> */,
    0x00000331    /*  54 INST_STACK */,
    0x00000030    /*  55 FRAME */,
    SG_WORD(6),
    0x00000047    /*  57 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose*#core.base> */,
    0x00000145    /*  59 LREF_PUSH */,
    0x00000205    /*  60 LREF */,
    0x0000032a    /*  61 APPLY */,
    0x0000000b    /*  62 PUSH */,
    0x00000048    /*  63 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000305    /*  65 LREF */,
    0x0000022e    /*  66 LOCAL_TAIL_CALL */,
    0x0000002f    /*  67 RET */,
    /* fold-left */0x00000305    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(20),
    0x00000245    /*   3 LREF_PUSH */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000405    /*   5 LREF */,
    0x00000021    /*   6 BNNULL */,
    SG_WORD(3),
    0x00000505    /*   8 LREF */,
    0x0000002f    /*   9 RET */,
    0x0000045c    /*  10 LREF_CDR_PUSH */,
    0x00000030    /*  11 FRAME */,
    SG_WORD(5),
    0x00000545    /*  13 LREF_PUSH */,
    0x0000045b    /*  14 LREF_CAR_PUSH */,
    0x00000005    /*  15 LREF */,
    0x0000022b    /*  16 CALL */,
    0x0000000b    /*  17 PUSH */,
    0x00400219    /*  18 SHIFTJ */,
    0x00000018    /*  19 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  21 RET */,
    0x00000030    /*  22 FRAME */,
    SG_WORD(6),
    0x00000047    /*  24 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose*#core.base> */,
    0x00000245    /*  26 LREF_PUSH */,
    0x00000305    /*  27 LREF */,
    0x0000032a    /*  28 APPLY */,
    0x0000000b    /*  29 PUSH */,
    0x00000145    /*  30 LREF_PUSH */,
    0x00000405    /*  31 LREF */,
    0x00000021    /*  32 BNNULL */,
    SG_WORD(3),
    0x00000505    /*  34 LREF */,
    0x0000002f    /*  35 RET */,
    0x0000045c    /*  36 LREF_CDR_PUSH */,
    0x00000030    /*  37 FRAME */,
    SG_WORD(5),
    0x00000045    /*  39 LREF_PUSH */,
    0x00000545    /*  40 LREF_PUSH */,
    0x00000455    /*  41 LREF_CAR */,
    0x0000032a    /*  42 APPLY */,
    0x0000000b    /*  43 PUSH */,
    0x00400219    /*  44 SHIFTJ */,
    0x00000018    /*  45 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  47 RET */,
    /* fold-right */0x00000305    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(25),
    0x00000030    /*   3 FRAME */,
    SG_WORD(4),
    0x00000245    /*   5 LREF_PUSH */,
    0x0000014a    /*   6 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse#core.base> */,
    0x0000000b    /*   8 PUSH */,
    0x00000145    /*   9 LREF_PUSH */,
    0x00000405    /*  10 LREF */,
    0x00000021    /*  11 BNNULL */,
    SG_WORD(3),
    0x00000505    /*  13 LREF */,
    0x0000002f    /*  14 RET */,
    0x0000045c    /*  15 LREF_CDR_PUSH */,
    0x00000030    /*  16 FRAME */,
    SG_WORD(5),
    0x0000045b    /*  18 LREF_CAR_PUSH */,
    0x00000545    /*  19 LREF_PUSH */,
    0x00000005    /*  20 LREF */,
    0x0000022b    /*  21 CALL */,
    0x0000000b    /*  22 PUSH */,
    0x00400219    /*  23 SHIFTJ */,
    0x00000018    /*  24 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  26 RET */,
    0x00000030    /*  27 FRAME */,
    SG_WORD(11),
    0x00000030    /*  29 FRAME */,
    SG_WORD(6),
    0x00000047    /*  31 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier list-transpose*#core.base> */,
    0x00000245    /*  33 LREF_PUSH */,
    0x00000305    /*  34 LREF */,
    0x0000032a    /*  35 APPLY */,
    0x0000000b    /*  36 PUSH */,
    0x0000014a    /*  37 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000000b    /*  39 PUSH */,
    0x00000145    /*  40 LREF_PUSH */,
    0x00000405    /*  41 LREF */,
    0x00000021    /*  42 BNNULL */,
    SG_WORD(3),
    0x00000505    /*  44 LREF */,
    0x0000002f    /*  45 RET */,
    0x0000045c    /*  46 LREF_CDR_PUSH */,
    0x00000030    /*  47 FRAME */,
    SG_WORD(11),
    0x00000045    /*  49 LREF_PUSH */,
    0x00000030    /*  50 FRAME */,
    SG_WORD(7),
    0x0000045b    /*  52 LREF_CAR_PUSH */,
    0x00000505    /*  53 LREF */,
    0x00000138    /*  54 LIST */,
    0x0000000b    /*  55 PUSH */,
    0x0000024a    /*  56 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier append!#core.base> */,
    0x0000022a    /*  58 APPLY */,
    0x0000000b    /*  59 PUSH */,
    0x00400219    /*  60 SHIFTJ */,
    0x00000018    /*  61 JUMP */,
    SG_WORD(-21),
    0x0000002f    /*  63 RET */,
    /* remp */0x00000145    /*   0 LREF_PUSH */,
    0x00000048    /*   1 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000205    /*   3 LREF */,
    0x00000021    /*   4 BNNULL */,
    SG_WORD(5),
    0x00000345    /*   6 LREF_PUSH */,
    0x0000014b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*   9 RET */,
    0x00000030    /*  10 FRAME */,
    SG_WORD(4),
    0x0000025b    /*  12 LREF_CAR_PUSH */,
    0x00000005    /*  13 LREF */,
    0x0000012b    /*  14 CALL */,
    0x00000017    /*  15 TEST */,
    SG_WORD(7),
    0x0000025c    /*  17 LREF_CDR_PUSH */,
    0x00000345    /*  18 LREF_PUSH */,
    0x00200219    /*  19 SHIFTJ */,
    0x00000018    /*  20 JUMP */,
    SG_WORD(-18),
    0x0000002f    /*  22 RET */,
    0x0000025c    /*  23 LREF_CDR_PUSH */,
    0x0000025b    /*  24 LREF_CAR_PUSH */,
    0x00000305    /*  25 LREF */,
    0x00000054    /*  26 CONS_PUSH */,
    0x00200219    /*  27 SHIFTJ */,
    0x00000018    /*  28 JUMP */,
    SG_WORD(-26),
    0x0000002f    /*  30 RET */,
    /* remove */0x00000145    /*   0 LREF_PUSH */,
    0x00000048    /*   1 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000205    /*   3 LREF */,
    0x00000021    /*   4 BNNULL */,
    SG_WORD(5),
    0x00000345    /*   6 LREF_PUSH */,
    0x0000014b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*   9 RET */,
    0x00000030    /*  10 FRAME */,
    SG_WORD(5),
    0x0000025b    /*  12 LREF_CAR_PUSH */,
    0x00000045    /*  13 LREF_PUSH */,
    0x0000024a    /*  14 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier equal?#core.base> */,
    0x00000017    /*  16 TEST */,
    SG_WORD(7),
    0x0000025c    /*  18 LREF_CDR_PUSH */,
    0x00000345    /*  19 LREF_PUSH */,
    0x00200219    /*  20 SHIFTJ */,
    0x00000018    /*  21 JUMP */,
    SG_WORD(-19),
    0x0000002f    /*  23 RET */,
    0x0000025c    /*  24 LREF_CDR_PUSH */,
    0x0000025b    /*  25 LREF_CAR_PUSH */,
    0x00000305    /*  26 LREF */,
    0x00000054    /*  27 CONS_PUSH */,
    0x00200219    /*  28 SHIFTJ */,
    0x00000018    /*  29 JUMP */,
    SG_WORD(-27),
    0x0000002f    /*  31 RET */,
    /* remv */0x00000145    /*   0 LREF_PUSH */,
    0x00000048    /*   1 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000205    /*   3 LREF */,
    0x00000021    /*   4 BNNULL */,
    SG_WORD(5),
    0x00000345    /*   6 LREF_PUSH */,
    0x0000014b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*   9 RET */,
    0x0000025b    /*  10 LREF_CAR_PUSH */,
    0x00000005    /*  11 LREF */,
    0x00000020    /*  12 BNEQV */,
    SG_WORD(7),
    0x0000025c    /*  14 LREF_CDR_PUSH */,
    0x00000345    /*  15 LREF_PUSH */,
    0x00200219    /*  16 SHIFTJ */,
    0x00000018    /*  17 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  19 RET */,
    0x0000025c    /*  20 LREF_CDR_PUSH */,
    0x0000025b    /*  21 LREF_CAR_PUSH */,
    0x00000305    /*  22 LREF */,
    0x00000054    /*  23 CONS_PUSH */,
    0x00200219    /*  24 SHIFTJ */,
    0x00000018    /*  25 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  27 RET */,
    /* remq */0x00000145    /*   0 LREF_PUSH */,
    0x00000048    /*   1 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000205    /*   3 LREF */,
    0x00000021    /*   4 BNNULL */,
    SG_WORD(5),
    0x00000345    /*   6 LREF_PUSH */,
    0x0000014b    /*   7 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.base> */,
    0x0000002f    /*   9 RET */,
    0x0000025b    /*  10 LREF_CAR_PUSH */,
    0x00000005    /*  11 LREF */,
    0x0000001f    /*  12 BNEQ */,
    SG_WORD(7),
    0x0000025c    /*  14 LREF_CDR_PUSH */,
    0x00000345    /*  15 LREF_PUSH */,
    0x00200219    /*  16 SHIFTJ */,
    0x00000018    /*  17 JUMP */,
    SG_WORD(-15),
    0x0000002f    /*  19 RET */,
    0x0000025c    /*  20 LREF_CDR_PUSH */,
    0x0000025b    /*  21 LREF_CAR_PUSH */,
    0x00000305    /*  22 LREF */,
    0x00000054    /*  23 CONS_PUSH */,
    0x00200219    /*  24 SHIFTJ */,
    0x00000018    /*  25 JUMP */,
    SG_WORD(-23),
    0x0000002f    /*  27 RET */,
    /* memp */0x00000105    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   3 CONST_RET */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000030    /*   5 FRAME */,
    SG_WORD(4),
    0x0000015b    /*   7 LREF_CAR_PUSH */,
    0x00000005    /*   8 LREF */,
    0x0000012b    /*   9 CALL */,
    0x00000017    /*  10 TEST */,
    SG_WORD(3),
    0x00000105    /*  12 LREF */,
    0x0000002f    /*  13 RET */,
    0x00000045    /*  14 LREF_PUSH */,
    0x0000015c    /*  15 LREF_CDR_PUSH */,
    0x0000024b    /*  16 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier memp#core.base> */,
    0x0000002f    /*  18 RET */,
    /* assp */0x00000105    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(3),
    0x00000061    /*   3 CONST_RET */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000030    /*   5 FRAME */,
    SG_WORD(6),
    0x00000105    /*   7 LREF */,
    0x0000004e    /*   8 CAAR */,
    0x0000000b    /*   9 PUSH */,
    0x00000005    /*  10 LREF */,
    0x0000012b    /*  11 CALL */,
    0x00000017    /*  12 TEST */,
    SG_WORD(3),
    0x00000155    /*  14 LREF_CAR */,
    0x0000002f    /*  15 RET */,
    0x00000045    /*  16 LREF_PUSH */,
    0x0000015c    /*  17 LREF_CDR_PUSH */,
    0x0000024b    /*  18 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assp#core.base> */,
    0x0000002f    /*  20 RET */,
    /* recur */0x00000145    /*   0 LREF_PUSH */,
    0x00000104    /*   1 CONSTI */,
    0x0000001a    /*   2 BNNUME */,
    SG_WORD(9),
    0x00000055    /*   4 LREF_CAR */,
    0x00000138    /*   5 LIST */,
    0x0000000b    /*   6 PUSH */,
    0x00000245    /*   7 LREF_PUSH */,
    0x00000245    /*   8 LREF_PUSH */,
    0x00000056    /*   9 LREF_CDR */,
    0x0000033a    /*  10 VALUES */,
    0x0000002f    /*  11 RET */,
    0x00000145    /*  12 LREF_PUSH */,
    0x00000204    /*  13 CONSTI */,
    0x0000001a    /*  14 BNNUME */,
    SG_WORD(28),
    0x0000005b    /*  16 LREF_CAR_PUSH */,
    0x00000005    /*  17 LREF */,
    0x0000004f    /*  18 CADR */,
    0x0000000b    /*  19 PUSH */,
    0x00000030    /*  20 FRAME */,
    SG_WORD(5),
    0x00000345    /*  22 LREF_PUSH */,
    0x00000245    /*  23 LREF_PUSH */,
    0x00000207    /*  24 FREF */,
    0x0000022b    /*  25 CALL */,
    0x00000017    /*  26 TEST */,
    SG_WORD(6),
    0x00000345    /*  28 LREF_PUSH */,
    0x00000205    /*  29 LREF */,
    0x00000238    /*  30 LIST */,
    0x00000018    /*  31 JUMP */,
    SG_WORD(4),
    0x00000245    /*  33 LREF_PUSH */,
    0x00000305    /*  34 LREF */,
    0x00000238    /*  35 LIST */,
    0x0000000b    /*  36 PUSH */,
    0x00000445    /*  37 LREF_PUSH */,
    0x0000045c    /*  38 LREF_CDR_PUSH */,
    0x00000005    /*  39 LREF */,
    0x00000051    /*  40 CDDR */,
    0x0000033a    /*  41 VALUES */,
    0x0000002f    /*  42 RET */,
    0x00000030    /*  43 FRAME */,
    SG_WORD(5),
    0x00000145    /*  45 LREF_PUSH */,
    0x00000249    /*  46 CONSTI_PUSH */,
    0x0000024a    /*  47 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier div#core.base> */,
    0x0000000b    /*  49 PUSH */,
    0x00000030    /*  50 FRAME */,
    SG_WORD(5),
    0x00000045    /*  52 LREF_PUSH */,
    0x00000245    /*  53 LREF_PUSH */,
    0x00000107    /*  54 FREF */,
    0x0000022c    /*  55 LOCAL_CALL */,
    0x00000328    /*  56 RECEIVE */,
    0x00000030    /*  57 FRAME */,
    SG_WORD(8),
    0x00000545    /*  59 LREF_PUSH */,
    0x00000145    /*  60 LREF_PUSH */,
    0x00000205    /*  61 LREF */,
    0x00000010    /*  62 SUB */,
    0x0000000b    /*  63 PUSH */,
    0x00000107    /*  64 FREF */,
    0x0000022c    /*  65 LOCAL_CALL */,
    0x00000328    /*  66 RECEIVE */,
    0x00000246    /*  67 FREF_PUSH */,
    0x00000145    /*  68 LREF_PUSH */,
    0x00000804    /*  69 CONSTI */,
    0x00000027    /*  70 NUM_GE */,
    0x0000000b    /*  71 PUSH */,
    0x00000046    /*  72 FREF_PUSH */,
    0x00000345    /*  73 LREF_PUSH */,
    0x00000645    /*  74 LREF_PUSH */,
    0x00000a05    /*  75 LREF */,
    0x00000017    /*  76 TEST */,
    SG_WORD(55),
    0x00000030    /*  78 FRAME */,
    SG_WORD(5),
    0x0000065b    /*  80 LREF_CAR_PUSH */,
    0x0000045b    /*  81 LREF_CAR_PUSH */,
    0x00000207    /*  82 FREF */,
    0x0000022b    /*  83 CALL */,
    0x00000017    /*  84 TEST */,
    SG_WORD(39),
    0x00000030    /*  86 FRAME */,
    SG_WORD(5),
    0x0000075b    /*  88 LREF_CAR_PUSH */,
    0x0000035b    /*  89 LREF_CAR_PUSH */,
    0x00000207    /*  90 FREF */,
    0x0000022b    /*  91 CALL */,
    0x00000017    /*  92 TEST */,
    SG_WORD(9),
    0x00000745    /*  94 LREF_PUSH */,
    0x00000305    /*  95 LREF */,
    0x0000004d    /*  96 SET_CDR */,
    0x00000645    /*  97 LREF_PUSH */,
    0x00000445    /*  98 LREF_PUSH */,
    0x00000805    /*  99 LREF */,
    0x0000033a    /* 100 VALUES */,
    0x0000002f    /* 101 RET */,
    0x00000030    /* 102 FRAME */,
    SG_WORD(9),
    0x00000945    /* 104 LREF_PUSH */,
    0x00000b45    /* 105 LREF_PUSH */,
    0x00000c45    /* 106 LREF_PUSH */,
    0x00000d45    /* 107 LREF_PUSH */,
    0x00000b45    /* 108 LREF_PUSH */,
    0x00000009    /* 109 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17178#core.base> */,
    0x0000052c    /* 111 LOCAL_CALL */,
    0x0000000b    /* 112 PUSH */,
    0x00000456    /* 113 LREF_CDR */,
    0x00000021    /* 114 BNNULL */,
    SG_WORD(4),
    0x00000405    /* 116 LREF */,
    0x00000018    /* 117 JUMP */,
    SG_WORD(2),
    0x00000705    /* 119 LREF */,
    0x0000000b    /* 120 PUSH */,
    0x00000805    /* 121 LREF */,
    0x0000033a    /* 122 VALUES */,
    0x0000002f    /* 123 RET */,
    0x00000445    /* 124 LREF_PUSH */,
    0x00000605    /* 125 LREF */,
    0x0000004d    /* 126 SET_CDR */,
    0x00000345    /* 127 LREF_PUSH */,
    0x00000745    /* 128 LREF_PUSH */,
    0x00000805    /* 129 LREF */,
    0x0000033a    /* 130 VALUES */,
    0x0000002f    /* 131 RET */,
    0x00000030    /* 132 FRAME */,
    SG_WORD(9),
    0x00000945    /* 134 LREF_PUSH */,
    0x00000b45    /* 135 LREF_PUSH */,
    0x00000c45    /* 136 LREF_PUSH */,
    0x00000d45    /* 137 LREF_PUSH */,
    0x00000b45    /* 138 LREF_PUSH */,
    0x00000009    /* 139 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17178#core.base> */,
    0x0000052c    /* 141 LOCAL_CALL */,
    0x0000000b    /* 142 PUSH */,
    0x00000456    /* 143 LREF_CDR */,
    0x00000021    /* 144 BNNULL */,
    SG_WORD(4),
    0x00000405    /* 146 LREF */,
    0x00000018    /* 147 JUMP */,
    SG_WORD(2),
    0x00000705    /* 149 LREF */,
    0x0000000b    /* 150 PUSH */,
    0x00000805    /* 151 LREF */,
    0x0000033a    /* 152 VALUES */,
    0x0000002f    /* 153 RET */,
    /* list-sort */0x00000163    /*   0 RESV_STACK */,
    0x00000009    /*   1 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17178#core.base> */,
    0x00000231    /*   3 INST_STACK */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(4),
    0x00000045    /*   6 LREF_PUSH */,
    0x0000014a    /*   7 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier procedure?#core.base> */,
    0x00000017    /*   9 TEST */,
    SG_WORD(4),
    0x00000002    /*  11 UNDEF */,
    0x00000018    /*  12 JUMP */,
    SG_WORD(16),
    0x00000030    /*  14 FRAME */,
    SG_WORD(14),
    0x00000048    /*  16 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* list-sort */,
    0x00000030    /*  18 FRAME */,
    SG_WORD(7),
    0x00000048    /*  20 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* procedure */,
    0x00000045    /*  22 LREF_PUSH */,
    0x00000149    /*  23 CONSTI_PUSH */,
    0x0000034a    /*  24 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  26 PUSH */,
    0x0000024a    /*  27 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000105    /*  29 LREF */,
    0x00000021    /*  30 BNNULL */,
    SG_WORD(3),
    0x00000105    /*  32 LREF */,
    0x0000002f    /*  33 RET */,
    0x00000145    /*  34 LREF_PUSH */,
    0x00000149    /*  35 CONSTI_PUSH */,
    0x00000345    /*  36 LREF_PUSH */,
    0x00000556    /*  37 LREF_CDR */,
    0x00000021    /*  38 BNNULL */,
    SG_WORD(7),
    0x00000445    /*  40 LREF_PUSH */,
    0x00000003    /*  41 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x0000023a    /*  43 VALUES */,
    0x00000018    /*  44 JUMP */,
    SG_WORD(23),
    0x00000030    /*  46 FRAME */,
    SG_WORD(7),
    0x0000055b    /*  48 LREF_CAR_PUSH */,
    0x00000505    /*  49 LREF */,
    0x0000004f    /*  50 CADR */,
    0x0000000b    /*  51 PUSH */,
    0x00000005    /*  52 LREF */,
    0x0000022b    /*  53 CALL */,
    0x00000017    /*  54 TEST */,
    SG_WORD(10),
    0x00000405    /*  56 LREF */,
    0x0000010f    /*  57 ADDI */,
    0x0000000b    /*  58 PUSH */,
    0x0000055c    /*  59 LREF_CDR_PUSH */,
    0x00400219    /*  60 SHIFTJ */,
    0x00000018    /*  61 JUMP */,
    SG_WORD(-25),
    0x00000018    /*  63 JUMP */,
    SG_WORD(4),
    0x00000445    /*  65 LREF_PUSH */,
    0x00000556    /*  66 LREF_CDR */,
    0x0000023a    /*  67 VALUES */,
    0x00000332    /*  68 LEAVE */,
    0x00000228    /*  69 RECEIVE */,
    0x00000405    /*  70 LREF */,
    0x00000021    /*  71 BNNULL */,
    SG_WORD(3),
    0x00000105    /*  73 LREF */,
    0x0000002f    /*  74 RET */,
    0x00000048    /*  75 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000003    /*  77 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x00000054    /*  79 CONS_PUSH */,
    0x00000445    /*  80 LREF_PUSH */,
    0x00000030    /*  81 FRAME */,
    SG_WORD(4),
    0x00000445    /*  83 LREF_PUSH */,
    0x0000014a    /*  84 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x0000000b    /*  86 PUSH */,
    0x00000163    /*  87 RESV_STACK */,
    0x00000045    /*  88 LREF_PUSH */,
    0x00000845    /*  89 LREF_PUSH */,
    0x00000545    /*  90 LREF_PUSH */,
    0x00000229    /*  91 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[90])) /* #<code-builder recur (2 0 3)> */,
    0x00000831    /*  93 INST_STACK */,
    0x00000030    /*  94 FRAME */,
    SG_WORD(5),
    0x00000645    /*  96 LREF_PUSH */,
    0x00000745    /*  97 LREF_PUSH */,
    0x00000805    /*  98 LREF */,
    0x0000022c    /*  99 LOCAL_CALL */,
    0x00000328    /* 100 RECEIVE */,
    0x00000905    /* 101 LREF */,
    0x00000632    /* 102 LEAVE */,
    0x0000000b    /* 103 PUSH */,
    0x00000045    /* 104 LREF_PUSH */,
    0x00000545    /* 105 LREF_PUSH */,
    0x00000030    /* 106 FRAME */,
    SG_WORD(5),
    0x00000145    /* 108 LREF_PUSH */,
    0x00000345    /* 109 LREF_PUSH */,
    0x0000024a    /* 110 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier list-head#core.base> */,
    0x0000000b    /* 112 PUSH */,
    0x00000645    /* 113 LREF_PUSH */,
    0x00000545    /* 114 LREF_PUSH */,
    0x00000009    /* 115 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17178#core.base> */,
    0x0000052e    /* 117 LOCAL_TAIL_CALL */,
    0x0000002f    /* 118 RET */,
    /* vector-sort */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(4),
    0x00000004    /*   3 CONSTI */,
    0x00000018    /*   4 JUMP */,
    SG_WORD(2),
    0x00000255    /*   6 LREF_CAR */,
    0x0000000b    /*   7 PUSH */,
    0x00000205    /*   8 LREF */,
    0x00000021    /*   9 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  11 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x00000018    /*  13 JUMP */,
    SG_WORD(2),
    0x00000256    /*  15 LREF_CDR */,
    0x0000000b    /*  16 PUSH */,
    0x00000405    /*  17 LREF */,
    0x00000021    /*  18 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  20 CONST */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000018    /*  22 JUMP */,
    SG_WORD(2),
    0x00000455    /*  24 LREF_CAR */,
    0x0000000b    /*  25 PUSH */,
    0x00000405    /*  26 LREF */,
    0x00000021    /*  27 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  29 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x00000018    /*  31 JUMP */,
    SG_WORD(2),
    0x00000456    /*  33 LREF_CDR */,
    0x0000000b    /*  34 PUSH */,
    0x00000605    /*  35 LREF */,
    0x00000021    /*  36 BNNULL */,
    SG_WORD(4),
    0x00000002    /*  38 UNDEF */,
    0x00000018    /*  39 JUMP */,
    SG_WORD(11),
    0x00000030    /*  41 FRAME */,
    SG_WORD(9),
    0x00000048    /*  43 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* lambda */,
    0x00000048    /*  45 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* too many argument for */,
    0x00000048    /*  47 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* ((define len (vector-length vect)) (define end (or maybe-end len)) (define (vector-copy! src src-from dst dst-from size) (if (<= dst-from src-from) (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))))) (when (or (negative? start) (negative? end)) (assertion-violation 'vector-sort! start and end must be positive start vect)) (when (or (> start len) (> end len)) (assertion-violation 'vector-sort! out of range (list (list start end) len) vect)) (when (> start end) (assertion-violation 'vector-sort! start is greater than end (list start end) vect)) (let* ((lst (vector->list vect start end)) (lst2 (list-sort proc lst))) (cond ((eq? lst lst2) vect) ((= (- end start) len) (list->vector lst2)) (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end))))))) */,
    0x0000034a    /*  49 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#(sagittarius compiler)> */,
    0x00000363    /*  51 RESV_STACK */,
    0x00000105    /*  52 LREF */,
    0x00000042    /*  53 VEC_LEN */,
    0x00000731    /*  54 INST_STACK */,
    0x00000505    /*  55 LREF */,
    0x00000017    /*  56 TEST */,
    SG_WORD(3),
    0x00000018    /*  58 JUMP */,
    SG_WORD(2),
    0x00000705    /*  60 LREF */,
    0x00000831    /*  61 INST_STACK */,
    0x00000009    /*  62 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17177#core.base> */,
    0x00000931    /*  64 INST_STACK */,
    0x00000030    /*  65 FRAME */,
    SG_WORD(4),
    0x00000345    /*  67 LREF_PUSH */,
    0x0000014a    /*  68 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier negative?#core.base> */,
    0x00000017    /*  70 TEST */,
    SG_WORD(13),
    0x00000030    /*  72 FRAME */,
    SG_WORD(9),
    0x00000048    /*  74 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* vector-sort! */,
    0x00000048    /*  76 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* start and end must be positive */,
    0x00000345    /*  78 LREF_PUSH */,
    0x00000145    /*  79 LREF_PUSH */,
    0x0000044a    /*  80 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000018    /*  82 JUMP */,
    SG_WORD(13),
    0x00000030    /*  84 FRAME */,
    SG_WORD(4),
    0x00000845    /*  86 LREF_PUSH */,
    0x0000014a    /*  87 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier negative?#core.base> */,
    0x00000017    /*  89 TEST */,
    SG_WORD(5),
    0x00000018    /*  91 JUMP */,
    SG_WORD(-20),
    0x00000018    /*  93 JUMP */,
    SG_WORD(2),
    0x00000002    /*  95 UNDEF */,
    0x00000345    /*  96 LREF_PUSH */,
    0x00000705    /*  97 LREF */,
    0x0000001d    /*  98 BNGT */,
    SG_WORD(19),
    0x00000030    /* 100 FRAME */,
    SG_WORD(15),
    0x00000048    /* 102 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* vector-sort! */,
    0x00000048    /* 104 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* out of range */,
    0x00000345    /* 106 LREF_PUSH */,
    0x00000805    /* 107 LREF */,
    0x00000238    /* 108 LIST */,
    0x0000000b    /* 109 PUSH */,
    0x00000705    /* 110 LREF */,
    0x00000238    /* 111 LIST */,
    0x0000000b    /* 112 PUSH */,
    0x00000145    /* 113 LREF_PUSH */,
    0x0000044a    /* 114 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000018    /* 116 JUMP */,
    SG_WORD(10),
    0x00000845    /* 118 LREF_PUSH */,
    0x00000705    /* 119 LREF */,
    0x0000001d    /* 120 BNGT */,
    SG_WORD(5),
    0x00000018    /* 122 JUMP */,
    SG_WORD(-23),
    0x00000018    /* 124 JUMP */,
    SG_WORD(2),
    0x00000002    /* 126 UNDEF */,
    0x00000345    /* 127 LREF_PUSH */,
    0x00000805    /* 128 LREF */,
    0x0000001d    /* 129 BNGT */,
    SG_WORD(16),
    0x00000030    /* 131 FRAME */,
    SG_WORD(12),
    0x00000048    /* 133 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* vector-sort! */,
    0x00000048    /* 135 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* start is greater than end */,
    0x00000345    /* 137 LREF_PUSH */,
    0x00000805    /* 138 LREF */,
    0x00000238    /* 139 LIST */,
    0x0000000b    /* 140 PUSH */,
    0x00000145    /* 141 LREF_PUSH */,
    0x0000044a    /* 142 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000018    /* 144 JUMP */,
    SG_WORD(2),
    0x00000002    /* 146 UNDEF */,
    0x00000030    /* 147 FRAME */,
    SG_WORD(6),
    0x00000145    /* 149 LREF_PUSH */,
    0x00000345    /* 150 LREF_PUSH */,
    0x00000845    /* 151 LREF_PUSH */,
    0x0000034a    /* 152 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier vector->list#core.base> */,
    0x0000000b    /* 154 PUSH */,
    0x00000030    /* 155 FRAME */,
    SG_WORD(5),
    0x00000045    /* 157 LREF_PUSH */,
    0x00000a45    /* 158 LREF_PUSH */,
    0x0000024a    /* 159 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier list-sort#core.base> */,
    0x0000000b    /* 161 PUSH */,
    0x00000a45    /* 162 LREF_PUSH */,
    0x00000b05    /* 163 LREF */,
    0x0000001f    /* 164 BNEQ */,
    SG_WORD(3),
    0x00000105    /* 166 LREF */,
    0x0000002f    /* 167 RET */,
    0x00000845    /* 168 LREF_PUSH */,
    0x00000305    /* 169 LREF */,
    0x00000010    /* 170 SUB */,
    0x0000000b    /* 171 PUSH */,
    0x00000705    /* 172 LREF */,
    0x0000001a    /* 173 BNNUME */,
    SG_WORD(5),
    0x00000b45    /* 175 LREF_PUSH */,
    0x0000014b    /* 176 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier list->vector#core.base> */,
    0x0000002f    /* 178 RET */,
    0x00000030    /* 179 FRAME */,
    SG_WORD(4),
    0x00000745    /* 181 LREF_PUSH */,
    0x0000014a    /* 182 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-vector#core.base> */,
    0x0000000b    /* 184 PUSH */,
    0x00000030    /* 185 FRAME */,
    SG_WORD(9),
    0x00000145    /* 187 LREF_PUSH */,
    0x00000049    /* 188 CONSTI_PUSH */,
    0x00000c45    /* 189 LREF_PUSH */,
    0x00000049    /* 190 CONSTI_PUSH */,
    0x00000345    /* 191 LREF_PUSH */,
    0x00000009    /* 192 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17177#core.base> */,
    0x0000052c    /* 194 LOCAL_CALL */,
    0x00000345    /* 195 LREF_PUSH */,
    0x00000b45    /* 196 LREF_PUSH */,
    0x00000e05    /* 197 LREF */,
    0x00000021    /* 198 BNNULL */,
    SG_WORD(3),
    0x00000018    /* 200 JUMP */,
    SG_WORD(12),
    0x00000c45    /* 202 LREF_PUSH */,
    0x00000d45    /* 203 LREF_PUSH */,
    0x00000e55    /* 204 LREF_CAR */,
    0x00000044    /* 205 VEC_SET */,
    0x00000d05    /* 206 LREF */,
    0x0000010f    /* 207 ADDI */,
    0x0000000b    /* 208 PUSH */,
    0x00000e5c    /* 209 LREF_CDR_PUSH */,
    0x00d00219    /* 210 SHIFTJ */,
    0x00000018    /* 211 JUMP */,
    SG_WORD(-15),
    0x00000232    /* 213 LEAVE */,
    0x00000145    /* 214 LREF_PUSH */,
    0x00000845    /* 215 LREF_PUSH */,
    0x00000c45    /* 216 LREF_PUSH */,
    0x00000845    /* 217 LREF_PUSH */,
    0x00000745    /* 218 LREF_PUSH */,
    0x00000805    /* 219 LREF */,
    0x00000010    /* 220 SUB */,
    0x0000000b    /* 221 PUSH */,
    0x00000009    /* 222 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17177#core.base> */,
    0x0000052e    /* 224 LOCAL_TAIL_CALL */,
    0x0000002f    /* 225 RET */,
    /* sort! */0x00000145    /*   0 LREF_PUSH */,
    0x00000005    /*   1 LREF */,
    0x00000010    /*   2 SUB */,
    0x0000000b    /*   3 PUSH */,
    0x00000a04    /*   4 CONSTI */,
    0x0000001d    /*   5 BNGT */,
    SG_WORD(135),
    0x00000030    /*   7 FRAME */,
    SG_WORD(8),
    0x00000045    /*   9 LREF_PUSH */,
    0x00000105    /*  10 LREF */,
    0x0000000e    /*  11 ADD */,
    0x0000000b    /*  12 PUSH */,
    0x00000249    /*  13 CONSTI_PUSH */,
    0x0000024a    /*  14 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier div#core.base> */,
    0x0000000b    /*  16 PUSH */,
    0x00000030    /*  17 FRAME */,
    SG_WORD(5),
    0x00000045    /*  19 LREF_PUSH */,
    0x00000245    /*  20 LREF_PUSH */,
    0x00000307    /*  21 FREF */,
    0x0000022c    /*  22 LOCAL_CALL */,
    0x00000030    /*  23 FRAME */,
    SG_WORD(7),
    0x00000205    /*  25 LREF */,
    0x0000010f    /*  26 ADDI */,
    0x0000000b    /*  27 PUSH */,
    0x00000145    /*  28 LREF_PUSH */,
    0x00000307    /*  29 FREF */,
    0x0000022c    /*  30 LOCAL_CALL */,
    0x00000045    /*  31 LREF_PUSH */,
    0x00000049    /*  32 CONSTI_PUSH */,
    0x00000345    /*  33 LREF_PUSH */,
    0x00000205    /*  34 LREF */,
    0x0000001d    /*  35 BNGT */,
    SG_WORD(89),
    0x00000205    /*  37 LREF */,
    0x0000010f    /*  38 ADDI */,
    0x0000000b    /*  39 PUSH */,
    0x00000049    /*  40 CONSTI_PUSH */,
    0x00000045    /*  41 LREF_PUSH */,
    0x00000545    /*  42 LREF_PUSH */,
    0x00000105    /*  43 LREF */,
    0x0000001c    /*  44 BNLE */,
    SG_WORD(77),
    0x00000645    /*  46 LREF_PUSH */,
    0x00000405    /*  47 LREF */,
    0x0000001b    /*  48 BNLT */,
    SG_WORD(49),
    0x00000030    /*  50 FRAME */,
    SG_WORD(11),
    0x00000246    /*  52 FREF_PUSH */,
    0x00000605    /*  53 LREF */,
    0x00000043    /*  54 VEC_REF */,
    0x0000000b    /*  55 PUSH */,
    0x00000146    /*  56 FREF_PUSH */,
    0x00000505    /*  57 LREF */,
    0x00000043    /*  58 VEC_REF */,
    0x0000000b    /*  59 PUSH */,
    0x00000007    /*  60 FREF */,
    0x0000022b    /*  61 CALL */,
    0x00000017    /*  62 TEST */,
    SG_WORD(18),
    0x00000146    /*  64 FREF_PUSH */,
    0x00000745    /*  65 LREF_PUSH */,
    0x00000246    /*  66 FREF_PUSH */,
    0x00000605    /*  67 LREF */,
    0x00000043    /*  68 VEC_REF */,
    0x00000044    /*  69 VEC_SET */,
    0x00000545    /*  70 LREF_PUSH */,
    0x00000605    /*  71 LREF */,
    0x0000010f    /*  72 ADDI */,
    0x0000000b    /*  73 PUSH */,
    0x00000705    /*  74 LREF */,
    0x0000010f    /*  75 ADDI */,
    0x0000000b    /*  76 PUSH */,
    0x00500319    /*  77 SHIFTJ */,
    0x00000018    /*  78 JUMP */,
    SG_WORD(-37),
    0x0000002f    /*  80 RET */,
    0x00000146    /*  81 FREF_PUSH */,
    0x00000745    /*  82 LREF_PUSH */,
    0x00000146    /*  83 FREF_PUSH */,
    0x00000505    /*  84 LREF */,
    0x00000043    /*  85 VEC_REF */,
    0x00000044    /*  86 VEC_SET */,
    0x00000505    /*  87 LREF */,
    0x0000010f    /*  88 ADDI */,
    0x0000000b    /*  89 PUSH */,
    0x00000645    /*  90 LREF_PUSH */,
    0x00000705    /*  91 LREF */,
    0x0000010f    /*  92 ADDI */,
    0x0000000b    /*  93 PUSH */,
    0x00500319    /*  94 SHIFTJ */,
    0x00000018    /*  95 JUMP */,
    SG_WORD(-54),
    0x0000002f    /*  97 RET */,
    0x00000645    /*  98 LREF_PUSH */,
    0x00000745    /*  99 LREF_PUSH */,
    0x00000845    /* 100 LREF_PUSH */,
    0x00000405    /* 101 LREF */,
    0x0000001b    /* 102 BNLT */,
    SG_WORD(17),
    0x00000146    /* 104 FREF_PUSH */,
    0x00000945    /* 105 LREF_PUSH */,
    0x00000246    /* 106 FREF_PUSH */,
    0x00000805    /* 107 LREF */,
    0x00000043    /* 108 VEC_REF */,
    0x00000044    /* 109 VEC_SET */,
    0x00000805    /* 110 LREF */,
    0x0000010f    /* 111 ADDI */,
    0x0000000b    /* 112 PUSH */,
    0x00000905    /* 113 LREF */,
    0x0000010f    /* 114 ADDI */,
    0x0000000b    /* 115 PUSH */,
    0x00800219    /* 116 SHIFTJ */,
    0x00000018    /* 117 JUMP */,
    SG_WORD(-18),
    0x0000002f    /* 119 RET */,
    0x00000002    /* 120 UNDEF */,
    0x0000002f    /* 121 RET */,
    0x00000018    /* 122 JUMP */,
    SG_WORD(-25),
    0x0000002f    /* 124 RET */,
    0x00000246    /* 125 FREF_PUSH */,
    0x00000445    /* 126 LREF_PUSH */,
    0x00000146    /* 127 FREF_PUSH */,
    0x00000305    /* 128 LREF */,
    0x00000043    /* 129 VEC_REF */,
    0x00000044    /* 130 VEC_SET */,
    0x00000305    /* 131 LREF */,
    0x0000010f    /* 132 ADDI */,
    0x0000000b    /* 133 PUSH */,
    0x00000405    /* 134 LREF */,
    0x0000010f    /* 135 ADDI */,
    0x0000000b    /* 136 PUSH */,
    0x00300219    /* 137 SHIFTJ */,
    0x00000018    /* 138 JUMP */,
    SG_WORD(-106),
    0x0000002f    /* 140 RET */,
    0x00000045    /* 141 LREF_PUSH */,
    0x00000145    /* 142 LREF_PUSH */,
    0x00000245    /* 143 LREF_PUSH */,
    0x00000445    /* 144 LREF_PUSH */,
    0x00000305    /* 145 LREF */,
    0x0000001b    /* 146 BNLT */,
    SG_WORD(64),
    0x00000146    /* 148 FREF_PUSH */,
    0x00000405    /* 149 LREF */,
    0x00000043    /* 150 VEC_REF */,
    0x0000000b    /* 151 PUSH */,
    0x00000445    /* 152 LREF_PUSH */,
    0x0000010c    /* 153 BOX */,
    0x0000000c    /* 154 BOX */,
    0x00000405    /* 155 LREF */,
    0x0000010f    /* 156 ADDI */,
    0x0000000b    /* 157 PUSH */,
    0x00000745    /* 158 LREF_PUSH */,
    0x00000305    /* 159 LREF */,
    0x0000001c    /* 160 BNLE */,
    SG_WORD(30),
    0x00000030    /* 162 FRAME */,
    SG_WORD(10),
    0x00000146    /* 164 FREF_PUSH */,
    0x00000705    /* 165 LREF */,
    0x00000043    /* 166 VEC_REF */,
    0x0000000b    /* 167 PUSH */,
    0x00000505    /* 168 LREF */,
    0x0000000d    /* 169 UNBOX */,
    0x0000000b    /* 170 PUSH */,
    0x00000007    /* 171 FREF */,
    0x0000022b    /* 172 CALL */,
    0x00000017    /* 173 TEST */,
    SG_WORD(9),
    0x00000146    /* 175 FREF_PUSH */,
    0x00000705    /* 176 LREF */,
    0x00000043    /* 177 VEC_REF */,
    0x00000506    /* 178 LSET */,
    0x00000705    /* 179 LREF */,
    0x00000606    /* 180 LSET */,
    0x00000018    /* 181 JUMP */,
    SG_WORD(2),
    0x00000002    /* 183 UNDEF */,
    0x00000705    /* 184 LREF */,
    0x0000010f    /* 185 ADDI */,
    0x0000000b    /* 186 PUSH */,
    0x00700119    /* 187 SHIFTJ */,
    0x00000018    /* 188 JUMP */,
    SG_WORD(-31),
    0x0000002f    /* 190 RET */,
    0x00000146    /* 191 FREF_PUSH */,
    0x00000605    /* 192 LREF */,
    0x0000000d    /* 193 UNBOX */,
    0x0000000b    /* 194 PUSH */,
    0x00000146    /* 195 FREF_PUSH */,
    0x00000405    /* 196 LREF */,
    0x00000043    /* 197 VEC_REF */,
    0x00000044    /* 198 VEC_SET */,
    0x00000146    /* 199 FREF_PUSH */,
    0x00000445    /* 200 LREF_PUSH */,
    0x00000505    /* 201 LREF */,
    0x0000000d    /* 202 UNBOX */,
    0x00000044    /* 203 VEC_SET */,
    0x00000405    /* 204 LREF */,
    0x0000010f    /* 205 ADDI */,
    0x0000000b    /* 206 PUSH */,
    0x00400119    /* 207 SHIFTJ */,
    0x00000018    /* 208 JUMP */,
    SG_WORD(-65),
    0x0000002f    /* 210 RET */,
    0x00000002    /* 211 UNDEF */,
    0x0000002f    /* 212 RET */,
    /* vector-sort! */0x00000205    /*   0 LREF */,
    0x00000021    /*   1 BNNULL */,
    SG_WORD(4),
    0x00000004    /*   3 CONSTI */,
    0x00000018    /*   4 JUMP */,
    SG_WORD(2),
    0x00000255    /*   6 LREF_CAR */,
    0x0000000b    /*   7 PUSH */,
    0x00000205    /*   8 LREF */,
    0x00000021    /*   9 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  11 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x00000018    /*  13 JUMP */,
    SG_WORD(2),
    0x00000256    /*  15 LREF_CDR */,
    0x0000000b    /*  16 PUSH */,
    0x00000405    /*  17 LREF */,
    0x00000021    /*  18 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  20 CONST */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000018    /*  22 JUMP */,
    SG_WORD(2),
    0x00000455    /*  24 LREF_CAR */,
    0x0000000b    /*  25 PUSH */,
    0x00000405    /*  26 LREF */,
    0x00000021    /*  27 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  29 CONST */,
    SG_WORD(SG_NIL) /* () */,
    0x00000018    /*  31 JUMP */,
    SG_WORD(2),
    0x00000456    /*  33 LREF_CDR */,
    0x0000000b    /*  34 PUSH */,
    0x00000605    /*  35 LREF */,
    0x00000021    /*  36 BNNULL */,
    SG_WORD(4),
    0x00000002    /*  38 UNDEF */,
    0x00000018    /*  39 JUMP */,
    SG_WORD(11),
    0x00000030    /*  41 FRAME */,
    SG_WORD(9),
    0x00000048    /*  43 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* lambda */,
    0x00000048    /*  45 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* too many argument for */,
    0x00000048    /*  47 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* ((define len (vector-length vect)) (define end (or maybe-end len)) (when (or (negative? start) (negative? end)) (assertion-violation 'vector-sort! start and end must be positive start vect)) (when (or (> start len) (> end len)) (assertion-violation 'vector-sort! out of range (list (list start end) len) vect)) (when (> start end) (assertion-violation 'vector-sort! start is greater than end (list start end) vect)) (let* ((n (- end start)) (work (make-vector (+ (div n 2) 1)))) (define (simple-sort! first last) (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))))) (define (sort! first last) (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last)))) (sort! start (- end 1)))) */,
    0x0000034a    /*  49 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#(sagittarius compiler)> */,
    0x00000263    /*  51 RESV_STACK */,
    0x00000105    /*  52 LREF */,
    0x00000042    /*  53 VEC_LEN */,
    0x00000731    /*  54 INST_STACK */,
    0x00000505    /*  55 LREF */,
    0x00000017    /*  56 TEST */,
    SG_WORD(3),
    0x00000018    /*  58 JUMP */,
    SG_WORD(2),
    0x00000705    /*  60 LREF */,
    0x00000831    /*  61 INST_STACK */,
    0x00000030    /*  62 FRAME */,
    SG_WORD(4),
    0x00000345    /*  64 LREF_PUSH */,
    0x0000014a    /*  65 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier negative?#core.base> */,
    0x00000017    /*  67 TEST */,
    SG_WORD(13),
    0x00000030    /*  69 FRAME */,
    SG_WORD(9),
    0x00000048    /*  71 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* vector-sort! */,
    0x00000048    /*  73 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* start and end must be positive */,
    0x00000345    /*  75 LREF_PUSH */,
    0x00000145    /*  76 LREF_PUSH */,
    0x0000044a    /*  77 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000018    /*  79 JUMP */,
    SG_WORD(13),
    0x00000030    /*  81 FRAME */,
    SG_WORD(4),
    0x00000845    /*  83 LREF_PUSH */,
    0x0000014a    /*  84 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier negative?#core.base> */,
    0x00000017    /*  86 TEST */,
    SG_WORD(5),
    0x00000018    /*  88 JUMP */,
    SG_WORD(-20),
    0x00000018    /*  90 JUMP */,
    SG_WORD(2),
    0x00000002    /*  92 UNDEF */,
    0x00000345    /*  93 LREF_PUSH */,
    0x00000705    /*  94 LREF */,
    0x0000001d    /*  95 BNGT */,
    SG_WORD(19),
    0x00000030    /*  97 FRAME */,
    SG_WORD(15),
    0x00000048    /*  99 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* vector-sort! */,
    0x00000048    /* 101 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* out of range */,
    0x00000345    /* 103 LREF_PUSH */,
    0x00000805    /* 104 LREF */,
    0x00000238    /* 105 LIST */,
    0x0000000b    /* 106 PUSH */,
    0x00000705    /* 107 LREF */,
    0x00000238    /* 108 LIST */,
    0x0000000b    /* 109 PUSH */,
    0x00000145    /* 110 LREF_PUSH */,
    0x0000044a    /* 111 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000018    /* 113 JUMP */,
    SG_WORD(10),
    0x00000845    /* 115 LREF_PUSH */,
    0x00000705    /* 116 LREF */,
    0x0000001d    /* 117 BNGT */,
    SG_WORD(5),
    0x00000018    /* 119 JUMP */,
    SG_WORD(-23),
    0x00000018    /* 121 JUMP */,
    SG_WORD(2),
    0x00000002    /* 123 UNDEF */,
    0x00000345    /* 124 LREF_PUSH */,
    0x00000805    /* 125 LREF */,
    0x0000001d    /* 126 BNGT */,
    SG_WORD(16),
    0x00000030    /* 128 FRAME */,
    SG_WORD(12),
    0x00000048    /* 130 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* vector-sort! */,
    0x00000048    /* 132 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* start is greater than end */,
    0x00000345    /* 134 LREF_PUSH */,
    0x00000805    /* 135 LREF */,
    0x00000238    /* 136 LIST */,
    0x0000000b    /* 137 PUSH */,
    0x00000145    /* 138 LREF_PUSH */,
    0x0000044a    /* 139 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000018    /* 141 JUMP */,
    SG_WORD(2),
    0x00000002    /* 143 UNDEF */,
    0x00000845    /* 144 LREF_PUSH */,
    0x00000305    /* 145 LREF */,
    0x00000010    /* 146 SUB */,
    0x0000000b    /* 147 PUSH */,
    0x00000030    /* 148 FRAME */,
    SG_WORD(11),
    0x00000030    /* 150 FRAME */,
    SG_WORD(5),
    0x00000945    /* 152 LREF_PUSH */,
    0x00000249    /* 153 CONSTI_PUSH */,
    0x0000024a    /* 154 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier div#core.base> */,
    0x0000010f    /* 156 ADDI */,
    0x0000000b    /* 157 PUSH */,
    0x0000014a    /* 158 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-vector#core.base> */,
    0x0000000b    /* 160 PUSH */,
    0x00000163    /* 161 RESV_STACK */,
    0x00000b45    /* 162 LREF_PUSH */,
    0x00000a45    /* 163 LREF_PUSH */,
    0x00000145    /* 164 LREF_PUSH */,
    0x00000045    /* 165 LREF_PUSH */,
    0x00000429    /* 166 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[93])) /* #<code-builder sort! (2 0 4)> */,
    0x00000b31    /* 168 INST_STACK */,
    0x00000345    /* 169 LREF_PUSH */,
    0x00000805    /* 170 LREF */,
    -0x000000f1   /* 171 ADDI */,
    0x0000000b    /* 172 PUSH */,
    0x00000b05    /* 173 LREF */,
    0x0000022e    /* 174 LOCAL_TAIL_CALL */,
    0x0000002f    /* 175 RET */,
    /* call-with-port */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x00000105    /*   3 LREF */,
    0x0000012b    /*   4 CALL */,
    0x00100028    /*   5 RECEIVE */,
    0x00000030    /*   6 FRAME */,
    SG_WORD(4),
    0x00000045    /*   8 LREF_PUSH */,
    0x0000014a    /*   9 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier close-port#core.base> */,
    0x00000047    /*  11 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.base> */,
    0x00000205    /*  13 LREF */,
    0x0010022a    /*  14 APPLY */,
    0x0000002f    /*  15 RET */,
    /* proc */0x00000046    /*   0 FREF_PUSH */,
    0x0000014b    /*   1 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier extract-output-bytevector#core.base> */,
    0x0000002f    /*   3 RET */,
    /* open-bytevector-output-port */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x0000000b    /*   5 PUSH */,
    0x00000104    /*   6 CONSTI */,
    0x0000001d    /*   7 BNGT */,
    SG_WORD(23),
    0x00000030    /*   9 FRAME */,
    SG_WORD(19),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* open-bytevector-output-port */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(11),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* wrong number of argument: expected between 0 and 1, but got ~a */,
    0x00000030    /*  17 FRAME */,
    SG_WORD(4),
    0x00000045    /*  19 LREF_PUSH */,
    0x0000014a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier length#core.base> */,
    0x0000000b    /*  22 PUSH */,
    0x0000024a    /*  23 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier format#core.base> */,
    0x0000000b    /*  25 PUSH */,
    0x00000045    /*  26 LREF_PUSH */,
    0x0000034a    /*  27 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000018    /*  29 JUMP */,
    SG_WORD(2),
    0x00000002    /*  31 UNDEF */,
    0x00000005    /*  32 LREF */,
    0x00000021    /*  33 BNNULL */,
    SG_WORD(5),
    0x00000003    /*  35 CONST */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000018    /*  37 JUMP */,
    SG_WORD(2),
    0x00000055    /*  39 LREF_CAR */,
    0x0000000b    /*  40 PUSH */,
    0x00000030    /*  41 FRAME */,
    SG_WORD(4),
    0x00000145    /*  43 LREF_PUSH */,
    0x0000014a    /*  44 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier open-output-bytevector#core.base> */,
    0x0000000b    /*  46 PUSH */,
    0x00000245    /*  47 LREF_PUSH */,
    0x00000029    /*  48 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[96])) /* #<code-builder proc (0 0 1)> */,
    0x0000000b    /*  50 PUSH */,
    0x00000245    /*  51 LREF_PUSH */,
    0x00000305    /*  52 LREF */,
    0x0000023a    /*  53 VALUES */,
    0x0000002f    /*  54 RET */,
    /* proc */0x00000046    /*   0 FREF_PUSH */,
    0x0000014b    /*   1 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier extract-output-string#core.base> */,
    0x0000002f    /*   3 RET */,
    /* open-string-output-port */0x00000030    /*   0 FRAME */,
    SG_WORD(3),
    0x0000004a    /*   2 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier open-output-string#core.base> */,
    0x0000000b    /*   4 PUSH */,
    0x00000045    /*   5 LREF_PUSH */,
    0x00000029    /*   6 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[98])) /* #<code-builder proc (0 0 1)> */,
    0x0000000b    /*   8 PUSH */,
    0x00000045    /*   9 LREF_PUSH */,
    0x00000105    /*  10 LREF */,
    0x0000023a    /*  11 VALUES */,
    0x0000002f    /*  12 RET */,
    /* call-with-bytevector-output-port */0x00000030    /*   0 FRAME */,
    SG_WORD(5),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier open-bytevector-output-port#core.base> */,
    0x00000105    /*   4 LREF */,
    0x0000022a    /*   5 APPLY */,
    0x00000228    /*   6 RECEIVE */,
    0x00000030    /*   7 FRAME */,
    SG_WORD(4),
    0x00000245    /*   9 LREF_PUSH */,
    0x00000005    /*  10 LREF */,
    0x0000012b    /*  11 CALL */,
    0x00000305    /*  12 LREF */,
    0x0000002d    /*  13 TAIL_CALL */,
    0x0000002f    /*  14 RET */,
    /* call-with-string-output-port */0x00000030    /*   0 FRAME */,
    SG_WORD(3),
    0x0000004a    /*   2 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier open-string-output-port#core.base> */,
    0x00000228    /*   4 RECEIVE */,
    0x00000030    /*   5 FRAME */,
    SG_WORD(4),
    0x00000145    /*   7 LREF_PUSH */,
    0x00000005    /*   8 LREF */,
    0x0000012b    /*   9 CALL */,
    0x00000205    /*  10 LREF */,
    0x0000002d    /*  11 TAIL_CALL */,
    0x0000002f    /*  12 RET */,
    /* hashtable-equivalence-function */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(15),
    0x00000030    /*   9 FRAME */,
    SG_WORD(13),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-equivalence-function */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(6),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable */,
    0x00000045    /*  17 LREF_PUSH */,
    0x0000024a    /*  18 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  20 PUSH */,
    0x0000024a    /*  21 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  23 FRAME */,
    SG_WORD(4),
    0x00000045    /*  25 LREF_PUSH */,
    0x0000014a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-type#core.base> */,
    0x0000000b    /*  28 PUSH */,
    0x00000145    /*  29 LREF_PUSH */,
    0x00000003    /*  30 CONST */,
    SG_WORD(SG_UNDEF) /* eq */,
    0x0000001f    /*  32 BNEQ */,
    SG_WORD(4),
    0x00000009    /*  34 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier eq?#core.base> */,
    0x0000002f    /*  36 RET */,
    0x00000145    /*  37 LREF_PUSH */,
    0x00000003    /*  38 CONST */,
    SG_WORD(SG_UNDEF) /* eqv */,
    0x0000001f    /*  40 BNEQ */,
    SG_WORD(4),
    0x00000009    /*  42 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier eqv?#core.base> */,
    0x0000002f    /*  44 RET */,
    0x00000145    /*  45 LREF_PUSH */,
    0x00000003    /*  46 CONST */,
    SG_WORD(SG_UNDEF) /* equal */,
    0x0000001f    /*  48 BNEQ */,
    SG_WORD(4),
    0x00000009    /*  50 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier equal?#core.base> */,
    0x0000002f    /*  52 RET */,
    0x00000145    /*  53 LREF_PUSH */,
    0x00000003    /*  54 CONST */,
    SG_WORD(SG_UNDEF) /* string */,
    0x0000001f    /*  56 BNEQ */,
    SG_WORD(4),
    0x00000009    /*  58 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier string=?#core.base> */,
    0x0000002f    /*  60 RET */,
    0x00000145    /*  61 LREF_PUSH */,
    0x00000003    /*  62 CONST */,
    SG_WORD(SG_UNDEF) /* general */,
    0x0000001f    /*  64 BNEQ */,
    SG_WORD(5),
    0x00000045    /*  66 LREF_PUSH */,
    0x0000014b    /*  67 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-compare#core.base> */,
    0x0000002f    /*  69 RET */,
    0x00000061    /*  70 CONST_RET */,
    SG_WORD(SG_UNDEF) /* #<unspecified> */,
    /* hashtable-hash-function */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable?#core.base> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(3),
    0x00000018    /*   7 JUMP */,
    SG_WORD(15),
    0x00000030    /*   9 FRAME */,
    SG_WORD(13),
    0x00000048    /*  11 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable-hash-function */,
    0x00000030    /*  13 FRAME */,
    SG_WORD(6),
    0x00000048    /*  15 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* hashtable */,
    0x00000045    /*  17 LREF_PUSH */,
    0x0000024a    /*  18 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x0000000b    /*  20 PUSH */,
    0x0000024a    /*  21 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion-violation#core.base> */,
    0x00000030    /*  23 FRAME */,
    SG_WORD(4),
    0x00000045    /*  25 LREF_PUSH */,
    0x0000014a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-type#core.base> */,
    0x0000000b    /*  28 PUSH */,
    0x00000145    /*  29 LREF_PUSH */,
    0x00000003    /*  30 CONST */,
    SG_WORD(SG_UNDEF) /* eq */,
    0x0000001f    /*  32 BNEQ */,
    SG_WORD(3),
    0x00000061    /*  34 CONST_RET */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000145    /*  36 LREF_PUSH */,
    0x00000003    /*  37 CONST */,
    SG_WORD(SG_UNDEF) /* eqv */,
    0x0000001f    /*  39 BNEQ */,
    SG_WORD(3),
    0x00000061    /*  41 CONST_RET */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000145    /*  43 LREF_PUSH */,
    0x00000003    /*  44 CONST */,
    SG_WORD(SG_UNDEF) /* equal */,
    0x0000001f    /*  46 BNEQ */,
    SG_WORD(4),
    0x00000009    /*  48 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier equal-hash#core.base> */,
    0x0000002f    /*  50 RET */,
    0x00000145    /*  51 LREF_PUSH */,
    0x00000003    /*  52 CONST */,
    SG_WORD(SG_UNDEF) /* string */,
    0x0000001f    /*  54 BNEQ */,
    SG_WORD(4),
    0x00000009    /*  56 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier string-hash#core.base> */,
    0x0000002f    /*  58 RET */,
    0x00000145    /*  59 LREF_PUSH */,
    0x00000003    /*  60 CONST */,
    SG_WORD(SG_UNDEF) /* general */,
    0x0000001f    /*  62 BNEQ */,
    SG_WORD(5),
    0x00000045    /*  64 LREF_PUSH */,
    0x0000014b    /*  65 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-hasher#core.base> */,
    0x0000002f    /*  67 RET */,
    0x00000061    /*  68 CONST_RET */,
    SG_WORD(SG_UNDEF) /* #<unspecified> */,
    /* #f */0x00000029    /*   0 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[0])) /* #<code-builder (vector-map vector-tabulate) (2 0 0)> */,
    0x00000033    /*   2 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17185#core.base> */,
    0x00000029    /*   4 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[1])) /* #<code-builder (vector-map! vector-update!) (3 0 0)> */,
    0x00000033    /*   6 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17184#core.base> */,
    0x00000029    /*   8 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[2])) /* #<code-builder (take recur) (2 0 0)> */,
    0x00000033    /*  10 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17183#core.base> */,
    0x00000029    /*  12 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[3])) /* #<code-builder (for-all loop) (1 0 0)> */,
    0x00000033    /*  14 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17182#core.base> */,
    0x00000029    /*  16 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[4])) /* #<code-builder (for-all collect-cdr) (1 0 0)> */,
    0x00000033    /*  18 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17181#core.base> */,
    0x00000029    /*  20 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[5])) /* #<code-builder (exists loop) (1 0 0)> */,
    0x00000033    /*  22 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17180#core.base> */,
    0x00000029    /*  24 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[6])) /* #<code-builder (exists collect-cdr) (1 0 0)> */,
    0x00000033    /*  26 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17179#core.base> */,
    0x00000029    /*  28 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[7])) /* #<code-builder (list-sort merge-list!) (5 0 0)> */,
    0x00000033    /*  30 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17178#core.base> */,
    0x00000029    /*  32 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[8])) /* #<code-builder (vector-sort vector-copy!) (5 0 0)> */,
    0x00000033    /*  34 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda17177#core.base> */,
    0x00000034    /*  36 LIBRARY */,
    SG_WORD(SG_UNDEF) /* #<library core.base> */,
    0x00000029    /*  38 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[9])) /* #<code-builder hashtable-for-each (2 0 0)> */,
    0x00000033    /*  40 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-for-each#core.base> */,
    0x00000029    /*  42 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[10])) /* #<code-builder hashtable-map (2 0 0)> */,
    0x00000033    /*  44 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-map#core.base> */,
    0x00000029    /*  46 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[11])) /* #<code-builder hashtable-fold (3 0 0)> */,
    0x00000033    /*  48 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-fold#core.base> */,
    0x00000029    /*  50 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[12])) /* #<code-builder hashtable->alist (1 0 0)> */,
    0x00000033    /*  52 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable->alist#core.base> */,
    0x00000029    /*  54 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[13])) /* #<code-builder unique-id-list? (1 0 0)> */,
    0x00000033    /*  56 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier unique-id-list?#core.base> */,
    0x00000029    /*  58 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[14])) /* #<code-builder call-with-values (2 0 0)> */,
    0x00000033    /*  60 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier call-with-values#core.base> */,
    0x00000029    /*  62 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[15])) /* #<code-builder print (0 1 0)> */,
    0x00000033    /*  64 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier print#core.base> */,
    0x00000029    /*  66 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[16])) /* #<code-builder fold (3 1 0)> */,
    0x00000033    /*  68 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier fold#core.base> */,
    0x00000029    /*  70 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[17])) /* #<code-builder wrong-type-argument-message (2 1 0)> */,
    0x00000033    /*  72 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier wrong-type-argument-message#core.base> */,
    0x00000029    /*  74 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[21])) /* #<code-builder vector-map (2 1 0)> */,
    0x00000033    /*  76 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-map#core.base> */,
    0x00000029    /*  78 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[25])) /* #<code-builder vector-map! (2 1 0)> */,
    0x00000033    /*  80 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-map!#core.base> */,
    0x00000029    /*  82 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[27])) /* #<code-builder vector-for-each (2 1 0)> */,
    0x00000033    /*  84 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-for-each#core.base> */,
    0x00000029    /*  86 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[29])) /* #<code-builder string-for-each (2 1 0)> */,
    0x00000033    /*  88 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier string-for-each#core.base> */,
    0x00000029    /*  90 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[32])) /* #<code-builder string-join (1 1 0)> */,
    0x00000033    /*  92 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier string-join#core.base> */,
    0x00000029    /*  94 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[33])) /* #<code-builder null-list? (1 0 0)> */,
    0x00000033    /*  96 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier null-list?#core.base> */,
    0x00000029    /*  98 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[34])) /* #<code-builder split-at (2 0 0)> */,
    0x00000033    /* 100 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier split-at#core.base> */,
    0x00000029    /* 102 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[35])) /* #<code-builder find (2 0 0)> */,
    0x00000033    /* 104 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier find#core.base> */,
    0x00000029    /* 106 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[36])) /* #<code-builder find-tail (2 0 0)> */,
    0x00000033    /* 108 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier find-tail#core.base> */,
    0x00000029    /* 110 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[38])) /* #<code-builder assoc (2 1 0)> */,
    0x00000033    /* 112 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier assoc#core.base> */,
    0x00000029    /* 114 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[40])) /* #<code-builder member (2 1 0)> */,
    0x00000033    /* 116 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier member#core.base> */,
    0x00000029    /* 118 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[42])) /* #<code-builder delete (2 1 0)> */,
    0x00000033    /* 120 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier delete#core.base> */,
    0x00000029    /* 122 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[44])) /* #<code-builder delete! (2 1 0)> */,
    0x00000033    /* 124 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier delete!#core.base> */,
    0x00000029    /* 126 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[45])) /* #<code-builder reduce (3 0 0)> */,
    0x00000033    /* 128 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier reduce#core.base> */,
    0x00000029    /* 130 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[49])) /* #<code-builder lset-union (1 1 0)> */,
    0x00000033    /* 132 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lset-union#core.base> */,
    0x00000029    /* 134 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[52])) /* #<code-builder lset-intersection (2 1 0)> */,
    0x00000033    /* 136 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lset-intersection#core.base> */,
    0x00000029    /* 138 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[55])) /* #<code-builder lset-difference (2 1 0)> */,
    0x00000033    /* 140 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lset-difference#core.base> */,
    0x00000029    /* 142 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[56])) /* #<code-builder take (2 0 0)> */,
    0x00000033    /* 144 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier take#core.base> */,
    0x00000029    /* 146 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[57])) /* #<code-builder drop (2 0 0)> */,
    0x00000033    /* 148 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier drop#core.base> */,
    0x00000009    /* 150 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier take#core.base> */,
    0x00000033    /* 152 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier list-head#core.base> */,
    0x00000029    /* 154 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[59])) /* #<code-builder make-ci-comparison (2 0 0)> */,
    0x00000033    /* 156 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000030    /* 158 FRAME */,
    SG_WORD(7),
    0x00000047    /* 160 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char=?#core.base> */,
    0x00000047    /* 162 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char-foldcase#core.base> */,
    0x0000024a    /* 164 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 166 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier char-ci=?#core.base> */,
    0x00000030    /* 168 FRAME */,
    SG_WORD(7),
    0x00000047    /* 170 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char<?#core.base> */,
    0x00000047    /* 172 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char-foldcase#core.base> */,
    0x0000024a    /* 174 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 176 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier char-ci<?#core.base> */,
    0x00000030    /* 178 FRAME */,
    SG_WORD(7),
    0x00000047    /* 180 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char>?#core.base> */,
    0x00000047    /* 182 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char-foldcase#core.base> */,
    0x0000024a    /* 184 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 186 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier char-ci>?#core.base> */,
    0x00000030    /* 188 FRAME */,
    SG_WORD(7),
    0x00000047    /* 190 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char<=?#core.base> */,
    0x00000047    /* 192 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char-foldcase#core.base> */,
    0x0000024a    /* 194 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 196 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier char-ci<=?#core.base> */,
    0x00000030    /* 198 FRAME */,
    SG_WORD(7),
    0x00000047    /* 200 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char>=?#core.base> */,
    0x00000047    /* 202 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier char-foldcase#core.base> */,
    0x0000024a    /* 204 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 206 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier char-ci>=?#core.base> */,
    0x00000030    /* 208 FRAME */,
    SG_WORD(7),
    0x00000047    /* 210 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string=?#core.base> */,
    0x00000047    /* 212 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-foldcase#core.base> */,
    0x0000024a    /* 214 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 216 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier string-ci=?#core.base> */,
    0x00000030    /* 218 FRAME */,
    SG_WORD(7),
    0x00000047    /* 220 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string<?#core.base> */,
    0x00000047    /* 222 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-foldcase#core.base> */,
    0x0000024a    /* 224 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 226 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier string-ci<?#core.base> */,
    0x00000030    /* 228 FRAME */,
    SG_WORD(7),
    0x00000047    /* 230 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string>?#core.base> */,
    0x00000047    /* 232 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-foldcase#core.base> */,
    0x0000024a    /* 234 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 236 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier string-ci>?#core.base> */,
    0x00000030    /* 238 FRAME */,
    SG_WORD(7),
    0x00000047    /* 240 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string<=?#core.base> */,
    0x00000047    /* 242 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-foldcase#core.base> */,
    0x0000024a    /* 244 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 246 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier string-ci<=?#core.base> */,
    0x00000030    /* 248 FRAME */,
    SG_WORD(7),
    0x00000047    /* 250 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string>=?#core.base> */,
    0x00000047    /* 252 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier string-foldcase#core.base> */,
    0x0000024a    /* 254 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-ci-comparison#core.base> */,
    0x00000033    /* 256 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier string-ci>=?#core.base> */,
    0x00000029    /* 258 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[60])) /* #<code-builder bytevector-uint-ref (4 0 0)> */,
    0x00000033    /* 260 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-ref#core.base> */,
    0x00000029    /* 262 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[61])) /* #<code-builder bytevector-sint-ref (4 0 0)> */,
    0x00000033    /* 264 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-sint-ref#core.base> */,
    0x00000029    /* 266 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[62])) /* #<code-builder bytevector-uint-set! (5 0 0)> */,
    0x00000033    /* 268 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-uint-set!#core.base> */,
    0x00000029    /* 270 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[63])) /* #<code-builder bytevector-sint-set! (5 0 0)> */,
    0x00000033    /* 272 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector-sint-set!#core.base> */,
    0x00000029    /* 274 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[64])) /* #<code-builder bytevector->uint-list (3 0 0)> */,
    0x00000033    /* 276 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector->uint-list#core.base> */,
    0x00000029    /* 278 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[65])) /* #<code-builder bytevector->sint-list (3 0 0)> */,
    0x00000033    /* 280 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier bytevector->sint-list#core.base> */,
    0x00000029    /* 282 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[66])) /* #<code-builder uint-list->bytevector (3 0 0)> */,
    0x00000033    /* 284 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier uint-list->bytevector#core.base> */,
    0x00000029    /* 286 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[67])) /* #<code-builder sint-list->bytevector (3 0 0)> */,
    0x00000033    /* 288 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier sint-list->bytevector#core.base> */,
    0x00000029    /* 290 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[70])) /* #<code-builder for-all (2 1 0)> */,
    0x00000033    /* 292 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier for-all#core.base> */,
    0x00000029    /* 294 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[73])) /* #<code-builder exists (2 1 0)> */,
    0x00000033    /* 296 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier exists#core.base> */,
    0x00000029    /* 298 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[74])) /* #<code-builder filter (2 0 0)> */,
    0x00000033    /* 300 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.base> */,
    0x00000029    /* 302 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[75])) /* #<code-builder filter! (2 0 0)> */,
    0x00000033    /* 304 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier filter!#core.base> */,
    0x00000029    /* 306 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[76])) /* #<code-builder partition (2 0 0)> */,
    0x00000033    /* 308 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier partition#core.base> */,
    0x00000029    /* 310 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[77])) /* #<code-builder map (2 1 0)> */,
    0x00000033    /* 312 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier map#core.base> */,
    0x00000029    /* 314 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[78])) /* #<code-builder for-each (2 1 0)> */,
    0x00000033    /* 316 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier for-each#core.base> */,
    0x00000029    /* 318 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[81])) /* #<code-builder filter-map (2 1 0)> */,
    0x00000033    /* 320 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier filter-map#core.base> */,
    0x00000029    /* 322 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[82])) /* #<code-builder fold-left (3 1 0)> */,
    0x00000033    /* 324 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier fold-left#core.base> */,
    0x00000029    /* 326 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[83])) /* #<code-builder fold-right (3 1 0)> */,
    0x00000033    /* 328 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier fold-right#core.base> */,
    0x00000029    /* 330 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[84])) /* #<code-builder remp (2 0 0)> */,
    0x00000033    /* 332 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier remp#core.base> */,
    0x00000029    /* 334 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[85])) /* #<code-builder remove (2 0 0)> */,
    0x00000033    /* 336 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier remove#core.base> */,
    0x00000029    /* 338 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[86])) /* #<code-builder remv (2 0 0)> */,
    0x00000033    /* 340 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier remv#core.base> */,
    0x00000029    /* 342 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[87])) /* #<code-builder remq (2 0 0)> */,
    0x00000033    /* 344 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier remq#core.base> */,
    0x00000029    /* 346 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[88])) /* #<code-builder memp (2 0 0)> */,
    0x00000033    /* 348 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier memp#core.base> */,
    0x00000029    /* 350 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[89])) /* #<code-builder assp (2 0 0)> */,
    0x00000033    /* 352 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier assp#core.base> */,
    0x00000029    /* 354 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[91])) /* #<code-builder list-sort (2 0 0)> */,
    0x00000033    /* 356 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier list-sort#core.base> */,
    0x00000029    /* 358 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[92])) /* #<code-builder vector-sort (2 1 0)> */,
    0x00000033    /* 360 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-sort#core.base> */,
    0x00000029    /* 362 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[94])) /* #<code-builder vector-sort! (2 1 0)> */,
    0x00000033    /* 364 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier vector-sort!#core.base> */,
    0x00000029    /* 366 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[95])) /* #<code-builder call-with-port (2 0 0)> */,
    0x00000033    /* 368 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier call-with-port#core.base> */,
    0x00000029    /* 370 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[97])) /* #<code-builder open-bytevector-output-port (0 1 0)> */,
    0x00000033    /* 372 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier open-bytevector-output-port#core.base> */,
    0x00000029    /* 374 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[99])) /* #<code-builder open-string-output-port (0 0 0)> */,
    0x00000033    /* 376 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier open-string-output-port#core.base> */,
    0x00000029    /* 378 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[100])) /* #<code-builder call-with-bytevector-output-port (1 1 0)> */,
    0x00000033    /* 380 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier call-with-bytevector-output-port#core.base> */,
    0x00000029    /* 382 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[101])) /* #<code-builder call-with-string-output-port (1 0 0)> */,
    0x00000033    /* 384 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier call-with-string-output-port#core.base> */,
    0x00000029    /* 386 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[102])) /* #<code-builder hashtable-equivalence-function (1 0 0)> */,
    0x00000033    /* 388 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-equivalence-function#core.base> */,
    0x00000029    /* 390 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen17086.d17188[103])) /* #<code-builder hashtable-hash-function (1 0 0)> */,
    0x00000033    /* 392 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier hashtable-hash-function#core.base> */,
    0x00000002    /* 394 UNDEF */,
    0x0000002f    /* 395 RET */,
  },
  {  /* SgCodeBuilder d17188 */
    
    SG_STATIC_CODE_BUILDER( /* (vector-map vector-tabulate) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[0]), SG_FALSE, 2, 0, 0, 16, 31),
    
    SG_STATIC_CODE_BUILDER( /* (vector-map! vector-update!) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[31]), SG_FALSE, 3, 0, 0, 14, 22),
    
    SG_STATIC_CODE_BUILDER( /* (take recur) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[53]), SG_FALSE, 2, 0, 0, 12, 18),
    
    SG_STATIC_CODE_BUILDER( /* (for-all loop) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[71]), SG_FALSE, 1, 0, 0, 12, 25),
    
    SG_STATIC_CODE_BUILDER( /* (for-all collect-cdr) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[96]), SG_FALSE, 1, 0, 0, 9, 9),
    
    SG_STATIC_CODE_BUILDER( /* (exists loop) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[105]), SG_FALSE, 1, 0, 0, 12, 25),
    
    SG_STATIC_CODE_BUILDER( /* (exists collect-cdr) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[130]), SG_FALSE, 1, 0, 0, 9, 9),
    
    SG_STATIC_CODE_BUILDER( /* (list-sort merge-list!) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[139]), SG_FALSE, 5, 0, 0, 21, 73),
    
    SG_STATIC_CODE_BUILDER( /* (vector-sort vector-copy!) */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[212]), SG_FALSE, 5, 0, 0, 26, 66),
    
    SG_STATIC_CODE_BUILDER( /* hashtable-for-each */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[278]), SG_FALSE, 2, 0, 0, 19, 83),
    
    SG_STATIC_CODE_BUILDER( /* hashtable-map */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[361]), SG_FALSE, 2, 0, 0, 21, 88),
    
    SG_STATIC_CODE_BUILDER( /* hashtable-fold */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[449]), SG_FALSE, 3, 0, 0, 23, 87),
    
    SG_STATIC_CODE_BUILDER( /* hashtable->alist */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[536]), SG_FALSE, 1, 0, 0, 9, 6),
    
    SG_STATIC_CODE_BUILDER( /* unique-id-list? */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[542]), SG_FALSE, 1, 0, 0, 13, 39),
    
    SG_STATIC_CODE_BUILDER( /* call-with-values */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[581]), SG_FALSE, 2, 0, 0, 10, 9),
    
    SG_STATIC_CODE_BUILDER( /* print */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[590]), SG_FALSE, 0, 1, 0, 9, 10),
    
    SG_STATIC_CODE_BUILDER( /* fold */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[600]), SG_FALSE, 3, 1, 0, 31, 50),
    
    SG_STATIC_CODE_BUILDER( /* wrong-type-argument-message */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[650]), SG_FALSE, 2, 1, 0, 17, 18),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[668]), SG_FALSE, 1, 0, 2, 9, 7),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[675]), SG_FALSE, 1, 0, 1, 8, 4),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[679]), SG_FALSE, 1, 0, 2, 10, 12),
    
    SG_STATIC_CODE_BUILDER( /* vector-map */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[691]), SG_FALSE, 2, 1, 0, 26, 44),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[735]), SG_FALSE, 1, 0, 2, 9, 7),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[742]), SG_FALSE, 1, 0, 1, 8, 4),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[746]), SG_FALSE, 1, 0, 2, 10, 12),
    
    SG_STATIC_CODE_BUILDER( /* vector-map! */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[758]), SG_FALSE, 2, 1, 0, 28, 46),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[804]), SG_FALSE, 1, 0, 1, 8, 4),
    
    SG_STATIC_CODE_BUILDER( /* vector-for-each */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[808]), SG_FALSE, 2, 1, 0, 41, 71),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[879]), SG_FALSE, 1, 0, 1, 9, 5),
    
    SG_STATIC_CODE_BUILDER( /* string-for-each */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[884]), SG_FALSE, 2, 1, 0, 43, 77),
    
    SG_STATIC_CODE_BUILDER( /* recur */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[961]), SG_FALSE, 1, 0, 3, 10, 16),
    
    SG_STATIC_CODE_BUILDER( /* buildit */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[977]), SG_FALSE, 2, 0, 1, 10, 11),
    
    SG_STATIC_CODE_BUILDER( /* string-join */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[988]), SG_FALSE, 1, 1, 0, 45, 175),
    
    SG_STATIC_CODE_BUILDER( /* null-list? */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1163]), SG_FALSE, 1, 0, 0, 11, 19),
    
    SG_STATIC_CODE_BUILDER( /* split-at */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1182]), SG_FALSE, 2, 0, 0, 20, 62),
    
    SG_STATIC_CODE_BUILDER( /* find */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1244]), SG_FALSE, 2, 0, 0, 12, 12),
    
    SG_STATIC_CODE_BUILDER( /* find-tail */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1256]), SG_FALSE, 2, 0, 0, 14, 44),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1300]), SG_FALSE, 1, 0, 2, 9, 5),
    
    SG_STATIC_CODE_BUILDER( /* assoc */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1305]), SG_FALSE, 2, 1, 0, 15, 43),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1348]), SG_FALSE, 1, 0, 2, 9, 5),
    
    SG_STATIC_CODE_BUILDER( /* member */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1353]), SG_FALSE, 2, 1, 0, 15, 19),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1372]), SG_FALSE, 1, 0, 2, 9, 8),
    
    SG_STATIC_CODE_BUILDER( /* delete */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1380]), SG_FALSE, 2, 1, 0, 15, 19),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1399]), SG_FALSE, 1, 0, 2, 9, 8),
    
    SG_STATIC_CODE_BUILDER( /* delete! */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1407]), SG_FALSE, 2, 1, 0, 15, 19),
    
    SG_STATIC_CODE_BUILDER( /* reduce */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1426]), SG_FALSE, 3, 0, 0, 15, 36),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1462]), SG_FALSE, 1, 0, 2, 9, 5),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1467]), SG_FALSE, 2, 0, 1, 11, 18),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1485]), SG_FALSE, 2, 0, 1, 14, 25),
    
    SG_STATIC_CODE_BUILDER( /* lset-union */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1510]), SG_FALSE, 1, 1, 0, 14, 34),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1544]), SG_FALSE, 1, 0, 2, 10, 6),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1550]), SG_FALSE, 1, 0, 2, 9, 9),
    
    SG_STATIC_CODE_BUILDER( /* lset-intersection */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1559]), SG_FALSE, 2, 1, 0, 19, 58),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1617]), SG_FALSE, 1, 0, 2, 10, 9),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1626]), SG_FALSE, 1, 0, 2, 9, 9),
    
    SG_STATIC_CODE_BUILDER( /* lset-difference */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1635]), SG_FALSE, 2, 1, 0, 18, 56),
    
    SG_STATIC_CODE_BUILDER( /* take */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1691]), SG_FALSE, 2, 0, 0, 14, 34),
    
    SG_STATIC_CODE_BUILDER( /* drop */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1725]), SG_FALSE, 2, 0, 0, 14, 40),
    
    SG_STATIC_CODE_BUILDER( /* make-ci-comparison */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1765]), SG_FALSE, 2, 1, 2, 18, 37),
    
    SG_STATIC_CODE_BUILDER( /* make-ci-comparison */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1802]), SG_FALSE, 2, 0, 0, 8, 5),
    
    SG_STATIC_CODE_BUILDER( /* bytevector-uint-ref */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1807]), SG_FALSE, 4, 0, 0, 37, 91),
    
    SG_STATIC_CODE_BUILDER( /* bytevector-sint-ref */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1898]), SG_FALSE, 4, 0, 0, 39, 101),
    
    SG_STATIC_CODE_BUILDER( /* bytevector-uint-set! */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[1999]), SG_FALSE, 5, 0, 0, 56, 165),
    
    SG_STATIC_CODE_BUILDER( /* bytevector-sint-set! */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2164]), SG_FALSE, 5, 0, 0, 40, 82),
    
    SG_STATIC_CODE_BUILDER( /* bytevector->uint-list */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2246]), SG_FALSE, 3, 0, 0, 24, 59),
    
    SG_STATIC_CODE_BUILDER( /* bytevector->sint-list */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2305]), SG_FALSE, 3, 0, 0, 24, 59),
    
    SG_STATIC_CODE_BUILDER( /* uint-list->bytevector */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2364]), SG_FALSE, 3, 0, 0, 22, 38),
    
    SG_STATIC_CODE_BUILDER( /* sint-list->bytevector */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2402]), SG_FALSE, 3, 0, 0, 22, 38),
    
    SG_STATIC_CODE_BUILDER( /* loop */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2440]), SG_FALSE, 1, 0, 2, 14, 33),
    
    SG_STATIC_CODE_BUILDER( /* collect-car */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2473]), SG_FALSE, 1, 0, 1, 9, 10),
    
    SG_STATIC_CODE_BUILDER( /* for-all */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2483]), SG_FALSE, 2, 1, 0, 83, 202),
    
    SG_STATIC_CODE_BUILDER( /* loop */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2685]), SG_FALSE, 1, 0, 2, 14, 33),
    
    SG_STATIC_CODE_BUILDER( /* collect-car */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2718]), SG_FALSE, 1, 0, 1, 9, 10),
    
    SG_STATIC_CODE_BUILDER( /* exists */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2728]), SG_FALSE, 2, 1, 0, 81, 198),
    
    SG_STATIC_CODE_BUILDER( /* filter */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2926]), SG_FALSE, 2, 0, 0, 18, 31),
    
    SG_STATIC_CODE_BUILDER( /* filter! */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[2957]), SG_FALSE, 2, 0, 0, 25, 77),
    
    SG_STATIC_CODE_BUILDER( /* partition */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3034]), SG_FALSE, 2, 0, 0, 22, 46),
    
    SG_STATIC_CODE_BUILDER( /* map */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3080]), SG_FALSE, 2, 1, 0, 40, 102),
    
    SG_STATIC_CODE_BUILDER( /* for-each */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3182]), SG_FALSE, 2, 1, 0, 32, 88),
    
    SG_STATIC_CODE_BUILDER( /* loop */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3270]), SG_FALSE, 2, 0, 4, 25, 52),
    
    SG_STATIC_CODE_BUILDER( /* loop */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3322]), SG_FALSE, 2, 0, 4, 31, 52),
    
    SG_STATIC_CODE_BUILDER( /* filter-map */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3374]), SG_FALSE, 2, 1, 0, 23, 68),
    
    SG_STATIC_CODE_BUILDER( /* fold-left */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3442]), SG_FALSE, 3, 1, 0, 31, 48),
    
    SG_STATIC_CODE_BUILDER( /* fold-right */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3490]), SG_FALSE, 3, 1, 0, 32, 64),
    
    SG_STATIC_CODE_BUILDER( /* remp */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3554]), SG_FALSE, 2, 0, 0, 18, 31),
    
    SG_STATIC_CODE_BUILDER( /* remove */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3585]), SG_FALSE, 2, 0, 0, 19, 32),
    
    SG_STATIC_CODE_BUILDER( /* remv */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3617]), SG_FALSE, 2, 0, 0, 18, 28),
    
    SG_STATIC_CODE_BUILDER( /* remq */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3645]), SG_FALSE, 2, 0, 0, 18, 28),
    
    SG_STATIC_CODE_BUILDER( /* memp */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3673]), SG_FALSE, 2, 0, 0, 12, 19),
    
    SG_STATIC_CODE_BUILDER( /* assp */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3692]), SG_FALSE, 2, 0, 0, 12, 21),
    
    SG_STATIC_CODE_BUILDER( /* recur */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3713]), SG_FALSE, 2, 0, 3, 69, 154),
    
    SG_STATIC_CODE_BUILDER( /* list-sort */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3867]), SG_FALSE, 2, 0, 0, 45, 119),
    
    SG_STATIC_CODE_BUILDER( /* vector-sort */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[3986]), SG_FALSE, 2, 1, 0, 43, 226),
    
    SG_STATIC_CODE_BUILDER( /* sort! */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4212]), SG_FALSE, 2, 0, 4, 57, 213),
    
    SG_STATIC_CODE_BUILDER( /* vector-sort! */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4425]), SG_FALSE, 2, 1, 0, 32, 176),
    
    SG_STATIC_CODE_BUILDER( /* call-with-port */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4601]), SG_FALSE, 2, 0, 0, 11, 16),
    
    SG_STATIC_CODE_BUILDER( /* proc */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4617]), SG_FALSE, 0, 0, 1, 7, 4),
    
    SG_STATIC_CODE_BUILDER( /* open-bytevector-output-port */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4621]), SG_FALSE, 0, 1, 0, 16, 55),
    
    SG_STATIC_CODE_BUILDER( /* proc */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4676]), SG_FALSE, 0, 0, 1, 7, 4),
    
    SG_STATIC_CODE_BUILDER( /* open-string-output-port */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4680]), SG_FALSE, 0, 0, 0, 11, 13),
    
    SG_STATIC_CODE_BUILDER( /* call-with-bytevector-output-port */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4693]), SG_FALSE, 1, 1, 0, 18, 15),
    
    SG_STATIC_CODE_BUILDER( /* call-with-string-output-port */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4708]), SG_FALSE, 1, 0, 0, 10, 13),
    
    SG_STATIC_CODE_BUILDER( /* hashtable-equivalence-function */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4721]), SG_FALSE, 1, 0, 0, 16, 72),
    
    SG_STATIC_CODE_BUILDER( /* hashtable-hash-function */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4793]), SG_FALSE, 1, 0, 0, 16, 70),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen17086.d17187[4863]), SG_FALSE, 0, 0, 0, 0, 396),
  },
};
static SgCodeBuilder *G17087 = 
   SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[104]));
void Sg__Init_core_base() {
  SgObject save = Sg_VM()->currentLibrary;

  sg__rc_cgen17086.d17186[0] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[2] = SG_MAKE_STRING("reverse!");
  sg__rc_cgen17086.d17186[1] = Sg_Intern(sg__rc_cgen17086.d17186[2]); /* reverse! */
  sg__rc_cgen17086.d17186[5] = SG_MAKE_STRING("(core base)");
  sg__rc_cgen17086.d17186[4] = Sg_Intern(sg__rc_cgen17086.d17186[5]); /* (core base) */
  sg__rc_cgen17086.d17186[3] = Sg_FindLibrary(SG_SYMBOL(sg__rc_cgen17086.d17186[4]), TRUE);
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[0],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[6] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[8] = SG_MAKE_STRING("list->vector");
  sg__rc_cgen17086.d17186[7] = Sg_Intern(sg__rc_cgen17086.d17186[8]); /* list->vector */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[6],SG_SYMBOL(sg__rc_cgen17086.d17186[7]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list->vector */
  sg__rc_cgen17086.d17186[10] = SG_MAKE_STRING("(vector-map vector-tabulate)");
  sg__rc_cgen17086.d17186[9] = Sg_Intern(sg__rc_cgen17086.d17186[10]); /* (vector-map vector-tabulate) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[0]))->name = sg__rc_cgen17086.d17186[9];/* (vector-map vector-tabulate) */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[0]))[11] = SG_WORD(sg__rc_cgen17086.d17186[0]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[0]))[14] = SG_WORD(sg__rc_cgen17086.d17186[6]);
  sg__rc_cgen17086.d17186[11] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[13] = SG_MAKE_STRING("lambda17185");
  sg__rc_cgen17086.d17186[12] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[13]), FALSE); /* lambda17185 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[11],SG_SYMBOL(sg__rc_cgen17086.d17186[12]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17185 */
  sg__rc_cgen17086.d17186[15] = SG_MAKE_STRING("(vector-map! vector-update!)");
  sg__rc_cgen17086.d17186[14] = Sg_Intern(sg__rc_cgen17086.d17186[15]); /* (vector-map! vector-update!) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[1]))->name = sg__rc_cgen17086.d17186[14];/* (vector-map! vector-update!) */
  sg__rc_cgen17086.d17186[16] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[18] = SG_MAKE_STRING("lambda17184");
  sg__rc_cgen17086.d17186[17] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[18]), FALSE); /* lambda17184 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[16],SG_SYMBOL(sg__rc_cgen17086.d17186[17]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17184 */
  sg__rc_cgen17086.d17186[19] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[21] = SG_MAKE_STRING("lambda17183");
  sg__rc_cgen17086.d17186[20] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[21]), FALSE); /* lambda17183 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[19],SG_SYMBOL(sg__rc_cgen17086.d17186[20]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17183 */
  sg__rc_cgen17086.d17186[23] = SG_MAKE_STRING("(take recur)");
  sg__rc_cgen17086.d17186[22] = Sg_Intern(sg__rc_cgen17086.d17186[23]); /* (take recur) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[2]))->name = sg__rc_cgen17086.d17186[22];/* (take recur) */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[53]))[14] = SG_WORD(sg__rc_cgen17086.d17186[19]);
  sg__rc_cgen17086.d17186[24] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[26] = SG_MAKE_STRING("lambda17182");
  sg__rc_cgen17086.d17186[25] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[26]), FALSE); /* lambda17182 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[24],SG_SYMBOL(sg__rc_cgen17086.d17186[25]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17182 */
  sg__rc_cgen17086.d17186[28] = SG_MAKE_STRING("(for-all loop)");
  sg__rc_cgen17086.d17186[27] = Sg_Intern(sg__rc_cgen17086.d17186[28]); /* (for-all loop) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[3]))->name = sg__rc_cgen17086.d17186[27];/* (for-all loop) */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[71]))[11] = SG_WORD(sg__rc_cgen17086.d17186[24]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[71]))[21] = SG_WORD(sg__rc_cgen17086.d17186[24]);
  sg__rc_cgen17086.d17186[30] = SG_MAKE_STRING("(for-all collect-cdr)");
  sg__rc_cgen17086.d17186[29] = Sg_Intern(sg__rc_cgen17086.d17186[30]); /* (for-all collect-cdr) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[4]))->name = sg__rc_cgen17086.d17186[29];/* (for-all collect-cdr) */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[96]))[2] = SG_WORD(sg__rc_cgen17086.d17186[24]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[96]))[6] = SG_WORD(sg__rc_cgen17086.d17186[24]);
  sg__rc_cgen17086.d17186[31] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[33] = SG_MAKE_STRING("lambda17181");
  sg__rc_cgen17086.d17186[32] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[33]), FALSE); /* lambda17181 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[31],SG_SYMBOL(sg__rc_cgen17086.d17186[32]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17181 */
  sg__rc_cgen17086.d17186[34] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[36] = SG_MAKE_STRING("lambda17180");
  sg__rc_cgen17086.d17186[35] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[36]), FALSE); /* lambda17180 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[34],SG_SYMBOL(sg__rc_cgen17086.d17186[35]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17180 */
  sg__rc_cgen17086.d17186[38] = SG_MAKE_STRING("(exists loop)");
  sg__rc_cgen17086.d17186[37] = Sg_Intern(sg__rc_cgen17086.d17186[38]); /* (exists loop) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[5]))->name = sg__rc_cgen17086.d17186[37];/* (exists loop) */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[105]))[11] = SG_WORD(sg__rc_cgen17086.d17186[34]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[105]))[21] = SG_WORD(sg__rc_cgen17086.d17186[34]);
  sg__rc_cgen17086.d17186[40] = SG_MAKE_STRING("(exists collect-cdr)");
  sg__rc_cgen17086.d17186[39] = Sg_Intern(sg__rc_cgen17086.d17186[40]); /* (exists collect-cdr) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[6]))->name = sg__rc_cgen17086.d17186[39];/* (exists collect-cdr) */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[130]))[2] = SG_WORD(sg__rc_cgen17086.d17186[34]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[130]))[6] = SG_WORD(sg__rc_cgen17086.d17186[34]);
  sg__rc_cgen17086.d17186[41] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[43] = SG_MAKE_STRING("lambda17179");
  sg__rc_cgen17086.d17186[42] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[43]), FALSE); /* lambda17179 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[41],SG_SYMBOL(sg__rc_cgen17086.d17186[42]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17179 */
  sg__rc_cgen17086.d17186[45] = SG_MAKE_STRING("(list-sort merge-list!)");
  sg__rc_cgen17086.d17186[44] = Sg_Intern(sg__rc_cgen17086.d17186[45]); /* (list-sort merge-list!) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[7]))->name = sg__rc_cgen17086.d17186[44];/* (list-sort merge-list!) */
  sg__rc_cgen17086.d17186[46] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[48] = SG_MAKE_STRING("lambda17178");
  sg__rc_cgen17086.d17186[47] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[48]), FALSE); /* lambda17178 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[46],SG_SYMBOL(sg__rc_cgen17086.d17186[47]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17178 */
  sg__rc_cgen17086.d17186[50] = SG_MAKE_STRING("(vector-sort vector-copy!)");
  sg__rc_cgen17086.d17186[49] = Sg_Intern(sg__rc_cgen17086.d17186[50]); /* (vector-sort vector-copy!) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[8]))->name = sg__rc_cgen17086.d17186[49];/* (vector-sort vector-copy!) */
  sg__rc_cgen17086.d17186[51] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[53] = SG_MAKE_STRING("lambda17177");
  sg__rc_cgen17086.d17186[52] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen17086.d17186[53]), FALSE); /* lambda17177 */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[51],SG_SYMBOL(sg__rc_cgen17086.d17186[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lambda17177 */
  sg__rc_cgen17086.d17186[54] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[56] = SG_MAKE_STRING("procedure?");
  sg__rc_cgen17086.d17186[55] = Sg_Intern(sg__rc_cgen17086.d17186[56]); /* procedure? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[54],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[58] = SG_MAKE_STRING("hashtable-for-each");
  sg__rc_cgen17086.d17186[57] = Sg_Intern(sg__rc_cgen17086.d17186[58]); /* hashtable-for-each */
  sg__rc_cgen17086.d17186[59] = SG_MAKE_STRING("procedure");
  sg__rc_cgen17086.d17186[60] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[62] = SG_MAKE_STRING("wrong-type-argument-message");
  sg__rc_cgen17086.d17186[61] = Sg_Intern(sg__rc_cgen17086.d17186[62]); /* wrong-type-argument-message */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[60],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[63] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[65] = SG_MAKE_STRING("assertion-violation");
  sg__rc_cgen17086.d17186[64] = Sg_Intern(sg__rc_cgen17086.d17186[65]); /* assertion-violation */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[63],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[66] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[68] = SG_MAKE_STRING("hashtable?");
  sg__rc_cgen17086.d17186[67] = Sg_Intern(sg__rc_cgen17086.d17186[68]); /* hashtable? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[66],SG_SYMBOL(sg__rc_cgen17086.d17186[67]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable? */
  sg__rc_cgen17086.d17186[69] = SG_MAKE_STRING("hashtable");
  sg__rc_cgen17086.d17186[70] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[70],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[71] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[71],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[72] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[74] = SG_MAKE_STRING("%hashtable-iter");
  sg__rc_cgen17086.d17186[73] = Sg_Intern(sg__rc_cgen17086.d17186[74]); /* %hashtable-iter */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[72],SG_SYMBOL(sg__rc_cgen17086.d17186[73]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* %hashtable-iter */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[9]))->name = sg__rc_cgen17086.d17186[57];/* hashtable-for-each */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[4] = SG_WORD(sg__rc_cgen17086.d17186[54]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[13] = SG_WORD(sg__rc_cgen17086.d17186[57]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[17] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[21] = SG_WORD(sg__rc_cgen17086.d17186[60]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[24] = SG_WORD(sg__rc_cgen17086.d17186[63]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[29] = SG_WORD(sg__rc_cgen17086.d17186[66]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[38] = SG_WORD(sg__rc_cgen17086.d17186[57]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[42] = SG_WORD(sg__rc_cgen17086.d17186[69]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[46] = SG_WORD(sg__rc_cgen17086.d17186[70]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[49] = SG_WORD(sg__rc_cgen17086.d17186[71]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[278]))[54] = SG_WORD(sg__rc_cgen17086.d17186[72]);
  sg__rc_cgen17086.d17186[75] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[75],SG_SYMBOL(sg__rc_cgen17086.d17186[57]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-for-each */
  sg__rc_cgen17086.d17186[76] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[76],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[78] = SG_MAKE_STRING("hashtable-map");
  sg__rc_cgen17086.d17186[77] = Sg_Intern(sg__rc_cgen17086.d17186[78]); /* hashtable-map */
  sg__rc_cgen17086.d17186[79] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[79],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[80] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[80],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[81] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[81],SG_SYMBOL(sg__rc_cgen17086.d17186[67]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable? */
  sg__rc_cgen17086.d17186[82] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[82],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[83] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[83],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[84] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[84],SG_SYMBOL(sg__rc_cgen17086.d17186[73]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* %hashtable-iter */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[10]))->name = sg__rc_cgen17086.d17186[77];/* hashtable-map */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[4] = SG_WORD(sg__rc_cgen17086.d17186[76]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[13] = SG_WORD(sg__rc_cgen17086.d17186[77]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[17] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[21] = SG_WORD(sg__rc_cgen17086.d17186[79]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[24] = SG_WORD(sg__rc_cgen17086.d17186[80]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[29] = SG_WORD(sg__rc_cgen17086.d17186[81]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[38] = SG_WORD(sg__rc_cgen17086.d17186[77]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[42] = SG_WORD(sg__rc_cgen17086.d17186[69]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[46] = SG_WORD(sg__rc_cgen17086.d17186[82]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[49] = SG_WORD(sg__rc_cgen17086.d17186[83]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[361]))[54] = SG_WORD(sg__rc_cgen17086.d17186[84]);
  sg__rc_cgen17086.d17186[85] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[85],SG_SYMBOL(sg__rc_cgen17086.d17186[77]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-map */
  sg__rc_cgen17086.d17186[86] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[86],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[88] = SG_MAKE_STRING("hashtable-fold");
  sg__rc_cgen17086.d17186[87] = Sg_Intern(sg__rc_cgen17086.d17186[88]); /* hashtable-fold */
  sg__rc_cgen17086.d17186[89] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[91] = SG_MAKE_STRING("proc");
  sg__rc_cgen17086.d17186[90] = Sg_Intern(sg__rc_cgen17086.d17186[91]); /* proc */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[89],SG_SYMBOL(sg__rc_cgen17086.d17186[90]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* proc */
  sg__rc_cgen17086.d17186[92] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[92],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[93] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[93],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[94] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[94],SG_SYMBOL(sg__rc_cgen17086.d17186[67]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable? */
  sg__rc_cgen17086.d17186[95] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[95],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[96] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[96],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[97] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[97],SG_SYMBOL(sg__rc_cgen17086.d17186[73]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* %hashtable-iter */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[11]))->name = sg__rc_cgen17086.d17186[87];/* hashtable-fold */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[4] = SG_WORD(sg__rc_cgen17086.d17186[86]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[13] = SG_WORD(sg__rc_cgen17086.d17186[87]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[17] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[19] = SG_WORD(sg__rc_cgen17086.d17186[89]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[22] = SG_WORD(sg__rc_cgen17086.d17186[92]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[25] = SG_WORD(sg__rc_cgen17086.d17186[93]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[30] = SG_WORD(sg__rc_cgen17086.d17186[94]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[39] = SG_WORD(sg__rc_cgen17086.d17186[87]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[43] = SG_WORD(sg__rc_cgen17086.d17186[69]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[47] = SG_WORD(sg__rc_cgen17086.d17186[95]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[50] = SG_WORD(sg__rc_cgen17086.d17186[96]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[449]))[55] = SG_WORD(sg__rc_cgen17086.d17186[97]);
  sg__rc_cgen17086.d17186[98] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[98],SG_SYMBOL(sg__rc_cgen17086.d17186[87]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-fold */
  sg__rc_cgen17086.d17186[99] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[101] = SG_MAKE_STRING("cons");
  sg__rc_cgen17086.d17186[100] = Sg_Intern(sg__rc_cgen17086.d17186[101]); /* cons */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[99],SG_SYMBOL(sg__rc_cgen17086.d17186[100]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* cons */
  sg__rc_cgen17086.d17186[102] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[102],SG_SYMBOL(sg__rc_cgen17086.d17186[77]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-map */
  sg__rc_cgen17086.d17186[104] = SG_MAKE_STRING("hashtable->alist");
  sg__rc_cgen17086.d17186[103] = Sg_Intern(sg__rc_cgen17086.d17186[104]); /* hashtable->alist */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[12]))->name = sg__rc_cgen17086.d17186[103];/* hashtable->alist */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[536]))[1] = SG_WORD(sg__rc_cgen17086.d17186[99]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[536]))[4] = SG_WORD(sg__rc_cgen17086.d17186[102]);
  sg__rc_cgen17086.d17186[105] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[105],SG_SYMBOL(sg__rc_cgen17086.d17186[103]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable->alist */
  sg__rc_cgen17086.d17186[106] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[108] = SG_MAKE_STRING("list?");
  sg__rc_cgen17086.d17186[107] = Sg_Intern(sg__rc_cgen17086.d17186[108]); /* list? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[106],SG_SYMBOL(sg__rc_cgen17086.d17186[107]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list? */
  sg__rc_cgen17086.d17186[109] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[111] = SG_MAKE_STRING("variable?");
  sg__rc_cgen17086.d17186[110] = Sg_Intern(sg__rc_cgen17086.d17186[111]); /* variable? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[109],SG_SYMBOL(sg__rc_cgen17086.d17186[110]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* variable? */
  sg__rc_cgen17086.d17186[112] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[114] = SG_MAKE_STRING("id-memq");
  sg__rc_cgen17086.d17186[113] = Sg_Intern(sg__rc_cgen17086.d17186[114]); /* id-memq */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[112],SG_SYMBOL(sg__rc_cgen17086.d17186[113]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* id-memq */
  sg__rc_cgen17086.d17186[116] = SG_MAKE_STRING("unique-id-list?");
  sg__rc_cgen17086.d17186[115] = Sg_Intern(sg__rc_cgen17086.d17186[116]); /* unique-id-list? */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[13]))->name = sg__rc_cgen17086.d17186[115];/* unique-id-list? */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[542]))[4] = SG_WORD(sg__rc_cgen17086.d17186[106]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[542]))[16] = SG_WORD(sg__rc_cgen17086.d17186[109]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[542]))[27] = SG_WORD(sg__rc_cgen17086.d17186[112]);
  sg__rc_cgen17086.d17186[117] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[117],SG_SYMBOL(sg__rc_cgen17086.d17186[115]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* unique-id-list? */
  sg__rc_cgen17086.d17186[119] = SG_MAKE_STRING("call-with-values");
  sg__rc_cgen17086.d17186[118] = Sg_Intern(sg__rc_cgen17086.d17186[119]); /* call-with-values */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[14]))->name = sg__rc_cgen17086.d17186[118];/* call-with-values */
  sg__rc_cgen17086.d17186[120] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[120],SG_SYMBOL(sg__rc_cgen17086.d17186[118]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* call-with-values */
  sg__rc_cgen17086.d17186[121] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[123] = SG_MAKE_STRING("display");
  sg__rc_cgen17086.d17186[122] = Sg_Intern(sg__rc_cgen17086.d17186[123]); /* display */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[121],SG_SYMBOL(sg__rc_cgen17086.d17186[122]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* display */
  sg__rc_cgen17086.d17186[124] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[126] = SG_MAKE_STRING("for-each");
  sg__rc_cgen17086.d17186[125] = Sg_Intern(sg__rc_cgen17086.d17186[126]); /* for-each */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[124],SG_SYMBOL(sg__rc_cgen17086.d17186[125]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* for-each */
  sg__rc_cgen17086.d17186[127] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[129] = SG_MAKE_STRING("newline");
  sg__rc_cgen17086.d17186[128] = Sg_Intern(sg__rc_cgen17086.d17186[129]); /* newline */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[127],SG_SYMBOL(sg__rc_cgen17086.d17186[128]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* newline */
  sg__rc_cgen17086.d17186[131] = SG_MAKE_STRING("print");
  sg__rc_cgen17086.d17186[130] = Sg_Intern(sg__rc_cgen17086.d17186[131]); /* print */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[15]))->name = sg__rc_cgen17086.d17186[130];/* print */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[590]))[3] = SG_WORD(sg__rc_cgen17086.d17186[121]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[590]))[6] = SG_WORD(sg__rc_cgen17086.d17186[124]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[590]))[8] = SG_WORD(sg__rc_cgen17086.d17186[127]);
  sg__rc_cgen17086.d17186[132] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[132],SG_SYMBOL(sg__rc_cgen17086.d17186[130]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* print */
  sg__rc_cgen17086.d17186[133] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[135] = SG_MAKE_STRING("list-transpose*");
  sg__rc_cgen17086.d17186[134] = Sg_Intern(sg__rc_cgen17086.d17186[135]); /* list-transpose* */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[133],SG_SYMBOL(sg__rc_cgen17086.d17186[134]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose* */
  sg__rc_cgen17086.d17186[137] = SG_MAKE_STRING("fold");
  sg__rc_cgen17086.d17186[136] = Sg_Intern(sg__rc_cgen17086.d17186[137]); /* fold */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[16]))->name = sg__rc_cgen17086.d17186[136];/* fold */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[600]))[25] = SG_WORD(sg__rc_cgen17086.d17186[133]);
  sg__rc_cgen17086.d17186[138] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[138],SG_SYMBOL(sg__rc_cgen17086.d17186[136]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* fold */
  sg__rc_cgen17086.d17186[139] = SG_MAKE_STRING("expected ~a, but got ~a");
  sg__rc_cgen17086.d17186[140] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[142] = SG_MAKE_STRING("format");
  sg__rc_cgen17086.d17186[141] = Sg_Intern(sg__rc_cgen17086.d17186[142]); /* format */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[140],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[143] = SG_MAKE_STRING("expected ~a, but got ~a, as argument ~a");
  sg__rc_cgen17086.d17186[144] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[144],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[17]))->name = sg__rc_cgen17086.d17186[61];/* wrong-type-argument-message */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[650]))[4] = SG_WORD(sg__rc_cgen17086.d17186[139]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[650]))[8] = SG_WORD(sg__rc_cgen17086.d17186[140]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[650]))[11] = SG_WORD(sg__rc_cgen17086.d17186[143]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[650]))[16] = SG_WORD(sg__rc_cgen17086.d17186[144]);
  sg__rc_cgen17086.d17186[145] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[145],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[146] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[148] = SG_MAKE_STRING("min");
  sg__rc_cgen17086.d17186[147] = Sg_Intern(sg__rc_cgen17086.d17186[148]); /* min */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[146],SG_SYMBOL(sg__rc_cgen17086.d17186[147]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* min */
  sg__rc_cgen17086.d17186[149] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[151] = SG_MAKE_STRING("vector-length");
  sg__rc_cgen17086.d17186[150] = Sg_Intern(sg__rc_cgen17086.d17186[151]); /* vector-length */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[149],SG_SYMBOL(sg__rc_cgen17086.d17186[150]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-length */
  sg__rc_cgen17086.d17186[152] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[154] = SG_MAKE_STRING("map");
  sg__rc_cgen17086.d17186[153] = Sg_Intern(sg__rc_cgen17086.d17186[154]); /* map */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[152],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  sg__rc_cgen17086.d17186[155] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[155],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[679]))[9] = SG_WORD(sg__rc_cgen17086.d17186[155]);
  sg__rc_cgen17086.d17186[157] = SG_MAKE_STRING("vector-map");
  sg__rc_cgen17086.d17186[156] = Sg_Intern(sg__rc_cgen17086.d17186[157]); /* vector-map */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[21]))->name = sg__rc_cgen17086.d17186[156];/* vector-map */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[691]))[2] = SG_WORD(sg__rc_cgen17086.d17186[11]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[691]))[16] = SG_WORD(sg__rc_cgen17086.d17186[11]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[691]))[25] = SG_WORD(sg__rc_cgen17086.d17186[146]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[691]))[29] = SG_WORD(sg__rc_cgen17086.d17186[149]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[691]))[32] = SG_WORD(sg__rc_cgen17086.d17186[152]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[691]))[41] = SG_WORD(sg__rc_cgen17086.d17186[11]);
  sg__rc_cgen17086.d17186[158] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[158],SG_SYMBOL(sg__rc_cgen17086.d17186[156]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-map */
  sg__rc_cgen17086.d17186[159] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[159],SG_SYMBOL(sg__rc_cgen17086.d17186[147]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* min */
  sg__rc_cgen17086.d17186[160] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[160],SG_SYMBOL(sg__rc_cgen17086.d17186[150]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-length */
  sg__rc_cgen17086.d17186[161] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[161],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  sg__rc_cgen17086.d17186[162] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[162],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[746]))[9] = SG_WORD(sg__rc_cgen17086.d17186[162]);
  sg__rc_cgen17086.d17186[164] = SG_MAKE_STRING("vector-map!");
  sg__rc_cgen17086.d17186[163] = Sg_Intern(sg__rc_cgen17086.d17186[164]); /* vector-map! */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[25]))->name = sg__rc_cgen17086.d17186[163];/* vector-map! */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[758]))[2] = SG_WORD(sg__rc_cgen17086.d17186[16]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[758]))[17] = SG_WORD(sg__rc_cgen17086.d17186[16]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[758]))[27] = SG_WORD(sg__rc_cgen17086.d17186[159]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[758]))[31] = SG_WORD(sg__rc_cgen17086.d17186[160]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[758]))[34] = SG_WORD(sg__rc_cgen17086.d17186[161]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[758]))[43] = SG_WORD(sg__rc_cgen17086.d17186[16]);
  sg__rc_cgen17086.d17186[165] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[165],SG_SYMBOL(sg__rc_cgen17086.d17186[163]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-map! */
  sg__rc_cgen17086.d17186[166] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[166],SG_SYMBOL(sg__rc_cgen17086.d17186[147]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* min */
  sg__rc_cgen17086.d17186[167] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[167],SG_SYMBOL(sg__rc_cgen17086.d17186[150]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-length */
  sg__rc_cgen17086.d17186[168] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[168],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  sg__rc_cgen17086.d17186[169] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[169],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  sg__rc_cgen17086.d17186[171] = SG_MAKE_STRING("vector-for-each");
  sg__rc_cgen17086.d17186[170] = Sg_Intern(sg__rc_cgen17086.d17186[171]); /* vector-for-each */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[27]))->name = sg__rc_cgen17086.d17186[170];/* vector-for-each */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[808]))[34] = SG_WORD(sg__rc_cgen17086.d17186[166]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[808]))[38] = SG_WORD(sg__rc_cgen17086.d17186[167]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[808]))[41] = SG_WORD(sg__rc_cgen17086.d17186[168]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[808]))[62] = SG_WORD(sg__rc_cgen17086.d17186[169]);
  sg__rc_cgen17086.d17186[172] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[172],SG_SYMBOL(sg__rc_cgen17086.d17186[170]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-for-each */
  sg__rc_cgen17086.d17186[173] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[175] = SG_MAKE_STRING("string-length");
  sg__rc_cgen17086.d17186[174] = Sg_Intern(sg__rc_cgen17086.d17186[175]); /* string-length */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[173],SG_SYMBOL(sg__rc_cgen17086.d17186[174]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-length */
  sg__rc_cgen17086.d17186[176] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[178] = SG_MAKE_STRING("string-ref");
  sg__rc_cgen17086.d17186[177] = Sg_Intern(sg__rc_cgen17086.d17186[178]); /* string-ref */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[176],SG_SYMBOL(sg__rc_cgen17086.d17186[177]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-ref */
  sg__rc_cgen17086.d17186[179] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[179],SG_SYMBOL(sg__rc_cgen17086.d17186[147]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* min */
  sg__rc_cgen17086.d17186[180] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[180],SG_SYMBOL(sg__rc_cgen17086.d17186[174]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-length */
  sg__rc_cgen17086.d17186[181] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[181],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  sg__rc_cgen17086.d17186[182] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[182],SG_SYMBOL(sg__rc_cgen17086.d17186[177]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-ref */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[879]))[3] = SG_WORD(sg__rc_cgen17086.d17186[182]);
  sg__rc_cgen17086.d17186[183] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[183],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  sg__rc_cgen17086.d17186[185] = SG_MAKE_STRING("string-for-each");
  sg__rc_cgen17086.d17186[184] = Sg_Intern(sg__rc_cgen17086.d17186[185]); /* string-for-each */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[29]))->name = sg__rc_cgen17086.d17186[184];/* string-for-each */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[884]))[7] = SG_WORD(sg__rc_cgen17086.d17186[173]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[884]))[23] = SG_WORD(sg__rc_cgen17086.d17186[176]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[884]))[40] = SG_WORD(sg__rc_cgen17086.d17186[179]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[884]))[44] = SG_WORD(sg__rc_cgen17086.d17186[180]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[884]))[47] = SG_WORD(sg__rc_cgen17086.d17186[181]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[884]))[68] = SG_WORD(sg__rc_cgen17086.d17186[183]);
  sg__rc_cgen17086.d17186[186] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[186],SG_SYMBOL(sg__rc_cgen17086.d17186[184]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-for-each */
  sg__rc_cgen17086.d17186[187] = SG_MAKE_STRING(" ");
  sg__rc_cgen17086.d17186[189] = SG_MAKE_STRING("infix");
  sg__rc_cgen17086.d17186[188] = Sg_Intern(sg__rc_cgen17086.d17186[189]); /* infix */
  sg__rc_cgen17086.d17186[191] = SG_MAKE_STRING("lambda");
  sg__rc_cgen17086.d17186[190] = Sg_Intern(sg__rc_cgen17086.d17186[191]); /* lambda */
  sg__rc_cgen17086.d17186[192] = SG_MAKE_STRING("too many argument for");
  sg__rc_cgen17086.d17186[196] = SG_MAKE_STRING("define");
  sg__rc_cgen17086.d17186[195] = Sg_Intern(sg__rc_cgen17086.d17186[196]); /* define */
  sg__rc_cgen17086.d17186[199] = SG_MAKE_STRING("buildit");
  sg__rc_cgen17086.d17186[198] = Sg_Intern(sg__rc_cgen17086.d17186[199]); /* buildit */
  sg__rc_cgen17086.d17186[201] = SG_MAKE_STRING("lis");
  sg__rc_cgen17086.d17186[200] = Sg_Intern(sg__rc_cgen17086.d17186[201]); /* lis */
  sg__rc_cgen17086.d17186[203] = SG_MAKE_STRING("final");
  sg__rc_cgen17086.d17186[202] = Sg_Intern(sg__rc_cgen17086.d17186[203]); /* final */
  do {
    /* (buildit lis final) */ 
    SgObject G17189 = SG_NIL, G17190 = SG_NIL;
    SG_APPEND1(G17189, G17190, sg__rc_cgen17086.d17186[198]); /* buildit */ 
    SG_APPEND1(G17189, G17190, sg__rc_cgen17086.d17186[200]); /* lis */ 
    SG_APPEND1(G17189, G17190, sg__rc_cgen17086.d17186[202]); /* final */ 
    sg__rc_cgen17086.d17186[197] = G17189;
  } while (0);
  sg__rc_cgen17086.d17186[206] = SG_MAKE_STRING("let");
  sg__rc_cgen17086.d17186[205] = Sg_Intern(sg__rc_cgen17086.d17186[206]); /* let */
  sg__rc_cgen17086.d17186[208] = SG_MAKE_STRING("recur");
  sg__rc_cgen17086.d17186[207] = Sg_Intern(sg__rc_cgen17086.d17186[208]); /* recur */
  do {
    /* (lis lis) */ 
    SgObject G17191 = SG_NIL, G17192 = SG_NIL;
    SG_APPEND1(G17191, G17192, sg__rc_cgen17086.d17186[200]); /* lis */ 
    SG_APPEND1(G17191, G17192, sg__rc_cgen17086.d17186[200]); /* lis */ 
    sg__rc_cgen17086.d17186[210] = G17191;
  } while (0);
  do {
    /* ((lis lis)) */ 
    SgObject G17193 = SG_NIL, G17194 = SG_NIL;
    SG_APPEND1(G17193, G17194, sg__rc_cgen17086.d17186[210]); /* (lis lis) */ 
    sg__rc_cgen17086.d17186[209] = G17193;
  } while (0);
  sg__rc_cgen17086.d17186[213] = SG_MAKE_STRING("if");
  sg__rc_cgen17086.d17186[212] = Sg_Intern(sg__rc_cgen17086.d17186[213]); /* if */
  sg__rc_cgen17086.d17186[216] = SG_MAKE_STRING("pair?");
  sg__rc_cgen17086.d17186[215] = Sg_Intern(sg__rc_cgen17086.d17186[216]); /* pair? */
  do {
    /* (pair? lis) */ 
    SgObject G17195 = SG_NIL, G17196 = SG_NIL;
    SG_APPEND1(G17195, G17196, sg__rc_cgen17086.d17186[215]); /* pair? */ 
    SG_APPEND1(G17195, G17196, sg__rc_cgen17086.d17186[200]); /* lis */ 
    sg__rc_cgen17086.d17186[214] = G17195;
  } while (0);
  sg__rc_cgen17086.d17186[219] = SG_MAKE_STRING("delim");
  sg__rc_cgen17086.d17186[218] = Sg_Intern(sg__rc_cgen17086.d17186[219]); /* delim */
  sg__rc_cgen17086.d17186[223] = SG_MAKE_STRING("car");
  sg__rc_cgen17086.d17186[222] = Sg_Intern(sg__rc_cgen17086.d17186[223]); /* car */
  do {
    /* (car lis) */ 
    SgObject G17197 = SG_NIL, G17198 = SG_NIL;
    SG_APPEND1(G17197, G17198, sg__rc_cgen17086.d17186[222]); /* car */ 
    SG_APPEND1(G17197, G17198, sg__rc_cgen17086.d17186[200]); /* lis */ 
    sg__rc_cgen17086.d17186[221] = G17197;
  } while (0);
  sg__rc_cgen17086.d17186[227] = SG_MAKE_STRING("cdr");
  sg__rc_cgen17086.d17186[226] = Sg_Intern(sg__rc_cgen17086.d17186[227]); /* cdr */
  do {
    /* (cdr lis) */ 
    SgObject G17199 = SG_NIL, G17200 = SG_NIL;
    SG_APPEND1(G17199, G17200, sg__rc_cgen17086.d17186[226]); /* cdr */ 
    SG_APPEND1(G17199, G17200, sg__rc_cgen17086.d17186[200]); /* lis */ 
    sg__rc_cgen17086.d17186[225] = G17199;
  } while (0);
  do {
    /* (recur (cdr lis)) */ 
    SgObject G17201 = SG_NIL, G17202 = SG_NIL;
    SG_APPEND1(G17201, G17202, sg__rc_cgen17086.d17186[207]); /* recur */ 
    SG_APPEND1(G17201, G17202, sg__rc_cgen17086.d17186[225]); /* (cdr lis) */ 
    sg__rc_cgen17086.d17186[224] = G17201;
  } while (0);
  do {
    /* (cons (car lis) (recur (cdr lis))) */ 
    SgObject G17203 = SG_NIL, G17204 = SG_NIL;
    SG_APPEND1(G17203, G17204, sg__rc_cgen17086.d17186[100]); /* cons */ 
    SG_APPEND1(G17203, G17204, sg__rc_cgen17086.d17186[221]); /* (car lis) */ 
    SG_APPEND1(G17203, G17204, sg__rc_cgen17086.d17186[224]); /* (recur (cdr lis)) */ 
    sg__rc_cgen17086.d17186[220] = G17203;
  } while (0);
  do {
    /* (cons delim (cons (car lis) (recur (cdr lis)))) */ 
    SgObject G17205 = SG_NIL, G17206 = SG_NIL;
    SG_APPEND1(G17205, G17206, sg__rc_cgen17086.d17186[100]); /* cons */ 
    SG_APPEND1(G17205, G17206, sg__rc_cgen17086.d17186[218]); /* delim */ 
    SG_APPEND1(G17205, G17206, sg__rc_cgen17086.d17186[220]); /* (cons (car lis) (recur (cdr lis))) */ 
    sg__rc_cgen17086.d17186[217] = G17205;
  } while (0);
  do {
    /* (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final) */ 
    SgObject G17207 = SG_NIL, G17208 = SG_NIL;
    SG_APPEND1(G17207, G17208, sg__rc_cgen17086.d17186[212]); /* if */ 
    SG_APPEND1(G17207, G17208, sg__rc_cgen17086.d17186[214]); /* (pair? lis) */ 
    SG_APPEND1(G17207, G17208, sg__rc_cgen17086.d17186[217]); /* (cons delim (cons (car lis) (recur (cdr lis)))) */ 
    SG_APPEND1(G17207, G17208, sg__rc_cgen17086.d17186[202]); /* final */ 
    sg__rc_cgen17086.d17186[211] = G17207;
  } while (0);
  do {
    /* (let recur ((lis lis)) (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final)) */ 
    SgObject G17209 = SG_NIL, G17210 = SG_NIL;
    SG_APPEND1(G17209, G17210, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17209, G17210, sg__rc_cgen17086.d17186[207]); /* recur */ 
    SG_APPEND1(G17209, G17210, sg__rc_cgen17086.d17186[209]); /* ((lis lis)) */ 
    SG_APPEND1(G17209, G17210, sg__rc_cgen17086.d17186[211]); /* (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final) */ 
    sg__rc_cgen17086.d17186[204] = G17209;
  } while (0);
  do {
    /* (define (buildit lis final) (let recur ((lis lis)) (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final))) */ 
    SgObject G17211 = SG_NIL, G17212 = SG_NIL;
    SG_APPEND1(G17211, G17212, sg__rc_cgen17086.d17186[195]); /* define */ 
    SG_APPEND1(G17211, G17212, sg__rc_cgen17086.d17186[197]); /* (buildit lis final) */ 
    SG_APPEND1(G17211, G17212, sg__rc_cgen17086.d17186[204]); /* (let recur ((lis lis)) (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final)) */ 
    sg__rc_cgen17086.d17186[194] = G17211;
  } while (0);
  sg__rc_cgen17086.d17186[230] = SG_MAKE_STRING("unless");
  sg__rc_cgen17086.d17186[229] = Sg_Intern(sg__rc_cgen17086.d17186[230]); /* unless */
  sg__rc_cgen17086.d17186[233] = SG_MAKE_STRING("string?");
  sg__rc_cgen17086.d17186[232] = Sg_Intern(sg__rc_cgen17086.d17186[233]); /* string? */
  do {
    /* (string? delim) */ 
    SgObject G17213 = SG_NIL, G17214 = SG_NIL;
    SG_APPEND1(G17213, G17214, sg__rc_cgen17086.d17186[232]); /* string? */ 
    SG_APPEND1(G17213, G17214, sg__rc_cgen17086.d17186[218]); /* delim */ 
    sg__rc_cgen17086.d17186[231] = G17213;
  } while (0);
  sg__rc_cgen17086.d17186[236] = SG_MAKE_STRING("error");
  sg__rc_cgen17086.d17186[235] = Sg_Intern(sg__rc_cgen17086.d17186[236]); /* error */
  sg__rc_cgen17086.d17186[239] = SG_MAKE_STRING("quote");
  sg__rc_cgen17086.d17186[238] = Sg_Intern(sg__rc_cgen17086.d17186[239]); /* quote */
  sg__rc_cgen17086.d17186[241] = SG_MAKE_STRING("string-join");
  sg__rc_cgen17086.d17186[240] = Sg_Intern(sg__rc_cgen17086.d17186[241]); /* string-join */
  do {
    /* 'string-join */ 
    SgObject G17215 = SG_NIL, G17216 = SG_NIL;
    SG_APPEND1(G17215, G17216, sg__rc_cgen17086.d17186[238]); /* quote */ 
    SG_APPEND1(G17215, G17216, sg__rc_cgen17086.d17186[240]); /* string-join */ 
    sg__rc_cgen17086.d17186[237] = G17215;
  } while (0);
  sg__rc_cgen17086.d17186[242] = SG_MAKE_STRING("Delimiter must be a string");
  do {
    /* (error 'string-join "Delimiter must be a string" delim) */ 
    SgObject G17217 = SG_NIL, G17218 = SG_NIL;
    SG_APPEND1(G17217, G17218, sg__rc_cgen17086.d17186[235]); /* error */ 
    SG_APPEND1(G17217, G17218, sg__rc_cgen17086.d17186[237]); /* 'string-join */ 
    SG_APPEND1(G17217, G17218, sg__rc_cgen17086.d17186[242]); /* "Delimiter must be a string" */ 
    SG_APPEND1(G17217, G17218, sg__rc_cgen17086.d17186[218]); /* delim */ 
    sg__rc_cgen17086.d17186[234] = G17217;
  } while (0);
  do {
    /* (unless (string? delim) (error 'string-join "Delimiter must be a string" delim)) */ 
    SgObject G17219 = SG_NIL, G17220 = SG_NIL;
    SG_APPEND1(G17219, G17220, sg__rc_cgen17086.d17186[229]); /* unless */ 
    SG_APPEND1(G17219, G17220, sg__rc_cgen17086.d17186[231]); /* (string? delim) */ 
    SG_APPEND1(G17219, G17220, sg__rc_cgen17086.d17186[234]); /* (error 'string-join "Delimiter must be a string" delim) */ 
    sg__rc_cgen17086.d17186[228] = G17219;
  } while (0);
  sg__rc_cgen17086.d17186[245] = SG_MAKE_STRING("cond");
  sg__rc_cgen17086.d17186[244] = Sg_Intern(sg__rc_cgen17086.d17186[245]); /* cond */
  sg__rc_cgen17086.d17186[249] = SG_MAKE_STRING("strings");
  sg__rc_cgen17086.d17186[248] = Sg_Intern(sg__rc_cgen17086.d17186[249]); /* strings */
  do {
    /* (pair? strings) */ 
    SgObject G17221 = SG_NIL, G17222 = SG_NIL;
    SG_APPEND1(G17221, G17222, sg__rc_cgen17086.d17186[215]); /* pair? */ 
    SG_APPEND1(G17221, G17222, sg__rc_cgen17086.d17186[248]); /* strings */ 
    sg__rc_cgen17086.d17186[247] = G17221;
  } while (0);
  sg__rc_cgen17086.d17186[252] = SG_MAKE_STRING("string-concatenate");
  sg__rc_cgen17086.d17186[251] = Sg_Intern(sg__rc_cgen17086.d17186[252]); /* string-concatenate */
  sg__rc_cgen17086.d17186[255] = SG_MAKE_STRING("case");
  sg__rc_cgen17086.d17186[254] = Sg_Intern(sg__rc_cgen17086.d17186[255]); /* case */
  sg__rc_cgen17086.d17186[257] = SG_MAKE_STRING("grammar");
  sg__rc_cgen17086.d17186[256] = Sg_Intern(sg__rc_cgen17086.d17186[257]); /* grammar */
  sg__rc_cgen17086.d17186[261] = SG_MAKE_STRING("strict-infix");
  sg__rc_cgen17086.d17186[260] = Sg_Intern(sg__rc_cgen17086.d17186[261]); /* strict-infix */
  do {
    /* (infix strict-infix) */ 
    SgObject G17223 = SG_NIL, G17224 = SG_NIL;
    SG_APPEND1(G17223, G17224, sg__rc_cgen17086.d17186[188]); /* infix */ 
    SG_APPEND1(G17223, G17224, sg__rc_cgen17086.d17186[260]); /* strict-infix */ 
    sg__rc_cgen17086.d17186[259] = G17223;
  } while (0);
  do {
    /* (car strings) */ 
    SgObject G17225 = SG_NIL, G17226 = SG_NIL;
    SG_APPEND1(G17225, G17226, sg__rc_cgen17086.d17186[222]); /* car */ 
    SG_APPEND1(G17225, G17226, sg__rc_cgen17086.d17186[248]); /* strings */ 
    sg__rc_cgen17086.d17186[263] = G17225;
  } while (0);
  do {
    /* (cdr strings) */ 
    SgObject G17227 = SG_NIL, G17228 = SG_NIL;
    SG_APPEND1(G17227, G17228, sg__rc_cgen17086.d17186[226]); /* cdr */ 
    SG_APPEND1(G17227, G17228, sg__rc_cgen17086.d17186[248]); /* strings */ 
    sg__rc_cgen17086.d17186[265] = G17227;
  } while (0);
  do {
    /* '() */ 
    SgObject G17229 = SG_NIL, G17230 = SG_NIL;
    SG_APPEND1(G17229, G17230, sg__rc_cgen17086.d17186[238]); /* quote */ 
    SG_APPEND1(G17229, G17230, SG_NIL); /* () */ 
    sg__rc_cgen17086.d17186[266] = G17229;
  } while (0);
  do {
    /* (buildit (cdr strings) '()) */ 
    SgObject G17231 = SG_NIL, G17232 = SG_NIL;
    SG_APPEND1(G17231, G17232, sg__rc_cgen17086.d17186[198]); /* buildit */ 
    SG_APPEND1(G17231, G17232, sg__rc_cgen17086.d17186[265]); /* (cdr strings) */ 
    SG_APPEND1(G17231, G17232, sg__rc_cgen17086.d17186[266]); /* '() */ 
    sg__rc_cgen17086.d17186[264] = G17231;
  } while (0);
  do {
    /* (cons (car strings) (buildit (cdr strings) '())) */ 
    SgObject G17233 = SG_NIL, G17234 = SG_NIL;
    SG_APPEND1(G17233, G17234, sg__rc_cgen17086.d17186[100]); /* cons */ 
    SG_APPEND1(G17233, G17234, sg__rc_cgen17086.d17186[263]); /* (car strings) */ 
    SG_APPEND1(G17233, G17234, sg__rc_cgen17086.d17186[264]); /* (buildit (cdr strings) '()) */ 
    sg__rc_cgen17086.d17186[262] = G17233;
  } while (0);
  do {
    /* ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) */ 
    SgObject G17235 = SG_NIL, G17236 = SG_NIL;
    SG_APPEND1(G17235, G17236, sg__rc_cgen17086.d17186[259]); /* (infix strict-infix) */ 
    SG_APPEND1(G17235, G17236, sg__rc_cgen17086.d17186[262]); /* (cons (car strings) (buildit (cdr strings) '())) */ 
    sg__rc_cgen17086.d17186[258] = G17235;
  } while (0);
  sg__rc_cgen17086.d17186[270] = SG_MAKE_STRING("prefix");
  sg__rc_cgen17086.d17186[269] = Sg_Intern(sg__rc_cgen17086.d17186[270]); /* prefix */
  do {
    /* (prefix) */ 
    SgObject G17237 = SG_NIL, G17238 = SG_NIL;
    SG_APPEND1(G17237, G17238, sg__rc_cgen17086.d17186[269]); /* prefix */ 
    sg__rc_cgen17086.d17186[268] = G17237;
  } while (0);
  do {
    /* (buildit strings '()) */ 
    SgObject G17239 = SG_NIL, G17240 = SG_NIL;
    SG_APPEND1(G17239, G17240, sg__rc_cgen17086.d17186[198]); /* buildit */ 
    SG_APPEND1(G17239, G17240, sg__rc_cgen17086.d17186[248]); /* strings */ 
    SG_APPEND1(G17239, G17240, sg__rc_cgen17086.d17186[266]); /* '() */ 
    sg__rc_cgen17086.d17186[271] = G17239;
  } while (0);
  do {
    /* ((prefix) (buildit strings '())) */ 
    SgObject G17241 = SG_NIL, G17242 = SG_NIL;
    SG_APPEND1(G17241, G17242, sg__rc_cgen17086.d17186[268]); /* (prefix) */ 
    SG_APPEND1(G17241, G17242, sg__rc_cgen17086.d17186[271]); /* (buildit strings '()) */ 
    sg__rc_cgen17086.d17186[267] = G17241;
  } while (0);
  sg__rc_cgen17086.d17186[275] = SG_MAKE_STRING("suffix");
  sg__rc_cgen17086.d17186[274] = Sg_Intern(sg__rc_cgen17086.d17186[275]); /* suffix */
  do {
    /* (suffix) */ 
    SgObject G17243 = SG_NIL, G17244 = SG_NIL;
    SG_APPEND1(G17243, G17244, sg__rc_cgen17086.d17186[274]); /* suffix */ 
    sg__rc_cgen17086.d17186[273] = G17243;
  } while (0);
  sg__rc_cgen17086.d17186[280] = SG_MAKE_STRING("list");
  sg__rc_cgen17086.d17186[279] = Sg_Intern(sg__rc_cgen17086.d17186[280]); /* list */
  do {
    /* (list delim) */ 
    SgObject G17245 = SG_NIL, G17246 = SG_NIL;
    SG_APPEND1(G17245, G17246, sg__rc_cgen17086.d17186[279]); /* list */ 
    SG_APPEND1(G17245, G17246, sg__rc_cgen17086.d17186[218]); /* delim */ 
    sg__rc_cgen17086.d17186[278] = G17245;
  } while (0);
  do {
    /* (buildit (cdr strings) (list delim)) */ 
    SgObject G17247 = SG_NIL, G17248 = SG_NIL;
    SG_APPEND1(G17247, G17248, sg__rc_cgen17086.d17186[198]); /* buildit */ 
    SG_APPEND1(G17247, G17248, sg__rc_cgen17086.d17186[265]); /* (cdr strings) */ 
    SG_APPEND1(G17247, G17248, sg__rc_cgen17086.d17186[278]); /* (list delim) */ 
    sg__rc_cgen17086.d17186[277] = G17247;
  } while (0);
  do {
    /* (cons (car strings) (buildit (cdr strings) (list delim))) */ 
    SgObject G17249 = SG_NIL, G17250 = SG_NIL;
    SG_APPEND1(G17249, G17250, sg__rc_cgen17086.d17186[100]); /* cons */ 
    SG_APPEND1(G17249, G17250, sg__rc_cgen17086.d17186[263]); /* (car strings) */ 
    SG_APPEND1(G17249, G17250, sg__rc_cgen17086.d17186[277]); /* (buildit (cdr strings) (list delim)) */ 
    sg__rc_cgen17086.d17186[276] = G17249;
  } while (0);
  do {
    /* ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) */ 
    SgObject G17251 = SG_NIL, G17252 = SG_NIL;
    SG_APPEND1(G17251, G17252, sg__rc_cgen17086.d17186[273]); /* (suffix) */ 
    SG_APPEND1(G17251, G17252, sg__rc_cgen17086.d17186[276]); /* (cons (car strings) (buildit (cdr strings) (list delim))) */ 
    sg__rc_cgen17086.d17186[272] = G17251;
  } while (0);
  sg__rc_cgen17086.d17186[283] = SG_MAKE_STRING("else");
  sg__rc_cgen17086.d17186[282] = Sg_Intern(sg__rc_cgen17086.d17186[283]); /* else */
  sg__rc_cgen17086.d17186[285] = SG_MAKE_STRING("Illegal join grammar");
  do {
    /* (error 'string-join "Illegal join grammar" grammar string-join) */ 
    SgObject G17253 = SG_NIL, G17254 = SG_NIL;
    SG_APPEND1(G17253, G17254, sg__rc_cgen17086.d17186[235]); /* error */ 
    SG_APPEND1(G17253, G17254, sg__rc_cgen17086.d17186[237]); /* 'string-join */ 
    SG_APPEND1(G17253, G17254, sg__rc_cgen17086.d17186[285]); /* "Illegal join grammar" */ 
    SG_APPEND1(G17253, G17254, sg__rc_cgen17086.d17186[256]); /* grammar */ 
    SG_APPEND1(G17253, G17254, sg__rc_cgen17086.d17186[240]); /* string-join */ 
    sg__rc_cgen17086.d17186[284] = G17253;
  } while (0);
  do {
    /* (else (error 'string-join "Illegal join grammar" grammar string-join)) */ 
    SgObject G17255 = SG_NIL, G17256 = SG_NIL;
    SG_APPEND1(G17255, G17256, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17255, G17256, sg__rc_cgen17086.d17186[284]); /* (error 'string-join "Illegal join grammar" grammar string-join) */ 
    sg__rc_cgen17086.d17186[281] = G17255;
  } while (0);
  do {
    /* (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join))) */ 
    SgObject G17257 = SG_NIL, G17258 = SG_NIL;
    SG_APPEND1(G17257, G17258, sg__rc_cgen17086.d17186[254]); /* case */ 
    SG_APPEND1(G17257, G17258, sg__rc_cgen17086.d17186[256]); /* grammar */ 
    SG_APPEND1(G17257, G17258, sg__rc_cgen17086.d17186[258]); /* ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) */ 
    SG_APPEND1(G17257, G17258, sg__rc_cgen17086.d17186[267]); /* ((prefix) (buildit strings '())) */ 
    SG_APPEND1(G17257, G17258, sg__rc_cgen17086.d17186[272]); /* ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) */ 
    SG_APPEND1(G17257, G17258, sg__rc_cgen17086.d17186[281]); /* (else (error 'string-join "Illegal join grammar" grammar string-join)) */ 
    sg__rc_cgen17086.d17186[253] = G17257;
  } while (0);
  do {
    /* (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join)))) */ 
    SgObject G17259 = SG_NIL, G17260 = SG_NIL;
    SG_APPEND1(G17259, G17260, sg__rc_cgen17086.d17186[251]); /* string-concatenate */ 
    SG_APPEND1(G17259, G17260, sg__rc_cgen17086.d17186[253]); /* (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join))) */ 
    sg__rc_cgen17086.d17186[250] = G17259;
  } while (0);
  do {
    /* ((pair? strings) (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join))))) */ 
    SgObject G17261 = SG_NIL, G17262 = SG_NIL;
    SG_APPEND1(G17261, G17262, sg__rc_cgen17086.d17186[247]); /* (pair? strings) */ 
    SG_APPEND1(G17261, G17262, sg__rc_cgen17086.d17186[250]); /* (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join)))) */ 
    sg__rc_cgen17086.d17186[246] = G17261;
  } while (0);
  sg__rc_cgen17086.d17186[289] = SG_MAKE_STRING("not");
  sg__rc_cgen17086.d17186[288] = Sg_Intern(sg__rc_cgen17086.d17186[289]); /* not */
  sg__rc_cgen17086.d17186[292] = SG_MAKE_STRING("null?");
  sg__rc_cgen17086.d17186[291] = Sg_Intern(sg__rc_cgen17086.d17186[292]); /* null? */
  do {
    /* (null? strings) */ 
    SgObject G17263 = SG_NIL, G17264 = SG_NIL;
    SG_APPEND1(G17263, G17264, sg__rc_cgen17086.d17186[291]); /* null? */ 
    SG_APPEND1(G17263, G17264, sg__rc_cgen17086.d17186[248]); /* strings */ 
    sg__rc_cgen17086.d17186[290] = G17263;
  } while (0);
  do {
    /* (not (null? strings)) */ 
    SgObject G17265 = SG_NIL, G17266 = SG_NIL;
    SG_APPEND1(G17265, G17266, sg__rc_cgen17086.d17186[288]); /* not */ 
    SG_APPEND1(G17265, G17266, sg__rc_cgen17086.d17186[290]); /* (null? strings) */ 
    sg__rc_cgen17086.d17186[287] = G17265;
  } while (0);
  sg__rc_cgen17086.d17186[294] = SG_MAKE_STRING("STRINGS parameter not list.");
  do {
    /* (error 'string-join "STRINGS parameter not list." strings string-join) */ 
    SgObject G17267 = SG_NIL, G17268 = SG_NIL;
    SG_APPEND1(G17267, G17268, sg__rc_cgen17086.d17186[235]); /* error */ 
    SG_APPEND1(G17267, G17268, sg__rc_cgen17086.d17186[237]); /* 'string-join */ 
    SG_APPEND1(G17267, G17268, sg__rc_cgen17086.d17186[294]); /* "STRINGS parameter not list." */ 
    SG_APPEND1(G17267, G17268, sg__rc_cgen17086.d17186[248]); /* strings */ 
    SG_APPEND1(G17267, G17268, sg__rc_cgen17086.d17186[240]); /* string-join */ 
    sg__rc_cgen17086.d17186[293] = G17267;
  } while (0);
  do {
    /* ((not (null? strings)) (error 'string-join "STRINGS parameter not list." strings string-join)) */ 
    SgObject G17269 = SG_NIL, G17270 = SG_NIL;
    SG_APPEND1(G17269, G17270, sg__rc_cgen17086.d17186[287]); /* (not (null? strings)) */ 
    SG_APPEND1(G17269, G17270, sg__rc_cgen17086.d17186[293]); /* (error 'string-join "STRINGS parameter not list." strings string-join) */ 
    sg__rc_cgen17086.d17186[286] = G17269;
  } while (0);
  sg__rc_cgen17086.d17186[298] = SG_MAKE_STRING("eq?");
  sg__rc_cgen17086.d17186[297] = Sg_Intern(sg__rc_cgen17086.d17186[298]); /* eq? */
  do {
    /* 'strict-infix */ 
    SgObject G17271 = SG_NIL, G17272 = SG_NIL;
    SG_APPEND1(G17271, G17272, sg__rc_cgen17086.d17186[238]); /* quote */ 
    SG_APPEND1(G17271, G17272, sg__rc_cgen17086.d17186[260]); /* strict-infix */ 
    sg__rc_cgen17086.d17186[299] = G17271;
  } while (0);
  do {
    /* (eq? grammar 'strict-infix) */ 
    SgObject G17273 = SG_NIL, G17274 = SG_NIL;
    SG_APPEND1(G17273, G17274, sg__rc_cgen17086.d17186[297]); /* eq? */ 
    SG_APPEND1(G17273, G17274, sg__rc_cgen17086.d17186[256]); /* grammar */ 
    SG_APPEND1(G17273, G17274, sg__rc_cgen17086.d17186[299]); /* 'strict-infix */ 
    sg__rc_cgen17086.d17186[296] = G17273;
  } while (0);
  sg__rc_cgen17086.d17186[301] = SG_MAKE_STRING("Empty list cannot be joined with STRICT-INFIX grammar.");
  do {
    /* (error 'string-join "Empty list cannot be joined with STRICT-INFIX grammar." string-join) */ 
    SgObject G17275 = SG_NIL, G17276 = SG_NIL;
    SG_APPEND1(G17275, G17276, sg__rc_cgen17086.d17186[235]); /* error */ 
    SG_APPEND1(G17275, G17276, sg__rc_cgen17086.d17186[237]); /* 'string-join */ 
    SG_APPEND1(G17275, G17276, sg__rc_cgen17086.d17186[301]); /* "Empty list cannot be joined with STRICT-INFIX grammar." */ 
    SG_APPEND1(G17275, G17276, sg__rc_cgen17086.d17186[240]); /* string-join */ 
    sg__rc_cgen17086.d17186[300] = G17275;
  } while (0);
  do {
    /* ((eq? grammar 'strict-infix) (error 'string-join "Empty list cannot be joined with STRICT-INFIX grammar." string-join)) */ 
    SgObject G17277 = SG_NIL, G17278 = SG_NIL;
    SG_APPEND1(G17277, G17278, sg__rc_cgen17086.d17186[296]); /* (eq? grammar 'strict-infix) */ 
    SG_APPEND1(G17277, G17278, sg__rc_cgen17086.d17186[300]); /* (error 'string-join "Empty list cannot be joined with STRICT-INFIX grammar." string-join) */ 
    sg__rc_cgen17086.d17186[295] = G17277;
  } while (0);
  sg__rc_cgen17086.d17186[303] = SG_MAKE_STRING("");
  do {
    /* (else "") */ 
    SgObject G17279 = SG_NIL, G17280 = SG_NIL;
    SG_APPEND1(G17279, G17280, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17279, G17280, sg__rc_cgen17086.d17186[303]); /* "" */ 
    sg__rc_cgen17086.d17186[302] = G17279;
  } while (0);
  do {
    /* (cond ((pair? strings) (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join))))) ((not (null? strings)) (error 'string-join "STRINGS parameter not list." strings string-join)) ((eq? grammar 'strict-infix) (error 'string-join "Empty list cannot be joined with STRICT-INFIX grammar." string-join)) (else "")) */ 
    SgObject G17281 = SG_NIL, G17282 = SG_NIL;
    SG_APPEND1(G17281, G17282, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17281, G17282, sg__rc_cgen17086.d17186[246]); /* ((pair? strings) (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join))))) */ 
    SG_APPEND1(G17281, G17282, sg__rc_cgen17086.d17186[286]); /* ((not (null? strings)) (error 'string-join "STRINGS parameter not list." strings string-join)) */ 
    SG_APPEND1(G17281, G17282, sg__rc_cgen17086.d17186[295]); /* ((eq? grammar 'strict-infix) (error 'string-join "Empty list cannot be joined with STRICT-INFIX grammar." string-join)) */ 
    SG_APPEND1(G17281, G17282, sg__rc_cgen17086.d17186[302]); /* (else "") */ 
    sg__rc_cgen17086.d17186[243] = G17281;
  } while (0);
  do {
    /* ((define (buildit lis final) (let recur ((lis lis)) (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final))) (unless (string? delim) (error 'string-join "Delimiter must be a string" delim)) (cond ((pair? strings) (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join))))) ((not (null? strings)) (error 'string-join "STRINGS parameter not list." strings string-join)) ((eq? grammar 'strict-infix) (error 'string-join "Empty list cannot be joined with STRICT-INFIX grammar." string-join)) (else ""))) */ 
    SgObject G17283 = SG_NIL, G17284 = SG_NIL;
    SG_APPEND1(G17283, G17284, sg__rc_cgen17086.d17186[194]); /* (define (buildit lis final) (let recur ((lis lis)) (if (pair? lis) (cons delim (cons (car lis) (recur (cdr lis)))) final))) */ 
    SG_APPEND1(G17283, G17284, sg__rc_cgen17086.d17186[228]); /* (unless (string? delim) (error 'string-join "Delimiter must be a string" delim)) */ 
    SG_APPEND1(G17283, G17284, sg__rc_cgen17086.d17186[243]); /* (cond ((pair? strings) (string-concatenate (case grammar ((infix strict-infix) (cons (car strings) (buildit (cdr strings) '()))) ((prefix) (buildit strings '())) ((suffix) (cons (car strings) (buildit (cdr strings) (list delim)))) (else (error 'string-join "Illegal join grammar" grammar string-join))))) ((not (null? strings)) (error 'string-join "STRINGS parameter not list." strings string-join)) ((eq? grammar 'strict-infix) (error 'string-join "Empty list cannot be joined with STRICT-INFIX grammar." string-join)) (else "")) */ 
    sg__rc_cgen17086.d17186[193] = G17283;
  } while (0);
  sg__rc_cgen17086.d17186[304] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[307] = SG_MAKE_STRING("(sagittarius compiler)");
  sg__rc_cgen17086.d17186[306] = Sg_Intern(sg__rc_cgen17086.d17186[307]); /* (sagittarius compiler) */
  sg__rc_cgen17086.d17186[305] = Sg_FindLibrary(SG_SYMBOL(sg__rc_cgen17086.d17186[306]), TRUE);
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[304],SG_SYMBOL(sg__rc_cgen17086.d17186[235]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[305]),FALSE); /* error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[30]))->name = sg__rc_cgen17086.d17186[207];/* recur */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[31]))->name = sg__rc_cgen17086.d17186[198];/* buildit */
  sg__rc_cgen17086.d17186[308] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[308],SG_SYMBOL(sg__rc_cgen17086.d17186[232]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string? */
  sg__rc_cgen17086.d17186[309] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[309],SG_SYMBOL(sg__rc_cgen17086.d17186[235]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* error */
  sg__rc_cgen17086.d17186[310] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[312] = SG_MAKE_STRING("memv");
  sg__rc_cgen17086.d17186[311] = Sg_Intern(sg__rc_cgen17086.d17186[312]); /* memv */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[310],SG_SYMBOL(sg__rc_cgen17086.d17186[311]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[305]),FALSE); /* memv */
  sg__rc_cgen17086.d17186[313] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[313],SG_SYMBOL(sg__rc_cgen17086.d17186[240]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-join */
  sg__rc_cgen17086.d17186[314] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[314],SG_SYMBOL(sg__rc_cgen17086.d17186[235]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* error */
  sg__rc_cgen17086.d17186[315] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[315],SG_SYMBOL(sg__rc_cgen17086.d17186[251]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-concatenate */
  sg__rc_cgen17086.d17186[316] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[316],SG_SYMBOL(sg__rc_cgen17086.d17186[240]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-join */
  sg__rc_cgen17086.d17186[317] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[317],SG_SYMBOL(sg__rc_cgen17086.d17186[235]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* error */
  sg__rc_cgen17086.d17186[318] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[318],SG_SYMBOL(sg__rc_cgen17086.d17186[240]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-join */
  sg__rc_cgen17086.d17186[319] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[319],SG_SYMBOL(sg__rc_cgen17086.d17186[235]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[32]))->name = sg__rc_cgen17086.d17186[240];/* string-join */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[4] = SG_WORD(sg__rc_cgen17086.d17186[187]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[22] = SG_WORD(sg__rc_cgen17086.d17186[188]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[45] = SG_WORD(sg__rc_cgen17086.d17186[190]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[47] = SG_WORD(sg__rc_cgen17086.d17186[192]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[49] = SG_WORD(sg__rc_cgen17086.d17186[193]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[51] = SG_WORD(sg__rc_cgen17086.d17186[304]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[61] = SG_WORD(sg__rc_cgen17086.d17186[308]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[70] = SG_WORD(sg__rc_cgen17086.d17186[240]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[72] = SG_WORD(sg__rc_cgen17086.d17186[242]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[75] = SG_WORD(sg__rc_cgen17086.d17186[309]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[84] = SG_WORD(sg__rc_cgen17086.d17186[259]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[86] = SG_WORD(sg__rc_cgen17086.d17186[310]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[102] = SG_WORD(sg__rc_cgen17086.d17186[269]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[116] = SG_WORD(sg__rc_cgen17086.d17186[274]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[134] = SG_WORD(sg__rc_cgen17086.d17186[240]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[136] = SG_WORD(sg__rc_cgen17086.d17186[285]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[139] = SG_WORD(sg__rc_cgen17086.d17186[313]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[141] = SG_WORD(sg__rc_cgen17086.d17186[314]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[144] = SG_WORD(sg__rc_cgen17086.d17186[315]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[151] = SG_WORD(sg__rc_cgen17086.d17186[260]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[155] = SG_WORD(sg__rc_cgen17086.d17186[240]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[157] = SG_WORD(sg__rc_cgen17086.d17186[301]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[159] = SG_WORD(sg__rc_cgen17086.d17186[316]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[161] = SG_WORD(sg__rc_cgen17086.d17186[317]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[164] = SG_WORD(sg__rc_cgen17086.d17186[303]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[166] = SG_WORD(sg__rc_cgen17086.d17186[240]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[168] = SG_WORD(sg__rc_cgen17086.d17186[294]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[171] = SG_WORD(sg__rc_cgen17086.d17186[318]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[988]))[173] = SG_WORD(sg__rc_cgen17086.d17186[319]);
  sg__rc_cgen17086.d17186[320] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[320],SG_SYMBOL(sg__rc_cgen17086.d17186[240]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-join */
  sg__rc_cgen17086.d17186[322] = SG_MAKE_STRING("null-list?");
  sg__rc_cgen17086.d17186[321] = Sg_Intern(sg__rc_cgen17086.d17186[322]); /* null-list? */
  sg__rc_cgen17086.d17186[323] = SG_MAKE_STRING("argument out of domain");
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[33]))->name = sg__rc_cgen17086.d17186[321];/* null-list? */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1163]))[12] = SG_WORD(sg__rc_cgen17086.d17186[321]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1163]))[14] = SG_WORD(sg__rc_cgen17086.d17186[323]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1163]))[17] = SG_WORD(sg__rc_cgen17086.d17186[83]);
  sg__rc_cgen17086.d17186[324] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[324],SG_SYMBOL(sg__rc_cgen17086.d17186[321]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* null-list? */
  sg__rc_cgen17086.d17186[325] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[327] = SG_MAKE_STRING("integer?");
  sg__rc_cgen17086.d17186[326] = Sg_Intern(sg__rc_cgen17086.d17186[327]); /* integer? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[325],SG_SYMBOL(sg__rc_cgen17086.d17186[326]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* integer? */
  sg__rc_cgen17086.d17186[329] = SG_MAKE_STRING("split-at");
  sg__rc_cgen17086.d17186[328] = Sg_Intern(sg__rc_cgen17086.d17186[329]); /* split-at */
  sg__rc_cgen17086.d17186[330] = SG_MAKE_STRING("integer");
  sg__rc_cgen17086.d17186[331] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[331],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[332] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[332],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[333] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[333],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[334] = SG_MAKE_STRING("given list it too short");
  sg__rc_cgen17086.d17186[335] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[335],SG_SYMBOL(sg__rc_cgen17086.d17186[235]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[34]))->name = sg__rc_cgen17086.d17186[328];/* split-at */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[4] = SG_WORD(sg__rc_cgen17086.d17186[325]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[12] = SG_WORD(sg__rc_cgen17086.d17186[328]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[16] = SG_WORD(sg__rc_cgen17086.d17186[330]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[20] = SG_WORD(sg__rc_cgen17086.d17186[331]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[23] = SG_WORD(sg__rc_cgen17086.d17186[332]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[36] = SG_WORD(sg__rc_cgen17086.d17186[333]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[45] = SG_WORD(sg__rc_cgen17086.d17186[328]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[47] = SG_WORD(sg__rc_cgen17086.d17186[334]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1182]))[49] = SG_WORD(sg__rc_cgen17086.d17186[335]);
  sg__rc_cgen17086.d17186[336] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[336],SG_SYMBOL(sg__rc_cgen17086.d17186[328]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* split-at */
  sg__rc_cgen17086.d17186[337] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[339] = SG_MAKE_STRING("find-tail");
  sg__rc_cgen17086.d17186[338] = Sg_Intern(sg__rc_cgen17086.d17186[339]); /* find-tail */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[337],SG_SYMBOL(sg__rc_cgen17086.d17186[338]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* find-tail */
  sg__rc_cgen17086.d17186[341] = SG_MAKE_STRING("find");
  sg__rc_cgen17086.d17186[340] = Sg_Intern(sg__rc_cgen17086.d17186[341]); /* find */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[35]))->name = sg__rc_cgen17086.d17186[340];/* find */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1244]))[5] = SG_WORD(sg__rc_cgen17086.d17186[337]);
  sg__rc_cgen17086.d17186[342] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[342],SG_SYMBOL(sg__rc_cgen17086.d17186[340]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* find */
  sg__rc_cgen17086.d17186[343] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[343],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[344] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[344],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[345] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[345],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[36]))->name = sg__rc_cgen17086.d17186[338];/* find-tail */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1256]))[4] = SG_WORD(sg__rc_cgen17086.d17186[343]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1256]))[12] = SG_WORD(sg__rc_cgen17086.d17186[338]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1256]))[16] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1256]))[20] = SG_WORD(sg__rc_cgen17086.d17186[344]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1256]))[23] = SG_WORD(sg__rc_cgen17086.d17186[345]);
  sg__rc_cgen17086.d17186[346] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[346],SG_SYMBOL(sg__rc_cgen17086.d17186[338]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* find-tail */
  sg__rc_cgen17086.d17186[347] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[347],SG_SYMBOL(sg__rc_cgen17086.d17186[107]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list? */
  sg__rc_cgen17086.d17186[349] = SG_MAKE_STRING("assoc");
  sg__rc_cgen17086.d17186[348] = Sg_Intern(sg__rc_cgen17086.d17186[349]); /* assoc */
  sg__rc_cgen17086.d17186[350] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[350],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[351] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[351],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[352] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[354] = SG_MAKE_STRING("equal?");
  sg__rc_cgen17086.d17186[353] = Sg_Intern(sg__rc_cgen17086.d17186[354]); /* equal? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[352],SG_SYMBOL(sg__rc_cgen17086.d17186[353]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* equal? */
  sg__rc_cgen17086.d17186[355] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[355],SG_SYMBOL(sg__rc_cgen17086.d17186[348]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assoc */
  sg__rc_cgen17086.d17186[356] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[356],SG_SYMBOL(sg__rc_cgen17086.d17186[340]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* find */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[38]))->name = sg__rc_cgen17086.d17186[348];/* assoc */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[4] = SG_WORD(sg__rc_cgen17086.d17186[347]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[12] = SG_WORD(sg__rc_cgen17086.d17186[348]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[16] = SG_WORD(sg__rc_cgen17086.d17186[280]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[20] = SG_WORD(sg__rc_cgen17086.d17186[350]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[23] = SG_WORD(sg__rc_cgen17086.d17186[351]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[30] = SG_WORD(sg__rc_cgen17086.d17186[352]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[32] = SG_WORD(sg__rc_cgen17086.d17186[355]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1305]))[41] = SG_WORD(sg__rc_cgen17086.d17186[356]);
  sg__rc_cgen17086.d17186[357] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[357],SG_SYMBOL(sg__rc_cgen17086.d17186[348]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assoc */
  sg__rc_cgen17086.d17186[358] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[358],SG_SYMBOL(sg__rc_cgen17086.d17186[353]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* equal? */
  sg__rc_cgen17086.d17186[359] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[361] = SG_MAKE_STRING("member");
  sg__rc_cgen17086.d17186[360] = Sg_Intern(sg__rc_cgen17086.d17186[361]); /* member */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[359],SG_SYMBOL(sg__rc_cgen17086.d17186[360]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* member */
  sg__rc_cgen17086.d17186[362] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[362],SG_SYMBOL(sg__rc_cgen17086.d17186[338]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* find-tail */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[40]))->name = sg__rc_cgen17086.d17186[360];/* member */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1353]))[6] = SG_WORD(sg__rc_cgen17086.d17186[358]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1353]))[8] = SG_WORD(sg__rc_cgen17086.d17186[359]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1353]))[17] = SG_WORD(sg__rc_cgen17086.d17186[362]);
  sg__rc_cgen17086.d17186[363] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[363],SG_SYMBOL(sg__rc_cgen17086.d17186[360]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* member */
  sg__rc_cgen17086.d17186[364] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[364],SG_SYMBOL(sg__rc_cgen17086.d17186[353]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* equal? */
  sg__rc_cgen17086.d17186[365] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[367] = SG_MAKE_STRING("delete");
  sg__rc_cgen17086.d17186[366] = Sg_Intern(sg__rc_cgen17086.d17186[367]); /* delete */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[365],SG_SYMBOL(sg__rc_cgen17086.d17186[366]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* delete */
  sg__rc_cgen17086.d17186[368] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[370] = SG_MAKE_STRING("filter");
  sg__rc_cgen17086.d17186[369] = Sg_Intern(sg__rc_cgen17086.d17186[370]); /* filter */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[368],SG_SYMBOL(sg__rc_cgen17086.d17186[369]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[42]))->name = sg__rc_cgen17086.d17186[366];/* delete */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1380]))[6] = SG_WORD(sg__rc_cgen17086.d17186[364]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1380]))[8] = SG_WORD(sg__rc_cgen17086.d17186[365]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1380]))[17] = SG_WORD(sg__rc_cgen17086.d17186[368]);
  sg__rc_cgen17086.d17186[371] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[371],SG_SYMBOL(sg__rc_cgen17086.d17186[366]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* delete */
  sg__rc_cgen17086.d17186[372] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[372],SG_SYMBOL(sg__rc_cgen17086.d17186[353]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* equal? */
  sg__rc_cgen17086.d17186[373] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[373],SG_SYMBOL(sg__rc_cgen17086.d17186[366]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* delete */
  sg__rc_cgen17086.d17186[374] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[376] = SG_MAKE_STRING("filter!");
  sg__rc_cgen17086.d17186[375] = Sg_Intern(sg__rc_cgen17086.d17186[376]); /* filter! */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[374],SG_SYMBOL(sg__rc_cgen17086.d17186[375]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter! */
  sg__rc_cgen17086.d17186[378] = SG_MAKE_STRING("delete!");
  sg__rc_cgen17086.d17186[377] = Sg_Intern(sg__rc_cgen17086.d17186[378]); /* delete! */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[44]))->name = sg__rc_cgen17086.d17186[377];/* delete! */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1407]))[6] = SG_WORD(sg__rc_cgen17086.d17186[372]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1407]))[8] = SG_WORD(sg__rc_cgen17086.d17186[373]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1407]))[17] = SG_WORD(sg__rc_cgen17086.d17186[374]);
  sg__rc_cgen17086.d17186[379] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[379],SG_SYMBOL(sg__rc_cgen17086.d17186[377]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* delete! */
  sg__rc_cgen17086.d17186[380] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[380],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[382] = SG_MAKE_STRING("reduce");
  sg__rc_cgen17086.d17186[381] = Sg_Intern(sg__rc_cgen17086.d17186[382]); /* reduce */
  sg__rc_cgen17086.d17186[383] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[385] = SG_MAKE_STRING("=");
  sg__rc_cgen17086.d17186[384] = Sg_Intern(sg__rc_cgen17086.d17186[385]); /* = */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[383],SG_SYMBOL(sg__rc_cgen17086.d17186[384]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* = */
  sg__rc_cgen17086.d17186[386] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[386],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[387] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[387],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[388] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[388],SG_SYMBOL(sg__rc_cgen17086.d17186[136]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* fold */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[45]))->name = sg__rc_cgen17086.d17186[381];/* reduce */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1426]))[4] = SG_WORD(sg__rc_cgen17086.d17186[380]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1426]))[12] = SG_WORD(sg__rc_cgen17086.d17186[381]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1426]))[16] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1426]))[18] = SG_WORD(sg__rc_cgen17086.d17186[383]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1426]))[21] = SG_WORD(sg__rc_cgen17086.d17186[386]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1426]))[24] = SG_WORD(sg__rc_cgen17086.d17186[387]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1426]))[34] = SG_WORD(sg__rc_cgen17086.d17186[388]);
  sg__rc_cgen17086.d17186[389] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[389],SG_SYMBOL(sg__rc_cgen17086.d17186[381]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reduce */
  sg__rc_cgen17086.d17186[390] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[390],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[392] = SG_MAKE_STRING("lset-union");
  sg__rc_cgen17086.d17186[391] = Sg_Intern(sg__rc_cgen17086.d17186[392]); /* lset-union */
  sg__rc_cgen17086.d17186[393] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[393],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[394] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[394],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[395] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[397] = SG_MAKE_STRING("exists");
  sg__rc_cgen17086.d17186[396] = Sg_Intern(sg__rc_cgen17086.d17186[397]); /* exists */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[395],SG_SYMBOL(sg__rc_cgen17086.d17186[396]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* exists */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1467]))[9] = SG_WORD(sg__rc_cgen17086.d17186[395]);
  sg__rc_cgen17086.d17186[398] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[398],SG_SYMBOL(sg__rc_cgen17086.d17186[136]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* fold */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1485]))[23] = SG_WORD(sg__rc_cgen17086.d17186[398]);
  sg__rc_cgen17086.d17186[399] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[399],SG_SYMBOL(sg__rc_cgen17086.d17186[381]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reduce */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[49]))->name = sg__rc_cgen17086.d17186[391];/* lset-union */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1510]))[4] = SG_WORD(sg__rc_cgen17086.d17186[390]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1510]))[12] = SG_WORD(sg__rc_cgen17086.d17186[391]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1510]))[16] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1510]))[20] = SG_WORD(sg__rc_cgen17086.d17186[393]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1510]))[23] = SG_WORD(sg__rc_cgen17086.d17186[394]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1510]))[32] = SG_WORD(sg__rc_cgen17086.d17186[399]);
  sg__rc_cgen17086.d17186[400] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[400],SG_SYMBOL(sg__rc_cgen17086.d17186[391]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lset-union */
  sg__rc_cgen17086.d17186[401] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[401],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[403] = SG_MAKE_STRING("lset-intersection");
  sg__rc_cgen17086.d17186[402] = Sg_Intern(sg__rc_cgen17086.d17186[403]); /* lset-intersection */
  sg__rc_cgen17086.d17186[404] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[404],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[405] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[405],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[406] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[406],SG_SYMBOL(sg__rc_cgen17086.d17186[297]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* eq? */
  sg__rc_cgen17086.d17186[407] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[407],SG_SYMBOL(sg__rc_cgen17086.d17186[366]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* delete */
  sg__rc_cgen17086.d17186[408] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[408],SG_SYMBOL(sg__rc_cgen17086.d17186[291]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* null? */
  sg__rc_cgen17086.d17186[409] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[409],SG_SYMBOL(sg__rc_cgen17086.d17186[396]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* exists */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1544]))[4] = SG_WORD(sg__rc_cgen17086.d17186[363]);
  sg__rc_cgen17086.d17186[410] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[412] = SG_MAKE_STRING("for-all");
  sg__rc_cgen17086.d17186[411] = Sg_Intern(sg__rc_cgen17086.d17186[412]); /* for-all */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[410],SG_SYMBOL(sg__rc_cgen17086.d17186[411]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* for-all */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1550]))[7] = SG_WORD(sg__rc_cgen17086.d17186[410]);
  sg__rc_cgen17086.d17186[413] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[413],SG_SYMBOL(sg__rc_cgen17086.d17186[369]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[52]))->name = sg__rc_cgen17086.d17186[402];/* lset-intersection */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[4] = SG_WORD(sg__rc_cgen17086.d17186[401]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[12] = SG_WORD(sg__rc_cgen17086.d17186[402]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[16] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[20] = SG_WORD(sg__rc_cgen17086.d17186[404]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[23] = SG_WORD(sg__rc_cgen17086.d17186[405]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[29] = SG_WORD(sg__rc_cgen17086.d17186[406]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[31] = SG_WORD(sg__rc_cgen17086.d17186[407]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[36] = SG_WORD(sg__rc_cgen17086.d17186[408]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[39] = SG_WORD(sg__rc_cgen17086.d17186[409]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1559]))[56] = SG_WORD(sg__rc_cgen17086.d17186[413]);
  sg__rc_cgen17086.d17186[414] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[414],SG_SYMBOL(sg__rc_cgen17086.d17186[402]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lset-intersection */
  sg__rc_cgen17086.d17186[415] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[415],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[417] = SG_MAKE_STRING("lset-difference");
  sg__rc_cgen17086.d17186[416] = Sg_Intern(sg__rc_cgen17086.d17186[417]); /* lset-difference */
  sg__rc_cgen17086.d17186[418] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[418],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[419] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[419],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[420] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[420],SG_SYMBOL(sg__rc_cgen17086.d17186[215]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* pair? */
  sg__rc_cgen17086.d17186[421] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[421],SG_SYMBOL(sg__rc_cgen17086.d17186[369]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter */
  sg__rc_cgen17086.d17186[422] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[424] = SG_MAKE_STRING("memq");
  sg__rc_cgen17086.d17186[423] = Sg_Intern(sg__rc_cgen17086.d17186[424]); /* memq */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[422],SG_SYMBOL(sg__rc_cgen17086.d17186[423]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* memq */
  sg__rc_cgen17086.d17186[425] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[425],SG_SYMBOL(sg__rc_cgen17086.d17186[360]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* member */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1617]))[6] = SG_WORD(sg__rc_cgen17086.d17186[425]);
  sg__rc_cgen17086.d17186[426] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[426],SG_SYMBOL(sg__rc_cgen17086.d17186[411]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* for-all */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1626]))[7] = SG_WORD(sg__rc_cgen17086.d17186[426]);
  sg__rc_cgen17086.d17186[427] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[427],SG_SYMBOL(sg__rc_cgen17086.d17186[369]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[55]))->name = sg__rc_cgen17086.d17186[416];/* lset-difference */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[4] = SG_WORD(sg__rc_cgen17086.d17186[415]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[12] = SG_WORD(sg__rc_cgen17086.d17186[416]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[16] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[20] = SG_WORD(sg__rc_cgen17086.d17186[418]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[23] = SG_WORD(sg__rc_cgen17086.d17186[419]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[27] = SG_WORD(sg__rc_cgen17086.d17186[420]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[30] = SG_WORD(sg__rc_cgen17086.d17186[421]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[42] = SG_WORD(sg__rc_cgen17086.d17186[422]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1635]))[54] = SG_WORD(sg__rc_cgen17086.d17186[427]);
  sg__rc_cgen17086.d17186[428] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[428],SG_SYMBOL(sg__rc_cgen17086.d17186[416]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* lset-difference */
  sg__rc_cgen17086.d17186[429] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[429],SG_SYMBOL(sg__rc_cgen17086.d17186[326]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* integer? */
  sg__rc_cgen17086.d17186[431] = SG_MAKE_STRING("take");
  sg__rc_cgen17086.d17186[430] = Sg_Intern(sg__rc_cgen17086.d17186[431]); /* take */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[56]))->name = sg__rc_cgen17086.d17186[430];/* take */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1691]))[4] = SG_WORD(sg__rc_cgen17086.d17186[429]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1691]))[12] = SG_WORD(sg__rc_cgen17086.d17186[430]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1691]))[16] = SG_WORD(sg__rc_cgen17086.d17186[330]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1691]))[20] = SG_WORD(sg__rc_cgen17086.d17186[350]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1691]))[23] = SG_WORD(sg__rc_cgen17086.d17186[351]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1691]))[26] = SG_WORD(sg__rc_cgen17086.d17186[19]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1691]))[31] = SG_WORD(sg__rc_cgen17086.d17186[19]);
  sg__rc_cgen17086.d17186[432] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[432],SG_SYMBOL(sg__rc_cgen17086.d17186[430]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* take */
  sg__rc_cgen17086.d17186[433] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[433],SG_SYMBOL(sg__rc_cgen17086.d17186[326]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* integer? */
  sg__rc_cgen17086.d17186[435] = SG_MAKE_STRING("drop");
  sg__rc_cgen17086.d17186[434] = Sg_Intern(sg__rc_cgen17086.d17186[435]); /* drop */
  sg__rc_cgen17086.d17186[436] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[436],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[437] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[437],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[57]))->name = sg__rc_cgen17086.d17186[434];/* drop */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1725]))[4] = SG_WORD(sg__rc_cgen17086.d17186[433]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1725]))[12] = SG_WORD(sg__rc_cgen17086.d17186[434]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1725]))[16] = SG_WORD(sg__rc_cgen17086.d17186[330]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1725]))[20] = SG_WORD(sg__rc_cgen17086.d17186[436]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1725]))[23] = SG_WORD(sg__rc_cgen17086.d17186[437]);
  sg__rc_cgen17086.d17186[438] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[438],SG_SYMBOL(sg__rc_cgen17086.d17186[434]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* drop */
  sg__rc_cgen17086.d17186[439] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[439],SG_SYMBOL(sg__rc_cgen17086.d17186[430]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* take */
  sg__rc_cgen17086.d17186[440] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[442] = SG_MAKE_STRING("list-head");
  sg__rc_cgen17086.d17186[441] = Sg_Intern(sg__rc_cgen17086.d17186[442]); /* list-head */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[440],SG_SYMBOL(sg__rc_cgen17086.d17186[441]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-head */
  sg__rc_cgen17086.d17186[444] = SG_MAKE_STRING("make-ci-comparison");
  sg__rc_cgen17086.d17186[443] = Sg_Intern(sg__rc_cgen17086.d17186[444]); /* make-ci-comparison */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[58]))->name = sg__rc_cgen17086.d17186[443];/* make-ci-comparison */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[59]))->name = sg__rc_cgen17086.d17186[443];/* make-ci-comparison */
  sg__rc_cgen17086.d17186[445] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[445],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[446] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[448] = SG_MAKE_STRING("char=?");
  sg__rc_cgen17086.d17186[447] = Sg_Intern(sg__rc_cgen17086.d17186[448]); /* char=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[446],SG_SYMBOL(sg__rc_cgen17086.d17186[447]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char=? */
  sg__rc_cgen17086.d17186[449] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[451] = SG_MAKE_STRING("char-foldcase");
  sg__rc_cgen17086.d17186[450] = Sg_Intern(sg__rc_cgen17086.d17186[451]); /* char-foldcase */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[449],SG_SYMBOL(sg__rc_cgen17086.d17186[450]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-foldcase */
  sg__rc_cgen17086.d17186[452] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[452],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[453] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[455] = SG_MAKE_STRING("char-ci=?");
  sg__rc_cgen17086.d17186[454] = Sg_Intern(sg__rc_cgen17086.d17186[455]); /* char-ci=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[453],SG_SYMBOL(sg__rc_cgen17086.d17186[454]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-ci=? */
  sg__rc_cgen17086.d17186[456] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[458] = SG_MAKE_STRING("char<?");
  sg__rc_cgen17086.d17186[457] = Sg_Intern(sg__rc_cgen17086.d17186[458]); /* char<? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[456],SG_SYMBOL(sg__rc_cgen17086.d17186[457]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char<? */
  sg__rc_cgen17086.d17186[459] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[459],SG_SYMBOL(sg__rc_cgen17086.d17186[450]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-foldcase */
  sg__rc_cgen17086.d17186[460] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[460],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[461] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[463] = SG_MAKE_STRING("char-ci<?");
  sg__rc_cgen17086.d17186[462] = Sg_Intern(sg__rc_cgen17086.d17186[463]); /* char-ci<? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[461],SG_SYMBOL(sg__rc_cgen17086.d17186[462]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-ci<? */
  sg__rc_cgen17086.d17186[464] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[466] = SG_MAKE_STRING("char>?");
  sg__rc_cgen17086.d17186[465] = Sg_Intern(sg__rc_cgen17086.d17186[466]); /* char>? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[464],SG_SYMBOL(sg__rc_cgen17086.d17186[465]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char>? */
  sg__rc_cgen17086.d17186[467] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[467],SG_SYMBOL(sg__rc_cgen17086.d17186[450]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-foldcase */
  sg__rc_cgen17086.d17186[468] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[468],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[469] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[471] = SG_MAKE_STRING("char-ci>?");
  sg__rc_cgen17086.d17186[470] = Sg_Intern(sg__rc_cgen17086.d17186[471]); /* char-ci>? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[469],SG_SYMBOL(sg__rc_cgen17086.d17186[470]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-ci>? */
  sg__rc_cgen17086.d17186[472] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[474] = SG_MAKE_STRING("char<=?");
  sg__rc_cgen17086.d17186[473] = Sg_Intern(sg__rc_cgen17086.d17186[474]); /* char<=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[472],SG_SYMBOL(sg__rc_cgen17086.d17186[473]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char<=? */
  sg__rc_cgen17086.d17186[475] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[475],SG_SYMBOL(sg__rc_cgen17086.d17186[450]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-foldcase */
  sg__rc_cgen17086.d17186[476] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[476],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[477] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[479] = SG_MAKE_STRING("char-ci<=?");
  sg__rc_cgen17086.d17186[478] = Sg_Intern(sg__rc_cgen17086.d17186[479]); /* char-ci<=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[477],SG_SYMBOL(sg__rc_cgen17086.d17186[478]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-ci<=? */
  sg__rc_cgen17086.d17186[480] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[482] = SG_MAKE_STRING("char>=?");
  sg__rc_cgen17086.d17186[481] = Sg_Intern(sg__rc_cgen17086.d17186[482]); /* char>=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[480],SG_SYMBOL(sg__rc_cgen17086.d17186[481]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char>=? */
  sg__rc_cgen17086.d17186[483] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[483],SG_SYMBOL(sg__rc_cgen17086.d17186[450]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-foldcase */
  sg__rc_cgen17086.d17186[484] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[484],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[485] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[487] = SG_MAKE_STRING("char-ci>=?");
  sg__rc_cgen17086.d17186[486] = Sg_Intern(sg__rc_cgen17086.d17186[487]); /* char-ci>=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[485],SG_SYMBOL(sg__rc_cgen17086.d17186[486]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* char-ci>=? */
  sg__rc_cgen17086.d17186[488] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[490] = SG_MAKE_STRING("string=?");
  sg__rc_cgen17086.d17186[489] = Sg_Intern(sg__rc_cgen17086.d17186[490]); /* string=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[488],SG_SYMBOL(sg__rc_cgen17086.d17186[489]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string=? */
  sg__rc_cgen17086.d17186[491] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[493] = SG_MAKE_STRING("string-foldcase");
  sg__rc_cgen17086.d17186[492] = Sg_Intern(sg__rc_cgen17086.d17186[493]); /* string-foldcase */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[491],SG_SYMBOL(sg__rc_cgen17086.d17186[492]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-foldcase */
  sg__rc_cgen17086.d17186[494] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[494],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[495] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[497] = SG_MAKE_STRING("string-ci=?");
  sg__rc_cgen17086.d17186[496] = Sg_Intern(sg__rc_cgen17086.d17186[497]); /* string-ci=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[495],SG_SYMBOL(sg__rc_cgen17086.d17186[496]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-ci=? */
  sg__rc_cgen17086.d17186[498] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[500] = SG_MAKE_STRING("string<?");
  sg__rc_cgen17086.d17186[499] = Sg_Intern(sg__rc_cgen17086.d17186[500]); /* string<? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[498],SG_SYMBOL(sg__rc_cgen17086.d17186[499]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string<? */
  sg__rc_cgen17086.d17186[501] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[501],SG_SYMBOL(sg__rc_cgen17086.d17186[492]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-foldcase */
  sg__rc_cgen17086.d17186[502] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[502],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[503] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[505] = SG_MAKE_STRING("string-ci<?");
  sg__rc_cgen17086.d17186[504] = Sg_Intern(sg__rc_cgen17086.d17186[505]); /* string-ci<? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[503],SG_SYMBOL(sg__rc_cgen17086.d17186[504]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-ci<? */
  sg__rc_cgen17086.d17186[506] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[508] = SG_MAKE_STRING("string>?");
  sg__rc_cgen17086.d17186[507] = Sg_Intern(sg__rc_cgen17086.d17186[508]); /* string>? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[506],SG_SYMBOL(sg__rc_cgen17086.d17186[507]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string>? */
  sg__rc_cgen17086.d17186[509] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[509],SG_SYMBOL(sg__rc_cgen17086.d17186[492]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-foldcase */
  sg__rc_cgen17086.d17186[510] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[510],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[511] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[513] = SG_MAKE_STRING("string-ci>?");
  sg__rc_cgen17086.d17186[512] = Sg_Intern(sg__rc_cgen17086.d17186[513]); /* string-ci>? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[511],SG_SYMBOL(sg__rc_cgen17086.d17186[512]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-ci>? */
  sg__rc_cgen17086.d17186[514] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[516] = SG_MAKE_STRING("string<=?");
  sg__rc_cgen17086.d17186[515] = Sg_Intern(sg__rc_cgen17086.d17186[516]); /* string<=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[514],SG_SYMBOL(sg__rc_cgen17086.d17186[515]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string<=? */
  sg__rc_cgen17086.d17186[517] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[517],SG_SYMBOL(sg__rc_cgen17086.d17186[492]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-foldcase */
  sg__rc_cgen17086.d17186[518] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[518],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[519] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[521] = SG_MAKE_STRING("string-ci<=?");
  sg__rc_cgen17086.d17186[520] = Sg_Intern(sg__rc_cgen17086.d17186[521]); /* string-ci<=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[519],SG_SYMBOL(sg__rc_cgen17086.d17186[520]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-ci<=? */
  sg__rc_cgen17086.d17186[522] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[524] = SG_MAKE_STRING("string>=?");
  sg__rc_cgen17086.d17186[523] = Sg_Intern(sg__rc_cgen17086.d17186[524]); /* string>=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[522],SG_SYMBOL(sg__rc_cgen17086.d17186[523]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string>=? */
  sg__rc_cgen17086.d17186[525] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[525],SG_SYMBOL(sg__rc_cgen17086.d17186[492]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-foldcase */
  sg__rc_cgen17086.d17186[526] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[526],SG_SYMBOL(sg__rc_cgen17086.d17186[443]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-ci-comparison */
  sg__rc_cgen17086.d17186[527] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[529] = SG_MAKE_STRING("string-ci>=?");
  sg__rc_cgen17086.d17186[528] = Sg_Intern(sg__rc_cgen17086.d17186[529]); /* string-ci>=? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[527],SG_SYMBOL(sg__rc_cgen17086.d17186[528]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-ci>=? */
  sg__rc_cgen17086.d17186[531] = SG_MAKE_STRING("big");
  sg__rc_cgen17086.d17186[530] = Sg_Intern(sg__rc_cgen17086.d17186[531]); /* big */
  sg__rc_cgen17086.d17186[532] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[534] = SG_MAKE_STRING("bytevector-u8-ref");
  sg__rc_cgen17086.d17186[533] = Sg_Intern(sg__rc_cgen17086.d17186[534]); /* bytevector-u8-ref */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[532],SG_SYMBOL(sg__rc_cgen17086.d17186[533]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-u8-ref */
  sg__rc_cgen17086.d17186[536] = SG_MAKE_STRING("little");
  sg__rc_cgen17086.d17186[535] = Sg_Intern(sg__rc_cgen17086.d17186[536]); /* little */
  sg__rc_cgen17086.d17186[537] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[537],SG_SYMBOL(sg__rc_cgen17086.d17186[533]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-u8-ref */
  sg__rc_cgen17086.d17186[539] = SG_MAKE_STRING("bytevector-uint-ref");
  sg__rc_cgen17086.d17186[538] = Sg_Intern(sg__rc_cgen17086.d17186[539]); /* bytevector-uint-ref */
  sg__rc_cgen17086.d17186[540] = SG_MAKE_STRING("expected endianness, but got ~s, as argument 3");
  sg__rc_cgen17086.d17186[541] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[541],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[542] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[542],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[60]))->name = sg__rc_cgen17086.d17186[538];/* bytevector-uint-ref */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[2] = SG_WORD(sg__rc_cgen17086.d17186[530]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[29] = SG_WORD(sg__rc_cgen17086.d17186[532]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[38] = SG_WORD(sg__rc_cgen17086.d17186[535]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[65] = SG_WORD(sg__rc_cgen17086.d17186[537]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[73] = SG_WORD(sg__rc_cgen17086.d17186[538]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[77] = SG_WORD(sg__rc_cgen17086.d17186[540]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[80] = SG_WORD(sg__rc_cgen17086.d17186[541]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1807]))[89] = SG_WORD(sg__rc_cgen17086.d17186[542]);
  sg__rc_cgen17086.d17186[543] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[543],SG_SYMBOL(sg__rc_cgen17086.d17186[538]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-ref */
  sg__rc_cgen17086.d17186[544] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[544],SG_SYMBOL(sg__rc_cgen17086.d17186[533]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-u8-ref */
  sg__rc_cgen17086.d17186[545] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[545],SG_SYMBOL(sg__rc_cgen17086.d17186[538]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-ref */
  sg__rc_cgen17086.d17186[546] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[548] = SG_MAKE_STRING("expt");
  sg__rc_cgen17086.d17186[547] = Sg_Intern(sg__rc_cgen17086.d17186[548]); /* expt */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[546],SG_SYMBOL(sg__rc_cgen17086.d17186[547]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* expt */
  sg__rc_cgen17086.d17186[549] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[549],SG_SYMBOL(sg__rc_cgen17086.d17186[538]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-ref */
  sg__rc_cgen17086.d17186[550] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[550],SG_SYMBOL(sg__rc_cgen17086.d17186[533]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-u8-ref */
  sg__rc_cgen17086.d17186[551] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[551],SG_SYMBOL(sg__rc_cgen17086.d17186[538]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-ref */
  sg__rc_cgen17086.d17186[552] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[552],SG_SYMBOL(sg__rc_cgen17086.d17186[547]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* expt */
  sg__rc_cgen17086.d17186[553] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[553],SG_SYMBOL(sg__rc_cgen17086.d17186[538]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-ref */
  sg__rc_cgen17086.d17186[554] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[554],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[555] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[555],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[557] = SG_MAKE_STRING("bytevector-sint-ref");
  sg__rc_cgen17086.d17186[556] = Sg_Intern(sg__rc_cgen17086.d17186[557]); /* bytevector-sint-ref */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[61]))->name = sg__rc_cgen17086.d17186[556];/* bytevector-sint-ref */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[2] = SG_WORD(sg__rc_cgen17086.d17186[530]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[10] = SG_WORD(sg__rc_cgen17086.d17186[544]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[22] = SG_WORD(sg__rc_cgen17086.d17186[545]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[29] = SG_WORD(sg__rc_cgen17086.d17186[546]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[37] = SG_WORD(sg__rc_cgen17086.d17186[549]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[41] = SG_WORD(sg__rc_cgen17086.d17186[535]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[53] = SG_WORD(sg__rc_cgen17086.d17186[550]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[65] = SG_WORD(sg__rc_cgen17086.d17186[551]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[72] = SG_WORD(sg__rc_cgen17086.d17186[552]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[80] = SG_WORD(sg__rc_cgen17086.d17186[553]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[83] = SG_WORD(sg__rc_cgen17086.d17186[538]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[87] = SG_WORD(sg__rc_cgen17086.d17186[540]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[90] = SG_WORD(sg__rc_cgen17086.d17186[554]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1898]))[99] = SG_WORD(sg__rc_cgen17086.d17186[555]);
  sg__rc_cgen17086.d17186[558] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[558],SG_SYMBOL(sg__rc_cgen17086.d17186[556]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-sint-ref */
  sg__rc_cgen17086.d17186[559] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[561] = SG_MAKE_STRING("bytevector-u8-set!");
  sg__rc_cgen17086.d17186[560] = Sg_Intern(sg__rc_cgen17086.d17186[561]); /* bytevector-u8-set! */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[559],SG_SYMBOL(sg__rc_cgen17086.d17186[560]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-u8-set! */
  sg__rc_cgen17086.d17186[562] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[562],SG_SYMBOL(sg__rc_cgen17086.d17186[547]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* expt */
  sg__rc_cgen17086.d17186[563] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[565] = SG_MAKE_STRING("<");
  sg__rc_cgen17086.d17186[564] = Sg_Intern(sg__rc_cgen17086.d17186[565]); /* < */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[563],SG_SYMBOL(sg__rc_cgen17086.d17186[564]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* < */
  sg__rc_cgen17086.d17186[566] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[568] = SG_MAKE_STRING("bitwise-and");
  sg__rc_cgen17086.d17186[567] = Sg_Intern(sg__rc_cgen17086.d17186[568]); /* bitwise-and */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[566],SG_SYMBOL(sg__rc_cgen17086.d17186[567]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bitwise-and */
  sg__rc_cgen17086.d17186[569] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[569],SG_SYMBOL(sg__rc_cgen17086.d17186[560]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-u8-set! */
  sg__rc_cgen17086.d17186[570] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[572] = SG_MAKE_STRING("bitwise-arithmetic-shift");
  sg__rc_cgen17086.d17186[571] = Sg_Intern(sg__rc_cgen17086.d17186[572]); /* bitwise-arithmetic-shift */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[570],SG_SYMBOL(sg__rc_cgen17086.d17186[571]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bitwise-arithmetic-shift */
  sg__rc_cgen17086.d17186[573] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[573],SG_SYMBOL(sg__rc_cgen17086.d17186[567]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bitwise-and */
  sg__rc_cgen17086.d17186[574] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[574],SG_SYMBOL(sg__rc_cgen17086.d17186[560]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-u8-set! */
  sg__rc_cgen17086.d17186[575] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[575],SG_SYMBOL(sg__rc_cgen17086.d17186[571]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bitwise-arithmetic-shift */
  sg__rc_cgen17086.d17186[577] = SG_MAKE_STRING("bytevector-uint-set!");
  sg__rc_cgen17086.d17186[576] = Sg_Intern(sg__rc_cgen17086.d17186[577]); /* bytevector-uint-set! */
  sg__rc_cgen17086.d17186[578] = SG_MAKE_STRING("value out of range, ~s as argument 3");
  sg__rc_cgen17086.d17186[579] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[579],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[580] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[580],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[62]))->name = sg__rc_cgen17086.d17186[576];/* bytevector-uint-set! */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[21] = SG_WORD(sg__rc_cgen17086.d17186[559]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[40] = SG_WORD(sg__rc_cgen17086.d17186[562]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[43] = SG_WORD(sg__rc_cgen17086.d17186[563]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[48] = SG_WORD(sg__rc_cgen17086.d17186[530]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[73] = SG_WORD(sg__rc_cgen17086.d17186[566]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[76] = SG_WORD(sg__rc_cgen17086.d17186[569]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[85] = SG_WORD(sg__rc_cgen17086.d17186[570]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[95] = SG_WORD(sg__rc_cgen17086.d17186[535]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[119] = SG_WORD(sg__rc_cgen17086.d17186[573]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[122] = SG_WORD(sg__rc_cgen17086.d17186[574]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[131] = SG_WORD(sg__rc_cgen17086.d17186[575]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[145] = SG_WORD(sg__rc_cgen17086.d17186[576]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[149] = SG_WORD(sg__rc_cgen17086.d17186[578]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[152] = SG_WORD(sg__rc_cgen17086.d17186[579]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[1999]))[162] = SG_WORD(sg__rc_cgen17086.d17186[580]);
  sg__rc_cgen17086.d17186[581] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[581],SG_SYMBOL(sg__rc_cgen17086.d17186[576]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-set! */
  sg__rc_cgen17086.d17186[582] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[582],SG_SYMBOL(sg__rc_cgen17086.d17186[547]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* expt */
  sg__rc_cgen17086.d17186[583] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[583],SG_SYMBOL(sg__rc_cgen17086.d17186[564]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* < */
  sg__rc_cgen17086.d17186[584] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[584],SG_SYMBOL(sg__rc_cgen17086.d17186[576]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-set! */
  sg__rc_cgen17086.d17186[585] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[585],SG_SYMBOL(sg__rc_cgen17086.d17186[547]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* expt */
  sg__rc_cgen17086.d17186[586] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[586],SG_SYMBOL(sg__rc_cgen17086.d17186[576]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-set! */
  sg__rc_cgen17086.d17186[588] = SG_MAKE_STRING("bytevector-sint-set!");
  sg__rc_cgen17086.d17186[587] = Sg_Intern(sg__rc_cgen17086.d17186[588]); /* bytevector-sint-set! */
  sg__rc_cgen17086.d17186[589] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[589],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[63]))->name = sg__rc_cgen17086.d17186[587];/* bytevector-sint-set! */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[9] = SG_WORD(sg__rc_cgen17086.d17186[582]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[21] = SG_WORD(sg__rc_cgen17086.d17186[583]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[36] = SG_WORD(sg__rc_cgen17086.d17186[584]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[49] = SG_WORD(sg__rc_cgen17086.d17186[585]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[55] = SG_WORD(sg__rc_cgen17086.d17186[586]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[61] = SG_WORD(sg__rc_cgen17086.d17186[587]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[65] = SG_WORD(sg__rc_cgen17086.d17186[578]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[68] = SG_WORD(sg__rc_cgen17086.d17186[589]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2164]))[78] = SG_WORD(sg__rc_cgen17086.d17186[387]);
  sg__rc_cgen17086.d17186[590] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[590],SG_SYMBOL(sg__rc_cgen17086.d17186[587]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-sint-set! */
  sg__rc_cgen17086.d17186[591] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[593] = SG_MAKE_STRING("bytevector-length");
  sg__rc_cgen17086.d17186[592] = Sg_Intern(sg__rc_cgen17086.d17186[593]); /* bytevector-length */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[591],SG_SYMBOL(sg__rc_cgen17086.d17186[592]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-length */
  sg__rc_cgen17086.d17186[594] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[594],SG_SYMBOL(sg__rc_cgen17086.d17186[538]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-ref */
  sg__rc_cgen17086.d17186[596] = SG_MAKE_STRING("bytevector->uint-list");
  sg__rc_cgen17086.d17186[595] = Sg_Intern(sg__rc_cgen17086.d17186[596]); /* bytevector->uint-list */
  sg__rc_cgen17086.d17186[597] = SG_MAKE_STRING("expected appropriate element size as argument 3, but got ~s");
  sg__rc_cgen17086.d17186[598] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[598],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[599] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[599],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[64]))->name = sg__rc_cgen17086.d17186[595];/* bytevector->uint-list */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2246]))[4] = SG_WORD(sg__rc_cgen17086.d17186[591]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2246]))[26] = SG_WORD(sg__rc_cgen17086.d17186[594]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2246]))[42] = SG_WORD(sg__rc_cgen17086.d17186[595]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2246]))[46] = SG_WORD(sg__rc_cgen17086.d17186[597]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2246]))[49] = SG_WORD(sg__rc_cgen17086.d17186[598]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2246]))[57] = SG_WORD(sg__rc_cgen17086.d17186[599]);
  sg__rc_cgen17086.d17186[600] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[600],SG_SYMBOL(sg__rc_cgen17086.d17186[595]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector->uint-list */
  sg__rc_cgen17086.d17186[601] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[601],SG_SYMBOL(sg__rc_cgen17086.d17186[592]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-length */
  sg__rc_cgen17086.d17186[602] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[602],SG_SYMBOL(sg__rc_cgen17086.d17186[556]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-sint-ref */
  sg__rc_cgen17086.d17186[604] = SG_MAKE_STRING("bytevector->sint-list");
  sg__rc_cgen17086.d17186[603] = Sg_Intern(sg__rc_cgen17086.d17186[604]); /* bytevector->sint-list */
  sg__rc_cgen17086.d17186[605] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[605],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[606] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[606],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[65]))->name = sg__rc_cgen17086.d17186[603];/* bytevector->sint-list */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2305]))[4] = SG_WORD(sg__rc_cgen17086.d17186[601]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2305]))[26] = SG_WORD(sg__rc_cgen17086.d17186[602]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2305]))[42] = SG_WORD(sg__rc_cgen17086.d17186[603]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2305]))[46] = SG_WORD(sg__rc_cgen17086.d17186[597]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2305]))[49] = SG_WORD(sg__rc_cgen17086.d17186[605]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2305]))[57] = SG_WORD(sg__rc_cgen17086.d17186[606]);
  sg__rc_cgen17086.d17186[607] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[607],SG_SYMBOL(sg__rc_cgen17086.d17186[603]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector->sint-list */
  sg__rc_cgen17086.d17186[608] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[610] = SG_MAKE_STRING("length");
  sg__rc_cgen17086.d17186[609] = Sg_Intern(sg__rc_cgen17086.d17186[610]); /* length */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[608],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[611] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[613] = SG_MAKE_STRING("make-bytevector");
  sg__rc_cgen17086.d17186[612] = Sg_Intern(sg__rc_cgen17086.d17186[613]); /* make-bytevector */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[611],SG_SYMBOL(sg__rc_cgen17086.d17186[612]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-bytevector */
  sg__rc_cgen17086.d17186[614] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[614],SG_SYMBOL(sg__rc_cgen17086.d17186[576]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-uint-set! */
  sg__rc_cgen17086.d17186[616] = SG_MAKE_STRING("uint-list->bytevector");
  sg__rc_cgen17086.d17186[615] = Sg_Intern(sg__rc_cgen17086.d17186[616]); /* uint-list->bytevector */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[66]))->name = sg__rc_cgen17086.d17186[615];/* uint-list->bytevector */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2364]))[7] = SG_WORD(sg__rc_cgen17086.d17186[608]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2364]))[11] = SG_WORD(sg__rc_cgen17086.d17186[611]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2364]))[28] = SG_WORD(sg__rc_cgen17086.d17186[614]);
  sg__rc_cgen17086.d17186[617] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[617],SG_SYMBOL(sg__rc_cgen17086.d17186[615]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* uint-list->bytevector */
  sg__rc_cgen17086.d17186[618] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[618],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[619] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[619],SG_SYMBOL(sg__rc_cgen17086.d17186[612]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-bytevector */
  sg__rc_cgen17086.d17186[620] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[620],SG_SYMBOL(sg__rc_cgen17086.d17186[587]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* bytevector-sint-set! */
  sg__rc_cgen17086.d17186[622] = SG_MAKE_STRING("sint-list->bytevector");
  sg__rc_cgen17086.d17186[621] = Sg_Intern(sg__rc_cgen17086.d17186[622]); /* sint-list->bytevector */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[67]))->name = sg__rc_cgen17086.d17186[621];/* sint-list->bytevector */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2402]))[7] = SG_WORD(sg__rc_cgen17086.d17186[618]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2402]))[11] = SG_WORD(sg__rc_cgen17086.d17186[619]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2402]))[28] = SG_WORD(sg__rc_cgen17086.d17186[620]);
  sg__rc_cgen17086.d17186[623] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[623],SG_SYMBOL(sg__rc_cgen17086.d17186[621]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* sint-list->bytevector */
  sg__rc_cgen17086.d17186[624] = SG_MAKE_STRING("traversal reached to non-pair element ~s");
  sg__rc_cgen17086.d17186[625] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[625],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[626] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[626],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[627] = SG_MAKE_STRING("expected chain of pairs, but got ~a, as argument 2");
  sg__rc_cgen17086.d17186[628] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[628],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[629] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[629],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[630] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[632] = SG_MAKE_STRING("list-transpose+");
  sg__rc_cgen17086.d17186[631] = Sg_Intern(sg__rc_cgen17086.d17186[632]); /* list-transpose+ */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[630],SG_SYMBOL(sg__rc_cgen17086.d17186[631]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose+ */
  sg__rc_cgen17086.d17186[633] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[633],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[634] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[634],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[635] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[635],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[637] = SG_MAKE_STRING("loop");
  sg__rc_cgen17086.d17186[636] = Sg_Intern(sg__rc_cgen17086.d17186[637]); /* loop */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[68]))->name = sg__rc_cgen17086.d17186[636];/* loop */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2440]))[20] = SG_WORD(sg__rc_cgen17086.d17186[411]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2440]))[24] = SG_WORD(sg__rc_cgen17086.d17186[624]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2440]))[27] = SG_WORD(sg__rc_cgen17086.d17186[634]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2440]))[31] = SG_WORD(sg__rc_cgen17086.d17186[635]);
  sg__rc_cgen17086.d17186[639] = SG_MAKE_STRING("collect-car");
  sg__rc_cgen17086.d17186[638] = Sg_Intern(sg__rc_cgen17086.d17186[639]); /* collect-car */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[69]))->name = sg__rc_cgen17086.d17186[638];/* collect-car */
  sg__rc_cgen17086.d17186[640] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[640],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[641] = SG_MAKE_STRING("expected same length chains of pairs");
  sg__rc_cgen17086.d17186[642] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[642],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[70]))->name = sg__rc_cgen17086.d17186[411];/* for-all */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[48] = SG_WORD(sg__rc_cgen17086.d17186[411]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[52] = SG_WORD(sg__rc_cgen17086.d17186[624]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[55] = SG_WORD(sg__rc_cgen17086.d17186[625]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[62] = SG_WORD(sg__rc_cgen17086.d17186[626]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[65] = SG_WORD(sg__rc_cgen17086.d17186[411]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[69] = SG_WORD(sg__rc_cgen17086.d17186[627]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[72] = SG_WORD(sg__rc_cgen17086.d17186[628]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[79] = SG_WORD(sg__rc_cgen17086.d17186[629]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[84] = SG_WORD(sg__rc_cgen17086.d17186[630]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[128] = SG_WORD(sg__rc_cgen17086.d17186[633]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[132] = SG_WORD(sg__rc_cgen17086.d17186[31]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[148] = SG_WORD(sg__rc_cgen17086.d17186[31]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[155] = SG_WORD(sg__rc_cgen17086.d17186[640]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[165] = SG_WORD(sg__rc_cgen17086.d17186[411]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[167] = SG_WORD(sg__rc_cgen17086.d17186[641]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[170] = SG_WORD(sg__rc_cgen17086.d17186[642]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2483]))[195] = SG_WORD(sg__rc_cgen17086.d17186[31]);
  sg__rc_cgen17086.d17186[643] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[643],SG_SYMBOL(sg__rc_cgen17086.d17186[411]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* for-all */
  sg__rc_cgen17086.d17186[644] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[644],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[645] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[645],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[646] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[646],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[647] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[647],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[648] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[648],SG_SYMBOL(sg__rc_cgen17086.d17186[631]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose+ */
  sg__rc_cgen17086.d17186[649] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[649],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[650] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[650],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[651] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[651],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[71]))->name = sg__rc_cgen17086.d17186[636];/* loop */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2685]))[20] = SG_WORD(sg__rc_cgen17086.d17186[396]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2685]))[24] = SG_WORD(sg__rc_cgen17086.d17186[624]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2685]))[27] = SG_WORD(sg__rc_cgen17086.d17186[650]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2685]))[31] = SG_WORD(sg__rc_cgen17086.d17186[651]);
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[72]))->name = sg__rc_cgen17086.d17186[638];/* collect-car */
  sg__rc_cgen17086.d17186[652] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[652],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[653] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[653],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[73]))->name = sg__rc_cgen17086.d17186[396];/* exists */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[42] = SG_WORD(sg__rc_cgen17086.d17186[396]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[46] = SG_WORD(sg__rc_cgen17086.d17186[624]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[49] = SG_WORD(sg__rc_cgen17086.d17186[644]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[56] = SG_WORD(sg__rc_cgen17086.d17186[645]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[59] = SG_WORD(sg__rc_cgen17086.d17186[396]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[63] = SG_WORD(sg__rc_cgen17086.d17186[627]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[66] = SG_WORD(sg__rc_cgen17086.d17186[646]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[73] = SG_WORD(sg__rc_cgen17086.d17186[647]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[78] = SG_WORD(sg__rc_cgen17086.d17186[648]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[123] = SG_WORD(sg__rc_cgen17086.d17186[649]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[127] = SG_WORD(sg__rc_cgen17086.d17186[41]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[143] = SG_WORD(sg__rc_cgen17086.d17186[41]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[150] = SG_WORD(sg__rc_cgen17086.d17186[652]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[160] = SG_WORD(sg__rc_cgen17086.d17186[396]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[162] = SG_WORD(sg__rc_cgen17086.d17186[641]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[165] = SG_WORD(sg__rc_cgen17086.d17186[653]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2728]))[191] = SG_WORD(sg__rc_cgen17086.d17186[41]);
  sg__rc_cgen17086.d17186[654] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[654],SG_SYMBOL(sg__rc_cgen17086.d17186[396]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* exists */
  sg__rc_cgen17086.d17186[655] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[655],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[74]))->name = sg__rc_cgen17086.d17186[369];/* filter */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[2926]))[8] = SG_WORD(sg__rc_cgen17086.d17186[655]);
  sg__rc_cgen17086.d17186[656] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[656],SG_SYMBOL(sg__rc_cgen17086.d17186[369]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[75]))->name = sg__rc_cgen17086.d17186[375];/* filter! */
  sg__rc_cgen17086.d17186[657] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[657],SG_SYMBOL(sg__rc_cgen17086.d17186[375]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter! */
  sg__rc_cgen17086.d17186[658] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[658],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[659] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[659],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[661] = SG_MAKE_STRING("partition");
  sg__rc_cgen17086.d17186[660] = Sg_Intern(sg__rc_cgen17086.d17186[661]); /* partition */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[76]))->name = sg__rc_cgen17086.d17186[660];/* partition */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3034]))[12] = SG_WORD(sg__rc_cgen17086.d17186[658]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3034]))[18] = SG_WORD(sg__rc_cgen17086.d17186[659]);
  sg__rc_cgen17086.d17186[662] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[662],SG_SYMBOL(sg__rc_cgen17086.d17186[660]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* partition */
  sg__rc_cgen17086.d17186[663] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[663],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[664] = SG_MAKE_STRING("proper list");
  sg__rc_cgen17086.d17186[665] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[665],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[666] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[666],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[667] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[667],SG_SYMBOL(sg__rc_cgen17086.d17186[134]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose* */
  sg__rc_cgen17086.d17186[668] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[668],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[669] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[669],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[670] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[670],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[77]))->name = sg__rc_cgen17086.d17186[153];/* map */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[28] = SG_WORD(sg__rc_cgen17086.d17186[663]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[31] = SG_WORD(sg__rc_cgen17086.d17186[153]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[35] = SG_WORD(sg__rc_cgen17086.d17186[664]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[39] = SG_WORD(sg__rc_cgen17086.d17186[665]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[47] = SG_WORD(sg__rc_cgen17086.d17186[666]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[52] = SG_WORD(sg__rc_cgen17086.d17186[667]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[81] = SG_WORD(sg__rc_cgen17086.d17186[668]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[84] = SG_WORD(sg__rc_cgen17086.d17186[153]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[88] = SG_WORD(sg__rc_cgen17086.d17186[664]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[92] = SG_WORD(sg__rc_cgen17086.d17186[669]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3080]))[100] = SG_WORD(sg__rc_cgen17086.d17186[670]);
  sg__rc_cgen17086.d17186[671] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[671],SG_SYMBOL(sg__rc_cgen17086.d17186[153]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* map */
  sg__rc_cgen17086.d17186[672] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[672],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[673] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[673],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[674] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[674],SG_SYMBOL(sg__rc_cgen17086.d17186[134]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose* */
  sg__rc_cgen17086.d17186[675] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[675],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[676] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[676],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[78]))->name = sg__rc_cgen17086.d17186[125];/* for-each */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[24] = SG_WORD(sg__rc_cgen17086.d17186[125]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[28] = SG_WORD(sg__rc_cgen17086.d17186[664]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[32] = SG_WORD(sg__rc_cgen17086.d17186[672]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[40] = SG_WORD(sg__rc_cgen17086.d17186[673]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[45] = SG_WORD(sg__rc_cgen17086.d17186[674]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[70] = SG_WORD(sg__rc_cgen17086.d17186[125]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[74] = SG_WORD(sg__rc_cgen17086.d17186[664]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[78] = SG_WORD(sg__rc_cgen17086.d17186[675]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3182]))[86] = SG_WORD(sg__rc_cgen17086.d17186[676]);
  sg__rc_cgen17086.d17186[677] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[677],SG_SYMBOL(sg__rc_cgen17086.d17186[125]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* for-each */
  sg__rc_cgen17086.d17186[678] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[678],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[680] = SG_MAKE_STRING("filter-map");
  sg__rc_cgen17086.d17186[679] = Sg_Intern(sg__rc_cgen17086.d17186[680]); /* filter-map */
  sg__rc_cgen17086.d17186[681] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[681],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[682] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[682],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[683] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[683],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[79]))->name = sg__rc_cgen17086.d17186[636];/* loop */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3270]))[5] = SG_WORD(sg__rc_cgen17086.d17186[682]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3270]))[34] = SG_WORD(sg__rc_cgen17086.d17186[679]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3270]))[38] = SG_WORD(sg__rc_cgen17086.d17186[664]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3270]))[42] = SG_WORD(sg__rc_cgen17086.d17186[683]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3270]))[50] = SG_WORD(sg__rc_cgen17086.d17186[629]);
  sg__rc_cgen17086.d17186[684] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[684],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[685] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[685],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[80]))->name = sg__rc_cgen17086.d17186[636];/* loop */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3322]))[5] = SG_WORD(sg__rc_cgen17086.d17186[684]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3322]))[34] = SG_WORD(sg__rc_cgen17086.d17186[153]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3322]))[38] = SG_WORD(sg__rc_cgen17086.d17186[664]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3322]))[42] = SG_WORD(sg__rc_cgen17086.d17186[82]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3322]))[50] = SG_WORD(sg__rc_cgen17086.d17186[685]);
  sg__rc_cgen17086.d17186[686] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[686],SG_SYMBOL(sg__rc_cgen17086.d17186[134]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose* */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[81]))->name = sg__rc_cgen17086.d17186[679];/* filter-map */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3374]))[4] = SG_WORD(sg__rc_cgen17086.d17186[678]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3374]))[13] = SG_WORD(sg__rc_cgen17086.d17186[679]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3374]))[17] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3374]))[21] = SG_WORD(sg__rc_cgen17086.d17186[681]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3374]))[29] = SG_WORD(sg__rc_cgen17086.d17186[647]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3374]))[58] = SG_WORD(sg__rc_cgen17086.d17186[686]);
  sg__rc_cgen17086.d17186[687] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[687],SG_SYMBOL(sg__rc_cgen17086.d17186[679]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* filter-map */
  sg__rc_cgen17086.d17186[688] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[688],SG_SYMBOL(sg__rc_cgen17086.d17186[134]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose* */
  sg__rc_cgen17086.d17186[690] = SG_MAKE_STRING("fold-left");
  sg__rc_cgen17086.d17186[689] = Sg_Intern(sg__rc_cgen17086.d17186[690]); /* fold-left */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[82]))->name = sg__rc_cgen17086.d17186[689];/* fold-left */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3442]))[25] = SG_WORD(sg__rc_cgen17086.d17186[688]);
  sg__rc_cgen17086.d17186[691] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[691],SG_SYMBOL(sg__rc_cgen17086.d17186[689]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* fold-left */
  sg__rc_cgen17086.d17186[692] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[694] = SG_MAKE_STRING("reverse");
  sg__rc_cgen17086.d17186[693] = Sg_Intern(sg__rc_cgen17086.d17186[694]); /* reverse */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[692],SG_SYMBOL(sg__rc_cgen17086.d17186[693]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse */
  sg__rc_cgen17086.d17186[695] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[695],SG_SYMBOL(sg__rc_cgen17086.d17186[134]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-transpose* */
  sg__rc_cgen17086.d17186[696] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[696],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[697] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[699] = SG_MAKE_STRING("append!");
  sg__rc_cgen17086.d17186[698] = Sg_Intern(sg__rc_cgen17086.d17186[699]); /* append! */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[697],SG_SYMBOL(sg__rc_cgen17086.d17186[698]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* append! */
  sg__rc_cgen17086.d17186[701] = SG_MAKE_STRING("fold-right");
  sg__rc_cgen17086.d17186[700] = Sg_Intern(sg__rc_cgen17086.d17186[701]); /* fold-right */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[83]))->name = sg__rc_cgen17086.d17186[700];/* fold-right */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3490]))[7] = SG_WORD(sg__rc_cgen17086.d17186[692]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3490]))[32] = SG_WORD(sg__rc_cgen17086.d17186[695]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3490]))[38] = SG_WORD(sg__rc_cgen17086.d17186[696]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3490]))[57] = SG_WORD(sg__rc_cgen17086.d17186[697]);
  sg__rc_cgen17086.d17186[702] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[702],SG_SYMBOL(sg__rc_cgen17086.d17186[700]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* fold-right */
  sg__rc_cgen17086.d17186[703] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[703],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[705] = SG_MAKE_STRING("remp");
  sg__rc_cgen17086.d17186[704] = Sg_Intern(sg__rc_cgen17086.d17186[705]); /* remp */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[84]))->name = sg__rc_cgen17086.d17186[704];/* remp */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3554]))[8] = SG_WORD(sg__rc_cgen17086.d17186[703]);
  sg__rc_cgen17086.d17186[706] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[706],SG_SYMBOL(sg__rc_cgen17086.d17186[704]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* remp */
  sg__rc_cgen17086.d17186[707] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[707],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[708] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[708],SG_SYMBOL(sg__rc_cgen17086.d17186[353]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* equal? */
  sg__rc_cgen17086.d17186[710] = SG_MAKE_STRING("remove");
  sg__rc_cgen17086.d17186[709] = Sg_Intern(sg__rc_cgen17086.d17186[710]); /* remove */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[85]))->name = sg__rc_cgen17086.d17186[709];/* remove */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3585]))[8] = SG_WORD(sg__rc_cgen17086.d17186[707]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3585]))[15] = SG_WORD(sg__rc_cgen17086.d17186[708]);
  sg__rc_cgen17086.d17186[711] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[711],SG_SYMBOL(sg__rc_cgen17086.d17186[709]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* remove */
  sg__rc_cgen17086.d17186[712] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[712],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[714] = SG_MAKE_STRING("remv");
  sg__rc_cgen17086.d17186[713] = Sg_Intern(sg__rc_cgen17086.d17186[714]); /* remv */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[86]))->name = sg__rc_cgen17086.d17186[713];/* remv */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3617]))[8] = SG_WORD(sg__rc_cgen17086.d17186[712]);
  sg__rc_cgen17086.d17186[715] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[715],SG_SYMBOL(sg__rc_cgen17086.d17186[713]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* remv */
  sg__rc_cgen17086.d17186[716] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[716],SG_SYMBOL(sg__rc_cgen17086.d17186[1]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* reverse! */
  sg__rc_cgen17086.d17186[718] = SG_MAKE_STRING("remq");
  sg__rc_cgen17086.d17186[717] = Sg_Intern(sg__rc_cgen17086.d17186[718]); /* remq */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[87]))->name = sg__rc_cgen17086.d17186[717];/* remq */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3645]))[8] = SG_WORD(sg__rc_cgen17086.d17186[716]);
  sg__rc_cgen17086.d17186[719] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[719],SG_SYMBOL(sg__rc_cgen17086.d17186[717]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* remq */
  sg__rc_cgen17086.d17186[720] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[722] = SG_MAKE_STRING("memp");
  sg__rc_cgen17086.d17186[721] = Sg_Intern(sg__rc_cgen17086.d17186[722]); /* memp */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[720],SG_SYMBOL(sg__rc_cgen17086.d17186[721]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* memp */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[88]))->name = sg__rc_cgen17086.d17186[721];/* memp */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3673]))[17] = SG_WORD(sg__rc_cgen17086.d17186[720]);
  sg__rc_cgen17086.d17186[723] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[723],SG_SYMBOL(sg__rc_cgen17086.d17186[721]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* memp */
  sg__rc_cgen17086.d17186[724] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[726] = SG_MAKE_STRING("assp");
  sg__rc_cgen17086.d17186[725] = Sg_Intern(sg__rc_cgen17086.d17186[726]); /* assp */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[724],SG_SYMBOL(sg__rc_cgen17086.d17186[725]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assp */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[89]))->name = sg__rc_cgen17086.d17186[725];/* assp */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3692]))[19] = SG_WORD(sg__rc_cgen17086.d17186[724]);
  sg__rc_cgen17086.d17186[727] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[727],SG_SYMBOL(sg__rc_cgen17086.d17186[725]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assp */
  sg__rc_cgen17086.d17186[728] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[728],SG_SYMBOL(sg__rc_cgen17086.d17186[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* procedure? */
  sg__rc_cgen17086.d17186[730] = SG_MAKE_STRING("list-sort");
  sg__rc_cgen17086.d17186[729] = Sg_Intern(sg__rc_cgen17086.d17186[730]); /* list-sort */
  sg__rc_cgen17086.d17186[731] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[731],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[732] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[732],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[733] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[733],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[734] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[736] = SG_MAKE_STRING("div");
  sg__rc_cgen17086.d17186[735] = Sg_Intern(sg__rc_cgen17086.d17186[736]); /* div */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[734],SG_SYMBOL(sg__rc_cgen17086.d17186[735]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* div */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[90]))->name = sg__rc_cgen17086.d17186[207];/* recur */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3713]))[48] = SG_WORD(sg__rc_cgen17086.d17186[734]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3713]))[110] = SG_WORD(sg__rc_cgen17086.d17186[46]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3713]))[140] = SG_WORD(sg__rc_cgen17086.d17186[46]);
  sg__rc_cgen17086.d17186[737] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[737],SG_SYMBOL(sg__rc_cgen17086.d17186[441]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-head */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[91]))->name = sg__rc_cgen17086.d17186[729];/* list-sort */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[2] = SG_WORD(sg__rc_cgen17086.d17186[46]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[8] = SG_WORD(sg__rc_cgen17086.d17186[728]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[17] = SG_WORD(sg__rc_cgen17086.d17186[729]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[21] = SG_WORD(sg__rc_cgen17086.d17186[59]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[25] = SG_WORD(sg__rc_cgen17086.d17186[731]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[28] = SG_WORD(sg__rc_cgen17086.d17186[732]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[85] = SG_WORD(sg__rc_cgen17086.d17186[733]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[111] = SG_WORD(sg__rc_cgen17086.d17186[737]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3867]))[116] = SG_WORD(sg__rc_cgen17086.d17186[46]);
  sg__rc_cgen17086.d17186[738] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[738],SG_SYMBOL(sg__rc_cgen17086.d17186[729]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-sort */
  sg__rc_cgen17086.d17186[742] = SG_MAKE_STRING("len");
  sg__rc_cgen17086.d17186[741] = Sg_Intern(sg__rc_cgen17086.d17186[742]); /* len */
  sg__rc_cgen17086.d17186[745] = SG_MAKE_STRING("vect");
  sg__rc_cgen17086.d17186[744] = Sg_Intern(sg__rc_cgen17086.d17186[745]); /* vect */
  do {
    /* (vector-length vect) */ 
    SgObject G17285 = SG_NIL, G17286 = SG_NIL;
    SG_APPEND1(G17285, G17286, sg__rc_cgen17086.d17186[150]); /* vector-length */ 
    SG_APPEND1(G17285, G17286, sg__rc_cgen17086.d17186[744]); /* vect */ 
    sg__rc_cgen17086.d17186[743] = G17285;
  } while (0);
  do {
    /* (define len (vector-length vect)) */ 
    SgObject G17287 = SG_NIL, G17288 = SG_NIL;
    SG_APPEND1(G17287, G17288, sg__rc_cgen17086.d17186[195]); /* define */ 
    SG_APPEND1(G17287, G17288, sg__rc_cgen17086.d17186[741]); /* len */ 
    SG_APPEND1(G17287, G17288, sg__rc_cgen17086.d17186[743]); /* (vector-length vect) */ 
    sg__rc_cgen17086.d17186[740] = G17287;
  } while (0);
  sg__rc_cgen17086.d17186[748] = SG_MAKE_STRING("end");
  sg__rc_cgen17086.d17186[747] = Sg_Intern(sg__rc_cgen17086.d17186[748]); /* end */
  sg__rc_cgen17086.d17186[751] = SG_MAKE_STRING("or");
  sg__rc_cgen17086.d17186[750] = Sg_Intern(sg__rc_cgen17086.d17186[751]); /* or */
  sg__rc_cgen17086.d17186[753] = SG_MAKE_STRING("maybe-end");
  sg__rc_cgen17086.d17186[752] = Sg_Intern(sg__rc_cgen17086.d17186[753]); /* maybe-end */
  do {
    /* (or maybe-end len) */ 
    SgObject G17289 = SG_NIL, G17290 = SG_NIL;
    SG_APPEND1(G17289, G17290, sg__rc_cgen17086.d17186[750]); /* or */ 
    SG_APPEND1(G17289, G17290, sg__rc_cgen17086.d17186[752]); /* maybe-end */ 
    SG_APPEND1(G17289, G17290, sg__rc_cgen17086.d17186[741]); /* len */ 
    sg__rc_cgen17086.d17186[749] = G17289;
  } while (0);
  do {
    /* (define end (or maybe-end len)) */ 
    SgObject G17291 = SG_NIL, G17292 = SG_NIL;
    SG_APPEND1(G17291, G17292, sg__rc_cgen17086.d17186[195]); /* define */ 
    SG_APPEND1(G17291, G17292, sg__rc_cgen17086.d17186[747]); /* end */ 
    SG_APPEND1(G17291, G17292, sg__rc_cgen17086.d17186[749]); /* (or maybe-end len) */ 
    sg__rc_cgen17086.d17186[746] = G17291;
  } while (0);
  sg__rc_cgen17086.d17186[757] = SG_MAKE_STRING("vector-copy!");
  sg__rc_cgen17086.d17186[756] = Sg_Intern(sg__rc_cgen17086.d17186[757]); /* vector-copy! */
  sg__rc_cgen17086.d17186[759] = SG_MAKE_STRING("src");
  sg__rc_cgen17086.d17186[758] = Sg_Intern(sg__rc_cgen17086.d17186[759]); /* src */
  sg__rc_cgen17086.d17186[761] = SG_MAKE_STRING("src-from");
  sg__rc_cgen17086.d17186[760] = Sg_Intern(sg__rc_cgen17086.d17186[761]); /* src-from */
  sg__rc_cgen17086.d17186[763] = SG_MAKE_STRING("dst");
  sg__rc_cgen17086.d17186[762] = Sg_Intern(sg__rc_cgen17086.d17186[763]); /* dst */
  sg__rc_cgen17086.d17186[765] = SG_MAKE_STRING("dst-from");
  sg__rc_cgen17086.d17186[764] = Sg_Intern(sg__rc_cgen17086.d17186[765]); /* dst-from */
  sg__rc_cgen17086.d17186[767] = SG_MAKE_STRING("size");
  sg__rc_cgen17086.d17186[766] = Sg_Intern(sg__rc_cgen17086.d17186[767]); /* size */
  do {
    /* (vector-copy! src src-from dst dst-from size) */ 
    SgObject G17293 = SG_NIL, G17294 = SG_NIL;
    SG_APPEND1(G17293, G17294, sg__rc_cgen17086.d17186[756]); /* vector-copy! */ 
    SG_APPEND1(G17293, G17294, sg__rc_cgen17086.d17186[758]); /* src */ 
    SG_APPEND1(G17293, G17294, sg__rc_cgen17086.d17186[760]); /* src-from */ 
    SG_APPEND1(G17293, G17294, sg__rc_cgen17086.d17186[762]); /* dst */ 
    SG_APPEND1(G17293, G17294, sg__rc_cgen17086.d17186[764]); /* dst-from */ 
    SG_APPEND1(G17293, G17294, sg__rc_cgen17086.d17186[766]); /* size */ 
    sg__rc_cgen17086.d17186[755] = G17293;
  } while (0);
  sg__rc_cgen17086.d17186[771] = SG_MAKE_STRING("<=");
  sg__rc_cgen17086.d17186[770] = Sg_Intern(sg__rc_cgen17086.d17186[771]); /* <= */
  do {
    /* (<= dst-from src-from) */ 
    SgObject G17295 = SG_NIL, G17296 = SG_NIL;
    SG_APPEND1(G17295, G17296, sg__rc_cgen17086.d17186[770]); /* <= */ 
    SG_APPEND1(G17295, G17296, sg__rc_cgen17086.d17186[764]); /* dst-from */ 
    SG_APPEND1(G17295, G17296, sg__rc_cgen17086.d17186[760]); /* src-from */ 
    sg__rc_cgen17086.d17186[769] = G17295;
  } while (0);
  sg__rc_cgen17086.d17186[774] = SG_MAKE_STRING("do");
  sg__rc_cgen17086.d17186[773] = Sg_Intern(sg__rc_cgen17086.d17186[774]); /* do */
  sg__rc_cgen17086.d17186[778] = SG_MAKE_STRING("i");
  sg__rc_cgen17086.d17186[777] = Sg_Intern(sg__rc_cgen17086.d17186[778]); /* i */
  sg__rc_cgen17086.d17186[781] = SG_MAKE_STRING("+");
  sg__rc_cgen17086.d17186[780] = Sg_Intern(sg__rc_cgen17086.d17186[781]); /* + */
  do {
    /* (+ i 1) */ 
    SgObject G17297 = SG_NIL, G17298 = SG_NIL;
    SG_APPEND1(G17297, G17298, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17297, G17298, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17297, G17298, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[779] = G17297;
  } while (0);
  do {
    /* (i 0 (+ i 1)) */ 
    SgObject G17299 = SG_NIL, G17300 = SG_NIL;
    SG_APPEND1(G17299, G17300, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17299, G17300, SG_MAKE_INT(0)); /* 0 */ 
    SG_APPEND1(G17299, G17300, sg__rc_cgen17086.d17186[779]); /* (+ i 1) */ 
    sg__rc_cgen17086.d17186[776] = G17299;
  } while (0);
  sg__rc_cgen17086.d17186[784] = SG_MAKE_STRING("s");
  sg__rc_cgen17086.d17186[783] = Sg_Intern(sg__rc_cgen17086.d17186[784]); /* s */
  do {
    /* (+ s 1) */ 
    SgObject G17301 = SG_NIL, G17302 = SG_NIL;
    SG_APPEND1(G17301, G17302, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17301, G17302, sg__rc_cgen17086.d17186[783]); /* s */ 
    SG_APPEND1(G17301, G17302, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[785] = G17301;
  } while (0);
  do {
    /* (s src-from (+ s 1)) */ 
    SgObject G17303 = SG_NIL, G17304 = SG_NIL;
    SG_APPEND1(G17303, G17304, sg__rc_cgen17086.d17186[783]); /* s */ 
    SG_APPEND1(G17303, G17304, sg__rc_cgen17086.d17186[760]); /* src-from */ 
    SG_APPEND1(G17303, G17304, sg__rc_cgen17086.d17186[785]); /* (+ s 1) */ 
    sg__rc_cgen17086.d17186[782] = G17303;
  } while (0);
  sg__rc_cgen17086.d17186[788] = SG_MAKE_STRING("d");
  sg__rc_cgen17086.d17186[787] = Sg_Intern(sg__rc_cgen17086.d17186[788]); /* d */
  do {
    /* (+ d 1) */ 
    SgObject G17305 = SG_NIL, G17306 = SG_NIL;
    SG_APPEND1(G17305, G17306, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17305, G17306, sg__rc_cgen17086.d17186[787]); /* d */ 
    SG_APPEND1(G17305, G17306, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[789] = G17305;
  } while (0);
  do {
    /* (d dst-from (+ d 1)) */ 
    SgObject G17307 = SG_NIL, G17308 = SG_NIL;
    SG_APPEND1(G17307, G17308, sg__rc_cgen17086.d17186[787]); /* d */ 
    SG_APPEND1(G17307, G17308, sg__rc_cgen17086.d17186[764]); /* dst-from */ 
    SG_APPEND1(G17307, G17308, sg__rc_cgen17086.d17186[789]); /* (+ d 1) */ 
    sg__rc_cgen17086.d17186[786] = G17307;
  } while (0);
  do {
    /* ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) */ 
    SgObject G17309 = SG_NIL, G17310 = SG_NIL;
    SG_APPEND1(G17309, G17310, sg__rc_cgen17086.d17186[776]); /* (i 0 (+ i 1)) */ 
    SG_APPEND1(G17309, G17310, sg__rc_cgen17086.d17186[782]); /* (s src-from (+ s 1)) */ 
    SG_APPEND1(G17309, G17310, sg__rc_cgen17086.d17186[786]); /* (d dst-from (+ d 1)) */ 
    sg__rc_cgen17086.d17186[775] = G17309;
  } while (0);
  do {
    /* (= i size) */ 
    SgObject G17311 = SG_NIL, G17312 = SG_NIL;
    SG_APPEND1(G17311, G17312, sg__rc_cgen17086.d17186[384]); /* = */ 
    SG_APPEND1(G17311, G17312, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17311, G17312, sg__rc_cgen17086.d17186[766]); /* size */ 
    sg__rc_cgen17086.d17186[791] = G17311;
  } while (0);
  do {
    /* ((= i size) dst) */ 
    SgObject G17313 = SG_NIL, G17314 = SG_NIL;
    SG_APPEND1(G17313, G17314, sg__rc_cgen17086.d17186[791]); /* (= i size) */ 
    SG_APPEND1(G17313, G17314, sg__rc_cgen17086.d17186[762]); /* dst */ 
    sg__rc_cgen17086.d17186[790] = G17313;
  } while (0);
  sg__rc_cgen17086.d17186[794] = SG_MAKE_STRING("vector-set!");
  sg__rc_cgen17086.d17186[793] = Sg_Intern(sg__rc_cgen17086.d17186[794]); /* vector-set! */
  sg__rc_cgen17086.d17186[797] = SG_MAKE_STRING("vector-ref");
  sg__rc_cgen17086.d17186[796] = Sg_Intern(sg__rc_cgen17086.d17186[797]); /* vector-ref */
  do {
    /* (vector-ref src s) */ 
    SgObject G17315 = SG_NIL, G17316 = SG_NIL;
    SG_APPEND1(G17315, G17316, sg__rc_cgen17086.d17186[796]); /* vector-ref */ 
    SG_APPEND1(G17315, G17316, sg__rc_cgen17086.d17186[758]); /* src */ 
    SG_APPEND1(G17315, G17316, sg__rc_cgen17086.d17186[783]); /* s */ 
    sg__rc_cgen17086.d17186[795] = G17315;
  } while (0);
  do {
    /* (vector-set! dst d (vector-ref src s)) */ 
    SgObject G17317 = SG_NIL, G17318 = SG_NIL;
    SG_APPEND1(G17317, G17318, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17317, G17318, sg__rc_cgen17086.d17186[762]); /* dst */ 
    SG_APPEND1(G17317, G17318, sg__rc_cgen17086.d17186[787]); /* d */ 
    SG_APPEND1(G17317, G17318, sg__rc_cgen17086.d17186[795]); /* (vector-ref src s) */ 
    sg__rc_cgen17086.d17186[792] = G17317;
  } while (0);
  do {
    /* (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) */ 
    SgObject G17319 = SG_NIL, G17320 = SG_NIL;
    SG_APPEND1(G17319, G17320, sg__rc_cgen17086.d17186[773]); /* do */ 
    SG_APPEND1(G17319, G17320, sg__rc_cgen17086.d17186[775]); /* ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) */ 
    SG_APPEND1(G17319, G17320, sg__rc_cgen17086.d17186[790]); /* ((= i size) dst) */ 
    SG_APPEND1(G17319, G17320, sg__rc_cgen17086.d17186[792]); /* (vector-set! dst d (vector-ref src s)) */ 
    sg__rc_cgen17086.d17186[772] = G17319;
  } while (0);
  do {
    /* (+ src-from size) */ 
    SgObject G17321 = SG_NIL, G17322 = SG_NIL;
    SG_APPEND1(G17321, G17322, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17321, G17322, sg__rc_cgen17086.d17186[760]); /* src-from */ 
    SG_APPEND1(G17321, G17322, sg__rc_cgen17086.d17186[766]); /* size */ 
    sg__rc_cgen17086.d17186[801] = G17321;
  } while (0);
  sg__rc_cgen17086.d17186[804] = SG_MAKE_STRING("-");
  sg__rc_cgen17086.d17186[803] = Sg_Intern(sg__rc_cgen17086.d17186[804]); /* - */
  do {
    /* (- s 1) */ 
    SgObject G17323 = SG_NIL, G17324 = SG_NIL;
    SG_APPEND1(G17323, G17324, sg__rc_cgen17086.d17186[803]); /* - */ 
    SG_APPEND1(G17323, G17324, sg__rc_cgen17086.d17186[783]); /* s */ 
    SG_APPEND1(G17323, G17324, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[802] = G17323;
  } while (0);
  do {
    /* (s (+ src-from size) (- s 1)) */ 
    SgObject G17325 = SG_NIL, G17326 = SG_NIL;
    SG_APPEND1(G17325, G17326, sg__rc_cgen17086.d17186[783]); /* s */ 
    SG_APPEND1(G17325, G17326, sg__rc_cgen17086.d17186[801]); /* (+ src-from size) */ 
    SG_APPEND1(G17325, G17326, sg__rc_cgen17086.d17186[802]); /* (- s 1) */ 
    sg__rc_cgen17086.d17186[800] = G17325;
  } while (0);
  do {
    /* (+ dst-from size) */ 
    SgObject G17327 = SG_NIL, G17328 = SG_NIL;
    SG_APPEND1(G17327, G17328, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17327, G17328, sg__rc_cgen17086.d17186[764]); /* dst-from */ 
    SG_APPEND1(G17327, G17328, sg__rc_cgen17086.d17186[766]); /* size */ 
    sg__rc_cgen17086.d17186[806] = G17327;
  } while (0);
  do {
    /* (- d 1) */ 
    SgObject G17329 = SG_NIL, G17330 = SG_NIL;
    SG_APPEND1(G17329, G17330, sg__rc_cgen17086.d17186[803]); /* - */ 
    SG_APPEND1(G17329, G17330, sg__rc_cgen17086.d17186[787]); /* d */ 
    SG_APPEND1(G17329, G17330, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[807] = G17329;
  } while (0);
  do {
    /* (d (+ dst-from size) (- d 1)) */ 
    SgObject G17331 = SG_NIL, G17332 = SG_NIL;
    SG_APPEND1(G17331, G17332, sg__rc_cgen17086.d17186[787]); /* d */ 
    SG_APPEND1(G17331, G17332, sg__rc_cgen17086.d17186[806]); /* (+ dst-from size) */ 
    SG_APPEND1(G17331, G17332, sg__rc_cgen17086.d17186[807]); /* (- d 1) */ 
    sg__rc_cgen17086.d17186[805] = G17331;
  } while (0);
  do {
    /* ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) */ 
    SgObject G17333 = SG_NIL, G17334 = SG_NIL;
    SG_APPEND1(G17333, G17334, sg__rc_cgen17086.d17186[776]); /* (i 0 (+ i 1)) */ 
    SG_APPEND1(G17333, G17334, sg__rc_cgen17086.d17186[800]); /* (s (+ src-from size) (- s 1)) */ 
    SG_APPEND1(G17333, G17334, sg__rc_cgen17086.d17186[805]); /* (d (+ dst-from size) (- d 1)) */ 
    sg__rc_cgen17086.d17186[799] = G17333;
  } while (0);
  do {
    /* (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) */ 
    SgObject G17335 = SG_NIL, G17336 = SG_NIL;
    SG_APPEND1(G17335, G17336, sg__rc_cgen17086.d17186[773]); /* do */ 
    SG_APPEND1(G17335, G17336, sg__rc_cgen17086.d17186[799]); /* ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) */ 
    SG_APPEND1(G17335, G17336, sg__rc_cgen17086.d17186[790]); /* ((= i size) dst) */ 
    SG_APPEND1(G17335, G17336, sg__rc_cgen17086.d17186[792]); /* (vector-set! dst d (vector-ref src s)) */ 
    sg__rc_cgen17086.d17186[798] = G17335;
  } while (0);
  do {
    /* (if (<= dst-from src-from) (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s)))) */ 
    SgObject G17337 = SG_NIL, G17338 = SG_NIL;
    SG_APPEND1(G17337, G17338, sg__rc_cgen17086.d17186[212]); /* if */ 
    SG_APPEND1(G17337, G17338, sg__rc_cgen17086.d17186[769]); /* (<= dst-from src-from) */ 
    SG_APPEND1(G17337, G17338, sg__rc_cgen17086.d17186[772]); /* (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) */ 
    SG_APPEND1(G17337, G17338, sg__rc_cgen17086.d17186[798]); /* (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) */ 
    sg__rc_cgen17086.d17186[768] = G17337;
  } while (0);
  do {
    /* (define (vector-copy! src src-from dst dst-from size) (if (<= dst-from src-from) (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))))) */ 
    SgObject G17339 = SG_NIL, G17340 = SG_NIL;
    SG_APPEND1(G17339, G17340, sg__rc_cgen17086.d17186[195]); /* define */ 
    SG_APPEND1(G17339, G17340, sg__rc_cgen17086.d17186[755]); /* (vector-copy! src src-from dst dst-from size) */ 
    SG_APPEND1(G17339, G17340, sg__rc_cgen17086.d17186[768]); /* (if (<= dst-from src-from) (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s)))) */ 
    sg__rc_cgen17086.d17186[754] = G17339;
  } while (0);
  sg__rc_cgen17086.d17186[810] = SG_MAKE_STRING("when");
  sg__rc_cgen17086.d17186[809] = Sg_Intern(sg__rc_cgen17086.d17186[810]); /* when */
  sg__rc_cgen17086.d17186[814] = SG_MAKE_STRING("negative?");
  sg__rc_cgen17086.d17186[813] = Sg_Intern(sg__rc_cgen17086.d17186[814]); /* negative? */
  sg__rc_cgen17086.d17186[816] = SG_MAKE_STRING("start");
  sg__rc_cgen17086.d17186[815] = Sg_Intern(sg__rc_cgen17086.d17186[816]); /* start */
  do {
    /* (negative? start) */ 
    SgObject G17341 = SG_NIL, G17342 = SG_NIL;
    SG_APPEND1(G17341, G17342, sg__rc_cgen17086.d17186[813]); /* negative? */ 
    SG_APPEND1(G17341, G17342, sg__rc_cgen17086.d17186[815]); /* start */ 
    sg__rc_cgen17086.d17186[812] = G17341;
  } while (0);
  do {
    /* (negative? end) */ 
    SgObject G17343 = SG_NIL, G17344 = SG_NIL;
    SG_APPEND1(G17343, G17344, sg__rc_cgen17086.d17186[813]); /* negative? */ 
    SG_APPEND1(G17343, G17344, sg__rc_cgen17086.d17186[747]); /* end */ 
    sg__rc_cgen17086.d17186[817] = G17343;
  } while (0);
  do {
    /* (or (negative? start) (negative? end)) */ 
    SgObject G17345 = SG_NIL, G17346 = SG_NIL;
    SG_APPEND1(G17345, G17346, sg__rc_cgen17086.d17186[750]); /* or */ 
    SG_APPEND1(G17345, G17346, sg__rc_cgen17086.d17186[812]); /* (negative? start) */ 
    SG_APPEND1(G17345, G17346, sg__rc_cgen17086.d17186[817]); /* (negative? end) */ 
    sg__rc_cgen17086.d17186[811] = G17345;
  } while (0);
  sg__rc_cgen17086.d17186[821] = SG_MAKE_STRING("vector-sort!");
  sg__rc_cgen17086.d17186[820] = Sg_Intern(sg__rc_cgen17086.d17186[821]); /* vector-sort! */
  do {
    /* 'vector-sort! */ 
    SgObject G17347 = SG_NIL, G17348 = SG_NIL;
    SG_APPEND1(G17347, G17348, sg__rc_cgen17086.d17186[238]); /* quote */ 
    SG_APPEND1(G17347, G17348, sg__rc_cgen17086.d17186[820]); /* vector-sort! */ 
    sg__rc_cgen17086.d17186[819] = G17347;
  } while (0);
  sg__rc_cgen17086.d17186[822] = SG_MAKE_STRING("start and end must be positive");
  do {
    /* (assertion-violation 'vector-sort! "start and end must be positive" start vect) */ 
    SgObject G17349 = SG_NIL, G17350 = SG_NIL;
    SG_APPEND1(G17349, G17350, sg__rc_cgen17086.d17186[64]); /* assertion-violation */ 
    SG_APPEND1(G17349, G17350, sg__rc_cgen17086.d17186[819]); /* 'vector-sort! */ 
    SG_APPEND1(G17349, G17350, sg__rc_cgen17086.d17186[822]); /* "start and end must be positive" */ 
    SG_APPEND1(G17349, G17350, sg__rc_cgen17086.d17186[815]); /* start */ 
    SG_APPEND1(G17349, G17350, sg__rc_cgen17086.d17186[744]); /* vect */ 
    sg__rc_cgen17086.d17186[818] = G17349;
  } while (0);
  do {
    /* (when (or (negative? start) (negative? end)) (assertion-violation 'vector-sort! "start and end must be positive" start vect)) */ 
    SgObject G17351 = SG_NIL, G17352 = SG_NIL;
    SG_APPEND1(G17351, G17352, sg__rc_cgen17086.d17186[809]); /* when */ 
    SG_APPEND1(G17351, G17352, sg__rc_cgen17086.d17186[811]); /* (or (negative? start) (negative? end)) */ 
    SG_APPEND1(G17351, G17352, sg__rc_cgen17086.d17186[818]); /* (assertion-violation 'vector-sort! "start and end must be positive" start vect) */ 
    sg__rc_cgen17086.d17186[808] = G17351;
  } while (0);
  sg__rc_cgen17086.d17186[827] = SG_MAKE_STRING(">");
  sg__rc_cgen17086.d17186[826] = Sg_Intern(sg__rc_cgen17086.d17186[827]); /* > */
  do {
    /* (> start len) */ 
    SgObject G17353 = SG_NIL, G17354 = SG_NIL;
    SG_APPEND1(G17353, G17354, sg__rc_cgen17086.d17186[826]); /* > */ 
    SG_APPEND1(G17353, G17354, sg__rc_cgen17086.d17186[815]); /* start */ 
    SG_APPEND1(G17353, G17354, sg__rc_cgen17086.d17186[741]); /* len */ 
    sg__rc_cgen17086.d17186[825] = G17353;
  } while (0);
  do {
    /* (> end len) */ 
    SgObject G17355 = SG_NIL, G17356 = SG_NIL;
    SG_APPEND1(G17355, G17356, sg__rc_cgen17086.d17186[826]); /* > */ 
    SG_APPEND1(G17355, G17356, sg__rc_cgen17086.d17186[747]); /* end */ 
    SG_APPEND1(G17355, G17356, sg__rc_cgen17086.d17186[741]); /* len */ 
    sg__rc_cgen17086.d17186[828] = G17355;
  } while (0);
  do {
    /* (or (> start len) (> end len)) */ 
    SgObject G17357 = SG_NIL, G17358 = SG_NIL;
    SG_APPEND1(G17357, G17358, sg__rc_cgen17086.d17186[750]); /* or */ 
    SG_APPEND1(G17357, G17358, sg__rc_cgen17086.d17186[825]); /* (> start len) */ 
    SG_APPEND1(G17357, G17358, sg__rc_cgen17086.d17186[828]); /* (> end len) */ 
    sg__rc_cgen17086.d17186[824] = G17357;
  } while (0);
  sg__rc_cgen17086.d17186[830] = SG_MAKE_STRING("out of range");
  do {
    /* (list start end) */ 
    SgObject G17359 = SG_NIL, G17360 = SG_NIL;
    SG_APPEND1(G17359, G17360, sg__rc_cgen17086.d17186[279]); /* list */ 
    SG_APPEND1(G17359, G17360, sg__rc_cgen17086.d17186[815]); /* start */ 
    SG_APPEND1(G17359, G17360, sg__rc_cgen17086.d17186[747]); /* end */ 
    sg__rc_cgen17086.d17186[832] = G17359;
  } while (0);
  do {
    /* (list (list start end) len) */ 
    SgObject G17361 = SG_NIL, G17362 = SG_NIL;
    SG_APPEND1(G17361, G17362, sg__rc_cgen17086.d17186[279]); /* list */ 
    SG_APPEND1(G17361, G17362, sg__rc_cgen17086.d17186[832]); /* (list start end) */ 
    SG_APPEND1(G17361, G17362, sg__rc_cgen17086.d17186[741]); /* len */ 
    sg__rc_cgen17086.d17186[831] = G17361;
  } while (0);
  do {
    /* (assertion-violation 'vector-sort! "out of range" (list (list start end) len) vect) */ 
    SgObject G17363 = SG_NIL, G17364 = SG_NIL;
    SG_APPEND1(G17363, G17364, sg__rc_cgen17086.d17186[64]); /* assertion-violation */ 
    SG_APPEND1(G17363, G17364, sg__rc_cgen17086.d17186[819]); /* 'vector-sort! */ 
    SG_APPEND1(G17363, G17364, sg__rc_cgen17086.d17186[830]); /* "out of range" */ 
    SG_APPEND1(G17363, G17364, sg__rc_cgen17086.d17186[831]); /* (list (list start end) len) */ 
    SG_APPEND1(G17363, G17364, sg__rc_cgen17086.d17186[744]); /* vect */ 
    sg__rc_cgen17086.d17186[829] = G17363;
  } while (0);
  do {
    /* (when (or (> start len) (> end len)) (assertion-violation 'vector-sort! "out of range" (list (list start end) len) vect)) */ 
    SgObject G17365 = SG_NIL, G17366 = SG_NIL;
    SG_APPEND1(G17365, G17366, sg__rc_cgen17086.d17186[809]); /* when */ 
    SG_APPEND1(G17365, G17366, sg__rc_cgen17086.d17186[824]); /* (or (> start len) (> end len)) */ 
    SG_APPEND1(G17365, G17366, sg__rc_cgen17086.d17186[829]); /* (assertion-violation 'vector-sort! "out of range" (list (list start end) len) vect) */ 
    sg__rc_cgen17086.d17186[823] = G17365;
  } while (0);
  do {
    /* (> start end) */ 
    SgObject G17367 = SG_NIL, G17368 = SG_NIL;
    SG_APPEND1(G17367, G17368, sg__rc_cgen17086.d17186[826]); /* > */ 
    SG_APPEND1(G17367, G17368, sg__rc_cgen17086.d17186[815]); /* start */ 
    SG_APPEND1(G17367, G17368, sg__rc_cgen17086.d17186[747]); /* end */ 
    sg__rc_cgen17086.d17186[834] = G17367;
  } while (0);
  sg__rc_cgen17086.d17186[836] = SG_MAKE_STRING("start is greater than end");
  do {
    /* (assertion-violation 'vector-sort! "start is greater than end" (list start end) vect) */ 
    SgObject G17369 = SG_NIL, G17370 = SG_NIL;
    SG_APPEND1(G17369, G17370, sg__rc_cgen17086.d17186[64]); /* assertion-violation */ 
    SG_APPEND1(G17369, G17370, sg__rc_cgen17086.d17186[819]); /* 'vector-sort! */ 
    SG_APPEND1(G17369, G17370, sg__rc_cgen17086.d17186[836]); /* "start is greater than end" */ 
    SG_APPEND1(G17369, G17370, sg__rc_cgen17086.d17186[832]); /* (list start end) */ 
    SG_APPEND1(G17369, G17370, sg__rc_cgen17086.d17186[744]); /* vect */ 
    sg__rc_cgen17086.d17186[835] = G17369;
  } while (0);
  do {
    /* (when (> start end) (assertion-violation 'vector-sort! "start is greater than end" (list start end) vect)) */ 
    SgObject G17371 = SG_NIL, G17372 = SG_NIL;
    SG_APPEND1(G17371, G17372, sg__rc_cgen17086.d17186[809]); /* when */ 
    SG_APPEND1(G17371, G17372, sg__rc_cgen17086.d17186[834]); /* (> start end) */ 
    SG_APPEND1(G17371, G17372, sg__rc_cgen17086.d17186[835]); /* (assertion-violation 'vector-sort! "start is greater than end" (list start end) vect) */ 
    sg__rc_cgen17086.d17186[833] = G17371;
  } while (0);
  sg__rc_cgen17086.d17186[839] = SG_MAKE_STRING("let*");
  sg__rc_cgen17086.d17186[838] = Sg_Intern(sg__rc_cgen17086.d17186[839]); /* let* */
  sg__rc_cgen17086.d17186[843] = SG_MAKE_STRING("lst");
  sg__rc_cgen17086.d17186[842] = Sg_Intern(sg__rc_cgen17086.d17186[843]); /* lst */
  sg__rc_cgen17086.d17186[846] = SG_MAKE_STRING("vector->list");
  sg__rc_cgen17086.d17186[845] = Sg_Intern(sg__rc_cgen17086.d17186[846]); /* vector->list */
  do {
    /* (vector->list vect start end) */ 
    SgObject G17373 = SG_NIL, G17374 = SG_NIL;
    SG_APPEND1(G17373, G17374, sg__rc_cgen17086.d17186[845]); /* vector->list */ 
    SG_APPEND1(G17373, G17374, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17373, G17374, sg__rc_cgen17086.d17186[815]); /* start */ 
    SG_APPEND1(G17373, G17374, sg__rc_cgen17086.d17186[747]); /* end */ 
    sg__rc_cgen17086.d17186[844] = G17373;
  } while (0);
  do {
    /* (lst (vector->list vect start end)) */ 
    SgObject G17375 = SG_NIL, G17376 = SG_NIL;
    SG_APPEND1(G17375, G17376, sg__rc_cgen17086.d17186[842]); /* lst */ 
    SG_APPEND1(G17375, G17376, sg__rc_cgen17086.d17186[844]); /* (vector->list vect start end) */ 
    sg__rc_cgen17086.d17186[841] = G17375;
  } while (0);
  sg__rc_cgen17086.d17186[849] = SG_MAKE_STRING("lst2");
  sg__rc_cgen17086.d17186[848] = Sg_Intern(sg__rc_cgen17086.d17186[849]); /* lst2 */
  do {
    /* (list-sort proc lst) */ 
    SgObject G17377 = SG_NIL, G17378 = SG_NIL;
    SG_APPEND1(G17377, G17378, sg__rc_cgen17086.d17186[729]); /* list-sort */ 
    SG_APPEND1(G17377, G17378, sg__rc_cgen17086.d17186[90]); /* proc */ 
    SG_APPEND1(G17377, G17378, sg__rc_cgen17086.d17186[842]); /* lst */ 
    sg__rc_cgen17086.d17186[850] = G17377;
  } while (0);
  do {
    /* (lst2 (list-sort proc lst)) */ 
    SgObject G17379 = SG_NIL, G17380 = SG_NIL;
    SG_APPEND1(G17379, G17380, sg__rc_cgen17086.d17186[848]); /* lst2 */ 
    SG_APPEND1(G17379, G17380, sg__rc_cgen17086.d17186[850]); /* (list-sort proc lst) */ 
    sg__rc_cgen17086.d17186[847] = G17379;
  } while (0);
  do {
    /* ((lst (vector->list vect start end)) (lst2 (list-sort proc lst))) */ 
    SgObject G17381 = SG_NIL, G17382 = SG_NIL;
    SG_APPEND1(G17381, G17382, sg__rc_cgen17086.d17186[841]); /* (lst (vector->list vect start end)) */ 
    SG_APPEND1(G17381, G17382, sg__rc_cgen17086.d17186[847]); /* (lst2 (list-sort proc lst)) */ 
    sg__rc_cgen17086.d17186[840] = G17381;
  } while (0);
  do {
    /* (eq? lst lst2) */ 
    SgObject G17383 = SG_NIL, G17384 = SG_NIL;
    SG_APPEND1(G17383, G17384, sg__rc_cgen17086.d17186[297]); /* eq? */ 
    SG_APPEND1(G17383, G17384, sg__rc_cgen17086.d17186[842]); /* lst */ 
    SG_APPEND1(G17383, G17384, sg__rc_cgen17086.d17186[848]); /* lst2 */ 
    sg__rc_cgen17086.d17186[853] = G17383;
  } while (0);
  do {
    /* ((eq? lst lst2) vect) */ 
    SgObject G17385 = SG_NIL, G17386 = SG_NIL;
    SG_APPEND1(G17385, G17386, sg__rc_cgen17086.d17186[853]); /* (eq? lst lst2) */ 
    SG_APPEND1(G17385, G17386, sg__rc_cgen17086.d17186[744]); /* vect */ 
    sg__rc_cgen17086.d17186[852] = G17385;
  } while (0);
  do {
    /* (- end start) */ 
    SgObject G17387 = SG_NIL, G17388 = SG_NIL;
    SG_APPEND1(G17387, G17388, sg__rc_cgen17086.d17186[803]); /* - */ 
    SG_APPEND1(G17387, G17388, sg__rc_cgen17086.d17186[747]); /* end */ 
    SG_APPEND1(G17387, G17388, sg__rc_cgen17086.d17186[815]); /* start */ 
    sg__rc_cgen17086.d17186[856] = G17387;
  } while (0);
  do {
    /* (= (- end start) len) */ 
    SgObject G17389 = SG_NIL, G17390 = SG_NIL;
    SG_APPEND1(G17389, G17390, sg__rc_cgen17086.d17186[384]); /* = */ 
    SG_APPEND1(G17389, G17390, sg__rc_cgen17086.d17186[856]); /* (- end start) */ 
    SG_APPEND1(G17389, G17390, sg__rc_cgen17086.d17186[741]); /* len */ 
    sg__rc_cgen17086.d17186[855] = G17389;
  } while (0);
  do {
    /* (list->vector lst2) */ 
    SgObject G17391 = SG_NIL, G17392 = SG_NIL;
    SG_APPEND1(G17391, G17392, sg__rc_cgen17086.d17186[7]); /* list->vector */ 
    SG_APPEND1(G17391, G17392, sg__rc_cgen17086.d17186[848]); /* lst2 */ 
    sg__rc_cgen17086.d17186[857] = G17391;
  } while (0);
  do {
    /* ((= (- end start) len) (list->vector lst2)) */ 
    SgObject G17393 = SG_NIL, G17394 = SG_NIL;
    SG_APPEND1(G17393, G17394, sg__rc_cgen17086.d17186[855]); /* (= (- end start) len) */ 
    SG_APPEND1(G17393, G17394, sg__rc_cgen17086.d17186[857]); /* (list->vector lst2) */ 
    sg__rc_cgen17086.d17186[854] = G17393;
  } while (0);
  sg__rc_cgen17086.d17186[863] = SG_MAKE_STRING("v");
  sg__rc_cgen17086.d17186[862] = Sg_Intern(sg__rc_cgen17086.d17186[863]); /* v */
  sg__rc_cgen17086.d17186[866] = SG_MAKE_STRING("make-vector");
  sg__rc_cgen17086.d17186[865] = Sg_Intern(sg__rc_cgen17086.d17186[866]); /* make-vector */
  do {
    /* (make-vector len) */ 
    SgObject G17395 = SG_NIL, G17396 = SG_NIL;
    SG_APPEND1(G17395, G17396, sg__rc_cgen17086.d17186[865]); /* make-vector */ 
    SG_APPEND1(G17395, G17396, sg__rc_cgen17086.d17186[741]); /* len */ 
    sg__rc_cgen17086.d17186[864] = G17395;
  } while (0);
  do {
    /* (v (make-vector len)) */ 
    SgObject G17397 = SG_NIL, G17398 = SG_NIL;
    SG_APPEND1(G17397, G17398, sg__rc_cgen17086.d17186[862]); /* v */ 
    SG_APPEND1(G17397, G17398, sg__rc_cgen17086.d17186[864]); /* (make-vector len) */ 
    sg__rc_cgen17086.d17186[861] = G17397;
  } while (0);
  do {
    /* ((v (make-vector len))) */ 
    SgObject G17399 = SG_NIL, G17400 = SG_NIL;
    SG_APPEND1(G17399, G17400, sg__rc_cgen17086.d17186[861]); /* (v (make-vector len)) */ 
    sg__rc_cgen17086.d17186[860] = G17399;
  } while (0);
  do {
    /* (vector-copy! vect 0 v 0 start) */ 
    SgObject G17401 = SG_NIL, G17402 = SG_NIL;
    SG_APPEND1(G17401, G17402, sg__rc_cgen17086.d17186[756]); /* vector-copy! */ 
    SG_APPEND1(G17401, G17402, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17401, G17402, SG_MAKE_INT(0)); /* 0 */ 
    SG_APPEND1(G17401, G17402, sg__rc_cgen17086.d17186[862]); /* v */ 
    SG_APPEND1(G17401, G17402, SG_MAKE_INT(0)); /* 0 */ 
    SG_APPEND1(G17401, G17402, sg__rc_cgen17086.d17186[815]); /* start */ 
    sg__rc_cgen17086.d17186[867] = G17401;
  } while (0);
  do {
    /* (i start (+ i 1)) */ 
    SgObject G17403 = SG_NIL, G17404 = SG_NIL;
    SG_APPEND1(G17403, G17404, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17403, G17404, sg__rc_cgen17086.d17186[815]); /* start */ 
    SG_APPEND1(G17403, G17404, sg__rc_cgen17086.d17186[779]); /* (+ i 1) */ 
    sg__rc_cgen17086.d17186[870] = G17403;
  } while (0);
  sg__rc_cgen17086.d17186[873] = SG_MAKE_STRING("l");
  sg__rc_cgen17086.d17186[872] = Sg_Intern(sg__rc_cgen17086.d17186[873]); /* l */
  do {
    /* (cdr l) */ 
    SgObject G17405 = SG_NIL, G17406 = SG_NIL;
    SG_APPEND1(G17405, G17406, sg__rc_cgen17086.d17186[226]); /* cdr */ 
    SG_APPEND1(G17405, G17406, sg__rc_cgen17086.d17186[872]); /* l */ 
    sg__rc_cgen17086.d17186[874] = G17405;
  } while (0);
  do {
    /* (l lst2 (cdr l)) */ 
    SgObject G17407 = SG_NIL, G17408 = SG_NIL;
    SG_APPEND1(G17407, G17408, sg__rc_cgen17086.d17186[872]); /* l */ 
    SG_APPEND1(G17407, G17408, sg__rc_cgen17086.d17186[848]); /* lst2 */ 
    SG_APPEND1(G17407, G17408, sg__rc_cgen17086.d17186[874]); /* (cdr l) */ 
    sg__rc_cgen17086.d17186[871] = G17407;
  } while (0);
  do {
    /* ((i start (+ i 1)) (l lst2 (cdr l))) */ 
    SgObject G17409 = SG_NIL, G17410 = SG_NIL;
    SG_APPEND1(G17409, G17410, sg__rc_cgen17086.d17186[870]); /* (i start (+ i 1)) */ 
    SG_APPEND1(G17409, G17410, sg__rc_cgen17086.d17186[871]); /* (l lst2 (cdr l)) */ 
    sg__rc_cgen17086.d17186[869] = G17409;
  } while (0);
  do {
    /* (null? l) */ 
    SgObject G17411 = SG_NIL, G17412 = SG_NIL;
    SG_APPEND1(G17411, G17412, sg__rc_cgen17086.d17186[291]); /* null? */ 
    SG_APPEND1(G17411, G17412, sg__rc_cgen17086.d17186[872]); /* l */ 
    sg__rc_cgen17086.d17186[876] = G17411;
  } while (0);
  do {
    /* ((null? l)) */ 
    SgObject G17413 = SG_NIL, G17414 = SG_NIL;
    SG_APPEND1(G17413, G17414, sg__rc_cgen17086.d17186[876]); /* (null? l) */ 
    sg__rc_cgen17086.d17186[875] = G17413;
  } while (0);
  do {
    /* (car l) */ 
    SgObject G17415 = SG_NIL, G17416 = SG_NIL;
    SG_APPEND1(G17415, G17416, sg__rc_cgen17086.d17186[222]); /* car */ 
    SG_APPEND1(G17415, G17416, sg__rc_cgen17086.d17186[872]); /* l */ 
    sg__rc_cgen17086.d17186[878] = G17415;
  } while (0);
  do {
    /* (vector-set! v i (car l)) */ 
    SgObject G17417 = SG_NIL, G17418 = SG_NIL;
    SG_APPEND1(G17417, G17418, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17417, G17418, sg__rc_cgen17086.d17186[862]); /* v */ 
    SG_APPEND1(G17417, G17418, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17417, G17418, sg__rc_cgen17086.d17186[878]); /* (car l) */ 
    sg__rc_cgen17086.d17186[877] = G17417;
  } while (0);
  do {
    /* (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) */ 
    SgObject G17419 = SG_NIL, G17420 = SG_NIL;
    SG_APPEND1(G17419, G17420, sg__rc_cgen17086.d17186[773]); /* do */ 
    SG_APPEND1(G17419, G17420, sg__rc_cgen17086.d17186[869]); /* ((i start (+ i 1)) (l lst2 (cdr l))) */ 
    SG_APPEND1(G17419, G17420, sg__rc_cgen17086.d17186[875]); /* ((null? l)) */ 
    SG_APPEND1(G17419, G17420, sg__rc_cgen17086.d17186[877]); /* (vector-set! v i (car l)) */ 
    sg__rc_cgen17086.d17186[868] = G17419;
  } while (0);
  do {
    /* (- len end) */ 
    SgObject G17421 = SG_NIL, G17422 = SG_NIL;
    SG_APPEND1(G17421, G17422, sg__rc_cgen17086.d17186[803]); /* - */ 
    SG_APPEND1(G17421, G17422, sg__rc_cgen17086.d17186[741]); /* len */ 
    SG_APPEND1(G17421, G17422, sg__rc_cgen17086.d17186[747]); /* end */ 
    sg__rc_cgen17086.d17186[880] = G17421;
  } while (0);
  do {
    /* (vector-copy! vect end v end (- len end)) */ 
    SgObject G17423 = SG_NIL, G17424 = SG_NIL;
    SG_APPEND1(G17423, G17424, sg__rc_cgen17086.d17186[756]); /* vector-copy! */ 
    SG_APPEND1(G17423, G17424, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17423, G17424, sg__rc_cgen17086.d17186[747]); /* end */ 
    SG_APPEND1(G17423, G17424, sg__rc_cgen17086.d17186[862]); /* v */ 
    SG_APPEND1(G17423, G17424, sg__rc_cgen17086.d17186[747]); /* end */ 
    SG_APPEND1(G17423, G17424, sg__rc_cgen17086.d17186[880]); /* (- len end) */ 
    sg__rc_cgen17086.d17186[879] = G17423;
  } while (0);
  do {
    /* (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end))) */ 
    SgObject G17425 = SG_NIL, G17426 = SG_NIL;
    SG_APPEND1(G17425, G17426, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17425, G17426, sg__rc_cgen17086.d17186[860]); /* ((v (make-vector len))) */ 
    SG_APPEND1(G17425, G17426, sg__rc_cgen17086.d17186[867]); /* (vector-copy! vect 0 v 0 start) */ 
    SG_APPEND1(G17425, G17426, sg__rc_cgen17086.d17186[868]); /* (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) */ 
    SG_APPEND1(G17425, G17426, sg__rc_cgen17086.d17186[879]); /* (vector-copy! vect end v end (- len end)) */ 
    sg__rc_cgen17086.d17186[859] = G17425;
  } while (0);
  do {
    /* (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end)))) */ 
    SgObject G17427 = SG_NIL, G17428 = SG_NIL;
    SG_APPEND1(G17427, G17428, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17427, G17428, sg__rc_cgen17086.d17186[859]); /* (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end))) */ 
    sg__rc_cgen17086.d17186[858] = G17427;
  } while (0);
  do {
    /* (cond ((eq? lst lst2) vect) ((= (- end start) len) (list->vector lst2)) (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end))))) */ 
    SgObject G17429 = SG_NIL, G17430 = SG_NIL;
    SG_APPEND1(G17429, G17430, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17429, G17430, sg__rc_cgen17086.d17186[852]); /* ((eq? lst lst2) vect) */ 
    SG_APPEND1(G17429, G17430, sg__rc_cgen17086.d17186[854]); /* ((= (- end start) len) (list->vector lst2)) */ 
    SG_APPEND1(G17429, G17430, sg__rc_cgen17086.d17186[858]); /* (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end)))) */ 
    sg__rc_cgen17086.d17186[851] = G17429;
  } while (0);
  do {
    /* (let* ((lst (vector->list vect start end)) (lst2 (list-sort proc lst))) (cond ((eq? lst lst2) vect) ((= (- end start) len) (list->vector lst2)) (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end)))))) */ 
    SgObject G17431 = SG_NIL, G17432 = SG_NIL;
    SG_APPEND1(G17431, G17432, sg__rc_cgen17086.d17186[838]); /* let* */ 
    SG_APPEND1(G17431, G17432, sg__rc_cgen17086.d17186[840]); /* ((lst (vector->list vect start end)) (lst2 (list-sort proc lst))) */ 
    SG_APPEND1(G17431, G17432, sg__rc_cgen17086.d17186[851]); /* (cond ((eq? lst lst2) vect) ((= (- end start) len) (list->vector lst2)) (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end))))) */ 
    sg__rc_cgen17086.d17186[837] = G17431;
  } while (0);
  do {
    /* ((define len (vector-length vect)) (define end (or maybe-end len)) (define (vector-copy! src src-from dst dst-from size) (if (<= dst-from src-from) (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))))) (when (or (negative? start) (negative? end)) (assertion-violation 'vector-sort! "start and end must be positive" start vect)) (when (or (> start len) (> end len)) (assertion-violation 'vector-sort! "out of range" (list (list start end) len) vect)) (when (> start end) (assertion-violation 'vector-sort! "start is greater than end" (list start end) vect)) (let* ((lst (vector->list vect start end)) (lst2 (list-sort proc lst))) (cond ((eq? lst lst2) vect) ((= (- end start) len) (list->vector lst2)) (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end))))))) */ 
    SgObject G17433 = SG_NIL, G17434 = SG_NIL;
    SG_APPEND1(G17433, G17434, sg__rc_cgen17086.d17186[740]); /* (define len (vector-length vect)) */ 
    SG_APPEND1(G17433, G17434, sg__rc_cgen17086.d17186[746]); /* (define end (or maybe-end len)) */ 
    SG_APPEND1(G17433, G17434, sg__rc_cgen17086.d17186[754]); /* (define (vector-copy! src src-from dst dst-from size) (if (<= dst-from src-from) (do ((i 0 (+ i 1)) (s src-from (+ s 1)) (d dst-from (+ d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))) (do ((i 0 (+ i 1)) (s (+ src-from size) (- s 1)) (d (+ dst-from size) (- d 1))) ((= i size) dst) (vector-set! dst d (vector-ref src s))))) */ 
    SG_APPEND1(G17433, G17434, sg__rc_cgen17086.d17186[808]); /* (when (or (negative? start) (negative? end)) (assertion-violation 'vector-sort! "start and end must be positive" start vect)) */ 
    SG_APPEND1(G17433, G17434, sg__rc_cgen17086.d17186[823]); /* (when (or (> start len) (> end len)) (assertion-violation 'vector-sort! "out of range" (list (list start end) len) vect)) */ 
    SG_APPEND1(G17433, G17434, sg__rc_cgen17086.d17186[833]); /* (when (> start end) (assertion-violation 'vector-sort! "start is greater than end" (list start end) vect)) */ 
    SG_APPEND1(G17433, G17434, sg__rc_cgen17086.d17186[837]); /* (let* ((lst (vector->list vect start end)) (lst2 (list-sort proc lst))) (cond ((eq? lst lst2) vect) ((= (- end start) len) (list->vector lst2)) (else (let ((v (make-vector len))) (vector-copy! vect 0 v 0 start) (do ((i start (+ i 1)) (l lst2 (cdr l))) ((null? l)) (vector-set! v i (car l))) (vector-copy! vect end v end (- len end)))))) */ 
    sg__rc_cgen17086.d17186[739] = G17433;
  } while (0);
  sg__rc_cgen17086.d17186[881] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[881],SG_SYMBOL(sg__rc_cgen17086.d17186[813]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* negative? */
  sg__rc_cgen17086.d17186[882] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[882],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[883] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[883],SG_SYMBOL(sg__rc_cgen17086.d17186[813]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* negative? */
  sg__rc_cgen17086.d17186[884] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[884],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[885] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[885],SG_SYMBOL(sg__rc_cgen17086.d17186[845]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector->list */
  sg__rc_cgen17086.d17186[886] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[886],SG_SYMBOL(sg__rc_cgen17086.d17186[729]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list-sort */
  sg__rc_cgen17086.d17186[887] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[887],SG_SYMBOL(sg__rc_cgen17086.d17186[7]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* list->vector */
  sg__rc_cgen17086.d17186[888] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[888],SG_SYMBOL(sg__rc_cgen17086.d17186[865]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-vector */
  sg__rc_cgen17086.d17186[890] = SG_MAKE_STRING("vector-sort");
  sg__rc_cgen17086.d17186[889] = Sg_Intern(sg__rc_cgen17086.d17186[890]); /* vector-sort */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[92]))->name = sg__rc_cgen17086.d17186[889];/* vector-sort */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[44] = SG_WORD(sg__rc_cgen17086.d17186[190]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[46] = SG_WORD(sg__rc_cgen17086.d17186[192]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[48] = SG_WORD(sg__rc_cgen17086.d17186[739]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[50] = SG_WORD(sg__rc_cgen17086.d17186[304]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[63] = SG_WORD(sg__rc_cgen17086.d17186[51]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[69] = SG_WORD(sg__rc_cgen17086.d17186[881]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[75] = SG_WORD(sg__rc_cgen17086.d17186[820]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[77] = SG_WORD(sg__rc_cgen17086.d17186[822]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[81] = SG_WORD(sg__rc_cgen17086.d17186[882]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[88] = SG_WORD(sg__rc_cgen17086.d17186[883]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[103] = SG_WORD(sg__rc_cgen17086.d17186[820]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[105] = SG_WORD(sg__rc_cgen17086.d17186[830]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[115] = SG_WORD(sg__rc_cgen17086.d17186[884]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[134] = SG_WORD(sg__rc_cgen17086.d17186[820]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[136] = SG_WORD(sg__rc_cgen17086.d17186[836]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[143] = SG_WORD(sg__rc_cgen17086.d17186[387]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[153] = SG_WORD(sg__rc_cgen17086.d17186[885]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[160] = SG_WORD(sg__rc_cgen17086.d17186[886]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[177] = SG_WORD(sg__rc_cgen17086.d17186[887]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[183] = SG_WORD(sg__rc_cgen17086.d17186[888]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[193] = SG_WORD(sg__rc_cgen17086.d17186[51]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[3986]))[223] = SG_WORD(sg__rc_cgen17086.d17186[51]);
  sg__rc_cgen17086.d17186[891] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[891],SG_SYMBOL(sg__rc_cgen17086.d17186[889]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-sort */
  sg__rc_cgen17086.d17186[897] = SG_MAKE_STRING("n");
  sg__rc_cgen17086.d17186[896] = Sg_Intern(sg__rc_cgen17086.d17186[897]); /* n */
  do {
    /* (n (- end start)) */ 
    SgObject G17435 = SG_NIL, G17436 = SG_NIL;
    SG_APPEND1(G17435, G17436, sg__rc_cgen17086.d17186[896]); /* n */ 
    SG_APPEND1(G17435, G17436, sg__rc_cgen17086.d17186[856]); /* (- end start) */ 
    sg__rc_cgen17086.d17186[895] = G17435;
  } while (0);
  sg__rc_cgen17086.d17186[900] = SG_MAKE_STRING("work");
  sg__rc_cgen17086.d17186[899] = Sg_Intern(sg__rc_cgen17086.d17186[900]); /* work */
  do {
    /* (div n 2) */ 
    SgObject G17437 = SG_NIL, G17438 = SG_NIL;
    SG_APPEND1(G17437, G17438, sg__rc_cgen17086.d17186[735]); /* div */ 
    SG_APPEND1(G17437, G17438, sg__rc_cgen17086.d17186[896]); /* n */ 
    SG_APPEND1(G17437, G17438, SG_MAKE_INT(2U)); /* 2 */ 
    sg__rc_cgen17086.d17186[903] = G17437;
  } while (0);
  do {
    /* (+ (div n 2) 1) */ 
    SgObject G17439 = SG_NIL, G17440 = SG_NIL;
    SG_APPEND1(G17439, G17440, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17439, G17440, sg__rc_cgen17086.d17186[903]); /* (div n 2) */ 
    SG_APPEND1(G17439, G17440, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[902] = G17439;
  } while (0);
  do {
    /* (make-vector (+ (div n 2) 1)) */ 
    SgObject G17441 = SG_NIL, G17442 = SG_NIL;
    SG_APPEND1(G17441, G17442, sg__rc_cgen17086.d17186[865]); /* make-vector */ 
    SG_APPEND1(G17441, G17442, sg__rc_cgen17086.d17186[902]); /* (+ (div n 2) 1) */ 
    sg__rc_cgen17086.d17186[901] = G17441;
  } while (0);
  do {
    /* (work (make-vector (+ (div n 2) 1))) */ 
    SgObject G17443 = SG_NIL, G17444 = SG_NIL;
    SG_APPEND1(G17443, G17444, sg__rc_cgen17086.d17186[899]); /* work */ 
    SG_APPEND1(G17443, G17444, sg__rc_cgen17086.d17186[901]); /* (make-vector (+ (div n 2) 1)) */ 
    sg__rc_cgen17086.d17186[898] = G17443;
  } while (0);
  do {
    /* ((n (- end start)) (work (make-vector (+ (div n 2) 1)))) */ 
    SgObject G17445 = SG_NIL, G17446 = SG_NIL;
    SG_APPEND1(G17445, G17446, sg__rc_cgen17086.d17186[895]); /* (n (- end start)) */ 
    SG_APPEND1(G17445, G17446, sg__rc_cgen17086.d17186[898]); /* (work (make-vector (+ (div n 2) 1))) */ 
    sg__rc_cgen17086.d17186[894] = G17445;
  } while (0);
  sg__rc_cgen17086.d17186[907] = SG_MAKE_STRING("simple-sort!");
  sg__rc_cgen17086.d17186[906] = Sg_Intern(sg__rc_cgen17086.d17186[907]); /* simple-sort! */
  sg__rc_cgen17086.d17186[909] = SG_MAKE_STRING("first");
  sg__rc_cgen17086.d17186[908] = Sg_Intern(sg__rc_cgen17086.d17186[909]); /* first */
  sg__rc_cgen17086.d17186[911] = SG_MAKE_STRING("last");
  sg__rc_cgen17086.d17186[910] = Sg_Intern(sg__rc_cgen17086.d17186[911]); /* last */
  do {
    /* (simple-sort! first last) */ 
    SgObject G17447 = SG_NIL, G17448 = SG_NIL;
    SG_APPEND1(G17447, G17448, sg__rc_cgen17086.d17186[906]); /* simple-sort! */ 
    SG_APPEND1(G17447, G17448, sg__rc_cgen17086.d17186[908]); /* first */ 
    SG_APPEND1(G17447, G17448, sg__rc_cgen17086.d17186[910]); /* last */ 
    sg__rc_cgen17086.d17186[905] = G17447;
  } while (0);
  sg__rc_cgen17086.d17186[914] = SG_MAKE_STRING("loop1");
  sg__rc_cgen17086.d17186[913] = Sg_Intern(sg__rc_cgen17086.d17186[914]); /* loop1 */
  do {
    /* (i first) */ 
    SgObject G17449 = SG_NIL, G17450 = SG_NIL;
    SG_APPEND1(G17449, G17450, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17449, G17450, sg__rc_cgen17086.d17186[908]); /* first */ 
    sg__rc_cgen17086.d17186[916] = G17449;
  } while (0);
  do {
    /* ((i first)) */ 
    SgObject G17451 = SG_NIL, G17452 = SG_NIL;
    SG_APPEND1(G17451, G17452, sg__rc_cgen17086.d17186[916]); /* (i first) */ 
    sg__rc_cgen17086.d17186[915] = G17451;
  } while (0);
  do {
    /* (< i last) */ 
    SgObject G17453 = SG_NIL, G17454 = SG_NIL;
    SG_APPEND1(G17453, G17454, sg__rc_cgen17086.d17186[564]); /* < */ 
    SG_APPEND1(G17453, G17454, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17453, G17454, sg__rc_cgen17086.d17186[910]); /* last */ 
    sg__rc_cgen17086.d17186[919] = G17453;
  } while (0);
  sg__rc_cgen17086.d17186[924] = SG_MAKE_STRING("m");
  sg__rc_cgen17086.d17186[923] = Sg_Intern(sg__rc_cgen17086.d17186[924]); /* m */
  do {
    /* (vector-ref vect i) */ 
    SgObject G17455 = SG_NIL, G17456 = SG_NIL;
    SG_APPEND1(G17455, G17456, sg__rc_cgen17086.d17186[796]); /* vector-ref */ 
    SG_APPEND1(G17455, G17456, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17455, G17456, sg__rc_cgen17086.d17186[777]); /* i */ 
    sg__rc_cgen17086.d17186[925] = G17455;
  } while (0);
  do {
    /* (m (vector-ref vect i)) */ 
    SgObject G17457 = SG_NIL, G17458 = SG_NIL;
    SG_APPEND1(G17457, G17458, sg__rc_cgen17086.d17186[923]); /* m */ 
    SG_APPEND1(G17457, G17458, sg__rc_cgen17086.d17186[925]); /* (vector-ref vect i) */ 
    sg__rc_cgen17086.d17186[922] = G17457;
  } while (0);
  sg__rc_cgen17086.d17186[928] = SG_MAKE_STRING("k");
  sg__rc_cgen17086.d17186[927] = Sg_Intern(sg__rc_cgen17086.d17186[928]); /* k */
  do {
    /* (k i) */ 
    SgObject G17459 = SG_NIL, G17460 = SG_NIL;
    SG_APPEND1(G17459, G17460, sg__rc_cgen17086.d17186[927]); /* k */ 
    SG_APPEND1(G17459, G17460, sg__rc_cgen17086.d17186[777]); /* i */ 
    sg__rc_cgen17086.d17186[926] = G17459;
  } while (0);
  do {
    /* ((m (vector-ref vect i)) (k i)) */ 
    SgObject G17461 = SG_NIL, G17462 = SG_NIL;
    SG_APPEND1(G17461, G17462, sg__rc_cgen17086.d17186[922]); /* (m (vector-ref vect i)) */ 
    SG_APPEND1(G17461, G17462, sg__rc_cgen17086.d17186[926]); /* (k i) */ 
    sg__rc_cgen17086.d17186[921] = G17461;
  } while (0);
  sg__rc_cgen17086.d17186[931] = SG_MAKE_STRING("loop2");
  sg__rc_cgen17086.d17186[930] = Sg_Intern(sg__rc_cgen17086.d17186[931]); /* loop2 */
  sg__rc_cgen17086.d17186[935] = SG_MAKE_STRING("j");
  sg__rc_cgen17086.d17186[934] = Sg_Intern(sg__rc_cgen17086.d17186[935]); /* j */
  do {
    /* (j (+ i 1)) */ 
    SgObject G17463 = SG_NIL, G17464 = SG_NIL;
    SG_APPEND1(G17463, G17464, sg__rc_cgen17086.d17186[934]); /* j */ 
    SG_APPEND1(G17463, G17464, sg__rc_cgen17086.d17186[779]); /* (+ i 1) */ 
    sg__rc_cgen17086.d17186[933] = G17463;
  } while (0);
  do {
    /* ((j (+ i 1))) */ 
    SgObject G17465 = SG_NIL, G17466 = SG_NIL;
    SG_APPEND1(G17465, G17466, sg__rc_cgen17086.d17186[933]); /* (j (+ i 1)) */ 
    sg__rc_cgen17086.d17186[932] = G17465;
  } while (0);
  do {
    /* (<= j last) */ 
    SgObject G17467 = SG_NIL, G17468 = SG_NIL;
    SG_APPEND1(G17467, G17468, sg__rc_cgen17086.d17186[770]); /* <= */ 
    SG_APPEND1(G17467, G17468, sg__rc_cgen17086.d17186[934]); /* j */ 
    SG_APPEND1(G17467, G17468, sg__rc_cgen17086.d17186[910]); /* last */ 
    sg__rc_cgen17086.d17186[938] = G17467;
  } while (0);
  do {
    /* (vector-ref vect j) */ 
    SgObject G17469 = SG_NIL, G17470 = SG_NIL;
    SG_APPEND1(G17469, G17470, sg__rc_cgen17086.d17186[796]); /* vector-ref */ 
    SG_APPEND1(G17469, G17470, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17469, G17470, sg__rc_cgen17086.d17186[934]); /* j */ 
    sg__rc_cgen17086.d17186[941] = G17469;
  } while (0);
  do {
    /* (proc (vector-ref vect j) m) */ 
    SgObject G17471 = SG_NIL, G17472 = SG_NIL;
    SG_APPEND1(G17471, G17472, sg__rc_cgen17086.d17186[90]); /* proc */ 
    SG_APPEND1(G17471, G17472, sg__rc_cgen17086.d17186[941]); /* (vector-ref vect j) */ 
    SG_APPEND1(G17471, G17472, sg__rc_cgen17086.d17186[923]); /* m */ 
    sg__rc_cgen17086.d17186[940] = G17471;
  } while (0);
  sg__rc_cgen17086.d17186[944] = SG_MAKE_STRING("begin");
  sg__rc_cgen17086.d17186[943] = Sg_Intern(sg__rc_cgen17086.d17186[944]); /* begin */
  sg__rc_cgen17086.d17186[947] = SG_MAKE_STRING("set!");
  sg__rc_cgen17086.d17186[946] = Sg_Intern(sg__rc_cgen17086.d17186[947]); /* set! */
  do {
    /* (set! m (vector-ref vect j)) */ 
    SgObject G17473 = SG_NIL, G17474 = SG_NIL;
    SG_APPEND1(G17473, G17474, sg__rc_cgen17086.d17186[946]); /* set! */ 
    SG_APPEND1(G17473, G17474, sg__rc_cgen17086.d17186[923]); /* m */ 
    SG_APPEND1(G17473, G17474, sg__rc_cgen17086.d17186[941]); /* (vector-ref vect j) */ 
    sg__rc_cgen17086.d17186[945] = G17473;
  } while (0);
  do {
    /* (set! k j) */ 
    SgObject G17475 = SG_NIL, G17476 = SG_NIL;
    SG_APPEND1(G17475, G17476, sg__rc_cgen17086.d17186[946]); /* set! */ 
    SG_APPEND1(G17475, G17476, sg__rc_cgen17086.d17186[927]); /* k */ 
    SG_APPEND1(G17475, G17476, sg__rc_cgen17086.d17186[934]); /* j */ 
    sg__rc_cgen17086.d17186[948] = G17475;
  } while (0);
  do {
    /* (begin (set! m (vector-ref vect j)) (set! k j)) */ 
    SgObject G17477 = SG_NIL, G17478 = SG_NIL;
    SG_APPEND1(G17477, G17478, sg__rc_cgen17086.d17186[943]); /* begin */ 
    SG_APPEND1(G17477, G17478, sg__rc_cgen17086.d17186[945]); /* (set! m (vector-ref vect j)) */ 
    SG_APPEND1(G17477, G17478, sg__rc_cgen17086.d17186[948]); /* (set! k j) */ 
    sg__rc_cgen17086.d17186[942] = G17477;
  } while (0);
  do {
    /* (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) */ 
    SgObject G17479 = SG_NIL, G17480 = SG_NIL;
    SG_APPEND1(G17479, G17480, sg__rc_cgen17086.d17186[212]); /* if */ 
    SG_APPEND1(G17479, G17480, sg__rc_cgen17086.d17186[940]); /* (proc (vector-ref vect j) m) */ 
    SG_APPEND1(G17479, G17480, sg__rc_cgen17086.d17186[942]); /* (begin (set! m (vector-ref vect j)) (set! k j)) */ 
    sg__rc_cgen17086.d17186[939] = G17479;
  } while (0);
  do {
    /* (+ j 1) */ 
    SgObject G17481 = SG_NIL, G17482 = SG_NIL;
    SG_APPEND1(G17481, G17482, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17481, G17482, sg__rc_cgen17086.d17186[934]); /* j */ 
    SG_APPEND1(G17481, G17482, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[950] = G17481;
  } while (0);
  do {
    /* (loop2 (+ j 1)) */ 
    SgObject G17483 = SG_NIL, G17484 = SG_NIL;
    SG_APPEND1(G17483, G17484, sg__rc_cgen17086.d17186[930]); /* loop2 */ 
    SG_APPEND1(G17483, G17484, sg__rc_cgen17086.d17186[950]); /* (+ j 1) */ 
    sg__rc_cgen17086.d17186[949] = G17483;
  } while (0);
  do {
    /* ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) */ 
    SgObject G17485 = SG_NIL, G17486 = SG_NIL;
    SG_APPEND1(G17485, G17486, sg__rc_cgen17086.d17186[938]); /* (<= j last) */ 
    SG_APPEND1(G17485, G17486, sg__rc_cgen17086.d17186[939]); /* (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) */ 
    SG_APPEND1(G17485, G17486, sg__rc_cgen17086.d17186[949]); /* (loop2 (+ j 1)) */ 
    sg__rc_cgen17086.d17186[937] = G17485;
  } while (0);
  do {
    /* (vector-set! vect k (vector-ref vect i)) */ 
    SgObject G17487 = SG_NIL, G17488 = SG_NIL;
    SG_APPEND1(G17487, G17488, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17487, G17488, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17487, G17488, sg__rc_cgen17086.d17186[927]); /* k */ 
    SG_APPEND1(G17487, G17488, sg__rc_cgen17086.d17186[925]); /* (vector-ref vect i) */ 
    sg__rc_cgen17086.d17186[952] = G17487;
  } while (0);
  do {
    /* (vector-set! vect i m) */ 
    SgObject G17489 = SG_NIL, G17490 = SG_NIL;
    SG_APPEND1(G17489, G17490, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17489, G17490, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17489, G17490, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17489, G17490, sg__rc_cgen17086.d17186[923]); /* m */ 
    sg__rc_cgen17086.d17186[953] = G17489;
  } while (0);
  do {
    /* (loop1 (+ i 1)) */ 
    SgObject G17491 = SG_NIL, G17492 = SG_NIL;
    SG_APPEND1(G17491, G17492, sg__rc_cgen17086.d17186[913]); /* loop1 */ 
    SG_APPEND1(G17491, G17492, sg__rc_cgen17086.d17186[779]); /* (+ i 1) */ 
    sg__rc_cgen17086.d17186[954] = G17491;
  } while (0);
  do {
    /* (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))) */ 
    SgObject G17493 = SG_NIL, G17494 = SG_NIL;
    SG_APPEND1(G17493, G17494, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17493, G17494, sg__rc_cgen17086.d17186[952]); /* (vector-set! vect k (vector-ref vect i)) */ 
    SG_APPEND1(G17493, G17494, sg__rc_cgen17086.d17186[953]); /* (vector-set! vect i m) */ 
    SG_APPEND1(G17493, G17494, sg__rc_cgen17086.d17186[954]); /* (loop1 (+ i 1)) */ 
    sg__rc_cgen17086.d17186[951] = G17493;
  } while (0);
  do {
    /* (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))) */ 
    SgObject G17495 = SG_NIL, G17496 = SG_NIL;
    SG_APPEND1(G17495, G17496, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17495, G17496, sg__rc_cgen17086.d17186[937]); /* ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) */ 
    SG_APPEND1(G17495, G17496, sg__rc_cgen17086.d17186[951]); /* (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))) */ 
    sg__rc_cgen17086.d17186[936] = G17495;
  } while (0);
  do {
    /* (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))))) */ 
    SgObject G17497 = SG_NIL, G17498 = SG_NIL;
    SG_APPEND1(G17497, G17498, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17497, G17498, sg__rc_cgen17086.d17186[930]); /* loop2 */ 
    SG_APPEND1(G17497, G17498, sg__rc_cgen17086.d17186[932]); /* ((j (+ i 1))) */ 
    SG_APPEND1(G17497, G17498, sg__rc_cgen17086.d17186[936]); /* (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))) */ 
    sg__rc_cgen17086.d17186[929] = G17497;
  } while (0);
  do {
    /* (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))) */ 
    SgObject G17499 = SG_NIL, G17500 = SG_NIL;
    SG_APPEND1(G17499, G17500, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17499, G17500, sg__rc_cgen17086.d17186[921]); /* ((m (vector-ref vect i)) (k i)) */ 
    SG_APPEND1(G17499, G17500, sg__rc_cgen17086.d17186[929]); /* (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))))) */ 
    sg__rc_cgen17086.d17186[920] = G17499;
  } while (0);
  do {
    /* ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))))))) */ 
    SgObject G17501 = SG_NIL, G17502 = SG_NIL;
    SG_APPEND1(G17501, G17502, sg__rc_cgen17086.d17186[919]); /* (< i last) */ 
    SG_APPEND1(G17501, G17502, sg__rc_cgen17086.d17186[920]); /* (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))) */ 
    sg__rc_cgen17086.d17186[918] = G17501;
  } while (0);
  do {
    /* (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))) */ 
    SgObject G17503 = SG_NIL, G17504 = SG_NIL;
    SG_APPEND1(G17503, G17504, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17503, G17504, sg__rc_cgen17086.d17186[918]); /* ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))))))) */ 
    sg__rc_cgen17086.d17186[917] = G17503;
  } while (0);
  do {
    /* (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))))))))) */ 
    SgObject G17505 = SG_NIL, G17506 = SG_NIL;
    SG_APPEND1(G17505, G17506, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17505, G17506, sg__rc_cgen17086.d17186[913]); /* loop1 */ 
    SG_APPEND1(G17505, G17506, sg__rc_cgen17086.d17186[915]); /* ((i first)) */ 
    SG_APPEND1(G17505, G17506, sg__rc_cgen17086.d17186[917]); /* (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))) */ 
    sg__rc_cgen17086.d17186[912] = G17505;
  } while (0);
  do {
    /* (define (simple-sort! first last) (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))))) */ 
    SgObject G17507 = SG_NIL, G17508 = SG_NIL;
    SG_APPEND1(G17507, G17508, sg__rc_cgen17086.d17186[195]); /* define */ 
    SG_APPEND1(G17507, G17508, sg__rc_cgen17086.d17186[905]); /* (simple-sort! first last) */ 
    SG_APPEND1(G17507, G17508, sg__rc_cgen17086.d17186[912]); /* (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1))))))))) */ 
    sg__rc_cgen17086.d17186[904] = G17507;
  } while (0);
  sg__rc_cgen17086.d17186[958] = SG_MAKE_STRING("sort!");
  sg__rc_cgen17086.d17186[957] = Sg_Intern(sg__rc_cgen17086.d17186[958]); /* sort! */
  do {
    /* (sort! first last) */ 
    SgObject G17509 = SG_NIL, G17510 = SG_NIL;
    SG_APPEND1(G17509, G17510, sg__rc_cgen17086.d17186[957]); /* sort! */ 
    SG_APPEND1(G17509, G17510, sg__rc_cgen17086.d17186[908]); /* first */ 
    SG_APPEND1(G17509, G17510, sg__rc_cgen17086.d17186[910]); /* last */ 
    sg__rc_cgen17086.d17186[956] = G17509;
  } while (0);
  do {
    /* (- last first) */ 
    SgObject G17511 = SG_NIL, G17512 = SG_NIL;
    SG_APPEND1(G17511, G17512, sg__rc_cgen17086.d17186[803]); /* - */ 
    SG_APPEND1(G17511, G17512, sg__rc_cgen17086.d17186[910]); /* last */ 
    SG_APPEND1(G17511, G17512, sg__rc_cgen17086.d17186[908]); /* first */ 
    sg__rc_cgen17086.d17186[962] = G17511;
  } while (0);
  do {
    /* (> (- last first) 10) */ 
    SgObject G17513 = SG_NIL, G17514 = SG_NIL;
    SG_APPEND1(G17513, G17514, sg__rc_cgen17086.d17186[826]); /* > */ 
    SG_APPEND1(G17513, G17514, sg__rc_cgen17086.d17186[962]); /* (- last first) */ 
    SG_APPEND1(G17513, G17514, SG_MAKE_INT(10U)); /* 10 */ 
    sg__rc_cgen17086.d17186[961] = G17513;
  } while (0);
  sg__rc_cgen17086.d17186[967] = SG_MAKE_STRING("middle");
  sg__rc_cgen17086.d17186[966] = Sg_Intern(sg__rc_cgen17086.d17186[967]); /* middle */
  do {
    /* (+ first last) */ 
    SgObject G17515 = SG_NIL, G17516 = SG_NIL;
    SG_APPEND1(G17515, G17516, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17515, G17516, sg__rc_cgen17086.d17186[908]); /* first */ 
    SG_APPEND1(G17515, G17516, sg__rc_cgen17086.d17186[910]); /* last */ 
    sg__rc_cgen17086.d17186[969] = G17515;
  } while (0);
  do {
    /* (div (+ first last) 2) */ 
    SgObject G17517 = SG_NIL, G17518 = SG_NIL;
    SG_APPEND1(G17517, G17518, sg__rc_cgen17086.d17186[735]); /* div */ 
    SG_APPEND1(G17517, G17518, sg__rc_cgen17086.d17186[969]); /* (+ first last) */ 
    SG_APPEND1(G17517, G17518, SG_MAKE_INT(2U)); /* 2 */ 
    sg__rc_cgen17086.d17186[968] = G17517;
  } while (0);
  do {
    /* (middle (div (+ first last) 2)) */ 
    SgObject G17519 = SG_NIL, G17520 = SG_NIL;
    SG_APPEND1(G17519, G17520, sg__rc_cgen17086.d17186[966]); /* middle */ 
    SG_APPEND1(G17519, G17520, sg__rc_cgen17086.d17186[968]); /* (div (+ first last) 2) */ 
    sg__rc_cgen17086.d17186[965] = G17519;
  } while (0);
  do {
    /* ((middle (div (+ first last) 2))) */ 
    SgObject G17521 = SG_NIL, G17522 = SG_NIL;
    SG_APPEND1(G17521, G17522, sg__rc_cgen17086.d17186[965]); /* (middle (div (+ first last) 2)) */ 
    sg__rc_cgen17086.d17186[964] = G17521;
  } while (0);
  do {
    /* (sort! first middle) */ 
    SgObject G17523 = SG_NIL, G17524 = SG_NIL;
    SG_APPEND1(G17523, G17524, sg__rc_cgen17086.d17186[957]); /* sort! */ 
    SG_APPEND1(G17523, G17524, sg__rc_cgen17086.d17186[908]); /* first */ 
    SG_APPEND1(G17523, G17524, sg__rc_cgen17086.d17186[966]); /* middle */ 
    sg__rc_cgen17086.d17186[970] = G17523;
  } while (0);
  do {
    /* (+ middle 1) */ 
    SgObject G17525 = SG_NIL, G17526 = SG_NIL;
    SG_APPEND1(G17525, G17526, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17525, G17526, sg__rc_cgen17086.d17186[966]); /* middle */ 
    SG_APPEND1(G17525, G17526, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[972] = G17525;
  } while (0);
  do {
    /* (sort! (+ middle 1) last) */ 
    SgObject G17527 = SG_NIL, G17528 = SG_NIL;
    SG_APPEND1(G17527, G17528, sg__rc_cgen17086.d17186[957]); /* sort! */ 
    SG_APPEND1(G17527, G17528, sg__rc_cgen17086.d17186[972]); /* (+ middle 1) */ 
    SG_APPEND1(G17527, G17528, sg__rc_cgen17086.d17186[910]); /* last */ 
    sg__rc_cgen17086.d17186[971] = G17527;
  } while (0);
  sg__rc_cgen17086.d17186[977] = SG_MAKE_STRING("p2size");
  sg__rc_cgen17086.d17186[976] = Sg_Intern(sg__rc_cgen17086.d17186[977]); /* p2size */
  do {
    /* (p2size 0) */ 
    SgObject G17529 = SG_NIL, G17530 = SG_NIL;
    SG_APPEND1(G17529, G17530, sg__rc_cgen17086.d17186[976]); /* p2size */ 
    SG_APPEND1(G17529, G17530, SG_MAKE_INT(0)); /* 0 */ 
    sg__rc_cgen17086.d17186[975] = G17529;
  } while (0);
  do {
    /* ((i first) (p2size 0)) */ 
    SgObject G17531 = SG_NIL, G17532 = SG_NIL;
    SG_APPEND1(G17531, G17532, sg__rc_cgen17086.d17186[916]); /* (i first) */ 
    SG_APPEND1(G17531, G17532, sg__rc_cgen17086.d17186[975]); /* (p2size 0) */ 
    sg__rc_cgen17086.d17186[974] = G17531;
  } while (0);
  do {
    /* (> i middle) */ 
    SgObject G17533 = SG_NIL, G17534 = SG_NIL;
    SG_APPEND1(G17533, G17534, sg__rc_cgen17086.d17186[826]); /* > */ 
    SG_APPEND1(G17533, G17534, sg__rc_cgen17086.d17186[777]); /* i */ 
    SG_APPEND1(G17533, G17534, sg__rc_cgen17086.d17186[966]); /* middle */ 
    sg__rc_cgen17086.d17186[980] = G17533;
  } while (0);
  sg__rc_cgen17086.d17186[985] = SG_MAKE_STRING("p1");
  sg__rc_cgen17086.d17186[984] = Sg_Intern(sg__rc_cgen17086.d17186[985]); /* p1 */
  do {
    /* (p1 (+ middle 1)) */ 
    SgObject G17535 = SG_NIL, G17536 = SG_NIL;
    SG_APPEND1(G17535, G17536, sg__rc_cgen17086.d17186[984]); /* p1 */ 
    SG_APPEND1(G17535, G17536, sg__rc_cgen17086.d17186[972]); /* (+ middle 1) */ 
    sg__rc_cgen17086.d17186[983] = G17535;
  } while (0);
  sg__rc_cgen17086.d17186[988] = SG_MAKE_STRING("p2");
  sg__rc_cgen17086.d17186[987] = Sg_Intern(sg__rc_cgen17086.d17186[988]); /* p2 */
  do {
    /* (p2 0) */ 
    SgObject G17537 = SG_NIL, G17538 = SG_NIL;
    SG_APPEND1(G17537, G17538, sg__rc_cgen17086.d17186[987]); /* p2 */ 
    SG_APPEND1(G17537, G17538, SG_MAKE_INT(0)); /* 0 */ 
    sg__rc_cgen17086.d17186[986] = G17537;
  } while (0);
  sg__rc_cgen17086.d17186[991] = SG_MAKE_STRING("p3");
  sg__rc_cgen17086.d17186[990] = Sg_Intern(sg__rc_cgen17086.d17186[991]); /* p3 */
  do {
    /* (p3 first) */ 
    SgObject G17539 = SG_NIL, G17540 = SG_NIL;
    SG_APPEND1(G17539, G17540, sg__rc_cgen17086.d17186[990]); /* p3 */ 
    SG_APPEND1(G17539, G17540, sg__rc_cgen17086.d17186[908]); /* first */ 
    sg__rc_cgen17086.d17186[989] = G17539;
  } while (0);
  do {
    /* ((p1 (+ middle 1)) (p2 0) (p3 first)) */ 
    SgObject G17541 = SG_NIL, G17542 = SG_NIL;
    SG_APPEND1(G17541, G17542, sg__rc_cgen17086.d17186[983]); /* (p1 (+ middle 1)) */ 
    SG_APPEND1(G17541, G17542, sg__rc_cgen17086.d17186[986]); /* (p2 0) */ 
    SG_APPEND1(G17541, G17542, sg__rc_cgen17086.d17186[989]); /* (p3 first) */ 
    sg__rc_cgen17086.d17186[982] = G17541;
  } while (0);
  sg__rc_cgen17086.d17186[996] = SG_MAKE_STRING("and");
  sg__rc_cgen17086.d17186[995] = Sg_Intern(sg__rc_cgen17086.d17186[996]); /* and */
  do {
    /* (<= p1 last) */ 
    SgObject G17543 = SG_NIL, G17544 = SG_NIL;
    SG_APPEND1(G17543, G17544, sg__rc_cgen17086.d17186[770]); /* <= */ 
    SG_APPEND1(G17543, G17544, sg__rc_cgen17086.d17186[984]); /* p1 */ 
    SG_APPEND1(G17543, G17544, sg__rc_cgen17086.d17186[910]); /* last */ 
    sg__rc_cgen17086.d17186[997] = G17543;
  } while (0);
  do {
    /* (< p2 p2size) */ 
    SgObject G17545 = SG_NIL, G17546 = SG_NIL;
    SG_APPEND1(G17545, G17546, sg__rc_cgen17086.d17186[564]); /* < */ 
    SG_APPEND1(G17545, G17546, sg__rc_cgen17086.d17186[987]); /* p2 */ 
    SG_APPEND1(G17545, G17546, sg__rc_cgen17086.d17186[976]); /* p2size */ 
    sg__rc_cgen17086.d17186[998] = G17545;
  } while (0);
  do {
    /* (and (<= p1 last) (< p2 p2size)) */ 
    SgObject G17547 = SG_NIL, G17548 = SG_NIL;
    SG_APPEND1(G17547, G17548, sg__rc_cgen17086.d17186[995]); /* and */ 
    SG_APPEND1(G17547, G17548, sg__rc_cgen17086.d17186[997]); /* (<= p1 last) */ 
    SG_APPEND1(G17547, G17548, sg__rc_cgen17086.d17186[998]); /* (< p2 p2size) */ 
    sg__rc_cgen17086.d17186[994] = G17547;
  } while (0);
  do {
    /* (vector-ref work p2) */ 
    SgObject G17549 = SG_NIL, G17550 = SG_NIL;
    SG_APPEND1(G17549, G17550, sg__rc_cgen17086.d17186[796]); /* vector-ref */ 
    SG_APPEND1(G17549, G17550, sg__rc_cgen17086.d17186[899]); /* work */ 
    SG_APPEND1(G17549, G17550, sg__rc_cgen17086.d17186[987]); /* p2 */ 
    sg__rc_cgen17086.d17186[1002] = G17549;
  } while (0);
  do {
    /* (vector-ref vect p1) */ 
    SgObject G17551 = SG_NIL, G17552 = SG_NIL;
    SG_APPEND1(G17551, G17552, sg__rc_cgen17086.d17186[796]); /* vector-ref */ 
    SG_APPEND1(G17551, G17552, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17551, G17552, sg__rc_cgen17086.d17186[984]); /* p1 */ 
    sg__rc_cgen17086.d17186[1003] = G17551;
  } while (0);
  do {
    /* (proc (vector-ref work p2) (vector-ref vect p1)) */ 
    SgObject G17553 = SG_NIL, G17554 = SG_NIL;
    SG_APPEND1(G17553, G17554, sg__rc_cgen17086.d17186[90]); /* proc */ 
    SG_APPEND1(G17553, G17554, sg__rc_cgen17086.d17186[1002]); /* (vector-ref work p2) */ 
    SG_APPEND1(G17553, G17554, sg__rc_cgen17086.d17186[1003]); /* (vector-ref vect p1) */ 
    sg__rc_cgen17086.d17186[1001] = G17553;
  } while (0);
  do {
    /* (vector-set! vect p3 (vector-ref work p2)) */ 
    SgObject G17555 = SG_NIL, G17556 = SG_NIL;
    SG_APPEND1(G17555, G17556, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17555, G17556, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17555, G17556, sg__rc_cgen17086.d17186[990]); /* p3 */ 
    SG_APPEND1(G17555, G17556, sg__rc_cgen17086.d17186[1002]); /* (vector-ref work p2) */ 
    sg__rc_cgen17086.d17186[1004] = G17555;
  } while (0);
  do {
    /* (+ p2 1) */ 
    SgObject G17557 = SG_NIL, G17558 = SG_NIL;
    SG_APPEND1(G17557, G17558, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17557, G17558, sg__rc_cgen17086.d17186[987]); /* p2 */ 
    SG_APPEND1(G17557, G17558, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[1006] = G17557;
  } while (0);
  do {
    /* (+ p3 1) */ 
    SgObject G17559 = SG_NIL, G17560 = SG_NIL;
    SG_APPEND1(G17559, G17560, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17559, G17560, sg__rc_cgen17086.d17186[990]); /* p3 */ 
    SG_APPEND1(G17559, G17560, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[1007] = G17559;
  } while (0);
  do {
    /* (loop p1 (+ p2 1) (+ p3 1)) */ 
    SgObject G17561 = SG_NIL, G17562 = SG_NIL;
    SG_APPEND1(G17561, G17562, sg__rc_cgen17086.d17186[636]); /* loop */ 
    SG_APPEND1(G17561, G17562, sg__rc_cgen17086.d17186[984]); /* p1 */ 
    SG_APPEND1(G17561, G17562, sg__rc_cgen17086.d17186[1006]); /* (+ p2 1) */ 
    SG_APPEND1(G17561, G17562, sg__rc_cgen17086.d17186[1007]); /* (+ p3 1) */ 
    sg__rc_cgen17086.d17186[1005] = G17561;
  } while (0);
  do {
    /* ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) */ 
    SgObject G17563 = SG_NIL, G17564 = SG_NIL;
    SG_APPEND1(G17563, G17564, sg__rc_cgen17086.d17186[1001]); /* (proc (vector-ref work p2) (vector-ref vect p1)) */ 
    SG_APPEND1(G17563, G17564, sg__rc_cgen17086.d17186[1004]); /* (vector-set! vect p3 (vector-ref work p2)) */ 
    SG_APPEND1(G17563, G17564, sg__rc_cgen17086.d17186[1005]); /* (loop p1 (+ p2 1) (+ p3 1)) */ 
    sg__rc_cgen17086.d17186[1000] = G17563;
  } while (0);
  do {
    /* (vector-set! vect p3 (vector-ref vect p1)) */ 
    SgObject G17565 = SG_NIL, G17566 = SG_NIL;
    SG_APPEND1(G17565, G17566, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17565, G17566, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17565, G17566, sg__rc_cgen17086.d17186[990]); /* p3 */ 
    SG_APPEND1(G17565, G17566, sg__rc_cgen17086.d17186[1003]); /* (vector-ref vect p1) */ 
    sg__rc_cgen17086.d17186[1009] = G17565;
  } while (0);
  do {
    /* (+ p1 1) */ 
    SgObject G17567 = SG_NIL, G17568 = SG_NIL;
    SG_APPEND1(G17567, G17568, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17567, G17568, sg__rc_cgen17086.d17186[984]); /* p1 */ 
    SG_APPEND1(G17567, G17568, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[1011] = G17567;
  } while (0);
  do {
    /* (loop (+ p1 1) p2 (+ p3 1)) */ 
    SgObject G17569 = SG_NIL, G17570 = SG_NIL;
    SG_APPEND1(G17569, G17570, sg__rc_cgen17086.d17186[636]); /* loop */ 
    SG_APPEND1(G17569, G17570, sg__rc_cgen17086.d17186[1011]); /* (+ p1 1) */ 
    SG_APPEND1(G17569, G17570, sg__rc_cgen17086.d17186[987]); /* p2 */ 
    SG_APPEND1(G17569, G17570, sg__rc_cgen17086.d17186[1007]); /* (+ p3 1) */ 
    sg__rc_cgen17086.d17186[1010] = G17569;
  } while (0);
  do {
    /* (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))) */ 
    SgObject G17571 = SG_NIL, G17572 = SG_NIL;
    SG_APPEND1(G17571, G17572, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17571, G17572, sg__rc_cgen17086.d17186[1009]); /* (vector-set! vect p3 (vector-ref vect p1)) */ 
    SG_APPEND1(G17571, G17572, sg__rc_cgen17086.d17186[1010]); /* (loop (+ p1 1) p2 (+ p3 1)) */ 
    sg__rc_cgen17086.d17186[1008] = G17571;
  } while (0);
  do {
    /* (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1)))) */ 
    SgObject G17573 = SG_NIL, G17574 = SG_NIL;
    SG_APPEND1(G17573, G17574, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17573, G17574, sg__rc_cgen17086.d17186[1000]); /* ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) */ 
    SG_APPEND1(G17573, G17574, sg__rc_cgen17086.d17186[1008]); /* (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))) */ 
    sg__rc_cgen17086.d17186[999] = G17573;
  } while (0);
  do {
    /* ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) */ 
    SgObject G17575 = SG_NIL, G17576 = SG_NIL;
    SG_APPEND1(G17575, G17576, sg__rc_cgen17086.d17186[994]); /* (and (<= p1 last) (< p2 p2size)) */ 
    SG_APPEND1(G17575, G17576, sg__rc_cgen17086.d17186[999]); /* (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1)))) */ 
    sg__rc_cgen17086.d17186[993] = G17575;
  } while (0);
  sg__rc_cgen17086.d17186[1017] = SG_MAKE_STRING("s2");
  sg__rc_cgen17086.d17186[1016] = Sg_Intern(sg__rc_cgen17086.d17186[1017]); /* s2 */
  do {
    /* (s2 p2) */ 
    SgObject G17577 = SG_NIL, G17578 = SG_NIL;
    SG_APPEND1(G17577, G17578, sg__rc_cgen17086.d17186[1016]); /* s2 */ 
    SG_APPEND1(G17577, G17578, sg__rc_cgen17086.d17186[987]); /* p2 */ 
    sg__rc_cgen17086.d17186[1015] = G17577;
  } while (0);
  sg__rc_cgen17086.d17186[1020] = SG_MAKE_STRING("d3");
  sg__rc_cgen17086.d17186[1019] = Sg_Intern(sg__rc_cgen17086.d17186[1020]); /* d3 */
  do {
    /* (d3 p3) */ 
    SgObject G17579 = SG_NIL, G17580 = SG_NIL;
    SG_APPEND1(G17579, G17580, sg__rc_cgen17086.d17186[1019]); /* d3 */ 
    SG_APPEND1(G17579, G17580, sg__rc_cgen17086.d17186[990]); /* p3 */ 
    sg__rc_cgen17086.d17186[1018] = G17579;
  } while (0);
  do {
    /* ((s2 p2) (d3 p3)) */ 
    SgObject G17581 = SG_NIL, G17582 = SG_NIL;
    SG_APPEND1(G17581, G17582, sg__rc_cgen17086.d17186[1015]); /* (s2 p2) */ 
    SG_APPEND1(G17581, G17582, sg__rc_cgen17086.d17186[1018]); /* (d3 p3) */ 
    sg__rc_cgen17086.d17186[1014] = G17581;
  } while (0);
  do {
    /* (< s2 p2size) */ 
    SgObject G17583 = SG_NIL, G17584 = SG_NIL;
    SG_APPEND1(G17583, G17584, sg__rc_cgen17086.d17186[564]); /* < */ 
    SG_APPEND1(G17583, G17584, sg__rc_cgen17086.d17186[1016]); /* s2 */ 
    SG_APPEND1(G17583, G17584, sg__rc_cgen17086.d17186[976]); /* p2size */ 
    sg__rc_cgen17086.d17186[1023] = G17583;
  } while (0);
  do {
    /* (vector-ref work s2) */ 
    SgObject G17585 = SG_NIL, G17586 = SG_NIL;
    SG_APPEND1(G17585, G17586, sg__rc_cgen17086.d17186[796]); /* vector-ref */ 
    SG_APPEND1(G17585, G17586, sg__rc_cgen17086.d17186[899]); /* work */ 
    SG_APPEND1(G17585, G17586, sg__rc_cgen17086.d17186[1016]); /* s2 */ 
    sg__rc_cgen17086.d17186[1025] = G17585;
  } while (0);
  do {
    /* (vector-set! vect d3 (vector-ref work s2)) */ 
    SgObject G17587 = SG_NIL, G17588 = SG_NIL;
    SG_APPEND1(G17587, G17588, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17587, G17588, sg__rc_cgen17086.d17186[744]); /* vect */ 
    SG_APPEND1(G17587, G17588, sg__rc_cgen17086.d17186[1019]); /* d3 */ 
    SG_APPEND1(G17587, G17588, sg__rc_cgen17086.d17186[1025]); /* (vector-ref work s2) */ 
    sg__rc_cgen17086.d17186[1024] = G17587;
  } while (0);
  do {
    /* (+ s2 1) */ 
    SgObject G17589 = SG_NIL, G17590 = SG_NIL;
    SG_APPEND1(G17589, G17590, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17589, G17590, sg__rc_cgen17086.d17186[1016]); /* s2 */ 
    SG_APPEND1(G17589, G17590, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[1027] = G17589;
  } while (0);
  do {
    /* (+ d3 1) */ 
    SgObject G17591 = SG_NIL, G17592 = SG_NIL;
    SG_APPEND1(G17591, G17592, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17591, G17592, sg__rc_cgen17086.d17186[1019]); /* d3 */ 
    SG_APPEND1(G17591, G17592, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[1028] = G17591;
  } while (0);
  do {
    /* (loop (+ s2 1) (+ d3 1)) */ 
    SgObject G17593 = SG_NIL, G17594 = SG_NIL;
    SG_APPEND1(G17593, G17594, sg__rc_cgen17086.d17186[636]); /* loop */ 
    SG_APPEND1(G17593, G17594, sg__rc_cgen17086.d17186[1027]); /* (+ s2 1) */ 
    SG_APPEND1(G17593, G17594, sg__rc_cgen17086.d17186[1028]); /* (+ d3 1) */ 
    sg__rc_cgen17086.d17186[1026] = G17593;
  } while (0);
  do {
    /* ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))) */ 
    SgObject G17595 = SG_NIL, G17596 = SG_NIL;
    SG_APPEND1(G17595, G17596, sg__rc_cgen17086.d17186[1023]); /* (< s2 p2size) */ 
    SG_APPEND1(G17595, G17596, sg__rc_cgen17086.d17186[1024]); /* (vector-set! vect d3 (vector-ref work s2)) */ 
    SG_APPEND1(G17595, G17596, sg__rc_cgen17086.d17186[1026]); /* (loop (+ s2 1) (+ d3 1)) */ 
    sg__rc_cgen17086.d17186[1022] = G17595;
  } while (0);
  do {
    /* (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1)))) */ 
    SgObject G17597 = SG_NIL, G17598 = SG_NIL;
    SG_APPEND1(G17597, G17598, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17597, G17598, sg__rc_cgen17086.d17186[1022]); /* ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))) */ 
    sg__rc_cgen17086.d17186[1021] = G17597;
  } while (0);
  do {
    /* (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))) */ 
    SgObject G17599 = SG_NIL, G17600 = SG_NIL;
    SG_APPEND1(G17599, G17600, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17599, G17600, sg__rc_cgen17086.d17186[636]); /* loop */ 
    SG_APPEND1(G17599, G17600, sg__rc_cgen17086.d17186[1014]); /* ((s2 p2) (d3 p3)) */ 
    SG_APPEND1(G17599, G17600, sg__rc_cgen17086.d17186[1021]); /* (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1)))) */ 
    sg__rc_cgen17086.d17186[1013] = G17599;
  } while (0);
  do {
    /* (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1)))))) */ 
    SgObject G17601 = SG_NIL, G17602 = SG_NIL;
    SG_APPEND1(G17601, G17602, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17601, G17602, sg__rc_cgen17086.d17186[1013]); /* (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))) */ 
    sg__rc_cgen17086.d17186[1012] = G17601;
  } while (0);
  do {
    /* (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))) */ 
    SgObject G17603 = SG_NIL, G17604 = SG_NIL;
    SG_APPEND1(G17603, G17604, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17603, G17604, sg__rc_cgen17086.d17186[993]); /* ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) */ 
    SG_APPEND1(G17603, G17604, sg__rc_cgen17086.d17186[1012]); /* (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1)))))) */ 
    sg__rc_cgen17086.d17186[992] = G17603;
  } while (0);
  do {
    /* (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1)))))))) */ 
    SgObject G17605 = SG_NIL, G17606 = SG_NIL;
    SG_APPEND1(G17605, G17606, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17605, G17606, sg__rc_cgen17086.d17186[636]); /* loop */ 
    SG_APPEND1(G17605, G17606, sg__rc_cgen17086.d17186[982]); /* ((p1 (+ middle 1)) (p2 0) (p3 first)) */ 
    SG_APPEND1(G17605, G17606, sg__rc_cgen17086.d17186[992]); /* (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))) */ 
    sg__rc_cgen17086.d17186[981] = G17605;
  } while (0);
  do {
    /* ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) */ 
    SgObject G17607 = SG_NIL, G17608 = SG_NIL;
    SG_APPEND1(G17607, G17608, sg__rc_cgen17086.d17186[980]); /* (> i middle) */ 
    SG_APPEND1(G17607, G17608, sg__rc_cgen17086.d17186[981]); /* (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1)))))))) */ 
    sg__rc_cgen17086.d17186[979] = G17607;
  } while (0);
  do {
    /* (vector-set! work p2size (vector-ref vect i)) */ 
    SgObject G17609 = SG_NIL, G17610 = SG_NIL;
    SG_APPEND1(G17609, G17610, sg__rc_cgen17086.d17186[793]); /* vector-set! */ 
    SG_APPEND1(G17609, G17610, sg__rc_cgen17086.d17186[899]); /* work */ 
    SG_APPEND1(G17609, G17610, sg__rc_cgen17086.d17186[976]); /* p2size */ 
    SG_APPEND1(G17609, G17610, sg__rc_cgen17086.d17186[925]); /* (vector-ref vect i) */ 
    sg__rc_cgen17086.d17186[1030] = G17609;
  } while (0);
  do {
    /* (+ p2size 1) */ 
    SgObject G17611 = SG_NIL, G17612 = SG_NIL;
    SG_APPEND1(G17611, G17612, sg__rc_cgen17086.d17186[780]); /* + */ 
    SG_APPEND1(G17611, G17612, sg__rc_cgen17086.d17186[976]); /* p2size */ 
    SG_APPEND1(G17611, G17612, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[1032] = G17611;
  } while (0);
  do {
    /* (loop (+ i 1) (+ p2size 1)) */ 
    SgObject G17613 = SG_NIL, G17614 = SG_NIL;
    SG_APPEND1(G17613, G17614, sg__rc_cgen17086.d17186[636]); /* loop */ 
    SG_APPEND1(G17613, G17614, sg__rc_cgen17086.d17186[779]); /* (+ i 1) */ 
    SG_APPEND1(G17613, G17614, sg__rc_cgen17086.d17186[1032]); /* (+ p2size 1) */ 
    sg__rc_cgen17086.d17186[1031] = G17613;
  } while (0);
  do {
    /* (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))) */ 
    SgObject G17615 = SG_NIL, G17616 = SG_NIL;
    SG_APPEND1(G17615, G17616, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17615, G17616, sg__rc_cgen17086.d17186[1030]); /* (vector-set! work p2size (vector-ref vect i)) */ 
    SG_APPEND1(G17615, G17616, sg__rc_cgen17086.d17186[1031]); /* (loop (+ i 1) (+ p2size 1)) */ 
    sg__rc_cgen17086.d17186[1029] = G17615;
  } while (0);
  do {
    /* (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1)))) */ 
    SgObject G17617 = SG_NIL, G17618 = SG_NIL;
    SG_APPEND1(G17617, G17618, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17617, G17618, sg__rc_cgen17086.d17186[979]); /* ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) */ 
    SG_APPEND1(G17617, G17618, sg__rc_cgen17086.d17186[1029]); /* (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))) */ 
    sg__rc_cgen17086.d17186[978] = G17617;
  } while (0);
  do {
    /* (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))) */ 
    SgObject G17619 = SG_NIL, G17620 = SG_NIL;
    SG_APPEND1(G17619, G17620, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17619, G17620, sg__rc_cgen17086.d17186[636]); /* loop */ 
    SG_APPEND1(G17619, G17620, sg__rc_cgen17086.d17186[974]); /* ((i first) (p2size 0)) */ 
    SG_APPEND1(G17619, G17620, sg__rc_cgen17086.d17186[978]); /* (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1)))) */ 
    sg__rc_cgen17086.d17186[973] = G17619;
  } while (0);
  do {
    /* (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1)))))) */ 
    SgObject G17621 = SG_NIL, G17622 = SG_NIL;
    SG_APPEND1(G17621, G17622, sg__rc_cgen17086.d17186[205]); /* let */ 
    SG_APPEND1(G17621, G17622, sg__rc_cgen17086.d17186[964]); /* ((middle (div (+ first last) 2))) */ 
    SG_APPEND1(G17621, G17622, sg__rc_cgen17086.d17186[970]); /* (sort! first middle) */ 
    SG_APPEND1(G17621, G17622, sg__rc_cgen17086.d17186[971]); /* (sort! (+ middle 1) last) */ 
    SG_APPEND1(G17621, G17622, sg__rc_cgen17086.d17186[973]); /* (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))) */ 
    sg__rc_cgen17086.d17186[963] = G17621;
  } while (0);
  do {
    /* ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) */ 
    SgObject G17623 = SG_NIL, G17624 = SG_NIL;
    SG_APPEND1(G17623, G17624, sg__rc_cgen17086.d17186[961]); /* (> (- last first) 10) */ 
    SG_APPEND1(G17623, G17624, sg__rc_cgen17086.d17186[963]); /* (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1)))))) */ 
    sg__rc_cgen17086.d17186[960] = G17623;
  } while (0);
  do {
    /* (else (simple-sort! first last)) */ 
    SgObject G17625 = SG_NIL, G17626 = SG_NIL;
    SG_APPEND1(G17625, G17626, sg__rc_cgen17086.d17186[282]); /* else */ 
    SG_APPEND1(G17625, G17626, sg__rc_cgen17086.d17186[905]); /* (simple-sort! first last) */ 
    sg__rc_cgen17086.d17186[1033] = G17625;
  } while (0);
  do {
    /* (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last))) */ 
    SgObject G17627 = SG_NIL, G17628 = SG_NIL;
    SG_APPEND1(G17627, G17628, sg__rc_cgen17086.d17186[244]); /* cond */ 
    SG_APPEND1(G17627, G17628, sg__rc_cgen17086.d17186[960]); /* ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) */ 
    SG_APPEND1(G17627, G17628, sg__rc_cgen17086.d17186[1033]); /* (else (simple-sort! first last)) */ 
    sg__rc_cgen17086.d17186[959] = G17627;
  } while (0);
  do {
    /* (define (sort! first last) (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last)))) */ 
    SgObject G17629 = SG_NIL, G17630 = SG_NIL;
    SG_APPEND1(G17629, G17630, sg__rc_cgen17086.d17186[195]); /* define */ 
    SG_APPEND1(G17629, G17630, sg__rc_cgen17086.d17186[956]); /* (sort! first last) */ 
    SG_APPEND1(G17629, G17630, sg__rc_cgen17086.d17186[959]); /* (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last))) */ 
    sg__rc_cgen17086.d17186[955] = G17629;
  } while (0);
  do {
    /* (- end 1) */ 
    SgObject G17631 = SG_NIL, G17632 = SG_NIL;
    SG_APPEND1(G17631, G17632, sg__rc_cgen17086.d17186[803]); /* - */ 
    SG_APPEND1(G17631, G17632, sg__rc_cgen17086.d17186[747]); /* end */ 
    SG_APPEND1(G17631, G17632, SG_MAKE_INT(1U)); /* 1 */ 
    sg__rc_cgen17086.d17186[1035] = G17631;
  } while (0);
  do {
    /* (sort! start (- end 1)) */ 
    SgObject G17633 = SG_NIL, G17634 = SG_NIL;
    SG_APPEND1(G17633, G17634, sg__rc_cgen17086.d17186[957]); /* sort! */ 
    SG_APPEND1(G17633, G17634, sg__rc_cgen17086.d17186[815]); /* start */ 
    SG_APPEND1(G17633, G17634, sg__rc_cgen17086.d17186[1035]); /* (- end 1) */ 
    sg__rc_cgen17086.d17186[1034] = G17633;
  } while (0);
  do {
    /* (let* ((n (- end start)) (work (make-vector (+ (div n 2) 1)))) (define (simple-sort! first last) (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))))) (define (sort! first last) (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last)))) (sort! start (- end 1))) */ 
    SgObject G17635 = SG_NIL, G17636 = SG_NIL;
    SG_APPEND1(G17635, G17636, sg__rc_cgen17086.d17186[838]); /* let* */ 
    SG_APPEND1(G17635, G17636, sg__rc_cgen17086.d17186[894]); /* ((n (- end start)) (work (make-vector (+ (div n 2) 1)))) */ 
    SG_APPEND1(G17635, G17636, sg__rc_cgen17086.d17186[904]); /* (define (simple-sort! first last) (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))))) */ 
    SG_APPEND1(G17635, G17636, sg__rc_cgen17086.d17186[955]); /* (define (sort! first last) (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last)))) */ 
    SG_APPEND1(G17635, G17636, sg__rc_cgen17086.d17186[1034]); /* (sort! start (- end 1)) */ 
    sg__rc_cgen17086.d17186[893] = G17635;
  } while (0);
  do {
    /* ((define len (vector-length vect)) (define end (or maybe-end len)) (when (or (negative? start) (negative? end)) (assertion-violation 'vector-sort! "start and end must be positive" start vect)) (when (or (> start len) (> end len)) (assertion-violation 'vector-sort! "out of range" (list (list start end) len) vect)) (when (> start end) (assertion-violation 'vector-sort! "start is greater than end" (list start end) vect)) (let* ((n (- end start)) (work (make-vector (+ (div n 2) 1)))) (define (simple-sort! first last) (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))))) (define (sort! first last) (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last)))) (sort! start (- end 1)))) */ 
    SgObject G17637 = SG_NIL, G17638 = SG_NIL;
    SG_APPEND1(G17637, G17638, sg__rc_cgen17086.d17186[740]); /* (define len (vector-length vect)) */ 
    SG_APPEND1(G17637, G17638, sg__rc_cgen17086.d17186[746]); /* (define end (or maybe-end len)) */ 
    SG_APPEND1(G17637, G17638, sg__rc_cgen17086.d17186[808]); /* (when (or (negative? start) (negative? end)) (assertion-violation 'vector-sort! "start and end must be positive" start vect)) */ 
    SG_APPEND1(G17637, G17638, sg__rc_cgen17086.d17186[823]); /* (when (or (> start len) (> end len)) (assertion-violation 'vector-sort! "out of range" (list (list start end) len) vect)) */ 
    SG_APPEND1(G17637, G17638, sg__rc_cgen17086.d17186[833]); /* (when (> start end) (assertion-violation 'vector-sort! "start is greater than end" (list start end) vect)) */ 
    SG_APPEND1(G17637, G17638, sg__rc_cgen17086.d17186[893]); /* (let* ((n (- end start)) (work (make-vector (+ (div n 2) 1)))) (define (simple-sort! first last) (let loop1 ((i first)) (cond ((< i last) (let ((m (vector-ref vect i)) (k i)) (let loop2 ((j (+ i 1))) (cond ((<= j last) (if (proc (vector-ref vect j) m) (begin (set! m (vector-ref vect j)) (set! k j))) (loop2 (+ j 1))) (else (vector-set! vect k (vector-ref vect i)) (vector-set! vect i m) (loop1 (+ i 1)))))))))) (define (sort! first last) (cond ((> (- last first) 10) (let ((middle (div (+ first last) 2))) (sort! first middle) (sort! (+ middle 1) last) (let loop ((i first) (p2size 0)) (cond ((> i middle) (let loop ((p1 (+ middle 1)) (p2 0) (p3 first)) (cond ((and (<= p1 last) (< p2 p2size)) (cond ((proc (vector-ref work p2) (vector-ref vect p1)) (vector-set! vect p3 (vector-ref work p2)) (loop p1 (+ p2 1) (+ p3 1))) (else (vector-set! vect p3 (vector-ref vect p1)) (loop (+ p1 1) p2 (+ p3 1))))) (else (let loop ((s2 p2) (d3 p3)) (cond ((< s2 p2size) (vector-set! vect d3 (vector-ref work s2)) (loop (+ s2 1) (+ d3 1))))))))) (else (vector-set! work p2size (vector-ref vect i)) (loop (+ i 1) (+ p2size 1))))))) (else (simple-sort! first last)))) (sort! start (- end 1))) */ 
    sg__rc_cgen17086.d17186[892] = G17637;
  } while (0);
  sg__rc_cgen17086.d17186[1036] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1036],SG_SYMBOL(sg__rc_cgen17086.d17186[813]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* negative? */
  sg__rc_cgen17086.d17186[1037] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1037],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[1038] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1038],SG_SYMBOL(sg__rc_cgen17086.d17186[813]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* negative? */
  sg__rc_cgen17086.d17186[1039] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1039],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[1040] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1040],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[1041] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1041],SG_SYMBOL(sg__rc_cgen17086.d17186[735]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* div */
  sg__rc_cgen17086.d17186[1042] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1042],SG_SYMBOL(sg__rc_cgen17086.d17186[865]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* make-vector */
  sg__rc_cgen17086.d17186[1043] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1043],SG_SYMBOL(sg__rc_cgen17086.d17186[735]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* div */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[93]))->name = sg__rc_cgen17086.d17186[957];/* sort! */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4212]))[15] = SG_WORD(sg__rc_cgen17086.d17186[1043]);
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[94]))->name = sg__rc_cgen17086.d17186[820];/* vector-sort! */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[44] = SG_WORD(sg__rc_cgen17086.d17186[190]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[46] = SG_WORD(sg__rc_cgen17086.d17186[192]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[48] = SG_WORD(sg__rc_cgen17086.d17186[892]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[50] = SG_WORD(sg__rc_cgen17086.d17186[304]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[66] = SG_WORD(sg__rc_cgen17086.d17186[1036]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[72] = SG_WORD(sg__rc_cgen17086.d17186[820]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[74] = SG_WORD(sg__rc_cgen17086.d17186[822]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[78] = SG_WORD(sg__rc_cgen17086.d17186[1037]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[85] = SG_WORD(sg__rc_cgen17086.d17186[1038]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[100] = SG_WORD(sg__rc_cgen17086.d17186[820]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[102] = SG_WORD(sg__rc_cgen17086.d17186[830]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[112] = SG_WORD(sg__rc_cgen17086.d17186[1039]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[131] = SG_WORD(sg__rc_cgen17086.d17186[820]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[133] = SG_WORD(sg__rc_cgen17086.d17186[836]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[140] = SG_WORD(sg__rc_cgen17086.d17186[1040]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[155] = SG_WORD(sg__rc_cgen17086.d17186[1041]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4425]))[159] = SG_WORD(sg__rc_cgen17086.d17186[1042]);
  sg__rc_cgen17086.d17186[1044] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1044],SG_SYMBOL(sg__rc_cgen17086.d17186[820]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* vector-sort! */
  sg__rc_cgen17086.d17186[1045] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1047] = SG_MAKE_STRING("close-port");
  sg__rc_cgen17086.d17186[1046] = Sg_Intern(sg__rc_cgen17086.d17186[1047]); /* close-port */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1045],SG_SYMBOL(sg__rc_cgen17086.d17186[1046]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* close-port */
  sg__rc_cgen17086.d17186[1048] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1050] = SG_MAKE_STRING("values");
  sg__rc_cgen17086.d17186[1049] = Sg_Intern(sg__rc_cgen17086.d17186[1050]); /* values */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1048],SG_SYMBOL(sg__rc_cgen17086.d17186[1049]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* values */
  sg__rc_cgen17086.d17186[1052] = SG_MAKE_STRING("call-with-port");
  sg__rc_cgen17086.d17186[1051] = Sg_Intern(sg__rc_cgen17086.d17186[1052]); /* call-with-port */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[95]))->name = sg__rc_cgen17086.d17186[1051];/* call-with-port */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4601]))[10] = SG_WORD(sg__rc_cgen17086.d17186[1045]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4601]))[12] = SG_WORD(sg__rc_cgen17086.d17186[1048]);
  sg__rc_cgen17086.d17186[1053] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1053],SG_SYMBOL(sg__rc_cgen17086.d17186[1051]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* call-with-port */
  sg__rc_cgen17086.d17186[1054] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1054],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[1056] = SG_MAKE_STRING("open-bytevector-output-port");
  sg__rc_cgen17086.d17186[1055] = Sg_Intern(sg__rc_cgen17086.d17186[1056]); /* open-bytevector-output-port */
  sg__rc_cgen17086.d17186[1057] = SG_MAKE_STRING("wrong number of argument: expected between 0 and 1, but got ~a");
  sg__rc_cgen17086.d17186[1058] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1058],SG_SYMBOL(sg__rc_cgen17086.d17186[609]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* length */
  sg__rc_cgen17086.d17186[1059] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1059],SG_SYMBOL(sg__rc_cgen17086.d17186[141]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* format */
  sg__rc_cgen17086.d17186[1060] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1060],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[1061] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1063] = SG_MAKE_STRING("open-output-bytevector");
  sg__rc_cgen17086.d17186[1062] = Sg_Intern(sg__rc_cgen17086.d17186[1063]); /* open-output-bytevector */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1061],SG_SYMBOL(sg__rc_cgen17086.d17186[1062]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* open-output-bytevector */
  sg__rc_cgen17086.d17186[1064] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1066] = SG_MAKE_STRING("extract-output-bytevector");
  sg__rc_cgen17086.d17186[1065] = Sg_Intern(sg__rc_cgen17086.d17186[1066]); /* extract-output-bytevector */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1064],SG_SYMBOL(sg__rc_cgen17086.d17186[1065]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* extract-output-bytevector */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[96]))->name = sg__rc_cgen17086.d17186[90];/* proc */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4617]))[2] = SG_WORD(sg__rc_cgen17086.d17186[1064]);
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[97]))->name = sg__rc_cgen17086.d17186[1055];/* open-bytevector-output-port */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4621]))[4] = SG_WORD(sg__rc_cgen17086.d17186[1054]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4621]))[12] = SG_WORD(sg__rc_cgen17086.d17186[1055]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4621]))[16] = SG_WORD(sg__rc_cgen17086.d17186[1057]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4621]))[21] = SG_WORD(sg__rc_cgen17086.d17186[1058]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4621]))[24] = SG_WORD(sg__rc_cgen17086.d17186[1059]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4621]))[28] = SG_WORD(sg__rc_cgen17086.d17186[1060]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4621]))[45] = SG_WORD(sg__rc_cgen17086.d17186[1061]);
  sg__rc_cgen17086.d17186[1067] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1067],SG_SYMBOL(sg__rc_cgen17086.d17186[1055]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* open-bytevector-output-port */
  sg__rc_cgen17086.d17186[1068] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1070] = SG_MAKE_STRING("open-output-string");
  sg__rc_cgen17086.d17186[1069] = Sg_Intern(sg__rc_cgen17086.d17186[1070]); /* open-output-string */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1068],SG_SYMBOL(sg__rc_cgen17086.d17186[1069]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* open-output-string */
  sg__rc_cgen17086.d17186[1071] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1073] = SG_MAKE_STRING("extract-output-string");
  sg__rc_cgen17086.d17186[1072] = Sg_Intern(sg__rc_cgen17086.d17186[1073]); /* extract-output-string */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1071],SG_SYMBOL(sg__rc_cgen17086.d17186[1072]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* extract-output-string */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[98]))->name = sg__rc_cgen17086.d17186[90];/* proc */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4676]))[2] = SG_WORD(sg__rc_cgen17086.d17186[1071]);
  sg__rc_cgen17086.d17186[1075] = SG_MAKE_STRING("open-string-output-port");
  sg__rc_cgen17086.d17186[1074] = Sg_Intern(sg__rc_cgen17086.d17186[1075]); /* open-string-output-port */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[99]))->name = sg__rc_cgen17086.d17186[1074];/* open-string-output-port */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4680]))[3] = SG_WORD(sg__rc_cgen17086.d17186[1068]);
  sg__rc_cgen17086.d17186[1076] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1076],SG_SYMBOL(sg__rc_cgen17086.d17186[1074]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* open-string-output-port */
  sg__rc_cgen17086.d17186[1077] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1077],SG_SYMBOL(sg__rc_cgen17086.d17186[1055]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* open-bytevector-output-port */
  sg__rc_cgen17086.d17186[1079] = SG_MAKE_STRING("call-with-bytevector-output-port");
  sg__rc_cgen17086.d17186[1078] = Sg_Intern(sg__rc_cgen17086.d17186[1079]); /* call-with-bytevector-output-port */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[100]))->name = sg__rc_cgen17086.d17186[1078];/* call-with-bytevector-output-port */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4693]))[3] = SG_WORD(sg__rc_cgen17086.d17186[1077]);
  sg__rc_cgen17086.d17186[1080] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1080],SG_SYMBOL(sg__rc_cgen17086.d17186[1078]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* call-with-bytevector-output-port */
  sg__rc_cgen17086.d17186[1081] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1081],SG_SYMBOL(sg__rc_cgen17086.d17186[1074]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* open-string-output-port */
  sg__rc_cgen17086.d17186[1083] = SG_MAKE_STRING("call-with-string-output-port");
  sg__rc_cgen17086.d17186[1082] = Sg_Intern(sg__rc_cgen17086.d17186[1083]); /* call-with-string-output-port */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[101]))->name = sg__rc_cgen17086.d17186[1082];/* call-with-string-output-port */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4708]))[3] = SG_WORD(sg__rc_cgen17086.d17186[1081]);
  sg__rc_cgen17086.d17186[1084] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1084],SG_SYMBOL(sg__rc_cgen17086.d17186[1082]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* call-with-string-output-port */
  sg__rc_cgen17086.d17186[1085] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1085],SG_SYMBOL(sg__rc_cgen17086.d17186[67]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable? */
  sg__rc_cgen17086.d17186[1087] = SG_MAKE_STRING("hashtable-equivalence-function");
  sg__rc_cgen17086.d17186[1086] = Sg_Intern(sg__rc_cgen17086.d17186[1087]); /* hashtable-equivalence-function */
  sg__rc_cgen17086.d17186[1088] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1088],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[1089] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1091] = SG_MAKE_STRING("hashtable-type");
  sg__rc_cgen17086.d17186[1090] = Sg_Intern(sg__rc_cgen17086.d17186[1091]); /* hashtable-type */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1089],SG_SYMBOL(sg__rc_cgen17086.d17186[1090]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-type */
  sg__rc_cgen17086.d17186[1093] = SG_MAKE_STRING("eq");
  sg__rc_cgen17086.d17186[1092] = Sg_Intern(sg__rc_cgen17086.d17186[1093]); /* eq */
  sg__rc_cgen17086.d17186[1094] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1094],SG_SYMBOL(sg__rc_cgen17086.d17186[297]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* eq? */
  sg__rc_cgen17086.d17186[1096] = SG_MAKE_STRING("eqv");
  sg__rc_cgen17086.d17186[1095] = Sg_Intern(sg__rc_cgen17086.d17186[1096]); /* eqv */
  sg__rc_cgen17086.d17186[1097] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1099] = SG_MAKE_STRING("eqv?");
  sg__rc_cgen17086.d17186[1098] = Sg_Intern(sg__rc_cgen17086.d17186[1099]); /* eqv? */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1097],SG_SYMBOL(sg__rc_cgen17086.d17186[1098]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* eqv? */
  sg__rc_cgen17086.d17186[1101] = SG_MAKE_STRING("equal");
  sg__rc_cgen17086.d17186[1100] = Sg_Intern(sg__rc_cgen17086.d17186[1101]); /* equal */
  sg__rc_cgen17086.d17186[1102] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1102],SG_SYMBOL(sg__rc_cgen17086.d17186[353]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* equal? */
  sg__rc_cgen17086.d17186[1104] = SG_MAKE_STRING("string");
  sg__rc_cgen17086.d17186[1103] = Sg_Intern(sg__rc_cgen17086.d17186[1104]); /* string */
  sg__rc_cgen17086.d17186[1105] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1105],SG_SYMBOL(sg__rc_cgen17086.d17186[489]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string=? */
  sg__rc_cgen17086.d17186[1107] = SG_MAKE_STRING("general");
  sg__rc_cgen17086.d17186[1106] = Sg_Intern(sg__rc_cgen17086.d17186[1107]); /* general */
  sg__rc_cgen17086.d17186[1108] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1110] = SG_MAKE_STRING("hashtable-compare");
  sg__rc_cgen17086.d17186[1109] = Sg_Intern(sg__rc_cgen17086.d17186[1110]); /* hashtable-compare */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1108],SG_SYMBOL(sg__rc_cgen17086.d17186[1109]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-compare */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[102]))->name = sg__rc_cgen17086.d17186[1086];/* hashtable-equivalence-function */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[4] = SG_WORD(sg__rc_cgen17086.d17186[1085]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[12] = SG_WORD(sg__rc_cgen17086.d17186[1086]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[16] = SG_WORD(sg__rc_cgen17086.d17186[69]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[19] = SG_WORD(sg__rc_cgen17086.d17186[1088]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[22] = SG_WORD(sg__rc_cgen17086.d17186[645]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[27] = SG_WORD(sg__rc_cgen17086.d17186[1089]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[31] = SG_WORD(sg__rc_cgen17086.d17186[1092]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[35] = SG_WORD(sg__rc_cgen17086.d17186[1094]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[39] = SG_WORD(sg__rc_cgen17086.d17186[1095]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[43] = SG_WORD(sg__rc_cgen17086.d17186[1097]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[47] = SG_WORD(sg__rc_cgen17086.d17186[1100]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[51] = SG_WORD(sg__rc_cgen17086.d17186[1102]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[55] = SG_WORD(sg__rc_cgen17086.d17186[1103]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[59] = SG_WORD(sg__rc_cgen17086.d17186[1105]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[63] = SG_WORD(sg__rc_cgen17086.d17186[1106]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4721]))[68] = SG_WORD(sg__rc_cgen17086.d17186[1108]);
  sg__rc_cgen17086.d17186[1111] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1111],SG_SYMBOL(sg__rc_cgen17086.d17186[1086]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-equivalence-function */
  sg__rc_cgen17086.d17186[1112] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1112],SG_SYMBOL(sg__rc_cgen17086.d17186[67]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable? */
  sg__rc_cgen17086.d17186[1114] = SG_MAKE_STRING("hashtable-hash-function");
  sg__rc_cgen17086.d17186[1113] = Sg_Intern(sg__rc_cgen17086.d17186[1114]); /* hashtable-hash-function */
  sg__rc_cgen17086.d17186[1115] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1115],SG_SYMBOL(sg__rc_cgen17086.d17186[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* wrong-type-argument-message */
  sg__rc_cgen17086.d17186[1116] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1116],SG_SYMBOL(sg__rc_cgen17086.d17186[64]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* assertion-violation */
  sg__rc_cgen17086.d17186[1117] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1117],SG_SYMBOL(sg__rc_cgen17086.d17186[1090]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-type */
  sg__rc_cgen17086.d17186[1118] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1120] = SG_MAKE_STRING("equal-hash");
  sg__rc_cgen17086.d17186[1119] = Sg_Intern(sg__rc_cgen17086.d17186[1120]); /* equal-hash */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1118],SG_SYMBOL(sg__rc_cgen17086.d17186[1119]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* equal-hash */
  sg__rc_cgen17086.d17186[1121] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1123] = SG_MAKE_STRING("string-hash");
  sg__rc_cgen17086.d17186[1122] = Sg_Intern(sg__rc_cgen17086.d17186[1123]); /* string-hash */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1121],SG_SYMBOL(sg__rc_cgen17086.d17186[1122]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* string-hash */
  sg__rc_cgen17086.d17186[1124] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen17086.d17186[1126] = SG_MAKE_STRING("hashtable-hasher");
  sg__rc_cgen17086.d17186[1125] = Sg_Intern(sg__rc_cgen17086.d17186[1126]); /* hashtable-hasher */
  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1124],SG_SYMBOL(sg__rc_cgen17086.d17186[1125]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-hasher */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen17086.d17188[103]))->name = sg__rc_cgen17086.d17186[1113];/* hashtable-hash-function */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[4] = SG_WORD(sg__rc_cgen17086.d17186[1112]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[12] = SG_WORD(sg__rc_cgen17086.d17186[1113]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[16] = SG_WORD(sg__rc_cgen17086.d17186[69]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[19] = SG_WORD(sg__rc_cgen17086.d17186[1115]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[22] = SG_WORD(sg__rc_cgen17086.d17186[1116]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[27] = SG_WORD(sg__rc_cgen17086.d17186[1117]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[31] = SG_WORD(sg__rc_cgen17086.d17186[1092]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[38] = SG_WORD(sg__rc_cgen17086.d17186[1095]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[45] = SG_WORD(sg__rc_cgen17086.d17186[1100]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[49] = SG_WORD(sg__rc_cgen17086.d17186[1118]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[53] = SG_WORD(sg__rc_cgen17086.d17186[1103]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[57] = SG_WORD(sg__rc_cgen17086.d17186[1121]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[61] = SG_WORD(sg__rc_cgen17086.d17186[1106]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4793]))[66] = SG_WORD(sg__rc_cgen17086.d17186[1124]);
  sg__rc_cgen17086.d17186[1127] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen17086.d17186[1127],SG_SYMBOL(sg__rc_cgen17086.d17186[1113]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen17086.d17186[3]),FALSE); /* hashtable-hash-function */
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[3] = SG_WORD(sg__rc_cgen17086.d17186[11]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[7] = SG_WORD(sg__rc_cgen17086.d17186[16]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[11] = SG_WORD(sg__rc_cgen17086.d17186[19]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[15] = SG_WORD(sg__rc_cgen17086.d17186[24]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[19] = SG_WORD(sg__rc_cgen17086.d17186[31]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[23] = SG_WORD(sg__rc_cgen17086.d17186[34]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[27] = SG_WORD(sg__rc_cgen17086.d17186[41]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[31] = SG_WORD(sg__rc_cgen17086.d17186[46]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[35] = SG_WORD(sg__rc_cgen17086.d17186[51]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[37] = SG_WORD(sg__rc_cgen17086.d17186[3]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[41] = SG_WORD(sg__rc_cgen17086.d17186[75]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[45] = SG_WORD(sg__rc_cgen17086.d17186[85]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[49] = SG_WORD(sg__rc_cgen17086.d17186[98]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[53] = SG_WORD(sg__rc_cgen17086.d17186[105]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[57] = SG_WORD(sg__rc_cgen17086.d17186[117]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[61] = SG_WORD(sg__rc_cgen17086.d17186[120]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[65] = SG_WORD(sg__rc_cgen17086.d17186[132]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[69] = SG_WORD(sg__rc_cgen17086.d17186[138]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[73] = SG_WORD(sg__rc_cgen17086.d17186[145]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[77] = SG_WORD(sg__rc_cgen17086.d17186[158]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[81] = SG_WORD(sg__rc_cgen17086.d17186[165]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[85] = SG_WORD(sg__rc_cgen17086.d17186[172]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[89] = SG_WORD(sg__rc_cgen17086.d17186[186]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[93] = SG_WORD(sg__rc_cgen17086.d17186[320]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[97] = SG_WORD(sg__rc_cgen17086.d17186[324]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[101] = SG_WORD(sg__rc_cgen17086.d17186[336]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[105] = SG_WORD(sg__rc_cgen17086.d17186[342]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[109] = SG_WORD(sg__rc_cgen17086.d17186[346]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[113] = SG_WORD(sg__rc_cgen17086.d17186[357]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[117] = SG_WORD(sg__rc_cgen17086.d17186[363]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[121] = SG_WORD(sg__rc_cgen17086.d17186[371]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[125] = SG_WORD(sg__rc_cgen17086.d17186[379]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[129] = SG_WORD(sg__rc_cgen17086.d17186[389]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[133] = SG_WORD(sg__rc_cgen17086.d17186[400]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[137] = SG_WORD(sg__rc_cgen17086.d17186[414]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[141] = SG_WORD(sg__rc_cgen17086.d17186[428]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[145] = SG_WORD(sg__rc_cgen17086.d17186[432]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[149] = SG_WORD(sg__rc_cgen17086.d17186[438]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[151] = SG_WORD(sg__rc_cgen17086.d17186[439]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[153] = SG_WORD(sg__rc_cgen17086.d17186[440]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[157] = SG_WORD(sg__rc_cgen17086.d17186[445]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[161] = SG_WORD(sg__rc_cgen17086.d17186[446]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[163] = SG_WORD(sg__rc_cgen17086.d17186[449]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[165] = SG_WORD(sg__rc_cgen17086.d17186[452]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[167] = SG_WORD(sg__rc_cgen17086.d17186[453]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[171] = SG_WORD(sg__rc_cgen17086.d17186[456]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[173] = SG_WORD(sg__rc_cgen17086.d17186[459]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[175] = SG_WORD(sg__rc_cgen17086.d17186[460]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[177] = SG_WORD(sg__rc_cgen17086.d17186[461]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[181] = SG_WORD(sg__rc_cgen17086.d17186[464]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[183] = SG_WORD(sg__rc_cgen17086.d17186[467]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[185] = SG_WORD(sg__rc_cgen17086.d17186[468]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[187] = SG_WORD(sg__rc_cgen17086.d17186[469]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[191] = SG_WORD(sg__rc_cgen17086.d17186[472]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[193] = SG_WORD(sg__rc_cgen17086.d17186[475]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[195] = SG_WORD(sg__rc_cgen17086.d17186[476]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[197] = SG_WORD(sg__rc_cgen17086.d17186[477]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[201] = SG_WORD(sg__rc_cgen17086.d17186[480]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[203] = SG_WORD(sg__rc_cgen17086.d17186[483]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[205] = SG_WORD(sg__rc_cgen17086.d17186[484]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[207] = SG_WORD(sg__rc_cgen17086.d17186[485]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[211] = SG_WORD(sg__rc_cgen17086.d17186[488]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[213] = SG_WORD(sg__rc_cgen17086.d17186[491]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[215] = SG_WORD(sg__rc_cgen17086.d17186[494]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[217] = SG_WORD(sg__rc_cgen17086.d17186[495]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[221] = SG_WORD(sg__rc_cgen17086.d17186[498]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[223] = SG_WORD(sg__rc_cgen17086.d17186[501]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[225] = SG_WORD(sg__rc_cgen17086.d17186[502]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[227] = SG_WORD(sg__rc_cgen17086.d17186[503]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[231] = SG_WORD(sg__rc_cgen17086.d17186[506]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[233] = SG_WORD(sg__rc_cgen17086.d17186[509]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[235] = SG_WORD(sg__rc_cgen17086.d17186[510]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[237] = SG_WORD(sg__rc_cgen17086.d17186[511]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[241] = SG_WORD(sg__rc_cgen17086.d17186[514]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[243] = SG_WORD(sg__rc_cgen17086.d17186[517]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[245] = SG_WORD(sg__rc_cgen17086.d17186[518]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[247] = SG_WORD(sg__rc_cgen17086.d17186[519]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[251] = SG_WORD(sg__rc_cgen17086.d17186[522]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[253] = SG_WORD(sg__rc_cgen17086.d17186[525]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[255] = SG_WORD(sg__rc_cgen17086.d17186[526]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[257] = SG_WORD(sg__rc_cgen17086.d17186[527]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[261] = SG_WORD(sg__rc_cgen17086.d17186[543]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[265] = SG_WORD(sg__rc_cgen17086.d17186[558]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[269] = SG_WORD(sg__rc_cgen17086.d17186[581]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[273] = SG_WORD(sg__rc_cgen17086.d17186[590]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[277] = SG_WORD(sg__rc_cgen17086.d17186[600]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[281] = SG_WORD(sg__rc_cgen17086.d17186[607]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[285] = SG_WORD(sg__rc_cgen17086.d17186[617]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[289] = SG_WORD(sg__rc_cgen17086.d17186[623]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[293] = SG_WORD(sg__rc_cgen17086.d17186[643]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[297] = SG_WORD(sg__rc_cgen17086.d17186[654]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[301] = SG_WORD(sg__rc_cgen17086.d17186[656]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[305] = SG_WORD(sg__rc_cgen17086.d17186[657]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[309] = SG_WORD(sg__rc_cgen17086.d17186[662]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[313] = SG_WORD(sg__rc_cgen17086.d17186[671]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[317] = SG_WORD(sg__rc_cgen17086.d17186[677]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[321] = SG_WORD(sg__rc_cgen17086.d17186[687]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[325] = SG_WORD(sg__rc_cgen17086.d17186[691]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[329] = SG_WORD(sg__rc_cgen17086.d17186[702]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[333] = SG_WORD(sg__rc_cgen17086.d17186[706]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[337] = SG_WORD(sg__rc_cgen17086.d17186[711]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[341] = SG_WORD(sg__rc_cgen17086.d17186[715]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[345] = SG_WORD(sg__rc_cgen17086.d17186[719]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[349] = SG_WORD(sg__rc_cgen17086.d17186[723]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[353] = SG_WORD(sg__rc_cgen17086.d17186[727]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[357] = SG_WORD(sg__rc_cgen17086.d17186[738]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[361] = SG_WORD(sg__rc_cgen17086.d17186[891]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[365] = SG_WORD(sg__rc_cgen17086.d17186[1044]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[369] = SG_WORD(sg__rc_cgen17086.d17186[1053]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[373] = SG_WORD(sg__rc_cgen17086.d17186[1067]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[377] = SG_WORD(sg__rc_cgen17086.d17186[1076]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[381] = SG_WORD(sg__rc_cgen17086.d17186[1080]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[385] = SG_WORD(sg__rc_cgen17086.d17186[1084]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[389] = SG_WORD(sg__rc_cgen17086.d17186[1111]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen17086.d17187[4863]))[393] = SG_WORD(sg__rc_cgen17086.d17186[1127]);
  sg__rc_cgen17086.d17186[1129] = SG_MAKE_STRING("(core)");
  sg__rc_cgen17086.d17186[1128] = Sg_Intern(sg__rc_cgen17086.d17186[1129]); /* (core) */
  Sg_ImportLibrary(sg__rc_cgen17086.d17186[3], sg__rc_cgen17086.d17186[1128]);

  sg__rc_cgen17086.d17186[1131] = SG_MAKE_STRING("(sagittarius)");
  sg__rc_cgen17086.d17186[1130] = Sg_Intern(sg__rc_cgen17086.d17186[1131]); /* (sagittarius) */
  Sg_ImportLibrary(sg__rc_cgen17086.d17186[3], sg__rc_cgen17086.d17186[1130]);

  sg__rc_cgen17086.d17186[1133] = SG_MAKE_STRING("(sagittarius vm)");
  sg__rc_cgen17086.d17186[1132] = Sg_Intern(sg__rc_cgen17086.d17186[1133]); /* (sagittarius vm) */
  Sg_ImportLibrary(sg__rc_cgen17086.d17186[3], sg__rc_cgen17086.d17186[1132]);

  do {
    /* (hashtable-for-each hashtable-map hashtable-fold hashtable->alist unique-id-list? call-with-values print fold wrong-type-argument-message vector-map vector-map! vector-for-each string-for-each string-join null-list? split-at find find-tail assoc member delete delete! reduce lset-union lset-intersection lset-difference take drop list-head make-ci-comparison char-ci=? char-ci<? char-ci>? char-ci<=? char-ci>=? string-ci=? string-ci<? string-ci>? string-ci<=? string-ci>=? bytevector-uint-ref bytevector-sint-ref bytevector-uint-set! bytevector-sint-set! bytevector->uint-list bytevector->sint-list uint-list->bytevector sint-list->bytevector for-all exists filter filter! partition map for-each filter-map fold-left fold-right remp remove remv remq memp assp list-sort vector-sort vector-sort! call-with-port open-bytevector-output-port open-string-output-port call-with-bytevector-output-port call-with-string-output-port hashtable-equivalence-function hashtable-hash-function) */ 
    SgObject G17639 = SG_NIL, G17640 = SG_NIL;
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[57]); /* hashtable-for-each */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[77]); /* hashtable-map */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[87]); /* hashtable-fold */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[103]); /* hashtable->alist */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[115]); /* unique-id-list? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[118]); /* call-with-values */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[130]); /* print */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[136]); /* fold */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[61]); /* wrong-type-argument-message */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[156]); /* vector-map */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[163]); /* vector-map! */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[170]); /* vector-for-each */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[184]); /* string-for-each */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[240]); /* string-join */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[321]); /* null-list? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[328]); /* split-at */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[340]); /* find */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[338]); /* find-tail */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[348]); /* assoc */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[360]); /* member */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[366]); /* delete */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[377]); /* delete! */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[381]); /* reduce */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[391]); /* lset-union */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[402]); /* lset-intersection */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[416]); /* lset-difference */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[430]); /* take */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[434]); /* drop */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[441]); /* list-head */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[443]); /* make-ci-comparison */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[454]); /* char-ci=? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[462]); /* char-ci<? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[470]); /* char-ci>? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[478]); /* char-ci<=? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[486]); /* char-ci>=? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[496]); /* string-ci=? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[504]); /* string-ci<? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[512]); /* string-ci>? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[520]); /* string-ci<=? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[528]); /* string-ci>=? */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[538]); /* bytevector-uint-ref */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[556]); /* bytevector-sint-ref */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[576]); /* bytevector-uint-set! */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[587]); /* bytevector-sint-set! */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[595]); /* bytevector->uint-list */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[603]); /* bytevector->sint-list */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[615]); /* uint-list->bytevector */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[621]); /* sint-list->bytevector */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[411]); /* for-all */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[396]); /* exists */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[369]); /* filter */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[375]); /* filter! */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[660]); /* partition */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[153]); /* map */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[125]); /* for-each */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[679]); /* filter-map */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[689]); /* fold-left */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[700]); /* fold-right */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[704]); /* remp */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[709]); /* remove */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[713]); /* remv */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[717]); /* remq */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[721]); /* memp */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[725]); /* assp */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[729]); /* list-sort */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[889]); /* vector-sort */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[820]); /* vector-sort! */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[1051]); /* call-with-port */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[1055]); /* open-bytevector-output-port */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[1074]); /* open-string-output-port */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[1078]); /* call-with-bytevector-output-port */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[1082]); /* call-with-string-output-port */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[1086]); /* hashtable-equivalence-function */ 
    SG_APPEND1(G17639, G17640, sg__rc_cgen17086.d17186[1113]); /* hashtable-hash-function */ 
    sg__rc_cgen17086.d17186[1135] = G17639;
  } while (0);
  do {
    /* ((hashtable-for-each hashtable-map hashtable-fold hashtable->alist unique-id-list? call-with-values print fold wrong-type-argument-message vector-map vector-map! vector-for-each string-for-each string-join null-list? split-at find find-tail assoc member delete delete! reduce lset-union lset-intersection lset-difference take drop list-head make-ci-comparison char-ci=? char-ci<? char-ci>? char-ci<=? char-ci>=? string-ci=? string-ci<? string-ci>? string-ci<=? string-ci>=? bytevector-uint-ref bytevector-sint-ref bytevector-uint-set! bytevector-sint-set! bytevector->uint-list bytevector->sint-list uint-list->bytevector sint-list->bytevector for-all exists filter filter! partition map for-each filter-map fold-left fold-right remp remove remv remq memp assp list-sort vector-sort vector-sort! call-with-port open-bytevector-output-port open-string-output-port call-with-bytevector-output-port call-with-string-output-port hashtable-equivalence-function hashtable-hash-function)) */ 
    SgObject G17641 = SG_NIL, G17642 = SG_NIL;
    SG_APPEND1(G17641, G17642, sg__rc_cgen17086.d17186[1135]); /* (hashtable-for-each hashtable-map hashtable-fold hashtable->alist unique-id-list? call-with-values print fold wrong-type-argument-message vector-map vector-map! vector-for-each string-for-each string-join null-list? split-at find find-tail assoc member delete delete! reduce lset-union lset-intersection lset-difference take drop list-head make-ci-comparison char-ci=? char-ci<? char-ci>? char-ci<=? char-ci>=? string-ci=? string-ci<? string-ci>? string-ci<=? string-ci>=? bytevector-uint-ref bytevector-sint-ref bytevector-uint-set! bytevector-sint-set! bytevector->uint-list bytevector->sint-list uint-list->bytevector sint-list->bytevector for-all exists filter filter! partition map for-each filter-map fold-left fold-right remp remove remv remq memp assp list-sort vector-sort vector-sort! call-with-port open-bytevector-output-port open-string-output-port call-with-bytevector-output-port call-with-string-output-port hashtable-equivalence-function hashtable-hash-function) */ 
    sg__rc_cgen17086.d17186[1134] = G17641;
  } while (0);
  Sg_LibraryExportedSet(sg__rc_cgen17086.d17186[3], sg__rc_cgen17086.d17186[1134]);

  Sg_VM()->currentLibrary = sg__rc_cgen17086.d17186[3];
  Sg_VMExecute(SG_OBJ(G17087));
  Sg_VM()->currentLibrary = save;
}
