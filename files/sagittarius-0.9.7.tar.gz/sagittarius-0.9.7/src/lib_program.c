/* Generated automatically from ../boot/lib/program.scm. DO NOT EDIT! */
#define LIBSAGITTARIUS_BODY 
#include <sagittarius.h>
static struct sg__rc_cgen23495Rec {
  SgObject d23505[216];
  SgWord d23506[529];
  SgCodeBuilder d23507[6];
} sg__rc_cgen23495 = {
  {  /* SgObject d23505 */
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
  },
  {  /* SgWord d23506 */
    /* (script import-it) */0x00000048    /*   0 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* import */,
    0x00000005    /*   2 LREF */,
    0x00000238    /*   3 LIST */,
    0x0000000b    /*   4 PUSH */,
    0x00000030    /*   5 FRAME */,
    SG_WORD(3),
    0x0000004a    /*   7 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-library#core.program> */,
    0x0000000b    /*   9 PUSH */,
    0x0000024b    /*  10 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x0000002f    /*  12 RET */,
    /* program-r6rs */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier port?#core.program> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(4),
    0x00000005    /*   7 LREF */,
    0x00000018    /*   8 JUMP */,
    SG_WORD(32),
    0x00000030    /*  10 FRAME */,
    SG_WORD(4),
    0x00000045    /*  12 LREF_PUSH */,
    0x0000014a    /*  13 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier string?#core.program> */,
    0x00000017    /*  15 TEST */,
    SG_WORD(17),
    0x00000030    /*  17 FRAME */,
    SG_WORD(13),
    0x00000045    /*  19 LREF_PUSH */,
    0x00000048    /*  20 CONST_PUSH */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000048    /*  22 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* block */,
    0x00000030    /*  24 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier *current-load-transcoder*#core.program> */,
    0x0000000b    /*  28 PUSH */,
    0x0000044a    /*  29 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier open-file-input-port#core.program> */,
    0x00000018    /*  31 JUMP */,
    SG_WORD(9),
    0x00000030    /*  33 FRAME */,
    SG_WORD(7),
    0x00000048    /*  35 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* progam */,
    0x00000048    /*  37 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* Strict R6RS mode doesn't have REPL */,
    0x0000024a    /*  39 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier error#core.program> */,
    0x0000000b    /*  41 PUSH */,
    0x00000030    /*  42 FRAME */,
    SG_WORD(8),
    0x00000145    /*  44 LREF_PUSH */,
    0x00000048    /*  45 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* r6rs */,
    0x00000047    /*  47 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier *r6rs-read-context*#core.program> */,
    0x0000034a    /*  49 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier apply-directive!#core.program> */,
    0x00000030    /*  51 FRAME */,
    SG_WORD(4),
    0x00000145    /*  53 LREF_PUSH */,
    0x0000014a    /*  54 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier read#core.program> */,
    0x0000000b    /*  56 PUSH */,
    0x00000048    /*  57 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x00000030    /*  59 FRAME */,
    SG_WORD(4),
    0x00000245    /*  61 LREF_PUSH */,
    0x0000014a    /*  62 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eof-object?#core.program> */,
    0x00000017    /*  64 TEST */,
    SG_WORD(23),
    0x00000030    /*  66 FRAME */,
    SG_WORD(18),
    0x00000048    /*  68 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* program */,
    0x00000030    /*  70 FRAME */,
    SG_WORD(4),
    0x00000345    /*  72 LREF_PUSH */,
    0x0000014a    /*  73 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier reverse!#core.program> */,
    0x00000254    /*  75 CONS_PUSH */,
    0x00000030    /*  76 FRAME */,
    SG_WORD(5),
    0x00000048    /*  78 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (r6rs-script) */,
    0x0000014a    /*  80 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier environment#core.program> */,
    0x0000000b    /*  82 PUSH */,
    0x0000024a    /*  83 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x0000004b    /*  85 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier exit#core.program> */,
    0x0000002f    /*  87 RET */,
    0x00000030    /*  88 FRAME */,
    SG_WORD(4),
    0x00000145    /*  90 LREF_PUSH */,
    0x0000014a    /*  91 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier read#core.program> */,
    0x0000000b    /*  93 PUSH */,
    0x00000245    /*  94 LREF_PUSH */,
    0x00000305    /*  95 LREF */,
    0x00000054    /*  96 CONS_PUSH */,
    0x00200219    /*  97 SHIFTJ */,
    0x00000018    /*  98 JUMP */,
    SG_WORD(-40),
    0x0000002f    /* 100 RET */,
    /* repl */0x00000163    /*   0 RESV_STACK */,
    0x00000030    /*   1 FRAME */,
    SG_WORD(7),
    0x00000048    /*   3 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (sagittarius interactive) */,
    0x00000048    /*   5 CONST_PUSH */,
    SG_WORD(SG_FALSE) /* #f */,
    0x0000024a    /*   7 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier find-library#core.program> */,
    0x00000031    /*   9 INST_STACK */,
    0x00000005    /*  10 LREF */,
    0x00000017    /*  11 TEST */,
    SG_WORD(32),
    0x00000046    /*  13 FREF_PUSH */,
    0x00000003    /*  14 CONST */,
    SG_WORD(SG_UNDEF) /* r7rs */,
    0x0000001f    /*  16 BNEQ */,
    SG_WORD(21),
    0x00000030    /*  18 FRAME */,
    SG_WORD(6),
    0x00000048    /*  20 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (*import-libraries* '((scheme base))) */,
    0x00000045    /*  22 LREF_PUSH */,
    0x0000024a    /*  23 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x00000030    /*  25 FRAME */,
    SG_WORD(6),
    0x00000048    /*  27 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (current-prompter (lambda () (display sash[r7rs]> ))) */,
    0x00000045    /*  29 LREF_PUSH */,
    0x0000024a    /*  30 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x00000048    /*  32 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (read-eval-print-loop) */,
    0x00000045    /*  34 LREF_PUSH */,
    0x0000024b    /*  35 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x0000002f    /*  37 RET */,
    0x00000048    /*  38 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (read-eval-print-loop) */,
    0x00000045    /*  40 LREF_PUSH */,
    0x0000024b    /*  41 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x0000002f    /*  43 RET */,
    0x00000030    /*  44 FRAME */,
    SG_WORD(10),
    0x00000048    /*  46 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (sagittarius interactive) is not located on the loadpath. Add -L option to indicate it */,
    0x00000030    /*  48 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  50 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-error-port#core.program> */,
    0x0000000b    /*  52 PUSH */,
    0x0000024a    /*  53 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier display#core.program> */,
    0x00000030    /*  55 FRAME */,
    SG_WORD(8),
    0x00000030    /*  57 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  59 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-error-port#core.program> */,
    0x0000000b    /*  61 PUSH */,
    0x0000014a    /*  62 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier newline#core.program> */,
    -0x000000b7   /*  64 CONSTI_PUSH */,
    0x0000014b    /*  65 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier exit#core.program> */,
    0x0000002f    /*  67 RET */,
    /* script */0x00000263    /*   0 RESV_STACK */,
    0x00000009    /*   1 GREF */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda23504#core.program> */,
    0x00000331    /*   3 INST_STACK */,
    0x00000145    /*   4 LREF_PUSH */,
    0x00000029    /*   5 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23495.d23507[2])) /* #<code-builder repl (0 0 1)> */,
    0x00000431    /*   7 INST_STACK */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(6),
    0x00000048    /*  10 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* preimports */,
    0x00000245    /*  12 LREF_PUSH */,
    0x0000024a    /*  13 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assq#core.program> */,
    0x0000000b    /*  15 PUSH */,
    0x00000505    /*  16 LREF */,
    0x00000017    /*  17 TEST */,
    SG_WORD(10),
    0x00000030    /*  19 FRAME */,
    SG_WORD(6),
    0x00000047    /*  21 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda23504#core.program> */,
    0x0000055c    /*  23 LREF_CDR_PUSH */,
    0x0000024a    /*  24 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier for-each#core.program> */,
    0x00000018    /*  26 JUMP */,
    SG_WORD(2),
    0x00000002    /*  28 UNDEF */,
    0x00000132    /*  29 LEAVE */,
    0x00000030    /*  30 FRAME */,
    SG_WORD(6),
    0x00000048    /*  32 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* expressions */,
    0x00000245    /*  34 LREF_PUSH */,
    0x0000024a    /*  35 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assq#core.program> */,
    0x0000000b    /*  37 PUSH */,
    0x00000505    /*  38 LREF */,
    0x00000017    /*  39 TEST */,
    SG_WORD(15),
    0x00000030    /*  41 FRAME */,
    SG_WORD(11),
    0x00000030    /*  43 FRAME */,
    SG_WORD(4),
    0x0000055c    /*  45 LREF_CDR_PUSH */,
    0x0000014a    /*  46 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier open-string-input-port#core.program> */,
    0x0000000b    /*  48 PUSH */,
    0x00000047    /*  49 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier load-from-port#core.program> */,
    0x0000024a    /*  51 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier call-with-port#core.program> */,
    0x00000018    /*  53 JUMP */,
    SG_WORD(2),
    0x00000002    /*  55 UNDEF */,
    0x00000132    /*  56 LEAVE */,
    0x00000005    /*  57 LREF */,
    0x00000017    /*  58 TEST */,
    SG_WORD(202),
    0x00000145    /*  60 LREF_PUSH */,
    0x00000003    /*  61 CONST */,
    SG_WORD(SG_UNDEF) /* r7rs */,
    0x0000001f    /*  63 BNEQ */,
    SG_WORD(51),
    0x00000030    /*  65 FRAME */,
    SG_WORD(4),
    0x00000045    /*  67 LREF_PUSH */,
    0x0000014a    /*  68 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier port?#core.program> */,
    0x00000017    /*  70 TEST */,
    SG_WORD(4),
    0x00000005    /*  72 LREF */,
    0x00000018    /*  73 JUMP */,
    SG_WORD(15),
    0x00000030    /*  75 FRAME */,
    SG_WORD(13),
    0x00000045    /*  77 LREF_PUSH */,
    0x00000048    /*  78 CONST_PUSH */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000048    /*  80 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* block */,
    0x00000030    /*  82 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  84 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier *current-load-transcoder*#core.program> */,
    0x0000000b    /*  86 PUSH */,
    0x0000044a    /*  87 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier open-file-input-port#core.program> */,
    0x0000000b    /*  89 PUSH */,
    0x00000030    /*  90 FRAME */,
    SG_WORD(8),
    0x00000545    /*  92 LREF_PUSH */,
    0x00000048    /*  93 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* r7rs */,
    0x00000047    /*  95 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier *r6rs-read-context*#core.program> */,
    0x0000034a    /*  97 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier apply-directive!#core.program> */,
    0x00000030    /*  99 FRAME */,
    SG_WORD(7),
    0x00000048    /* 101 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* (import (only (sagittarius) cond-expand)) */,
    0x00000048    /* 103 CONST_PUSH */,
    SG_WORD(SG_FALSE) /* #f */,
    0x0000024a    /* 105 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x00000030    /* 107 FRAME */,
    SG_WORD(4),
    0x00000545    /* 109 LREF_PUSH */,
    0x0000014a    /* 110 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier load-from-port#core.program> */,
    0x00000132    /* 112 LEAVE */,
    0x00000018    /* 113 JUMP */,
    SG_WORD(20),
    0x00000030    /* 115 FRAME */,
    SG_WORD(4),
    0x00000045    /* 117 LREF_PUSH */,
    0x0000014a    /* 118 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier port?#core.program> */,
    0x00000017    /* 120 TEST */,
    SG_WORD(8),
    0x00000030    /* 122 FRAME */,
    SG_WORD(4),
    0x00000045    /* 124 LREF_PUSH */,
    0x0000014a    /* 125 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier load-from-port#core.program> */,
    0x00000018    /* 127 JUMP */,
    SG_WORD(6),
    0x00000030    /* 129 FRAME */,
    SG_WORD(4),
    0x00000045    /* 131 LREF_PUSH */,
    0x0000014a    /* 132 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier load#core.program> */,
    0x0000000b    /* 134 PUSH */,
    0x00000030    /* 135 FRAME */,
    SG_WORD(6),
    0x00000048    /* 137 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* main? */,
    0x00000245    /* 139 LREF_PUSH */,
    0x0000024a    /* 140 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assq#core.program> */,
    0x0000000b    /* 142 PUSH */,
    0x00000605    /* 143 LREF */,
    0x00000017    /* 144 TEST */,
    SG_WORD(96),
    0x00000656    /* 146 LREF_CDR */,
    0x00000017    /* 147 TEST */,
    SG_WORD(93),
    0x00000030    /* 149 FRAME */,
    SG_WORD(12),
    0x00000030    /* 151 FRAME */,
    SG_WORD(3),
    0x0000004a    /* 153 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-library#core.program> */,
    0x0000000b    /* 155 PUSH */,
    0x00000048    /* 156 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* main */,
    0x00000048    /* 158 CONST_PUSH */,
    SG_WORD(SG_FALSE) /* #f */,
    0x0000034a    /* 160 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier find-binding#core.program> */,
    0x0000000b    /* 162 PUSH */,
    0x00000705    /* 163 LREF */,
    0x00000017    /* 164 TEST */,
    SG_WORD(75),
    0x00000030    /* 166 FRAME */,
    SG_WORD(19),
    0x00000048    /* 168 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* main */,
    0x00000048    /* 170 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* quote */,
    0x00000030    /* 172 FRAME */,
    SG_WORD(3),
    0x0000004a    /* 174 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier command-line#core.program> */,
    0x00000238    /* 176 LIST */,
    0x00000238    /* 177 LIST */,
    0x0000000b    /* 178 PUSH */,
    0x00000030    /* 179 FRAME */,
    SG_WORD(3),
    0x0000004a    /* 181 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-library#core.program> */,
    0x0000000b    /* 183 PUSH */,
    0x0000024a    /* 184 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier eval#core.program> */,
    0x0000000b    /* 186 PUSH */,
    0x00000805    /* 187 LREF */,
    0x00000017    /* 188 TEST */,
    SG_WORD(50),
    0x00000030    /* 190 FRAME */,
    SG_WORD(4),
    0x00000845    /* 192 LREF_PUSH */,
    0x0000014a    /* 193 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier fixnum?#core.program> */,
    0x00000017    /* 195 TEST */,
    SG_WORD(23),
    0x00000030    /* 197 FRAME */,
    SG_WORD(6),
    0x00000048    /* 199 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* interactive? */,
    0x00000245    /* 201 LREF_PUSH */,
    0x0000024a    /* 202 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assq#core.program> */,
    0x00000017    /* 204 TEST */,
    SG_WORD(7),
    0x00000030    /* 206 FRAME */,
    SG_WORD(3),
    0x00000405    /* 208 LREF */,
    0x0000002c    /* 209 LOCAL_CALL */,
    0x00000018    /* 210 JUMP */,
    SG_WORD(6),
    0x00000030    /* 212 FRAME */,
    SG_WORD(4),
    0x00000845    /* 214 LREF_PUSH */,
    0x0000014a    /* 215 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier exit#core.program> */,
    0x00000018    /* 217 JUMP */,
    SG_WORD(21),
    0x00000030    /* 219 FRAME */,
    SG_WORD(6),
    0x00000048    /* 221 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* interactive? */,
    0x00000245    /* 223 LREF_PUSH */,
    0x0000024a    /* 224 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assq#core.program> */,
    0x00000017    /* 226 TEST */,
    SG_WORD(7),
    0x00000030    /* 228 FRAME */,
    SG_WORD(3),
    0x00000405    /* 230 LREF */,
    0x0000002c    /* 231 LOCAL_CALL */,
    0x00000018    /* 232 JUMP */,
    SG_WORD(6),
    0x00000030    /* 234 FRAME */,
    SG_WORD(4),
    0x00000545    /* 236 LREF_PUSH */,
    0x0000014a    /* 237 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier exit#core.program> */,
    0x00000132    /* 239 LEAVE */,
    0x00000132    /* 240 LEAVE */,
    0x00000132    /* 241 LEAVE */,
    0x00000017    /* 242 TEST */,
    SG_WORD(2),
    0x0000002f    /* 244 RET */,
    0x00000030    /* 245 FRAME */,
    SG_WORD(6),
    0x00000048    /* 247 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* interactive? */,
    0x00000245    /* 249 LREF_PUSH */,
    0x0000024a    /* 250 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assq#core.program> */,
    0x00000017    /* 252 TEST */,
    SG_WORD(4),
    0x00000405    /* 254 LREF */,
    0x0000002e    /* 255 LOCAL_TAIL_CALL */,
    0x0000002f    /* 256 RET */,
    0x00000545    /* 257 LREF_PUSH */,
    0x0000014b    /* 258 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier exit#core.program> */,
    0x0000002f    /* 260 RET */,
    0x00000405    /* 261 LREF */,
    0x0000002e    /* 262 LOCAL_TAIL_CALL */,
    0x0000002f    /* 263 RET */,
    /* start */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000145    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier command-line#core.program> */,
    0x00000030    /*   5 FRAME */,
    SG_WORD(6),
    0x00000048    /*   7 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* standard */,
    0x00000245    /*   9 LREF_PUSH */,
    0x0000024a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier assq#core.program> */,
    0x0000000b    /*  12 PUSH */,
    0x00000305    /*  13 LREF */,
    0x00000017    /*  14 TEST */,
    SG_WORD(6),
    0x00000030    /*  16 FRAME */,
    SG_WORD(4),
    0x00000345    /*  18 LREF_PUSH */,
    0x0000014a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier cdr#core.program> */,
    0x00000132    /*  21 LEAVE */,
    0x0000000b    /*  22 PUSH */,
    0x00000345    /*  23 LREF_PUSH */,
    0x00000604    /*  24 CONSTI */,
    0x00000020    /*  25 BNEQV */,
    SG_WORD(5),
    0x00000045    /*  27 LREF_PUSH */,
    0x0000014b    /*  28 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier program-r6rs#core.program> */,
    0x0000002f    /*  30 RET */,
    0x00000345    /*  31 LREF_PUSH */,
    0x00000704    /*  32 CONSTI */,
    0x00000020    /*  33 BNEQV */,
    SG_WORD(8),
    0x00000045    /*  35 LREF_PUSH */,
    0x00000048    /*  36 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* r7rs */,
    0x00000245    /*  38 LREF_PUSH */,
    0x0000034b    /*  39 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier script#core.program> */,
    0x0000002f    /*  41 RET */,
    0x00000045    /*  42 LREF_PUSH */,
    0x00000048    /*  43 CONST_PUSH */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000245    /*  45 LREF_PUSH */,
    0x0000034b    /*  46 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier script#core.program> */,
    0x0000002f    /*  48 RET */,
    /* #f */0x00000029    /*   0 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23495.d23507[0])) /* #<code-builder (script import-it) (1 0 0)> */,
    0x00000033    /*   2 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lambda23504#core.program> */,
    0x00000034    /*   4 LIBRARY */,
    SG_WORD(SG_UNDEF) /* #<library core.program> */,
    0x00000030    /*   6 FRAME */,
    SG_WORD(5),
    0x00000048    /*   8 CONST_PUSH */,
    SG_WORD(SG_NIL) /* () */,
    0x0000014a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-core-parameter#core.program> */,
    0x00000033    /*  12 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier command-line#core.program> */,
    0x00000030    /*  14 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  16 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-read-context-for-load#core.program> */,
    0x00000033    /*  18 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier *r6rs-read-context*#core.program> */,
    0x00000029    /*  20 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23495.d23507[1])) /* #<code-builder program-r6rs (1 0 0)> */,
    0x00000033    /*  22 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier program-r6rs#core.program> */,
    0x00000029    /*  24 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23495.d23507[3])) /* #<code-builder script (3 0 0)> */,
    0x00000033    /*  26 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier script#core.program> */,
    0x00000029    /*  28 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23495.d23507[4])) /* #<code-builder start (3 0 0)> */,
    0x00000033    /*  30 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier start#core.program> */,
    0x00000002    /*  32 UNDEF */,
    0x0000002f    /*  33 RET */,
  },
  {  /* SgCodeBuilder d23507 */
    
    SG_STATIC_CODE_BUILDER( /* (script import-it) */
      (SgWord *)SG_OBJ(&sg__rc_cgen23495.d23506[0]), SG_FALSE, 1, 0, 0, 9, 13),
    
    SG_STATIC_CODE_BUILDER( /* program-r6rs */
      (SgWord *)SG_OBJ(&sg__rc_cgen23495.d23506[13]), SG_FALSE, 1, 0, 0, 26, 101),
    
    SG_STATIC_CODE_BUILDER( /* repl */
      (SgWord *)SG_OBJ(&sg__rc_cgen23495.d23506[114]), SG_FALSE, 0, 0, 1, 16, 68),
    
    SG_STATIC_CODE_BUILDER( /* script */
      (SgWord *)SG_OBJ(&sg__rc_cgen23495.d23506[182]), SG_FALSE, 3, 0, 0, 51, 264),
    
    SG_STATIC_CODE_BUILDER( /* start */
      (SgWord *)SG_OBJ(&sg__rc_cgen23495.d23506[446]), SG_FALSE, 3, 0, 0, 25, 49),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen23495.d23506[495]), SG_FALSE, 0, 0, 0, 0, 34),
  },
};
static SgCodeBuilder *G23496 = 
   SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23495.d23507[5]));
void Sg__Init_core_program() {
  SgObject save = Sg_VM()->currentLibrary;

  sg__rc_cgen23495.d23505[1] = SG_MAKE_STRING("import");
  sg__rc_cgen23495.d23505[0] = Sg_Intern(sg__rc_cgen23495.d23505[1]); /* import */
  sg__rc_cgen23495.d23505[2] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[4] = SG_MAKE_STRING("current-library");
  sg__rc_cgen23495.d23505[3] = Sg_Intern(sg__rc_cgen23495.d23505[4]); /* current-library */
  sg__rc_cgen23495.d23505[7] = SG_MAKE_STRING("(core program)");
  sg__rc_cgen23495.d23505[6] = Sg_Intern(sg__rc_cgen23495.d23505[7]); /* (core program) */
  sg__rc_cgen23495.d23505[5] = Sg_FindLibrary(SG_SYMBOL(sg__rc_cgen23495.d23505[6]), TRUE);
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[2],SG_SYMBOL(sg__rc_cgen23495.d23505[3]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* current-library */
  sg__rc_cgen23495.d23505[8] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[10] = SG_MAKE_STRING("eval");
  sg__rc_cgen23495.d23505[9] = Sg_Intern(sg__rc_cgen23495.d23505[10]); /* eval */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[8],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[12] = SG_MAKE_STRING("(script import-it)");
  sg__rc_cgen23495.d23505[11] = Sg_Intern(sg__rc_cgen23495.d23505[12]); /* (script import-it) */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23495.d23507[0]))->name = sg__rc_cgen23495.d23505[11];/* (script import-it) */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[0]))[1] = SG_WORD(sg__rc_cgen23495.d23505[0]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[0]))[8] = SG_WORD(sg__rc_cgen23495.d23505[2]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[0]))[11] = SG_WORD(sg__rc_cgen23495.d23505[8]);
  sg__rc_cgen23495.d23505[13] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[15] = SG_MAKE_STRING("lambda23504");
  sg__rc_cgen23495.d23505[14] = Sg_MakeSymbol(SG_STRING(sg__rc_cgen23495.d23505[15]), FALSE); /* lambda23504 */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[13],SG_SYMBOL(sg__rc_cgen23495.d23505[14]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* lambda23504 */
  sg__rc_cgen23495.d23505[16] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[18] = SG_MAKE_STRING("make-core-parameter");
  sg__rc_cgen23495.d23505[17] = Sg_Intern(sg__rc_cgen23495.d23505[18]); /* make-core-parameter */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[16],SG_SYMBOL(sg__rc_cgen23495.d23505[17]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* make-core-parameter */
  sg__rc_cgen23495.d23505[19] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[21] = SG_MAKE_STRING("command-line");
  sg__rc_cgen23495.d23505[20] = Sg_Intern(sg__rc_cgen23495.d23505[21]); /* command-line */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[19],SG_SYMBOL(sg__rc_cgen23495.d23505[20]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* command-line */
  sg__rc_cgen23495.d23505[22] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[24] = SG_MAKE_STRING("make-read-context-for-load");
  sg__rc_cgen23495.d23505[23] = Sg_Intern(sg__rc_cgen23495.d23505[24]); /* make-read-context-for-load */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[22],SG_SYMBOL(sg__rc_cgen23495.d23505[23]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* make-read-context-for-load */
  sg__rc_cgen23495.d23505[25] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[27] = SG_MAKE_STRING("*r6rs-read-context*");
  sg__rc_cgen23495.d23505[26] = Sg_Intern(sg__rc_cgen23495.d23505[27]); /* *r6rs-read-context* */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[25],SG_SYMBOL(sg__rc_cgen23495.d23505[26]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* *r6rs-read-context* */
  sg__rc_cgen23495.d23505[28] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[30] = SG_MAKE_STRING("port?");
  sg__rc_cgen23495.d23505[29] = Sg_Intern(sg__rc_cgen23495.d23505[30]); /* port? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[28],SG_SYMBOL(sg__rc_cgen23495.d23505[29]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* port? */
  sg__rc_cgen23495.d23505[31] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[33] = SG_MAKE_STRING("string?");
  sg__rc_cgen23495.d23505[32] = Sg_Intern(sg__rc_cgen23495.d23505[33]); /* string? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[31],SG_SYMBOL(sg__rc_cgen23495.d23505[32]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* string? */
  sg__rc_cgen23495.d23505[35] = SG_MAKE_STRING("block");
  sg__rc_cgen23495.d23505[34] = Sg_Intern(sg__rc_cgen23495.d23505[35]); /* block */
  sg__rc_cgen23495.d23505[36] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[38] = SG_MAKE_STRING("*current-load-transcoder*");
  sg__rc_cgen23495.d23505[37] = Sg_Intern(sg__rc_cgen23495.d23505[38]); /* *current-load-transcoder* */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[36],SG_SYMBOL(sg__rc_cgen23495.d23505[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* *current-load-transcoder* */
  sg__rc_cgen23495.d23505[39] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[41] = SG_MAKE_STRING("open-file-input-port");
  sg__rc_cgen23495.d23505[40] = Sg_Intern(sg__rc_cgen23495.d23505[41]); /* open-file-input-port */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[39],SG_SYMBOL(sg__rc_cgen23495.d23505[40]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* open-file-input-port */
  sg__rc_cgen23495.d23505[43] = SG_MAKE_STRING("progam");
  sg__rc_cgen23495.d23505[42] = Sg_Intern(sg__rc_cgen23495.d23505[43]); /* progam */
  sg__rc_cgen23495.d23505[44] = SG_MAKE_STRING("Strict R6RS mode doesn't have REPL");
  sg__rc_cgen23495.d23505[45] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[47] = SG_MAKE_STRING("error");
  sg__rc_cgen23495.d23505[46] = Sg_Intern(sg__rc_cgen23495.d23505[47]); /* error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[45],SG_SYMBOL(sg__rc_cgen23495.d23505[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* error */
  sg__rc_cgen23495.d23505[49] = SG_MAKE_STRING("r6rs");
  sg__rc_cgen23495.d23505[48] = Sg_Intern(sg__rc_cgen23495.d23505[49]); /* r6rs */
  sg__rc_cgen23495.d23505[50] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[50],SG_SYMBOL(sg__rc_cgen23495.d23505[26]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* *r6rs-read-context* */
  sg__rc_cgen23495.d23505[51] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[53] = SG_MAKE_STRING("apply-directive!");
  sg__rc_cgen23495.d23505[52] = Sg_Intern(sg__rc_cgen23495.d23505[53]); /* apply-directive! */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[51],SG_SYMBOL(sg__rc_cgen23495.d23505[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* apply-directive! */
  sg__rc_cgen23495.d23505[54] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[56] = SG_MAKE_STRING("read");
  sg__rc_cgen23495.d23505[55] = Sg_Intern(sg__rc_cgen23495.d23505[56]); /* read */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[54],SG_SYMBOL(sg__rc_cgen23495.d23505[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* read */
  sg__rc_cgen23495.d23505[57] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[59] = SG_MAKE_STRING("eof-object?");
  sg__rc_cgen23495.d23505[58] = Sg_Intern(sg__rc_cgen23495.d23505[59]); /* eof-object? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[57],SG_SYMBOL(sg__rc_cgen23495.d23505[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eof-object? */
  sg__rc_cgen23495.d23505[61] = SG_MAKE_STRING("program");
  sg__rc_cgen23495.d23505[60] = Sg_Intern(sg__rc_cgen23495.d23505[61]); /* program */
  sg__rc_cgen23495.d23505[62] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[64] = SG_MAKE_STRING("reverse!");
  sg__rc_cgen23495.d23505[63] = Sg_Intern(sg__rc_cgen23495.d23505[64]); /* reverse! */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[62],SG_SYMBOL(sg__rc_cgen23495.d23505[63]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* reverse! */
  sg__rc_cgen23495.d23505[67] = SG_MAKE_STRING("r6rs-script");
  sg__rc_cgen23495.d23505[66] = Sg_Intern(sg__rc_cgen23495.d23505[67]); /* r6rs-script */
  do {
    /* (r6rs-script) */ 
    SgObject G23508 = SG_NIL, G23509 = SG_NIL;
    SG_APPEND1(G23508, G23509, sg__rc_cgen23495.d23505[66]); /* r6rs-script */ 
    sg__rc_cgen23495.d23505[65] = G23508;
  } while (0);
  sg__rc_cgen23495.d23505[68] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[70] = SG_MAKE_STRING("environment");
  sg__rc_cgen23495.d23505[69] = Sg_Intern(sg__rc_cgen23495.d23505[70]); /* environment */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[68],SG_SYMBOL(sg__rc_cgen23495.d23505[69]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* environment */
  sg__rc_cgen23495.d23505[71] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[71],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[72] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[74] = SG_MAKE_STRING("exit");
  sg__rc_cgen23495.d23505[73] = Sg_Intern(sg__rc_cgen23495.d23505[74]); /* exit */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[72],SG_SYMBOL(sg__rc_cgen23495.d23505[73]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* exit */
  sg__rc_cgen23495.d23505[75] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[75],SG_SYMBOL(sg__rc_cgen23495.d23505[55]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* read */
  sg__rc_cgen23495.d23505[77] = SG_MAKE_STRING("program-r6rs");
  sg__rc_cgen23495.d23505[76] = Sg_Intern(sg__rc_cgen23495.d23505[77]); /* program-r6rs */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23495.d23507[1]))->name = sg__rc_cgen23495.d23505[76];/* program-r6rs */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[4] = SG_WORD(sg__rc_cgen23495.d23505[28]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[14] = SG_WORD(sg__rc_cgen23495.d23505[31]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[23] = SG_WORD(sg__rc_cgen23495.d23505[34]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[27] = SG_WORD(sg__rc_cgen23495.d23505[36]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[30] = SG_WORD(sg__rc_cgen23495.d23505[39]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[36] = SG_WORD(sg__rc_cgen23495.d23505[42]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[38] = SG_WORD(sg__rc_cgen23495.d23505[44]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[40] = SG_WORD(sg__rc_cgen23495.d23505[45]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[46] = SG_WORD(sg__rc_cgen23495.d23505[48]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[48] = SG_WORD(sg__rc_cgen23495.d23505[50]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[50] = SG_WORD(sg__rc_cgen23495.d23505[51]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[55] = SG_WORD(sg__rc_cgen23495.d23505[54]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[63] = SG_WORD(sg__rc_cgen23495.d23505[57]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[69] = SG_WORD(sg__rc_cgen23495.d23505[60]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[74] = SG_WORD(sg__rc_cgen23495.d23505[62]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[79] = SG_WORD(sg__rc_cgen23495.d23505[65]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[81] = SG_WORD(sg__rc_cgen23495.d23505[68]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[84] = SG_WORD(sg__rc_cgen23495.d23505[71]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[86] = SG_WORD(sg__rc_cgen23495.d23505[72]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[13]))[92] = SG_WORD(sg__rc_cgen23495.d23505[75]);
  sg__rc_cgen23495.d23505[78] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[78],SG_SYMBOL(sg__rc_cgen23495.d23505[76]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* program-r6rs */
  sg__rc_cgen23495.d23505[81] = SG_MAKE_STRING("sagittarius");
  sg__rc_cgen23495.d23505[80] = Sg_Intern(sg__rc_cgen23495.d23505[81]); /* sagittarius */
  sg__rc_cgen23495.d23505[83] = SG_MAKE_STRING("interactive");
  sg__rc_cgen23495.d23505[82] = Sg_Intern(sg__rc_cgen23495.d23505[83]); /* interactive */
  do {
    /* (sagittarius interactive) */ 
    SgObject G23510 = SG_NIL, G23511 = SG_NIL;
    SG_APPEND1(G23510, G23511, sg__rc_cgen23495.d23505[80]); /* sagittarius */ 
    SG_APPEND1(G23510, G23511, sg__rc_cgen23495.d23505[82]); /* interactive */ 
    sg__rc_cgen23495.d23505[79] = G23510;
  } while (0);
  sg__rc_cgen23495.d23505[84] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[86] = SG_MAKE_STRING("find-library");
  sg__rc_cgen23495.d23505[85] = Sg_Intern(sg__rc_cgen23495.d23505[86]); /* find-library */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[84],SG_SYMBOL(sg__rc_cgen23495.d23505[85]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* find-library */
  sg__rc_cgen23495.d23505[88] = SG_MAKE_STRING("r7rs");
  sg__rc_cgen23495.d23505[87] = Sg_Intern(sg__rc_cgen23495.d23505[88]); /* r7rs */
  sg__rc_cgen23495.d23505[91] = SG_MAKE_STRING("*import-libraries*");
  sg__rc_cgen23495.d23505[90] = Sg_Intern(sg__rc_cgen23495.d23505[91]); /* *import-libraries* */
  sg__rc_cgen23495.d23505[94] = SG_MAKE_STRING("quote");
  sg__rc_cgen23495.d23505[93] = Sg_Intern(sg__rc_cgen23495.d23505[94]); /* quote */
  sg__rc_cgen23495.d23505[98] = SG_MAKE_STRING("scheme");
  sg__rc_cgen23495.d23505[97] = Sg_Intern(sg__rc_cgen23495.d23505[98]); /* scheme */
  sg__rc_cgen23495.d23505[100] = SG_MAKE_STRING("base");
  sg__rc_cgen23495.d23505[99] = Sg_Intern(sg__rc_cgen23495.d23505[100]); /* base */
  do {
    /* (scheme base) */ 
    SgObject G23512 = SG_NIL, G23513 = SG_NIL;
    SG_APPEND1(G23512, G23513, sg__rc_cgen23495.d23505[97]); /* scheme */ 
    SG_APPEND1(G23512, G23513, sg__rc_cgen23495.d23505[99]); /* base */ 
    sg__rc_cgen23495.d23505[96] = G23512;
  } while (0);
  do {
    /* ((scheme base)) */ 
    SgObject G23514 = SG_NIL, G23515 = SG_NIL;
    SG_APPEND1(G23514, G23515, sg__rc_cgen23495.d23505[96]); /* (scheme base) */ 
    sg__rc_cgen23495.d23505[95] = G23514;
  } while (0);
  do {
    /* '((scheme base)) */ 
    SgObject G23516 = SG_NIL, G23517 = SG_NIL;
    SG_APPEND1(G23516, G23517, sg__rc_cgen23495.d23505[93]); /* quote */ 
    SG_APPEND1(G23516, G23517, sg__rc_cgen23495.d23505[95]); /* ((scheme base)) */ 
    sg__rc_cgen23495.d23505[92] = G23516;
  } while (0);
  do {
    /* (*import-libraries* '((scheme base))) */ 
    SgObject G23518 = SG_NIL, G23519 = SG_NIL;
    SG_APPEND1(G23518, G23519, sg__rc_cgen23495.d23505[90]); /* *import-libraries* */ 
    SG_APPEND1(G23518, G23519, sg__rc_cgen23495.d23505[92]); /* '((scheme base)) */ 
    sg__rc_cgen23495.d23505[89] = G23518;
  } while (0);
  sg__rc_cgen23495.d23505[101] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[101],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[104] = SG_MAKE_STRING("current-prompter");
  sg__rc_cgen23495.d23505[103] = Sg_Intern(sg__rc_cgen23495.d23505[104]); /* current-prompter */
  sg__rc_cgen23495.d23505[107] = SG_MAKE_STRING("lambda");
  sg__rc_cgen23495.d23505[106] = Sg_Intern(sg__rc_cgen23495.d23505[107]); /* lambda */
  sg__rc_cgen23495.d23505[110] = SG_MAKE_STRING("display");
  sg__rc_cgen23495.d23505[109] = Sg_Intern(sg__rc_cgen23495.d23505[110]); /* display */
  sg__rc_cgen23495.d23505[111] = SG_MAKE_STRING("sash[r7rs]> ");
  do {
    /* (display "sash[r7rs]> ") */ 
    SgObject G23520 = SG_NIL, G23521 = SG_NIL;
    SG_APPEND1(G23520, G23521, sg__rc_cgen23495.d23505[109]); /* display */ 
    SG_APPEND1(G23520, G23521, sg__rc_cgen23495.d23505[111]); /* "sash[r7rs]> " */ 
    sg__rc_cgen23495.d23505[108] = G23520;
  } while (0);
  do {
    /* (lambda () (display "sash[r7rs]> ")) */ 
    SgObject G23522 = SG_NIL, G23523 = SG_NIL;
    SG_APPEND1(G23522, G23523, sg__rc_cgen23495.d23505[106]); /* lambda */ 
    SG_APPEND1(G23522, G23523, SG_NIL); /* () */ 
    SG_APPEND1(G23522, G23523, sg__rc_cgen23495.d23505[108]); /* (display "sash[r7rs]> ") */ 
    sg__rc_cgen23495.d23505[105] = G23522;
  } while (0);
  do {
    /* (current-prompter (lambda () (display "sash[r7rs]> "))) */ 
    SgObject G23524 = SG_NIL, G23525 = SG_NIL;
    SG_APPEND1(G23524, G23525, sg__rc_cgen23495.d23505[103]); /* current-prompter */ 
    SG_APPEND1(G23524, G23525, sg__rc_cgen23495.d23505[105]); /* (lambda () (display "sash[r7rs]> ")) */ 
    sg__rc_cgen23495.d23505[102] = G23524;
  } while (0);
  sg__rc_cgen23495.d23505[112] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[112],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[115] = SG_MAKE_STRING("read-eval-print-loop");
  sg__rc_cgen23495.d23505[114] = Sg_Intern(sg__rc_cgen23495.d23505[115]); /* read-eval-print-loop */
  do {
    /* (read-eval-print-loop) */ 
    SgObject G23526 = SG_NIL, G23527 = SG_NIL;
    SG_APPEND1(G23526, G23527, sg__rc_cgen23495.d23505[114]); /* read-eval-print-loop */ 
    sg__rc_cgen23495.d23505[113] = G23526;
  } while (0);
  sg__rc_cgen23495.d23505[116] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[116],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[117] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[117],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[118] = SG_MAKE_STRING("(sagittarius interactive) is not located on the loadpath. Add -L option to indicate it");
  sg__rc_cgen23495.d23505[119] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[121] = SG_MAKE_STRING("current-error-port");
  sg__rc_cgen23495.d23505[120] = Sg_Intern(sg__rc_cgen23495.d23505[121]); /* current-error-port */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[119],SG_SYMBOL(sg__rc_cgen23495.d23505[120]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* current-error-port */
  sg__rc_cgen23495.d23505[122] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[122],SG_SYMBOL(sg__rc_cgen23495.d23505[109]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* display */
  sg__rc_cgen23495.d23505[123] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[123],SG_SYMBOL(sg__rc_cgen23495.d23505[120]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* current-error-port */
  sg__rc_cgen23495.d23505[124] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[126] = SG_MAKE_STRING("newline");
  sg__rc_cgen23495.d23505[125] = Sg_Intern(sg__rc_cgen23495.d23505[126]); /* newline */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[124],SG_SYMBOL(sg__rc_cgen23495.d23505[125]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* newline */
  sg__rc_cgen23495.d23505[127] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[127],SG_SYMBOL(sg__rc_cgen23495.d23505[73]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* exit */
  sg__rc_cgen23495.d23505[129] = SG_MAKE_STRING("repl");
  sg__rc_cgen23495.d23505[128] = Sg_Intern(sg__rc_cgen23495.d23505[129]); /* repl */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23495.d23507[2]))->name = sg__rc_cgen23495.d23505[128];/* repl */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[4] = SG_WORD(sg__rc_cgen23495.d23505[79]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[8] = SG_WORD(sg__rc_cgen23495.d23505[84]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[15] = SG_WORD(sg__rc_cgen23495.d23505[87]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[21] = SG_WORD(sg__rc_cgen23495.d23505[89]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[24] = SG_WORD(sg__rc_cgen23495.d23505[101]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[28] = SG_WORD(sg__rc_cgen23495.d23505[102]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[31] = SG_WORD(sg__rc_cgen23495.d23505[112]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[33] = SG_WORD(sg__rc_cgen23495.d23505[113]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[36] = SG_WORD(sg__rc_cgen23495.d23505[116]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[39] = SG_WORD(sg__rc_cgen23495.d23505[113]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[42] = SG_WORD(sg__rc_cgen23495.d23505[117]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[47] = SG_WORD(sg__rc_cgen23495.d23505[118]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[51] = SG_WORD(sg__rc_cgen23495.d23505[119]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[54] = SG_WORD(sg__rc_cgen23495.d23505[122]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[60] = SG_WORD(sg__rc_cgen23495.d23505[123]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[63] = SG_WORD(sg__rc_cgen23495.d23505[124]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[114]))[66] = SG_WORD(sg__rc_cgen23495.d23505[127]);
  sg__rc_cgen23495.d23505[131] = SG_MAKE_STRING("preimports");
  sg__rc_cgen23495.d23505[130] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen23495.d23505[131])); /* preimports */
  sg__rc_cgen23495.d23505[132] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[134] = SG_MAKE_STRING("assq");
  sg__rc_cgen23495.d23505[133] = Sg_Intern(sg__rc_cgen23495.d23505[134]); /* assq */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[132],SG_SYMBOL(sg__rc_cgen23495.d23505[133]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* assq */
  sg__rc_cgen23495.d23505[135] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[137] = SG_MAKE_STRING("for-each");
  sg__rc_cgen23495.d23505[136] = Sg_Intern(sg__rc_cgen23495.d23505[137]); /* for-each */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[135],SG_SYMBOL(sg__rc_cgen23495.d23505[136]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* for-each */
  sg__rc_cgen23495.d23505[139] = SG_MAKE_STRING("expressions");
  sg__rc_cgen23495.d23505[138] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen23495.d23505[139])); /* expressions */
  sg__rc_cgen23495.d23505[140] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[140],SG_SYMBOL(sg__rc_cgen23495.d23505[133]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* assq */
  sg__rc_cgen23495.d23505[141] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[143] = SG_MAKE_STRING("open-string-input-port");
  sg__rc_cgen23495.d23505[142] = Sg_Intern(sg__rc_cgen23495.d23505[143]); /* open-string-input-port */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[141],SG_SYMBOL(sg__rc_cgen23495.d23505[142]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* open-string-input-port */
  sg__rc_cgen23495.d23505[144] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[146] = SG_MAKE_STRING("load-from-port");
  sg__rc_cgen23495.d23505[145] = Sg_Intern(sg__rc_cgen23495.d23505[146]); /* load-from-port */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[144],SG_SYMBOL(sg__rc_cgen23495.d23505[145]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* load-from-port */
  sg__rc_cgen23495.d23505[147] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[149] = SG_MAKE_STRING("call-with-port");
  sg__rc_cgen23495.d23505[148] = Sg_Intern(sg__rc_cgen23495.d23505[149]); /* call-with-port */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[147],SG_SYMBOL(sg__rc_cgen23495.d23505[148]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* call-with-port */
  sg__rc_cgen23495.d23505[150] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[150],SG_SYMBOL(sg__rc_cgen23495.d23505[29]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* port? */
  sg__rc_cgen23495.d23505[151] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[151],SG_SYMBOL(sg__rc_cgen23495.d23505[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* *current-load-transcoder* */
  sg__rc_cgen23495.d23505[152] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[152],SG_SYMBOL(sg__rc_cgen23495.d23505[40]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* open-file-input-port */
  sg__rc_cgen23495.d23505[153] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[153],SG_SYMBOL(sg__rc_cgen23495.d23505[26]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* *r6rs-read-context* */
  sg__rc_cgen23495.d23505[154] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[154],SG_SYMBOL(sg__rc_cgen23495.d23505[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* apply-directive! */
  sg__rc_cgen23495.d23505[158] = SG_MAKE_STRING("only");
  sg__rc_cgen23495.d23505[157] = Sg_Intern(sg__rc_cgen23495.d23505[158]); /* only */
  do {
    /* (sagittarius) */ 
    SgObject G23528 = SG_NIL, G23529 = SG_NIL;
    SG_APPEND1(G23528, G23529, sg__rc_cgen23495.d23505[80]); /* sagittarius */ 
    sg__rc_cgen23495.d23505[159] = G23528;
  } while (0);
  sg__rc_cgen23495.d23505[161] = SG_MAKE_STRING("cond-expand");
  sg__rc_cgen23495.d23505[160] = Sg_Intern(sg__rc_cgen23495.d23505[161]); /* cond-expand */
  do {
    /* (only (sagittarius) cond-expand) */ 
    SgObject G23530 = SG_NIL, G23531 = SG_NIL;
    SG_APPEND1(G23530, G23531, sg__rc_cgen23495.d23505[157]); /* only */ 
    SG_APPEND1(G23530, G23531, sg__rc_cgen23495.d23505[159]); /* (sagittarius) */ 
    SG_APPEND1(G23530, G23531, sg__rc_cgen23495.d23505[160]); /* cond-expand */ 
    sg__rc_cgen23495.d23505[156] = G23530;
  } while (0);
  do {
    /* (import (only (sagittarius) cond-expand)) */ 
    SgObject G23532 = SG_NIL, G23533 = SG_NIL;
    SG_APPEND1(G23532, G23533, sg__rc_cgen23495.d23505[0]); /* import */ 
    SG_APPEND1(G23532, G23533, sg__rc_cgen23495.d23505[156]); /* (only (sagittarius) cond-expand) */ 
    sg__rc_cgen23495.d23505[155] = G23532;
  } while (0);
  sg__rc_cgen23495.d23505[162] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[162],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[163] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[163],SG_SYMBOL(sg__rc_cgen23495.d23505[145]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* load-from-port */
  sg__rc_cgen23495.d23505[164] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[164],SG_SYMBOL(sg__rc_cgen23495.d23505[29]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* port? */
  sg__rc_cgen23495.d23505[165] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[165],SG_SYMBOL(sg__rc_cgen23495.d23505[145]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* load-from-port */
  sg__rc_cgen23495.d23505[166] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[168] = SG_MAKE_STRING("load");
  sg__rc_cgen23495.d23505[167] = Sg_Intern(sg__rc_cgen23495.d23505[168]); /* load */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[166],SG_SYMBOL(sg__rc_cgen23495.d23505[167]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* load */
  sg__rc_cgen23495.d23505[170] = SG_MAKE_STRING("main?");
  sg__rc_cgen23495.d23505[169] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen23495.d23505[170])); /* main? */
  sg__rc_cgen23495.d23505[171] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[171],SG_SYMBOL(sg__rc_cgen23495.d23505[133]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* assq */
  sg__rc_cgen23495.d23505[172] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[172],SG_SYMBOL(sg__rc_cgen23495.d23505[3]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* current-library */
  sg__rc_cgen23495.d23505[174] = SG_MAKE_STRING("main");
  sg__rc_cgen23495.d23505[173] = Sg_Intern(sg__rc_cgen23495.d23505[174]); /* main */
  sg__rc_cgen23495.d23505[175] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[177] = SG_MAKE_STRING("find-binding");
  sg__rc_cgen23495.d23505[176] = Sg_Intern(sg__rc_cgen23495.d23505[177]); /* find-binding */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[175],SG_SYMBOL(sg__rc_cgen23495.d23505[176]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* find-binding */
  sg__rc_cgen23495.d23505[178] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[178],SG_SYMBOL(sg__rc_cgen23495.d23505[20]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* command-line */
  sg__rc_cgen23495.d23505[179] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[179],SG_SYMBOL(sg__rc_cgen23495.d23505[3]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* current-library */
  sg__rc_cgen23495.d23505[180] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[180],SG_SYMBOL(sg__rc_cgen23495.d23505[9]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* eval */
  sg__rc_cgen23495.d23505[181] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[183] = SG_MAKE_STRING("fixnum?");
  sg__rc_cgen23495.d23505[182] = Sg_Intern(sg__rc_cgen23495.d23505[183]); /* fixnum? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[181],SG_SYMBOL(sg__rc_cgen23495.d23505[182]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* fixnum? */
  sg__rc_cgen23495.d23505[185] = SG_MAKE_STRING("interactive?");
  sg__rc_cgen23495.d23505[184] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen23495.d23505[185])); /* interactive? */
  sg__rc_cgen23495.d23505[186] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[186],SG_SYMBOL(sg__rc_cgen23495.d23505[133]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* assq */
  sg__rc_cgen23495.d23505[187] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[187],SG_SYMBOL(sg__rc_cgen23495.d23505[73]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* exit */
  sg__rc_cgen23495.d23505[189] = SG_MAKE_STRING("script");
  sg__rc_cgen23495.d23505[188] = Sg_Intern(sg__rc_cgen23495.d23505[189]); /* script */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23495.d23507[3]))->name = sg__rc_cgen23495.d23505[188];/* script */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[2] = SG_WORD(sg__rc_cgen23495.d23505[13]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[11] = SG_WORD(sg__rc_cgen23495.d23505[130]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[14] = SG_WORD(sg__rc_cgen23495.d23505[132]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[22] = SG_WORD(sg__rc_cgen23495.d23505[13]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[25] = SG_WORD(sg__rc_cgen23495.d23505[135]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[33] = SG_WORD(sg__rc_cgen23495.d23505[138]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[36] = SG_WORD(sg__rc_cgen23495.d23505[140]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[47] = SG_WORD(sg__rc_cgen23495.d23505[141]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[50] = SG_WORD(sg__rc_cgen23495.d23505[144]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[52] = SG_WORD(sg__rc_cgen23495.d23505[147]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[62] = SG_WORD(sg__rc_cgen23495.d23505[87]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[69] = SG_WORD(sg__rc_cgen23495.d23505[150]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[81] = SG_WORD(sg__rc_cgen23495.d23505[34]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[85] = SG_WORD(sg__rc_cgen23495.d23505[151]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[88] = SG_WORD(sg__rc_cgen23495.d23505[152]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[94] = SG_WORD(sg__rc_cgen23495.d23505[87]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[96] = SG_WORD(sg__rc_cgen23495.d23505[153]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[98] = SG_WORD(sg__rc_cgen23495.d23505[154]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[102] = SG_WORD(sg__rc_cgen23495.d23505[155]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[106] = SG_WORD(sg__rc_cgen23495.d23505[162]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[111] = SG_WORD(sg__rc_cgen23495.d23505[163]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[119] = SG_WORD(sg__rc_cgen23495.d23505[164]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[126] = SG_WORD(sg__rc_cgen23495.d23505[165]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[133] = SG_WORD(sg__rc_cgen23495.d23505[166]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[138] = SG_WORD(sg__rc_cgen23495.d23505[169]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[141] = SG_WORD(sg__rc_cgen23495.d23505[171]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[154] = SG_WORD(sg__rc_cgen23495.d23505[172]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[157] = SG_WORD(sg__rc_cgen23495.d23505[173]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[161] = SG_WORD(sg__rc_cgen23495.d23505[175]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[169] = SG_WORD(sg__rc_cgen23495.d23505[173]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[171] = SG_WORD(sg__rc_cgen23495.d23505[93]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[175] = SG_WORD(sg__rc_cgen23495.d23505[178]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[182] = SG_WORD(sg__rc_cgen23495.d23505[179]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[185] = SG_WORD(sg__rc_cgen23495.d23505[180]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[194] = SG_WORD(sg__rc_cgen23495.d23505[181]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[200] = SG_WORD(sg__rc_cgen23495.d23505[184]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[203] = SG_WORD(sg__rc_cgen23495.d23505[186]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[216] = SG_WORD(sg__rc_cgen23495.d23505[187]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[222] = SG_WORD(sg__rc_cgen23495.d23505[184]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[225] = SG_WORD(sg__rc_cgen23495.d23505[186]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[238] = SG_WORD(sg__rc_cgen23495.d23505[187]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[248] = SG_WORD(sg__rc_cgen23495.d23505[184]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[251] = SG_WORD(sg__rc_cgen23495.d23505[186]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[182]))[259] = SG_WORD(sg__rc_cgen23495.d23505[187]);
  sg__rc_cgen23495.d23505[190] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[190],SG_SYMBOL(sg__rc_cgen23495.d23505[188]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* script */
  sg__rc_cgen23495.d23505[191] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[191],SG_SYMBOL(sg__rc_cgen23495.d23505[20]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* command-line */
  sg__rc_cgen23495.d23505[193] = SG_MAKE_STRING("standard");
  sg__rc_cgen23495.d23505[192] = Sg_MakeKeyword(SG_STRING(sg__rc_cgen23495.d23505[193])); /* standard */
  sg__rc_cgen23495.d23505[194] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[194],SG_SYMBOL(sg__rc_cgen23495.d23505[133]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* assq */
  sg__rc_cgen23495.d23505[195] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23495.d23505[197] = SG_MAKE_STRING("cdr");
  sg__rc_cgen23495.d23505[196] = Sg_Intern(sg__rc_cgen23495.d23505[197]); /* cdr */
  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[195],SG_SYMBOL(sg__rc_cgen23495.d23505[196]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* cdr */
  sg__rc_cgen23495.d23505[198] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[198],SG_SYMBOL(sg__rc_cgen23495.d23505[76]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* program-r6rs */
  sg__rc_cgen23495.d23505[199] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[199],SG_SYMBOL(sg__rc_cgen23495.d23505[188]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* script */
  sg__rc_cgen23495.d23505[200] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[200],SG_SYMBOL(sg__rc_cgen23495.d23505[188]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* script */
  sg__rc_cgen23495.d23505[202] = SG_MAKE_STRING("start");
  sg__rc_cgen23495.d23505[201] = Sg_Intern(sg__rc_cgen23495.d23505[202]); /* start */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23495.d23507[4]))->name = sg__rc_cgen23495.d23505[201];/* start */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[4] = SG_WORD(sg__rc_cgen23495.d23505[191]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[8] = SG_WORD(sg__rc_cgen23495.d23505[192]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[11] = SG_WORD(sg__rc_cgen23495.d23505[194]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[20] = SG_WORD(sg__rc_cgen23495.d23505[195]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[29] = SG_WORD(sg__rc_cgen23495.d23505[198]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[37] = SG_WORD(sg__rc_cgen23495.d23505[87]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[40] = SG_WORD(sg__rc_cgen23495.d23505[199]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[446]))[47] = SG_WORD(sg__rc_cgen23495.d23505[200]);
  sg__rc_cgen23495.d23505[203] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23495.d23505[203],SG_SYMBOL(sg__rc_cgen23495.d23505[201]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23495.d23505[5]),FALSE); /* start */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[3] = SG_WORD(sg__rc_cgen23495.d23505[13]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[5] = SG_WORD(sg__rc_cgen23495.d23505[5]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[11] = SG_WORD(sg__rc_cgen23495.d23505[16]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[13] = SG_WORD(sg__rc_cgen23495.d23505[19]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[17] = SG_WORD(sg__rc_cgen23495.d23505[22]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[19] = SG_WORD(sg__rc_cgen23495.d23505[25]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[23] = SG_WORD(sg__rc_cgen23495.d23505[78]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[27] = SG_WORD(sg__rc_cgen23495.d23505[190]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23495.d23506[495]))[31] = SG_WORD(sg__rc_cgen23495.d23505[203]);
  sg__rc_cgen23495.d23505[205] = SG_MAKE_STRING("(core)");
  sg__rc_cgen23495.d23505[204] = Sg_Intern(sg__rc_cgen23495.d23505[205]); /* (core) */
  Sg_ImportLibrary(sg__rc_cgen23495.d23505[5], sg__rc_cgen23495.d23505[204]);

  sg__rc_cgen23495.d23505[207] = SG_MAKE_STRING("(core base)");
  sg__rc_cgen23495.d23505[206] = Sg_Intern(sg__rc_cgen23495.d23505[207]); /* (core base) */
  Sg_ImportLibrary(sg__rc_cgen23495.d23505[5], sg__rc_cgen23495.d23505[206]);

  sg__rc_cgen23495.d23505[209] = SG_MAKE_STRING("(sagittarius)");
  sg__rc_cgen23495.d23505[208] = Sg_Intern(sg__rc_cgen23495.d23505[209]); /* (sagittarius) */
  Sg_ImportLibrary(sg__rc_cgen23495.d23505[5], sg__rc_cgen23495.d23505[208]);

  sg__rc_cgen23495.d23505[211] = SG_MAKE_STRING("(sagittarius vm)");
  sg__rc_cgen23495.d23505[210] = Sg_Intern(sg__rc_cgen23495.d23505[211]); /* (sagittarius vm) */
  Sg_ImportLibrary(sg__rc_cgen23495.d23505[5], sg__rc_cgen23495.d23505[210]);

  sg__rc_cgen23495.d23505[213] = SG_MAKE_STRING("(sagittarius fixnums)");
  sg__rc_cgen23495.d23505[212] = Sg_Intern(sg__rc_cgen23495.d23505[213]); /* (sagittarius fixnums) */
  Sg_ImportLibrary(sg__rc_cgen23495.d23505[5], sg__rc_cgen23495.d23505[212]);

  do {
    /* (command-line start) */ 
    SgObject G23534 = SG_NIL, G23535 = SG_NIL;
    SG_APPEND1(G23534, G23535, sg__rc_cgen23495.d23505[20]); /* command-line */ 
    SG_APPEND1(G23534, G23535, sg__rc_cgen23495.d23505[201]); /* start */ 
    sg__rc_cgen23495.d23505[215] = G23534;
  } while (0);
  do {
    /* ((command-line start)) */ 
    SgObject G23536 = SG_NIL, G23537 = SG_NIL;
    SG_APPEND1(G23536, G23537, sg__rc_cgen23495.d23505[215]); /* (command-line start) */ 
    sg__rc_cgen23495.d23505[214] = G23536;
  } while (0);
  Sg_LibraryExportedSet(sg__rc_cgen23495.d23505[5], sg__rc_cgen23495.d23505[214]);

  Sg_VM()->currentLibrary = sg__rc_cgen23495.d23505[5];
  Sg_VMExecute(SG_OBJ(G23496));
  Sg_VM()->currentLibrary = save;
}
