/* Generated automatically from ../boot/lib/errors.scm. DO NOT EDIT! */
#define LIBSAGITTARIUS_BODY 
#include <sagittarius.h>
static struct sg__rc_cgen23449Rec {
  SgObject d23473[279];
  SgWord d23474[848];
  SgCodeBuilder d23475[23];
} sg__rc_cgen23449 = {
  {  /* SgObject d23473 */
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
    SG_UNBOUND,
  },
  {  /* SgWord d23474 */
    /* %condition-message */0x00000030    /*   0 FRAME */,
    SG_WORD(4),
    0x00000045    /*   2 LREF_PUSH */,
    0x0000014a    /*   3 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier message-condition?#core.errors> */,
    0x00000017    /*   5 TEST */,
    SG_WORD(35),
    0x00000030    /*   7 FRAME */,
    SG_WORD(4),
    0x00000045    /*   9 LREF_PUSH */,
    0x0000014a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier simple-condition?#core.errors> */,
    0x00000017    /*  12 TEST */,
    SG_WORD(5),
    0x00000045    /*  14 LREF_PUSH */,
    0x0000014b    /*  15 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier &message-message#core.errors> */,
    0x0000002f    /*  17 RET */,
    0x00000030    /*  18 FRAME */,
    SG_WORD(4),
    0x00000045    /*  20 LREF_PUSH */,
    0x0000014a    /*  21 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier &compound-condition-components#core.errors> */,
    0x0000000b    /*  23 PUSH */,
    0x00000105    /*  24 LREF */,
    0x00000021    /*  25 BNNULL */,
    SG_WORD(3),
    0x00000061    /*  27 CONST_RET */,
    SG_WORD(SG_FALSE) /* #f */,
    0x00000030    /*  29 FRAME */,
    SG_WORD(4),
    0x0000015b    /*  31 LREF_CAR_PUSH */,
    0x0000014a    /*  32 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier %condition-message#core.errors> */,
    0x00000017    /*  34 TEST */,
    SG_WORD(2),
    0x0000002f    /*  36 RET */,
    0x0000015c    /*  37 LREF_CDR_PUSH */,
    0x00100119    /*  38 SHIFTJ */,
    0x00000018    /*  39 JUMP */,
    SG_WORD(-16),
    0x0000002f    /*  41 RET */,
    /* raise-continuable */0x00000163    /*   0 RESV_STACK */,
    0x00000030    /*   1 FRAME */,
    SG_WORD(4),
    0x00000045    /*   3 LREF_PUSH */,
    0x0000014a    /*   4 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier vm-attach-stack-trace#core.errors> */,
    0x00000131    /*   6 INST_STACK */,
    0x00000145    /*   7 LREF_PUSH */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-exception-handlers#core.errors> */,
    0x00000035    /*  12 CAR */,
    0x0000012d    /*  13 TAIL_CALL */,
    0x0000002f    /*  14 RET */,
    /* raise */0x00000163    /*   0 RESV_STACK */,
    0x00000030    /*   1 FRAME */,
    SG_WORD(4),
    0x00000045    /*   3 LREF_PUSH */,
    0x0000014a    /*   4 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier vm-attach-stack-trace#core.errors> */,
    0x00000131    /*   6 INST_STACK */,
    0x00000030    /*   7 FRAME */,
    SG_WORD(3),
    0x0000004a    /*   9 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-exception-handlers#core.errors> */,
    0x0000000b    /*  11 PUSH */,
    0x00000030    /*  12 FRAME */,
    SG_WORD(4),
    0x00000145    /*  14 LREF_PUSH */,
    0x00000255    /*  15 LREF_CAR */,
    0x0000012b    /*  16 CALL */,
    0x00000030    /*  17 FRAME */,
    SG_WORD(4),
    0x0000025c    /*  19 LREF_CDR_PUSH */,
    0x0000014a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier current-exception-handlers#core.errors> */,
    0x00000030    /*  22 FRAME */,
    SG_WORD(4),
    0x00000145    /*  24 LREF_PUSH */,
    0x0000014a    /*  25 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier non-continuable-violation?#core.errors> */,
    0x00000017    /*  27 TEST */,
    SG_WORD(50),
    0x00000030    /*  29 FRAME */,
    SG_WORD(4),
    0x00000145    /*  31 LREF_PUSH */,
    0x0000014a    /*  32 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier %condition-message#core.errors> */,
    0x0000000b    /*  34 PUSH */,
    0x00000003    /*  35 CONST */,
    SG_WORD(SG_UNDEF) /* error in raise: returned from non-continuable */,
    0x0000001f    /*  37 BNEQ */,
    SG_WORD(5),
    0x00000145    /*  39 LREF_PUSH */,
    0x0000014b    /*  40 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  42 RET */,
    0x00000030    /*  43 FRAME */,
    SG_WORD(30),
    0x00000030    /*  45 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  47 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-non-continuable-violation#core.errors> */,
    0x0000000b    /*  49 PUSH */,
    0x00000030    /*  50 FRAME */,
    SG_WORD(5),
    0x00000048    /*  52 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* raise */,
    0x0000014a    /*  54 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  56 PUSH */,
    0x00000030    /*  57 FRAME */,
    SG_WORD(5),
    0x00000048    /*  59 CONST_PUSH */,
    SG_WORD(SG_UNDEF) /* error in raise: returned from non-continuable */,
    0x0000014a    /*  61 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x0000000b    /*  63 PUSH */,
    0x00000030    /*  64 FRAME */,
    SG_WORD(6),
    0x00000105    /*  66 LREF */,
    0x00000138    /*  67 LIST */,
    0x0000000b    /*  68 PUSH */,
    0x0000014a    /*  69 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-irritants-condition#core.errors> */,
    0x0000000b    /*  71 PUSH */,
    0x0000044a    /*  72 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x0000000b    /*  74 PUSH */,
    0x0000014b    /*  75 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  77 RET */,
    0x00000018    /*  78 JUMP */,
    SG_WORD(-36),
    0x0000002f    /*  80 RET */,
    /* undefined-violation */0x00000030    /*   0 FRAME */,
    SG_WORD(35),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(30),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-undefined-violation#core.errors> */,
    0x0000000b    /*  12 PUSH */,
    0x00000005    /*  13 LREF */,
    0x00000017    /*  14 TEST */,
    SG_WORD(6),
    0x00000030    /*  16 FRAME */,
    SG_WORD(4),
    0x00000045    /*  18 LREF_PUSH */,
    0x0000014a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  21 PUSH */,
    0x00000105    /*  22 LREF */,
    0x0000003e    /*  23 PAIRP */,
    0x00000017    /*  24 TEST */,
    SG_WORD(6),
    0x00000030    /*  26 FRAME */,
    SG_WORD(4),
    0x0000015b    /*  28 LREF_CAR_PUSH */,
    0x0000014a    /*  29 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x00000338    /*  31 LIST */,
    0x0000000b    /*  32 PUSH */,
    0x0000024a    /*  33 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  35 APPLY */,
    0x0000000b    /*  36 PUSH */,
    0x0000014b    /*  37 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  39 RET */,
    /* lexical-violation */0x00000030    /*   0 FRAME */,
    SG_WORD(35),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(30),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-lexical-violation#core.errors> */,
    0x0000000b    /*  12 PUSH */,
    0x00000005    /*  13 LREF */,
    0x00000017    /*  14 TEST */,
    SG_WORD(6),
    0x00000030    /*  16 FRAME */,
    SG_WORD(4),
    0x00000045    /*  18 LREF_PUSH */,
    0x0000014a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  21 PUSH */,
    0x00000105    /*  22 LREF */,
    0x0000003e    /*  23 PAIRP */,
    0x00000017    /*  24 TEST */,
    SG_WORD(6),
    0x00000030    /*  26 FRAME */,
    SG_WORD(4),
    0x0000015b    /*  28 LREF_CAR_PUSH */,
    0x0000014a    /*  29 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x00000338    /*  31 LIST */,
    0x0000000b    /*  32 PUSH */,
    0x0000024a    /*  33 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  35 APPLY */,
    0x0000000b    /*  36 PUSH */,
    0x0000014b    /*  37 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  39 RET */,
    /* syntax-violation */0x00000030    /*   0 FRAME */,
    SG_WORD(80),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(75),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(10),
    0x00000245    /*  10 LREF_PUSH */,
    0x00000305    /*  11 LREF */,
    0x0000003e    /*  12 PAIRP */,
    0x00000017    /*  13 TEST */,
    SG_WORD(2),
    0x00000355    /*  15 LREF_CAR */,
    0x0000000b    /*  16 PUSH */,
    0x0000024a    /*  17 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-syntax-violation#core.errors> */,
    0x0000000b    /*  19 PUSH */,
    0x00000005    /*  20 LREF */,
    0x00000017    /*  21 TEST */,
    SG_WORD(8),
    0x00000030    /*  23 FRAME */,
    SG_WORD(4),
    0x00000045    /*  25 LREF_PUSH */,
    0x0000014a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x00000018    /*  28 JUMP */,
    SG_WORD(41),
    0x00000030    /*  30 FRAME */,
    SG_WORD(4),
    0x00000245    /*  32 LREF_PUSH */,
    0x0000014a    /*  33 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier identifier?#core.errors> */,
    0x00000017    /*  35 TEST */,
    SG_WORD(8),
    0x00000030    /*  37 FRAME */,
    SG_WORD(4),
    0x00000245    /*  39 LREF_PUSH */,
    0x0000014a    /*  40 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier id-name#core.errors> */,
    0x00000018    /*  42 JUMP */,
    SG_WORD(17),
    0x00000205    /*  44 LREF */,
    0x0000003e    /*  45 PAIRP */,
    0x00000017    /*  46 TEST */,
    SG_WORD(13),
    0x00000030    /*  48 FRAME */,
    SG_WORD(4),
    0x0000025b    /*  50 LREF_CAR_PUSH */,
    0x0000014a    /*  51 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier identifier?#core.errors> */,
    0x00000017    /*  53 TEST */,
    SG_WORD(6),
    0x00000030    /*  55 FRAME */,
    SG_WORD(4),
    0x0000025b    /*  57 LREF_CAR_PUSH */,
    0x0000014a    /*  58 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier id-name#core.errors> */,
    0x0000000b    /*  60 PUSH */,
    0x00001305    /*  61 LREF */,
    0x00000017    /*  62 TEST */,
    SG_WORD(6),
    0x00000030    /*  64 FRAME */,
    SG_WORD(4),
    0x00001345    /*  66 LREF_PUSH */,
    0x0000014a    /*  67 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x00000132    /*  69 LEAVE */,
    0x0000000b    /*  70 PUSH */,
    0x00000030    /*  71 FRAME */,
    SG_WORD(4),
    0x00000145    /*  73 LREF_PUSH */,
    0x0000014a    /*  74 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x00000338    /*  76 LIST */,
    0x0000000b    /*  77 PUSH */,
    0x0000024a    /*  78 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  80 APPLY */,
    0x0000000b    /*  81 PUSH */,
    0x0000014b    /*  82 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  84 RET */,
    /* implementation-restriction-violation */0x00000030    /*   0 FRAME */,
    SG_WORD(41),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(36),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-implementation-restriction-violation#core.errors> */,
    0x0000000b    /*  12 PUSH */,
    0x00000005    /*  13 LREF */,
    0x00000017    /*  14 TEST */,
    SG_WORD(6),
    0x00000030    /*  16 FRAME */,
    SG_WORD(4),
    0x00000045    /*  18 LREF_PUSH */,
    0x0000014a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  21 PUSH */,
    0x00000030    /*  22 FRAME */,
    SG_WORD(4),
    0x00000145    /*  24 LREF_PUSH */,
    0x0000014a    /*  25 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x0000000b    /*  27 PUSH */,
    0x00000205    /*  28 LREF */,
    0x0000003e    /*  29 PAIRP */,
    0x00000017    /*  30 TEST */,
    SG_WORD(6),
    0x00000030    /*  32 FRAME */,
    SG_WORD(4),
    0x00000245    /*  34 LREF_PUSH */,
    0x0000014a    /*  35 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-irritants-condition#core.errors> */,
    0x00000438    /*  37 LIST */,
    0x0000000b    /*  38 PUSH */,
    0x0000024a    /*  39 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  41 APPLY */,
    0x0000000b    /*  42 PUSH */,
    0x0000014b    /*  43 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  45 RET */,
    /* undefined/syntax-violation */0x00000030    /*   0 FRAME */,
    SG_WORD(43),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(38),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(10),
    0x00000245    /*  10 LREF_PUSH */,
    0x00000305    /*  11 LREF */,
    0x0000003e    /*  12 PAIRP */,
    0x00000017    /*  13 TEST */,
    SG_WORD(2),
    0x00000355    /*  15 LREF_CAR */,
    0x0000000b    /*  16 PUSH */,
    0x0000024a    /*  17 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-syntax-violation#core.errors> */,
    0x0000000b    /*  19 PUSH */,
    0x00000030    /*  20 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-undefined-violation#core.errors> */,
    0x0000000b    /*  24 PUSH */,
    0x00000005    /*  25 LREF */,
    0x00000017    /*  26 TEST */,
    SG_WORD(6),
    0x00000030    /*  28 FRAME */,
    SG_WORD(4),
    0x00000045    /*  30 LREF_PUSH */,
    0x0000014a    /*  31 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  33 PUSH */,
    0x00000030    /*  34 FRAME */,
    SG_WORD(4),
    0x00000145    /*  36 LREF_PUSH */,
    0x0000014a    /*  37 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x00000438    /*  39 LIST */,
    0x0000000b    /*  40 PUSH */,
    0x0000024a    /*  41 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  43 APPLY */,
    0x0000000b    /*  44 PUSH */,
    0x0000014b    /*  45 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  47 RET */,
    /* assertion/syntax-violation */0x00000030    /*   0 FRAME */,
    SG_WORD(43),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(38),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(10),
    0x00000245    /*  10 LREF_PUSH */,
    0x00000305    /*  11 LREF */,
    0x0000003e    /*  12 PAIRP */,
    0x00000017    /*  13 TEST */,
    SG_WORD(2),
    0x00000355    /*  15 LREF_CAR */,
    0x0000000b    /*  16 PUSH */,
    0x0000024a    /*  17 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-syntax-violation#core.errors> */,
    0x0000000b    /*  19 PUSH */,
    0x00000030    /*  20 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  22 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-assertion-violation#core.errors> */,
    0x0000000b    /*  24 PUSH */,
    0x00000005    /*  25 LREF */,
    0x00000017    /*  26 TEST */,
    SG_WORD(6),
    0x00000030    /*  28 FRAME */,
    SG_WORD(4),
    0x00000045    /*  30 LREF_PUSH */,
    0x0000014a    /*  31 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  33 PUSH */,
    0x00000030    /*  34 FRAME */,
    SG_WORD(4),
    0x00000145    /*  36 LREF_PUSH */,
    0x0000014a    /*  37 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x00000438    /*  39 LIST */,
    0x0000000b    /*  40 PUSH */,
    0x0000024a    /*  41 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  43 APPLY */,
    0x0000000b    /*  44 PUSH */,
    0x0000014b    /*  45 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  47 RET */,
    /* raise-i/o-filename-error */0x00000030    /*   0 FRAME */,
    SG_WORD(42),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(37),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(4),
    0x00000245    /*  10 LREF_PUSH */,
    0x0000014a    /*  11 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-filename-error#core.errors> */,
    0x0000000b    /*  13 PUSH */,
    0x00000005    /*  14 LREF */,
    0x00000017    /*  15 TEST */,
    SG_WORD(6),
    0x00000030    /*  17 FRAME */,
    SG_WORD(4),
    0x00000045    /*  19 LREF_PUSH */,
    0x0000014a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  22 PUSH */,
    0x00000030    /*  23 FRAME */,
    SG_WORD(4),
    0x00000145    /*  25 LREF_PUSH */,
    0x0000014a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x0000000b    /*  28 PUSH */,
    0x00000305    /*  29 LREF */,
    0x0000003e    /*  30 PAIRP */,
    0x00000017    /*  31 TEST */,
    SG_WORD(6),
    0x00000030    /*  33 FRAME */,
    SG_WORD(4),
    0x00000345    /*  35 LREF_PUSH */,
    0x0000014a    /*  36 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-irritants-condition#core.errors> */,
    0x00000438    /*  38 LIST */,
    0x0000000b    /*  39 PUSH */,
    0x0000024a    /*  40 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  42 APPLY */,
    0x0000000b    /*  43 PUSH */,
    0x0000014b    /*  44 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  46 RET */,
    /* raise-i/o-error */0x00000030    /*   0 FRAME */,
    SG_WORD(41),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(36),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(3),
    0x0000004a    /*  10 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-error#core.errors> */,
    0x0000000b    /*  12 PUSH */,
    0x00000005    /*  13 LREF */,
    0x00000017    /*  14 TEST */,
    SG_WORD(6),
    0x00000030    /*  16 FRAME */,
    SG_WORD(4),
    0x00000045    /*  18 LREF_PUSH */,
    0x0000014a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  21 PUSH */,
    0x00000030    /*  22 FRAME */,
    SG_WORD(4),
    0x00000145    /*  24 LREF_PUSH */,
    0x0000014a    /*  25 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x0000000b    /*  27 PUSH */,
    0x00000205    /*  28 LREF */,
    0x0000003e    /*  29 PAIRP */,
    0x00000017    /*  30 TEST */,
    SG_WORD(6),
    0x00000030    /*  32 FRAME */,
    SG_WORD(4),
    0x00000245    /*  34 LREF_PUSH */,
    0x0000014a    /*  35 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-irritants-condition#core.errors> */,
    0x00000438    /*  37 LIST */,
    0x0000000b    /*  38 PUSH */,
    0x0000024a    /*  39 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  41 APPLY */,
    0x0000000b    /*  42 PUSH */,
    0x0000014b    /*  43 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  45 RET */,
    /* raise-misc-i/o-error-with-port */0x00000030    /*   0 FRAME */,
    SG_WORD(52),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(47),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(3),
    0x00000005    /*  10 LREF */,
    0x0000002b    /*  11 CALL */,
    0x0000000b    /*  12 PUSH */,
    0x00000105    /*  13 LREF */,
    0x00000017    /*  14 TEST */,
    SG_WORD(6),
    0x00000030    /*  16 FRAME */,
    SG_WORD(4),
    0x00000145    /*  18 LREF_PUSH */,
    0x0000014a    /*  19 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  21 PUSH */,
    0x00000030    /*  22 FRAME */,
    SG_WORD(4),
    0x00000245    /*  24 LREF_PUSH */,
    0x0000014a    /*  25 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x0000000b    /*  27 PUSH */,
    0x00000305    /*  28 LREF */,
    0x00000017    /*  29 TEST */,
    SG_WORD(6),
    0x00000030    /*  31 FRAME */,
    SG_WORD(4),
    0x00000345    /*  33 LREF_PUSH */,
    0x0000014a    /*  34 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-port-error#core.errors> */,
    0x0000000b    /*  36 PUSH */,
    0x00000030    /*  37 FRAME */,
    SG_WORD(10),
    0x00000030    /*  39 FRAME */,
    SG_WORD(5),
    0x00000345    /*  41 LREF_PUSH */,
    0x00000445    /*  42 LREF_PUSH */,
    0x0000024a    /*  43 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier cons*#core.errors> */,
    0x0000000b    /*  45 PUSH */,
    0x0000014a    /*  46 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-irritants-condition#core.errors> */,
    0x00000538    /*  48 LIST */,
    0x0000000b    /*  49 PUSH */,
    0x0000024a    /*  50 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  52 APPLY */,
    0x0000000b    /*  53 PUSH */,
    0x0000014b    /*  54 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  56 RET */,
    /* raise-misc-i/o-error */0x00000030    /*   0 FRAME */,
    SG_WORD(42),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(37),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(4),
    0x00000045    /*  10 LREF_PUSH */,
    0x00000305    /*  11 LREF */,
    0x0000022a    /*  12 APPLY */,
    0x0000000b    /*  13 PUSH */,
    0x00000105    /*  14 LREF */,
    0x00000017    /*  15 TEST */,
    SG_WORD(6),
    0x00000030    /*  17 FRAME */,
    SG_WORD(4),
    0x00000145    /*  19 LREF_PUSH */,
    0x0000014a    /*  20 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  22 PUSH */,
    0x00000030    /*  23 FRAME */,
    SG_WORD(4),
    0x00000245    /*  25 LREF_PUSH */,
    0x0000014a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x0000000b    /*  28 PUSH */,
    0x00000305    /*  29 LREF */,
    0x0000003e    /*  30 PAIRP */,
    0x00000017    /*  31 TEST */,
    SG_WORD(6),
    0x00000030    /*  33 FRAME */,
    SG_WORD(4),
    0x00000345    /*  35 LREF_PUSH */,
    0x0000014a    /*  36 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-irritants-condition#core.errors> */,
    0x00000438    /*  38 LIST */,
    0x0000000b    /*  39 PUSH */,
    0x0000024a    /*  40 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  42 APPLY */,
    0x0000000b    /*  43 PUSH */,
    0x0000014b    /*  44 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  46 RET */,
    /* raise-i/o-read-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error-with-port#core.errors> */,
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-read-error#core.errors> */,
    0x00000045    /*   4 LREF_PUSH */,
    0x00000145    /*   5 LREF_PUSH */,
    0x00000245    /*   6 LREF_PUSH */,
    0x00000305    /*   7 LREF */,
    0x0010062a    /*   8 APPLY */,
    0x0000002f    /*   9 RET */,
    /* raise-i/o-write-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error-with-port#core.errors> */,
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-write-error#core.errors> */,
    0x00000045    /*   4 LREF_PUSH */,
    0x00000145    /*   5 LREF_PUSH */,
    0x00000245    /*   6 LREF_PUSH */,
    0x00000305    /*   7 LREF */,
    0x0010062a    /*   8 APPLY */,
    0x0000002f    /*   9 RET */,
    /* raise-i/o-file-protection-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-file-protection-error#core.errors> */,
    0x00000045    /*   2 LREF_PUSH */,
    0x00000145    /*   3 LREF_PUSH */,
    0x00000245    /*   4 LREF_PUSH */,
    0x0000044b    /*   5 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error#core.errors> */,
    0x0000002f    /*   7 RET */,
    /* raise-i/o-file-is-read-only-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error-with-port#core.errors> */,
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-file-is-read-only-error#core.errors> */,
    0x00000045    /*   4 LREF_PUSH */,
    0x00000145    /*   5 LREF_PUSH */,
    0x00000245    /*   6 LREF_PUSH */,
    0x00000305    /*   7 LREF */,
    0x0010062a    /*   8 APPLY */,
    0x0000002f    /*   9 RET */,
    /* raise-i/o-file-already-exists-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-file-already-exists-error#core.errors> */,
    0x00000045    /*   2 LREF_PUSH */,
    0x00000145    /*   3 LREF_PUSH */,
    0x00000245    /*   4 LREF_PUSH */,
    0x0000044b    /*   5 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error#core.errors> */,
    0x0000002f    /*   7 RET */,
    /* raise-i/o-file-does-not-exist-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-file-does-not-exist-error#core.errors> */,
    0x00000045    /*   2 LREF_PUSH */,
    0x00000145    /*   3 LREF_PUSH */,
    0x00000245    /*   4 LREF_PUSH */,
    0x0000044b    /*   5 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error#core.errors> */,
    0x0000002f    /*   7 RET */,
    /* raise-i/o-invalid-position-error */0x00000030    /*   0 FRAME */,
    SG_WORD(38),
    0x00000047    /*   2 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier condition#core.errors> */,
    0x00000030    /*   4 FRAME */,
    SG_WORD(33),
    0x00000047    /*   6 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier values#core.errors> */,
    0x00000030    /*   8 FRAME */,
    SG_WORD(4),
    0x00000345    /*  10 LREF_PUSH */,
    0x0000014a    /*  11 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-invalid-position-error#core.errors> */,
    0x0000000b    /*  13 PUSH */,
    0x00000030    /*  14 FRAME */,
    SG_WORD(4),
    0x00000245    /*  16 LREF_PUSH */,
    0x0000014a    /*  17 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-port-error#core.errors> */,
    0x0000000b    /*  19 PUSH */,
    0x00000005    /*  20 LREF */,
    0x00000017    /*  21 TEST */,
    SG_WORD(6),
    0x00000030    /*  23 FRAME */,
    SG_WORD(4),
    0x00000045    /*  25 LREF_PUSH */,
    0x0000014a    /*  26 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-who-condition#core.errors> */,
    0x0000000b    /*  28 PUSH */,
    0x00000030    /*  29 FRAME */,
    SG_WORD(4),
    0x00000145    /*  31 LREF_PUSH */,
    0x0000014a    /*  32 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier make-message-condition#core.errors> */,
    0x00000438    /*  34 LIST */,
    0x0000000b    /*  35 PUSH */,
    0x0000024a    /*  36 GREF_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier filter#core.errors> */,
    0x0000022a    /*  38 APPLY */,
    0x0000000b    /*  39 PUSH */,
    0x0000014b    /*  40 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x0000002f    /*  42 RET */,
    /* raise-i/o-decoding-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-decoding-error#core.errors> */,
    0x00000045    /*   2 LREF_PUSH */,
    0x00000145    /*   3 LREF_PUSH */,
    0x00000245    /*   4 LREF_PUSH */,
    0x0000044b    /*   5 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error#core.errors> */,
    0x0000002f    /*   7 RET */,
    /* raise-i/o-encoding-error */0x00000047    /*   0 GREF_PUSH */,
    SG_WORD(SG_UNDEF) /* #<identifier make-i/o-encoding-error#core.errors> */,
    0x00000045    /*   2 LREF_PUSH */,
    0x00000145    /*   3 LREF_PUSH */,
    0x00000245    /*   4 LREF_PUSH */,
    0x00000345    /*   5 LREF_PUSH */,
    0x0000054b    /*   6 GREF_TAIL_CALL */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error#core.errors> */,
    0x0000002f    /*   8 RET */,
    /* #f */0x00000034    /*   0 LIBRARY */,
    SG_WORD(SG_UNDEF) /* #<library core.errors> */,
    0x00000029    /*   2 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[0])) /* #<code-builder %condition-message (1 0 0)> */,
    0x00000033    /*   4 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier %condition-message#core.errors> */,
    0x00000029    /*   6 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[1])) /* #<code-builder raise-continuable (1 0 0)> */,
    0x00000033    /*   8 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-continuable#core.errors> */,
    0x00000029    /*  10 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[2])) /* #<code-builder raise (1 0 0)> */,
    0x00000033    /*  12 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise#core.errors> */,
    0x00000029    /*  14 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[3])) /* #<code-builder undefined-violation (1 1 0)> */,
    0x00000033    /*  16 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier undefined-violation#core.errors> */,
    0x00000029    /*  18 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[4])) /* #<code-builder lexical-violation (1 1 0)> */,
    0x00000033    /*  20 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier lexical-violation#core.errors> */,
    0x00000029    /*  22 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[5])) /* #<code-builder syntax-violation (3 1 0)> */,
    0x00000033    /*  24 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier syntax-violation#core.errors> */,
    0x00000029    /*  26 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[6])) /* #<code-builder implementation-restriction-violation (2 1 0)> */,
    0x00000033    /*  28 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier implementation-restriction-violation#core.errors> */,
    0x00000029    /*  30 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[7])) /* #<code-builder undefined/syntax-violation (3 1 0)> */,
    0x00000033    /*  32 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier undefined/syntax-violation#core.errors> */,
    0x00000029    /*  34 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[8])) /* #<code-builder assertion/syntax-violation (3 1 0)> */,
    0x00000033    /*  36 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier assertion/syntax-violation#core.errors> */,
    0x00000029    /*  38 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[9])) /* #<code-builder raise-i/o-filename-error (3 1 0)> */,
    0x00000033    /*  40 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-filename-error#core.errors> */,
    0x00000029    /*  42 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[10])) /* #<code-builder raise-i/o-error (2 1 0)> */,
    0x00000033    /*  44 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-error#core.errors> */,
    0x00000029    /*  46 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[11])) /* #<code-builder raise-misc-i/o-error-with-port (4 1 0)> */,
    0x00000033    /*  48 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error-with-port#core.errors> */,
    0x00000029    /*  50 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[12])) /* #<code-builder raise-misc-i/o-error (3 1 0)> */,
    0x00000033    /*  52 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-misc-i/o-error#core.errors> */,
    0x00000029    /*  54 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[13])) /* #<code-builder raise-i/o-read-error (3 1 0)> */,
    0x00000033    /*  56 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-read-error#core.errors> */,
    0x00000029    /*  58 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[14])) /* #<code-builder raise-i/o-write-error (3 1 0)> */,
    0x00000033    /*  60 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-write-error#core.errors> */,
    0x00000029    /*  62 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[15])) /* #<code-builder raise-i/o-file-protection-error (3 0 0)> */,
    0x00000033    /*  64 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-file-protection-error#core.errors> */,
    0x00000029    /*  66 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[16])) /* #<code-builder raise-i/o-file-is-read-only-error (3 1 0)> */,
    0x00000033    /*  68 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-file-is-read-only-error#core.errors> */,
    0x00000029    /*  70 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[17])) /* #<code-builder raise-i/o-file-already-exists-error (3 0 0)> */,
    0x00000033    /*  72 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-file-already-exists-error#core.errors> */,
    0x00000029    /*  74 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[18])) /* #<code-builder raise-i/o-file-does-not-exist-error (3 0 0)> */,
    0x00000033    /*  76 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-file-does-not-exist-error#core.errors> */,
    0x00000029    /*  78 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[19])) /* #<code-builder raise-i/o-invalid-position-error (4 0 0)> */,
    0x00000033    /*  80 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-invalid-position-error#core.errors> */,
    0x00000029    /*  82 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[20])) /* #<code-builder raise-i/o-decoding-error (3 0 0)> */,
    0x00000033    /*  84 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-decoding-error#core.errors> */,
    0x00000029    /*  86 CLOSURE */,
    SG_WORD(SG_OBJ(&sg__rc_cgen23449.d23475[21])) /* #<code-builder raise-i/o-encoding-error (4 0 0)> */,
    0x00000033    /*  88 DEFINE */,
    SG_WORD(SG_UNDEF) /* #<identifier raise-i/o-encoding-error#core.errors> */,
    0x00000002    /*  90 UNDEF */,
    0x0000002f    /*  91 RET */,
  },
  {  /* SgCodeBuilder d23475 */
    
    SG_STATIC_CODE_BUILDER( /* %condition-message */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[0]), SG_FALSE, 1, 0, 0, 14, 42),
    
    SG_STATIC_CODE_BUILDER( /* raise-continuable */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[42]), SG_FALSE, 1, 0, 0, 10, 15),
    
    SG_STATIC_CODE_BUILDER( /* raise */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[57]), SG_FALSE, 1, 0, 0, 20, 81),
    
    SG_STATIC_CODE_BUILDER( /* undefined-violation */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[138]), SG_FALSE, 1, 1, 0, 21, 40),
    
    SG_STATIC_CODE_BUILDER( /* lexical-violation */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[178]), SG_FALSE, 1, 1, 0, 21, 40),
    
    SG_STATIC_CODE_BUILDER( /* syntax-violation */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[218]), SG_FALSE, 3, 1, 0, 29, 85),
    
    SG_STATIC_CODE_BUILDER( /* implementation-restriction-violation */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[303]), SG_FALSE, 2, 1, 0, 23, 46),
    
    SG_STATIC_CODE_BUILDER( /* undefined/syntax-violation */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[349]), SG_FALSE, 3, 1, 0, 24, 48),
    
    SG_STATIC_CODE_BUILDER( /* assertion/syntax-violation */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[397]), SG_FALSE, 3, 1, 0, 24, 48),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-filename-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[445]), SG_FALSE, 3, 1, 0, 24, 47),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[492]), SG_FALSE, 2, 1, 0, 23, 46),
    
    SG_STATIC_CODE_BUILDER( /* raise-misc-i/o-error-with-port */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[538]), SG_FALSE, 4, 1, 0, 28, 57),
    
    SG_STATIC_CODE_BUILDER( /* raise-misc-i/o-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[595]), SG_FALSE, 3, 1, 0, 27, 47),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-read-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[642]), SG_FALSE, 3, 1, 0, 15, 10),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-write-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[652]), SG_FALSE, 3, 1, 0, 15, 10),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-file-protection-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[662]), SG_FALSE, 3, 0, 0, 13, 8),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-file-is-read-only-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[670]), SG_FALSE, 3, 1, 0, 15, 10),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-file-already-exists-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[680]), SG_FALSE, 3, 0, 0, 13, 8),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-file-does-not-exist-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[688]), SG_FALSE, 3, 0, 0, 13, 8),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-invalid-position-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[696]), SG_FALSE, 4, 0, 0, 24, 43),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-decoding-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[739]), SG_FALSE, 3, 0, 0, 13, 8),
    
    SG_STATIC_CODE_BUILDER( /* raise-i/o-encoding-error */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[747]), SG_FALSE, 4, 0, 0, 15, 9),
    
    SG_STATIC_CODE_BUILDER( /* #f */
      (SgWord *)SG_OBJ(&sg__rc_cgen23449.d23474[756]), SG_FALSE, 0, 0, 0, 0, 92),
  },
};
static SgCodeBuilder *G23450 = 
   SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[22]));
void Sg__Init_core_errors() {
  SgObject save = Sg_VM()->currentLibrary;

  sg__rc_cgen23449.d23473[2] = SG_MAKE_STRING("(core errors)");
  sg__rc_cgen23449.d23473[1] = Sg_Intern(sg__rc_cgen23449.d23473[2]); /* (core errors) */
  sg__rc_cgen23449.d23473[0] = Sg_FindLibrary(SG_SYMBOL(sg__rc_cgen23449.d23473[1]), TRUE);
  sg__rc_cgen23449.d23473[3] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[5] = SG_MAKE_STRING("message-condition?");
  sg__rc_cgen23449.d23473[4] = Sg_Intern(sg__rc_cgen23449.d23473[5]); /* message-condition? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[3],SG_SYMBOL(sg__rc_cgen23449.d23473[4]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* message-condition? */
  sg__rc_cgen23449.d23473[6] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[8] = SG_MAKE_STRING("simple-condition?");
  sg__rc_cgen23449.d23473[7] = Sg_Intern(sg__rc_cgen23449.d23473[8]); /* simple-condition? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[6],SG_SYMBOL(sg__rc_cgen23449.d23473[7]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* simple-condition? */
  sg__rc_cgen23449.d23473[9] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[11] = SG_MAKE_STRING("&message-message");
  sg__rc_cgen23449.d23473[10] = Sg_Intern(sg__rc_cgen23449.d23473[11]); /* &message-message */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[9],SG_SYMBOL(sg__rc_cgen23449.d23473[10]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* &message-message */
  sg__rc_cgen23449.d23473[12] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[14] = SG_MAKE_STRING("&compound-condition-components");
  sg__rc_cgen23449.d23473[13] = Sg_Intern(sg__rc_cgen23449.d23473[14]); /* &compound-condition-components */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[12],SG_SYMBOL(sg__rc_cgen23449.d23473[13]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* &compound-condition-components */
  sg__rc_cgen23449.d23473[15] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[17] = SG_MAKE_STRING("%condition-message");
  sg__rc_cgen23449.d23473[16] = Sg_Intern(sg__rc_cgen23449.d23473[17]); /* %condition-message */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[15],SG_SYMBOL(sg__rc_cgen23449.d23473[16]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* %condition-message */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[0]))->name = sg__rc_cgen23449.d23473[16];/* %condition-message */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[0]))[4] = SG_WORD(sg__rc_cgen23449.d23473[3]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[0]))[11] = SG_WORD(sg__rc_cgen23449.d23473[6]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[0]))[16] = SG_WORD(sg__rc_cgen23449.d23473[9]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[0]))[22] = SG_WORD(sg__rc_cgen23449.d23473[12]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[0]))[33] = SG_WORD(sg__rc_cgen23449.d23473[15]);
  sg__rc_cgen23449.d23473[18] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[18],SG_SYMBOL(sg__rc_cgen23449.d23473[16]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* %condition-message */
  sg__rc_cgen23449.d23473[19] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[21] = SG_MAKE_STRING("vm-attach-stack-trace");
  sg__rc_cgen23449.d23473[20] = Sg_Intern(sg__rc_cgen23449.d23473[21]); /* vm-attach-stack-trace */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[19],SG_SYMBOL(sg__rc_cgen23449.d23473[20]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* vm-attach-stack-trace */
  sg__rc_cgen23449.d23473[22] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[24] = SG_MAKE_STRING("current-exception-handlers");
  sg__rc_cgen23449.d23473[23] = Sg_Intern(sg__rc_cgen23449.d23473[24]); /* current-exception-handlers */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[22],SG_SYMBOL(sg__rc_cgen23449.d23473[23]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* current-exception-handlers */
  sg__rc_cgen23449.d23473[26] = SG_MAKE_STRING("raise-continuable");
  sg__rc_cgen23449.d23473[25] = Sg_Intern(sg__rc_cgen23449.d23473[26]); /* raise-continuable */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[1]))->name = sg__rc_cgen23449.d23473[25];/* raise-continuable */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[42]))[5] = SG_WORD(sg__rc_cgen23449.d23473[19]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[42]))[11] = SG_WORD(sg__rc_cgen23449.d23473[22]);
  sg__rc_cgen23449.d23473[27] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[27],SG_SYMBOL(sg__rc_cgen23449.d23473[25]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-continuable */
  sg__rc_cgen23449.d23473[28] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[28],SG_SYMBOL(sg__rc_cgen23449.d23473[20]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* vm-attach-stack-trace */
  sg__rc_cgen23449.d23473[29] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[29],SG_SYMBOL(sg__rc_cgen23449.d23473[23]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* current-exception-handlers */
  sg__rc_cgen23449.d23473[30] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[30],SG_SYMBOL(sg__rc_cgen23449.d23473[23]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* current-exception-handlers */
  sg__rc_cgen23449.d23473[31] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[33] = SG_MAKE_STRING("non-continuable-violation?");
  sg__rc_cgen23449.d23473[32] = Sg_Intern(sg__rc_cgen23449.d23473[33]); /* non-continuable-violation? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[31],SG_SYMBOL(sg__rc_cgen23449.d23473[32]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* non-continuable-violation? */
  sg__rc_cgen23449.d23473[34] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[34],SG_SYMBOL(sg__rc_cgen23449.d23473[16]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* %condition-message */
  sg__rc_cgen23449.d23473[35] = SG_MAKE_STRING("error in raise: returned from non-continuable");
  sg__rc_cgen23449.d23473[36] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[38] = SG_MAKE_STRING("raise");
  sg__rc_cgen23449.d23473[37] = Sg_Intern(sg__rc_cgen23449.d23473[38]); /* raise */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[36],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[39] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[41] = SG_MAKE_STRING("make-non-continuable-violation");
  sg__rc_cgen23449.d23473[40] = Sg_Intern(sg__rc_cgen23449.d23473[41]); /* make-non-continuable-violation */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[39],SG_SYMBOL(sg__rc_cgen23449.d23473[40]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-non-continuable-violation */
  sg__rc_cgen23449.d23473[42] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[44] = SG_MAKE_STRING("make-who-condition");
  sg__rc_cgen23449.d23473[43] = Sg_Intern(sg__rc_cgen23449.d23473[44]); /* make-who-condition */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[42],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[45] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[47] = SG_MAKE_STRING("make-message-condition");
  sg__rc_cgen23449.d23473[46] = Sg_Intern(sg__rc_cgen23449.d23473[47]); /* make-message-condition */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[45],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[48] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[50] = SG_MAKE_STRING("make-irritants-condition");
  sg__rc_cgen23449.d23473[49] = Sg_Intern(sg__rc_cgen23449.d23473[50]); /* make-irritants-condition */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[48],SG_SYMBOL(sg__rc_cgen23449.d23473[49]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-irritants-condition */
  sg__rc_cgen23449.d23473[51] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[53] = SG_MAKE_STRING("condition");
  sg__rc_cgen23449.d23473[52] = Sg_Intern(sg__rc_cgen23449.d23473[53]); /* condition */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[51],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[54] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[54],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[2]))->name = sg__rc_cgen23449.d23473[37];/* raise */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[5] = SG_WORD(sg__rc_cgen23449.d23473[28]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[10] = SG_WORD(sg__rc_cgen23449.d23473[29]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[21] = SG_WORD(sg__rc_cgen23449.d23473[30]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[26] = SG_WORD(sg__rc_cgen23449.d23473[31]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[33] = SG_WORD(sg__rc_cgen23449.d23473[34]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[36] = SG_WORD(sg__rc_cgen23449.d23473[35]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[41] = SG_WORD(sg__rc_cgen23449.d23473[36]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[48] = SG_WORD(sg__rc_cgen23449.d23473[39]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[53] = SG_WORD(sg__rc_cgen23449.d23473[37]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[55] = SG_WORD(sg__rc_cgen23449.d23473[42]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[60] = SG_WORD(sg__rc_cgen23449.d23473[35]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[62] = SG_WORD(sg__rc_cgen23449.d23473[45]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[70] = SG_WORD(sg__rc_cgen23449.d23473[48]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[73] = SG_WORD(sg__rc_cgen23449.d23473[51]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[57]))[76] = SG_WORD(sg__rc_cgen23449.d23473[54]);
  sg__rc_cgen23449.d23473[55] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[55],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[56] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[56],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[57] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[59] = SG_MAKE_STRING("values");
  sg__rc_cgen23449.d23473[58] = Sg_Intern(sg__rc_cgen23449.d23473[59]); /* values */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[57],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[60] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[62] = SG_MAKE_STRING("make-undefined-violation");
  sg__rc_cgen23449.d23473[61] = Sg_Intern(sg__rc_cgen23449.d23473[62]); /* make-undefined-violation */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[60],SG_SYMBOL(sg__rc_cgen23449.d23473[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-undefined-violation */
  sg__rc_cgen23449.d23473[63] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[63],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[64] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[64],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[65] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[67] = SG_MAKE_STRING("filter");
  sg__rc_cgen23449.d23473[66] = Sg_Intern(sg__rc_cgen23449.d23473[67]); /* filter */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[65],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[68] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[68],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[70] = SG_MAKE_STRING("undefined-violation");
  sg__rc_cgen23449.d23473[69] = Sg_Intern(sg__rc_cgen23449.d23473[70]); /* undefined-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[3]))->name = sg__rc_cgen23449.d23473[69];/* undefined-violation */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[138]))[3] = SG_WORD(sg__rc_cgen23449.d23473[56]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[138]))[7] = SG_WORD(sg__rc_cgen23449.d23473[57]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[138]))[11] = SG_WORD(sg__rc_cgen23449.d23473[60]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[138]))[20] = SG_WORD(sg__rc_cgen23449.d23473[63]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[138]))[30] = SG_WORD(sg__rc_cgen23449.d23473[64]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[138]))[34] = SG_WORD(sg__rc_cgen23449.d23473[65]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[138]))[38] = SG_WORD(sg__rc_cgen23449.d23473[68]);
  sg__rc_cgen23449.d23473[71] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[71],SG_SYMBOL(sg__rc_cgen23449.d23473[69]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* undefined-violation */
  sg__rc_cgen23449.d23473[72] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[72],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[73] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[73],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[74] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[76] = SG_MAKE_STRING("make-lexical-violation");
  sg__rc_cgen23449.d23473[75] = Sg_Intern(sg__rc_cgen23449.d23473[76]); /* make-lexical-violation */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[74],SG_SYMBOL(sg__rc_cgen23449.d23473[75]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-lexical-violation */
  sg__rc_cgen23449.d23473[77] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[77],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[78] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[78],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[79] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[79],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[80] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[80],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[82] = SG_MAKE_STRING("lexical-violation");
  sg__rc_cgen23449.d23473[81] = Sg_Intern(sg__rc_cgen23449.d23473[82]); /* lexical-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[4]))->name = sg__rc_cgen23449.d23473[81];/* lexical-violation */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[178]))[3] = SG_WORD(sg__rc_cgen23449.d23473[72]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[178]))[7] = SG_WORD(sg__rc_cgen23449.d23473[73]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[178]))[11] = SG_WORD(sg__rc_cgen23449.d23473[74]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[178]))[20] = SG_WORD(sg__rc_cgen23449.d23473[77]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[178]))[30] = SG_WORD(sg__rc_cgen23449.d23473[78]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[178]))[34] = SG_WORD(sg__rc_cgen23449.d23473[79]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[178]))[38] = SG_WORD(sg__rc_cgen23449.d23473[80]);
  sg__rc_cgen23449.d23473[83] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[83],SG_SYMBOL(sg__rc_cgen23449.d23473[81]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* lexical-violation */
  sg__rc_cgen23449.d23473[84] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[84],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[85] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[85],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[86] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[88] = SG_MAKE_STRING("make-syntax-violation");
  sg__rc_cgen23449.d23473[87] = Sg_Intern(sg__rc_cgen23449.d23473[88]); /* make-syntax-violation */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[86],SG_SYMBOL(sg__rc_cgen23449.d23473[87]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-syntax-violation */
  sg__rc_cgen23449.d23473[89] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[89],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[90] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[92] = SG_MAKE_STRING("identifier?");
  sg__rc_cgen23449.d23473[91] = Sg_Intern(sg__rc_cgen23449.d23473[92]); /* identifier? */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[90],SG_SYMBOL(sg__rc_cgen23449.d23473[91]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* identifier? */
  sg__rc_cgen23449.d23473[93] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[95] = SG_MAKE_STRING("id-name");
  sg__rc_cgen23449.d23473[94] = Sg_Intern(sg__rc_cgen23449.d23473[95]); /* id-name */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[93],SG_SYMBOL(sg__rc_cgen23449.d23473[94]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* id-name */
  sg__rc_cgen23449.d23473[96] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[96],SG_SYMBOL(sg__rc_cgen23449.d23473[91]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* identifier? */
  sg__rc_cgen23449.d23473[97] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[97],SG_SYMBOL(sg__rc_cgen23449.d23473[94]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* id-name */
  sg__rc_cgen23449.d23473[98] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[98],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[99] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[99],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[100] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[100],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[101] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[101],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[103] = SG_MAKE_STRING("syntax-violation");
  sg__rc_cgen23449.d23473[102] = Sg_Intern(sg__rc_cgen23449.d23473[103]); /* syntax-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[5]))->name = sg__rc_cgen23449.d23473[102];/* syntax-violation */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[3] = SG_WORD(sg__rc_cgen23449.d23473[84]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[7] = SG_WORD(sg__rc_cgen23449.d23473[85]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[18] = SG_WORD(sg__rc_cgen23449.d23473[86]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[27] = SG_WORD(sg__rc_cgen23449.d23473[89]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[34] = SG_WORD(sg__rc_cgen23449.d23473[90]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[41] = SG_WORD(sg__rc_cgen23449.d23473[93]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[52] = SG_WORD(sg__rc_cgen23449.d23473[96]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[59] = SG_WORD(sg__rc_cgen23449.d23473[97]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[68] = SG_WORD(sg__rc_cgen23449.d23473[98]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[75] = SG_WORD(sg__rc_cgen23449.d23473[99]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[79] = SG_WORD(sg__rc_cgen23449.d23473[100]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[218]))[83] = SG_WORD(sg__rc_cgen23449.d23473[101]);
  sg__rc_cgen23449.d23473[104] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[104],SG_SYMBOL(sg__rc_cgen23449.d23473[102]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* syntax-violation */
  sg__rc_cgen23449.d23473[105] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[105],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[106] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[106],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[107] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[109] = SG_MAKE_STRING("make-implementation-restriction-violation");
  sg__rc_cgen23449.d23473[108] = Sg_Intern(sg__rc_cgen23449.d23473[109]); /* make-implementation-restriction-violation */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[107],SG_SYMBOL(sg__rc_cgen23449.d23473[108]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-implementation-restriction-violation */
  sg__rc_cgen23449.d23473[110] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[110],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[111] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[111],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[112] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[112],SG_SYMBOL(sg__rc_cgen23449.d23473[49]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-irritants-condition */
  sg__rc_cgen23449.d23473[113] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[113],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[114] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[114],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[116] = SG_MAKE_STRING("implementation-restriction-violation");
  sg__rc_cgen23449.d23473[115] = Sg_Intern(sg__rc_cgen23449.d23473[116]); /* implementation-restriction-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[6]))->name = sg__rc_cgen23449.d23473[115];/* implementation-restriction-violation */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[3] = SG_WORD(sg__rc_cgen23449.d23473[105]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[7] = SG_WORD(sg__rc_cgen23449.d23473[106]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[11] = SG_WORD(sg__rc_cgen23449.d23473[107]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[20] = SG_WORD(sg__rc_cgen23449.d23473[110]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[26] = SG_WORD(sg__rc_cgen23449.d23473[111]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[36] = SG_WORD(sg__rc_cgen23449.d23473[112]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[40] = SG_WORD(sg__rc_cgen23449.d23473[113]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[303]))[44] = SG_WORD(sg__rc_cgen23449.d23473[114]);
  sg__rc_cgen23449.d23473[117] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[117],SG_SYMBOL(sg__rc_cgen23449.d23473[115]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* implementation-restriction-violation */
  sg__rc_cgen23449.d23473[118] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[118],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[119] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[119],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[120] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[120],SG_SYMBOL(sg__rc_cgen23449.d23473[87]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-syntax-violation */
  sg__rc_cgen23449.d23473[121] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[121],SG_SYMBOL(sg__rc_cgen23449.d23473[61]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-undefined-violation */
  sg__rc_cgen23449.d23473[122] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[122],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[123] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[123],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[124] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[124],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[125] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[125],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[127] = SG_MAKE_STRING("undefined/syntax-violation");
  sg__rc_cgen23449.d23473[126] = Sg_Intern(sg__rc_cgen23449.d23473[127]); /* undefined/syntax-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[7]))->name = sg__rc_cgen23449.d23473[126];/* undefined/syntax-violation */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[3] = SG_WORD(sg__rc_cgen23449.d23473[118]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[7] = SG_WORD(sg__rc_cgen23449.d23473[119]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[18] = SG_WORD(sg__rc_cgen23449.d23473[120]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[23] = SG_WORD(sg__rc_cgen23449.d23473[121]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[32] = SG_WORD(sg__rc_cgen23449.d23473[122]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[38] = SG_WORD(sg__rc_cgen23449.d23473[123]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[42] = SG_WORD(sg__rc_cgen23449.d23473[124]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[349]))[46] = SG_WORD(sg__rc_cgen23449.d23473[125]);
  sg__rc_cgen23449.d23473[128] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[128],SG_SYMBOL(sg__rc_cgen23449.d23473[126]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* undefined/syntax-violation */
  sg__rc_cgen23449.d23473[129] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[129],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[130] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[130],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[131] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[131],SG_SYMBOL(sg__rc_cgen23449.d23473[87]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-syntax-violation */
  sg__rc_cgen23449.d23473[132] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[134] = SG_MAKE_STRING("make-assertion-violation");
  sg__rc_cgen23449.d23473[133] = Sg_Intern(sg__rc_cgen23449.d23473[134]); /* make-assertion-violation */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[132],SG_SYMBOL(sg__rc_cgen23449.d23473[133]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-assertion-violation */
  sg__rc_cgen23449.d23473[135] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[135],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[136] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[136],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[137] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[137],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[138] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[138],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[140] = SG_MAKE_STRING("assertion/syntax-violation");
  sg__rc_cgen23449.d23473[139] = Sg_Intern(sg__rc_cgen23449.d23473[140]); /* assertion/syntax-violation */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[8]))->name = sg__rc_cgen23449.d23473[139];/* assertion/syntax-violation */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[3] = SG_WORD(sg__rc_cgen23449.d23473[129]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[7] = SG_WORD(sg__rc_cgen23449.d23473[130]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[18] = SG_WORD(sg__rc_cgen23449.d23473[131]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[23] = SG_WORD(sg__rc_cgen23449.d23473[132]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[32] = SG_WORD(sg__rc_cgen23449.d23473[135]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[38] = SG_WORD(sg__rc_cgen23449.d23473[136]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[42] = SG_WORD(sg__rc_cgen23449.d23473[137]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[397]))[46] = SG_WORD(sg__rc_cgen23449.d23473[138]);
  sg__rc_cgen23449.d23473[141] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[141],SG_SYMBOL(sg__rc_cgen23449.d23473[139]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* assertion/syntax-violation */
  sg__rc_cgen23449.d23473[142] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[142],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[143] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[143],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[144] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[146] = SG_MAKE_STRING("make-i/o-filename-error");
  sg__rc_cgen23449.d23473[145] = Sg_Intern(sg__rc_cgen23449.d23473[146]); /* make-i/o-filename-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[144],SG_SYMBOL(sg__rc_cgen23449.d23473[145]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-filename-error */
  sg__rc_cgen23449.d23473[147] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[147],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[148] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[148],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[149] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[149],SG_SYMBOL(sg__rc_cgen23449.d23473[49]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-irritants-condition */
  sg__rc_cgen23449.d23473[150] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[150],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[151] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[151],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[153] = SG_MAKE_STRING("raise-i/o-filename-error");
  sg__rc_cgen23449.d23473[152] = Sg_Intern(sg__rc_cgen23449.d23473[153]); /* raise-i/o-filename-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[9]))->name = sg__rc_cgen23449.d23473[152];/* raise-i/o-filename-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[3] = SG_WORD(sg__rc_cgen23449.d23473[142]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[7] = SG_WORD(sg__rc_cgen23449.d23473[143]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[12] = SG_WORD(sg__rc_cgen23449.d23473[144]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[21] = SG_WORD(sg__rc_cgen23449.d23473[147]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[27] = SG_WORD(sg__rc_cgen23449.d23473[148]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[37] = SG_WORD(sg__rc_cgen23449.d23473[149]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[41] = SG_WORD(sg__rc_cgen23449.d23473[150]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[445]))[45] = SG_WORD(sg__rc_cgen23449.d23473[151]);
  sg__rc_cgen23449.d23473[154] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[154],SG_SYMBOL(sg__rc_cgen23449.d23473[152]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-filename-error */
  sg__rc_cgen23449.d23473[155] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[155],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[156] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[156],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[157] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[159] = SG_MAKE_STRING("make-i/o-error");
  sg__rc_cgen23449.d23473[158] = Sg_Intern(sg__rc_cgen23449.d23473[159]); /* make-i/o-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[157],SG_SYMBOL(sg__rc_cgen23449.d23473[158]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-error */
  sg__rc_cgen23449.d23473[160] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[160],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[161] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[161],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[162] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[162],SG_SYMBOL(sg__rc_cgen23449.d23473[49]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-irritants-condition */
  sg__rc_cgen23449.d23473[163] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[163],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[164] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[164],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[166] = SG_MAKE_STRING("raise-i/o-error");
  sg__rc_cgen23449.d23473[165] = Sg_Intern(sg__rc_cgen23449.d23473[166]); /* raise-i/o-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[10]))->name = sg__rc_cgen23449.d23473[165];/* raise-i/o-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[3] = SG_WORD(sg__rc_cgen23449.d23473[155]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[7] = SG_WORD(sg__rc_cgen23449.d23473[156]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[11] = SG_WORD(sg__rc_cgen23449.d23473[157]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[20] = SG_WORD(sg__rc_cgen23449.d23473[160]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[26] = SG_WORD(sg__rc_cgen23449.d23473[161]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[36] = SG_WORD(sg__rc_cgen23449.d23473[162]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[40] = SG_WORD(sg__rc_cgen23449.d23473[163]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[492]))[44] = SG_WORD(sg__rc_cgen23449.d23473[164]);
  sg__rc_cgen23449.d23473[167] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[167],SG_SYMBOL(sg__rc_cgen23449.d23473[165]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-error */
  sg__rc_cgen23449.d23473[168] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[168],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[169] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[169],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[170] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[170],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[171] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[171],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[172] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[174] = SG_MAKE_STRING("make-i/o-port-error");
  sg__rc_cgen23449.d23473[173] = Sg_Intern(sg__rc_cgen23449.d23473[174]); /* make-i/o-port-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[172],SG_SYMBOL(sg__rc_cgen23449.d23473[173]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-port-error */
  sg__rc_cgen23449.d23473[175] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[177] = SG_MAKE_STRING("cons*");
  sg__rc_cgen23449.d23473[176] = Sg_Intern(sg__rc_cgen23449.d23473[177]); /* cons* */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[175],SG_SYMBOL(sg__rc_cgen23449.d23473[176]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* cons* */
  sg__rc_cgen23449.d23473[178] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[178],SG_SYMBOL(sg__rc_cgen23449.d23473[49]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-irritants-condition */
  sg__rc_cgen23449.d23473[179] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[179],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[180] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[180],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[182] = SG_MAKE_STRING("raise-misc-i/o-error-with-port");
  sg__rc_cgen23449.d23473[181] = Sg_Intern(sg__rc_cgen23449.d23473[182]); /* raise-misc-i/o-error-with-port */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[11]))->name = sg__rc_cgen23449.d23473[181];/* raise-misc-i/o-error-with-port */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[3] = SG_WORD(sg__rc_cgen23449.d23473[168]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[7] = SG_WORD(sg__rc_cgen23449.d23473[169]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[20] = SG_WORD(sg__rc_cgen23449.d23473[170]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[26] = SG_WORD(sg__rc_cgen23449.d23473[171]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[35] = SG_WORD(sg__rc_cgen23449.d23473[172]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[44] = SG_WORD(sg__rc_cgen23449.d23473[175]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[47] = SG_WORD(sg__rc_cgen23449.d23473[178]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[51] = SG_WORD(sg__rc_cgen23449.d23473[179]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[538]))[55] = SG_WORD(sg__rc_cgen23449.d23473[180]);
  sg__rc_cgen23449.d23473[183] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[183],SG_SYMBOL(sg__rc_cgen23449.d23473[181]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error-with-port */
  sg__rc_cgen23449.d23473[184] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[184],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[185] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[185],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[186] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[186],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[187] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[187],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[188] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[188],SG_SYMBOL(sg__rc_cgen23449.d23473[49]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-irritants-condition */
  sg__rc_cgen23449.d23473[189] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[189],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[190] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[190],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[192] = SG_MAKE_STRING("raise-misc-i/o-error");
  sg__rc_cgen23449.d23473[191] = Sg_Intern(sg__rc_cgen23449.d23473[192]); /* raise-misc-i/o-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[12]))->name = sg__rc_cgen23449.d23473[191];/* raise-misc-i/o-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[595]))[3] = SG_WORD(sg__rc_cgen23449.d23473[184]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[595]))[7] = SG_WORD(sg__rc_cgen23449.d23473[185]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[595]))[21] = SG_WORD(sg__rc_cgen23449.d23473[186]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[595]))[27] = SG_WORD(sg__rc_cgen23449.d23473[187]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[595]))[37] = SG_WORD(sg__rc_cgen23449.d23473[188]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[595]))[41] = SG_WORD(sg__rc_cgen23449.d23473[189]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[595]))[45] = SG_WORD(sg__rc_cgen23449.d23473[190]);
  sg__rc_cgen23449.d23473[193] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[193],SG_SYMBOL(sg__rc_cgen23449.d23473[191]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error */
  sg__rc_cgen23449.d23473[194] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[194],SG_SYMBOL(sg__rc_cgen23449.d23473[181]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error-with-port */
  sg__rc_cgen23449.d23473[195] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[197] = SG_MAKE_STRING("make-i/o-read-error");
  sg__rc_cgen23449.d23473[196] = Sg_Intern(sg__rc_cgen23449.d23473[197]); /* make-i/o-read-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[195],SG_SYMBOL(sg__rc_cgen23449.d23473[196]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-read-error */
  sg__rc_cgen23449.d23473[199] = SG_MAKE_STRING("raise-i/o-read-error");
  sg__rc_cgen23449.d23473[198] = Sg_Intern(sg__rc_cgen23449.d23473[199]); /* raise-i/o-read-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[13]))->name = sg__rc_cgen23449.d23473[198];/* raise-i/o-read-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[642]))[1] = SG_WORD(sg__rc_cgen23449.d23473[194]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[642]))[3] = SG_WORD(sg__rc_cgen23449.d23473[195]);
  sg__rc_cgen23449.d23473[200] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[200],SG_SYMBOL(sg__rc_cgen23449.d23473[198]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-read-error */
  sg__rc_cgen23449.d23473[201] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[201],SG_SYMBOL(sg__rc_cgen23449.d23473[181]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error-with-port */
  sg__rc_cgen23449.d23473[202] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[204] = SG_MAKE_STRING("make-i/o-write-error");
  sg__rc_cgen23449.d23473[203] = Sg_Intern(sg__rc_cgen23449.d23473[204]); /* make-i/o-write-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[202],SG_SYMBOL(sg__rc_cgen23449.d23473[203]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-write-error */
  sg__rc_cgen23449.d23473[206] = SG_MAKE_STRING("raise-i/o-write-error");
  sg__rc_cgen23449.d23473[205] = Sg_Intern(sg__rc_cgen23449.d23473[206]); /* raise-i/o-write-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[14]))->name = sg__rc_cgen23449.d23473[205];/* raise-i/o-write-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[652]))[1] = SG_WORD(sg__rc_cgen23449.d23473[201]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[652]))[3] = SG_WORD(sg__rc_cgen23449.d23473[202]);
  sg__rc_cgen23449.d23473[207] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[207],SG_SYMBOL(sg__rc_cgen23449.d23473[205]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-write-error */
  sg__rc_cgen23449.d23473[208] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[210] = SG_MAKE_STRING("make-i/o-file-protection-error");
  sg__rc_cgen23449.d23473[209] = Sg_Intern(sg__rc_cgen23449.d23473[210]); /* make-i/o-file-protection-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[208],SG_SYMBOL(sg__rc_cgen23449.d23473[209]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-file-protection-error */
  sg__rc_cgen23449.d23473[211] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[211],SG_SYMBOL(sg__rc_cgen23449.d23473[191]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error */
  sg__rc_cgen23449.d23473[213] = SG_MAKE_STRING("raise-i/o-file-protection-error");
  sg__rc_cgen23449.d23473[212] = Sg_Intern(sg__rc_cgen23449.d23473[213]); /* raise-i/o-file-protection-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[15]))->name = sg__rc_cgen23449.d23473[212];/* raise-i/o-file-protection-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[662]))[1] = SG_WORD(sg__rc_cgen23449.d23473[208]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[662]))[6] = SG_WORD(sg__rc_cgen23449.d23473[211]);
  sg__rc_cgen23449.d23473[214] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[214],SG_SYMBOL(sg__rc_cgen23449.d23473[212]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-file-protection-error */
  sg__rc_cgen23449.d23473[215] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[215],SG_SYMBOL(sg__rc_cgen23449.d23473[181]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error-with-port */
  sg__rc_cgen23449.d23473[216] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[218] = SG_MAKE_STRING("make-i/o-file-is-read-only-error");
  sg__rc_cgen23449.d23473[217] = Sg_Intern(sg__rc_cgen23449.d23473[218]); /* make-i/o-file-is-read-only-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[216],SG_SYMBOL(sg__rc_cgen23449.d23473[217]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-file-is-read-only-error */
  sg__rc_cgen23449.d23473[220] = SG_MAKE_STRING("raise-i/o-file-is-read-only-error");
  sg__rc_cgen23449.d23473[219] = Sg_Intern(sg__rc_cgen23449.d23473[220]); /* raise-i/o-file-is-read-only-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[16]))->name = sg__rc_cgen23449.d23473[219];/* raise-i/o-file-is-read-only-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[670]))[1] = SG_WORD(sg__rc_cgen23449.d23473[215]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[670]))[3] = SG_WORD(sg__rc_cgen23449.d23473[216]);
  sg__rc_cgen23449.d23473[221] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[221],SG_SYMBOL(sg__rc_cgen23449.d23473[219]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-file-is-read-only-error */
  sg__rc_cgen23449.d23473[222] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[224] = SG_MAKE_STRING("make-i/o-file-already-exists-error");
  sg__rc_cgen23449.d23473[223] = Sg_Intern(sg__rc_cgen23449.d23473[224]); /* make-i/o-file-already-exists-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[222],SG_SYMBOL(sg__rc_cgen23449.d23473[223]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-file-already-exists-error */
  sg__rc_cgen23449.d23473[225] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[225],SG_SYMBOL(sg__rc_cgen23449.d23473[191]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error */
  sg__rc_cgen23449.d23473[227] = SG_MAKE_STRING("raise-i/o-file-already-exists-error");
  sg__rc_cgen23449.d23473[226] = Sg_Intern(sg__rc_cgen23449.d23473[227]); /* raise-i/o-file-already-exists-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[17]))->name = sg__rc_cgen23449.d23473[226];/* raise-i/o-file-already-exists-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[680]))[1] = SG_WORD(sg__rc_cgen23449.d23473[222]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[680]))[6] = SG_WORD(sg__rc_cgen23449.d23473[225]);
  sg__rc_cgen23449.d23473[228] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[228],SG_SYMBOL(sg__rc_cgen23449.d23473[226]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-file-already-exists-error */
  sg__rc_cgen23449.d23473[229] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[231] = SG_MAKE_STRING("make-i/o-file-does-not-exist-error");
  sg__rc_cgen23449.d23473[230] = Sg_Intern(sg__rc_cgen23449.d23473[231]); /* make-i/o-file-does-not-exist-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[229],SG_SYMBOL(sg__rc_cgen23449.d23473[230]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-file-does-not-exist-error */
  sg__rc_cgen23449.d23473[232] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[232],SG_SYMBOL(sg__rc_cgen23449.d23473[191]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error */
  sg__rc_cgen23449.d23473[234] = SG_MAKE_STRING("raise-i/o-file-does-not-exist-error");
  sg__rc_cgen23449.d23473[233] = Sg_Intern(sg__rc_cgen23449.d23473[234]); /* raise-i/o-file-does-not-exist-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[18]))->name = sg__rc_cgen23449.d23473[233];/* raise-i/o-file-does-not-exist-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[688]))[1] = SG_WORD(sg__rc_cgen23449.d23473[229]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[688]))[6] = SG_WORD(sg__rc_cgen23449.d23473[232]);
  sg__rc_cgen23449.d23473[235] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[235],SG_SYMBOL(sg__rc_cgen23449.d23473[233]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-file-does-not-exist-error */
  sg__rc_cgen23449.d23473[236] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[236],SG_SYMBOL(sg__rc_cgen23449.d23473[52]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* condition */
  sg__rc_cgen23449.d23473[237] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[237],SG_SYMBOL(sg__rc_cgen23449.d23473[58]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* values */
  sg__rc_cgen23449.d23473[238] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[240] = SG_MAKE_STRING("make-i/o-invalid-position-error");
  sg__rc_cgen23449.d23473[239] = Sg_Intern(sg__rc_cgen23449.d23473[240]); /* make-i/o-invalid-position-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[238],SG_SYMBOL(sg__rc_cgen23449.d23473[239]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-invalid-position-error */
  sg__rc_cgen23449.d23473[241] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[241],SG_SYMBOL(sg__rc_cgen23449.d23473[173]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-port-error */
  sg__rc_cgen23449.d23473[242] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[242],SG_SYMBOL(sg__rc_cgen23449.d23473[43]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-who-condition */
  sg__rc_cgen23449.d23473[243] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[243],SG_SYMBOL(sg__rc_cgen23449.d23473[46]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-message-condition */
  sg__rc_cgen23449.d23473[244] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[244],SG_SYMBOL(sg__rc_cgen23449.d23473[66]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* filter */
  sg__rc_cgen23449.d23473[245] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[245],SG_SYMBOL(sg__rc_cgen23449.d23473[37]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise */
  sg__rc_cgen23449.d23473[247] = SG_MAKE_STRING("raise-i/o-invalid-position-error");
  sg__rc_cgen23449.d23473[246] = Sg_Intern(sg__rc_cgen23449.d23473[247]); /* raise-i/o-invalid-position-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[19]))->name = sg__rc_cgen23449.d23473[246];/* raise-i/o-invalid-position-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[3] = SG_WORD(sg__rc_cgen23449.d23473[236]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[7] = SG_WORD(sg__rc_cgen23449.d23473[237]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[12] = SG_WORD(sg__rc_cgen23449.d23473[238]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[18] = SG_WORD(sg__rc_cgen23449.d23473[241]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[27] = SG_WORD(sg__rc_cgen23449.d23473[242]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[33] = SG_WORD(sg__rc_cgen23449.d23473[243]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[37] = SG_WORD(sg__rc_cgen23449.d23473[244]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[696]))[41] = SG_WORD(sg__rc_cgen23449.d23473[245]);
  sg__rc_cgen23449.d23473[248] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[248],SG_SYMBOL(sg__rc_cgen23449.d23473[246]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-invalid-position-error */
  sg__rc_cgen23449.d23473[249] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[251] = SG_MAKE_STRING("make-i/o-decoding-error");
  sg__rc_cgen23449.d23473[250] = Sg_Intern(sg__rc_cgen23449.d23473[251]); /* make-i/o-decoding-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[249],SG_SYMBOL(sg__rc_cgen23449.d23473[250]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-decoding-error */
  sg__rc_cgen23449.d23473[252] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[252],SG_SYMBOL(sg__rc_cgen23449.d23473[191]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error */
  sg__rc_cgen23449.d23473[254] = SG_MAKE_STRING("raise-i/o-decoding-error");
  sg__rc_cgen23449.d23473[253] = Sg_Intern(sg__rc_cgen23449.d23473[254]); /* raise-i/o-decoding-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[20]))->name = sg__rc_cgen23449.d23473[253];/* raise-i/o-decoding-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[739]))[1] = SG_WORD(sg__rc_cgen23449.d23473[249]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[739]))[6] = SG_WORD(sg__rc_cgen23449.d23473[252]);
  sg__rc_cgen23449.d23473[255] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[255],SG_SYMBOL(sg__rc_cgen23449.d23473[253]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-decoding-error */
  sg__rc_cgen23449.d23473[256] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  sg__rc_cgen23449.d23473[258] = SG_MAKE_STRING("make-i/o-encoding-error");
  sg__rc_cgen23449.d23473[257] = Sg_Intern(sg__rc_cgen23449.d23473[258]); /* make-i/o-encoding-error */
  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[256],SG_SYMBOL(sg__rc_cgen23449.d23473[257]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* make-i/o-encoding-error */
  sg__rc_cgen23449.d23473[259] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[259],SG_SYMBOL(sg__rc_cgen23449.d23473[191]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-misc-i/o-error */
  sg__rc_cgen23449.d23473[261] = SG_MAKE_STRING("raise-i/o-encoding-error");
  sg__rc_cgen23449.d23473[260] = Sg_Intern(sg__rc_cgen23449.d23473[261]); /* raise-i/o-encoding-error */
  SG_CODE_BUILDER(SG_OBJ(&sg__rc_cgen23449.d23475[21]))->name = sg__rc_cgen23449.d23473[260];/* raise-i/o-encoding-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[747]))[1] = SG_WORD(sg__rc_cgen23449.d23473[256]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[747]))[7] = SG_WORD(sg__rc_cgen23449.d23473[259]);
  sg__rc_cgen23449.d23473[262] = Sg_MakeRawIdentifier(NULL, NULL, NULL, NULL, 0);

  SG_INIT_IDENTIFIER(sg__rc_cgen23449.d23473[262],SG_SYMBOL(sg__rc_cgen23449.d23473[260]),SG_NIL,SG_FALSE,SG_LIBRARY(sg__rc_cgen23449.d23473[0]),FALSE); /* raise-i/o-encoding-error */
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[1] = SG_WORD(sg__rc_cgen23449.d23473[0]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[5] = SG_WORD(sg__rc_cgen23449.d23473[18]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[9] = SG_WORD(sg__rc_cgen23449.d23473[27]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[13] = SG_WORD(sg__rc_cgen23449.d23473[55]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[17] = SG_WORD(sg__rc_cgen23449.d23473[71]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[21] = SG_WORD(sg__rc_cgen23449.d23473[83]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[25] = SG_WORD(sg__rc_cgen23449.d23473[104]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[29] = SG_WORD(sg__rc_cgen23449.d23473[117]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[33] = SG_WORD(sg__rc_cgen23449.d23473[128]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[37] = SG_WORD(sg__rc_cgen23449.d23473[141]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[41] = SG_WORD(sg__rc_cgen23449.d23473[154]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[45] = SG_WORD(sg__rc_cgen23449.d23473[167]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[49] = SG_WORD(sg__rc_cgen23449.d23473[183]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[53] = SG_WORD(sg__rc_cgen23449.d23473[193]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[57] = SG_WORD(sg__rc_cgen23449.d23473[200]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[61] = SG_WORD(sg__rc_cgen23449.d23473[207]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[65] = SG_WORD(sg__rc_cgen23449.d23473[214]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[69] = SG_WORD(sg__rc_cgen23449.d23473[221]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[73] = SG_WORD(sg__rc_cgen23449.d23473[228]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[77] = SG_WORD(sg__rc_cgen23449.d23473[235]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[81] = SG_WORD(sg__rc_cgen23449.d23473[248]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[85] = SG_WORD(sg__rc_cgen23449.d23473[255]);
  ((SgWord*)SG_OBJ(&sg__rc_cgen23449.d23474[756]))[89] = SG_WORD(sg__rc_cgen23449.d23473[262]);
  sg__rc_cgen23449.d23473[264] = SG_MAKE_STRING("(core)");
  sg__rc_cgen23449.d23473[263] = Sg_Intern(sg__rc_cgen23449.d23473[264]); /* (core) */
  Sg_ImportLibrary(sg__rc_cgen23449.d23473[0], sg__rc_cgen23449.d23473[263]);

  sg__rc_cgen23449.d23473[266] = SG_MAKE_STRING("(core base)");
  sg__rc_cgen23449.d23473[265] = Sg_Intern(sg__rc_cgen23449.d23473[266]); /* (core base) */
  Sg_ImportLibrary(sg__rc_cgen23449.d23473[0], sg__rc_cgen23449.d23473[265]);

  sg__rc_cgen23449.d23473[268] = SG_MAKE_STRING("(sagittarius)");
  sg__rc_cgen23449.d23473[267] = Sg_Intern(sg__rc_cgen23449.d23473[268]); /* (sagittarius) */
  Sg_ImportLibrary(sg__rc_cgen23449.d23473[0], sg__rc_cgen23449.d23473[267]);

  sg__rc_cgen23449.d23473[270] = SG_MAKE_STRING("(sagittarius vm)");
  sg__rc_cgen23449.d23473[269] = Sg_Intern(sg__rc_cgen23449.d23473[270]); /* (sagittarius vm) */
  Sg_ImportLibrary(sg__rc_cgen23449.d23473[0], sg__rc_cgen23449.d23473[269]);

  sg__rc_cgen23449.d23473[274] = SG_MAKE_STRING("error");
  sg__rc_cgen23449.d23473[273] = Sg_Intern(sg__rc_cgen23449.d23473[274]); /* error */
  sg__rc_cgen23449.d23473[276] = SG_MAKE_STRING("assertion-violation");
  sg__rc_cgen23449.d23473[275] = Sg_Intern(sg__rc_cgen23449.d23473[276]); /* assertion-violation */
  sg__rc_cgen23449.d23473[278] = SG_MAKE_STRING("describe-condition");
  sg__rc_cgen23449.d23473[277] = Sg_Intern(sg__rc_cgen23449.d23473[278]); /* describe-condition */
  do {
    /* (raise-i/o-encoding-error raise-i/o-decoding-error raise-i/o-invalid-position-error raise-i/o-file-does-not-exist-error raise-i/o-file-already-exists-error raise-i/o-file-is-read-only-error raise-i/o-file-protection-error raise-i/o-write-error raise-i/o-read-error raise-i/o-error raise-i/o-filename-error assertion/syntax-violation undefined/syntax-violation implementation-restriction-violation error syntax-violation lexical-violation undefined-violation assertion-violation describe-condition raise-continuable raise) */ 
    SgObject G23476 = SG_NIL, G23477 = SG_NIL;
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[260]); /* raise-i/o-encoding-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[253]); /* raise-i/o-decoding-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[246]); /* raise-i/o-invalid-position-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[233]); /* raise-i/o-file-does-not-exist-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[226]); /* raise-i/o-file-already-exists-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[219]); /* raise-i/o-file-is-read-only-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[212]); /* raise-i/o-file-protection-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[205]); /* raise-i/o-write-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[198]); /* raise-i/o-read-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[165]); /* raise-i/o-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[152]); /* raise-i/o-filename-error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[139]); /* assertion/syntax-violation */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[126]); /* undefined/syntax-violation */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[115]); /* implementation-restriction-violation */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[273]); /* error */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[102]); /* syntax-violation */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[81]); /* lexical-violation */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[69]); /* undefined-violation */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[275]); /* assertion-violation */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[277]); /* describe-condition */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[25]); /* raise-continuable */ 
    SG_APPEND1(G23476, G23477, sg__rc_cgen23449.d23473[37]); /* raise */ 
    sg__rc_cgen23449.d23473[272] = G23476;
  } while (0);
  do {
    /* ((raise-i/o-encoding-error raise-i/o-decoding-error raise-i/o-invalid-position-error raise-i/o-file-does-not-exist-error raise-i/o-file-already-exists-error raise-i/o-file-is-read-only-error raise-i/o-file-protection-error raise-i/o-write-error raise-i/o-read-error raise-i/o-error raise-i/o-filename-error assertion/syntax-violation undefined/syntax-violation implementation-restriction-violation error syntax-violation lexical-violation undefined-violation assertion-violation describe-condition raise-continuable raise)) */ 
    SgObject G23478 = SG_NIL, G23479 = SG_NIL;
    SG_APPEND1(G23478, G23479, sg__rc_cgen23449.d23473[272]); /* (raise-i/o-encoding-error raise-i/o-decoding-error raise-i/o-invalid-position-error raise-i/o-file-does-not-exist-error raise-i/o-file-already-exists-error raise-i/o-file-is-read-only-error raise-i/o-file-protection-error raise-i/o-write-error raise-i/o-read-error raise-i/o-error raise-i/o-filename-error assertion/syntax-violation undefined/syntax-violation implementation-restriction-violation error syntax-violation lexical-violation undefined-violation assertion-violation describe-condition raise-continuable raise) */ 
    sg__rc_cgen23449.d23473[271] = G23478;
  } while (0);
  Sg_LibraryExportedSet(sg__rc_cgen23449.d23473[0], sg__rc_cgen23449.d23473[271]);

  Sg_VM()->currentLibrary = sg__rc_cgen23449.d23473[0];
  Sg_VMExecute(SG_OBJ(G23450));
  Sg_VM()->currentLibrary = save;
}
