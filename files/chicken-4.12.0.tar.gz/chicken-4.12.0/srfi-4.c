/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-cc.org
   2017-02-19 13:16
   Version 4.12.0 (rev 6ea24b6)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2017-02-19 on yves.more-magic.net (Linux)
   command line: srfi-4.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file srfi-4.c
   unit: srfi_2d4
*/

#include "chicken.h"

#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[163];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,99,104,101,99,107,45,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,54,52,32,102,114,111,109,54,53,32,116,111,54,54,32,108,111,99,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,21),40,117,56,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,51,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,21),40,115,56,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,54,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,22),40,117,49,54,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,57,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,22),40,115,49,54,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,50,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,22),40,117,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,53,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,22),40,115,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,56,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,22),40,102,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,57,49,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,22),40,102,54,52,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,57,52,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,27),40,117,56,118,101,99,116,111,114,45,115,101,116,33,32,120,57,55,32,105,57,56,32,121,57,57,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,30),40,115,56,118,101,99,116,111,114,45,115,101,116,33,32,120,49,49,53,32,105,49,49,54,32,121,49,49,55,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,31),40,117,49,54,118,101,99,116,111,114,45,115,101,116,33,32,120,49,51,50,32,105,49,51,51,32,121,49,51,52,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,31),40,115,49,54,118,101,99,116,111,114,45,115,101,116,33,32,120,49,53,48,32,105,49,53,49,32,121,49,53,50,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,31),40,117,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,49,54,55,32,105,49,54,56,32,121,49,54,57,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,31),40,115,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,49,56,57,32,105,49,57,48,32,121,49,57,49,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,31),40,102,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,50,48,55,32,105,50,48,56,32,121,50,48,57,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,31),40,102,54,52,118,101,99,116,111,114,45,115,101,116,33,32,120,50,50,52,32,105,50,50,53,32,121,50,50,54,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,19),40,101,120,116,45,102,114,101,101,32,98,118,51,54,54,51,54,57,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,29),40,97,108,108,111,99,32,108,111,99,51,55,49,32,108,101,110,51,55,50,32,101,120,116,63,51,55,51,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,28),40,114,101,108,101,97,115,101,45,110,117,109,98,101,114,45,118,101,99,116,111,114,32,118,51,56,48,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,48,49,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,117,56,118,101,99,116,111,114,32,108,101,110,51,56,53,32,46,32,116,109,112,51,56,52,51,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,50,57,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,115,56,118,101,99,116,111,114,32,108,101,110,52,49,51,32,46,32,116,109,112,52,49,50,52,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,53,55,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,49,54,118,101,99,116,111,114,32,108,101,110,52,52,49,32,46,32,116,109,112,52,52,48,52,52,50,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,56,53,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,49,54,118,101,99,116,111,114,32,108,101,110,52,54,57,32,46,32,116,109,112,52,54,56,52,55,48,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,49,51,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,51,50,118,101,99,116,111,114,32,108,101,110,52,57,55,32,46,32,116,109,112,52,57,54,52,57,56,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,52,49,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,51,50,118,101,99,116,111,114,32,108,101,110,53,50,53,32,46,32,116,109,112,53,50,52,53,50,54,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,54,57,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,51,50,118,101,99,116,111,114,32,108,101,110,53,53,51,32,46,32,116,109,112,53,53,50,53,53,52,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,57,56,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,54,52,118,101,99,116,111,114,32,108,101,110,53,56,50,32,46,32,116,109,112,53,56,49,53,56,51,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,51,50,32,112,54,51,52,32,105,54,51,53,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,23),40,108,105,115,116,45,62,117,56,118,101,99,116,111,114,32,108,115,116,54,50,57,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,52,53,32,112,54,52,55,32,105,54,52,56,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,23),40,108,105,115,116,45,62,115,56,118,101,99,116,111,114,32,108,115,116,54,52,50,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,53,56,32,112,54,54,48,32,105,54,54,49,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,117,49,54,118,101,99,116,111,114,32,108,115,116,54,53,53,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,55,49,32,112,54,55,51,32,105,54,55,52,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,115,49,54,118,101,99,116,111,114,32,108,115,116,54,54,56,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,56,52,32,112,54,56,54,32,105,54,56,55,41,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,117,51,50,118,101,99,116,111,114,32,108,115,116,54,56,49,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,57,55,32,112,54,57,57,32,105,55,48,48,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,115,51,50,118,101,99,116,111,114,32,108,115,116,54,57,52,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,49,48,32,112,55,49,50,32,105,55,49,51,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,102,51,50,118,101,99,116,111,114,32,108,115,116,55,48,55,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,50,51,32,112,55,50,53,32,105,55,50,54,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,102,54,52,118,101,99,116,111,114,32,108,115,116,55,50,48,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,117,56,118,101,99,116,111,114,32,46,32,120,115,55,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,18),40,115,56,118,101,99,116,111,114,32,46,32,120,115,55,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,19),40,117,49,54,118,101,99,116,111,114,32,46,32,120,115,55,51,54,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,19),40,115,49,54,118,101,99,116,111,114,32,46,32,120,115,55,51,56,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,19),40,117,51,50,118,101,99,116,111,114,32,46,32,120,115,55,52,48,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,19),40,115,51,50,118,101,99,116,111,114,32,46,32,120,115,55,52,50,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,19),40,102,51,50,118,101,99,116,111,114,32,46,32,120,115,55,52,52,41,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,19),40,102,54,52,118,101,99,116,111,114,32,46,32,120,115,55,52,54,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,54,55,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,21),40,117,56,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,54,52,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,55,52,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,115,56,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,55,49,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,56,49,41,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,22),40,117,49,54,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,55,56,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,56,56,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,22),40,115,49,54,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,56,53,41,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,57,53,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,22),40,117,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,57,50,41,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,48,50,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,22),40,115,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,57,57,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,48,57,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,22),40,102,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,48,54,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,49,54,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,22),40,102,54,52,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,49,51,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,16),40,117,56,118,101,99,116,111,114,63,32,120,56,50,48,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,16),40,115,56,118,101,99,116,111,114,63,32,120,56,50,50,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,117,49,54,118,101,99,116,111,114,63,32,120,56,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,17),40,115,49,54,118,101,99,116,111,114,63,32,120,56,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,17),40,117,51,50,118,101,99,116,111,114,63,32,120,56,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,17),40,115,51,50,118,101,99,116,111,114,63,32,120,56,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,17),40,102,51,50,118,101,99,116,111,114,63,32,120,56,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,17),40,102,54,52,118,101,99,116,111,114,63,32,120,56,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,13),40,102,95,51,51,56,50,32,118,56,52,52,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,25),40,112,97,99,107,45,99,111,112,121,32,116,97,103,56,52,50,32,108,111,99,56,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,15),40,102,95,51,52,48,48,32,115,116,114,56,53,50,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,28),40,117,110,112,97,99,107,32,116,97,103,56,52,57,32,115,122,56,53,48,32,108,111,99,56,53,49,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,102,95,51,52,51,48,32,115,116,114,56,54,50,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,33),40,117,110,112,97,99,107,45,99,111,112,121,32,116,97,103,56,53,57,32,115,122,56,54,48,32,108,111,99,56,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,16),40,102,53,48,52,49,32,118,56,51,57,53,48,52,48,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,16),40,102,53,48,51,52,32,118,56,51,57,53,48,51,51,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,16),40,102,53,48,50,55,32,118,56,51,57,53,48,50,54,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,16),40,102,53,48,50,48,32,118,56,51,57,53,48,49,57,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,16),40,102,53,48,49,51,32,118,56,51,57,53,48,49,50,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,102,53,48,48,54,32,118,56,51,57,53,48,48,53,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,16),40,102,52,57,57,57,32,118,56,51,57,52,57,57,56,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,16),40,102,52,57,57,50,32,118,56,51,57,52,57,57,49,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,11),40,103,57,49,56,32,99,57,50,48,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,117,115,101,114,45,114,101,97,100,45,104,111,111,107,32,99,104,97,114,57,48,52,32,112,111,114,116,57,48,53,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,117,115,101,114,45,112,114,105,110,116,45,104,111,111,107,32,120,57,50,52,32,114,101,97,100,97,98,108,101,57,50,53,32,112,111,114,116,57,50,54,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,49),40,115,117,98,110,118,101,99,116,111,114,32,118,57,51,57,32,116,57,52,48,32,101,115,57,52,49,32,102,114,111,109,57,52,50,32,116,111,57,52,51,32,108,111,99,57,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,115,117,98,117,56,118,101,99,116,111,114,32,118,57,55,53,32,102,114,111,109,57,55,54,32,116,111,57,55,55,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,49,54,118,101,99,116,111,114,32,118,57,55,57,32,102,114,111,109,57,56,48,32,116,111,57,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,51,50,118,101,99,116,111,114,32,118,57,56,51,32,102,114,111,109,57,56,52,32,116,111,57,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,32),40,115,117,98,115,56,118,101,99,116,111,114,32,118,57,56,55,32,102,114,111,109,57,56,56,32,116,111,57,56,57,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,49,54,118,101,99,116,111,114,32,118,57,57,49,32,102,114,111,109,57,57,50,32,116,111,57,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,51,50,118,101,99,116,111,114,32,118,57,57,53,32,102,114,111,109,57,57,54,32,116,111,57,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,35),40,115,117,98,102,51,50,118,101,99,116,111,114,32,118,57,57,57,32,102,114,111,109,49,48,48,48,32,116,111,49,48,48,49,41,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,36),40,115,117,98,102,54,52,118,101,99,116,111,114,32,118,49,48,48,51,32,102,114,111,109,49,48,48,52,32,116,111,49,48,48,53,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,36),40,119,114,105,116,101,45,117,56,118,101,99,116,111,114,32,118,49,48,49,49,32,46,32,116,109,112,49,48,49,48,49,48,49,50,41,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,45),40,114,101,97,100,45,117,56,118,101,99,116,111,114,33,32,110,49,48,54,53,32,100,101,115,116,49,48,54,54,32,46,32,116,109,112,49,48,54,52,49,48,54,55,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,117,56,118,101,99,116,111,114,32,46,32,116,109,112,49,48,57,48,49,48,57,49,41,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,97,52,49,52,56,32,120,51,52,54,32,105,51,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,17),40,97,52,49,55,56,32,120,51,51,49,32,105,51,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,17),40,97,52,50,48,56,32,120,51,49,54,32,105,51,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,17),40,97,52,50,51,56,32,120,51,48,49,32,105,51,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,17),40,97,52,50,54,56,32,120,50,56,54,32,105,50,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,17),40,97,52,50,57,56,32,120,50,55,49,32,105,50,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,17),40,97,52,51,50,56,32,120,50,53,54,32,105,50,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,17),40,97,52,51,53,56,32,120,50,52,49,32,105,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub367(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub362(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) C_return(C_SCHEME_FALSE);C_block_header_init(buf, C_make_header(C_BYTEVECTOR_TYPE, bytes));C_return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word *av) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word *av) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word *av) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word *av) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word *av) C_noret;
C_noret_decl(f5034)
static void C_ccall f5034(C_word c,C_word *av) C_noret;
C_noret_decl(f_1917)
static void C_fcall f_1917(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word *av) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word *av) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word *av) C_noret;
C_noret_decl(f5041)
static void C_ccall f5041(C_word c,C_word *av) C_noret;
C_noret_decl(f_3398)
static void C_fcall f_3398(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word *av) C_noret;
C_noret_decl(f_3380)
static void C_fcall f_3380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word *av) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word *av) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word *av) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word *av) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word *av) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word *av) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word *av) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word *av) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word *av) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word *av) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word *av) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word *av) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word *av) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word *av) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word *av) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word *av) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word *av) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word *av) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word *av) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word *av) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word *av) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word *av) C_noret;
C_noret_decl(f_2485)
static C_word C_fcall f_2485(C_word t0,C_word t1);
C_noret_decl(f_3271)
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5013)
static void C_ccall f5013(C_word c,C_word *av) C_noret;
C_noret_decl(f_3093)
static void C_fcall f_3093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word *av) C_noret;
C_noret_decl(f5020)
static void C_ccall f5020(C_word c,C_word *av) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word *av) C_noret;
C_noret_decl(f5027)
static void C_ccall f5027(C_word c,C_word *av) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word *av) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word *av) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word *av) C_noret;
C_noret_decl(f5006)
static void C_ccall f5006(C_word c,C_word *av) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word *av) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word *av) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word *av) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word *av) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word *av) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word *av) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word *av) C_noret;
C_noret_decl(f_3153)
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word *av) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word *av) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word *av) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word *av) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word *av) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word *av) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word *av) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word *av) C_noret;
C_noret_decl(f_2904)
static void C_fcall f_2904(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word *av) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word *av) C_noret;
C_noret_decl(f_4061)
static void C_fcall f_4061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word *av) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word *av) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word *av) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word *av) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word *av) C_noret;
C_noret_decl(f_1494)
static void C_fcall f_1494(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word *av) C_noret;
C_noret_decl(f_2386)
static C_word C_fcall f_2386(C_word t0,C_word t1);
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word *av) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word *av) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word *av) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word *av) C_noret;
C_noret_decl(f_3917)
static void C_fcall f_3917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word *av) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word *av) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word *av) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word *av) C_noret;
C_noret_decl(f_2796)
static void C_fcall f_2796(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word *av) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word *av) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word *av) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word *av) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word *av) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word *av) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word *av) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word *av) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word *av) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word *av) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word *av) C_noret;
C_noret_decl(f_2690)
static C_word C_fcall f_2690(C_word t0,C_word t1);
C_noret_decl(f_2760)
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word *av) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word *av) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word *av) C_noret;
C_noret_decl(f_2685)
static void C_fcall f_2685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word *av) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word *av) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word *av) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word *av) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word *av) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word *av) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word *av) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word *av) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word *av) C_noret;
C_noret_decl(f_2832)
static void C_fcall f_2832(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word *av) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word *av) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word *av) C_noret;
C_noret_decl(f_2090)
static C_word C_fcall f_2090(C_word t0,C_word t1);
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word *av) C_noret;
C_noret_decl(f_2868)
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word *av) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word *av) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word *av) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word *av) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word *av) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word *av) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word *av) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d4_toplevel)
C_externexport void C_ccall C_srfi_2d4_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word *av) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word *av) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word *av) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word *av) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word *av) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word *av) C_noret;
C_noret_decl(f_3300)
static void C_fcall f_3300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word *av) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word *av) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word *av) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word *av) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word *av) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word *av) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word *av) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word *av) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word *av) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word *av) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word *av) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word *av) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word *av) C_noret;
C_noret_decl(f_2287)
static C_word C_fcall f_2287(C_word t0,C_word t1);
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word *av) C_noret;
C_noret_decl(f_3621)
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word *av) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word *av) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word *av) C_noret;
C_noret_decl(f_2587)
static C_word C_fcall f_2587(C_word t0,C_word t1);
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word *av) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word *av) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word *av) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word *av) C_noret;
C_noret_decl(f_2976)
static void C_fcall f_2976(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f4992)
static void C_ccall f4992(C_word c,C_word *av) C_noret;
C_noret_decl(f4999)
static void C_ccall f4999(C_word c,C_word *av) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word *av) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word *av) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word *av) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word *av) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word *av) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word *av) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word *av) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word *av) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word *av) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word *av) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word *av) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word *av) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word *av) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word *av) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word *av) C_noret;
C_noret_decl(f_3416)
static void C_fcall f_3416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word *av) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word *av) C_noret;
C_noret_decl(f_3449)
static void C_fcall f_3449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word *av) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word *av) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word *av) C_noret;
C_noret_decl(f_3213)
static void C_fcall f_3213(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word *av) C_noret;
C_noret_decl(f_3242)
static void C_fcall f_3242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word *av) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word *av) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word *av) C_noret;
C_noret_decl(f_2188)
static C_word C_fcall f_2188(C_word t0,C_word t1);
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word *av) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word *av) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word *av) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word *av) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word *av) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word *av) C_noret;
C_noret_decl(f_3428)
static void C_fcall f_3428(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word *av) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word *av) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word *av) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word *av) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word *av) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word *av) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word *av) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word *av) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word *av) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word *av) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word *av) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word *av) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word *av) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word *av) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word *av) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word *av) C_noret;
C_noret_decl(f_3012)
static void C_fcall f_3012(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3123)
static void C_fcall f_3123(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word *av) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word *av) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word *av) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word *av) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word *av) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word *av) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word *av) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word *av) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word *av) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word *av) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word *av) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word *av) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word *av) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word *av) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word *av) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word *av) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word *av) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word *av) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word *av) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word *av) C_noret;
C_noret_decl(f_3719)
static void C_fcall f_3719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2940)
static void C_fcall f_2940(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1992)
static C_word C_fcall f_1992(C_word t0,C_word t1);
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word *av) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word *av) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word *av) C_noret;

C_noret_decl(trf_1917)
static void C_ccall trf_1917(C_word c,C_word *av) C_noret;
static void C_ccall trf_1917(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1917(t0,t1,t2,t3);}

C_noret_decl(trf_3398)
static void C_ccall trf_3398(C_word c,C_word *av) C_noret;
static void C_ccall trf_3398(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3398(t0,t1,t2,t3);}

C_noret_decl(trf_3380)
static void C_ccall trf_3380(C_word c,C_word *av) C_noret;
static void C_ccall trf_3380(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3380(t0,t1,t2);}

C_noret_decl(trf_3271)
static void C_ccall trf_3271(C_word c,C_word *av) C_noret;
static void C_ccall trf_3271(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3271(t0,t1,t2);}

C_noret_decl(trf_3093)
static void C_ccall trf_3093(C_word c,C_word *av) C_noret;
static void C_ccall trf_3093(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3093(t0,t1,t2);}

C_noret_decl(trf_3153)
static void C_ccall trf_3153(C_word c,C_word *av) C_noret;
static void C_ccall trf_3153(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3153(t0,t1,t2);}

C_noret_decl(trf_2904)
static void C_ccall trf_2904(C_word c,C_word *av) C_noret;
static void C_ccall trf_2904(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2904(t0,t1,t2,t3);}

C_noret_decl(trf_4061)
static void C_ccall trf_4061(C_word c,C_word *av) C_noret;
static void C_ccall trf_4061(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4061(t0,t1);}

C_noret_decl(trf_3183)
static void C_ccall trf_3183(C_word c,C_word *av) C_noret;
static void C_ccall trf_3183(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3183(t0,t1,t2);}

C_noret_decl(trf_1494)
static void C_ccall trf_1494(C_word c,C_word *av) C_noret;
static void C_ccall trf_1494(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1494(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3917)
static void C_ccall trf_3917(C_word c,C_word *av) C_noret;
static void C_ccall trf_3917(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3917(t0,t1);}

C_noret_decl(trf_2796)
static void C_ccall trf_2796(C_word c,C_word *av) C_noret;
static void C_ccall trf_2796(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2796(t0,t1,t2,t3);}

C_noret_decl(trf_2760)
static void C_ccall trf_2760(C_word c,C_word *av) C_noret;
static void C_ccall trf_2760(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2760(t0,t1,t2,t3);}

C_noret_decl(trf_2685)
static void C_ccall trf_2685(C_word c,C_word *av) C_noret;
static void C_ccall trf_2685(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2685(t0,t1);}

C_noret_decl(trf_2832)
static void C_ccall trf_2832(C_word c,C_word *av) C_noret;
static void C_ccall trf_2832(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2832(t0,t1,t2,t3);}

C_noret_decl(trf_2868)
static void C_ccall trf_2868(C_word c,C_word *av) C_noret;
static void C_ccall trf_2868(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2868(t0,t1,t2,t3);}

C_noret_decl(trf_3300)
static void C_ccall trf_3300(C_word c,C_word *av) C_noret;
static void C_ccall trf_3300(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3300(t0,t1,t2);}

C_noret_decl(trf_3621)
static void C_ccall trf_3621(C_word c,C_word *av) C_noret;
static void C_ccall trf_3621(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3621(t0,t1,t2);}

C_noret_decl(trf_2582)
static void C_ccall trf_2582(C_word c,C_word *av) C_noret;
static void C_ccall trf_2582(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2582(t0,t1);}

C_noret_decl(trf_2976)
static void C_ccall trf_2976(C_word c,C_word *av) C_noret;
static void C_ccall trf_2976(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2976(t0,t1,t2,t3);}

C_noret_decl(trf_3416)
static void C_ccall trf_3416(C_word c,C_word *av) C_noret;
static void C_ccall trf_3416(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3416(t0,t1);}

C_noret_decl(trf_3449)
static void C_ccall trf_3449(C_word c,C_word *av) C_noret;
static void C_ccall trf_3449(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3449(t0,t1);}

C_noret_decl(trf_3213)
static void C_ccall trf_3213(C_word c,C_word *av) C_noret;
static void C_ccall trf_3213(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3213(t0,t1,t2);}

C_noret_decl(trf_3242)
static void C_ccall trf_3242(C_word c,C_word *av) C_noret;
static void C_ccall trf_3242(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3242(t0,t1,t2);}

C_noret_decl(trf_3428)
static void C_ccall trf_3428(C_word c,C_word *av) C_noret;
static void C_ccall trf_3428(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3428(t0,t1,t2,t3);}

C_noret_decl(trf_3012)
static void C_ccall trf_3012(C_word c,C_word *av) C_noret;
static void C_ccall trf_3012(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3012(t0,t1,t2,t3);}

C_noret_decl(trf_3123)
static void C_ccall trf_3123(C_word c,C_word *av) C_noret;
static void C_ccall trf_3123(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3123(t0,t1,t2);}

C_noret_decl(trf_3719)
static void C_ccall trf_3719(C_word c,C_word *av) C_noret;
static void C_ccall trf_3719(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_3719(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2940)
static void C_ccall trf_2940(C_word c,C_word *av) C_noret;
static void C_ccall trf_2940(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2940(t0,t1,t2,t3);}

/* k3106 in loop in u8vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3108,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3496,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[96]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3500,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:545: pack-copy */
f_3380(t3,lf[6],lf[97]);}

/* make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,4)))){
C_save_and_reclaim((void*)f_1950,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[47]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2010,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:286: alloc */
f_1917(t20,lf[47],t2,t11);}

/* k2008 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2010,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[4],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:287: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_1978(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_1978(2,av2);}}}

/* k1985 in k1976 in k2008 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_1987,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=(
  f_1992(t2,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* f5034 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f5034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5034,3,av);}
t3=C_i_check_structure_2(t2,lf[6],lf[89]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* alloc in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_1917(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,5)))){
C_save_and_reclaim_args((void *)trf_1917,4,t1,t2,t3,t4);}
a=C_alloc(3);
if(C_truep(t4)){
t5=t3;
t6=C_i_foreign_fixnum_argumentp(t5);
t7=stub362(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
/* srfi-4.scm:272: ##sys#error */
t8=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[42];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:273: ##sys#allocate-vector */
t6=*((C_word*)lf[43]+1);{
C_word av2[6];
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}}

/* ext-free in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1915,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=stub367(C_SCHEME_UNDEFINED,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,4)))){
C_save_and_reclaim((void*)f_2048,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[49]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2108,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:299: alloc */
f_1917(t20,lf[49],t2,t11);}

/* k1976 in k2008 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_1978,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:291: ##sys#check-exact-interval */
f_1494(t2,((C_word*)t0)[2],C_fix(0),C_fix(255),lf[47]);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* f5041 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f5041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5041,3,av);}
t3=C_i_check_structure_2(t2,lf[4],lf[88]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* unpack in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3398(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3398,4,t1,t2,t3,t4);}
a=C_alloc(6);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3400,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k3390 */
static void C_ccall f_3392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3392,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_copy_block(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* pack-copy in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3380(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_3380,3,t1,t2,t3);}
a=C_alloc(5);
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3382,a[2]=t2,a[3]=t3,a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* f_3382 in pack-copy in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3382,3,av);}
a=C_alloc(4);
t3=C_i_check_structure_2(t2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3392,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_block_size(t5);
/* srfi-4.scm:511: ##sys#make-blob */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[83]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[83]+1);
av2[1]=t6;
av2[2]=t7;
tp(3,av2);}}

/* k2469 in k2501 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2471(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2471,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[53]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word)li30),tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(
  f_2485(t3,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(189,c,5)))){
C_save_and_reclaim((void *)f_1908,2,av);}
a=C_alloc(189);
t2=C_mutate2((C_word*)lf[41]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
t5=C_mutate2((C_word*)lf[44]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1935,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[47]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1950,a[2]=t3,a[3]=t4,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
t7=C_mutate2((C_word*)lf[49]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2048,a[2]=t3,a[3]=t4,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp));
t8=C_mutate2((C_word*)lf[50]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2146,a[2]=t3,a[3]=t4,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t9=C_mutate2((C_word*)lf[51]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2245,a[2]=t3,a[3]=t4,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate2((C_word*)lf[52]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2344,a[2]=t3,a[3]=t4,a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate2((C_word*)lf[53]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2443,a[2]=t3,a[3]=t4,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate2((C_word*)lf[54]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2542,a[2]=t3,a[3]=t4,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate2((C_word*)lf[55]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2645,a[2]=t3,a[3]=t4,a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));
t14=*((C_word*)lf[47]+1);
t15=C_mutate2((C_word*)lf[56]+1 /* (set! list->u8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2748,a[2]=t14,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[49]+1);
t17=C_mutate2((C_word*)lf[58]+1 /* (set! list->s8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t16,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp));
t18=*((C_word*)lf[50]+1);
t19=C_mutate2((C_word*)lf[59]+1 /* (set! list->u16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2820,a[2]=t18,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[51]+1);
t21=C_mutate2((C_word*)lf[60]+1 /* (set! list->s16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2856,a[2]=t20,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp));
t22=*((C_word*)lf[52]+1);
t23=C_mutate2((C_word*)lf[61]+1 /* (set! list->u32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2892,a[2]=t22,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp));
t24=*((C_word*)lf[53]+1);
t25=C_mutate2((C_word*)lf[62]+1 /* (set! list->s32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2928,a[2]=t24,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp));
t26=*((C_word*)lf[54]+1);
t27=C_mutate2((C_word*)lf[63]+1 /* (set! list->f32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2964,a[2]=t26,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t28=*((C_word*)lf[55]+1);
t29=C_mutate2((C_word*)lf[64]+1 /* (set! list->f64vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3000,a[2]=t28,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t30=C_mutate2((C_word*)lf[4]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3036,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate2((C_word*)lf[6]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate2((C_word*)lf[8]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3048,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[10]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3054,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[12]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3060,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[14]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3066,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[16]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3072,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[18]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[65]+1 /* (set! u8vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3084,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate2((C_word*)lf[66]+1 /* (set! s8vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3114,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate2((C_word*)lf[67]+1 /* (set! u16vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate2((C_word*)lf[68]+1 /* (set! s16vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3174,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate2((C_word*)lf[69]+1 /* (set! u32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate2((C_word*)lf[70]+1 /* (set! s32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3233,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate2((C_word*)lf[71]+1 /* (set! f32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate2((C_word*)lf[72]+1 /* (set! f64vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate2((C_word*)lf[73]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3320,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate2((C_word*)lf[74]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate2((C_word*)lf[75]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3332,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate2((C_word*)lf[76]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3338,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate2((C_word*)lf[77]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate2((C_word*)lf[78]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3350,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate2((C_word*)lf[79]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3356,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate2((C_word*)lf[80]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate2((C_word*)lf[46]+1 /* (set! number-vector? ...) */,*((C_word*)lf[81]+1));
t55=C_mutate2(&lf[82] /* (set! pack-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3380,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate2(&lf[84] /* (set! unpack ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3398,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate2(&lf[86] /* (set! unpack-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3428,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5041,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t59=C_mutate2((C_word*)lf[88]+1 /* (set! u8vector->blob/shared ...) */,t58);
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5034,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
t61=C_mutate2((C_word*)lf[89]+1 /* (set! s8vector->blob/shared ...) */,t60);
t62=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5027,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
t63=C_mutate2((C_word*)lf[90]+1 /* (set! u16vector->blob/shared ...) */,t62);
t64=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5020,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
t65=C_mutate2((C_word*)lf[91]+1 /* (set! s16vector->blob/shared ...) */,t64);
t66=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5013,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t67=C_mutate2((C_word*)lf[92]+1 /* (set! u32vector->blob/shared ...) */,t66);
t68=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5006,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
t69=C_mutate2((C_word*)lf[93]+1 /* (set! s32vector->blob/shared ...) */,t68);
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4999,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t71=C_mutate2((C_word*)lf[94]+1 /* (set! f32vector->blob/shared ...) */,t70);
t72=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4992,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
t73=C_mutate2((C_word*)lf[95]+1 /* (set! f64vector->blob/shared ...) */,t72);
t74=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:544: pack-copy */
f_3380(t74,lf[4],lf[96]);}

/* k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_1900,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[39]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4179,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:236: getter-with-setter */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[32]+1);
av2[4]=lf[156];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_1904,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[40]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:246: getter-with-setter */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[33]+1);
av2[4]=lf[155];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* f64vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3291,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[18],lf[72]);
t4=C_u_i_f64vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3300,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3300(t8,t1,C_fix(0));}

/* f64vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3362,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[18]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a4148 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(9,c,6)))){
C_save_and_reclaim((void *)f_4149,4,av);}
a=C_alloc(9);
t4=C_i_check_structure_2(t2,lf[18],lf[41]);
t5=C_u_i_f64vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4177,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[41]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_a_u_i_f64vector_ref(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[41];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* k4145 in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_4147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4147,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2204 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2206,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[8],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:313: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2174(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2174(2,av2);}}}

/* a4178 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(9,c,6)))){
C_save_and_reclaim((void *)f_4179,4,av);}
a=C_alloc(9);
t4=C_i_check_structure_2(t2,lf[16],lf[40]);
t5=C_u_i_f32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4207,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[40]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_a_u_i_f32vector_ref(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[40];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* k4175 in a4148 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,1)))){
C_save_and_reclaim((void *)f_4177,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_u_i_f64vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3262,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[16],lf[71]);
t4=C_u_i_f32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3271,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li72),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3271(t8,t1,C_fix(0));}

/* k3254 in loop in s32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,1)))){
C_save_and_reclaim((void *)f_3256,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,C_a_u_i_s32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2707 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2709(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2709,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[18],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:382: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2673(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2673(2,av2);}}}

/* u8vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3084,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[4],lf[65]);
t4=C_u_i_u8vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3093,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3093(t8,t1,C_fix(0));}

/* k4115 in read-u8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in ... */
static void C_ccall f_4117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4117,2,av);}
a=C_alloc(3);
t2=C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record2(&a,2,lf[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3283 in loop in f32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3285(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,1)))){
C_save_and_reclaim((void *)f_3285,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,C_a_u_i_f32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2146(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,4)))){
C_save_and_reclaim((void*)f_2146,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[50]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2206,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(1));
/* srfi-4.scm:312: alloc */
f_1917(t20,lf[50],t21,t11);}

/* f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3078,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:451: list->f64vector */
t3=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3072,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:448: list->f32vector */
t3=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* read-u8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_4101(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,3)))){
C_save_and_reclaim((void*)f_4101,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_cdr(t2));
t7=C_i_nullp(t6);
t8=(C_truep(t7)?*((C_word*)lf[148]+1):C_i_car(t6));
t9=C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_cdr(t6));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:669: ##sys#read-string/port */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[151]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[151]+1);
av2[1]=t11;
av2[2]=t4;
av2[3]=t8;
tp(4,av2);}}

/* doloop541 in k2469 in k2501 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_2485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s32vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* loop in f32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3271,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3285,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:480: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* f5013 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f5013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5013,3,av);}
t3=C_i_check_structure_2(t2,lf[12],lf[92]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* loop in u8vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3093,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_u_i_u8vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3108,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:474: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k3666 in k3663 in user-print-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in ... */
static void C_ccall f_3668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3668,2,av);}
a=C_alloc(4);
t2=C_i_caddr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:612: g934 */
t4=t2;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* f5020 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f5020(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5020,3,av);}
t3=C_i_check_structure_2(t2,lf[10],lf[91]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3663 in user-print-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in ... */
static void C_ccall f_3665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3665,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* srfi-4.scm:611: ##sys#print */
t4=*((C_word*)lf[135]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* f5027 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f5027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5027,3,av);}
t3=C_i_check_structure_2(t2,lf[8],lf[90]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3196 in loop in s16vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3198,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* subf32vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3840,5,av);}
/* srfi-4.scm:640: subnvector */
f_3719(t1,t2,lf[16],C_fix(4),t3,t4,lf[143]);}

/* subf64vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3846,5,av);}
/* srfi-4.scm:641: subnvector */
f_3719(t1,t2,lf[18],C_fix(8),t3,t4,lf[144]);}

/* f5006 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f5006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5006,3,av);}
t3=C_i_check_structure_2(t2,lf[14],lf[93]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* subs32vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3834,5,av);}
/* srfi-4.scm:639: subnvector */
f_3719(t1,t2,lf[14],C_fix(4),t3,t4,lf[142]);}

/* list->u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2892,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[12]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2899,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:421: make-u32vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2897 in list->u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2899,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2904,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2904(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* s16vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3174,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[10],lf[68]);
t4=C_u_i_s16vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3183,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3183(t8,t1,C_fix(0));}

/* write-u8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,6)))){
C_save_and_reclaim((void*)f_3852,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[146]+1):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(0):C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_FALSE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_structure_2(t2,lf[4],lf[145]);
t20=C_i_check_port_2(t6,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[145]);
t21=C_u_i_8vector_length(t2);
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3901,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t16,a[6]=t11,a[7]=t21,tmp=(C_word)a,a+=8,tmp);
t23=(C_truep(t16)?C_fixnum_plus(t16,C_fix(1)):C_fixnum_plus(t21,C_fix(1)));
t24=C_i_check_exact_2(t11,lf[145]);
t25=C_fixnum_less_or_equal_p(C_fix(0),t11);
t26=(C_truep(t25)?C_fixnum_lessp(t11,t23):C_SCHEME_FALSE);
if(C_truep(t26)){
t27=C_SCHEME_UNDEFINED;
t28=t22;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t28;
av2[1]=t27;
f_3901(2,av2);}}
else{
t27=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t22;
av2[2]=t27;
av2[3]=lf[145];
av2[4]=t11;
av2[5]=C_fix(0);
av2[6]=t23;
tp(7,av2);}}}

/* k3166 in loop in u16vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3168,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2873 in doloop671 in k2861 in list->s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2875,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2868(t4,((C_word*)t0)[5],t2,t3);}

/* loop in u16vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3153,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_u_i_u16vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:476: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k2370 in k2402 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2372(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2372,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[52]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word)li28),tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(
  f_2386(t3,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3676 in k3666 in k3663 in user-print-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in ... */
static void C_ccall f_3678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3678,2,av);}
/* srfi-4.scm:612: ##sys#print */
t2=*((C_word*)lf[135]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* list->s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2856,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[10]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2863,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:420: make-s16vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* list->s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2928(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2928,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[14]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2935,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:422: make-s32vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2909 in doloop684 in k2897 in list->u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2911,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2904(t4,((C_word*)t0)[5],t2,t3);}

/* k2106 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2108,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[6],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:300: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2076(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2076(2,av2);}}}

/* k3775 in k3751 in subnvector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in ... */
static void C_ccall f_3777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,5)))){
C_save_and_reclaim((void *)f_3777,2,av);}
a=C_alloc(8);
t2=C_fixnum_difference(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_fixnum_times(((C_word*)t0)[4],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:628: ##sys#allocate-vector */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}

/* k1940 in release-number-vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_1942,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=stub367(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* srfi-4.scm:281: ##sys#error */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[44];
av2[3]=lf[45];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* doloop684 in k2897 in list->u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2904(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_2904,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2911,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:421: u32vector-set! */
t7=*((C_word*)lf[26]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:421: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* release-number-vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_1935,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1942,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:279: number-vector? */
t4=*((C_word*)lf[46]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1931 in alloc in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1933,2,av);}
t2=C_string_to_bytevector(t1);
t3=t1;
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4059 in read-u8vector! in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in ... */
static void C_fcall f_4061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,5)))){
C_save_and_reclaim_args((void *)trf_4061,2,t0,t1);}
if(C_truep(t1)){
/* srfi-4.scm:666: ##sys#read-string! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[149]+1));
C_word av2[6];
av2[0]=*((C_word*)lf[149]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
tp(6,av2);}}
else{
t2=C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=C_set_block_item(((C_word*)t0)[3],0,t2);
/* srfi-4.scm:666: ##sys#read-string! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[149]+1));
C_word av2[6];
av2[0]=*((C_word*)lf[149]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
tp(6,av2);}}}

/* loop in s16vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3183,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_u_i_s16vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3198,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:477: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3066,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:445: list->s32vector */
t3=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3060,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:442: list->u32vector */
t3=*((C_word*)lf[61]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3751 in subnvector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in ... */
static void C_ccall f_3753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,6)))){
C_save_and_reclaim((void *)f_3753,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[9];
t6=C_i_check_exact_2(t4,t5);
t7=C_fixnum_less_or_equal_p(C_fix(0),t4);
t8=(C_truep(t7)?C_fixnum_lessp(t4,t3):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=t9;
f_3777(2,av2);}}
else{
t9=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t2;
av2[2]=t9;
av2[3]=t5;
av2[4]=t4;
av2[5]=C_fix(0);
av2[6]=t3;
tp(7,av2);}}}

/* s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3054,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:439: list->s16vector */
t3=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3781 in k3775 in k3751 in subnvector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in ... */
static void C_ccall f_3783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3783,2,av);}
a=C_alloc(3);
t2=C_string_to_bytevector(t1);
t3=C_a_i_record2(&a,2,((C_word*)t0)[2],t1);
t4=C_fixnum_times(((C_word*)t0)[3],((C_word*)t0)[4]);
t5=C_copy_subvector(t1,((C_word*)t0)[5],C_fix(0),t4,((C_word*)t0)[6]);
t6=((C_word*)t0)[7];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* ##sys#check-exact-interval in k1490 */
static void C_fcall f_1494(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,6)))){
C_save_and_reclaim_args((void *)trf_1494,5,t1,t2,t3,t4,t5);}
t6=C_i_check_exact_2(t2,t5);
t7=C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm:52: ##sys#error */
t9=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t9;
av2[1]=t1;
av2[2]=t5;
av2[3]=lf[2];
av2[4]=t2;
av2[5]=t3;
av2[6]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(7,av2);}}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}

/* k1490 */
static void C_ccall f_1492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(57,c,6)))){
C_save_and_reclaim((void *)f_1492,2,av);}
a=C_alloc(57);
t2=C_mutate2(&lf[0] /* (set! ##sys#check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1494,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[3]+1 /* (set! u8vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1509,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[5]+1 /* (set! s8vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1515,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[7]+1 /* (set! u16vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[9]+1 /* (set! s16vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1527,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[11]+1 /* (set! u32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1533,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[13]+1 /* (set! s32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1539,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[15]+1 /* (set! f32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1545,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[17]+1 /* (set! f64vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[19]+1 /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[22]+1 /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[23]+1 /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1632,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[25]+1 /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[26]+1 /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1707,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[30]+1 /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1762,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[32]+1 /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1804,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[33]+1 /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1841,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4359,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:176: getter-with-setter */
t21=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t21;
av2[1]=t19;
av2[2]=t20;
av2[3]=*((C_word*)lf[19]+1);
av2[4]=lf[162];
((C_proc)(void*)(*((C_word*)t21+1)))(5,av2);}}

/* doloop513 in k2370 in k2402 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_2386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u32vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k4385 in a4358 in k1490 */
static void C_ccall f_4387(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4387,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_u8vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3925 in k3915 in k3902 in k3899 in write-u8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in ... */
static void C_ccall f_3927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3927,2,av);}
t2=C_slot(t1,C_fix(1));
/* srfi-4.scm:646: g1047 */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* read-u8vector! in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_4021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +10,c,2)))){
C_save_and_reclaim((void*)f_4021,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+10);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=C_i_nullp(t4);
t7=(C_truep(t6)?*((C_word*)lf[148]+1):C_i_car(t4));
t8=t7;
t9=C_i_nullp(t4);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t11=C_i_nullp(t10);
t12=(C_truep(t11)?C_fix(0):C_i_car(t10));
t13=t12;
t14=C_i_nullp(t10);
t15=(C_truep(t14)?C_SCHEME_END_OF_LIST:C_i_cdr(t10));
t16=C_i_check_port_2(t8,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[147]);
t17=C_i_check_exact_2(t13,lf[147]);
t18=C_i_check_structure_2(t3,lf[4],lf[147]);
t19=(C_truep(((C_word*)t5)[1])?C_i_check_exact_2(((C_word*)t5)[1],lf[147]):C_SCHEME_UNDEFINED);
t20=C_slot(t3,C_fix(1));
t21=t20;
t22=C_block_size(t21);
t23=t22;
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4061,a[2]=t1,a[3]=t5,a[4]=t21,a[5]=t8,a[6]=t13,a[7]=t23,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t5)[1])){
t25=C_fixnum_plus(t13,((C_word*)t5)[1]);
t26=t24;
f_4061(t26,C_fixnum_less_or_equal_p(t25,t23));}
else{
t25=t24;
f_4061(t25,C_SCHEME_FALSE);}}

/* k1770 in k1767 in s32vector-set! in k1490 */
static void C_ccall f_1772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1772,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[30]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_u_i_s32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t2;
av2[2]=t7;
av2[3]=lf[30];
av2[4]=t3;
av2[5]=C_fix(0);
av2[6]=((C_word*)t0)[6];
tp(7,av2);}}}

/* k3915 in k3902 in k3899 in write-u8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in ... */
static void C_fcall f_3917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_3917,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* srfi-4.scm:646: g1047 */
t3=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:655: subu8vector */
t3=*((C_word*)lf[137]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[7];
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* srfi-4.scm:655: subu8vector */
t3=*((C_word*)lf[137]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[7];
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}}

/* k3899 in write-u8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in ... */
static void C_ccall f_3901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,6)))){
C_save_and_reclaim((void *)f_3901,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t4=C_i_check_exact_2(((C_word*)t0)[5],lf[145]);
t5=C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[5]);
t6=(C_truep(t5)?C_fixnum_lessp(((C_word*)t0)[5],t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
f_3904(2,av2);}}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t2;
av2[2]=t7;
av2[3]=lf[145];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
av2[6]=t3;
tp(7,av2);}}}
else{
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_3904(2,av2);}}}

/* k3902 in k3899 in write-u8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in ... */
static void C_ccall f_3904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_3904,2,av);}
a=C_alloc(9);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_slot(t2,C_fix(3));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t6)){
t7=C_i_not(((C_word*)t0)[5]);
t8=t5;
f_3917(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[5],((C_word*)t0)[7])));}
else{
t7=t5;
f_3917(t7,C_SCHEME_FALSE);}}

/* k1794 in k1770 in k1767 in s32vector-set! in k1490 */
static void C_ccall f_1796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1796,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_s32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2789 in list->s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2791,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2796,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2796(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop645 in k2789 in list->s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2796(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_2796,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2803,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:418: s8vector-set! */
t7=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:418: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* ##sys#user-read-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_3593,4,av);}
a=C_alloc(5);
t4=t2;
if(C_truep((C_truep(C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3602,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm:587: read */
t6=*((C_word*)lf[131]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
/* srfi-4.scm:592: old-hook */
t5=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}}

/* list->s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2784(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2784,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[6]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2791,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:418: make-s8vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* u32vector-set! in k1490 */
static void C_ccall f_1707(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_1707,5,av);}
a=C_alloc(7);
t5=C_i_check_structure_2(t2,lf[12],lf[26]);
t6=C_u_i_32vector_length(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1714,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:134: ##sys#check-integer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t7;
av2[2]=t4;
av2[3]=lf[26];
tp(4,av2);}}

/* k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in ... */
static void C_ccall f_3588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(96,c,8)))){
C_save_and_reclaim((void *)f_3588,2,av);}
a=C_alloc(96);
t2=C_mutate2((C_word*)lf[119]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[120]+1);
t4=C_a_i_list(&a,16,lf[121],*((C_word*)lf[56]+1),lf[122],*((C_word*)lf[58]+1),lf[123],*((C_word*)lf[59]+1),lf[124],*((C_word*)lf[60]+1),lf[125],*((C_word*)lf[61]+1),lf[126],*((C_word*)lf[62]+1),lf[127],*((C_word*)lf[63]+1),lf[128],*((C_word*)lf[64]+1));
t5=t4;
t6=C_mutate2((C_word*)lf[120]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3593,a[2]=t5,a[3]=t3,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[134]+1);
t8=C_mutate2((C_word*)lf[134]+1 /* (set! ##sys#user-print-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3653,a[2]=t7,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate2(&lf[136] /* (set! subnvector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3719,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[137]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3804,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[138]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3810,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[139]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3816,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[140]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3822,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[141]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3828,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[142]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3834,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[143]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[144]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3846,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[145]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3852,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[147]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[150]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4101,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:673: register-feature! */
t22=*((C_word*)lf[152]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t22;
av2[1]=t21;
av2[2]=lf[153];
((C_proc)(void*)(*((C_word*)t22+1)))(3,av2);}}

/* k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in ... */
static void C_ccall f_3580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3580,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[117]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:568: unpack-copy */
f_3428(t3,lf[16],C_fix(4),lf[118]);}

/* k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in ... */
static void C_ccall f_3584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3584,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[118]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:569: unpack-copy */
f_3428(t3,lf[18],C_fix(8),lf[119]);}

/* k1703 in s16vector-set! in k1490 */
static void C_ccall f_1705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1705,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_s16vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in ... */
static void C_ccall f_3576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3576,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[116]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:567: unpack-copy */
f_3428(t3,lf[14],C_fix(4),lf[117]);}

/* k1715 in k1712 in u32vector-set! in k1490 */
static void C_ccall f_1717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1717,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[26]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_u_i_u32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t2;
av2[2]=t7;
av2[3]=lf[26];
av2[4]=t3;
av2[5]=C_fix(0);
av2[6]=((C_word*)t0)[6];
tp(7,av2);}}}

/* k1712 in u32vector-set! in k1490 */
static void C_ccall f_1714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_1714,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_negativep(((C_word*)t0)[5]))){
/* srfi-4.scm:136: ##sys#error */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[26];
av2[3]=lf[27];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
if(C_truep(C_fits_in_unsigned_int_p(((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
f_1717(2,av2);}}
else{
/* srfi-4.scm:138: ##sys#error */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[26];
av2[3]=lf[28];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}}

/* k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in ... */
static void C_ccall f_3572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3572,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[115]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:566: unpack-copy */
f_3428(t3,lf[12],C_fix(4),lf[116]);}

/* doloop598 in k2683 in k2671 in k2707 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_2690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_f64vector_set(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* doloop632 in k2753 in list->u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_2760,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2767,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:417: u8vector-set! */
t7=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:417: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in ... */
static void C_ccall f_3568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3568,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[114]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:565: unpack-copy */
f_3428(t3,lf[10],C_fix(2),lf[115]);}

/* k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in ... */
static void C_ccall f_3560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3560,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[112]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:563: unpack-copy */
f_3428(t3,lf[6],C_SCHEME_TRUE,lf[113]);}

/* k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in ... */
static void C_ccall f_3564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3564,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[113]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:564: unpack-copy */
f_3428(t3,lf[8],C_fix(2),lf[114]);}

/* k2683 in k2671 in k2707 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_2685,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li34),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t3;
av2[1]=(
  f_2690(t2,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2753 in list->u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2755,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2760,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2760(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k2765 in doloop632 in k2753 in list->u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2767,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2760(t4,((C_word*)t0)[5],t2,t3);}

/* s16vector-set! in k1490 */
static void C_ccall f_1674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1674,5,av);}
a=C_alloc(6);
t5=C_i_check_structure_2(t2,lf[10],lf[25]);
t6=C_u_i_16vector_length(t2);
t7=C_i_check_exact_2(t4,lf[25]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1705,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[25]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=C_u_i_s16vector_set(t2,t3,t4);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t8;
av2[2]=t13;
av2[3]=lf[25];
av2[4]=t9;
av2[5]=C_fix(0);
av2[6]=t6;
tp(7,av2);}}}

/* a4328 in k1878 in k1490 */
static void C_ccall f_4329(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4329,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[6],lf[35]);
t5=C_u_i_s8vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4357,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[35]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_u_i_s8vector_ref(t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[35];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* k4325 in a4298 in k1882 in k1878 in k1490 */
static void C_ccall f_4327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4327,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_u16vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2671 in k2707 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_2673,2,av);}
a=C_alloc(10);
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=C_i_check_number_2(((C_word*)((C_word*)t0)[2])[1],lf[55]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(((C_word*)((C_word*)t0)[2])[1]))){
t5=t4;
f_2685(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_a_i_fix_to_flo(&a,1,((C_word*)((C_word*)t0)[2])[1]));
t6=t4;
f_2685(t6,t5);}}
else{
t3=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* f32vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3356(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3356,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[16]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1664 in k1640 in u16vector-set! in k1490 */
static void C_ccall f_1666(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1666,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_u16vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* s32vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3350,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[14]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* doloop658 in k2825 in list->u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2832(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_2832,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2839,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:419: u16vector-set! */
t7=*((C_word*)lf[23]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:419: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* k2837 in doloop658 in k2825 in list->u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2839,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2832(t4,((C_word*)t0)[5],t2,t3);}

/* u32vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3344,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[12]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2861 in list->s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2863,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2868,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2868(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop429 in k2083 in k2074 in k2106 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_2090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s8vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* s16vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3338(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3338,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[10]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* doloop671 in k2861 in list->s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_2868,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2875,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:420: s16vector-set! */
t7=*((C_word*)lf[25]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:420: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* u16vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3332,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[8]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1882 in k1878 in k1490 */
static void C_ccall f_1884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_1884,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[35]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4299,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:196: getter-with-setter */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[23]+1);
av2[4]=lf[160];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_1888,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[36]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4269,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:206: getter-with-setter */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[25]+1);
av2[4]=lf[159];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k1878 in k1490 */
static void C_ccall f_1880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_1880,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[34]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4329,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:186: getter-with-setter */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[19]+1);
av2[4]=lf[161];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* a4358 in k1490 */
static void C_ccall f_4359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4359,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[4],lf[34]);
t5=C_u_i_s8vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4387,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[34]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_u_i_u8vector_ref(t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[34];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* s8vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3326,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[6]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4355 in a4328 in k1878 in k1490 */
static void C_ccall f_4357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4357,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_s8vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* u8vector? in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3320(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3320,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[4]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_srfi_2d4_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("srfi_2d4_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_srfi_2d4_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(973))){
C_save(t1);
C_rereclaim2(973*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,163);
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[3]=C_h_intern(&lf[3],15,"u8vector-length");
lf[4]=C_h_intern(&lf[4],8,"u8vector");
lf[5]=C_h_intern(&lf[5],15,"s8vector-length");
lf[6]=C_h_intern(&lf[6],8,"s8vector");
lf[7]=C_h_intern(&lf[7],16,"u16vector-length");
lf[8]=C_h_intern(&lf[8],9,"u16vector");
lf[9]=C_h_intern(&lf[9],16,"s16vector-length");
lf[10]=C_h_intern(&lf[10],9,"s16vector");
lf[11]=C_h_intern(&lf[11],16,"u32vector-length");
lf[12]=C_h_intern(&lf[12],9,"u32vector");
lf[13]=C_h_intern(&lf[13],16,"s32vector-length");
lf[14]=C_h_intern(&lf[14],9,"s32vector");
lf[15]=C_h_intern(&lf[15],16,"f32vector-length");
lf[16]=C_h_intern(&lf[16],9,"f32vector");
lf[17]=C_h_intern(&lf[17],16,"f64vector-length");
lf[18]=C_h_intern(&lf[18],9,"f64vector");
lf[19]=C_h_intern(&lf[19],13,"u8vector-set!");
lf[20]=C_h_intern(&lf[20],14,"\003syserror-hook");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[22]=C_h_intern(&lf[22],13,"s8vector-set!");
lf[23]=C_h_intern(&lf[23],14,"u16vector-set!");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[25]=C_h_intern(&lf[25],14,"s16vector-set!");
lf[26]=C_h_intern(&lf[26],14,"u32vector-set!");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[29]=C_h_intern(&lf[29],17,"\003syscheck-integer");
lf[30]=C_h_intern(&lf[30],14,"s32vector-set!");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[32]=C_h_intern(&lf[32],14,"f32vector-set!");
lf[33]=C_h_intern(&lf[33],14,"f64vector-set!");
lf[34]=C_h_intern(&lf[34],12,"u8vector-ref");
lf[35]=C_h_intern(&lf[35],12,"s8vector-ref");
lf[36]=C_h_intern(&lf[36],13,"u16vector-ref");
lf[37]=C_h_intern(&lf[37],13,"s16vector-ref");
lf[38]=C_h_intern(&lf[38],13,"u32vector-ref");
lf[39]=C_h_intern(&lf[39],13,"s32vector-ref");
lf[40]=C_h_intern(&lf[40],13,"f32vector-ref");
lf[41]=C_h_intern(&lf[41],13,"f64vector-ref");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[43]=C_h_intern(&lf[43],19,"\003sysallocate-vector");
lf[44]=C_h_intern(&lf[44],21,"release-number-vector");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[46]=C_h_intern(&lf[46],14,"number-vector\077");
lf[47]=C_h_intern(&lf[47],13,"make-u8vector");
lf[48]=C_h_intern(&lf[48],14,"set-finalizer!");
lf[49]=C_h_intern(&lf[49],13,"make-s8vector");
lf[50]=C_h_intern(&lf[50],14,"make-u16vector");
lf[51]=C_h_intern(&lf[51],14,"make-s16vector");
lf[52]=C_h_intern(&lf[52],14,"make-u32vector");
lf[53]=C_h_intern(&lf[53],14,"make-s32vector");
lf[54]=C_h_intern(&lf[54],14,"make-f32vector");
lf[55]=C_h_intern(&lf[55],14,"make-f64vector");
lf[56]=C_h_intern(&lf[56],14,"list->u8vector");
lf[57]=C_h_intern(&lf[57],27,"\003syserror-not-a-proper-list");
lf[58]=C_h_intern(&lf[58],14,"list->s8vector");
lf[59]=C_h_intern(&lf[59],15,"list->u16vector");
lf[60]=C_h_intern(&lf[60],15,"list->s16vector");
lf[61]=C_h_intern(&lf[61],15,"list->u32vector");
lf[62]=C_h_intern(&lf[62],15,"list->s32vector");
lf[63]=C_h_intern(&lf[63],15,"list->f32vector");
lf[64]=C_h_intern(&lf[64],15,"list->f64vector");
lf[65]=C_h_intern(&lf[65],14,"u8vector->list");
lf[66]=C_h_intern(&lf[66],14,"s8vector->list");
lf[67]=C_h_intern(&lf[67],15,"u16vector->list");
lf[68]=C_h_intern(&lf[68],15,"s16vector->list");
lf[69]=C_h_intern(&lf[69],15,"u32vector->list");
lf[70]=C_h_intern(&lf[70],15,"s32vector->list");
lf[71]=C_h_intern(&lf[71],15,"f32vector->list");
lf[72]=C_h_intern(&lf[72],15,"f64vector->list");
lf[73]=C_h_intern(&lf[73],9,"u8vector\077");
lf[74]=C_h_intern(&lf[74],9,"s8vector\077");
lf[75]=C_h_intern(&lf[75],10,"u16vector\077");
lf[76]=C_h_intern(&lf[76],10,"s16vector\077");
lf[77]=C_h_intern(&lf[77],10,"u32vector\077");
lf[78]=C_h_intern(&lf[78],10,"s32vector\077");
lf[79]=C_h_intern(&lf[79],10,"f32vector\077");
lf[80]=C_h_intern(&lf[80],10,"f64vector\077");
lf[81]=C_h_intern(&lf[81],18,"\003syssrfi-4-vector\077");
lf[83]=C_h_intern(&lf[83],13,"\003sysmake-blob");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[88]=C_h_intern(&lf[88],21,"u8vector->blob/shared");
lf[89]=C_h_intern(&lf[89],21,"s8vector->blob/shared");
lf[90]=C_h_intern(&lf[90],22,"u16vector->blob/shared");
lf[91]=C_h_intern(&lf[91],22,"s16vector->blob/shared");
lf[92]=C_h_intern(&lf[92],22,"u32vector->blob/shared");
lf[93]=C_h_intern(&lf[93],22,"s32vector->blob/shared");
lf[94]=C_h_intern(&lf[94],22,"f32vector->blob/shared");
lf[95]=C_h_intern(&lf[95],22,"f64vector->blob/shared");
lf[96]=C_h_intern(&lf[96],14,"u8vector->blob");
lf[97]=C_h_intern(&lf[97],14,"s8vector->blob");
lf[98]=C_h_intern(&lf[98],15,"u16vector->blob");
lf[99]=C_h_intern(&lf[99],15,"s16vector->blob");
lf[100]=C_h_intern(&lf[100],15,"u32vector->blob");
lf[101]=C_h_intern(&lf[101],15,"s32vector->blob");
lf[102]=C_h_intern(&lf[102],15,"f32vector->blob");
lf[103]=C_h_intern(&lf[103],15,"f64vector->blob");
lf[104]=C_h_intern(&lf[104],21,"blob->u8vector/shared");
lf[105]=C_h_intern(&lf[105],21,"blob->s8vector/shared");
lf[106]=C_h_intern(&lf[106],22,"blob->u16vector/shared");
lf[107]=C_h_intern(&lf[107],22,"blob->s16vector/shared");
lf[108]=C_h_intern(&lf[108],22,"blob->u32vector/shared");
lf[109]=C_h_intern(&lf[109],22,"blob->s32vector/shared");
lf[110]=C_h_intern(&lf[110],22,"blob->f32vector/shared");
lf[111]=C_h_intern(&lf[111],22,"blob->f64vector/shared");
lf[112]=C_h_intern(&lf[112],14,"blob->u8vector");
lf[113]=C_h_intern(&lf[113],14,"blob->s8vector");
lf[114]=C_h_intern(&lf[114],15,"blob->u16vector");
lf[115]=C_h_intern(&lf[115],15,"blob->s16vector");
lf[116]=C_h_intern(&lf[116],15,"blob->u32vector");
lf[117]=C_h_intern(&lf[117],15,"blob->s32vector");
lf[118]=C_h_intern(&lf[118],15,"blob->f32vector");
lf[119]=C_h_intern(&lf[119],15,"blob->f64vector");
lf[120]=C_h_intern(&lf[120],18,"\003sysuser-read-hook");
lf[121]=C_h_intern(&lf[121],2,"u8");
lf[122]=C_h_intern(&lf[122],2,"s8");
lf[123]=C_h_intern(&lf[123],3,"u16");
lf[124]=C_h_intern(&lf[124],3,"s16");
lf[125]=C_h_intern(&lf[125],3,"u32");
lf[126]=C_h_intern(&lf[126],3,"s32");
lf[127]=C_h_intern(&lf[127],3,"f32");
lf[128]=C_h_intern(&lf[128],3,"f64");
lf[129]=C_h_intern(&lf[129],1,"f");
lf[130]=C_h_intern(&lf[130],1,"F");
lf[131]=C_h_intern(&lf[131],4,"read");
lf[132]=C_h_intern(&lf[132],14,"\003sysread-error");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[134]=C_h_intern(&lf[134],19,"\003sysuser-print-hook");
lf[135]=C_h_intern(&lf[135],9,"\003sysprint");
lf[137]=C_h_intern(&lf[137],11,"subu8vector");
lf[138]=C_h_intern(&lf[138],12,"subu16vector");
lf[139]=C_h_intern(&lf[139],12,"subu32vector");
lf[140]=C_h_intern(&lf[140],11,"subs8vector");
lf[141]=C_h_intern(&lf[141],12,"subs16vector");
lf[142]=C_h_intern(&lf[142],12,"subs32vector");
lf[143]=C_h_intern(&lf[143],12,"subf32vector");
lf[144]=C_h_intern(&lf[144],12,"subf64vector");
lf[145]=C_h_intern(&lf[145],14,"write-u8vector");
lf[146]=C_h_intern(&lf[146],19,"\003sysstandard-output");
lf[147]=C_h_intern(&lf[147],14,"read-u8vector!");
lf[148]=C_h_intern(&lf[148],18,"\003sysstandard-input");
lf[149]=C_h_intern(&lf[149],16,"\003sysread-string!");
lf[150]=C_h_intern(&lf[150],13,"read-u8vector");
lf[151]=C_h_intern(&lf[151],20,"\003sysread-string/port");
lf[152]=C_h_intern(&lf[152],17,"register-feature!");
lf[153]=C_h_intern(&lf[153],6,"srfi-4");
lf[154]=C_h_intern(&lf[154],18,"getter-with-setter");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\023(f64vector-ref v i)");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\023(f32vector-ref v i)");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023(s32vector-ref v i)");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\023(u32vector-ref v i)");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\023(s16vector-ref v i)");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\023(u16vector-ref v i)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\022(s8vector-ref v i)");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\022(u8vector-ref v i)");
C_register_lf2(lf,163,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* subu8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3804,5,av);}
/* srfi-4.scm:634: subnvector */
f_3719(t1,t2,lf[4],C_fix(1),t3,t4,lf[137]);}

/* k2074 in k2106 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_2076,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:304: ##sys#check-exact-interval */
f_1494(t2,((C_word*)t0)[2],C_fix(-128),C_fix(127),lf[49]);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3312 in loop in f64vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,1)))){
C_save_and_reclaim((void *)f_3314,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,C_a_u_i_f64vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4298 in k1882 in k1878 in k1490 */
static void C_ccall f_4299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4299,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[8],lf[36]);
t5=C_u_i_s16vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4327,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[36]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_u_i_u16vector_ref(t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[36];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* k4295 in a4268 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4297,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_s16vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* subs16vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3828,5,av);}
/* srfi-4.scm:638: subnvector */
f_3719(t1,t2,lf[10],C_fix(2),t3,t4,lf[141]);}

/* loop in f64vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3300,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3314,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:481: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_1896,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[38]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4209,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:226: getter-with-setter */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[30]+1);
av2[4]=lf[157];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* subs8vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3822,5,av);}
/* srfi-4.scm:637: subnvector */
f_3719(t1,t2,lf[6],C_fix(1),t3,t4,lf[140]);}

/* k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_1892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_1892,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[37]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:216: getter-with-setter */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[26]+1);
av2[4]=lf[158];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* subu32vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3816,5,av);}
/* srfi-4.scm:636: subnvector */
f_3719(t1,t2,lf[12],C_fix(4),t3,t4,lf[139]);}

/* subu16vector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_3810,5,av);}
/* srfi-4.scm:635: subnvector */
f_3719(t1,t2,lf[8],C_fix(2),t3,t4,lf[138]);}

/* u16vector-length in k1490 */
static void C_ccall f_1521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1521,3,av);}
t3=C_i_check_structure_2(t2,lf[8],lf[7]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_16vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2083 in k2074 in k2106 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2085,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=(
  f_2090(t2,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* s16vector-length in k1490 */
static void C_ccall f_1527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1527,3,av);}
t3=C_i_check_structure_2(t2,lf[10],lf[9]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_16vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* f64vector-set! in k1490 */
static void C_ccall f_1841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1841,5,av);}
a=C_alloc(6);
t5=C_i_check_structure_2(t2,lf[18],lf[33]);
t6=C_u_i_64vector_length(t2);
t7=C_i_check_number_2(t4,lf[33]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1872,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[33]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=t8;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t14;
av2[1]=t13;
f_1872(2,av2);}}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t8;
av2[2]=t13;
av2[3]=lf[33];
av2[4]=t9;
av2[5]=C_fix(0);
av2[6]=t6;
tp(7,av2);}}}

/* f32vector-set! in k1490 */
static void C_ccall f_1804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1804,5,av);}
a=C_alloc(6);
t5=C_i_check_structure_2(t2,lf[16],lf[32]);
t6=C_u_i_32vector_length(t2);
t7=C_i_check_number_2(t4,lf[32]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1835,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[32]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=t8;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t14;
av2[1]=t13;
f_1835(2,av2);}}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t8;
av2[2]=t13;
av2[3]=lf[32];
av2[4]=t9;
av2[5]=C_fix(0);
av2[6]=t6;
tp(7,av2);}}}

/* s32vector-length in k1490 */
static void C_ccall f_1539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1539,3,av);}
t3=C_i_check_structure_2(t2,lf[14],lf[13]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_32vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* u32vector-length in k1490 */
static void C_ccall f_1533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1533,3,av);}
t3=C_i_check_structure_2(t2,lf[12],lf[11]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_32vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1870 in f64vector-set! in k1490 */
static void C_ccall f_1872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,1)))){
C_save_and_reclaim((void *)f_1872,2,av);}
a=C_alloc(4);
if(C_truep(C_blockp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_u_i_f64vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_fix_to_flo(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_u_i_f64vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* doloop485 in k2280 in k2271 in k2303 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_2287(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s16vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k2280 in k2271 in k2303 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2282,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=(
  f_2287(t2,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* g918 in k3600 in user-read-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in ... */
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3621,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_slot(t2,C_fix(1));
t4=C_slot(t3,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3632,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:590: read */
t7=*((C_word*)lf[131]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* f32vector-length in k1490 */
static void C_ccall f_1545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1545,3,av);}
t3=C_i_check_structure_2(t2,lf[16],lf[15]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_32vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2580 in k2568 in k2604 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_2582,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t3;
av2[1]=(
  f_2587(t2,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2271 in k2303 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2273(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_2273,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:330: ##sys#check-exact-interval */
f_1494(t2,((C_word*)t0)[2],C_fix(-32768),C_fix(32767),lf[51]);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k2981 in doloop710 in k2969 in list->f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2983,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2976(t4,((C_word*)t0)[5],t2,t3);}

/* doloop569 in k2580 in k2568 in k2604 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_2587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_f32vector_set(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* f64vector-length in k1490 */
static void C_ccall f_1551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1551,3,av);}
t3=C_i_check_structure_2(t2,lf[18],lf[17]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_64vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* u8vector-set! in k1490 */
static void C_ccall f_1557(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_1557,5,av);}
a=C_alloc(7);
t5=C_i_check_structure_2(t2,lf[4],lf[19]);
t6=C_u_i_8vector_length(t2);
t7=C_i_check_exact_2(t4,lf[19]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1567,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-4.scm:104: ##sys#error */
t9=*((C_word*)lf[1]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[19];
av2[3]=lf[21];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=t8;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=C_SCHEME_UNDEFINED;
f_1567(2,av2);}}}

/* make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2443(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,4)))){
C_save_and_reclaim((void*)f_2443,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[53]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2503,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(2));
/* srfi-4.scm:351: alloc */
f_1917(t20,lf[53],t21,t11);}

/* k2969 in list->f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2971,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2976,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2976(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop710 in k2969 in list->f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2976(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_2976,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2983,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:423: f32vector-set! */
t7=*((C_word*)lf[32]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:423: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* f4992 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f4992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f4992,3,av);}
t3=C_i_check_structure_2(t2,lf[18],lf[95]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* f4999 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f4999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f4999,3,av);}
t3=C_i_check_structure_2(t2,lf[16],lf[94]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##sys#user-print-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_ccall f_3653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(102,c,4)))){
C_save_and_reclaim((void *)f_3653,5,av);}
a=C_alloc(102);
t5=C_slot(t2,C_fix(0));
t6=C_a_i_list(&a,3,lf[4],lf[121],*((C_word*)lf[65]+1));
t7=C_a_i_list(&a,3,lf[6],lf[122],*((C_word*)lf[66]+1));
t8=C_a_i_list(&a,3,lf[8],lf[123],*((C_word*)lf[67]+1));
t9=C_a_i_list(&a,3,lf[10],lf[124],*((C_word*)lf[68]+1));
t10=C_a_i_list(&a,3,lf[12],lf[125],*((C_word*)lf[69]+1));
t11=C_a_i_list(&a,3,lf[14],lf[126],*((C_word*)lf[70]+1));
t12=C_a_i_list(&a,3,lf[16],lf[127],*((C_word*)lf[71]+1));
t13=C_a_i_list(&a,3,lf[18],lf[128],*((C_word*)lf[72]+1));
t14=C_a_i_list(&a,8,t6,t7,t8,t9,t10,t11,t12,t13);
t15=C_u_i_assq(t5,t14);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3665,a[2]=t15,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:610: ##sys#print */
t17=*((C_word*)lf[135]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t17;
av2[1]=t16;
av2[2]=C_make_character(35);
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t17+1)))(5,av2);}}
else{
/* srfi-4.scm:613: old-hook */
t16=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t16;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)C_fast_retrieve_proc(t16))(5,av2);}}}

/* u8vector-length in k1490 */
static void C_ccall f_1509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1509,3,av);}
t3=C_i_check_structure_2(t2,lf[4],lf[3]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_8vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1739 in k1715 in k1712 in u32vector-set! in k1490 */
static void C_ccall f_1741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1741,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_u32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* s8vector-length in k1490 */
static void C_ccall f_1515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1515,3,av);}
t3=C_i_check_structure_2(t2,lf[6],lf[5]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_u_i_8vector_length(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2402 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2404,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[12],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:339: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2372(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2372(2,av2);}}}

/* k4235 in a4208 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,1)))){
C_save_and_reclaim((void *)f_4237,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_u_i_s32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4238 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(9,c,6)))){
C_save_and_reclaim((void *)f_4239,4,av);}
a=C_alloc(9);
t4=C_i_check_structure_2(t2,lf[12],lf[38]);
t5=C_u_i_u32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4267,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[38]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_a_u_i_u32vector_ref(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[38];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* k1767 in s32vector-set! in k1490 */
static void C_ccall f_1769(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_1769,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fits_in_int_p(((C_word*)t0)[5]))){
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_1772(2,av2);}}
else{
/* srfi-4.scm:147: ##sys#error */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[30];
av2[3]=lf[31];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k3600 in user-read-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in ... */
static void C_ccall f_3602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3602,2,av);}
a=C_alloc(4);
t2=C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=C_eqp(t3,lf[129]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[130]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_memq(t3,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[4],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:587: g918 */
t8=t7;
f_3621(t8,((C_word*)t0)[2],t6);}
else{
/* srfi-4.scm:591: ##sys#read-error */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[132]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[132]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[133];
av2[4]=t3;
tp(5,av2);}}}}

/* f_3400 in unpack in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3400,3,av);}
a=C_alloc(8);
t3=C_i_check_bytevector_2(t2,((C_word*)t0)[2]);
t4=C_block_size(t2);
t5=t4;
t6=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3416,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_3416(t8,t6);}
else{
t8=C_fixnum_modulo(t5,((C_word*)t0)[3]);
t9=t7;
f_3416(t9,C_eqp(C_fix(0),t8));}}

/* s32vector-set! in k1490 */
static void C_ccall f_1762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_1762,5,av);}
a=C_alloc(7);
t5=C_i_check_structure_2(t2,lf[14],lf[30]);
t6=C_u_i_32vector_length(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1769,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:145: ##sys#check-integer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t7;
av2[2]=t4;
av2[3]=lf[30];
tp(4,av2);}}

/* a4268 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4269,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[10],lf[37]);
t5=C_u_i_s16vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4297,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[37]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_u_i_s16vector_ref(t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[37];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* k3630 in g918 in k3600 in user-read-hook in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in ... */
static void C_ccall f_3632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3632,2,av);}
/* srfi-4.scm:590: g921 */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* list->u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2748,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[4]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:417: make-u8vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k4265 in a4238 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,1)))){
C_save_and_reclaim((void *)f_4267,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_u_i_u32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3414 */
static void C_fcall f_3416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,6)))){
C_save_and_reclaim_args((void *)trf_3416,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_record2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* srfi-4.scm:521: ##sys#error */
t2=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[5];
av2[3]=lf[85];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[6];
av2[6]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}}

/* a4208 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(9,c,6)))){
C_save_and_reclaim((void *)f_4209,4,av);}
a=C_alloc(9);
t4=C_i_check_structure_2(t2,lf[14],lf[39]);
t5=C_u_i_s32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[39]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_a_u_i_s32vector_ref(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t6;
av2[2]=t11;
av2[3]=lf[39];
av2[4]=t7;
av2[5]=C_fix(0);
av2[6]=t5;
tp(7,av2);}}}

/* k4205 in a4178 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_4207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,1)))){
C_save_and_reclaim((void *)f_4207,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_u_i_f32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3447 in k3438 */
static void C_fcall f_3449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,6)))){
C_save_and_reclaim_args((void *)trf_3449,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_copy_block(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_record2(&a,2,((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* srfi-4.scm:533: ##sys#error */
t2=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[6];
av2[3]=lf[87];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[7];
av2[6]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}}

/* k3438 */
static void C_ccall f_3440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_3440,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_3449(t5,t3);}
else{
t5=C_fixnum_modulo(((C_word*)t0)[7],((C_word*)t0)[2]);
t6=t4;
f_3449(t6,C_eqp(C_fix(0),t5));}}

/* f_3430 in unpack-copy in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3430,3,av);}
a=C_alloc(8);
t3=C_i_check_bytevector_2(t2,((C_word*)t0)[2]);
t4=C_block_size(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:527: ##sys#make-blob */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[83]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[83]+1);
av2[1]=t6;
av2[2]=t5;
tp(3,av2);}}

/* k2604 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2606(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2606,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[16],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:365: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2570(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2570(2,av2);}}}

/* loop in u32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3213,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3227,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:478: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3225 in loop in u32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,1)))){
C_save_and_reclaim((void *)f_3227,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,C_a_u_i_u32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in s32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3242,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3256,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:479: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* u16vector-set! in k1490 */
static void C_ccall f_1632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_1632,5,av);}
a=C_alloc(7);
t5=C_i_check_structure_2(t2,lf[8],lf[23]);
t6=C_u_i_16vector_length(t2);
t7=C_i_check_exact_2(t4,lf[23]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1642,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-4.scm:120: ##sys#error */
t9=*((C_word*)lf[1]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[23];
av2[3]=lf[24];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=t8;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=C_SCHEME_UNDEFINED;
f_1642(2,av2);}}}

/* k1628 in s8vector-set! in k1490 */
static void C_ccall f_1630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1630,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_s8vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2568 in k2604 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_2570,2,av);}
a=C_alloc(10);
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=C_i_check_number_2(((C_word*)((C_word*)t0)[2])[1],lf[54]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(((C_word*)((C_word*)t0)[2])[1]))){
t5=t4;
f_2582(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_a_i_fix_to_flo(&a,1,((C_word*)((C_word*)t0)[2])[1]));
t6=t4;
f_2582(t6,t5);}}
else{
t3=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* doloop457 in k2181 in k2172 in k2204 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_2188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u16vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k2181 in k2172 in k2204 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2183,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=(
  f_2188(t2,C_fix(0))
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,4)))){
C_save_and_reclaim((void*)f_2344,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[52]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2404,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(2));
/* srfi-4.scm:338: alloc */
f_1917(t20,lf[52],t21,t11);}

/* s32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3233,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[14],lf[70]);
t4=C_u_i_s32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3242,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li70),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3242(t8,t1,C_fix(0));}

/* k1640 in u16vector-set! in k1490 */
static void C_ccall f_1642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1642,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[23]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_u_i_u16vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t2;
av2[2]=t7;
av2[3]=lf[23];
av2[4]=t3;
av2[5]=C_fix(0);
av2[6]=((C_word*)t0)[6];
tp(7,av2);}}}

/* k2172 in k2204 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_2174,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:317: ##sys#check-exact-interval */
f_1494(t2,((C_word*)t0)[2],C_fix(0),C_fix(65535),lf[50]);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k1565 in u8vector-set! in k1490 */
static void C_ccall f_1567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1567,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[19]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_u_i_u8vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t2;
av2[2]=t7;
av2[3]=lf[19];
av2[4]=t3;
av2[5]=C_fix(0);
av2[6]=((C_word*)t0)[6];
tp(7,av2);}}}

/* unpack-copy in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3428(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3428,4,t1,t2,t3,t4);}
a=C_alloc(6);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3430,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word)li88),tmp=(C_word)a,a+=6,tmp);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1589 in k1565 in u8vector-set! in k1490 */
static void C_ccall f_1591(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1591,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_u_i_u8vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* s8vector-set! in k1490 */
static void C_ccall f_1599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_1599,5,av);}
a=C_alloc(6);
t5=C_i_check_structure_2(t2,lf[6],lf[22]);
t6=C_u_i_8vector_length(t2);
t7=C_i_check_exact_2(t4,lf[22]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1630,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[22]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=C_u_i_s8vector_set(t2,t3,t4);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t8;
av2[2]=t13;
av2[3]=lf[22];
av2[4]=t9;
av2[5]=C_fix(0);
av2[6]=t6;
tp(7,av2);}}}

/* make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +10,c,4)))){
C_save_and_reclaim((void*)f_2645,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+10);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_TRUE:C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=C_i_check_exact_2(t2,lf[55]);
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2709,a[2]=t7,a[3]=t2,a[4]=t1,a[5]=t12,a[6]=t17,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=C_fixnum_shift_left(t2,C_fix(3));
/* srfi-4.scm:381: alloc */
f_1917(t21,lf[55],t22,t12);}

/* k3005 in list->f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_3007,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3012,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3012(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* list->f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3000,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[18]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3007,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:424: make-f64vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2303 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2305,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[10],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:326: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2273(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2273(2,av2);}}}

/* k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in ... */
static void C_ccall f_3556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3556,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[111]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:562: unpack-copy */
f_3428(t3,lf[4],C_SCHEME_TRUE,lf[112]);}

/* k1833 in f32vector-set! in k1490 */
static void C_ccall f_1835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,1)))){
C_save_and_reclaim((void *)f_1835,2,av);}
a=C_alloc(4);
if(C_truep(C_blockp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_u_i_f32vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_fix_to_flo(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_u_i_f32vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in ... */
static void C_ccall f_3552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3552,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[110]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:560: unpack */
f_3398(t3,lf[18],C_fix(8),lf[111]);}

/* u32vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3204,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[12],lf[69]);
t4=C_u_i_u32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3213,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3213(t8,t1,C_fix(0));}

/* k3136 in loop in s8vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3138,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in ... */
static void C_ccall f_3548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3548,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[109]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:559: unpack */
f_3398(t3,lf[16],C_fix(4),lf[110]);}

/* k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 in ... */
static void C_ccall f_3544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3544,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[108]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:558: unpack */
f_3398(t3,lf[14],C_fix(4),lf[109]);}

/* k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3540,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[107]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:557: unpack */
f_3398(t3,lf[12],C_fix(4),lf[108]);}

/* k3017 in doloop723 in k3005 in list->f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3019,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3012(t4,((C_word*)t0)[5],t2,t3);}

/* k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3536,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[106]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:556: unpack */
f_3398(t3,lf[10],C_fix(2),lf[107]);}

/* doloop723 in k3005 in list->f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3012(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_3012,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3019,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:424: f64vector-set! */
t7=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:424: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* loop in s8vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_3123(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3123,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_u_i_s8vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3138,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:475: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3532(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3532,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[105]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:555: unpack */
f_3398(t3,lf[8],C_fix(2),lf[106]);}

/* u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3048,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:436: list->u16vector */
t3=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* s8vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3114,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[6],lf[66]);
t4=C_u_i_s8vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3123,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3123(t8,t1,C_fix(0));}

/* k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3528,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[104]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:554: unpack */
f_3398(t3,lf[6],C_SCHEME_TRUE,lf[105]);}

/* k3522 in k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3524(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3524,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[103]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:553: unpack */
f_3398(t3,lf[4],C_SCHEME_TRUE,lf[104]);}

/* s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3042,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:433: list->s8vector */
t3=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3518 in k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3520,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[102]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:551: pack-copy */
f_3380(t3,lf[18],lf[103]);}

/* u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3036(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_3036,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
/* srfi-4.scm:430: list->u8vector */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3514 in k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3516,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[101]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:550: pack-copy */
f_3380(t3,lf[16],lf[102]);}

/* k3510 in k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3512,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[100]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:549: pack-copy */
f_3380(t3,lf[14],lf[101]);}

/* k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3504,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[98]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:547: pack-copy */
f_3380(t3,lf[10],lf[99]);}

/* k3506 in k3502 in k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3508,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[99]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:548: pack-copy */
f_3380(t3,lf[12],lf[100]);}

/* k3498 in k3494 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3500,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[97]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:546: pack-copy */
f_3380(t3,lf[8],lf[98]);}

/* k2501 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2503,2,av);}
a=C_alloc(9);
t2=C_a_i_record2(&a,2,lf[14],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:352: set-finalizer! */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2471(2,av2);}}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2471(2,av2);}}}

/* u16vector->list in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_3144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3144,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[8],lf[67]);
t4=C_u_i_u16vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3153,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3153(t8,t1,C_fix(0));}

/* list->f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2964,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[16]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2971,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:423: make-f32vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2825 in list->u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2827,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2832,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2832(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* list->u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2820(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2820,3,av);}
a=C_alloc(4);
t3=C_i_check_list_2(t2,lf[8]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2827,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:419: make-u16vector */
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,4)))){
C_save_and_reclaim((void*)f_2245,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[51]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2305,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(1));
/* srfi-4.scm:325: alloc */
f_1917(t20,lf[51],t21,t11);}

/* k2945 in doloop697 in k2933 in list->s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2947,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2940(t4,((C_word*)t0)[5],t2,t3);}

/* subnvector in k3586 in k3582 in k3578 in k3574 in k3570 in k3566 in k3562 in k3558 in k3554 in k3550 in k3546 in k3542 in k3538 in k3534 in k3530 in k3526 in k3522 in k3518 in k3514 in k3510 in k3506 in ... */
static void C_fcall f_3719(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,6)))){
C_save_and_reclaim_args((void *)trf_3719,7,t1,t2,t3,t4,t5,t6,t7);}
a=C_alloc(10);
t8=C_i_check_structure_2(t2,t3,t7);
t9=C_slot(t2,C_fix(1));
t10=t9;
t11=C_block_size(t10);
t12=C_u_fixnum_divide(t11,t4);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3753,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t10,a[7]=t1,a[8]=t12,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t14=C_fixnum_plus(t12,C_fix(1));
t15=t5;
t16=t7;
t17=C_i_check_exact_2(t15,t16);
t18=C_fixnum_less_or_equal_p(C_fix(0),t15);
t19=(C_truep(t18)?C_fixnum_lessp(t15,t14):C_SCHEME_FALSE);
if(C_truep(t19)){
t20=C_SCHEME_UNDEFINED;
t21=t13;{
C_word av2[2];
av2[0]=t21;
av2[1]=t20;
f_3753(2,av2);}}
else{
t20=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:57: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[20]+1));
C_word av2[7];
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t13;
av2[2]=t20;
av2[3]=t16;
av2[4]=t15;
av2[5]=C_fix(0);
av2[6]=t14;
tp(7,av2);}}}

/* doloop697 in k2933 in list->s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_fcall f_2940(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_2940,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2947,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:422: s32vector-set! */
t7=*((C_word*)lf[30]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* srfi-4.scm:422: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}}

/* doloop401 in k1985 in k1976 in k2008 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static C_word C_fcall f_1992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u8vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k2801 in doloop645 in k2789 in list->s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2803,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2796(t4,((C_word*)t0)[5],t2,t3);}

/* make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +10,c,4)))){
C_save_and_reclaim((void*)f_2542,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+10);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_TRUE:C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=C_i_check_exact_2(t2,lf[54]);
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2606,a[2]=t7,a[3]=t2,a[4]=t1,a[5]=t12,a[6]=t17,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=C_fixnum_shift_left(t2,C_fix(2));
/* srfi-4.scm:364: alloc */
f_1917(t21,lf[54],t22,t12);}

/* k2933 in list->s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1490 */
static void C_ccall f_2935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2935,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2940,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2940(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[245] = {
{"f_3108:srfi_2d4_2escm",(void*)f_3108},
{"f_3496:srfi_2d4_2escm",(void*)f_3496},
{"f_1950:srfi_2d4_2escm",(void*)f_1950},
{"f_2010:srfi_2d4_2escm",(void*)f_2010},
{"f_1987:srfi_2d4_2escm",(void*)f_1987},
{"f5034:srfi_2d4_2escm",(void*)f5034},
{"f_1917:srfi_2d4_2escm",(void*)f_1917},
{"f_1915:srfi_2d4_2escm",(void*)f_1915},
{"f_2048:srfi_2d4_2escm",(void*)f_2048},
{"f_1978:srfi_2d4_2escm",(void*)f_1978},
{"f5041:srfi_2d4_2escm",(void*)f5041},
{"f_3398:srfi_2d4_2escm",(void*)f_3398},
{"f_3392:srfi_2d4_2escm",(void*)f_3392},
{"f_3380:srfi_2d4_2escm",(void*)f_3380},
{"f_3382:srfi_2d4_2escm",(void*)f_3382},
{"f_2471:srfi_2d4_2escm",(void*)f_2471},
{"f_1908:srfi_2d4_2escm",(void*)f_1908},
{"f_1900:srfi_2d4_2escm",(void*)f_1900},
{"f_1904:srfi_2d4_2escm",(void*)f_1904},
{"f_3291:srfi_2d4_2escm",(void*)f_3291},
{"f_3362:srfi_2d4_2escm",(void*)f_3362},
{"f_4149:srfi_2d4_2escm",(void*)f_4149},
{"f_4147:srfi_2d4_2escm",(void*)f_4147},
{"f_2206:srfi_2d4_2escm",(void*)f_2206},
{"f_4179:srfi_2d4_2escm",(void*)f_4179},
{"f_4177:srfi_2d4_2escm",(void*)f_4177},
{"f_3262:srfi_2d4_2escm",(void*)f_3262},
{"f_3256:srfi_2d4_2escm",(void*)f_3256},
{"f_2709:srfi_2d4_2escm",(void*)f_2709},
{"f_3084:srfi_2d4_2escm",(void*)f_3084},
{"f_4117:srfi_2d4_2escm",(void*)f_4117},
{"f_3285:srfi_2d4_2escm",(void*)f_3285},
{"f_2146:srfi_2d4_2escm",(void*)f_2146},
{"f_3078:srfi_2d4_2escm",(void*)f_3078},
{"f_3072:srfi_2d4_2escm",(void*)f_3072},
{"f_4101:srfi_2d4_2escm",(void*)f_4101},
{"f_2485:srfi_2d4_2escm",(void*)f_2485},
{"f_3271:srfi_2d4_2escm",(void*)f_3271},
{"f5013:srfi_2d4_2escm",(void*)f5013},
{"f_3093:srfi_2d4_2escm",(void*)f_3093},
{"f_3668:srfi_2d4_2escm",(void*)f_3668},
{"f5020:srfi_2d4_2escm",(void*)f5020},
{"f_3665:srfi_2d4_2escm",(void*)f_3665},
{"f5027:srfi_2d4_2escm",(void*)f5027},
{"f_3198:srfi_2d4_2escm",(void*)f_3198},
{"f_3840:srfi_2d4_2escm",(void*)f_3840},
{"f_3846:srfi_2d4_2escm",(void*)f_3846},
{"f5006:srfi_2d4_2escm",(void*)f5006},
{"f_3834:srfi_2d4_2escm",(void*)f_3834},
{"f_2892:srfi_2d4_2escm",(void*)f_2892},
{"f_2899:srfi_2d4_2escm",(void*)f_2899},
{"f_3174:srfi_2d4_2escm",(void*)f_3174},
{"f_3852:srfi_2d4_2escm",(void*)f_3852},
{"f_3168:srfi_2d4_2escm",(void*)f_3168},
{"f_2875:srfi_2d4_2escm",(void*)f_2875},
{"f_3153:srfi_2d4_2escm",(void*)f_3153},
{"f_2372:srfi_2d4_2escm",(void*)f_2372},
{"f_3678:srfi_2d4_2escm",(void*)f_3678},
{"f_2856:srfi_2d4_2escm",(void*)f_2856},
{"f_2928:srfi_2d4_2escm",(void*)f_2928},
{"f_2911:srfi_2d4_2escm",(void*)f_2911},
{"f_2108:srfi_2d4_2escm",(void*)f_2108},
{"f_3777:srfi_2d4_2escm",(void*)f_3777},
{"f_1942:srfi_2d4_2escm",(void*)f_1942},
{"f_2904:srfi_2d4_2escm",(void*)f_2904},
{"f_1935:srfi_2d4_2escm",(void*)f_1935},
{"f_1933:srfi_2d4_2escm",(void*)f_1933},
{"f_4061:srfi_2d4_2escm",(void*)f_4061},
{"f_3183:srfi_2d4_2escm",(void*)f_3183},
{"f_3066:srfi_2d4_2escm",(void*)f_3066},
{"f_3060:srfi_2d4_2escm",(void*)f_3060},
{"f_3753:srfi_2d4_2escm",(void*)f_3753},
{"f_3054:srfi_2d4_2escm",(void*)f_3054},
{"f_3783:srfi_2d4_2escm",(void*)f_3783},
{"f_1494:srfi_2d4_2escm",(void*)f_1494},
{"f_1492:srfi_2d4_2escm",(void*)f_1492},
{"f_2386:srfi_2d4_2escm",(void*)f_2386},
{"f_4387:srfi_2d4_2escm",(void*)f_4387},
{"f_3927:srfi_2d4_2escm",(void*)f_3927},
{"f_4021:srfi_2d4_2escm",(void*)f_4021},
{"f_1772:srfi_2d4_2escm",(void*)f_1772},
{"f_3917:srfi_2d4_2escm",(void*)f_3917},
{"f_3901:srfi_2d4_2escm",(void*)f_3901},
{"f_3904:srfi_2d4_2escm",(void*)f_3904},
{"f_1796:srfi_2d4_2escm",(void*)f_1796},
{"f_2791:srfi_2d4_2escm",(void*)f_2791},
{"f_2796:srfi_2d4_2escm",(void*)f_2796},
{"f_3593:srfi_2d4_2escm",(void*)f_3593},
{"f_2784:srfi_2d4_2escm",(void*)f_2784},
{"f_1707:srfi_2d4_2escm",(void*)f_1707},
{"f_3588:srfi_2d4_2escm",(void*)f_3588},
{"f_3580:srfi_2d4_2escm",(void*)f_3580},
{"f_3584:srfi_2d4_2escm",(void*)f_3584},
{"f_1705:srfi_2d4_2escm",(void*)f_1705},
{"f_3576:srfi_2d4_2escm",(void*)f_3576},
{"f_1717:srfi_2d4_2escm",(void*)f_1717},
{"f_1714:srfi_2d4_2escm",(void*)f_1714},
{"f_3572:srfi_2d4_2escm",(void*)f_3572},
{"f_2690:srfi_2d4_2escm",(void*)f_2690},
{"f_2760:srfi_2d4_2escm",(void*)f_2760},
{"f_3568:srfi_2d4_2escm",(void*)f_3568},
{"f_3560:srfi_2d4_2escm",(void*)f_3560},
{"f_3564:srfi_2d4_2escm",(void*)f_3564},
{"f_2685:srfi_2d4_2escm",(void*)f_2685},
{"f_2755:srfi_2d4_2escm",(void*)f_2755},
{"f_2767:srfi_2d4_2escm",(void*)f_2767},
{"f_1674:srfi_2d4_2escm",(void*)f_1674},
{"f_4329:srfi_2d4_2escm",(void*)f_4329},
{"f_4327:srfi_2d4_2escm",(void*)f_4327},
{"f_2673:srfi_2d4_2escm",(void*)f_2673},
{"f_3356:srfi_2d4_2escm",(void*)f_3356},
{"f_1666:srfi_2d4_2escm",(void*)f_1666},
{"f_3350:srfi_2d4_2escm",(void*)f_3350},
{"f_2832:srfi_2d4_2escm",(void*)f_2832},
{"f_2839:srfi_2d4_2escm",(void*)f_2839},
{"f_3344:srfi_2d4_2escm",(void*)f_3344},
{"f_2863:srfi_2d4_2escm",(void*)f_2863},
{"f_2090:srfi_2d4_2escm",(void*)f_2090},
{"f_3338:srfi_2d4_2escm",(void*)f_3338},
{"f_2868:srfi_2d4_2escm",(void*)f_2868},
{"f_3332:srfi_2d4_2escm",(void*)f_3332},
{"f_1884:srfi_2d4_2escm",(void*)f_1884},
{"f_1888:srfi_2d4_2escm",(void*)f_1888},
{"f_1880:srfi_2d4_2escm",(void*)f_1880},
{"f_4359:srfi_2d4_2escm",(void*)f_4359},
{"f_3326:srfi_2d4_2escm",(void*)f_3326},
{"f_4357:srfi_2d4_2escm",(void*)f_4357},
{"f_3320:srfi_2d4_2escm",(void*)f_3320},
{"toplevel:srfi_2d4_2escm",(void*)C_srfi_2d4_toplevel},
{"f_3804:srfi_2d4_2escm",(void*)f_3804},
{"f_2076:srfi_2d4_2escm",(void*)f_2076},
{"f_3314:srfi_2d4_2escm",(void*)f_3314},
{"f_4299:srfi_2d4_2escm",(void*)f_4299},
{"f_4297:srfi_2d4_2escm",(void*)f_4297},
{"f_3828:srfi_2d4_2escm",(void*)f_3828},
{"f_3300:srfi_2d4_2escm",(void*)f_3300},
{"f_1896:srfi_2d4_2escm",(void*)f_1896},
{"f_3822:srfi_2d4_2escm",(void*)f_3822},
{"f_1892:srfi_2d4_2escm",(void*)f_1892},
{"f_3816:srfi_2d4_2escm",(void*)f_3816},
{"f_3810:srfi_2d4_2escm",(void*)f_3810},
{"f_1521:srfi_2d4_2escm",(void*)f_1521},
{"f_2085:srfi_2d4_2escm",(void*)f_2085},
{"f_1527:srfi_2d4_2escm",(void*)f_1527},
{"f_1841:srfi_2d4_2escm",(void*)f_1841},
{"f_1804:srfi_2d4_2escm",(void*)f_1804},
{"f_1539:srfi_2d4_2escm",(void*)f_1539},
{"f_1533:srfi_2d4_2escm",(void*)f_1533},
{"f_1872:srfi_2d4_2escm",(void*)f_1872},
{"f_2287:srfi_2d4_2escm",(void*)f_2287},
{"f_2282:srfi_2d4_2escm",(void*)f_2282},
{"f_3621:srfi_2d4_2escm",(void*)f_3621},
{"f_1545:srfi_2d4_2escm",(void*)f_1545},
{"f_2582:srfi_2d4_2escm",(void*)f_2582},
{"f_2273:srfi_2d4_2escm",(void*)f_2273},
{"f_2983:srfi_2d4_2escm",(void*)f_2983},
{"f_2587:srfi_2d4_2escm",(void*)f_2587},
{"f_1551:srfi_2d4_2escm",(void*)f_1551},
{"f_1557:srfi_2d4_2escm",(void*)f_1557},
{"f_2443:srfi_2d4_2escm",(void*)f_2443},
{"f_2971:srfi_2d4_2escm",(void*)f_2971},
{"f_2976:srfi_2d4_2escm",(void*)f_2976},
{"f4992:srfi_2d4_2escm",(void*)f4992},
{"f4999:srfi_2d4_2escm",(void*)f4999},
{"f_3653:srfi_2d4_2escm",(void*)f_3653},
{"f_1509:srfi_2d4_2escm",(void*)f_1509},
{"f_1741:srfi_2d4_2escm",(void*)f_1741},
{"f_1515:srfi_2d4_2escm",(void*)f_1515},
{"f_2404:srfi_2d4_2escm",(void*)f_2404},
{"f_4237:srfi_2d4_2escm",(void*)f_4237},
{"f_4239:srfi_2d4_2escm",(void*)f_4239},
{"f_1769:srfi_2d4_2escm",(void*)f_1769},
{"f_3602:srfi_2d4_2escm",(void*)f_3602},
{"f_3400:srfi_2d4_2escm",(void*)f_3400},
{"f_1762:srfi_2d4_2escm",(void*)f_1762},
{"f_4269:srfi_2d4_2escm",(void*)f_4269},
{"f_3632:srfi_2d4_2escm",(void*)f_3632},
{"f_2748:srfi_2d4_2escm",(void*)f_2748},
{"f_4267:srfi_2d4_2escm",(void*)f_4267},
{"f_3416:srfi_2d4_2escm",(void*)f_3416},
{"f_4209:srfi_2d4_2escm",(void*)f_4209},
{"f_4207:srfi_2d4_2escm",(void*)f_4207},
{"f_3449:srfi_2d4_2escm",(void*)f_3449},
{"f_3440:srfi_2d4_2escm",(void*)f_3440},
{"f_3430:srfi_2d4_2escm",(void*)f_3430},
{"f_2606:srfi_2d4_2escm",(void*)f_2606},
{"f_3213:srfi_2d4_2escm",(void*)f_3213},
{"f_3227:srfi_2d4_2escm",(void*)f_3227},
{"f_3242:srfi_2d4_2escm",(void*)f_3242},
{"f_1632:srfi_2d4_2escm",(void*)f_1632},
{"f_1630:srfi_2d4_2escm",(void*)f_1630},
{"f_2570:srfi_2d4_2escm",(void*)f_2570},
{"f_2188:srfi_2d4_2escm",(void*)f_2188},
{"f_2183:srfi_2d4_2escm",(void*)f_2183},
{"f_2344:srfi_2d4_2escm",(void*)f_2344},
{"f_3233:srfi_2d4_2escm",(void*)f_3233},
{"f_1642:srfi_2d4_2escm",(void*)f_1642},
{"f_2174:srfi_2d4_2escm",(void*)f_2174},
{"f_1567:srfi_2d4_2escm",(void*)f_1567},
{"f_3428:srfi_2d4_2escm",(void*)f_3428},
{"f_1591:srfi_2d4_2escm",(void*)f_1591},
{"f_1599:srfi_2d4_2escm",(void*)f_1599},
{"f_2645:srfi_2d4_2escm",(void*)f_2645},
{"f_3007:srfi_2d4_2escm",(void*)f_3007},
{"f_3000:srfi_2d4_2escm",(void*)f_3000},
{"f_2305:srfi_2d4_2escm",(void*)f_2305},
{"f_3556:srfi_2d4_2escm",(void*)f_3556},
{"f_1835:srfi_2d4_2escm",(void*)f_1835},
{"f_3552:srfi_2d4_2escm",(void*)f_3552},
{"f_3204:srfi_2d4_2escm",(void*)f_3204},
{"f_3138:srfi_2d4_2escm",(void*)f_3138},
{"f_3548:srfi_2d4_2escm",(void*)f_3548},
{"f_3544:srfi_2d4_2escm",(void*)f_3544},
{"f_3540:srfi_2d4_2escm",(void*)f_3540},
{"f_3019:srfi_2d4_2escm",(void*)f_3019},
{"f_3536:srfi_2d4_2escm",(void*)f_3536},
{"f_3012:srfi_2d4_2escm",(void*)f_3012},
{"f_3123:srfi_2d4_2escm",(void*)f_3123},
{"f_3532:srfi_2d4_2escm",(void*)f_3532},
{"f_3048:srfi_2d4_2escm",(void*)f_3048},
{"f_3114:srfi_2d4_2escm",(void*)f_3114},
{"f_3528:srfi_2d4_2escm",(void*)f_3528},
{"f_3524:srfi_2d4_2escm",(void*)f_3524},
{"f_3042:srfi_2d4_2escm",(void*)f_3042},
{"f_3520:srfi_2d4_2escm",(void*)f_3520},
{"f_3036:srfi_2d4_2escm",(void*)f_3036},
{"f_3516:srfi_2d4_2escm",(void*)f_3516},
{"f_3512:srfi_2d4_2escm",(void*)f_3512},
{"f_3504:srfi_2d4_2escm",(void*)f_3504},
{"f_3508:srfi_2d4_2escm",(void*)f_3508},
{"f_3500:srfi_2d4_2escm",(void*)f_3500},
{"f_2503:srfi_2d4_2escm",(void*)f_2503},
{"f_3144:srfi_2d4_2escm",(void*)f_3144},
{"f_2964:srfi_2d4_2escm",(void*)f_2964},
{"f_2827:srfi_2d4_2escm",(void*)f_2827},
{"f_2820:srfi_2d4_2escm",(void*)f_2820},
{"f_2245:srfi_2d4_2escm",(void*)f_2245},
{"f_2947:srfi_2d4_2escm",(void*)f_2947},
{"f_3719:srfi_2d4_2escm",(void*)f_3719},
{"f_2940:srfi_2d4_2escm",(void*)f_2940},
{"f_1992:srfi_2d4_2escm",(void*)f_1992},
{"f_2803:srfi_2d4_2escm",(void*)f_2803},
{"f_2542:srfi_2d4_2escm",(void*)f_2542},
{"f_2935:srfi_2d4_2escm",(void*)f_2935},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|eliminated procedure checks: 105 
o|specializations:
o|  1 (##sys#check-input-port * * *)
o|  1 (##sys#check-output-port * * *)
o|  1 (assq * (list-of pair))
o|  1 (memq * list)
(o e)|safe calls: 418 
(o e)|assignments to immediate values: 1 
o|safe globals: (f64vector-set! f32vector-set! s32vector-set! u32vector-set! s16vector-set! u16vector-set! s8vector-set! u8vector-set! f64vector-length f32vector-length s32vector-length u32vector-length s16vector-length u16vector-length s8vector-length u8vector-length ##sys#check-exact-interval) 
o|Removed `not' forms: 9 
o|inlining procedure: k1499 
o|inlining procedure: k1499 
o|contracted procedure: "(srfi-4.scm:105) g101102" 
o|inlining procedure: k1573 
o|inlining procedure: k1573 
o|contracted procedure: "(srfi-4.scm:112) g119120" 
o|inlining procedure: k1612 
o|inlining procedure: k1612 
o|contracted procedure: "(srfi-4.scm:121) g136137" 
o|inlining procedure: k1648 
o|inlining procedure: k1648 
o|contracted procedure: "(srfi-4.scm:128) g154155" 
o|inlining procedure: k1687 
o|inlining procedure: k1687 
o|contracted procedure: "(srfi-4.scm:139) g175176" 
o|inlining procedure: k1723 
o|inlining procedure: k1723 
o|contracted procedure: k1751 
o|inlining procedure: k1748 
o|inlining procedure: k1748 
o|contracted procedure: "(srfi-4.scm:148) g193194" 
o|inlining procedure: k1778 
o|inlining procedure: k1778 
o|inlining procedure: k1837 
o|inlining procedure: k1837 
o|contracted procedure: "(srfi-4.scm:155) g211212" 
o|inlining procedure: k1817 
o|inlining procedure: k1817 
o|inlining procedure: k1874 
o|inlining procedure: k1874 
o|contracted procedure: "(srfi-4.scm:167) g228229" 
o|inlining procedure: k1854 
o|inlining procedure: k1854 
o|inlining procedure: k1919 
o|contracted procedure: "(srfi-4.scm:270) ext-alloc360" 
o|inlining procedure: k1919 
o|inlining procedure: k1937 
o|inlining procedure: "(srfi-4.scm:280) ext-free365" 
o|inlining procedure: k1937 
o|contracted procedure: k1982 
o|inlining procedure: k1979 
o|inlining procedure: k1994 
o|inlining procedure: k1994 
o|inlining procedure: k1979 
o|contracted procedure: k2080 
o|inlining procedure: k2077 
o|inlining procedure: k2092 
o|inlining procedure: k2092 
o|inlining procedure: k2077 
o|contracted procedure: k2178 
o|inlining procedure: k2175 
o|inlining procedure: k2190 
o|inlining procedure: k2190 
o|inlining procedure: k2175 
o|contracted procedure: k2277 
o|inlining procedure: k2274 
o|inlining procedure: k2289 
o|inlining procedure: k2289 
o|inlining procedure: k2274 
o|contracted procedure: k2376 
o|inlining procedure: k2373 
o|inlining procedure: k2388 
o|inlining procedure: k2388 
o|inlining procedure: k2373 
o|contracted procedure: k2475 
o|inlining procedure: k2472 
o|inlining procedure: k2487 
o|inlining procedure: k2487 
o|inlining procedure: k2472 
o|contracted procedure: k2574 
o|inlining procedure: k2571 
o|inlining procedure: k2589 
o|inlining procedure: k2589 
o|inlining procedure: k2571 
o|contracted procedure: k2677 
o|inlining procedure: k2674 
o|inlining procedure: k2692 
o|inlining procedure: k2692 
o|inlining procedure: k2674 
o|inlining procedure: k2762 
o|inlining procedure: k2762 
o|inlining procedure: k2798 
o|inlining procedure: k2798 
o|inlining procedure: k2834 
o|inlining procedure: k2834 
o|inlining procedure: k2870 
o|inlining procedure: k2870 
o|inlining procedure: k2906 
o|inlining procedure: k2906 
o|inlining procedure: k2942 
o|inlining procedure: k2942 
o|inlining procedure: k2978 
o|inlining procedure: k2978 
o|inlining procedure: k3014 
o|inlining procedure: k3014 
o|inlining procedure: k3095 
o|inlining procedure: k3095 
o|inlining procedure: k3125 
o|inlining procedure: k3125 
o|inlining procedure: k3155 
o|inlining procedure: k3155 
o|inlining procedure: k3185 
o|inlining procedure: k3185 
o|inlining procedure: k3215 
o|inlining procedure: k3215 
o|inlining procedure: k3244 
o|inlining procedure: k3244 
o|inlining procedure: k3273 
o|inlining procedure: k3273 
o|inlining procedure: k3302 
o|inlining procedure: k3302 
o|inlining procedure: k3408 
o|inlining procedure: k3408 
o|inlining procedure: k3441 
o|inlining procedure: k3441 
o|substituted constant variable: a3599 
o|inlining procedure: k3595 
o|inlining procedure: k3618 
o|inlining procedure: k3618 
o|inlining procedure: k3595 
o|inlining procedure: k3660 
o|inlining procedure: k3660 
o|contracted procedure: "(srfi-4.scm:626) g957958" 
o|inlining procedure: k3759 
o|inlining procedure: k3759 
o|contracted procedure: "(srfi-4.scm:625) g948949" 
o|inlining procedure: k3735 
o|inlining procedure: k3735 
o|substituted constant variable: a3876 
o|substituted constant variable: a3877 
o|inlining procedure: k3912 
o|inlining procedure: k3912 
o|inlining procedure: k3929 
o|inlining procedure: k3929 
o|inlining procedure: k3938 
o|inlining procedure: k3938 
o|contracted procedure: "(srfi-4.scm:648) g10381039" 
o|inlining procedure: k3953 
o|inlining procedure: k3953 
o|contracted procedure: "(srfi-4.scm:647) g10261027" 
o|inlining procedure: k3883 
o|inlining procedure: k3883 
o|inlining procedure: k3981 
o|inlining procedure: k3981 
o|substituted constant variable: a4036 
o|substituted constant variable: a4037 
o|contracted procedure: "(srfi-4.scm:250) g349350" 
o|inlining procedure: k4159 
o|inlining procedure: k4159 
o|contracted procedure: "(srfi-4.scm:240) g334335" 
o|inlining procedure: k4189 
o|inlining procedure: k4189 
o|contracted procedure: "(srfi-4.scm:230) g319320" 
o|inlining procedure: k4219 
o|inlining procedure: k4219 
o|contracted procedure: "(srfi-4.scm:220) g304305" 
o|inlining procedure: k4249 
o|inlining procedure: k4249 
o|contracted procedure: "(srfi-4.scm:210) g289290" 
o|inlining procedure: k4279 
o|inlining procedure: k4279 
o|contracted procedure: "(srfi-4.scm:200) g274275" 
o|inlining procedure: k4309 
o|inlining procedure: k4309 
o|contracted procedure: "(srfi-4.scm:190) g259260" 
o|inlining procedure: k4339 
o|inlining procedure: k4339 
o|contracted procedure: "(srfi-4.scm:180) g244245" 
o|inlining procedure: k4369 
o|inlining procedure: k4369 
o|simplifications: ((if . 1)) 
o|replaced variables: 311 
o|removed binding forms: 323 
o|substituted constant variable: loc106 
o|substituted constant variable: from104 
o|substituted constant variable: from104 
o|substituted constant variable: loc106 
o|substituted constant variable: loc124 
o|substituted constant variable: from122 
o|substituted constant variable: from122 
o|substituted constant variable: loc124 
o|substituted constant variable: loc141 
o|substituted constant variable: from139 
o|substituted constant variable: from139 
o|substituted constant variable: loc141 
o|substituted constant variable: loc159 
o|substituted constant variable: from157 
o|substituted constant variable: from157 
o|substituted constant variable: loc159 
o|substituted constant variable: loc180 
o|substituted constant variable: from178 
o|substituted constant variable: from178 
o|substituted constant variable: loc180 
o|substituted constant variable: loc198 
o|substituted constant variable: from196 
o|substituted constant variable: from196 
o|substituted constant variable: loc198 
o|substituted constant variable: loc216 
o|substituted constant variable: from214 
o|substituted constant variable: from214 
o|substituted constant variable: loc216 
o|substituted constant variable: loc233 
o|substituted constant variable: from231 
o|substituted constant variable: from231 
o|substituted constant variable: loc233 
o|substituted constant variable: r30964470 
o|substituted constant variable: r31264472 
o|substituted constant variable: r31564474 
o|substituted constant variable: r31864476 
o|substituted constant variable: r32164478 
o|substituted constant variable: r32454480 
o|substituted constant variable: r32744482 
o|substituted constant variable: r33034484 
o|substituted constant variable: from960 
o|substituted constant variable: from960 
o|substituted constant variable: from951 
o|substituted constant variable: from951 
o|substituted constant variable: loc1043 
o|substituted constant variable: loc1043 
o|substituted constant variable: loc1031 
o|substituted constant variable: from1029 
o|substituted constant variable: from1029 
o|substituted constant variable: loc1031 
o|substituted constant variable: loc354 
o|substituted constant variable: from352 
o|substituted constant variable: from352 
o|substituted constant variable: loc354 
o|substituted constant variable: loc339 
o|substituted constant variable: from337 
o|substituted constant variable: from337 
o|substituted constant variable: loc339 
o|substituted constant variable: loc324 
o|substituted constant variable: from322 
o|substituted constant variable: from322 
o|substituted constant variable: loc324 
o|substituted constant variable: loc309 
o|substituted constant variable: from307 
o|substituted constant variable: from307 
o|substituted constant variable: loc309 
o|substituted constant variable: loc294 
o|substituted constant variable: from292 
o|substituted constant variable: from292 
o|substituted constant variable: loc294 
o|substituted constant variable: loc279 
o|substituted constant variable: from277 
o|substituted constant variable: from277 
o|substituted constant variable: loc279 
o|substituted constant variable: loc264 
o|substituted constant variable: from262 
o|substituted constant variable: from262 
o|substituted constant variable: loc264 
o|substituted constant variable: loc249 
o|substituted constant variable: from247 
o|substituted constant variable: from247 
o|substituted constant variable: loc249 
o|replaced variables: 48 
o|removed binding forms: 363 
o|inlining procedure: k2001 
o|inlining procedure: k2001 
o|inlining procedure: k2099 
o|inlining procedure: k2099 
o|inlining procedure: k2197 
o|inlining procedure: k2197 
o|inlining procedure: k2296 
o|inlining procedure: k2296 
o|inlining procedure: k2395 
o|inlining procedure: k2395 
o|inlining procedure: k2494 
o|inlining procedure: k2494 
o|inlining procedure: k2597 
o|inlining procedure: k2597 
o|inlining procedure: k2700 
o|inlining procedure: k2700 
o|inlining procedure: k4053 
o|inlining procedure: k4053 
o|replaced variables: 1 
o|removed binding forms: 88 
o|substituted constant variable: r20024634 
o|substituted constant variable: r21004638 
o|substituted constant variable: r21984642 
o|substituted constant variable: r22974646 
o|substituted constant variable: r23964650 
o|substituted constant variable: r24954654 
o|substituted constant variable: r25984658 
o|substituted constant variable: r27014662 
o|replaced variables: 8 
o|removed binding forms: 12 
o|removed conditional forms: 8 
o|removed binding forms: 16 
o|simplifications: ((##core#call . 351) (if . 95)) 
o|  call simplifications:
o|    list
o|    not
o|    fx=	2
o|    fx-	2
o|    fx*	2
o|    ##sys#list	9
o|    cadr
o|    caddr
o|    symbol?
o|    memq
o|    ##sys#check-byte-vector	2
o|    eq?	6
o|    ##sys#size	5
o|    ##sys#slot	10
o|    ##sys#structure?	8
o|    fx>=	8
o|    fx+	14
o|    cons	8
o|    ##sys#check-list	8
o|    car	31
o|    null?	62
o|    cdr	31
o|    ##sys#make-structure	12
o|    ##sys#foreign-fixnum-argument
o|    ##sys#check-number	4
o|    ##sys#fits-in-int?
o|    negative?
o|    ##sys#fits-in-unsigned-int?
o|    fx<=	21
o|    fx<	22
o|    ##sys#check-structure	37
o|    ##sys#check-exact	37
o|contracted procedure: k1496 
o|contracted procedure: k1502 
o|contracted procedure: k1511 
o|contracted procedure: k1517 
o|contracted procedure: k1523 
o|contracted procedure: k1529 
o|contracted procedure: k1535 
o|contracted procedure: k1541 
o|contracted procedure: k1547 
o|contracted procedure: k1553 
o|contracted procedure: k1559 
o|contracted procedure: k1562 
o|contracted procedure: k1570 
o|contracted procedure: k1583 
o|contracted procedure: k1576 
o|contracted procedure: k1592 
o|contracted procedure: k1601 
o|contracted procedure: k1604 
o|contracted procedure: k1609 
o|contracted procedure: k1622 
o|contracted procedure: k1615 
o|contracted procedure: k1634 
o|contracted procedure: k1637 
o|contracted procedure: k1645 
o|contracted procedure: k1658 
o|contracted procedure: k1651 
o|contracted procedure: k1667 
o|contracted procedure: k1676 
o|contracted procedure: k1679 
o|contracted procedure: k1684 
o|contracted procedure: k1697 
o|contracted procedure: k1690 
o|contracted procedure: k1709 
o|contracted procedure: k1720 
o|contracted procedure: k1733 
o|contracted procedure: k1726 
o|contracted procedure: k1742 
o|contracted procedure: k1758 
o|contracted procedure: k1764 
o|contracted procedure: k1775 
o|contracted procedure: k1788 
o|contracted procedure: k1781 
o|contracted procedure: k1797 
o|contracted procedure: k1806 
o|contracted procedure: k1809 
o|contracted procedure: k1814 
o|contracted procedure: k1827 
o|contracted procedure: k1820 
o|contracted procedure: k1843 
o|contracted procedure: k1846 
o|contracted procedure: k1851 
o|contracted procedure: k1864 
o|contracted procedure: k1857 
o|contracted procedure: k1912 
o|contracted procedure: k2041 
o|contracted procedure: k1952 
o|contracted procedure: k2035 
o|contracted procedure: k1955 
o|contracted procedure: k2029 
o|contracted procedure: k1958 
o|contracted procedure: k2023 
o|contracted procedure: k1961 
o|contracted procedure: k2017 
o|contracted procedure: k1964 
o|contracted procedure: k2011 
o|contracted procedure: k1967 
o|contracted procedure: k1970 
o|contracted procedure: k1973 
o|contracted procedure: k2139 
o|contracted procedure: k2050 
o|contracted procedure: k2133 
o|contracted procedure: k2053 
o|contracted procedure: k2127 
o|contracted procedure: k2056 
o|contracted procedure: k2121 
o|contracted procedure: k2059 
o|contracted procedure: k2115 
o|contracted procedure: k2062 
o|contracted procedure: k2109 
o|contracted procedure: k2065 
o|contracted procedure: k2068 
o|contracted procedure: k2071 
o|contracted procedure: k2238 
o|contracted procedure: k2148 
o|contracted procedure: k2232 
o|contracted procedure: k2151 
o|contracted procedure: k2226 
o|contracted procedure: k2154 
o|contracted procedure: k2220 
o|contracted procedure: k2157 
o|contracted procedure: k2214 
o|contracted procedure: k2160 
o|contracted procedure: k2208 
o|contracted procedure: k2163 
o|contracted procedure: k2166 
o|contracted procedure: k2169 
o|contracted procedure: k2337 
o|contracted procedure: k2247 
o|contracted procedure: k2331 
o|contracted procedure: k2250 
o|contracted procedure: k2325 
o|contracted procedure: k2253 
o|contracted procedure: k2319 
o|contracted procedure: k2256 
o|contracted procedure: k2313 
o|contracted procedure: k2259 
o|contracted procedure: k2307 
o|contracted procedure: k2262 
o|contracted procedure: k2265 
o|contracted procedure: k2268 
o|contracted procedure: k2436 
o|contracted procedure: k2346 
o|contracted procedure: k2430 
o|contracted procedure: k2349 
o|contracted procedure: k2424 
o|contracted procedure: k2352 
o|contracted procedure: k2418 
o|contracted procedure: k2355 
o|contracted procedure: k2412 
o|contracted procedure: k2358 
o|contracted procedure: k2406 
o|contracted procedure: k2361 
o|contracted procedure: k2364 
o|contracted procedure: k2367 
o|contracted procedure: k2379 
o|contracted procedure: k2535 
o|contracted procedure: k2445 
o|contracted procedure: k2529 
o|contracted procedure: k2448 
o|contracted procedure: k2523 
o|contracted procedure: k2451 
o|contracted procedure: k2517 
o|contracted procedure: k2454 
o|contracted procedure: k2511 
o|contracted procedure: k2457 
o|contracted procedure: k2505 
o|contracted procedure: k2460 
o|contracted procedure: k2463 
o|contracted procedure: k2466 
o|contracted procedure: k2478 
o|contracted procedure: k2638 
o|contracted procedure: k2544 
o|contracted procedure: k2632 
o|contracted procedure: k2547 
o|contracted procedure: k2626 
o|contracted procedure: k2550 
o|contracted procedure: k2620 
o|contracted procedure: k2553 
o|contracted procedure: k2614 
o|contracted procedure: k2556 
o|contracted procedure: k2608 
o|contracted procedure: k2559 
o|contracted procedure: k2562 
o|contracted procedure: k2565 
o|contracted procedure: k2577 
o|contracted procedure: k2741 
o|contracted procedure: k2647 
o|contracted procedure: k2735 
o|contracted procedure: k2650 
o|contracted procedure: k2729 
o|contracted procedure: k2653 
o|contracted procedure: k2723 
o|contracted procedure: k2656 
o|contracted procedure: k2717 
o|contracted procedure: k2659 
o|contracted procedure: k2711 
o|contracted procedure: k2662 
o|contracted procedure: k2665 
o|contracted procedure: k2668 
o|contracted procedure: k2680 
o|contracted procedure: k2750 
o|contracted procedure: k2773 
o|contracted procedure: k2786 
o|contracted procedure: k2809 
o|contracted procedure: k2822 
o|contracted procedure: k2845 
o|contracted procedure: k2858 
o|contracted procedure: k2881 
o|contracted procedure: k2894 
o|contracted procedure: k2917 
o|contracted procedure: k2930 
o|contracted procedure: k2953 
o|contracted procedure: k2966 
o|contracted procedure: k2989 
o|contracted procedure: k3002 
o|contracted procedure: k3025 
o|contracted procedure: k3086 
o|contracted procedure: k3098 
o|contracted procedure: k3110 
o|contracted procedure: k3116 
o|contracted procedure: k3128 
o|contracted procedure: k3140 
o|contracted procedure: k3146 
o|contracted procedure: k3158 
o|contracted procedure: k3170 
o|contracted procedure: k3176 
o|contracted procedure: k3188 
o|contracted procedure: k3200 
o|contracted procedure: k3206 
o|contracted procedure: k3218 
o|contracted procedure: k3229 
o|contracted procedure: k3235 
o|contracted procedure: k3247 
o|contracted procedure: k3258 
o|contracted procedure: k3264 
o|contracted procedure: k3276 
o|contracted procedure: k3287 
o|contracted procedure: k3293 
o|contracted procedure: k3305 
o|contracted procedure: k3316 
o|contracted procedure: k3373 
o|contracted procedure: k3384 
o|contracted procedure: k3387 
o|contracted procedure: k3394 
o|contracted procedure: k3402 
o|contracted procedure: k3405 
o|contracted procedure: k3411 
o|contracted procedure: k3432 
o|contracted procedure: k3435 
o|contracted procedure: k3444 
o|contracted procedure: k3590 
o|contracted procedure: k3646 
o|contracted procedure: k3603 
o|contracted procedure: k3609 
o|contracted procedure: k3612 
o|contracted procedure: k3615 
o|contracted procedure: k3634 
o|contracted procedure: k3623 
o|contracted procedure: k3687 
o|contracted procedure: k3691 
o|contracted procedure: k3695 
o|contracted procedure: k3699 
o|contracted procedure: k3703 
o|contracted procedure: k3707 
o|contracted procedure: k3711 
o|contracted procedure: k3715 
o|contracted procedure: k3657 
o|contracted procedure: k3673 
o|contracted procedure: k3680 
o|contracted procedure: k3721 
o|contracted procedure: k3724 
o|contracted procedure: k3727 
o|contracted procedure: k3792 
o|contracted procedure: k3778 
o|contracted procedure: k3784 
o|contracted procedure: k3788 
o|contracted procedure: k3796 
o|contracted procedure: k3756 
o|contracted procedure: k3769 
o|contracted procedure: k3762 
o|contracted procedure: k3800 
o|contracted procedure: k3732 
o|contracted procedure: k3745 
o|contracted procedure: k3738 
o|contracted procedure: k4014 
o|contracted procedure: k3854 
o|contracted procedure: k4008 
o|contracted procedure: k3857 
o|contracted procedure: k4002 
o|contracted procedure: k3860 
o|contracted procedure: k3996 
o|contracted procedure: k3863 
o|contracted procedure: k3990 
o|contracted procedure: k3866 
o|contracted procedure: k3984 
o|contracted procedure: k3869 
o|contracted procedure: k3872 
o|contracted procedure: k3945 
o|contracted procedure: k3905 
o|inlining procedure: k3912 
o|inlining procedure: k3912 
o|contracted procedure: k3932 
o|contracted procedure: k3935 
o|contracted procedure: k3973 
o|contracted procedure: k3950 
o|contracted procedure: k3963 
o|contracted procedure: k3956 
o|contracted procedure: k3977 
o|contracted procedure: k3880 
o|contracted procedure: k3893 
o|contracted procedure: k3886 
o|contracted procedure: k4094 
o|contracted procedure: k4023 
o|contracted procedure: k4088 
o|contracted procedure: k4026 
o|contracted procedure: k4082 
o|contracted procedure: k4029 
o|contracted procedure: k4076 
o|contracted procedure: k4032 
o|contracted procedure: k4038 
o|contracted procedure: k4041 
o|contracted procedure: k4044 
o|contracted procedure: k4047 
o|contracted procedure: k4050 
o|contracted procedure: k4063 
o|contracted procedure: k4070 
o|contracted procedure: k4139 
o|contracted procedure: k4103 
o|contracted procedure: k4133 
o|contracted procedure: k4106 
o|contracted procedure: k4127 
o|contracted procedure: k4109 
o|contracted procedure: k4121 
o|contracted procedure: k4112 
o|contracted procedure: k4151 
o|contracted procedure: k4156 
o|contracted procedure: k4169 
o|contracted procedure: k4162 
o|contracted procedure: k4181 
o|contracted procedure: k4186 
o|contracted procedure: k4199 
o|contracted procedure: k4192 
o|contracted procedure: k4211 
o|contracted procedure: k4216 
o|contracted procedure: k4229 
o|contracted procedure: k4222 
o|contracted procedure: k4241 
o|contracted procedure: k4246 
o|contracted procedure: k4259 
o|contracted procedure: k4252 
o|contracted procedure: k4271 
o|contracted procedure: k4276 
o|contracted procedure: k4289 
o|contracted procedure: k4282 
o|contracted procedure: k4301 
o|contracted procedure: k4306 
o|contracted procedure: k4319 
o|contracted procedure: k4312 
o|contracted procedure: k4331 
o|contracted procedure: k4336 
o|contracted procedure: k4349 
o|contracted procedure: k4342 
o|contracted procedure: k4361 
o|contracted procedure: k4366 
o|contracted procedure: k4379 
o|contracted procedure: k4372 
o|simplifications: ((let . 13)) 
o|removed binding forms: 334 
o|inlining procedure: "(srfi-4.scm:542) pack" 
o|inlining procedure: "(srfi-4.scm:541) pack" 
o|inlining procedure: "(srfi-4.scm:540) pack" 
o|inlining procedure: "(srfi-4.scm:539) pack" 
o|inlining procedure: "(srfi-4.scm:538) pack" 
o|inlining procedure: "(srfi-4.scm:537) pack" 
o|inlining procedure: "(srfi-4.scm:536) pack" 
o|inlining procedure: "(srfi-4.scm:535) pack" 
o|replaced variables: 235 
o|removed binding forms: 1 
o|inlining procedure: k1589 
o|inlining procedure: k1628 
o|inlining procedure: k1664 
o|inlining procedure: k1703 
o|inlining procedure: k1739 
o|inlining procedure: k1794 
o|inlining procedure: k1922 
o|removed side-effect free assignment to unused variable: pack 
o|substituted constant variable: tag8374988 
o|substituted constant variable: loc8384989 
o|substituted constant variable: tag8374995 
o|substituted constant variable: loc8384996 
o|substituted constant variable: tag8375002 
o|substituted constant variable: loc8385003 
o|substituted constant variable: tag8375009 
o|substituted constant variable: loc8385010 
o|substituted constant variable: tag8375016 
o|substituted constant variable: loc8385017 
o|substituted constant variable: tag8375023 
o|substituted constant variable: loc8385024 
o|substituted constant variable: tag8375030 
o|substituted constant variable: loc8385031 
o|substituted constant variable: tag8375037 
o|substituted constant variable: loc8385038 
o|inlining procedure: k4175 
o|inlining procedure: k4205 
o|inlining procedure: k4235 
o|inlining procedure: k4265 
o|inlining procedure: k4295 
o|inlining procedure: k4325 
o|inlining procedure: k4355 
o|inlining procedure: k4385 
o|simplifications: ((if . 1)) 
o|replaced variables: 8 
o|removed binding forms: 89 
o|removed binding forms: 40 
o|contracted procedure: k3462 
o|contracted procedure: k3466 
o|contracted procedure: k3470 
o|contracted procedure: k3474 
o|contracted procedure: k3478 
o|contracted procedure: k3482 
o|contracted procedure: k3486 
o|contracted procedure: k3490 
o|removed binding forms: 22 
o|direct leaf routine/allocation: doloop401402 0 
o|direct leaf routine/allocation: doloop429430 0 
o|direct leaf routine/allocation: doloop457458 0 
o|direct leaf routine/allocation: doloop485486 0 
o|direct leaf routine/allocation: doloop513514 0 
o|direct leaf routine/allocation: doloop541542 0 
o|direct leaf routine/allocation: doloop569570 0 
o|direct leaf routine/allocation: doloop598599 0 
o|converted assignments to bindings: (doloop401402) 
o|converted assignments to bindings: (doloop429430) 
o|converted assignments to bindings: (doloop457458) 
o|converted assignments to bindings: (doloop485486) 
o|converted assignments to bindings: (doloop513514) 
o|converted assignments to bindings: (doloop541542) 
o|converted assignments to bindings: (doloop569570) 
o|converted assignments to bindings: (doloop598599) 
o|simplifications: ((let . 8)) 
o|customizable procedures: (pack-copy unpack unpack-copy k4059 k3915 subnvector g918919 k3447 k3414 loop815 loop808 loop801 loop794 loop787 loop780 loop773 loop766 doloop723724 doloop710711 doloop697698 doloop684685 doloop671672 doloop658659 doloop645646 doloop632633 k2683 k2580 alloc370 ##sys#check-exact-interval) 
o|calls to known targets: 116 
o|identified direct recursive calls: f_1992 1 
o|identified direct recursive calls: f_2090 1 
o|identified direct recursive calls: f_2188 1 
o|identified direct recursive calls: f_2287 1 
o|identified direct recursive calls: f_2386 1 
o|identified direct recursive calls: f_2485 1 
o|identified direct recursive calls: f_2587 1 
o|identified direct recursive calls: f_2690 1 
o|identified direct recursive calls: f_3093 1 
o|identified direct recursive calls: f_3123 1 
o|identified direct recursive calls: f_3153 1 
o|identified direct recursive calls: f_3183 1 
o|identified direct recursive calls: f_3213 1 
o|identified direct recursive calls: f_3242 1 
o|identified direct recursive calls: f_3271 1 
o|identified direct recursive calls: f_3300 1 
o|fast box initializations: 16 
o|fast global references: 36 
o|fast global assignments: 5 
o|dropping unused closure argument: f_1917 
o|dropping unused closure argument: f_3398 
o|dropping unused closure argument: f_3380 
o|dropping unused closure argument: f_1494 
o|dropping unused closure argument: f_3428 
o|dropping unused closure argument: f_3719 
*/
/* end of file */
