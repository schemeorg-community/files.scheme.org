/* Generated from support.scm by the CHICKEN compiler
   http://www.call-cc.org
   2017-02-19 13:19
   Version 4.12.0 (rev 6ea24b6)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2017-02-19 on yves.more-magic.net (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[569];
static double C_possibly_force_alignment;


#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub3735(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from k5685 */
C_regparm static C_word C_fcall stub346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k5678 */
C_regparm static C_word C_fcall stub341(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word *av) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word *av) C_noret;
C_noret_decl(f_11991)
static void C_fcall f_11991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word *av) C_noret;
C_noret_decl(f_11994)
static void C_ccall f_11994(C_word c,C_word *av) C_noret;
C_noret_decl(f_12059)
static void C_fcall f_12059(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word *av) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word *av) C_noret;
C_noret_decl(f_4895)
static void C_fcall f_4895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word *av) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word *av) C_noret;
C_noret_decl(f_11696)
static void C_ccall f_11696(C_word c,C_word *av) C_noret;
C_noret_decl(f_10482)
static void C_ccall f_10482(C_word c,C_word *av) C_noret;
C_noret_decl(f_11693)
static void C_ccall f_11693(C_word c,C_word *av) C_noret;
C_noret_decl(f_11690)
static void C_ccall f_11690(C_word c,C_word *av) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word *av) C_noret;
C_noret_decl(f_8188)
static void C_fcall f_8188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12175)
static void C_fcall f_12175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_fcall f_9759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9726)
static void C_ccall f_9726(C_word c,C_word *av) C_noret;
C_noret_decl(f_9720)
static void C_ccall f_9720(C_word c,C_word *av) C_noret;
C_noret_decl(f_15334)
static void C_ccall f_15334(C_word c,C_word *av) C_noret;
C_noret_decl(f_10238)
static void C_ccall f_10238(C_word c,C_word *av) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word *av) C_noret;
C_noret_decl(f_9738)
static void C_ccall f_9738(C_word c,C_word *av) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word *av) C_noret;
C_noret_decl(f_9733)
static void C_ccall f_9733(C_word c,C_word *av) C_noret;
C_noret_decl(f_9730)
static void C_ccall f_9730(C_word c,C_word *av) C_noret;
C_noret_decl(f_15428)
static void C_ccall f_15428(C_word c,C_word *av) C_noret;
C_noret_decl(f_12157)
static void C_fcall f_12157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10437)
static void C_ccall f_10437(C_word c,C_word *av) C_noret;
C_noret_decl(f_15352)
static void C_ccall f_15352(C_word c,C_word *av) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word *av) C_noret;
C_noret_decl(f_15359)
static void C_ccall f_15359(C_word c,C_word *av) C_noret;
C_noret_decl(f_15431)
static void C_ccall f_15431(C_word c,C_word *av) C_noret;
C_noret_decl(f_12953)
static void C_fcall f_12953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word *av) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word *av) C_noret;
C_noret_decl(f_12965)
static void C_fcall f_12965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word *av) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word *av) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word *av) C_noret;
C_noret_decl(f_15451)
static void C_ccall f_15451(C_word c,C_word *av) C_noret;
C_noret_decl(f_15454)
static void C_ccall f_15454(C_word c,C_word *av) C_noret;
C_noret_decl(f_12932)
static void C_fcall f_12932(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word *av) C_noret;
C_noret_decl(f_11732)
static void C_ccall f_11732(C_word c,C_word *av) C_noret;
C_noret_decl(f_11738)
static void C_ccall f_11738(C_word c,C_word *av) C_noret;
C_noret_decl(f_12941)
static void C_fcall f_12941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10476)
static void C_ccall f_10476(C_word c,C_word *av) C_noret;
C_noret_decl(f_11726)
static void C_ccall f_11726(C_word c,C_word *av) C_noret;
C_noret_decl(f_11720)
static void C_ccall f_11720(C_word c,C_word *av) C_noret;
C_noret_decl(f_11729)
static void C_ccall f_11729(C_word c,C_word *av) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word *av) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word *av) C_noret;
C_noret_decl(f_15320)
static void C_ccall f_15320(C_word c,C_word *av) C_noret;
C_noret_decl(f_15324)
static void C_ccall f_15324(C_word c,C_word *av) C_noret;
C_noret_decl(f_11758)
static void C_ccall f_11758(C_word c,C_word *av) C_noret;
C_noret_decl(f_11750)
static void C_ccall f_11750(C_word c,C_word *av) C_noret;
C_noret_decl(f_11753)
static void C_ccall f_11753(C_word c,C_word *av) C_noret;
C_noret_decl(f_14248)
static void C_fcall f_14248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11741)
static void C_ccall f_11741(C_word c,C_word *av) C_noret;
C_noret_decl(f_11744)
static void C_ccall f_11744(C_word c,C_word *av) C_noret;
C_noret_decl(f_12086)
static void C_fcall f_12086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14227)
static void C_fcall f_14227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11779)
static void C_ccall f_11779(C_word c,C_word *av) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word *av) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word *av) C_noret;
C_noret_decl(f_11773)
static void C_ccall f_11773(C_word c,C_word *av) C_noret;
C_noret_decl(f_5714)
static void C_fcall f_5714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word *av) C_noret;
C_noret_decl(f_7777)
static void C_fcall f_7777(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word *av) C_noret;
C_noret_decl(f_11765)
static void C_ccall f_11765(C_word c,C_word *av) C_noret;
C_noret_decl(f_11762)
static void C_ccall f_11762(C_word c,C_word *av) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word *av) C_noret;
C_noret_decl(f_12160)
static void C_ccall f_12160(C_word c,C_word *av) C_noret;
C_noret_decl(f_9714)
static void C_ccall f_9714(C_word c,C_word *av) C_noret;
C_noret_decl(f_11790)
static void C_fcall f_11790(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word *av) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word *av) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word *av) C_noret;
C_noret_decl(f_6052)
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9012)
static void C_fcall f_9012(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9010)
static void C_ccall f_9010(C_word c,C_word *av) C_noret;
C_noret_decl(f_12320)
static void C_ccall f_12320(C_word c,C_word *av) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word *av) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word *av) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word *av) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word *av) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word *av) C_noret;
C_noret_decl(f17649)
static void C_ccall f17649(C_word c,C_word *av) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word *av) C_noret;
C_noret_decl(f_7149)
static void C_fcall f_7149(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9002)
static void C_ccall f_9002(C_word c,C_word *av) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word *av) C_noret;
C_noret_decl(f_6516)
static void C_ccall f_6516(C_word c,C_word *av) C_noret;
C_noret_decl(f_6506)
static void C_fcall f_6506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9060)
static void C_fcall f_9060(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word *av) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word *av) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word *av) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word *av) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word *av) C_noret;
C_noret_decl(f_11714)
static void C_ccall f_11714(C_word c,C_word *av) C_noret;
C_noret_decl(f_11717)
static void C_ccall f_11717(C_word c,C_word *av) C_noret;
C_noret_decl(f_11705)
static void C_ccall f_11705(C_word c,C_word *av) C_noret;
C_noret_decl(f_11702)
static void C_ccall f_11702(C_word c,C_word *av) C_noret;
C_noret_decl(f_11708)
static void C_ccall f_11708(C_word c,C_word *av) C_noret;
C_noret_decl(f_15300)
static void C_ccall f_15300(C_word c,C_word *av) C_noret;
C_noret_decl(f_16156)
static void C_ccall f_16156(C_word c,C_word *av) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word *av) C_noret;
C_noret_decl(f_16152)
static void C_ccall f_16152(C_word c,C_word *av) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word *av) C_noret;
C_noret_decl(f_10165)
static void C_fcall f_10165(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10163)
static void C_ccall f_10163(C_word c,C_word *av) C_noret;
C_noret_decl(f_16124)
static void C_ccall f_16124(C_word c,C_word *av) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word *av) C_noret;
C_noret_decl(f_15413)
static void C_ccall f_15413(C_word c,C_word *av) C_noret;
C_noret_decl(f_16196)
static void C_ccall f_16196(C_word c,C_word *av) C_noret;
C_noret_decl(f_6076)
static void C_fcall f_6076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16141)
static void C_ccall f_16141(C_word c,C_word *av) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word *av) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word *av) C_noret;
C_noret_decl(f_10441)
static void C_ccall f_10441(C_word c,C_word *av) C_noret;
C_noret_decl(f_10444)
static void C_ccall f_10444(C_word c,C_word *av) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word *av) C_noret;
C_noret_decl(f_16130)
static void C_ccall f_16130(C_word c,C_word *av) C_noret;
C_noret_decl(f_15389)
static void C_ccall f_15389(C_word c,C_word *av) C_noret;
C_noret_decl(f_14619)
static void C_ccall f_14619(C_word c,C_word *av) C_noret;
C_noret_decl(f_14615)
static void C_ccall f_14615(C_word c,C_word *av) C_noret;
C_noret_decl(f_14671)
static void C_ccall f_14671(C_word c,C_word *av) C_noret;
C_noret_decl(f_9529)
static void C_ccall f_9529(C_word c,C_word *av) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word *av) C_noret;
C_noret_decl(f_14661)
static void C_fcall f_14661(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10757)
static void C_ccall f_10757(C_word c,C_word *av) C_noret;
C_noret_decl(f_15493)
static void C_ccall f_15493(C_word c,C_word *av) C_noret;
C_noret_decl(f_10750)
static void C_ccall f_10750(C_word c,C_word *av) C_noret;
C_noret_decl(f_5761)
static void C_fcall f_5761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15499)
static void C_ccall f_15499(C_word c,C_word *av) C_noret;
C_noret_decl(f_14653)
static void C_fcall f_14653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10723)
static void C_fcall f_10723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9580)
static void C_ccall f_9580(C_word c,C_word *av) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word *av) C_noret;
C_noret_decl(f_15067)
static void C_ccall f_15067(C_word c,C_word *av) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word *av) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word *av) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word *av) C_noret;
C_noret_decl(f_6955)
static void C_fcall f_6955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9555)
static void C_fcall f_9555(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10700)
static void C_ccall f_10700(C_word c,C_word *av) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word *av) C_noret;
C_noret_decl(f_10709)
static void C_ccall f_10709(C_word c,C_word *av) C_noret;
C_noret_decl(f_10704)
static void C_ccall f_10704(C_word c,C_word *av) C_noret;
C_noret_decl(f_15088)
static void C_ccall f_15088(C_word c,C_word *av) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word *av) C_noret;
C_noret_decl(f_5269)
static void C_fcall f_5269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word *av) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word *av) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word *av) C_noret;
C_noret_decl(f_16109)
static void C_ccall f_16109(C_word c,C_word *av) C_noret;
C_noret_decl(f_15027)
static void C_ccall f_15027(C_word c,C_word *av) C_noret;
C_noret_decl(f_6918)
static void C_fcall f_6918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8628)
static void C_ccall f_8628(C_word c,C_word *av) C_noret;
C_noret_decl(f_15073)
static void C_ccall f_15073(C_word c,C_word *av) C_noret;
C_noret_decl(f_10748)
static void C_ccall f_10748(C_word c,C_word *av) C_noret;
C_noret_decl(f_15079)
static void C_ccall f_15079(C_word c,C_word *av) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word *av) C_noret;
C_noret_decl(f_5231)
static void C_fcall f_5231(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9504)
static void C_fcall f_9504(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9502)
static void C_ccall f_9502(C_word c,C_word *av) C_noret;
C_noret_decl(f_14053)
static void C_ccall f_14053(C_word c,C_word *av) C_noret;
C_noret_decl(f_14621)
static void C_ccall f_14621(C_word c,C_word *av) C_noret;
C_noret_decl(f_16168)
static void C_ccall f_16168(C_word c,C_word *av) C_noret;
C_noret_decl(f_10718)
static void C_ccall f_10718(C_word c,C_word *av) C_noret;
C_noret_decl(f_10715)
static void C_ccall f_10715(C_word c,C_word *av) C_noret;
C_noret_decl(f_12285)
static void C_ccall f_12285(C_word c,C_word *av) C_noret;
C_noret_decl(f_12282)
static void C_fcall f_12282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16162)
static void C_ccall f_16162(C_word c,C_word *av) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word *av) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word *av) C_noret;
C_noret_decl(f_16184)
static void C_ccall f_16184(C_word c,C_word *av) C_noret;
C_noret_decl(f_8431)
static void C_ccall f_8431(C_word c,C_word *av) C_noret;
C_noret_decl(f_8433)
static void C_fcall f_8433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16180)
static void C_ccall f_16180(C_word c,C_word *av) C_noret;
C_noret_decl(f_14077)
static void C_fcall f_14077(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word *av) C_noret;
C_noret_decl(f_8604)
static void C_ccall f_8604(C_word c,C_word *av) C_noret;
C_noret_decl(f_8600)
static void C_fcall f_8600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8494)
static void C_ccall f_8494(C_word c,C_word *av) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607(C_word c,C_word *av) C_noret;
C_noret_decl(f_11222)
static void C_ccall f_11222(C_word c,C_word *av) C_noret;
C_noret_decl(f_14685)
static void C_fcall f_14685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_ccall f_11214(C_word c,C_word *av) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word *av) C_noret;
C_noret_decl(f_15010)
static void C_fcall f_15010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8405)
static void C_fcall f_8405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word *av) C_noret;
C_noret_decl(f_10781)
static void C_fcall f_10781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15036)
static void C_fcall f_15036(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5277)
static void C_ccall f_5277(C_word c,C_word *av) C_noret;
C_noret_decl(f_15000)
static void C_ccall f_15000(C_word c,C_word *av) C_noret;
C_noret_decl(f_14971)
static void C_fcall f_14971(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6992)
static void C_fcall f_6992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6998)
static void C_ccall f_6998(C_word c,C_word *av) C_noret;
C_noret_decl(f_10393)
static void C_ccall f_10393(C_word c,C_word *av) C_noret;
C_noret_decl(f_10399)
static void C_ccall f_10399(C_word c,C_word *av) C_noret;
C_noret_decl(f_11200)
static void C_fcall f_11200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9658)
static void C_ccall f_9658(C_word c,C_word *av) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word *av) C_noret;
C_noret_decl(f_8299)
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word *av) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225(C_word c,C_word *av) C_noret;
C_noret_decl(f_10375)
static void C_fcall f_10375(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9664)
static void C_fcall f_9664(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10389)
static void C_ccall f_10389(C_word c,C_word *av) C_noret;
C_noret_decl(f_15505)
static void C_ccall f_15505(C_word c,C_word *av) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word *av) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word *av) C_noret;
C_noret_decl(f_15513)
static void C_ccall f_15513(C_word c,C_word *av) C_noret;
C_noret_decl(f_15515)
static void C_ccall f_15515(C_word c,C_word *av) C_noret;
C_noret_decl(f_14995)
static void C_ccall f_14995(C_word c,C_word *av) C_noret;
C_noret_decl(f_11404)
static void C_ccall f_11404(C_word c,C_word *av) C_noret;
C_noret_decl(f_15521)
static void C_ccall f_15521(C_word c,C_word *av) C_noret;
C_noret_decl(f_15527)
static void C_ccall f_15527(C_word c,C_word *av) C_noret;
C_noret_decl(f_14288)
static void C_fcall f_14288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11437)
static void C_ccall f_11437(C_word c,C_word *av) C_noret;
C_noret_decl(f_14981)
static void C_ccall f_14981(C_word c,C_word *av) C_noret;
C_noret_decl(f_11439)
static void C_ccall f_11439(C_word c,C_word *av) C_noret;
C_noret_decl(f_14266)
static void C_fcall f_14266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11414)
static void C_ccall f_11414(C_word c,C_word *av) C_noret;
C_noret_decl(f_11411)
static void C_fcall f_11411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word *av) C_noret;
C_noret_decl(f_10321)
static void C_fcall f_10321(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word *av) C_noret;
C_noret_decl(f_11445)
static void C_ccall f_11445(C_word c,C_word *av) C_noret;
C_noret_decl(f_11476)
static void C_ccall f_11476(C_word c,C_word *av) C_noret;
C_noret_decl(f_11474)
static void C_ccall f_11474(C_word c,C_word *av) C_noret;
C_noret_decl(f_8755)
static void C_ccall f_8755(C_word c,C_word *av) C_noret;
C_noret_decl(f_11455)
static void C_ccall f_11455(C_word c,C_word *av) C_noret;
C_noret_decl(f_11452)
static void C_fcall f_11452(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11148)
static void C_ccall f_11148(C_word c,C_word *av) C_noret;
C_noret_decl(f_8730)
static void C_fcall f_8730(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142(C_word c,C_word *av) C_noret;
C_noret_decl(f_14913)
static void C_ccall f_14913(C_word c,C_word *av) C_noret;
C_noret_decl(f_9234)
static void C_ccall f_9234(C_word c,C_word *av) C_noret;
C_noret_decl(f_7981)
static void C_ccall f_7981(C_word c,C_word *av) C_noret;
C_noret_decl(f_14901)
static void C_ccall f_14901(C_word c,C_word *av) C_noret;
C_noret_decl(f_6167)
static void C_fcall f_6167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word *av) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word *av) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word *av) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word *av) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word *av) C_noret;
C_noret_decl(f_10299)
static void C_ccall f_10299(C_word c,C_word *av) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word *av) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word *av) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word *av) C_noret;
C_noret_decl(f_10262)
static void C_fcall f_10262(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word *av) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word *av) C_noret;
C_noret_decl(f_15702)
static void C_ccall f_15702(C_word c,C_word *av) C_noret;
C_noret_decl(f_15704)
static void C_ccall f_15704(C_word c,C_word *av) C_noret;
C_noret_decl(f_15800)
static void C_ccall f_15800(C_word c,C_word *av) C_noret;
C_noret_decl(f_8772)
static void C_ccall f_8772(C_word c,C_word *av) C_noret;
C_noret_decl(f_15803)
static void C_ccall f_15803(C_word c,C_word *av) C_noret;
C_noret_decl(f_15806)
static void C_ccall f_15806(C_word c,C_word *av) C_noret;
C_noret_decl(f_15710)
static void C_ccall f_15710(C_word c,C_word *av) C_noret;
C_noret_decl(f_15714)
static void C_ccall f_15714(C_word c,C_word *av) C_noret;
C_noret_decl(f_15719)
static void C_fcall f_15719(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15827)
static void C_ccall f_15827(C_word c,C_word *av) C_noret;
C_noret_decl(f_15824)
static void C_ccall f_15824(C_word c,C_word *av) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word *av) C_noret;
C_noret_decl(f_8769)
static void C_ccall f_8769(C_word c,C_word *av) C_noret;
C_noret_decl(f_7614)
static void C_fcall f_7614(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word *av) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word *av) C_noret;
C_noret_decl(f_9259)
static void C_fcall f_9259(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7046)
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9222)
static void C_ccall f_9222(C_word c,C_word *av) C_noret;
C_noret_decl(f_9690)
static void C_ccall f_9690(C_word c,C_word *av) C_noret;
C_noret_decl(f_9694)
static void C_ccall f_9694(C_word c,C_word *av) C_noret;
C_noret_decl(f_10274)
static void C_fcall f_10274(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word *av) C_noret;
C_noret_decl(f_7906)
static void C_ccall f_7906(C_word c,C_word *av) C_noret;
C_noret_decl(f_15811)
static void C_fcall f_15811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15539)
static void C_ccall f_15539(C_word c,C_word *av) C_noret;
C_noret_decl(f_15533)
static void C_ccall f_15533(C_word c,C_word *av) C_noret;
C_noret_decl(f_9284)
static void C_ccall f_9284(C_word c,C_word *av) C_noret;
C_noret_decl(f_7937)
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_16054)
static void C_ccall f_16054(C_word c,C_word *av) C_noret;
C_noret_decl(f_15771)
static void C_ccall f_15771(C_word c,C_word *av) C_noret;
C_noret_decl(f_15772)
static void C_fcall f_15772(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15788)
static void C_ccall f_15788(C_word c,C_word *av) C_noret;
C_noret_decl(f_15782)
static void C_ccall f_15782(C_word c,C_word *av) C_noret;
C_noret_decl(f_15889)
static void C_ccall f_15889(C_word c,C_word *av) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word *av) C_noret;
C_noret_decl(f_14959)
static void C_fcall f_14959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14957)
static void C_fcall f_14957(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16074)
static void C_ccall f_16074(C_word c,C_word *av) C_noret;
C_noret_decl(f_15561)
static void C_ccall f_15561(C_word c,C_word *av) C_noret;
C_noret_decl(f_15563)
static void C_fcall f_15563(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11277)
static void C_ccall f_11277(C_word c,C_word *av) C_noret;
C_noret_decl(f_7665)
static void C_fcall f_7665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word *av) C_noret;
C_noret_decl(f_10005)
static void C_ccall f_10005(C_word c,C_word *av) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word *av) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word *av) C_noret;
C_noret_decl(f_16010)
static void C_ccall f_16010(C_word c,C_word *av) C_noret;
C_noret_decl(f_15871)
static void C_ccall f_15871(C_word c,C_word *av) C_noret;
C_noret_decl(f_15874)
static void C_fcall f_15874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10025)
static void C_ccall f_10025(C_word c,C_word *av) C_noret;
C_noret_decl(f_16084)
static void C_ccall f_16084(C_word c,C_word *av) C_noret;
C_noret_decl(f_16088)
static void C_ccall f_16088(C_word c,C_word *av) C_noret;
C_noret_decl(f_15747)
static void C_ccall f_15747(C_word c,C_word *av) C_noret;
C_noret_decl(f_15597)
static void C_fcall f_15597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16082)
static void C_ccall f_16082(C_word c,C_word *av) C_noret;
C_noret_decl(f_10369)
static void C_ccall f_10369(C_word c,C_word *av) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word *av) C_noret;
C_noret_decl(f_15844)
static void C_fcall f_15844(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15759)
static void C_ccall f_15759(C_word c,C_word *av) C_noret;
C_noret_decl(f_11482)
static void C_ccall f_11482(C_word c,C_word *av) C_noret;
C_noret_decl(f_15756)
static void C_ccall f_15756(C_word c,C_word *av) C_noret;
C_noret_decl(f_15893)
static void C_ccall f_15893(C_word c,C_word *av) C_noret;
C_noret_decl(f_15768)
static void C_ccall f_15768(C_word c,C_word *av) C_noret;
C_noret_decl(f_15765)
static void C_ccall f_15765(C_word c,C_word *av) C_noret;
C_noret_decl(f_15762)
static void C_ccall f_15762(C_word c,C_word *av) C_noret;
C_noret_decl(f_15867)
static void C_ccall f_15867(C_word c,C_word *av) C_noret;
C_noret_decl(f_10053)
static void C_fcall f_10053(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10048)
static void C_ccall f_10048(C_word c,C_word *av) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word *av) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word *av) C_noret;
C_noret_decl(f_12356)
static void C_ccall f_12356(C_word c,C_word *av) C_noret;
C_noret_decl(f_11495)
static void C_ccall f_11495(C_word c,C_word *av) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word *av) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word *av) C_noret;
C_noret_decl(f_10057)
static void C_ccall f_10057(C_word c,C_word *av) C_noret;
C_noret_decl(f_14882)
static void C_ccall f_14882(C_word c,C_word *av) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word *av) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word *av) C_noret;
C_noret_decl(f_9469)
static void C_ccall f_9469(C_word c,C_word *av) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word *av) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word *av) C_noret;
C_noret_decl(f_9431)
static void C_ccall f_9431(C_word c,C_word *av) C_noret;
C_noret_decl(f_15854)
static void C_ccall f_15854(C_word c,C_word *av) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word *av) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word *av) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word *av) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word *av) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word *av) C_noret;
C_noret_decl(f_15144)
static void C_ccall f_15144(C_word c,C_word *av) C_noret;
C_noret_decl(f_15147)
static void C_fcall f_15147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9442)
static void C_ccall f_9442(C_word c,C_word *av) C_noret;
C_noret_decl(f_9444)
static void C_fcall f_9444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15096)
static void C_ccall f_15096(C_word c,C_word *av) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word *av) C_noret;
C_noret_decl(f_12009)
static void C_fcall f_12009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6102)
static void C_ccall f_6102(C_word c,C_word *av) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word *av) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word *av) C_noret;
C_noret_decl(f_7506)
static void C_ccall f_7506(C_word c,C_word *av) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word *av) C_noret;
C_noret_decl(f_15137)
static void C_ccall f_15137(C_word c,C_word *av) C_noret;
C_noret_decl(f_14871)
static void C_ccall f_14871(C_word c,C_word *av) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word *av) C_noret;
C_noret_decl(f_6237)
static C_word C_fcall f_6237(C_word t0,C_word t1);
C_noret_decl(f_11886)
static void C_ccall f_11886(C_word c,C_word *av) C_noret;
C_noret_decl(f_12033)
static void C_fcall f_12033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word *av) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word *av) C_noret;
C_noret_decl(f_15151)
static void C_ccall f_15151(C_word c,C_word *av) C_noret;
C_noret_decl(f_15157)
static void C_ccall f_15157(C_word c,C_word *av) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word *av) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word *av) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word *av) C_noret;
C_noret_decl(f_15122)
static void C_ccall f_15122(C_word c,C_word *av) C_noret;
C_noret_decl(f_15126)
static void C_ccall f_15126(C_word c,C_word *av) C_noret;
C_noret_decl(f_14807)
static void C_fcall f_14807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word *av) C_noret;
C_noret_decl(f_6208)
static void C_fcall f_6208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word *av) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word *av) C_noret;
C_noret_decl(f_6385)
static void C_ccall f_6385(C_word c,C_word *av) C_noret;
C_noret_decl(f_9413)
static void C_ccall f_9413(C_word c,C_word *av) C_noret;
C_noret_decl(f_11822)
static void C_ccall f_11822(C_word c,C_word *av) C_noret;
C_noret_decl(f_11828)
static void C_fcall f_11828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14152)
static void C_fcall f_14152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_fcall f_9424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word *av) C_noret;
C_noret_decl(f_11816)
static void C_ccall f_11816(C_word c,C_word *av) C_noret;
C_noret_decl(f_7070)
static void C_fcall f_7070(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16034)
static void C_ccall f_16034(C_word c,C_word *av) C_noret;
C_noret_decl(f_11174)
static void C_ccall f_11174(C_word c,C_word *av) C_noret;
C_noret_decl(f_11800)
static void C_ccall f_11800(C_word c,C_word *av) C_noret;
C_noret_decl(f_11168)
static void C_ccall f_11168(C_word c,C_word *av) C_noret;
C_noret_decl(f_14826)
static void C_ccall f_14826(C_word c,C_word *av) C_noret;
C_noret_decl(f_13775)
static void C_ccall f_13775(C_word c,C_word *av) C_noret;
C_noret_decl(f_13370)
static void C_fcall f_13370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13382)
static void C_fcall f_13382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13388)
static void C_ccall f_13388(C_word c,C_word *av) C_noret;
C_noret_decl(f_15118)
static void C_ccall f_15118(C_word c,C_word *av) C_noret;
C_noret_decl(f_15111)
static void C_ccall f_15111(C_word c,C_word *av) C_noret;
C_noret_decl(f_15114)
static void C_ccall f_15114(C_word c,C_word *av) C_noret;
C_noret_decl(f_16005)
static void C_ccall f_16005(C_word c,C_word *av) C_noret;
C_noret_decl(f_13360)
static void C_ccall f_13360(C_word c,C_word *av) C_noret;
C_noret_decl(f_11027)
static void C_fcall f_11027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11010)
static void C_ccall f_11010(C_word c,C_word *av) C_noret;
C_noret_decl(f_13392)
static void C_fcall f_13392(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14836)
static void C_ccall f_14836(C_word c,C_word *av) C_noret;
C_noret_decl(f_14832)
static void C_ccall f_14832(C_word c,C_word *av) C_noret;
C_noret_decl(f_14862)
static void C_ccall f_14862(C_word c,C_word *av) C_noret;
C_noret_decl(f_11049)
static void C_ccall f_11049(C_word c,C_word *av) C_noret;
C_noret_decl(f_15190)
static void C_ccall f_15190(C_word c,C_word *av) C_noret;
C_noret_decl(f_15192)
static void C_fcall f_15192(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15163)
static void C_ccall f_15163(C_word c,C_word *av) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word *av) C_noret;
C_noret_decl(f_15105)
static void C_ccall f_15105(C_word c,C_word *av) C_noret;
C_noret_decl(f_15108)
static void C_ccall f_15108(C_word c,C_word *av) C_noret;
C_noret_decl(f_15102)
static void C_ccall f_15102(C_word c,C_word *av) C_noret;
C_noret_decl(f_10672)
static void C_ccall f_10672(C_word c,C_word *av) C_noret;
C_noret_decl(f_11868)
static void C_fcall f_11868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11853)
static void C_fcall f_11853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word *av) C_noret;
C_noret_decl(f_9943)
static void C_ccall f_9943(C_word c,C_word *av) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word *av) C_noret;
C_noret_decl(f_9940)
static void C_ccall f_9940(C_word c,C_word *av) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word *av) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word *av) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word *av) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word *av) C_noret;
C_noret_decl(f_9316)
static void C_fcall f_9316(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9996)
static void C_ccall f_9996(C_word c,C_word *av) C_noret;
C_noret_decl(f_9999)
static void C_ccall f_9999(C_word c,C_word *av) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word *av) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word *av) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word *av) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word *av) C_noret;
C_noret_decl(f_6615)
static void C_ccall f_6615(C_word c,C_word *av) C_noret;
C_noret_decl(f_5133)
static void C_fcall f_5133(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word *av) C_noret;
C_noret_decl(f_13781)
static void C_ccall f_13781(C_word c,C_word *av) C_noret;
C_noret_decl(f_9372)
static void C_fcall f_9372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9972)
static void C_ccall f_9972(C_word c,C_word *av) C_noret;
C_noret_decl(f_5129)
static void C_fcall f_5129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word *av) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word *av) C_noret;
C_noret_decl(f_9980)
static void C_ccall f_9980(C_word c,C_word *av) C_noret;
C_noret_decl(f_9386)
static void C_ccall f_9386(C_word c,C_word *av) C_noret;
C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_13785)
static void C_ccall f_13785(C_word c,C_word *av) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word *av) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word *av) C_noret;
C_noret_decl(f_5049)
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word *av) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word *av) C_noret;
C_noret_decl(f_6747)
static void C_fcall f_6747(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word *av) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word *av) C_noret;
C_noret_decl(f_16300)
static void C_ccall f_16300(C_word c,C_word *av) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word *av) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word *av) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word *av) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word *av) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word *av) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word *av) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word *av) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word *av) C_noret;
C_noret_decl(f_8820)
static void C_fcall f_8820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_fcall f_6751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11098)
static void C_ccall f_11098(C_word c,C_word *av) C_noret;
C_noret_decl(f_16309)
static void C_ccall f_16309(C_word c,C_word *av) C_noret;
C_noret_decl(f_16306)
static void C_ccall f_16306(C_word c,C_word *av) C_noret;
C_noret_decl(f_16303)
static void C_ccall f_16303(C_word c,C_word *av) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word *av) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word *av) C_noret;
C_noret_decl(f_12113)
static void C_fcall f_12113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12116)
static void C_ccall f_12116(C_word c,C_word *av) C_noret;
C_noret_decl(f_8833)
static void C_ccall f_8833(C_word c,C_word *av) C_noret;
C_noret_decl(f_8835)
static void C_fcall f_8835(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8860)
static void C_ccall f_8860(C_word c,C_word *av) C_noret;
C_noret_decl(f_7811)
static void C_fcall f_7811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word *av) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word *av) C_noret;
C_noret_decl(f_8892)
static void C_fcall f_8892(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5575)
static void C_fcall f_5575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word *av) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word *av) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15631)
static void C_ccall f_15631(C_word c,C_word *av) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word *av) C_noret;
C_noret_decl(f_15645)
static void C_ccall f_15645(C_word c,C_word *av) C_noret;
C_noret_decl(f_15926)
static void C_ccall f_15926(C_word c,C_word *av) C_noret;
C_noret_decl(f_15929)
static void C_ccall f_15929(C_word c,C_word *av) C_noret;
C_noret_decl(f_11067)
static void C_fcall f_11067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15971)
static void C_ccall f_15971(C_word c,C_word *av) C_noret;
C_noret_decl(f_5546)
static void C_fcall f_5546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word *av) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word *av) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word *av) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word *av) C_noret;
C_noret_decl(f_15941)
static void C_ccall f_15941(C_word c,C_word *av) C_noret;
C_noret_decl(f_15945)
static void C_ccall f_15945(C_word c,C_word *av) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word *av) C_noret;
C_noret_decl(f_15916)
static void C_ccall f_15916(C_word c,C_word *av) C_noret;
C_noret_decl(f_15910)
static void C_ccall f_15910(C_word c,C_word *av) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word *av) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word *av) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word *av) C_noret;
C_noret_decl(f_9390)
static void C_ccall f_9390(C_word c,C_word *av) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word *av) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word *av) C_noret;
C_noret_decl(f_10640)
static void C_ccall f_10640(C_word c,C_word *av) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word *av) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word *av) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word *av) C_noret;
C_noret_decl(f_10654)
static void C_ccall f_10654(C_word c,C_word *av) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word *av) C_noret;
C_noret_decl(f_15982)
static void C_ccall f_15982(C_word c,C_word *av) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word *av) C_noret;
C_noret_decl(f_10662)
static void C_fcall f_10662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word *av) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word *av) C_noret;
C_noret_decl(f_6670)
static void C_fcall f_6670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15950)
static void C_fcall f_15950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15954)
static void C_ccall f_15954(C_word c,C_word *av) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word *av) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word *av) C_noret;
C_noret_decl(f_5151)
static void C_fcall f_5151(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10962)
static C_word C_fcall f_10962(C_word t0,C_word t1);
C_noret_decl(f_5143)
static void C_ccall f_5143(C_word c,C_word *av) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word *av) C_noret;
C_noret_decl(f_14735)
static void C_ccall f_14735(C_word c,C_word *av) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word *av) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word *av) C_noret;
C_noret_decl(f_15255)
static void C_ccall f_15255(C_word c,C_word *av) C_noret;
C_noret_decl(f_15259)
static void C_ccall f_15259(C_word c,C_word *av) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word *av) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word *av) C_noret;
C_noret_decl(f_10945)
static void C_ccall f_10945(C_word c,C_word *av) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word *av) C_noret;
C_noret_decl(f_14717)
static void C_fcall f_14717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15997)
static void C_ccall f_15997(C_word c,C_word *av) C_noret;
C_noret_decl(f_15994)
static void C_ccall f_15994(C_word c,C_word *av) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word *av) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word *av) C_noret;
C_noret_decl(f_10142)
static void C_ccall f_10142(C_word c,C_word *av) C_noret;
C_noret_decl(f_5017)
static void C_fcall f_5017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5015)
static void C_fcall f_5015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10954)
static void C_fcall f_10954(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7435)
static void C_ccall f_7435(C_word c,C_word *av) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word *av) C_noret;
C_noret_decl(f_10951)
static void C_ccall f_10951(C_word c,C_word *av) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word *av) C_noret;
C_noret_decl(f_10150)
static void C_ccall f_10150(C_word c,C_word *av) C_noret;
C_noret_decl(f_11557)
static C_word C_fcall f_11557(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word *av) C_noret;
C_noret_decl(f_11550)
static void C_ccall f_11550(C_word c,C_word *av) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word *av) C_noret;
C_noret_decl(f_14773)
static void C_fcall f_14773(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14770)
static void C_ccall f_14770(C_word c,C_word *av) C_noret;
C_noret_decl(f_11546)
static void C_ccall f_11546(C_word c,C_word *av) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word *av) C_noret;
C_noret_decl(f_15295)
static void C_ccall f_15295(C_word c,C_word *av) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word *av) C_noret;
C_noret_decl(f_15292)
static void C_ccall f_15292(C_word c,C_word *av) C_noret;
C_noret_decl(f_10934)
static void C_ccall f_10934(C_word c,C_word *av) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word *av) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word *av) C_noret;
C_noret_decl(f_10901)
static void C_ccall f_10901(C_word c,C_word *av) C_noret;
C_noret_decl(f_10907)
static void C_fcall f_10907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15229)
static void C_ccall f_15229(C_word c,C_word *av) C_noret;
C_noret_decl(f_12840)
static void C_ccall f_12840(C_word c,C_word *av) C_noret;
C_noret_decl(f_10911)
static void C_ccall f_10911(C_word c,C_word *av) C_noret;
C_noret_decl(f_12853)
static void C_ccall f_12853(C_word c,C_word *av) C_noret;
C_noret_decl(f_15244)
static void C_ccall f_15244(C_word c,C_word *av) C_noret;
C_noret_decl(f_15248)
static void C_ccall f_15248(C_word c,C_word *av) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word *av) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word *av) C_noret;
C_noret_decl(f_12877)
static void C_ccall f_12877(C_word c,C_word *av) C_noret;
C_noret_decl(f_12871)
static void C_ccall f_12871(C_word c,C_word *av) C_noret;
C_noret_decl(f_11535)
static void C_ccall f_11535(C_word c,C_word *av) C_noret;
C_noret_decl(f_6483)
static void C_fcall f_6483(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11523)
static void C_ccall f_11523(C_word c,C_word *av) C_noret;
C_noret_decl(f_11525)
static void C_ccall f_11525(C_word c,C_word *av) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word *av) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word *av) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word *av) C_noret;
C_noret_decl(f_10123)
static void C_ccall f_10123(C_word c,C_word *av) C_noret;
C_noret_decl(f_14725)
static void C_fcall f_14725(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10134)
static void C_ccall f_10134(C_word c,C_word *av) C_noret;
C_noret_decl(f_5852)
static void C_ccall f_5852(C_word c,C_word *av) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word *av) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word *av) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word *av) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word *av) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word *av) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word *av) C_noret;
C_noret_decl(f_10060)
static void C_ccall f_10060(C_word c,C_word *av) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word *av) C_noret;
C_noret_decl(f_14049)
static void C_ccall f_14049(C_word c,C_word *av) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word *av) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word *av) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word *av) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word *av) C_noret;
C_noret_decl(f_10069)
static void C_ccall f_10069(C_word c,C_word *av) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word *av) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word *av) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word *av) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word *av) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word *av) C_noret;
C_noret_decl(f_10086)
static void C_fcall f_10086(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word *av) C_noret;
C_noret_decl(f_13425)
static void C_fcall f_13425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word *av) C_noret;
C_noret_decl(f_15206)
static void C_ccall f_15206(C_word c,C_word *av) C_noret;
C_noret_decl(f_10098)
static void C_fcall f_10098(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10096)
static void C_ccall f_10096(C_word c,C_word *av) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word *av) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word *av) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word *av) C_noret;
C_noret_decl(f_16244)
static void C_ccall f_16244(C_word c,C_word *av) C_noret;
C_noret_decl(f_16248)
static void C_ccall f_16248(C_word c,C_word *av) C_noret;
C_noret_decl(f_9175)
static void C_ccall f_9175(C_word c,C_word *av) C_noret;
C_noret_decl(f_16241)
static void C_ccall f_16241(C_word c,C_word *av) C_noret;
C_noret_decl(f_9183)
static void C_fcall f_9183(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5944)
static void C_ccall f_5944(C_word c,C_word *av) C_noret;
C_noret_decl(f_5948)
static void C_fcall f_5948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023(C_word c,C_word *av) C_noret;
C_noret_decl(f_16287)
static void C_ccall f_16287(C_word c,C_word *av) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word *av) C_noret;
C_noret_decl(f_16282)
static void C_ccall f_16282(C_word c,C_word *av) C_noret;
C_noret_decl(f_15264)
static void C_ccall f_15264(C_word c,C_word *av) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003(C_word c,C_word *av) C_noret;
C_noret_decl(f_15268)
static void C_ccall f_15268(C_word c,C_word *av) C_noret;
C_noret_decl(f_16235)
static void C_ccall f_16235(C_word c,C_word *av) C_noret;
C_noret_decl(f_12809)
static void C_ccall f_12809(C_word c,C_word *av) C_noret;
C_noret_decl(f_16238)
static void C_ccall f_16238(C_word c,C_word *av) C_noret;
C_noret_decl(f_12803)
static void C_ccall f_12803(C_word c,C_word *av) C_noret;
C_noret_decl(f_16232)
static void C_ccall f_16232(C_word c,C_word *av) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word *av) C_noret;
C_noret_decl(f_15276)
static void C_ccall f_15276(C_word c,C_word *av) C_noret;
C_noret_decl(f_16226)
static void C_ccall f_16226(C_word c,C_word *av) C_noret;
C_noret_decl(f_5807)
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word *av) C_noret;
C_noret_decl(f_6460)
static void C_fcall f_6460(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15282)
static void C_ccall f_15282(C_word c,C_word *av) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word *av) C_noret;
C_noret_decl(f_15289)
static void C_ccall f_15289(C_word c,C_word *av) C_noret;
C_noret_decl(f_16257)
static void C_ccall f_16257(C_word c,C_word *av) C_noret;
C_noret_decl(f_12822)
static void C_ccall f_12822(C_word c,C_word *av) C_noret;
C_noret_decl(f_16250)
static void C_ccall f_16250(C_word c,C_word *av) C_noret;
C_noret_decl(f_15216)
static void C_ccall f_15216(C_word c,C_word *av) C_noret;
C_noret_decl(f_8011)
static void C_ccall f_8011(C_word c,C_word *av) C_noret;
C_noret_decl(f_8015)
static void C_ccall f_8015(C_word c,C_word *av) C_noret;
C_noret_decl(f_9852)
static void C_ccall f_9852(C_word c,C_word *av) C_noret;
C_noret_decl(f_10988)
static void C_fcall f_10988(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8044)
static void C_ccall f_8044(C_word c,C_word *av) C_noret;
C_noret_decl(f_8048)
static void C_ccall f_8048(C_word c,C_word *av) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word *av) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word *av) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word *av) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word *av) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word *av) C_noret;
C_noret_decl(f_6853)
static void C_fcall f_6853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10553)
static void C_ccall f_10553(C_word c,C_word *av) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word *av) C_noret;
C_noret_decl(f_12885)
static void C_fcall f_12885(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8087)
static void C_fcall f_8087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10834)
static void C_ccall f_10834(C_word c,C_word *av) C_noret;
C_noret_decl(f_12881)
static void C_ccall f_12881(C_word c,C_word *av) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word *av) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word *av) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word *av) C_noret;
C_noret_decl(f_9827)
static void C_fcall f_9827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11951)
static void C_fcall f_11951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word *av) C_noret;
C_noret_decl(f_5492)
static void C_fcall f_5492(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word *av) C_noret;
C_noret_decl(f_9882)
static void C_fcall f_9882(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word *av) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word *av) C_noret;
C_noret_decl(f_10860)
static void C_ccall f_10860(C_word c,C_word *av) C_noret;
C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word *av) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word *av) C_noret;
C_noret_decl(f_6815)
static void C_fcall f_6815(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11636)
static void C_fcall f_11636(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word *av) C_noret;
C_noret_decl(f_9861)
static void C_ccall f_9861(C_word c,C_word *av) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word *av) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word *av) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word *av) C_noret;
C_noret_decl(f_6877)
static void C_ccall f_6877(C_word c,C_word *av) C_noret;
C_noret_decl(f_12971)
static void C_ccall f_12971(C_word c,C_word *av) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word *av) C_noret;
C_noret_decl(f_10893)
static void C_ccall f_10893(C_word c,C_word *av) C_noret;
C_noret_decl(f_16211)
static void C_ccall f_16211(C_word c,C_word *av) C_noret;
C_noret_decl(f_12245)
static void C_ccall f_12245(C_word c,C_word *av) C_noret;
C_noret_decl(f_12249)
static void C_fcall f_12249(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521(C_word c,C_word *av) C_noret;
C_noret_decl(f_11936)
static void C_ccall f_11936(C_word c,C_word *av) C_noret;
C_noret_decl(f_11687)
static void C_ccall f_11687(C_word c,C_word *av) C_noret;
C_noret_decl(f_11684)
static void C_ccall f_11684(C_word c,C_word *av) C_noret;
C_noret_decl(f_9813)
static void C_ccall f_9813(C_word c,C_word *av) C_noret;
C_noret_decl(f_8589)
static void C_ccall f_8589(C_word c,C_word *av) C_noret;
C_noret_decl(f_12975)
static void C_fcall f_12975(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11678)
static void C_ccall f_11678(C_word c,C_word *av) C_noret;
C_noret_decl(f_11671)
static void C_ccall f_11671(C_word c,C_word *av) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word *av) C_noret;
C_noret_decl(f_11665)
static void C_ccall f_11665(C_word c,C_word *av) C_noret;
C_noret_decl(f_11659)
static void C_ccall f_11659(C_word c,C_word *av) C_noret;
C_noret_decl(f_7767)
static void C_ccall f_7767(C_word c,C_word *av) C_noret;
C_noret_decl(f_8564)
static void C_fcall f_8564(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word *av) C_noret;
C_noret_decl(f_8368)
static void C_ccall f_8368(C_word c,C_word *av) C_noret;
C_noret_decl(f_5340)
static void C_fcall f_5340(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16279)
static void C_ccall f_16279(C_word c,C_word *av) C_noret;
C_noret_decl(f_16275)
static void C_ccall f_16275(C_word c,C_word *av) C_noret;
C_noret_decl(f_12922)
static void C_ccall f_12922(C_word c,C_word *av) C_noret;
C_noret_decl(f_16264)
static void C_ccall f_16264(C_word c,C_word *av) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word *av) C_noret;
C_noret_decl(f_12916)
static void C_ccall f_12916(C_word c,C_word *av) C_noret;
C_noret_decl(f_16293)
static void C_ccall f_16293(C_word c,C_word *av) C_noret;
C_noret_decl(f_10818)
static void C_fcall f_10818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10815)
static void C_ccall f_10815(C_word c,C_word *av) C_noret;
C_noret_decl(f_16201)
static void C_fcall f_16201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word *av) C_noret;
C_noret_decl(f_11398)
static void C_ccall f_11398(C_word c,C_word *av) C_noret;
C_noret_decl(f_10526)
static void C_ccall f_10526(C_word c,C_word *av) C_noret;
C_noret_decl(f_10528)
static void C_fcall f_10528(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word *av) C_noret;
C_noret_decl(f_7750)
static void C_fcall f_7750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12202)
static void C_fcall f_12202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12910)
static void C_ccall f_12910(C_word c,C_word *av) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word *av) C_noret;
C_noret_decl(f_7741)
static void C_ccall f_7741(C_word c,C_word *av) C_noret;
C_noret_decl(f_8539)
static void C_ccall f_8539(C_word c,C_word *av) C_noret;
C_noret_decl(f_13901)
static void C_fcall f_13901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word *av) C_noret;
C_noret_decl(f_8533)
static void C_ccall f_8533(C_word c,C_word *av) C_noret;
C_noret_decl(f_10213)
static void C_fcall f_10213(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4960)
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word *av) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word *av) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word *av) C_noret;
C_noret_decl(f_8101)
static void C_fcall f_8101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word *av) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word *av) C_noret;
C_noret_decl(f_5374)
static void C_fcall f_5374(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4937)
static void C_fcall f_4937(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10257)
static void C_ccall f_10257(C_word c,C_word *av) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word *av) C_noret;
C_noret_decl(f_13929)
static void C_ccall f_13929(C_word c,C_word *av) C_noret;
C_noret_decl(f_13342)
static void C_ccall f_13342(C_word c,C_word *av) C_noret;
C_noret_decl(f_13348)
static void C_ccall f_13348(C_word c,C_word *av) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word *av) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word *av) C_noret;
C_noret_decl(f_10597)
static void C_ccall f_10597(C_word c,C_word *av) C_noret;
C_noret_decl(f_10599)
static void C_fcall f_10599(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_11991)
static void C_ccall trf_11991(C_word c,C_word *av) C_noret;
static void C_ccall trf_11991(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11991(t0,t1);}

C_noret_decl(trf_12059)
static void C_ccall trf_12059(C_word c,C_word *av) C_noret;
static void C_ccall trf_12059(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12059(t0,t1);}

C_noret_decl(trf_4895)
static void C_ccall trf_4895(C_word c,C_word *av) C_noret;
static void C_ccall trf_4895(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4895(t0,t1);}

C_noret_decl(trf_8188)
static void C_ccall trf_8188(C_word c,C_word *av) C_noret;
static void C_ccall trf_8188(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8188(t0,t1,t2);}

C_noret_decl(trf_12175)
static void C_ccall trf_12175(C_word c,C_word *av) C_noret;
static void C_ccall trf_12175(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12175(t0,t1);}

C_noret_decl(trf_9759)
static void C_ccall trf_9759(C_word c,C_word *av) C_noret;
static void C_ccall trf_9759(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9759(t0,t1);}

C_noret_decl(trf_12157)
static void C_ccall trf_12157(C_word c,C_word *av) C_noret;
static void C_ccall trf_12157(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12157(t0,t1);}

C_noret_decl(trf_12953)
static void C_ccall trf_12953(C_word c,C_word *av) C_noret;
static void C_ccall trf_12953(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12953(t0,t1);}

C_noret_decl(trf_12965)
static void C_ccall trf_12965(C_word c,C_word *av) C_noret;
static void C_ccall trf_12965(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12965(t0,t1);}

C_noret_decl(trf_12932)
static void C_ccall trf_12932(C_word c,C_word *av) C_noret;
static void C_ccall trf_12932(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12932(t0,t1);}

C_noret_decl(trf_12941)
static void C_ccall trf_12941(C_word c,C_word *av) C_noret;
static void C_ccall trf_12941(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12941(t0,t1);}

C_noret_decl(trf_14248)
static void C_ccall trf_14248(C_word c,C_word *av) C_noret;
static void C_ccall trf_14248(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14248(t0,t1);}

C_noret_decl(trf_12086)
static void C_ccall trf_12086(C_word c,C_word *av) C_noret;
static void C_ccall trf_12086(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12086(t0,t1);}

C_noret_decl(trf_14227)
static void C_ccall trf_14227(C_word c,C_word *av) C_noret;
static void C_ccall trf_14227(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14227(t0,t1);}

C_noret_decl(trf_5714)
static void C_ccall trf_5714(C_word c,C_word *av) C_noret;
static void C_ccall trf_5714(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5714(t0,t1);}

C_noret_decl(trf_7777)
static void C_ccall trf_7777(C_word c,C_word *av) C_noret;
static void C_ccall trf_7777(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7777(t0,t1,t2);}

C_noret_decl(trf_11790)
static void C_ccall trf_11790(C_word c,C_word *av) C_noret;
static void C_ccall trf_11790(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11790(t0,t1,t2);}

C_noret_decl(trf_6052)
static void C_ccall trf_6052(C_word c,C_word *av) C_noret;
static void C_ccall trf_6052(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6052(t0,t1,t2);}

C_noret_decl(trf_9012)
static void C_ccall trf_9012(C_word c,C_word *av) C_noret;
static void C_ccall trf_9012(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9012(t0,t1,t2,t3);}

C_noret_decl(trf_7149)
static void C_ccall trf_7149(C_word c,C_word *av) C_noret;
static void C_ccall trf_7149(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7149(t0,t1);}

C_noret_decl(trf_6506)
static void C_ccall trf_6506(C_word c,C_word *av) C_noret;
static void C_ccall trf_6506(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6506(t0,t1,t2);}

C_noret_decl(trf_9060)
static void C_ccall trf_9060(C_word c,C_word *av) C_noret;
static void C_ccall trf_9060(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9060(t0,t1,t2);}

C_noret_decl(trf_10165)
static void C_ccall trf_10165(C_word c,C_word *av) C_noret;
static void C_ccall trf_10165(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10165(t0,t1,t2,t3);}

C_noret_decl(trf_6076)
static void C_ccall trf_6076(C_word c,C_word *av) C_noret;
static void C_ccall trf_6076(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6076(t0,t1);}

C_noret_decl(trf_14661)
static void C_ccall trf_14661(C_word c,C_word *av) C_noret;
static void C_ccall trf_14661(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14661(t0,t1,t2);}

C_noret_decl(trf_5761)
static void C_ccall trf_5761(C_word c,C_word *av) C_noret;
static void C_ccall trf_5761(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5761(t0,t1,t2);}

C_noret_decl(trf_14653)
static void C_ccall trf_14653(C_word c,C_word *av) C_noret;
static void C_ccall trf_14653(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14653(t0,t1);}

C_noret_decl(trf_10723)
static void C_ccall trf_10723(C_word c,C_word *av) C_noret;
static void C_ccall trf_10723(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10723(t0,t1,t2);}

C_noret_decl(trf_6955)
static void C_ccall trf_6955(C_word c,C_word *av) C_noret;
static void C_ccall trf_6955(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6955(t0,t1);}

C_noret_decl(trf_9555)
static void C_ccall trf_9555(C_word c,C_word *av) C_noret;
static void C_ccall trf_9555(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9555(t0,t1,t2);}

C_noret_decl(trf_5269)
static void C_ccall trf_5269(C_word c,C_word *av) C_noret;
static void C_ccall trf_5269(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5269(t0,t1);}

C_noret_decl(trf_6918)
static void C_ccall trf_6918(C_word c,C_word *av) C_noret;
static void C_ccall trf_6918(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6918(t0,t1);}

C_noret_decl(trf_5231)
static void C_ccall trf_5231(C_word c,C_word *av) C_noret;
static void C_ccall trf_5231(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5231(t0,t1,t2);}

C_noret_decl(trf_9504)
static void C_ccall trf_9504(C_word c,C_word *av) C_noret;
static void C_ccall trf_9504(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9504(t0,t1,t2);}

C_noret_decl(trf_12282)
static void C_ccall trf_12282(C_word c,C_word *av) C_noret;
static void C_ccall trf_12282(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12282(t0,t1);}

C_noret_decl(trf_8433)
static void C_ccall trf_8433(C_word c,C_word *av) C_noret;
static void C_ccall trf_8433(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8433(t0,t1,t2);}

C_noret_decl(trf_14077)
static void C_ccall trf_14077(C_word c,C_word *av) C_noret;
static void C_ccall trf_14077(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14077(t0,t1);}

C_noret_decl(trf_8600)
static void C_ccall trf_8600(C_word c,C_word *av) C_noret;
static void C_ccall trf_8600(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8600(t0,t1);}

C_noret_decl(trf_8496)
static void C_ccall trf_8496(C_word c,C_word *av) C_noret;
static void C_ccall trf_8496(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8496(t0,t1,t2);}

C_noret_decl(trf_14685)
static void C_ccall trf_14685(C_word c,C_word *av) C_noret;
static void C_ccall trf_14685(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14685(t0,t1);}

C_noret_decl(trf_15010)
static void C_ccall trf_15010(C_word c,C_word *av) C_noret;
static void C_ccall trf_15010(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15010(t0,t1);}

C_noret_decl(trf_8405)
static void C_ccall trf_8405(C_word c,C_word *av) C_noret;
static void C_ccall trf_8405(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8405(t0,t1);}

C_noret_decl(trf_5290)
static void C_ccall trf_5290(C_word c,C_word *av) C_noret;
static void C_ccall trf_5290(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5290(t0,t1,t2,t3);}

C_noret_decl(trf_10781)
static void C_ccall trf_10781(C_word c,C_word *av) C_noret;
static void C_ccall trf_10781(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10781(t0,t1);}

C_noret_decl(trf_15036)
static void C_ccall trf_15036(C_word c,C_word *av) C_noret;
static void C_ccall trf_15036(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15036(t0,t1,t2);}

C_noret_decl(trf_14971)
static void C_ccall trf_14971(C_word c,C_word *av) C_noret;
static void C_ccall trf_14971(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14971(t0,t1,t2);}

C_noret_decl(trf_6992)
static void C_ccall trf_6992(C_word c,C_word *av) C_noret;
static void C_ccall trf_6992(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6992(t0,t1);}

C_noret_decl(trf_11200)
static void C_ccall trf_11200(C_word c,C_word *av) C_noret;
static void C_ccall trf_11200(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11200(t0,t1);}

C_noret_decl(trf_8299)
static void C_ccall trf_8299(C_word c,C_word *av) C_noret;
static void C_ccall trf_8299(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8299(t0,t1,t2);}

C_noret_decl(trf_10375)
static void C_ccall trf_10375(C_word c,C_word *av) C_noret;
static void C_ccall trf_10375(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10375(t0,t1,t2);}

C_noret_decl(trf_9664)
static void C_ccall trf_9664(C_word c,C_word *av) C_noret;
static void C_ccall trf_9664(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9664(t0,t1,t2);}

C_noret_decl(trf_14288)
static void C_ccall trf_14288(C_word c,C_word *av) C_noret;
static void C_ccall trf_14288(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14288(t0,t1);}

C_noret_decl(trf_14266)
static void C_ccall trf_14266(C_word c,C_word *av) C_noret;
static void C_ccall trf_14266(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14266(t0,t1);}

C_noret_decl(trf_11411)
static void C_ccall trf_11411(C_word c,C_word *av) C_noret;
static void C_ccall trf_11411(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11411(t0,t1);}

C_noret_decl(trf_10321)
static void C_ccall trf_10321(C_word c,C_word *av) C_noret;
static void C_ccall trf_10321(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10321(t0,t1,t2,t3);}

C_noret_decl(trf_11452)
static void C_ccall trf_11452(C_word c,C_word *av) C_noret;
static void C_ccall trf_11452(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11452(t0,t1);}

C_noret_decl(trf_8730)
static void C_ccall trf_8730(C_word c,C_word *av) C_noret;
static void C_ccall trf_8730(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8730(t0,t1,t2);}

C_noret_decl(trf_6167)
static void C_ccall trf_6167(C_word c,C_word *av) C_noret;
static void C_ccall trf_6167(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6167(t0,t1);}

C_noret_decl(trf_10262)
static void C_ccall trf_10262(C_word c,C_word *av) C_noret;
static void C_ccall trf_10262(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10262(t0,t1,t2);}

C_noret_decl(trf_15719)
static void C_ccall trf_15719(C_word c,C_word *av) C_noret;
static void C_ccall trf_15719(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_15719(t0,t1,t2,t3);}

C_noret_decl(trf_7614)
static void C_ccall trf_7614(C_word c,C_word *av) C_noret;
static void C_ccall trf_7614(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7614(t0,t1,t2);}

C_noret_decl(trf_9259)
static void C_ccall trf_9259(C_word c,C_word *av) C_noret;
static void C_ccall trf_9259(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9259(t0,t1,t2);}

C_noret_decl(trf_7046)
static void C_ccall trf_7046(C_word c,C_word *av) C_noret;
static void C_ccall trf_7046(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7046(t0,t1,t2);}

C_noret_decl(trf_10274)
static void C_ccall trf_10274(C_word c,C_word *av) C_noret;
static void C_ccall trf_10274(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10274(t0,t1,t2);}

C_noret_decl(trf_15811)
static void C_ccall trf_15811(C_word c,C_word *av) C_noret;
static void C_ccall trf_15811(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15811(t0,t1,t2);}

C_noret_decl(trf_7937)
static void C_ccall trf_7937(C_word c,C_word *av) C_noret;
static void C_ccall trf_7937(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_7937(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15772)
static void C_ccall trf_15772(C_word c,C_word *av) C_noret;
static void C_ccall trf_15772(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15772(t0,t1,t2);}

C_noret_decl(trf_14959)
static void C_ccall trf_14959(C_word c,C_word *av) C_noret;
static void C_ccall trf_14959(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14959(t0,t1,t2);}

C_noret_decl(trf_14957)
static void C_ccall trf_14957(C_word c,C_word *av) C_noret;
static void C_ccall trf_14957(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_14957(t0,t1,t2,t3);}

C_noret_decl(trf_15563)
static void C_ccall trf_15563(C_word c,C_word *av) C_noret;
static void C_ccall trf_15563(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15563(t0,t1,t2);}

C_noret_decl(trf_7665)
static void C_ccall trf_7665(C_word c,C_word *av) C_noret;
static void C_ccall trf_7665(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7665(t0,t1);}

C_noret_decl(trf_15874)
static void C_ccall trf_15874(C_word c,C_word *av) C_noret;
static void C_ccall trf_15874(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15874(t0,t1);}

C_noret_decl(trf_15597)
static void C_ccall trf_15597(C_word c,C_word *av) C_noret;
static void C_ccall trf_15597(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15597(t0,t1,t2);}

C_noret_decl(trf_15844)
static void C_ccall trf_15844(C_word c,C_word *av) C_noret;
static void C_ccall trf_15844(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15844(t0,t1,t2);}

C_noret_decl(trf_10053)
static void C_ccall trf_10053(C_word c,C_word *av) C_noret;
static void C_ccall trf_10053(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10053(t0,t1,t2);}

C_noret_decl(trf_15147)
static void C_ccall trf_15147(C_word c,C_word *av) C_noret;
static void C_ccall trf_15147(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15147(t0,t1);}

C_noret_decl(trf_9444)
static void C_ccall trf_9444(C_word c,C_word *av) C_noret;
static void C_ccall trf_9444(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9444(t0,t1,t2);}

C_noret_decl(trf_12009)
static void C_ccall trf_12009(C_word c,C_word *av) C_noret;
static void C_ccall trf_12009(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12009(t0,t1);}

C_noret_decl(trf_12033)
static void C_ccall trf_12033(C_word c,C_word *av) C_noret;
static void C_ccall trf_12033(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12033(t0,t1);}

C_noret_decl(trf_14807)
static void C_ccall trf_14807(C_word c,C_word *av) C_noret;
static void C_ccall trf_14807(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14807(t0,t1);}

C_noret_decl(trf_6208)
static void C_ccall trf_6208(C_word c,C_word *av) C_noret;
static void C_ccall trf_6208(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6208(t0,t1,t2);}

C_noret_decl(trf_11828)
static void C_ccall trf_11828(C_word c,C_word *av) C_noret;
static void C_ccall trf_11828(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11828(t0,t1,t2);}

C_noret_decl(trf_14152)
static void C_ccall trf_14152(C_word c,C_word *av) C_noret;
static void C_ccall trf_14152(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14152(t0,t1);}

C_noret_decl(trf_9424)
static void C_ccall trf_9424(C_word c,C_word *av) C_noret;
static void C_ccall trf_9424(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9424(t0,t1);}

C_noret_decl(trf_7070)
static void C_ccall trf_7070(C_word c,C_word *av) C_noret;
static void C_ccall trf_7070(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7070(t0,t1);}

C_noret_decl(trf_13370)
static void C_ccall trf_13370(C_word c,C_word *av) C_noret;
static void C_ccall trf_13370(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13370(t0,t1);}

C_noret_decl(trf_13382)
static void C_ccall trf_13382(C_word c,C_word *av) C_noret;
static void C_ccall trf_13382(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13382(t0,t1);}

C_noret_decl(trf_11027)
static void C_ccall trf_11027(C_word c,C_word *av) C_noret;
static void C_ccall trf_11027(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11027(t0,t1,t2,t3);}

C_noret_decl(trf_13392)
static void C_ccall trf_13392(C_word c,C_word *av) C_noret;
static void C_ccall trf_13392(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_13392(t0,t1,t2);}

C_noret_decl(trf_15192)
static void C_ccall trf_15192(C_word c,C_word *av) C_noret;
static void C_ccall trf_15192(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_15192(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11868)
static void C_ccall trf_11868(C_word c,C_word *av) C_noret;
static void C_ccall trf_11868(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11868(t0,t1);}

C_noret_decl(trf_11853)
static void C_ccall trf_11853(C_word c,C_word *av) C_noret;
static void C_ccall trf_11853(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11853(t0,t1);}

C_noret_decl(trf_9316)
static void C_ccall trf_9316(C_word c,C_word *av) C_noret;
static void C_ccall trf_9316(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9316(t0,t1,t2);}

C_noret_decl(trf_5133)
static void C_ccall trf_5133(C_word c,C_word *av) C_noret;
static void C_ccall trf_5133(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5133(t0,t1,t2);}

C_noret_decl(trf_9372)
static void C_ccall trf_9372(C_word c,C_word *av) C_noret;
static void C_ccall trf_9372(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_9372(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5129)
static void C_ccall trf_5129(C_word c,C_word *av) C_noret;
static void C_ccall trf_5129(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5129(t0,t1);}

C_noret_decl(trf_5049)
static void C_ccall trf_5049(C_word c,C_word *av) C_noret;
static void C_ccall trf_5049(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5049(t0,t1,t2);}

C_noret_decl(trf_6747)
static void C_ccall trf_6747(C_word c,C_word *av) C_noret;
static void C_ccall trf_6747(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6747(t0,t1);}

C_noret_decl(trf_8820)
static void C_ccall trf_8820(C_word c,C_word *av) C_noret;
static void C_ccall trf_8820(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8820(t0,t1);}

C_noret_decl(trf_6751)
static void C_ccall trf_6751(C_word c,C_word *av) C_noret;
static void C_ccall trf_6751(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6751(t0,t1,t2);}

C_noret_decl(trf_12113)
static void C_ccall trf_12113(C_word c,C_word *av) C_noret;
static void C_ccall trf_12113(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12113(t0,t1);}

C_noret_decl(trf_8835)
static void C_ccall trf_8835(C_word c,C_word *av) C_noret;
static void C_ccall trf_8835(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8835(t0,t1,t2);}

C_noret_decl(trf_7811)
static void C_ccall trf_7811(C_word c,C_word *av) C_noret;
static void C_ccall trf_7811(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7811(t0,t1,t2);}

C_noret_decl(trf_8892)
static void C_ccall trf_8892(C_word c,C_word *av) C_noret;
static void C_ccall trf_8892(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8892(t0,t1,t2);}

C_noret_decl(trf_5575)
static void C_ccall trf_5575(C_word c,C_word *av) C_noret;
static void C_ccall trf_5575(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5575(t0,t1);}

C_noret_decl(trf_5568)
static void C_ccall trf_5568(C_word c,C_word *av) C_noret;
static void C_ccall trf_5568(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5568(t0,t1);}

C_noret_decl(trf_11067)
static void C_ccall trf_11067(C_word c,C_word *av) C_noret;
static void C_ccall trf_11067(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11067(t0,t1,t2,t3);}

C_noret_decl(trf_5546)
static void C_ccall trf_5546(C_word c,C_word *av) C_noret;
static void C_ccall trf_5546(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5546(t0,t1,t2);}

C_noret_decl(trf_10662)
static void C_ccall trf_10662(C_word c,C_word *av) C_noret;
static void C_ccall trf_10662(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10662(t0,t1,t2);}

C_noret_decl(trf_6670)
static void C_ccall trf_6670(C_word c,C_word *av) C_noret;
static void C_ccall trf_6670(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6670(t0,t1);}

C_noret_decl(trf_15950)
static void C_ccall trf_15950(C_word c,C_word *av) C_noret;
static void C_ccall trf_15950(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15950(t0,t1);}

C_noret_decl(trf_5151)
static void C_ccall trf_5151(C_word c,C_word *av) C_noret;
static void C_ccall trf_5151(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5151(t0,t1,t2);}

C_noret_decl(trf_14717)
static void C_ccall trf_14717(C_word c,C_word *av) C_noret;
static void C_ccall trf_14717(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14717(t0,t1);}

C_noret_decl(trf_5017)
static void C_ccall trf_5017(C_word c,C_word *av) C_noret;
static void C_ccall trf_5017(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5017(t0,t1,t2);}

C_noret_decl(trf_5015)
static void C_ccall trf_5015(C_word c,C_word *av) C_noret;
static void C_ccall trf_5015(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5015(t0,t1,t2);}

C_noret_decl(trf_10954)
static void C_ccall trf_10954(C_word c,C_word *av) C_noret;
static void C_ccall trf_10954(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10954(t0,t1,t2,t3);}

C_noret_decl(trf_14773)
static void C_ccall trf_14773(C_word c,C_word *av) C_noret;
static void C_ccall trf_14773(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_14773(t0,t1,t2,t3);}

C_noret_decl(trf_10907)
static void C_ccall trf_10907(C_word c,C_word *av) C_noret;
static void C_ccall trf_10907(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10907(t0,t1);}

C_noret_decl(trf_6483)
static void C_ccall trf_6483(C_word c,C_word *av) C_noret;
static void C_ccall trf_6483(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6483(t0,t1,t2);}

C_noret_decl(trf_14725)
static void C_ccall trf_14725(C_word c,C_word *av) C_noret;
static void C_ccall trf_14725(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14725(t0,t1,t2);}

C_noret_decl(trf_10086)
static void C_ccall trf_10086(C_word c,C_word *av) C_noret;
static void C_ccall trf_10086(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10086(t0,t1,t2);}

C_noret_decl(trf_13425)
static void C_ccall trf_13425(C_word c,C_word *av) C_noret;
static void C_ccall trf_13425(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13425(t0,t1);}

C_noret_decl(trf_10098)
static void C_ccall trf_10098(C_word c,C_word *av) C_noret;
static void C_ccall trf_10098(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10098(t0,t1,t2);}

C_noret_decl(trf_9183)
static void C_ccall trf_9183(C_word c,C_word *av) C_noret;
static void C_ccall trf_9183(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9183(t0,t1,t2,t3);}

C_noret_decl(trf_5948)
static void C_ccall trf_5948(C_word c,C_word *av) C_noret;
static void C_ccall trf_5948(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5948(t0,t1);}

C_noret_decl(trf_5807)
static void C_ccall trf_5807(C_word c,C_word *av) C_noret;
static void C_ccall trf_5807(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5807(t0,t1,t2,t3);}

C_noret_decl(trf_6460)
static void C_ccall trf_6460(C_word c,C_word *av) C_noret;
static void C_ccall trf_6460(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6460(t0,t1,t2);}

C_noret_decl(trf_10988)
static void C_ccall trf_10988(C_word c,C_word *av) C_noret;
static void C_ccall trf_10988(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10988(t0,t1,t2,t3);}

C_noret_decl(trf_6853)
static void C_ccall trf_6853(C_word c,C_word *av) C_noret;
static void C_ccall trf_6853(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6853(t0,t1);}

C_noret_decl(trf_12885)
static void C_ccall trf_12885(C_word c,C_word *av) C_noret;
static void C_ccall trf_12885(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12885(t0,t1,t2);}

C_noret_decl(trf_8087)
static void C_ccall trf_8087(C_word c,C_word *av) C_noret;
static void C_ccall trf_8087(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8087(t0,t1);}

C_noret_decl(trf_9827)
static void C_ccall trf_9827(C_word c,C_word *av) C_noret;
static void C_ccall trf_9827(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9827(t0,t1,t2);}

C_noret_decl(trf_11951)
static void C_ccall trf_11951(C_word c,C_word *av) C_noret;
static void C_ccall trf_11951(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11951(t0,t1);}

C_noret_decl(trf_5492)
static void C_ccall trf_5492(C_word c,C_word *av) C_noret;
static void C_ccall trf_5492(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5492(t0,t1,t2,t3);}

C_noret_decl(trf_9882)
static void C_ccall trf_9882(C_word c,C_word *av) C_noret;
static void C_ccall trf_9882(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9882(t0,t1,t2,t3);}

C_noret_decl(trf_6815)
static void C_ccall trf_6815(C_word c,C_word *av) C_noret;
static void C_ccall trf_6815(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6815(t0,t1,t2);}

C_noret_decl(trf_11636)
static void C_ccall trf_11636(C_word c,C_word *av) C_noret;
static void C_ccall trf_11636(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11636(t0,t1,t2);}

C_noret_decl(trf_12249)
static void C_ccall trf_12249(C_word c,C_word *av) C_noret;
static void C_ccall trf_12249(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12249(t0,t1,t2);}

C_noret_decl(trf_12975)
static void C_ccall trf_12975(C_word c,C_word *av) C_noret;
static void C_ccall trf_12975(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12975(t0,t1,t2);}

C_noret_decl(trf_8564)
static void C_ccall trf_8564(C_word c,C_word *av) C_noret;
static void C_ccall trf_8564(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8564(t0,t1,t2);}

C_noret_decl(trf_5340)
static void C_ccall trf_5340(C_word c,C_word *av) C_noret;
static void C_ccall trf_5340(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5340(t0,t1,t2,t3);}

C_noret_decl(trf_10818)
static void C_ccall trf_10818(C_word c,C_word *av) C_noret;
static void C_ccall trf_10818(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10818(t0,t1);}

C_noret_decl(trf_16201)
static void C_ccall trf_16201(C_word c,C_word *av) C_noret;
static void C_ccall trf_16201(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16201(t0,t1,t2);}

C_noret_decl(trf_10528)
static void C_ccall trf_10528(C_word c,C_word *av) C_noret;
static void C_ccall trf_10528(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10528(t0,t1,t2);}

C_noret_decl(trf_7750)
static void C_ccall trf_7750(C_word c,C_word *av) C_noret;
static void C_ccall trf_7750(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7750(t0,t1,t2);}

C_noret_decl(trf_12202)
static void C_ccall trf_12202(C_word c,C_word *av) C_noret;
static void C_ccall trf_12202(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12202(t0,t1);}

C_noret_decl(trf_13901)
static void C_ccall trf_13901(C_word c,C_word *av) C_noret;
static void C_ccall trf_13901(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13901(t0,t1);}

C_noret_decl(trf_10213)
static void C_ccall trf_10213(C_word c,C_word *av) C_noret;
static void C_ccall trf_10213(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10213(t0,t1,t2);}

C_noret_decl(trf_4960)
static void C_ccall trf_4960(C_word c,C_word *av) C_noret;
static void C_ccall trf_4960(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4960(t0,t1,t2);}

C_noret_decl(trf_8101)
static void C_ccall trf_8101(C_word c,C_word *av) C_noret;
static void C_ccall trf_8101(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8101(t0,t1,t2);}

C_noret_decl(trf_5374)
static void C_ccall trf_5374(C_word c,C_word *av) C_noret;
static void C_ccall trf_5374(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5374(t0,t1,t2,t3);}

C_noret_decl(trf_4937)
static void C_ccall trf_4937(C_word c,C_word *av) C_noret;
static void C_ccall trf_4937(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4937(t0,t1,t2);}

C_noret_decl(trf_10599)
static void C_ccall trf_10599(C_word c,C_word *av) C_noret;
static void C_ccall trf_10599(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10599(t0,t1,t2);}

/* k4983 in k4980 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_4985,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:78: flush-output */
t3=*((C_word*)lf[25]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4980 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_4982,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:77: display */
t4=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_11991,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1056: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[368]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12033,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_12033(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[411]);
if(C_truep(t4)){
t5=t3;
f_12033(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[412]);
if(C_truep(t5)){
t6=t3;
f_12033(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[413]);
if(C_truep(t6)){
t7=t3;
f_12033(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[414]);
if(C_truep(t7)){
t8=t3;
f_12033(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[415]);
if(C_truep(t8)){
t9=t3;
f_12033(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[416]);
t10=t3;
f_12033(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[417])));}}}}}}}}

/* k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_4979,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:76: text */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4895(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm:83: test-debugging-mode */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k11992 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,2)))){
C_save_and_reclaim((void *)f_11994,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12009,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[353]+1))){
t7=t6;
f_12009(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[97],((C_word*)t0)[4]);
t8=t6;
f_12009(t8,C_a_i_list(&a,3,lf[365],t7,t2));}}

/* k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12059(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_12059,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[353]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[371],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=(C_truep(*((C_word*)lf[353]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[373],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[374]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_12086(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[406]);
t6=t4;
f_12086(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[407])));}}}}

/* ##compiler#debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +17,c,3)))){
C_save_and_reclaim((void*)f_4892,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+17);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4895,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4960,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4979,a[2]=t1,a[3]=t8,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* support.scm:75: test-debugging-mode */
t12=*((C_word*)lf[11]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t12;
av2[1]=t11;
av2[2]=t2;
av2[3]=*((C_word*)lf[1]+1);
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}

/* k4888 in test-debugging-mode in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4890,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_i_pairp(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_4895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_4895,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:64: with-output-to-string */
t3=*((C_word*)lf[23]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8124 in map-loop1192 in k8085 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8126,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8101(t6,((C_word*)t0)[5],t5);}

/* k4986 in k4983 in k4980 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_4988,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm:79: test-debugging-mode */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_11696,2,av);}
a=C_alloc(9);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:993: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[340];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* walk in node->sexpr in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_10482,3,av);}
a=C_alloc(18);
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=((C_word*)((C_word*)t0)[2])[1];
t14=t2;
t15=C_slot(t14,C_fix(3));
t16=C_i_check_list_2(t15,lf[161]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10526,a[2]=t8,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10528,a[2]=t11,a[3]=t19,a[4]=t13,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_10528(t21,t17,t15);}

/* k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_11693,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:992: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_11690,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:992: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k8184 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8186,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1226 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8188(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8188,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:583: g1232 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12173 in k12158 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,0,1)))){
C_save_and_reclaim_args((void *)trf_12175,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9757 in k9731 in k9728 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_9759,2,t0,t1);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:707: take */
t4=*((C_word*)lf[284]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,3)))){
C_save_and_reclaim((void *)f_9726,4,av);}
a=C_alloc(25);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9730,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=*((C_word*)lf[110]+1);
t10=((C_word*)t0)[6];
t11=C_i_check_list_2(t10,lf[161]);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9827,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9827(t15,t4,t10);}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=((C_word*)t0)[6];
f_9730(2,av2);}}}

/* a9719 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9720,2,av);}
/* support.scm:689: split-at */
t2=*((C_word*)lf[282]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#source-info->line in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15334,3,av);}
if(C_truep(C_i_listp(t2))){
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_car(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(t2)){
/* support.scm:1480: ->string */
t3=*((C_word*)lf[60]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}

/* k10236 in map-loop1933 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10238,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10213(t6,((C_word*)t0)[5],t5);}

/* ##compiler#compiler-cleanup-hook in k4834 in k4831 in k4828 */
static void C_ccall f_4840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4840,2,av);}
t2=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a9737 in k9731 in k9728 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,1)))){
C_save_and_reclaim((void *)f_9738,5,av);}
a=C_alloc(14);
t5=C_a_i_list1(&a,1,t2);
t6=C_a_i_list2(&a,2,t3,t4);
t7=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[109],t5,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* ##compiler#bomb in k4834 in k4831 in k4828 */
static void C_ccall f_4845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,3)))){
C_save_and_reclaim((void*)f_4845,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4859,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:49: string-append */
t6=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[6];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* support.scm:50: error */
t3=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[7];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k9731 in k9728 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_9733,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9738,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9759,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9813,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm:698: last */
t6=*((C_word*)lf[265]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t4;
f_9759(t5,t2);}}

/* k9728 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,6)))){
C_save_and_reclaim((void *)f_9730,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* support.scm:692: copy-node-tree-and-rename */
t4=*((C_word*)lf[286]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[9];
av2[4]=t2;
av2[5]=((C_word*)t0)[10];
av2[6]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}
else{
t4=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=((C_word*)t0)[8];
f_9733(2,av2);}}}

/* k15426 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_15428,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1499: g3710 */
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_12157,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1091: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[384]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_12202(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[399]);
t5=t3;
f_12202(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[400])));}}}

/* ##compiler#copy-node! in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_10437,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10441,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_slot(t5,C_fix(1));
/* support.scm:769: node-class-set! */
t7=*((C_word*)lf[214]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t4;
av2[2]=t3;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* ##compiler#call-info in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15352(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,5)))){
C_save_and_reclaim((void *)f_15352,4,av);}
a=C_alloc(4);
t4=C_i_cdr(t2);
t5=C_i_pairp(t4);
t6=(C_truep(t5)?C_i_cadr(t2):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15359,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
if(C_truep(C_i_listp(t6))){
t8=C_i_car(t6);
t9=C_i_cadr(t6);
/* support.scm:1487: conc */
t10=*((C_word*)lf[507]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=lf[514];
av2[3]=t8;
av2[4]=lf[515];
av2[5]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(6,av2);}}
else{
t8=t3;
t9=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=t3;
t9=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k4857 in bomb in k4834 in k4831 in k4828 */
static void C_ccall f_4859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4859,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=*((C_word*)lf[4]+1);
av2[3]=t1;
av2[4]=t3;
C_apply(5,av2);}}

/* k15357 in call-info in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15359,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15429 in k15426 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_15431,2,av);}
a=C_alloc(6);
t2=t1;
if(C_truep(C_i_structurep(t2,lf[211]))){
/* support.scm:1504: k */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15451,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_i_length(t2);
t5=C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=C_i_car(t2);
/* support.scm:1506: encodeable-literal? */
t7=*((C_word*)lf[519]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_15451(2,av2);}}}}

/* k12951 in k12939 in k12930 in a12921 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_12953,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1190: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(4);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[357]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_12965(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[425]);
if(C_truep(t4)){
t5=t3;
f_12965(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[426]);
if(C_truep(t5)){
t6=t3;
f_12965(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[372]);
t7=t3;
f_12965(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[376])));}}}}}

/* k4923 in for-each-loop50 in k4915 in k4903 in a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4925,2,av);}
/* support.scm:70: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4915 in k4903 in a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4917,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4937(t6,((C_word*)t0)[3],t2);}

/* k12963 in k12951 in k12939 in k12930 in a12921 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_12965,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1192: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(4);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1194: ##sys#hash-table-ref */
t3=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[398]+1);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_12971(2,av2);}}}}

/* k9761 in k9757 in k9731 in k9728 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9763(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9763,2,av);}
/* support.scm:694: fold-right */
t2=*((C_word*)lf[283]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
av2[5]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* test-debugging-mode in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4873(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4873,4,av);}
a=C_alloc(3);
if(C_truep(C_i_symbolp(t2))){
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_i_memq(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4890,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:60: lset-intersection */
t5=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(61,c,5)))){
C_save_and_reclaim((void *)f_4870,2,av);}
a=C_alloc(61);
t2=C_mutate2((C_word*)lf[8]+1 /* (set! ##compiler#collected-debugging-output ...) */,t1);
t3=C_mutate2((C_word*)lf[9]+1 /* (set! +logged-debugging-modes+ ...) */,lf[10]);
t4=C_mutate2((C_word*)lf[11]+1 /* (set! test-debugging-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4873,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[14]+1 /* (set! ##compiler#debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4892,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[26]+1 /* (set! ##compiler#with-debugging-output ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5012,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[29]+1 /* (set! ##compiler#quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5109,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[33]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5125,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[42]+1 /* (set! syntax-error ...) */,*((C_word*)lf[33]+1));
t10=C_mutate2((C_word*)lf[43]+1 /* (set! ##compiler#emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5222,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[44]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5225,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[45]+1 /* (set! ##compiler#check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5266,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[48]+1 /* (set! ##compiler#posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5334,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[49]+1 /* (set! ##compiler#posv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5368,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[50]+1 /* (set! ##compiler#stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5402,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[55]+1 /* (set! ##compiler#symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5432,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[57]+1 /* (set! ##compiler#backslashify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5466,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[61]+1 /* (set! ##compiler#uncommentify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5476,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[63]+1 /* (set! ##compiler#build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5486,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate2((C_word*)lf[64]+1 /* (set! ##compiler#string->c-identifier ...) */,*((C_word*)lf[65]+1));
t21=C_mutate2((C_word*)lf[66]+1 /* (set! ##compiler#c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5528,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate2((C_word*)lf[76]+1 /* (set! ##compiler#valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5625,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate2((C_word*)lf[78]+1 /* (set! ##compiler#words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5675,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[79]+1 /* (set! ##compiler#words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5682,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[80]+1 /* (set! ##compiler#check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5689,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[87]+1 /* (set! ##compiler#close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5733,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[90]+1 /* (set! ##compiler#fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5745,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[92]+1 /* (set! ##compiler#follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5801,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[93]+1 /* (set! ##compiler#sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5832,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[96]+1 /* (set! ##compiler#constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5852,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate2((C_word*)lf[100]+1 /* (set! ##compiler#collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5914,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate2((C_word*)lf[101]+1 /* (set! ##compiler#immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5944,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate2((C_word*)lf[103]+1 /* (set! ##compiler#basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5990,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate2((C_word*)lf[106]+1 /* (set! ##compiler#canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6046,tmp=(C_word)a,a+=2,tmp));
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:302: condition-predicate */
t36=*((C_word*)lf[568]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t36;
av2[1]=t35;
av2[2]=lf[521];
((C_proc)(void*)(*((C_word*)t36+1)))(3,av2);}}

/* k15449 in k15429 in k15426 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_15451,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1507: debugging */
t3=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[261];
av2[3]=lf[517];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=C_u_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
/* support.scm:1510: k */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[5];
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}
else{
/* support.scm:1512: bomb */
t4=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[518];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* k15452 in k15449 in k15429 in k15426 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_15454,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* support.scm:1508: k */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[5];
av2[4]=t2;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k12930 in a12921 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12932(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_12932,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[381]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_12941(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[384]);
if(C_truep(t4)){
t5=t3;
f_12941(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[378]);
if(C_truep(t5)){
t6=t3;
f_12941(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[380]);
if(C_truep(t6)){
t7=t3;
f_12941(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[385]);
if(C_truep(t7)){
t8=t3;
f_12941(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[401]);
if(C_truep(t8)){
t9=t3;
f_12941(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[3],lf[399]);
if(C_truep(t9)){
t10=t3;
f_12941(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[402]);
if(C_truep(t10)){
t11=t3;
f_12941(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[3],lf[403]);
if(C_truep(t11)){
t12=t3;
f_12941(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[400]);
if(C_truep(t12)){
t13=t3;
f_12941(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[404]);
t14=t3;
f_12941(t14,(C_truep(t13)?t13:C_eqp(((C_word*)t0)[3],lf[405])));}}}}}}}}}}}}

/* a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4901,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4905,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:66: display */
t3=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11730 in k11727 in k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in ... */
static void C_ccall f_11732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_11732,2,av);}
a=C_alloc(6);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:996: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[337];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11736 in k11730 in k11727 in k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in ... */
static void C_ccall f_11738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_11738,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:996: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k12939 in k12930 in a12921 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_12941,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
/* support.scm:1188: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[374]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_12953(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[408]);
if(C_truep(t4)){
t5=t3;
f_12953(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[370]);
if(C_truep(t5)){
t6=t3;
f_12953(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[409]);
if(C_truep(t6)){
t7=t3;
f_12953(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[407]);
if(C_truep(t7)){
t8=t3;
f_12953(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[410]);
t9=t3;
f_12953(t9,(C_truep(t8)?t8:C_eqp(((C_word*)t0)[3],lf[406])));}}}}}}}

/* ##compiler#node->sexpr in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_10476,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10482,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
f_10482(3,av2);}}

/* k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 in ... */
static void C_ccall f_11726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_11726,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:995: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_11720,2,av);}
a=C_alloc(7);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:995: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[338];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11727 in k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in ... */
static void C_ccall f_11729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11729,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:995: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4903 in a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4905,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:68: display */
t4=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[22];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* support.scm:72: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4906 in k4903 in a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4908,2,av);}
/* support.scm:72: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15318 in source-info->string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15320(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,6)))){
C_save_and_reclaim((void *)f_15320,2,av);}
/* support.scm:1474: conc */
t2=*((C_word*)lf[507]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[508];
av2[4]=t1;
av2[5]=lf[509];
av2[6]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k15322 in source-info->string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15324,2,av);}
/* support.scm:1474: make-string */
t2=*((C_word*)lf[510]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#pprint-expressions-to-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_11758,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11762,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm:1003: open-output-file */
t5=*((C_word*)lf[349]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=*((C_word*)lf[16]+1);
f_11762(2,av2);}}}

/* k11748 in k11742 in k11739 in k11736 in k11730 in k11727 in k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in ... */
static void C_ccall f_11750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11750,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:997: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11751 in k11748 in k11742 in k11739 in k11736 in k11730 in k11727 in k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in ... */
static void C_ccall f_11753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11753,2,av);}
/* support.scm:997: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k14246 in k14225 in k14150 in k14075 in k14051 in foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_14248,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[477];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[404]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[405]));
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[478];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[384]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_14266(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[399]);
t7=t5;
f_14266(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[400])));}}}}

/* k11739 in k11736 in k11730 in k11727 in k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in ... */
static void C_ccall f_11741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_11741,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:996: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11742 in k11739 in k11736 in k11730 in k11727 in k11724 in k11718 in k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in ... */
static void C_ccall f_11744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_11744,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11750,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:997: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[336];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_12086,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[353]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[375],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=(C_truep(*((C_word*)lf[353]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[377],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[378]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_12113(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[404]);
t6=t4;
f_12113(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[405])));}}}}

/* k14225 in k14150 in k14075 in k14051 in foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_14227,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[426];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[378]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[476];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[380]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[396];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[381]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_14248(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[401]);
if(C_truep(t6)){
t7=t5;
f_14248(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[402]);
t8=t5;
f_14248(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[403])));}}}}}}

/* k11777 in for-each-loop2562 in a11772 in k11760 in pprint-expressions-to-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11779,2,av);}
/* support.scm:1009: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6042 in k6004 in basic-literal? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6044,2,av);}
/* support.scm:281: every */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[103]+1);
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#canonicalize-begin-body in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6046,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6052,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6052(t6,t1,t2);}

/* a11772 in k11760 in pprint-expressions-to-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11773,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11790,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11790(t7,t1,t2);}

/* k5712 in k5700 in check-and-open-input-file in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_5714,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:223: quit */
t2=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[84];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_i_car(((C_word*)t0)[4]);
/* support.scm:224: quit */
t3=*((C_word*)lf[29]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[85];
av2[3]=t2;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* ##compiler#inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_9708,8,av);}
a=C_alloc(7);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9714,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm:686: decompose-lambda-list */
t9=*((C_word*)lf[124]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t1;
av2[2]=t2;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* map-loop1121 in k7739 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7777(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7777,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:551: g1127 */
t5=((C_word*)t0)[4];
f_7750(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7773 in k7765 in k7739 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7775,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* support.scm:551: append */
t3=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11763 in k11760 in pprint-expressions-to-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11765,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* support.scm:1011: close-output-port */
t2=*((C_word*)lf[346]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11760 in pprint-expressions-to-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_11762,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11773,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1004: with-output-to-port */
t5=*((C_word*)lf[348]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5700 in check-and-open-input-file in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5702,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:222: open-input-file */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_i_nullp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_5714(t4,t2);}
else{
t4=C_i_car(((C_word*)t0)[4]);
t5=t3;
f_5714(t5,C_i_not(t4));}}}

/* k12158 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,2)))){
C_save_and_reclaim((void *)f_12160,2,av);}
a=C_alloc(26);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12175,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[353]+1))){
t7=t6;
f_12175(t7,C_a_i_list(&a,2,lf[382],t2));}
else{
t7=C_a_i_list(&a,2,lf[383],t2);
t8=t6;
f_12175(t8,C_a_i_list(&a,2,lf[382],t7));}}

/* a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_9714,5,av);}
a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9720,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9726,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* support.scm:688: ##sys#call-with-values */{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=0;
av2[1]=t1;
av2[2]=t5;
av2[3]=t6;
C_call_with_values(4,av2);}}

/* for-each-loop2562 in a11772 in k11760 in pprint-expressions-to-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11790(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_11790,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11800,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11779,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1008: pretty-print */
t7=*((C_word*)lf[347]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##compiler#close-checked-input-file in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5733,4,av);}
if(C_truep(C_i_string_equal_p(t3,lf[88]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
/* support.scm:227: close-input-port */
t4=*((C_word*)lf[89]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* a6558 in k6549 in get-all in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6559,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_assq(t2,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6549 in get-all in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_6551,2,av);}
a=C_alloc(3);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6559,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:383: filter-map */
t4=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in canonicalize-begin-body in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_6052,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[107];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_u_i_car(t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_equalp(t5,lf[108]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6076,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_6076(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6107,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:295: constant? */
t9=*((C_word*)lf[96]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}}

/* map-loop1555 in k8991 in k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9012(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_9012,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k9008 in k9000 in k8991 in k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9010,2,av);}
/* support.scm:640: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_8786(3,av2);}}

/* k12318 in k12280 in k12243 in k12200 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 in ... */
static void C_ccall f_12320(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(51,c,1)))){
C_save_and_reclaim((void *)f_12320,2,av);}
a=C_alloc(51);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[97],lf[390]);
t5=C_a_i_list(&a,3,lf[391],((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t7=C_a_i_list(&a,4,lf[225],t1,t5,t6);
t8=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* ##compiler#get-all in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +4,c,3)))){
C_save_and_reclaim((void*)f_6547,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+4);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6551,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:381: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k6004 in basic-literal? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_6006,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6044,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:281: vector->list */
t4=*((C_word*)lf[105]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_6012(2,av2);}}}}

/* k6531 in get in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6533,2,av);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=(C_truep(t2)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5757 in fold-inner in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5759,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5761(t5,((C_word*)t0)[3],t1);}

/* ##compiler#fold-inner in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5745,4,av);}
a=C_alloc(4);
t4=C_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5759,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:232: reverse */
t6=*((C_word*)lf[91]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* f17649 in print-version in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f17649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f17649,2,av);}
/* support.scm:1667: print */
t2=*((C_word*)lf[296]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#get in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_6529,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6533,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:375: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k7147 in k7068 in loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7149(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_7149,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:482: ##sys#write-char-0 */
t6=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(9);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[176]);
if(C_truep(t2)){
t3=C_i_cdar(((C_word*)t0)[2]);
t4=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:488: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7046(t7,((C_word*)t0)[7],t6);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[177]);
if(C_truep(t3)){
t4=C_i_cdar(((C_word*)t0)[2]);
t5=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t4);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:488: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_7046(t8,((C_word*)t0)[7],t7);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:487: bomb */
t6=*((C_word*)lf[3]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[178];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}}}

/* k9000 in k8991 in k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9002(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_9002,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9006,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9010,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:640: last */
t5=*((C_word*)lf[265]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9004 in k9000 in k8991 in k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9006,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6514 in for-each-loop534 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6516,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6506(t3,((C_word*)t0)[4],t2);}

/* for-each-loop534 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_6506,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6516,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6356,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_a_i_list(&a,1,lf[147]);
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop1576 in k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9060(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9060,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9085,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:639: g1582 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7153 in k7147 in k7068 in loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_7155,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_caar(((C_word*)t0)[2]);
/* support.scm:482: ##sys#print */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k9781 in k9811 in k9731 in k9728 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,1)))){
C_save_and_reclaim((void *)f_9783,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_9759(t3,C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[4],t2));}

/* k7156 in k7153 in k7147 in k7068 in loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_7158,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:482: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(61);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4989 in k4986 in k4983 in k4980 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4991,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4992 in k4986 in k4983 in k4980 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4994,2,av);}
if(C_truep(t1)){
/* support.scm:80: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4960(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_11714,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:994: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11715 in k11712 in k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_11717,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:994: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_11705,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:993: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_11702,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:993: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11706 in k11703 in k11700 in k11694 in k11691 in k11688 in k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_11708,2,av);}
a=C_alloc(8);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:994: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[339];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* ##compiler#source-info->string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_15300,3,av);}
a=C_alloc(12);
if(C_truep(C_i_listp(t2))){
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15320,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15324,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_i_string_length(t4);
t10=C_a_i_minus(&a,2,C_fix(4),t9);
/* support.scm:1474: max */
t11=*((C_word*)lf[511]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t11;
av2[1]=t8;
av2[2]=C_fix(0);
av2[3]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t3=t2;
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_16156,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16248,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1652: make-pathname */
t4=*((C_word*)lf[556]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7159 in k7156 in k7153 in k7147 in k7068 in loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7161,2,av);}
t2=C_i_cdar(((C_word*)t0)[2]);
/* support.scm:482: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* ##compiler#load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_16152,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16156,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1651: repository-path */
t4=*((C_word*)lf[557]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9083 in map-loop1576 in k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9085,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9060(t6,((C_word*)t0)[5],t5);}

/* map-loop1963 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10165(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_10165,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k10161 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10163,2,av);}
/* support.scm:747: append */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#variable-mark in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16124,4,av);}
/* support.scm:1642: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6090 in k6100 in k6074 in loop in canonicalize-begin-body in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_6092,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_15413,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(t2,lf[161]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15563,a[2]=t5,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_15563(t12,t8,t2);}

/* k16194 in k16166 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_16196,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16201,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_16201(t5,((C_word*)t0)[2],t1);}

/* k6074 in loop in canonicalize-begin-body in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6076,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:297: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6052(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:298: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[111];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* foldable? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16141,3,av);}
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[145];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10445 in k10442 in k10439 in copy-node! in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10447,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#put! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6565(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6565,6,av);}
a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6569,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:387: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k10439 in copy-node! in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_10441,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
/* support.scm:770: node-parameters-set! */
t5=*((C_word*)lf[217]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k10442 in k10439 in copy-node! in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_10444,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(3));
/* support.scm:771: node-subexpressions-set! */
t5=*((C_word*)lf[219]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6567 in put! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6569,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
t3=C_slot(t1,C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]),t3);
t5=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_i_setslot(t1,C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:392: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* ##compiler#intrinsic? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16130,3,av);}
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[143];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* ##compiler#constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_15389,5,av);}
a=C_alloc(17);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=C_i_check_list_2(t3,lf[161]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15413,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15597,a[2]=t7,a[3]=t12,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_15597(t14,t10,t3);}

/* k14617 in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_14619,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14615(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_14615,4,av);}
a=C_alloc(13);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14619,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14621,a[2]=t8,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=t6;
av2[2]=t2;
f_14621(3,av2);}}

/* k14669 in for-each-loop3418 in k14651 in walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_14671,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14661(t3,((C_word*)t0)[4],t2);}

/* k9527 in map-loop1723 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9529,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9504(t6,((C_word*)t0)[5],t5);}

/* k6010 in k6004 in basic-literal? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6012,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* support.scm:283: basic-literal? */
t5=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* for-each-loop3418 in k14651 in walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14661(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_14661,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14671,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1341: g3419 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10755 in a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_10757,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_i_assq(lf[173],((C_word*)t0)[2]);
t3=t2;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[4];
/* tweaks.scm:57: ##sys#get */
t6=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=lf[313];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15493(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_15493,3,av);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1499: with-exception-handler */
t5=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_10750,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10757,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* support.scm:789: variable-visible? */
t5=*((C_word*)lf[314]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* fold in k5757 in fold-inner in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_5761,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_list2(&a,2,t6,t8);{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t9;
C_apply(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5787,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_cdr(t5);
/* support.scm:237: fold */
t11=t4;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}

/* a15498 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_15499,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1499: k3706 */
t4=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k14651 in walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_14653,2,t0,t1);}
a=C_alloc(6);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(((C_word*)t0)[3],lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14661,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_14661(t7,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* for-each-loop2224 in k10713 in k10702 in a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_10723,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10733,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10709,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:814: pp */
t7=*((C_word*)lf[302]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k9578 in map-loop1749 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9580,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9555(t6,((C_word*)t0)[5],t5);}

/* k6959 in k6953 in k6916 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6961(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6961,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:492: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=t6;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* ##compiler#make-block-variable-literal in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_15067,3,av);}
a=C_alloc(3);
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record2(&a,2,lf[489],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10731 in for-each-loop2224 in k10713 in k10702 in a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10733,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10723(t3,((C_word*)t0)[4],t2);}

/* k5785 in fold in k5757 in fold-inner in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5787,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,t1,t3);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
C_apply(4,av2);}}

/* k9551 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9553,2,av);}
/* support.scm:674: append */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6953 in k6916 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_6955,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:492: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[167];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6992,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
t4=t2;
f_6992(t4,C_i_not(t3));}
else{
t3=t2;
f_6992(t3,C_SCHEME_FALSE);}}}

/* map-loop1749 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9555(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9555,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9580,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:674: g1755 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_10700,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10704,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10748,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:810: chicken-version */
t4=*((C_word*)lf[307]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6025 in k6010 in k6004 in basic-literal? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6027,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:284: basic-literal? */
t4=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10707 in for-each-loop2224 in k10713 in k10702 in a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10709(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10709,2,av);}
/* support.scm:815: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10702 in a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10704,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:816: reverse */
t3=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* ##compiler#make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2)))){
C_save_and_reclaim((void*)f_15088,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15096,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1414: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#check-signature in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_5266,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5269,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5290,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5290(t9,t1,t3,t4);}

/* err in check-signature in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_5269,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5277,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:139: real-name */
t3=*((C_word*)lf[47]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5252 in loop in map-llist in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5254(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5254,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:134: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5231(t6,t3,t5);}

/* k6922 in k6916 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6924,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:490: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=t6;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k5256 in k5252 in loop in map-llist in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5258,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#mark-variable in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,4)))){
C_save_and_reclaim((void*)f_16109,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* support.scm:1639: ##sys#put! */
t5=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=C_i_car(t4);
/* support.scm:1639: ##sys#put! */
t6=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* ##compiler#chop-extension in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_15027,3,av);}
a=C_alloc(10);
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15036,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_15036(t8,t1,t4);}

/* k6916 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_6918,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:490: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[166];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[169]);
t4=t2;
f_6955(t4,C_i_not(t3));}
else{
t3=t2;
f_6955(t3,C_SCHEME_FALSE);}}}

/* k8626 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,1)))){
C_save_and_reclaim((void *)f_8628,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_8600(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_8600(t2,C_SCHEME_FALSE);}}

/* ##compiler#block-variable-literal? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15073,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[489]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10746 in a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,6)))){
C_save_and_reclaim((void *)f_10748,2,av);}
/* support.scm:810: print */
t2=*((C_word*)lf[296]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[303];
av2[3]=t1;
av2[4]=lf[304];
av2[5]=*((C_word*)lf[305]+1);
av2[6]=lf[306];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* ##compiler#block-variable-literal-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15079,3,av);}
t3=C_i_check_structure_2(t2,lf[489],lf[492]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8612 in k8605 in k8598 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8614(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_8614,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t1);
f_8604(2,av2);}}

/* loop in map-llist in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5231(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_5231,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:133: proc */
t3=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5254,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm:134: proc */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}}

/* map-loop1723 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9504(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9504,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9529,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:673: g1729 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9500 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9502,2,av);}
/* support.scm:673: cons* */
t2=*((C_word*)lf[270]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k14051 in foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_14053,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_eqp(t3,lf[441]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=lf[195];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(t3,lf[351]);
t6=(C_truep(t5)?t5:C_eqp(t3,lf[352]));
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=lf[351];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(t3,lf[355]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14077,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_14077(t9,t7);}
else{
t9=C_eqp(t3,lf[427]);
if(C_truep(t9)){
t10=t8;
f_14077(t10,t9);}
else{
t10=C_eqp(t3,lf[428]);
if(C_truep(t10)){
t11=t8;
f_14077(t11,t10);}
else{
t11=C_eqp(t3,lf[429]);
if(C_truep(t11)){
t12=t8;
f_14077(t12,t11);}
else{
t12=C_eqp(t3,lf[430]);
if(C_truep(t12)){
t13=t8;
f_14077(t13,t12);}
else{
t13=C_eqp(t3,lf[431]);
if(C_truep(t13)){
t14=t8;
f_14077(t14,t13);}
else{
t14=C_eqp(t3,lf[432]);
t15=t8;
f_14077(t15,(C_truep(t14)?t14:C_eqp(t3,lf[433])));}}}}}}}}}

/* walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_14621,3,av);}
a=C_alloc(10);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=C_eqp(t7,lf[221]);
t9=(C_truep(t8)?t8:C_eqp(t7,lf[246]));
if(C_truep(t9)){
t10=t2;
t11=C_slot(t10,C_fix(2));
t12=C_i_car(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14653,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14685,a[2]=t13,a[3]=((C_word*)t0)[3],a[4]=t14,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t13,((C_word*)t0)[4]))){
t16=C_i_memq(t13,((C_word*)((C_word*)t0)[3])[1]);
t17=t15;
f_14685(t17,C_i_not(t16));}
else{
t16=t15;
f_14685(t16,C_SCHEME_FALSE);}}
else{
t10=C_eqp(t7,lf[97]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14717,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_14717(t12,t10);}
else{
t12=C_eqp(t7,lf[226]);
t13=t11;
f_14717(t13,(C_truep(t12)?t12:C_eqp(t7,lf[241])));}}}

/* k16166 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16168,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16196,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1660: read-file */
t3=*((C_word*)lf[552]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k10716 in k10713 in k10702 in a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10718,2,av);}
/* support.scm:817: print */
t2=*((C_word*)lf[296]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[301];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10713 in k10702 in a10699 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_10715,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10723,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10723(t6,t2,t1);}

/* k12283 in k12280 in k12243 in k12200 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 in ... */
static void C_ccall f_12285(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_12285,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[379],t1);
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k12280 in k12243 in k12200 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_12282,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1113: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[388]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[389]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1119: gensym */
t5=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1125: gensym */
t6=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[362]);
if(C_truep(t5)){
if(C_truep(*((C_word*)lf[353]+1))){
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,2,lf[361],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=C_eqp(((C_word*)t0)[4],lf[392]);
if(C_truep(t6)){
t7=C_a_i_list(&a,2,lf[97],lf[390]);
t8=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[391],((C_word*)t0)[2],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[393]);
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:1138: repeat */
t9=((C_word*)((C_word*)t0)[6])[1];
f_11828(t9,((C_word*)t0)[3],t8);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[394]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t9;
av2[1]=(C_truep(*((C_word*)lf[353]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[371],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[4],lf[395]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=(C_truep(t9)?C_a_i_list(&a,2,lf[379],((C_word*)t0)[2]):((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[4],lf[380]);
t11=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t11;
av2[1]=(C_truep(t10)?C_a_i_list(&a,2,lf[379],((C_word*)t0)[2]):((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}}}}}}

/* k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_16162,2,av);}
a=C_alloc(8);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16168,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16226,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1653: open-output-string */
t5=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8456 in map-loop1319 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8458,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8433(t6,((C_word*)t0)[5],t5);}

/* k9541 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9543,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k16182 in for-each-loop3976 in k16194 in k16166 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_16184,2,av);}
a=C_alloc(3);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_list1(&a,1,t3);
/* support.scm:1659: append */
t5=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k8429 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8431,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1319 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8433,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8458,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:600: g1325 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k16178 in for-each-loop3976 in k16194 in k16166 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_16180,2,av);}
/* support.scm:1657: ##sys#put! */
t2=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[551];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k14075 in k14051 in foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_14077,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[230];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[357]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[425]));
if(C_truep(t3)){
t4=((C_word*)t0)[4];
t5=C_eqp(t4,lf[462]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?lf[426]:lf[357]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[360]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[3],lf[362]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[3],lf[359]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
t8=C_eqp(t7,lf[462]);
t9=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t9;
av2[1]=(C_truep(t8)?lf[463]:lf[359]);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[3],lf[363]);
if(C_truep(t7)){
t8=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[359];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[3],lf[364]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=C_eqp(t9,lf[462]);
t11=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t11;
av2[1]=(C_truep(t10)?lf[464]:lf[364]);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[3],lf[366]);
if(C_truep(t9)){
t10=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[364];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[3],lf[367]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14152,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_14152(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[418]);
if(C_truep(t12)){
t13=t11;
f_14152(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[419]);
if(C_truep(t13)){
t14=t11;
f_14152(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[3],lf[420]);
if(C_truep(t14)){
t15=t11;
f_14152(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[3],lf[421]);
if(C_truep(t15)){
t16=t11;
f_14152(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[3],lf[422]);
if(C_truep(t16)){
t17=t11;
f_14152(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[3],lf[423]);
t18=t11;
f_14152(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[3],lf[424])));}}}}}}}}}}}}}}

/* k6906 in k6872 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6908,2,av);}
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:495: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k8602 in k8598 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,3)))){
C_save_and_reclaim((void *)f_8604,2,av);}
a=C_alloc(23);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)((C_word*)t0)[3])[1];
t9=((C_word*)t0)[4];
t10=C_i_check_list_2(t9,lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8564,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8564(t15,t11,t9);}

/* k8598 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_8600,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8604,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8607,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:612: real-name */
t5=*((C_word*)lf[47]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:615: ##sys#symbol->qualified-string */
t4=*((C_word*)lf[254]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* map-loop1350 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8496,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8521,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:602: g1356 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8492 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8494,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[253],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8605 in k8598 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_8607,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
f_8604(2,av2);}}
else{
/* support.scm:614: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k11220 in a11213 in k11198 in walk in expression-has-side-effects? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11222,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k14683 in walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,1)))){
C_save_and_reclaim_args((void *)trf_14685,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_14653(t4,t3);}
else{
t2=((C_word*)t0)[4];
f_14653(t2,C_SCHEME_UNDEFINED);}}

/* a11213 in k11198 in walk in expression-has-side-effects? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_11214,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11222,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:883: foreign-callback-stub-id */
t4=*((C_word*)lf[321]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8211 in map-loop1226 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8213,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8188(t6,((C_word*)t0)[5],t5);}

/* k15008 in chop-separator in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_15010,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:1391: substring */
t2=*((C_word*)lf[485]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,0,4)))){
C_save_and_reclaim_args((void *)trf_8405,2,t0,t1);}
a=C_alloc(20);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=((C_word*)((C_word*)t0)[3])[1];
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
t13=C_u_i_cdr(t12);
t14=C_i_check_list_2(t13,lf[161]);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8431,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8433,a[2]=t8,a[3]=t17,a[4]=t10,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_8433(t19,t15,t13);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[252]);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=((C_word*)((C_word*)t0)[3])[1];
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_i_check_list_2(t11,lf[161]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8494,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8496,a[2]=t7,a[3]=t15,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_8496(t17,t13,t11);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:604: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}}}

/* loop in check-signature in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_5290,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* support.scm:142: err */
t4=((C_word*)t0)[2];
f_5269(t4,t1);}}
else{
t4=C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(t2))){
/* support.scm:144: err */
t5=((C_word*)t0)[2];
f_5269(t5,t1);}
else{
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
/* support.scm:145: loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* k5279 in k5275 in err in check-signature in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5281,2,av);}
/* support.scm:138: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[46];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10779 in k10891 in k10755 in a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_10781,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(C_i_assq(lf[199],((C_word*)t0)[2]))){
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_slot(t2,C_fix(2));
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* support.scm:797: get */
t6=*((C_word*)lf[148]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[206];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* loop in chop-extension in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,4)))){
C_save_and_reclaim_args((void *)trf_15036,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_i_zerop(t2))){
t3=((C_word*)t0)[2];
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_string_ref(((C_word*)t0)[2],t2);
if(C_truep(C_u_i_char_equalp(C_make_character(46),t3))){
/* support.scm:1398: substring */
t4=*((C_word*)lf[485]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_a_i_minus(&a,2,t2,C_fix(1));
/* support.scm:1399: loop */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}}

/* k5275 in err in check-signature in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_5277,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5281,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:140: map-llist */
t5=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=*((C_word*)lf[47]+1);
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* ##compiler#chop-separator in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_15000,3,av);}
a=C_alloc(9);
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15010,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(t5,C_fix(0)))){
t7=C_i_string_ref(t2,t5);
t8=t6;
f_15010(t8,C_u_i_memq(t7,lf[486]));}
else{
t7=t6;
f_15010(t7,C_SCHEME_FALSE);}}

/* for-each-loop3508 in walkeach in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_14971,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14981,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1349: g3509 */
t5=((C_word*)t0)[3];
f_14959(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6990 in k6953 in k6916 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_6992,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:494: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[168];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6874(2,av2);}}}

/* k6996 in k6990 in k6953 in k6916 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6998,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:494: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=t6;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k10391 in k10387 in rec in tree-copy in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_10393,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* copy-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_10399,3,av);}
a=C_alloc(5);
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=C_a_i_record4(&a,4,lf[211],t4,t6,t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}

/* k11198 in walk in expression-has-side-effects? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_11200,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[133]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11214,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* support.scm:882: find */
t8=*((C_word*)lf[322]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=((C_word*)t0)[2];
av2[2]=t7;
av2[3]=*((C_word*)lf[323]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[225]);
if(C_truep(t3)){
if(C_truep(t3)){
/* support.scm:885: any */
t4=*((C_word*)lf[77]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[5])[1];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[109]);
if(C_truep(t4)){
/* support.scm:885: any */
t5=*((C_word*)lf[77]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[5])[1];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}}}

/* ##compiler#fold-boolean in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_9658,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9664,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_9664(t7,t1,t3);}

/* k8295 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8297,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[246],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1270 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8299,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8324,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:591: g1276 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#emit-syntax-trace-info in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5222,4,av);}
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[37]+1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-llist in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5225,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5231,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5231(t7,t1,t3);}

/* rec in tree-copy in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_10375,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10389,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:760: rec */
t7=t3;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* fold in fold-boolean in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9664(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_9664,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
C_apply(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9690,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=C_i_cadr(t2);
/* support.scm:682: proc */
t8=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t8;
av2[1]=t4;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}

/* k10387 in rec in tree-copy in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_10389,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10393,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:760: rec */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10375(t6,t3,t5);}

/* a15504 in a15498 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_15505,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15513,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1501: get-condition-property */
t3=*((C_word*)lf[520]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[521];
av2[4]=lf[522];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5200 in k5197 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_5202,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:120: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5203 in k5200 in k5197 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5205,2,av);}
/* support.scm:120: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k15511 in a15504 in a15498 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_15513,2,av);}
/* support.scm:1500: k */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_SCHEME_FALSE;
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* a15514 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_15515,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15533,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1499: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k14993 in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_14995,2,av);}
/* support.scm:1382: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
C_values(4,av2);}}

/* a11403 in dump-undefined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_11404,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11411,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11437,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:911: keyword? */
t6=*((C_word*)lf[326]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* a15520 in a15514 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_15521,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1499: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[523]+1);
C_call_with_values(4,av2);}}

/* a15526 in a15520 in a15514 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15527,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
C_apply(4,av2);}}

/* k14286 in k14264 in k14246 in k14225 in k14150 in k14075 in k14051 in foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_14288,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[480];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[393]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* support.scm:1323: foreign-type->scrutiny-type */
t4=*((C_word*)lf[461]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[394]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[426];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[395]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=(C_truep(t4)?lf[396]:lf[240]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[3],lf[380]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?lf[396]:lf[240]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}

/* k11435 in a11403 in dump-undefined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11437,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11411(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_assq(lf[189],((C_word*)t0)[3]))){
t2=C_i_assq(lf[187],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_11411(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_11411(t2,C_SCHEME_FALSE);}}}

/* k14979 in for-each-loop3508 in walkeach in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_14981,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14971(t3,((C_word*)t0)[4],t2);}

/* ##compiler#dump-defined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_11439,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11445,tmp=(C_word)a,a+=2,tmp);
/* support.scm:919: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k14264 in k14246 in k14225 in k14150 in k14075 in k14051 in foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_14266,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[479];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[385]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[385];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,lf[387]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14288,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_14288(t7,t5);}
else{
t7=C_eqp(t4,lf[396]);
if(C_truep(t7)){
t8=t6;
f_14288(t8,t7);}
else{
t8=C_eqp(t4,lf[397]);
t9=t6;
f_14288(t9,(C_truep(t8)?t8:C_eqp(t4,lf[378])));}}}
else{
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}}

/* k11412 in k11409 in a11403 in dump-undefined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11414,2,av);}
/* support.scm:915: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11409 in a11403 in dump-undefined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11411,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:914: write */
t3=*((C_word*)lf[207]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5607 in k5566 in loop in k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5609(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5609,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1852 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10321(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_10321,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_6134,3,av);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6165,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:302: with-exception-handler */
t5=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a11444 in dump-defined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_11445,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11452,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11474,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:921: keyword? */
t6=*((C_word*)lf[326]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* ##compiler#dump-global-refs in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_11476,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11482,tmp=(C_word)a,a+=2,tmp);
/* support.scm:929: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k11472 in a11444 in dump-defined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11474(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11474,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11452(t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[189],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_11452(t3,(C_truep(t2)?C_i_assq(lf[187],((C_word*)t0)[3]):C_SCHEME_FALSE));}}

/* k8753 in map-loop1427 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8755,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8730(t6,((C_word*)t0)[5],t5);}

/* k11453 in k11450 in a11444 in dump-defined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11455,2,av);}
/* support.scm:925: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11450 in a11444 in dump-defined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11452,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:924: write */
t3=*((C_word*)lf[207]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11146 in k11140 in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11148,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1427 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8730(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8730,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8755,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:617: g1433 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11140 in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,6)))){
C_save_and_reclaim((void *)f_11142,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
t5=((C_word*)t0)[4];
t6=C_slot(t5,C_fix(2));
/* support.scm:869: debugging */
t7=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[318];
av2[3]=lf[319];
av2[4]=t4;
av2[5]=t6;
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k14911 in a14900 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_14913,2,av);}
/* support.scm:1375: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14773(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k9232 in loop in k9169 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_9234,2,av);}
a=C_alloc(10);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9222,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
t7=((C_word*)t0)[5];
t8=C_u_i_cdr(t7);
/* support.scm:660: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_9183(t9,t4,t6,t8);}

/* k7979 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_7981,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_record4(&a,4,lf[211],lf[226],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[4]);
/* support.scm:566: reverse */
t7=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* a14900 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_14901,5,av);}
a=C_alloc(5);
t5=C_i_car(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14913,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1375: append */
t8=*((C_word*)lf[69]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* tmp14370 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_6167,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6171,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6193,tmp=(C_word)a,a+=2,tmp);
/* support.scm:311: with-input-from-string */
t4=*((C_word*)lf[121]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_6165,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6225,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp14370 */
t5=t2;
f_6167(t5,t4);}

/* k5627 in valid-c-identifier? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5629(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,3)))){
C_save_and_reclaim((void *)f_5629,2,av);}
a=C_alloc(2);
if(C_truep(C_i_pairp(t1))){
t2=C_u_i_car(t1);
t3=C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:C_u_i_char_equalp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5650,tmp=(C_word)a,a+=2,tmp);
t6=C_u_i_cdr(t1);
/* support.scm:206: any */
t7=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[2];
av2[2]=t5;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t5=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##compiler#valid-c-identifier? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5625,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5629,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5673,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:202: ->string */
t5=*((C_word*)lf[60]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9205 in loop in k9169 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9207,2,av);}
a=C_alloc(9);
t2=C_a_i_list(&a,2,lf[238],t1);
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8726 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8728,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[253],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10297 in map-loop2039 in k10255 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10299,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10274(t6,((C_word*)t0)[5],t5);}

/* k6155 in a6145 in a6139 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6157,2,av);}
if(C_truep(t1)){
/* support.scm:309: exn-msg */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
/* support.scm:310: ->string */
t2=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k6152 in a6145 in a6139 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6154,2,av);}
/* support.scm:306: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[114];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7958 in k7979 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_7960,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[237],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* g2045 in k10255 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10262(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_10262,3,t0,t1,t2);}
/* support.scm:754: g2062 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9882(t3,t1,t2,((C_word*)t0)[3]);}

/* a6139 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6140,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:302: k484 */
t4=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a6145 in a6139 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6146(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_6146,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6154,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6157,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:308: exn? */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k15700 in k15643 in encodeable-literal? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15702,2,av);}
/* support.scm:1534: every */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[519]+1);
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a15703 in k15643 in encodeable-literal? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15704,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[2],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k15798 in k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_15800,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(4));
/* support.scm:1553: ##sys#print */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k8770 in k8767 in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8772,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15801 in k15798 in k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_15803,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15811,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15811(t6,t2,C_fix(5));}

/* k15804 in k15801 in k15798 in k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15806,2,av);}
/* write-char/port */
t2=*((C_word*)lf[527]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(93);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_15710,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15714,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15719,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_15719(t7,t3,C_fix(0),t2);}

/* k15712 in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15714,2,av);}
/* support.scm:1559: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15719(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_15719,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t5;
t7=t3;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t3;
t11=C_slot(t10,C_fix(3));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15747,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t12,a[5]=t3,a[6]=t1,a[7]=t9,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* support.scm:1547: make-string */
t14=*((C_word*)lf[510]+1);{
C_word av2[4];
av2[0]=t14;
av2[1]=t13;
av2[2]=t2;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}

/* k15825 in k15822 in doloop3815 in k15801 in k15798 in k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 in ... */
static void C_ccall f_15827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15827,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15811(t3,((C_word*)t0)[4],t2);}

/* k15822 in doloop3815 in k15801 in k15798 in k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_15824,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[5],((C_word*)t0)[2]);
/* support.scm:1554: ##sys#print */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k7610 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_7612,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8767 in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8769(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_8769,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8772,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_positivep(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:620: debugging */
t4=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[261];
av2[3]=lf[262];
av2[4]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop1057 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7614(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7614,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:529: g1063 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7057 in loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7059,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:488: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7046(t4,((C_word*)t0)[4],t3);}

/* a5649 in k5627 in valid-c-identifier? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5650,3,av);}
t3=C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_u_i_char_numericp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_u_i_char_equalp(C_make_character(95),t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}

/* map-loop1625 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9259(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9259,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9284,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:662: g1631 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,0,2)))){
C_save_and_reclaim_args((void *)trf_7046,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_i_pairp(t2))){
t3=C_i_caar(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7059,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_eqp(t4,lf[170]);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7070,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t6)){
t8=t7;
f_7070(t8,t6);}
else{
t8=C_eqp(t4,lf[187]);
if(C_truep(t8)){
t9=t7;
f_7070(t9,t8);}
else{
t9=C_eqp(t4,lf[188]);
if(C_truep(t9)){
t10=t7;
f_7070(t10,t9);}
else{
t10=C_eqp(t4,lf[189]);
if(C_truep(t10)){
t11=t7;
f_7070(t11,t10);}
else{
t11=C_eqp(t4,lf[190]);
if(C_truep(t11)){
t12=t7;
f_7070(t12,t11);}
else{
t12=C_eqp(t4,lf[191]);
if(C_truep(t12)){
t13=t7;
f_7070(t13,t12);}
else{
t13=C_eqp(t4,lf[192]);
if(C_truep(t13)){
t14=t7;
f_7070(t14,t13);}
else{
t14=C_eqp(t4,lf[193]);
if(C_truep(t14)){
t15=t7;
f_7070(t15,t14);}
else{
t15=C_eqp(t4,lf[194]);
if(C_truep(t15)){
t16=t7;
f_7070(t16,t15);}
else{
t16=C_eqp(t4,lf[195]);
if(C_truep(t16)){
t17=t7;
f_7070(t17,t16);}
else{
t17=C_eqp(t4,lf[196]);
if(C_truep(t17)){
t18=t7;
f_7070(t18,t17);}
else{
t18=C_eqp(t4,lf[197]);
if(C_truep(t18)){
t19=t7;
f_7070(t19,t18);}
else{
t19=C_eqp(t4,lf[198]);
if(C_truep(t19)){
t20=t7;
f_7070(t20,t19);}
else{
t20=C_eqp(t4,lf[199]);
if(C_truep(t20)){
t21=t7;
f_7070(t21,t20);}
else{
t21=C_eqp(t4,lf[200]);
if(C_truep(t21)){
t22=t7;
f_7070(t22,t21);}
else{
t22=C_eqp(t4,lf[201]);
if(C_truep(t22)){
t23=t7;
f_7070(t23,t22);}
else{
t23=C_eqp(t4,lf[202]);
if(C_truep(t23)){
t24=t7;
f_7070(t24,t23);}
else{
t24=C_eqp(t4,lf[203]);
if(C_truep(t24)){
t25=t7;
f_7070(t25,t24);}
else{
t25=C_eqp(t4,lf[204]);
if(C_truep(t25)){
t26=t7;
f_7070(t26,t25);}
else{
t26=C_eqp(t4,lf[205]);
t27=t7;
f_7070(t27,(C_truep(t26)?t26:C_eqp(t4,lf[206])));}}}}}}}}}}}}}}}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k9220 in k9232 in loop in k9169 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9222,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9688 in fold in fold-boolean in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_9690,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9694,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:683: fold */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9664(t6,t3,t5);}

/* k9692 in k9688 in fold in fold-boolean in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,1)))){
C_save_and_reclaim((void *)f_9694,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[242],lf[280],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-loop2039 in k10255 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10274(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10274,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10299,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:754: g2045 */
t5=((C_word*)t0)[4];
f_10262(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10270 in k10255 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_10272,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7904 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_7906,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[236],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* doloop3815 in k15801 in k15798 in k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_15811,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=*((C_word*)lf[16]+1);
t4=*((C_word*)lf[16]+1);
t5=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15824,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1554: ##sys#write-char-0 */
t7=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=C_make_character(32);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* a15538 in a15532 in a15514 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15539,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* a15532 in a15514 in a15492 in k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2)))){
C_save_and_reclaim((void*)f_15533,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15539,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1499: k3706 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k9282 in map-loop1625 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9284,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9259(t6,((C_word*)t0)[5],t5);}

/* loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,2)))){
C_save_and_reclaim_args((void *)trf_7937,5,t0,t1,t2,t3,t4);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t2))){
t5=C_i_cadr(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7981,a[2]=t6,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:565: reverse */
t8=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t5=C_i_caar(t2);
t6=C_eqp(lf[238],t5);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8023,a[2]=t8,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_a_i_cons(&a,2,lf[240],t3);
/* support.scm:571: reverse */
t11=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_i_caar(t2);
t10=C_a_i_cons(&a,2,t9,t3);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8044,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t8,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8048,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* support.scm:575: cadar */
t14=*((C_word*)lf[239]+1);{
C_word av2[3];
av2[0]=t14;
av2[1]=t13;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}}}

/* ##compiler#export-variable in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_16054,3,av);}
a=C_alloc(3);
t3=C_a_i_list(&a,1,lf[543]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[541];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_i_car(t3);
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[541];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_15771,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[4],lf[35]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15844,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_15844(t8,t4,((C_word*)t0)[4]);}

/* g3785 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15772(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_15772,3,t0,t1,t2);}
/* support.scm:1550: g3800 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_15719(t3,t1,((C_word*)t0)[3],t2);}

/* k15786 in k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15788,2,av);}
/* write-char/port */
t2=*((C_word*)lf[527]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(62);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k15780 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_15782,2,av);}
a=C_alloc(9);
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15788,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(t3,C_fix(4)))){
t5=*((C_word*)lf[16]+1);
t6=*((C_word*)lf[16]+1);
t7=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15800,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1553: ##sys#write-char-0 */
t9=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
/* write-char/port */
t5=*((C_word*)lf[527]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(62);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k15887 in k15872 in read-info-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_15889,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15893,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:1571: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=*((C_word*)lf[158]+1);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k7673 in k7666 in k7663 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7675,2,av);}
t2=C_i_inexact_to_exact(t1);
/* support.scm:532: qnode */
t3=*((C_word*)lf[222]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* g3509 in walkeach in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_14959,3,t0,t1,t2);}
/* support.scm:1379: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14773(t3,t1,t2,((C_word*)t0)[3]);}

/* walkeach in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14957(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_14957,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14959,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_list_2(t2,lf[35]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14971,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_14971(t9,t1,t2);}

/* ##compiler#variable-hidden? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_16074,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16082,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1629: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[541];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k15559 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_15561,2,av);}
a=C_alloc(14);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_slot(((C_word*)t0)[2],C_fix(0));
t5=t4;
if(C_truep(C_i_closurep(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15493,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1499: call-with-current-continuation */
t8=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
/* support.scm:1513: bomb */
t6=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[524];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* map-loop3676 in k15411 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15563(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_15563,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,lf[97],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#simple-lambda-node? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_11277,3,av);}
a=C_alloc(6);
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_u_i_car(t5):C_SCHEME_FALSE);
t8=t7;
if(C_truep(t8)){
t9=C_u_i_cdr(t4);
if(C_truep(C_u_i_car(t9))){
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11305,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=t1;
av2[2]=t2;
f_11305(3,av2);}}
else{
t10=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t9=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k7663 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_7665,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:536: warning */
t3=*((C_word*)lf[228]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[229];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* support.scm:532: qnode */
t2=*((C_word*)lf[222]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k7666 in k7663 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7668,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:538: truncate */
t3=*((C_word*)lf[227]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k10003 in k9997 in k9994 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_10005,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:737: walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_9882(t6,t4,t5,((C_word*)t0)[7]);}

/* a6198 in a6192 in tmp14370 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6199,3,av);}
/* support.scm:313: read */
t3=*((C_word*)lf[117]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a6192 in tmp14370 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6193,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6199,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6207,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:313: read */
t4=*((C_word*)lf[117]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#big-fixnum? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16010,3,av);}
if(C_truep(C_fixnump(t2))){
if(C_truep(C_fudge(C_fix(3)))){
t3=C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(C_truep(t3)?t3:C_fixnum_lessp(t2,C_fix(-1073741824)));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15869 in read-info-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15871,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15872 in read-info-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_15874,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1570: conc */
t5=*((C_word*)lf[507]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[529]+1);
av2[3]=lf[530];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10023 in k10003 in k9997 in k9994 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,1)))){
C_save_and_reclaim((void *)f_10025,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#variable-visible? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_16084,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16088,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1632: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[541];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k16086 in variable-visible? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16088,2,av);}
t2=C_eqp(t1,lf[540]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(t1,lf[543]);
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(C_truep(t3)?C_SCHEME_TRUE:C_i_not(*((C_word*)lf[545]+1)));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15747(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_15747,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(2));
t4=t3;
t5=*((C_word*)lf[16]+1);
t6=*((C_word*)lf[16]+1);
t7=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15756,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* support.scm:1542: ##sys#write-char-0 */
t9=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* map-loop3645 in constant-form-eval in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_15597,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t11=t1;
t12=t9;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k16080 in variable-hidden? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16082,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_eqp(t1,lf[540]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#tree-copy in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_10369,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10375,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10375(t6,t1,t2);}

/* k7637 in map-loop1057 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7639,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7614(t6,((C_word*)t0)[5],t5);}

/* for-each-loop3784 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15844(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_15844,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15854,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1550: g3785 */
t5=((C_word*)t0)[3];
f_15772(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_15759,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1542: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(60);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a11481 in dump-global-refs in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_11482,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11523,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:931: keyword? */
t5=*((C_word*)lf[326]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_15756,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1542: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k15891 in k15887 in k15872 in read-info-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_15893,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=t1;
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),t2);
/* support.scm:1566: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=*((C_word*)lf[158]+1);
av2[3]=((C_word*)t0)[5];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),C_SCHEME_END_OF_LIST);
/* support.scm:1566: ##sys#hash-table-set! */
t3=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=*((C_word*)lf[158]+1);
av2[3]=((C_word*)t0)[5];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_15768,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1542: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_15765,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1542: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_15762,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1542: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* ##compiler#read-info-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_15867,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15871,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15874,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_eqp(lf[531],t2);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=t6;
f_15874(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_15874(t8,C_SCHEME_FALSE);}}

/* g1939 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10053(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_10053,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10057,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:743: gensym */
t4=*((C_word*)lf[110]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,3)))){
C_save_and_reclaim((void *)f_10048,5,av);}
a=C_alloc(26);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=t2;
t11=C_i_check_list_2(t10,lf[161]);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t4,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10213,a[2]=t7,a[3]=t14,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_10213(t16,t12,t10);}

/* ##compiler#build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_8780,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8786,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
f_8786(3,av2);}}

/* walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_8786,3,av);}
a=C_alloc(8);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=t10;
t12=t11;
t13=C_eqp(t12,lf[225]);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8820,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=t12,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t13)){
t15=t14;
f_8820(t15,t13);}
else{
t15=C_eqp(t12,lf[277]);
t16=t14;
f_8820(t16,(C_truep(t15)?t15:C_eqp(t12,lf[278])));}}

/* k12354 in k12280 in k12243 in k12200 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 in ... */
static void C_ccall f_12356(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_12356,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[353]+1))?t1:C_a_i_list(&a,2,lf[361],t1));
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k11493 in k11521 in a11481 in dump-global-refs in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11495,2,av);}
/* support.scm:934: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
av[0]=t0;
av[1]=t1;
av[2]=t2;
C_save_and_reclaim((void *)f_7545,3,av);}
a=C_alloc(21);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:524: varnode */
t3=*((C_word*)lf[220]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;
if(C_truep(C_i_structurep(t3,lf[211]))){
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_not_pair_p(t2))){
/* support.scm:526: bomb */
t4=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[224];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=C_u_i_car(t5);
t7=C_eqp(t6,lf[225]);
t8=(C_truep(t7)?t7:C_eqp(t6,lf[226]));
if(C_truep(t8)){
t9=t2;
t10=C_u_i_car(t9);
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=t2;
t17=C_u_i_cdr(t16);
t18=C_i_check_list_2(t17,lf[161]);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7612,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7614,a[2]=t13,a[3]=t21,a[4]=t15,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t23=((C_word*)t21)[1];
f_7614(t23,t19,t17);}
else{
t9=C_eqp(t6,lf[97]);
if(C_truep(t9)){
t10=C_i_cadr(t2);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7665,a[2]=t1,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_numberp(t11))){
t13=C_eqp(lf[230],*((C_word*)lf[231]+1));
if(C_truep(t13)){
t14=C_i_integerp(t11);
t15=t12;
f_7665(t15,C_i_not(t14));}
else{
t14=t12;
f_7665(t14,C_SCHEME_FALSE);}}
else{
t13=t12;
f_7665(t13,C_SCHEME_FALSE);}}
else{
t10=C_eqp(t6,lf[109]);
if(C_truep(t10)){
t11=C_i_cadr(t2);
t12=C_i_caddr(t2);
t13=t12;
if(C_truep(C_i_nullp(t11))){
/* support.scm:544: walk */
t39=t1;
t40=t13;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t14=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t15=t14;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t16)[1];
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7738,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t13,a[6]=t16,a[7]=t17,tmp=(C_word)a,a+=8,tmp);
/* support.scm:550: unzip1 */
t19=*((C_word*)lf[234]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t19;
av2[1]=t18;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}}
else{
t11=C_eqp(t6,lf[235]);
t12=(C_truep(t11)?t11:C_eqp(t6,lf[133]));
if(C_truep(t12)){
t13=C_i_cadr(t2);
t14=C_a_i_list1(&a,1,t13);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7872,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=C_i_caddr(t2);
/* support.scm:554: walk */
t39=t16;
t40=t17;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t13=C_eqp(t6,lf[236]);
if(C_truep(t13)){
t14=C_i_cadr(t2);
t15=C_i_caddr(t2);
t16=C_a_i_list2(&a,2,t14,t15);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7906,a[2]=t1,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t19=C_i_cadddr(t2);
/* support.scm:558: walk */
t39=t18;
t40=t19;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t14=C_eqp(t6,lf[237]);
if(C_truep(t14)){
t15=C_i_cdddr(t2);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8060,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=t2;
t19=C_u_i_cdr(t18);
t20=C_u_i_cdr(t19);
t21=C_u_i_car(t20);
/* support.scm:561: walk */
t39=t17;
t40=t21;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t15=C_eqp(t6,lf[241]);
if(C_truep(t15)){
t16=C_i_cadr(t2);
t17=t2;
t18=C_u_i_car(t17);
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t16))){
t20=C_u_i_car(t16);
t21=C_eqp(lf[97],t20);
if(C_truep(t21)){
t22=C_i_cadr(t16);
t23=t19;
f_8087(t23,C_a_i_list1(&a,1,t22));}
else{
t22=t19;
f_8087(t22,C_a_i_list1(&a,1,t16));}}
else{
t20=t19;
f_8087(t20,C_a_i_list1(&a,1,t16));}}
else{
t16=C_eqp(t6,lf[242]);
t17=(C_truep(t16)?t16:C_eqp(t6,lf[243]));
if(C_truep(t17)){
t18=t2;
t19=C_u_i_car(t18);
t20=C_i_cadr(t2);
t21=C_a_i_list1(&a,1,t20);
t22=t21;
t23=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t24=t23;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=((C_word*)t25)[1];
t27=((C_word*)((C_word*)t0)[2])[1];
t28=t2;
t29=C_u_i_cdr(t28);
t30=C_u_i_cdr(t29);
t31=C_i_check_list_2(t30,lf[161]);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8186,a[2]=t1,a[3]=t19,a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8188,a[2]=t25,a[3]=t34,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp));
t36=((C_word*)t34)[1];
f_8188(t36,t32,t30);}
else{
t18=C_eqp(t6,lf[244]);
if(C_truep(t18)){
t19=t2;
t20=C_u_i_car(t19);
t21=t2;
t22=C_u_i_cdr(t21);
t23=t1;
t24=t23;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t24;
av2[1]=C_a_i_record4(&a,4,lf[211],t20,t22,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t24+1)))(2,av2);}}
else{
t19=C_eqp(t6,lf[245]);
if(C_truep(t19)){
t20=C_i_cadr(t2);
t21=C_a_i_list2(&a,2,t20,C_SCHEME_TRUE);
t22=t1;
t23=t22;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t23;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[245],t21,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}
else{
t20=C_eqp(t6,lf[246]);
t21=(C_truep(t20)?t20:C_eqp(t6,lf[247]));
if(C_truep(t21)){
t22=C_i_cadr(t2);
t23=C_a_i_list1(&a,1,t22);
t24=t23;
t25=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t26=t25;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=((C_word*)t27)[1];
t29=((C_word*)((C_word*)t0)[2])[1];
t30=t2;
t31=C_u_i_cdr(t30);
t32=C_u_i_cdr(t31);
t33=C_i_check_list_2(t32,lf[161]);
t34=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8297,a[2]=t1,a[3]=t24,tmp=(C_word)a,a+=4,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_set_block_item(t36,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8299,a[2]=t27,a[3]=t36,a[4]=t29,a[5]=t28,tmp=(C_word)a,a+=6,tmp));
t38=((C_word*)t36)[1];
f_8299(t38,t34,t32);}
else{
t22=C_eqp(t6,lf[248]);
if(C_truep(t22)){
t23=C_i_cadr(t2);
t24=C_i_cadr(t23);
t25=t24;
t26=C_i_caddr(t2);
t27=C_i_cadr(t26);
t28=t27;
t29=C_i_cadddr(t2);
t30=C_i_cadr(t29);
t31=t30;
t32=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8384,a[2]=t25,a[3]=t28,a[4]=t31,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm:596: fifth */
t33=*((C_word*)lf[250]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t33;
av2[1]=t32;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t33+1)))(3,av2);}}
else{
t23=C_eqp(t6,lf[251]);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8405,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t23)){
t25=t24;
f_8405(t25,t23);}
else{
t25=C_eqp(t6,lf[257]);
if(C_truep(t25)){
t26=t24;
f_8405(t26,t25);}
else{
t26=C_eqp(t6,lf[258]);
if(C_truep(t26)){
t27=t24;
f_8405(t27,t26);}
else{
t27=C_eqp(t6,lf[259]);
t28=t24;
f_8405(t28,(C_truep(t27)?t27:C_eqp(t6,lf[260])));}}}}}}}}}}}}}}}}
else{
t5=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=((C_word*)((C_word*)t0)[2])[1];
t12=t2;
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8728,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8730,a[2]=t9,a[3]=t15,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_8730(t17,t13,t12);}}}}}

/* ##compiler#build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_7542,3,av);}
a=C_alloc(12);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7545,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8769,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:618: walk */
t9=((C_word*)t6)[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
f_7545(3,av2);}}

/* k10055 in g1939 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,5)))){
C_save_and_reclaim((void *)f_10057,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10060,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:744: put! */
t4=*((C_word*)lf[152]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[288];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k14880 in k14869 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_14882,2,av);}
/* support.scm:1370: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14773(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* ##compiler#words->bytes in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5682,3,av);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=stub346(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#check-and-open-input-file in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2)))){
C_save_and_reclaim((void*)f_5689,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
if(C_truep(C_i_string_equal_p(t2,lf[81]))){
t4=*((C_word*)lf[82]+1);
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=*((C_word*)lf[82]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5702,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:222: file-exists? */
t5=*((C_word*)lf[86]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k9467 in map-loop1694 in k9429 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9469,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9444(t6,((C_word*)t0)[5],t5);}

/* k5671 in valid-c-identifier? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5673,2,av);}
/* string->list */
t2=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#words in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5675,3,av);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=stub341(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9429 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,3)))){
C_save_and_reclaim((void *)f_9431,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_u_i_cdr(((C_word*)t0)[3]);
t9=C_i_check_list_2(t8,lf[161]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9442,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9444,a[2]=t5,a[3]=t12,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9444(t14,t10,t8);}

/* k15852 in for-each-loop3784 in k15769 in k15766 in k15763 in k15760 in k15757 in k15754 in k15745 in loop in dump-nodes in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15854,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15844(t3,((C_word*)t0)[4],t2);}

/* ##compiler#string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_6125,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6129,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6134,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:302: call-with-current-continuation */
t5=*((C_word*)lf[123]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(59,c,6)))){
C_save_and_reclaim((void *)f_6124,2,av);}
a=C_alloc(59);
t2=t1;
t3=C_mutate2((C_word*)lf[113]+1 /* (set! ##compiler#string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6125,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t4=C_mutate2((C_word*)lf[124]+1 /* (set! ##compiler#decompose-lambda-list ...) */,*((C_word*)lf[125]+1));
t5=C_mutate2((C_word*)lf[126]+1 /* (set! ##compiler#llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6228,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[127]+1 /* (set! ##compiler#llist-match? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6231,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[128]+1 /* (set! ##compiler#expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6275,tmp=(C_word)a,a+=2,tmp));
t8=C_SCHEME_TRUE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_mutate2((C_word*)lf[137]+1 /* (set! ##compiler#initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6332,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[148]+1 /* (set! ##compiler#get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6529,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[150]+1 /* (set! ##compiler#get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6547,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[152]+1 /* (set! ##compiler#put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6565,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[154]+1 /* (set! ##compiler#collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6611,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[155]+1 /* (set! ##compiler#count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6663,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[156]+1 /* (set! ##compiler#get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6718,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[157]+1 /* (set! ##compiler#get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6727,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[159]+1 /* (set! ##compiler#get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6737,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[160]+1 /* (set! ##compiler#display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6778,tmp=(C_word)a,a+=2,tmp));
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate2((C_word*)lf[163]+1 /* (set! ##compiler#display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6849,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[210]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7437,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[212]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7443,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[213]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7449,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[214]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7458,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[216]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7467,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[217]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7476,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[218]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7485,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[219]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7494,tmp=(C_word)a,a+=2,tmp));
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16293,tmp=(C_word)a,a+=2,tmp);
/* support.scm:512: ##sys#register-record-printer */
t33=*((C_word*)lf[566]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t33;
av2[1]=t31;
av2[2]=lf[211];
av2[3]=t32;
((C_proc)(void*)(*((C_word*)t33+1)))(4,av2);}}

/* k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_6121,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6124,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:303: condition-property-accessor */
t4=*((C_word*)lf[567]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[521];
av2[3]=lf[522];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* ##compiler#qnode in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_7527,3,av);}
a=C_alloc(8);
t3=C_a_i_list1(&a,1,t2);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[97],t3,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6127 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6129,2,av);}
/* support.scm:302: g488 */
t2=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,3)))){
C_save_and_reclaim((void*)f_15144,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15147,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15163,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1440: resolve */
f_15147(t5,t2);}

/* resolve in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15147(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_15147,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15151,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1435: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[497]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k9440 in k9429 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9442,2,av);}
/* support.scm:671: cons* */
t2=*((C_word*)lf[270]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* map-loop1694 in k9429 in k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9444,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9469,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:671: g1700 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_15096,2,av);}
a=C_alloc(9);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15102,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15126,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* support.scm:1415: gensym */
t8=*((C_word*)lf[110]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_i_car(t6);
/* support.scm:1414: ##sys#print */
t9=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=t8;
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* ##compiler#varnode in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_7512,3,av);}
a=C_alloc(8);
t3=C_a_i_list1(&a,1,t2);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[221],t3,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k12007 in k11992 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,0,1)))){
C_save_and_reclaim_args((void *)trf_12009,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6100 in k6074 in loop in canonicalize-begin-body in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_6102,2,av);}
a=C_alloc(13);
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list(&a,2,t1,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6092,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:299: loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_6052(t10,t7,t9);}

/* k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(137,c,8)))){
C_save_and_reclaim((void *)f_7504,2,av);}
a=C_alloc(137);
t2=C_mutate2((C_word*)lf[210]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7506,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate2((C_word*)lf[220]+1 /* (set! ##compiler#varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7512,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[222]+1 /* (set! ##compiler#qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7527,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[223]+1 /* (set! ##compiler#build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7542,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[263]+1 /* (set! ##compiler#build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8780,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[279]+1 /* (set! ##compiler#fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9658,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[281]+1 /* (set! ##compiler#inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9708,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[286]+1 /* (set! ##compiler#copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9861,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2((C_word*)lf[290]+1 /* (set! ##compiler#tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10369,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[291]+1 /* (set! copy-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10399,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[292]+1 /* (set! ##compiler#copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10437,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[293]+1 /* (set! ##compiler#node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10476,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[294]+1 /* (set! ##compiler#sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10562,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[295]+1 /* (set! ##compiler#emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10633,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[315]+1 /* (set! ##compiler#load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10895,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[317]+1 /* (set! ##compiler#match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10951,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[320]+1 /* (set! ##compiler#expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11168,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[324]+1 /* (set! ##compiler#simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11277,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate2((C_word*)lf[325]+1 /* (set! ##compiler#dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11398,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate2((C_word*)lf[327]+1 /* (set! ##compiler#dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11439,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate2((C_word*)lf[328]+1 /* (set! ##compiler#dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11476,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate2((C_word*)lf[329]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11525,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[332]+1 /* (set! ##compiler#compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11546,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[335]+1 /* (set! ##compiler#print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11659,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[345]+1 /* (set! ##compiler#pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11758,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[350]+1 /* (set! ##compiler#foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11816,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[435]+1 /* (set! ##compiler#foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12809,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[436]+1 /* (set! ##compiler#foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12840,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[437]+1 /* (set! ##compiler#final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12871,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate2((C_word*)lf[439]+1 /* (set! ##compiler#estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12916,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate2((C_word*)lf[444]+1 /* (set! ##compiler#estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13348,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate2((C_word*)lf[447]+1 /* (set! ##compiler#finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13781,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate2((C_word*)lf[461]+1 /* (set! ##compiler#foreign-type->scrutiny-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14049,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate2((C_word*)lf[481]+1 /* (set! ##compiler#scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14615,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate2((C_word*)lf[482]+1 /* (set! ##compiler#scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14770,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate2((C_word*)lf[484]+1 /* (set! ##compiler#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15000,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate2((C_word*)lf[487]+1 /* (set! ##compiler#chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15027,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate2((C_word*)lf[488]+1 /* (set! ##compiler#make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15067,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate2((C_word*)lf[490]+1 /* (set! ##compiler#block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15073,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate2((C_word*)lf[491]+1 /* (set! ##compiler#block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15079,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate2((C_word*)lf[493]+1 /* (set! ##compiler#make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15088,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate2((C_word*)lf[496]+1 /* (set! ##compiler#set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15137,tmp=(C_word)a,a+=2,tmp));
t44=C_set_block_item(lf[498] /* real-name-max-depth */,0,C_fix(20));
t45=C_mutate2((C_word*)lf[47]+1 /* (set! ##compiler#real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15144,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate2((C_word*)lf[504]+1 /* (set! ##compiler#real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15264,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate2((C_word*)lf[505]+1 /* (set! ##compiler#display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15276,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate2((C_word*)lf[506]+1 /* (set! ##compiler#source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15300,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate2((C_word*)lf[512]+1 /* (set! ##compiler#source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15334,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate2((C_word*)lf[513]+1 /* (set! ##compiler#call-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15352,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate2((C_word*)lf[516]+1 /* (set! ##compiler#constant-form-eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15389,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate2((C_word*)lf[519]+1 /* (set! ##compiler#encodeable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15631,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate2((C_word*)lf[526]+1 /* (set! ##compiler#dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15710,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate2((C_word*)lf[528]+1 /* (set! ##compiler#read-info-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15867,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate2((C_word*)lf[532]+1 /* (set! ##compiler#read/source-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15910,tmp=(C_word)a,a+=2,tmp));
t56=*((C_word*)lf[534]+1);
t57=C_mutate2((C_word*)lf[534]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15916,a[2]=t56,tmp=(C_word)a,a+=3,tmp));
t58=C_mutate2((C_word*)lf[537]+1 /* (set! ##compiler#scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15941,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate2((C_word*)lf[102]+1 /* (set! ##compiler#big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16010,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate2((C_word*)lf[330]+1 /* (set! ##compiler#hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16034,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate2((C_word*)lf[542]+1 /* (set! ##compiler#export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16054,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate2((C_word*)lf[544]+1 /* (set! ##compiler#variable-hidden? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16074,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate2((C_word*)lf[314]+1 /* (set! ##compiler#variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16084,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate2((C_word*)lf[546]+1 /* (set! ##compiler#mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16109,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate2((C_word*)lf[547]+1 /* (set! ##compiler#variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16124,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate2((C_word*)lf[548]+1 /* (set! ##compiler#intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16130,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate2((C_word*)lf[549]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16141,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate2((C_word*)lf[550]+1 /* (set! ##compiler#load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16152,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate2((C_word*)lf[558]+1 /* (set! ##compiler#print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16250,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate2((C_word*)lf[561]+1 /* (set! ##compiler#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16275,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate2((C_word*)lf[563]+1 /* (set! ##compiler#print-debug-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16287,tmp=(C_word)a,a+=2,tmp));
t72=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t72;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t72+1)))(2,av2);}}

/* k6105 in loop in canonicalize-begin-body in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6107(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6107,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_6076(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6076(t2,C_i_equalp(((C_word*)t0)[3],lf[112]));}}

/* make-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_7506,5,av);}
a=C_alloc(5);
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[211],t2,t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6169 in tmp14370 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6171,2,av);}
a=C_alloc(3);
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[115];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(t1);
t3=C_i_nullp(t2);
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(C_truep(t3)?C_u_i_car(t1):C_a_i_cons(&a,2,lf[116],t1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##compiler#set-real-name! in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15137,4,av);}
/* support.scm:1428: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=*((C_word*)lf[497]+1);
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k14869 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_14871,2,av);}
a=C_alloc(5);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1370: append */
t5=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* ##compiler#llist-match? in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,3)))){
C_save_and_reclaim((void *)f_6231,4,av);}
a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6237,tmp=(C_word)a,a+=2,tmp);
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=(
  f_6237(t2,t3)
);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in llist-match? in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static C_word C_fcall f_6237(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t1))){
return(C_i_nullp(t2));}
else{
t3=C_i_symbolp(t1);
if(C_truep(t3)){
return(t3);}
else{
if(C_truep(C_i_nullp(t2))){
return(C_i_not_pair_p(t1));}
else{
t4=C_i_cdr(t1);
t5=C_i_cdr(t2);
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}}

/* k11884 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_11886,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[353]+1))?t1:C_a_i_list(&a,2,lf[361],t1));
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_12033,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[353]+1))){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_assq(t2,lf[369]);
t4=C_slot(t3,C_fix(1));
t5=C_a_i_list(&a,2,lf[97],t4);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[365],t5,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[370]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_12059(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[408]);
if(C_truep(t4)){
t5=t3;
f_12059(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[409]);
t6=t3;
f_12059(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[410])));}}}}

/* k6223 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6225,2,av);}
a=C_alloc(3);
/* tmp24371 */
t2=((C_word*)t0)[2];
f_6208(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* ##compiler#llist-length in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6228,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_u_i_length(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k15149 in resolve in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_15151,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15157,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1437: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[497]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15155 in k15149 in resolve in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15157,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=(C_truep(t1)?t1:((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a6213 in tmp24371 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6214,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* ##compiler#initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_6332,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=*((C_word*)lf[138]+1);
t4=C_i_check_list_2(*((C_word*)lf[138]+1),lf[35]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6385,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6506,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_6506(t9,t5,*((C_word*)lf[138]+1));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6334 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6336,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k15120 in k15103 in k15100 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15122,2,av);}
/* support.scm:1414: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k15124 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15126,2,av);}
/* support.scm:1414: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,5)))){
C_save_and_reclaim_args((void *)trf_14807,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[221]);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[4]);
t4=t3;
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14826,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1361: lset-adjoin */
t6=*((C_word*)lf[483]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=((C_word*)((C_word*)t0)[6])[1];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[246]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_i_car(((C_word*)t0)[8]);
/* support.scm:1367: walk */
t6=((C_word*)((C_word*)t0)[9])[1];
f_14773(t6,((C_word*)t0)[2],t5,((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14862,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1366: lset-adjoin */
t6=*((C_word*)lf[483]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=((C_word*)((C_word*)t0)[6])[1];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[109]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14871,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[8]);
/* support.scm:1369: walk */
t7=((C_word*)((C_word*)t0)[9])[1];
f_14773(t7,t5,t6,((C_word*)t0)[5]);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[133]);
if(C_truep(t5)){
t6=C_i_caddr(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14901,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1372: decompose-lambda-list */
t8=*((C_word*)lf[124]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=((C_word*)t0)[2];
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
/* support.scm:1376: walkeach */
t6=((C_word*)((C_word*)t0)[10])[1];
f_14957(t6,((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[5]);}}}}}}

/* k6205 in a6192 in tmp14370 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6207,2,av);}
/* support.scm:313: unfold */
t2=*((C_word*)lf[118]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[119]+1);
av2[3]=*((C_word*)lf[120]+1);
av2[4]=((C_word*)t0)[3];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* tmp24371 in a6164 in a6133 in string->expr in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_6208,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6214,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:302: k484 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6277 in expand-profile-lambda in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(106,c,1)))){
C_save_and_reclaim((void *)f_6279,2,av);}
a=C_alloc(106);
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),*((C_word*)lf[130]+1));
t3=C_mutate2((C_word*)lf[130]+1 /* (set! ##compiler#profile-lambda-list ...) */,t2);
t4=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=C_mutate2((C_word*)lf[129]+1 /* (set! ##compiler#profile-lambda-index ...) */,t4);
t6=C_a_i_list(&a,2,lf[97],((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[131],t6,*((C_word*)lf[132]+1));
t8=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t7);
t9=C_a_i_list(&a,3,lf[133],((C_word*)t0)[4],((C_word*)t0)[5]);
t10=C_a_i_list(&a,3,lf[134],t9,t1);
t11=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t10);
t12=C_a_i_list(&a,2,lf[97],((C_word*)t0)[2]);
t13=C_a_i_list(&a,3,lf[135],t12,*((C_word*)lf[132]+1));
t14=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t13);
t15=C_a_i_list(&a,4,lf[136],t8,t11,t14);
t16=((C_word*)t0)[6];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t16;
av2[1]=C_a_i_list(&a,3,lf[133],t1,t15);
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}

/* ##compiler#expand-profile-lambda in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_6275,5,av);}
a=C_alloc(7);
t5=*((C_word*)lf[129]+1);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6279,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:335: gensym */
t7=*((C_word*)lf[110]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k6383 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_6385,2,av);}
a=C_alloc(8);
t2=*((C_word*)lf[139]+1);
t3=C_i_check_list_2(*((C_word*)lf[139]+1),lf[35]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6483,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6483(t8,t4,*((C_word*)lf[139]+1));}

/* k9411 in loop in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_9413,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:669: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9372(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_11822,4,av);}
a=C_alloc(7);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11828,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_11828(t7,t1,t2);}

/* repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_11828,3,t0,t1,t2);}
a=C_alloc(8);
t3=t2;
t4=C_eqp(t3,lf[351]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[352]));
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(*((C_word*)lf[353]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[354],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(t3,lf[355]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11853,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_11853(t8,t6);}
else{
t8=C_eqp(t3,lf[427]);
if(C_truep(t8)){
t9=t7;
f_11853(t9,t8);}
else{
t9=C_eqp(t3,lf[428]);
if(C_truep(t9)){
t10=t7;
f_11853(t10,t9);}
else{
t10=C_eqp(t3,lf[429]);
if(C_truep(t10)){
t11=t7;
f_11853(t11,t10);}
else{
t11=C_eqp(t3,lf[430]);
if(C_truep(t11)){
t12=t7;
f_11853(t12,t11);}
else{
t12=C_eqp(t3,lf[431]);
if(C_truep(t12)){
t13=t7;
f_11853(t13,t12);}
else{
t13=C_eqp(t3,lf[432]);
t14=t7;
f_11853(t14,(C_truep(t13)?t13:C_eqp(t3,lf[433])));}}}}}}}}

/* k14150 in k14075 in k14051 in foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_14152,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[462]);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,lf[465],((C_word*)t0)[3]);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[466],lf[467],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[465],((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[368]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[468];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[5],lf[412]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[469];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[5],lf[411]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[470];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[5],lf[413]);
if(C_truep(t5)){
t6=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[471];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[5],lf[414]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t7;
av2[1]=lf[472];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[5],lf[415]);
if(C_truep(t7)){
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[473];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[5],lf[416]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t9;
av2[1]=lf[474];
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[5],lf[417]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[475];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[5],lf[370]);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14227,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
t12=t11;
f_14227(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[408]);
if(C_truep(t12)){
t13=t11;
f_14227(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[5],lf[409]);
if(C_truep(t13)){
t14=t11;
f_14227(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[410]);
if(C_truep(t14)){
t15=t11;
f_14227(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[406]);
if(C_truep(t15)){
t16=t11;
f_14227(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[372]);
if(C_truep(t16)){
t17=t11;
f_14227(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[5],lf[376]);
t18=t11;
f_14227(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[5],lf[407])));}}}}}}}}}}}}}}}}

/* k9422 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,0,3)))){
C_save_and_reclaim_args((void *)trf_9424,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:671: walk */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
f_8786(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[7],lf[251]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[7],lf[273]));
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)((C_word*)t0)[2])[1];
t9=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9502,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9504,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9504(t14,t10,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9543,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=((C_word*)((C_word*)t0)[2])[1];
t10=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9553,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9555,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9555(t15,t11,((C_word*)t0)[3]);}}}

/* k7074 in k7068 in loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7076,2,av);}
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_assq(t2,lf[171]);
t4=C_i_cdr(t3);
/* support.scm:471: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* ##compiler#foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_11816,4,av);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11822,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1022: follow-without-loop */
t6=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7068 in loop in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_7070,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:471: ##sys#write-char-0 */
t6=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(9);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[169]);
if(C_truep(t2)){
t3=C_mutate2(((C_word *)((C_word*)t0)[5])+1,lf[169]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* support.scm:488: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_7046(t6,((C_word*)t0)[7],t5);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[172]);
if(C_truep(t3)){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:488: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7046(t7,((C_word*)t0)[7],t6);}
else{
t5=C_i_cdar(((C_word*)t0)[2]);
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
/* support.scm:488: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_7046(t9,((C_word*)t0)[7],t8);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[173]);
if(C_truep(t4)){
t5=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:488: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_7046(t8,((C_word*)t0)[7],t7);}
else{
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:488: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_7046(t10,((C_word*)t0)[7],t9);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[174]);
if(C_truep(t5)){
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate2(((C_word *)((C_word*)t0)[9])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:488: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_7046(t10,((C_word*)t0)[7],t9);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[175]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_7149(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[179]);
if(C_truep(t8)){
t9=t7;
f_7149(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[180]);
if(C_truep(t9)){
t10=t7;
f_7149(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[181]);
if(C_truep(t10)){
t11=t7;
f_7149(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[182]);
if(C_truep(t11)){
t12=t7;
f_7149(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[183]);
if(C_truep(t12)){
t13=t7;
f_7149(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[184]);
if(C_truep(t13)){
t14=t7;
f_7149(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[185]);
t15=t7;
f_7149(t15,(C_truep(t14)?t14:C_eqp(((C_word*)t0)[4],lf[186])));}}}}}}}}}}}}}

/* ##compiler#hide-variable in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_16034,3,av);}
a=C_alloc(3);
t3=C_a_i_list(&a,1,lf[540]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[541];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_i_car(t3);
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[541];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* walk in expression-has-side-effects? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_11174,3,av);}
a=C_alloc(7);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=t7;
t9=C_eqp(t8,lf[221]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11200,a[2]=t1,a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_11200(t11,t9);}
else{
t11=C_eqp(t8,lf[97]);
if(C_truep(t11)){
t12=t10;
f_11200(t12,t11);}
else{
t12=C_eqp(t8,lf[226]);
t13=t10;
f_11200(t13,(C_truep(t12)?t12:C_eqp(t8,lf[245])));}}}

/* k11798 in for-each-loop2562 in a11772 in k11760 in pprint-expressions-to-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11800,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11790(t3,((C_word*)t0)[4],t2);}

/* ##compiler#expression-has-side-effects? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11168,4,av);}
a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11174,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t1;
av2[2]=t2;
f_11174(3,av2);}}

/* k14824 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_14826,2,av);}
a=C_alloc(5);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1362: variable-visible? */
t4=*((C_word*)lf[314]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a13774 in estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_13775,2,av);}
/* support.scm:1231: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[446];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k13368 in a13359 in estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_13370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_13370,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1217: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[425]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_13382(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[426]);
if(C_truep(t4)){
t5=t3;
f_13382(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[372]);
t6=t3;
f_13382(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[3],lf[376])));}}}}

/* k13380 in k13368 in a13359 in estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_13382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_13382,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1219: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(2);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1221: ##sys#hash-table-ref */
t3=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[398]+1);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_13388(2,av2);}}}}

/* k13386 in k13380 in k13368 in a13359 in estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_13388,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1221: g3148 */
t3=t2;
f_13392(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[387]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_13425(t6,t4);}
else{
t6=C_eqp(t3,lf[395]);
if(C_truep(t6)){
t7=t5;
f_13425(t7,t6);}
else{
t7=C_eqp(t3,lf[396]);
if(C_truep(t7)){
t8=t5;
f_13425(t8,t7);}
else{
t8=C_eqp(t3,lf[378]);
if(C_truep(t8)){
t9=t5;
f_13425(t9,t8);}
else{
t9=C_eqp(t3,lf[380]);
if(C_truep(t9)){
t10=t5;
f_13425(t10,t9);}
else{
t10=C_eqp(t3,lf[397]);
if(C_truep(t10)){
t11=t5;
f_13425(t11,t10);}
else{
t11=C_eqp(t3,lf[360]);
t12=t5;
f_13425(t12,(C_truep(t11)?t11:C_eqp(t3,lf[362])));}}}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
/* support.scm:1207: quit */
t4=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[445];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* k15116 in k15106 in k15103 in k15100 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15118,2,av);}
/* support.scm:1414: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k15109 in k15106 in k15103 in k15100 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_15111,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1414: get-output-string */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k15112 in k15109 in k15106 in k15103 in k15100 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15114,2,av);}
/* support.scm:1413: string->symbol */
t2=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k16003 in k15952 in loop in k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16005,2,av);}
/* support.scm:1608: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15950(t2,((C_word*)t0)[3]);}

/* a13359 in estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_13360,4,av);}
a=C_alloc(6);
t4=t2;
t5=C_eqp(t4,lf[351]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13370,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_13370(t7,t5);}
else{
t7=C_eqp(t4,lf[355]);
if(C_truep(t7)){
t8=t6;
f_13370(t8,t7);}
else{
t8=C_eqp(t4,lf[428]);
if(C_truep(t8)){
t9=t6;
f_13370(t9,t8);}
else{
t9=C_eqp(t4,lf[440]);
if(C_truep(t9)){
t10=t6;
f_13370(t10,t9);}
else{
t10=C_eqp(t4,lf[429]);
if(C_truep(t10)){
t11=t6;
f_13370(t11,t10);}
else{
t11=C_eqp(t4,lf[352]);
if(C_truep(t11)){
t12=t6;
f_13370(t12,t11);}
else{
t12=C_eqp(t4,lf[427]);
if(C_truep(t12)){
t13=t6;
f_13370(t13,t12);}
else{
t13=C_eqp(t4,lf[408]);
if(C_truep(t13)){
t14=t6;
f_13370(t14,t13);}
else{
t14=C_eqp(t4,lf[407]);
if(C_truep(t14)){
t15=t6;
f_13370(t15,t14);}
else{
t15=C_eqp(t4,lf[430]);
if(C_truep(t15)){
t16=t6;
f_13370(t16,t15);}
else{
t16=C_eqp(t4,lf[431]);
if(C_truep(t16)){
t17=t6;
f_13370(t17,t16);}
else{
t17=C_eqp(t4,lf[378]);
if(C_truep(t17)){
t18=t6;
f_13370(t18,t17);}
else{
t18=C_eqp(t4,lf[380]);
if(C_truep(t18)){
t19=t6;
f_13370(t19,t18);}
else{
t19=C_eqp(t4,lf[374]);
if(C_truep(t19)){
t20=t6;
f_13370(t20,t19);}
else{
t20=C_eqp(t4,lf[370]);
if(C_truep(t20)){
t21=t6;
f_13370(t21,t20);}
else{
t21=C_eqp(t4,lf[357]);
if(C_truep(t21)){
t22=t6;
f_13370(t22,t21);}
else{
t22=C_eqp(t4,lf[381]);
if(C_truep(t22)){
t23=t6;
f_13370(t23,t22);}
else{
t23=C_eqp(t4,lf[385]);
if(C_truep(t23)){
t24=t6;
f_13370(t24,t23);}
else{
t24=C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_13370(t25,t24);}
else{
t25=C_eqp(t4,lf[362]);
if(C_truep(t25)){
t26=t6;
f_13370(t26,t25);}
else{
t26=C_eqp(t4,lf[432]);
if(C_truep(t26)){
t27=t6;
f_13370(t27,t26);}
else{
t27=C_eqp(t4,lf[433]);
if(C_truep(t27)){
t28=t6;
f_13370(t28,t27);}
else{
t28=C_eqp(t4,lf[410]);
if(C_truep(t28)){
t29=t6;
f_13370(t29,t28);}
else{
t29=C_eqp(t4,lf[406]);
if(C_truep(t29)){
t30=t6;
f_13370(t30,t29);}
else{
t30=C_eqp(t4,lf[402]);
if(C_truep(t30)){
t31=t6;
f_13370(t31,t30);}
else{
t31=C_eqp(t4,lf[403]);
if(C_truep(t31)){
t32=t6;
f_13370(t32,t31);}
else{
t32=C_eqp(t4,lf[400]);
if(C_truep(t32)){
t33=t6;
f_13370(t33,t32);}
else{
t33=C_eqp(t4,lf[409]);
if(C_truep(t33)){
t34=t6;
f_13370(t34,t33);}
else{
t34=C_eqp(t4,lf[384]);
if(C_truep(t34)){
t35=t6;
f_13370(t35,t34);}
else{
t35=C_eqp(t4,lf[401]);
if(C_truep(t35)){
t36=t6;
f_13370(t36,t35);}
else{
t36=C_eqp(t4,lf[399]);
if(C_truep(t36)){
t37=t6;
f_13370(t37,t36);}
else{
t37=C_eqp(t4,lf[404]);
t38=t6;
f_13370(t38,(C_truep(t37)?t37:C_eqp(t4,lf[405])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* matchn in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_11027,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:855: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10954(t4,t1,t3,t2);}
else{
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=C_i_car(t3);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11049,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_cadr(t3);
/* support.scm:857: match1 */
t12=((C_word*)((C_word*)t0)[4])[1];
f_10988(t12,t8,t10,t11);}
else{
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}

/* k11008 in match1 in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11010,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:850: match1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10988(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* g3148 in k13386 in k13380 in k13368 in a13359 in estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_13392(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_13392,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1223: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1223: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k14834 in k14830 in k14824 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_14836,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k14830 in k14824 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_14832,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1363: lset-adjoin */
t3=*((C_word*)lf[483]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=((C_word*)((C_word*)t0)[3])[1];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k14860 in k14805 in walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_14862,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:1367: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_14773(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* k11047 in matchn in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_11049,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_slot(t2,C_fix(3));
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11067,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_11067(t8,((C_word*)t0)[6],t3,t4);}
else{
t2=((C_word*)t0)[6];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_15190,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15192,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_15192(t5,((C_word*)t0)[4],((C_word*)t0)[5],C_fix(0),t1);}

/* loop in k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15192(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_15192,5,t0,t1,t2,t3,t4);}
a=C_alloc(8);
if(C_truep(C_i_greaterp(t3,*((C_word*)lf[498]+1)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15206,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_cons(&a,2,lf[501],t2);
/* support.scm:1449: reverse */
t7=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15216,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1451: resolve */
f_15147(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15255,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1457: reverse */
t6=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_15163,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15259,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1444: ##sys#symbol->qualified-string */
t5=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:1458: ##sys#symbol->qualified-string */
t2=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}
else{
/* support.scm:1441: ##sys#symbol->qualified-string */
t2=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k6354 in for-each-loop534 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6356(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6356,2,av);}
a=C_alloc(3);
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[144]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15103 in k15100 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15105(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_15105,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15122,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1416: current-seconds */
t4=*((C_word*)lf[495]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k15106 in k15103 in k15100 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_15108,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15118,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1417: random */
t4=*((C_word*)lf[494]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_fix(1000);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k15100 in k15094 in make-random-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_15102,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1414: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(45);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10670 in for-each-loop2246 in k10652 in k10644 in k10638 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10672(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10672,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10662(t3,((C_word*)t0)[4],t2);}

/* k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_11868,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=(C_truep(*((C_word*)lf[353]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[358],((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[359]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[360]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1032: gensym */
t5=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[362]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[363]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(*((C_word*)lf[353]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[361],((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[4],lf[364]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1044: gensym */
t8=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[366]);
if(C_truep(t7)){
if(C_truep(*((C_word*)lf[353]+1))){
t8=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t8;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_a_i_list(&a,2,lf[97],lf[364]);
t9=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_list(&a,3,lf[365],t8,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=C_eqp(((C_word*)t0)[4],lf[367]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t8)){
t10=t9;
f_11991(t10,t8);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[418]);
if(C_truep(t10)){
t11=t9;
f_11991(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[419]);
if(C_truep(t11)){
t12=t9;
f_11991(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[420]);
if(C_truep(t12)){
t13=t9;
f_11991(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[421]);
if(C_truep(t13)){
t14=t9;
f_11991(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[422]);
if(C_truep(t14)){
t15=t9;
f_11991(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[423]);
t16=t9;
f_11991(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[4],lf[424])));}}}}}}}}}}}}

/* k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_11853,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[353]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[356],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[357]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11868(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[425]);
t5=t3;
f_11868(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[426])));}}}

/* k9931 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_9933,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* support.scm:712: alist-ref */
t4=*((C_word*)lf[287]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=t3;
av2[4]=*((C_word*)lf[13]+1);
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k9941 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9943(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9943,2,av);}
if(C_truep(t1)){
/* support.scm:723: cfk */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_9933(2,av2);}}}

/* k9339 in map-loop1651 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9341,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9316(t6,((C_word*)t0)[5],t5);}

/* k9938 in k9931 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9940,2,av);}
/* support.scm:724: varnode */
t2=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#display-line-number-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_6778,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6784,tmp=(C_word)a,a+=2,tmp);
/* support.scm:429: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[158]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5111 in quit in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5113,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:107: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k9312 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9314,2,av);}
/* support.scm:663: cons* */
t2=*((C_word*)lf[270]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[243];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5114 in k5111 in quit in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5116,2,av);}
/* support.scm:108: exit */
t2=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1651 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9316(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9316,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9341,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:663: g1657 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9994 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_9996,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:732: gensym */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k9997 in k9994 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_9999,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t2),((C_word*)t0)[3]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10005,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* support.scm:734: put! */
t6=*((C_word*)lf[152]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[8];
av2[3]=t2;
av2[4]=lf[288];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}

/* k5098 in k5074 in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5100,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:102: with-output-to-string */
t3=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##compiler#collect! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6611,6,av);}
a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6615,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:395: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* ##compiler#quit in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +9,c,3)))){
C_save_and_reclaim((void*)f_5109,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+9);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=*((C_word*)lf[30]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5113,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5123,a[2]=t5,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:106: string-append */
t7=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[32];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k5105 in k5098 in k5074 in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5107(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5107,2,av);}
/* support.scm:102: collect */
t2=((C_word*)t0)[2];
f_5015(t2,((C_word*)t0)[3],t1);}

/* k6613 in collect! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6615(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_6615,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=C_slot(t1,C_fix(1));
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t3),t4);
t6=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_i_setslot(t1,C_fix(1),t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:400: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* g169 in k5130 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_5133,3,t0,t1,t2);}
/* support.scm:121: g184 */
t3=*((C_word*)lf[24]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[34];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5130 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_5132,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[35]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5143,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5151,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5151(t9,t5,t3);}

/* ##compiler#finish-foreign-result in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_13781,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13785,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1237: ##sys#strip-syntax */
t5=*((C_word*)lf[460]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* loop in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_9372,5,t0,t1,t2,t3,t4);}
a=C_alloc(11);
if(C_truep(C_i_zerop(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9386,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:668: reverse */
t6=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=C_a_i_minus(&a,2,t2,C_fix(1));
t6=t5;
t7=C_i_cdr(t3);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9413,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t6,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t10=t3;
t11=C_u_i_car(t10);
/* support.scm:669: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t9;
av2[2]=t11;
f_8786(3,av2);}}}

/* k9970 in k9978 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_9972,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[246],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_5129,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5178,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:119: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[40];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5199,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:120: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[41];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* k5121 in quit in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_5123,2,av);}{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[24]+1);
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
av2[5]=((C_word*)t0)[4];
C_apply(6,av2);}}

/* ##sys#syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +10,c,2)))){
C_save_and_reclaim((void*)f_5125,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+10);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[30]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5129,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t8=((C_word*)t4)[1];
t9=C_i_car(((C_word*)t5)[1]);
t10=C_set_block_item(t4,0,t9);
t11=C_i_cdr(((C_word*)t5)[1]);
t12=C_set_block_item(t5,0,t11);
t13=t7;
f_5129(t13,t8);}
else{
t8=t7;
f_5129(t8,C_SCHEME_FALSE);}}

/* k9978 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_9980,2,av);}
a=C_alloc(7);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9972,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[3]);
/* support.scm:728: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9882(t6,t4,t5,((C_word*)t0)[5]);}

/* k9384 in loop in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_9386,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9390,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* support.scm:668: walk */
t5=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
f_8786(3,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_support_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_support_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(4478))){
C_save(t1);
C_rereclaim2(4478*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,569);
lf[0]=C_h_intern(&lf[0],30,"\010compilercompiler-cleanup-hook");
lf[1]=C_h_intern(&lf[1],26,"\010compilerdebugging-chicken");
lf[2]=C_h_intern(&lf[2],26,"\010compilerdisabled-warnings");
lf[3]=C_h_intern(&lf[3],13,"\010compilerbomb");
lf[4]=C_h_intern(&lf[4],5,"error");
lf[5]=C_h_intern(&lf[5],13,"string-append");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[8]=C_h_intern(&lf[8],35,"\010compilercollected-debugging-output");
lf[9]=C_h_intern(&lf[9],24,"+logged-debugging-modes+");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\001x\376\003\000\000\002\376\001\000\000\001S\376\377\016");
lf[11]=C_h_intern(&lf[11],19,"test-debugging-mode");
lf[12]=C_h_intern(&lf[12],17,"lset-intersection");
lf[13]=C_h_intern(&lf[13],3,"eq\077");
lf[14]=C_h_intern(&lf[14],18,"\010compilerdebugging");
lf[15]=C_h_intern(&lf[15],7,"newline");
lf[16]=C_h_intern(&lf[16],19,"\003sysstandard-output");
lf[17]=C_h_intern(&lf[17],6,"printf");
lf[18]=C_h_intern(&lf[18],16,"\003syswrite-char-0");
lf[19]=C_h_intern(&lf[19],9,"\003sysprint");
lf[20]=C_h_intern(&lf[20],5,"force");
lf[21]=C_h_intern(&lf[21],7,"display");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[23]=C_h_intern(&lf[23],21,"with-output-to-string");
lf[24]=C_h_intern(&lf[24],7,"fprintf");
lf[25]=C_h_intern(&lf[25],12,"flush-output");
lf[26]=C_h_intern(&lf[26],30,"\010compilerwith-debugging-output");
lf[27]=C_h_intern(&lf[27],12,"string-split");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[29]=C_h_intern(&lf[29],13,"\010compilerquit");
lf[30]=C_h_intern(&lf[30],18,"\003sysstandard-error");
lf[31]=C_h_intern(&lf[31],4,"exit");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[33]=C_h_intern(&lf[33],21,"\003syssyntax-error-hook");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[35]=C_h_intern(&lf[35],8,"for-each");
lf[36]=C_h_intern(&lf[36],16,"print-call-chain");
lf[37]=C_h_intern(&lf[37],18,"\003syscurrent-thread");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error (");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error: ");
lf[42]=C_h_intern(&lf[42],12,"syntax-error");
lf[43]=C_h_intern(&lf[43],31,"\010compileremit-syntax-trace-info");
lf[44]=C_h_intern(&lf[44],9,"map-llist");
lf[45]=C_h_intern(&lf[45],24,"\010compilercheck-signature");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[47]=C_h_intern(&lf[47],18,"\010compilerreal-name");
lf[48]=C_h_intern(&lf[48],13,"\010compilerposq");
lf[49]=C_h_intern(&lf[49],13,"\010compilerposv");
lf[50]=C_h_intern(&lf[50],18,"\010compilerstringify");
lf[51]=C_h_intern(&lf[51],14,"symbol->string");
lf[52]=C_h_intern(&lf[52],7,"sprintf");
lf[53]=C_h_intern(&lf[53],17,"get-output-string");
lf[54]=C_h_intern(&lf[54],18,"open-output-string");
lf[55]=C_h_intern(&lf[55],18,"\010compilersymbolify");
lf[56]=C_h_intern(&lf[56],14,"string->symbol");
lf[57]=C_h_intern(&lf[57],21,"\010compilerbackslashify");
lf[58]=C_h_intern(&lf[58],17,"string-translate\052");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\134\376B\000\000\002\134\134\376\377\016");
lf[60]=C_h_intern(&lf[60],8,"->string");
lf[61]=C_h_intern(&lf[61],21,"\010compileruncommentify");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002\052/\376B\000\000\003\052_/\376\377\016");
lf[63]=C_h_intern(&lf[63],26,"\010compilerbuild-lambda-list");
lf[64]=C_h_intern(&lf[64],29,"\010compilerstring->c-identifier");
lf[65]=C_h_intern(&lf[65],24,"\003sysstring->c-identifier");
lf[66]=C_h_intern(&lf[66],21,"\010compilerc-ify-string");
lf[67]=C_h_intern(&lf[67],16,"\003syslist->string");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[69]=C_h_intern(&lf[69],6,"append");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[71]=C_h_intern(&lf[71],16,"\003sysstring->list");
lf[72]=C_h_intern(&lf[72],14,"number->string");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\003\000\000\002\376\377\012\000\000\052\376\377\016");
lf[76]=C_h_intern(&lf[76],28,"\010compilervalid-c-identifier\077");
lf[77]=C_h_intern(&lf[77],3,"any");
lf[78]=C_h_intern(&lf[78],14,"\010compilerwords");
lf[79]=C_h_intern(&lf[79],21,"\010compilerwords->bytes");
lf[80]=C_h_intern(&lf[80],34,"\010compilercheck-and-open-input-file");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[82]=C_h_intern(&lf[82],18,"\003sysstandard-input");
lf[83]=C_h_intern(&lf[83],15,"open-input-file");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\031(~a) can not open file ~s");
lf[86]=C_h_intern(&lf[86],12,"file-exists\077");
lf[87]=C_h_intern(&lf[87],33,"\010compilerclose-checked-input-file");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[89]=C_h_intern(&lf[89],16,"close-input-port");
lf[90]=C_h_intern(&lf[90],19,"\010compilerfold-inner");
lf[91]=C_h_intern(&lf[91],7,"reverse");
lf[92]=C_h_intern(&lf[92],28,"\010compilerfollow-without-loop");
lf[93]=C_h_intern(&lf[93],21,"\010compilersort-symbols");
lf[94]=C_h_intern(&lf[94],8,"string<\077");
lf[95]=C_h_intern(&lf[95],4,"sort");
lf[96]=C_h_intern(&lf[96],18,"\010compilerconstant\077");
lf[97]=C_h_intern(&lf[97],5,"quote");
lf[98]=C_h_intern(&lf[98],18,"\003syssrfi-4-vector\077");
lf[99]=C_h_intern(&lf[99],5,"blob\077");
lf[100]=C_h_intern(&lf[100],29,"\010compilercollapsable-literal\077");
lf[101]=C_h_intern(&lf[101],19,"\010compilerimmediate\077");
lf[102]=C_h_intern(&lf[102],20,"\010compilerbig-fixnum\077");
lf[103]=C_h_intern(&lf[103],23,"\010compilerbasic-literal\077");
lf[104]=C_h_intern(&lf[104],5,"every");
lf[105]=C_h_intern(&lf[105],12,"vector->list");
lf[106]=C_h_intern(&lf[106],32,"\010compilercanonicalize-begin-body");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[109]=C_h_intern(&lf[109],3,"let");
lf[110]=C_h_intern(&lf[110],6,"gensym");
lf[111]=C_h_intern(&lf[111],1,"t");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[113]=C_h_intern(&lf[113],21,"\010compilerstring->expr");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],4,"read");
lf[118]=C_h_intern(&lf[118],6,"unfold");
lf[119]=C_h_intern(&lf[119],11,"eof-object\077");
lf[120]=C_h_intern(&lf[120],6,"values");
lf[121]=C_h_intern(&lf[121],22,"with-input-from-string");
lf[122]=C_h_intern(&lf[122],22,"with-exception-handler");
lf[123]=C_h_intern(&lf[123],30,"call-with-current-continuation");
lf[124]=C_h_intern(&lf[124],30,"\010compilerdecompose-lambda-list");
lf[125]=C_h_intern(&lf[125],25,"\003sysdecompose-lambda-list");
lf[126]=C_h_intern(&lf[126],21,"\010compilerllist-length");
lf[127]=C_h_intern(&lf[127],21,"\010compilerllist-match\077");
lf[128]=C_h_intern(&lf[128],30,"\010compilerexpand-profile-lambda");
lf[129]=C_h_intern(&lf[129],29,"\010compilerprofile-lambda-index");
lf[130]=C_h_intern(&lf[130],28,"\010compilerprofile-lambda-list");
lf[131]=C_h_intern(&lf[131],17,"\003sysprofile-entry");
lf[132]=C_h_intern(&lf[132],33,"\010compilerprofile-info-vector-name");
lf[133]=C_h_intern(&lf[133],11,"\004corelambda");
lf[134]=C_h_intern(&lf[134],9,"\003sysapply");
lf[135]=C_h_intern(&lf[135],16,"\003sysprofile-exit");
lf[136]=C_h_intern(&lf[136],16,"\003sysdynamic-wind");
lf[137]=C_h_intern(&lf[137],37,"\010compilerinitialize-analysis-database");
lf[138]=C_h_intern(&lf[138],17,"standard-bindings");
lf[139]=C_h_intern(&lf[139],17,"extended-bindings");
lf[140]=C_h_intern(&lf[140],26,"\010compilerinternal-bindings");
lf[141]=C_h_intern(&lf[141],8,"internal");
lf[142]=C_h_intern(&lf[142],8,"\003sysput!");
lf[143]=C_h_intern(&lf[143],18,"\010compilerintrinsic");
lf[144]=C_h_intern(&lf[144],26,"\010compilerfoldable-bindings");
lf[145]=C_h_intern(&lf[145],17,"\010compilerfoldable");
lf[146]=C_h_intern(&lf[146],8,"extended");
lf[147]=C_h_intern(&lf[147],8,"standard");
lf[148]=C_h_intern(&lf[148],12,"\010compilerget");
lf[149]=C_h_intern(&lf[149],18,"\003syshash-table-ref");
lf[150]=C_h_intern(&lf[150],16,"\010compilerget-all");
lf[151]=C_h_intern(&lf[151],10,"filter-map");
lf[152]=C_h_intern(&lf[152],13,"\010compilerput!");
lf[153]=C_h_intern(&lf[153],19,"\003syshash-table-set!");
lf[154]=C_h_intern(&lf[154],17,"\010compilercollect!");
lf[155]=C_h_intern(&lf[155],15,"\010compilercount!");
lf[156]=C_h_intern(&lf[156],17,"\010compilerget-list");
lf[157]=C_h_intern(&lf[157],17,"\010compilerget-line");
lf[158]=C_h_intern(&lf[158],24,"\003sysline-number-database");
lf[159]=C_h_intern(&lf[159],19,"\010compilerget-line-2");
lf[160]=C_h_intern(&lf[160],37,"\010compilerdisplay-line-number-database");
lf[161]=C_h_intern(&lf[161],3,"map");
lf[162]=C_h_intern(&lf[162],23,"\003syshash-table-for-each");
lf[163]=C_h_intern(&lf[163],34,"\010compilerdisplay-analysis-database");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[169]=C_h_intern(&lf[169],7,"unknown");
lf[170]=C_h_intern(&lf[170],8,"captured");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\013hidden-refs\376\001\000\000\003hrf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011value-ref\376\001\000\000\003vvf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014custom"
"izable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012boxed-r"
"est\376\001\000\000\003bxr\376\377\016");
lf[172]=C_h_intern(&lf[172],5,"value");
lf[173]=C_h_intern(&lf[173],11,"local-value");
lf[174]=C_h_intern(&lf[174],15,"potential-value");
lf[175]=C_h_intern(&lf[175],10,"replacable");
lf[176]=C_h_intern(&lf[176],10,"references");
lf[177]=C_h_intern(&lf[177],10,"call-sites");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[179]=C_h_intern(&lf[179],4,"home");
lf[180]=C_h_intern(&lf[180],8,"contains");
lf[181]=C_h_intern(&lf[181],12,"contained-in");
lf[182]=C_h_intern(&lf[182],8,"use-expr");
lf[183]=C_h_intern(&lf[183],12,"closure-size");
lf[184]=C_h_intern(&lf[184],14,"rest-parameter");
lf[185]=C_h_intern(&lf[185],18,"captured-variables");
lf[186]=C_h_intern(&lf[186],13,"explicit-rest");
lf[187]=C_h_intern(&lf[187],8,"assigned");
lf[188]=C_h_intern(&lf[188],5,"boxed");
lf[189]=C_h_intern(&lf[189],6,"global");
lf[190]=C_h_intern(&lf[190],12,"contractable");
lf[191]=C_h_intern(&lf[191],16,"standard-binding");
lf[192]=C_h_intern(&lf[192],16,"assigned-locally");
lf[193]=C_h_intern(&lf[193],11,"collapsable");
lf[194]=C_h_intern(&lf[194],9,"removable");
lf[195]=C_h_intern(&lf[195],9,"undefined");
lf[196]=C_h_intern(&lf[196],9,"replacing");
lf[197]=C_h_intern(&lf[197],6,"unused");
lf[198]=C_h_intern(&lf[198],6,"simple");
lf[199]=C_h_intern(&lf[199],9,"inlinable");
lf[200]=C_h_intern(&lf[200],13,"inline-export");
lf[201]=C_h_intern(&lf[201],21,"has-unused-parameters");
lf[202]=C_h_intern(&lf[202],16,"extended-binding");
lf[203]=C_h_intern(&lf[203],12,"customizable");
lf[204]=C_h_intern(&lf[204],8,"constant");
lf[205]=C_h_intern(&lf[205],10,"boxed-rest");
lf[206]=C_h_intern(&lf[206],11,"hidden-refs");
lf[207]=C_h_intern(&lf[207],5,"write");
lf[208]=C_h_intern(&lf[208],34,"\010compilerdefault-standard-bindings");
lf[209]=C_h_intern(&lf[209],34,"\010compilerdefault-extended-bindings");
lf[210]=C_h_intern(&lf[210],9,"make-node");
lf[211]=C_h_intern(&lf[211],4,"node");
lf[212]=C_h_intern(&lf[212],5,"node\077");
lf[213]=C_h_intern(&lf[213],10,"node-class");
lf[214]=C_h_intern(&lf[214],15,"node-class-set!");
lf[215]=C_h_intern(&lf[215],14,"\003sysblock-set!");
lf[216]=C_h_intern(&lf[216],15,"node-parameters");
lf[217]=C_h_intern(&lf[217],20,"node-parameters-set!");
lf[218]=C_h_intern(&lf[218],19,"node-subexpressions");
lf[219]=C_h_intern(&lf[219],24,"node-subexpressions-set!");
lf[220]=C_h_intern(&lf[220],16,"\010compilervarnode");
lf[221]=C_h_intern(&lf[221],13,"\004corevariable");
lf[222]=C_h_intern(&lf[222],14,"\010compilerqnode");
lf[223]=C_h_intern(&lf[223],25,"\010compilerbuild-node-graph");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[225]=C_h_intern(&lf[225],2,"if");
lf[226]=C_h_intern(&lf[226],14,"\004coreundefined");
lf[227]=C_h_intern(&lf[227],8,"truncate");
lf[228]=C_h_intern(&lf[228],7,"warning");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\0006literal is out of range - will be truncated to integer");
lf[230]=C_h_intern(&lf[230],6,"fixnum");
lf[231]=C_h_intern(&lf[231],11,"number-type");
lf[232]=C_h_intern(&lf[232],4,"\000tmp");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\021SHOULD NOT HAPPEN");
lf[234]=C_h_intern(&lf[234],6,"unzip1");
lf[235]=C_h_intern(&lf[235],6,"lambda");
lf[236]=C_h_intern(&lf[236],8,"\004corethe");
lf[237]=C_h_intern(&lf[237],13,"\004coretypecase");
lf[238]=C_h_intern(&lf[238],4,"else");
lf[239]=C_h_intern(&lf[239],5,"cadar");
lf[240]=C_h_intern(&lf[240],1,"\052");
lf[241]=C_h_intern(&lf[241],14,"\004coreprimitive");
lf[242]=C_h_intern(&lf[242],11,"\004coreinline");
lf[243]=C_h_intern(&lf[243],13,"\004corecallunit");
lf[244]=C_h_intern(&lf[244],16,"\004coredebug-event");
lf[245]=C_h_intern(&lf[245],9,"\004coreproc");
lf[246]=C_h_intern(&lf[246],4,"set!");
lf[247]=C_h_intern(&lf[247],9,"\004coreset!");
lf[248]=C_h_intern(&lf[248],29,"\004coreforeign-callback-wrapper");
lf[249]=C_h_intern(&lf[249],5,"sixth");
lf[250]=C_h_intern(&lf[250],5,"fifth");
lf[251]=C_h_intern(&lf[251],20,"\004coreinline_allocate");
lf[252]=C_h_intern(&lf[252],8,"\004coreapp");
lf[253]=C_h_intern(&lf[253],9,"\004corecall");
lf[254]=C_h_intern(&lf[254],28,"\003syssymbol->qualified-string");
lf[255]=C_h_intern(&lf[255],7,"\003sysget");
lf[256]=C_h_intern(&lf[256],34,"\010compileralways-bound-to-procedure");
lf[257]=C_h_intern(&lf[257],15,"\004coreinline_ref");
lf[258]=C_h_intern(&lf[258],18,"\004coreinline_update");
lf[259]=C_h_intern(&lf[259],19,"\004coreinline_loc_ref");
lf[260]=C_h_intern(&lf[260],22,"\004coreinline_loc_update");
lf[261]=C_h_intern(&lf[261],1,"o");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[263]=C_h_intern(&lf[263],30,"\010compilerbuild-expression-tree");
lf[264]=C_h_intern(&lf[264],12,"\004coreclosure");
lf[265]=C_h_intern(&lf[265],4,"last");
lf[266]=C_h_intern(&lf[266],7,"butlast");
lf[267]=C_h_intern(&lf[267],3,"the");
lf[268]=C_h_intern(&lf[268],15,"\004corethe/result");
lf[269]=C_h_intern(&lf[269],17,"compiler-typecase");
lf[270]=C_h_intern(&lf[270],5,"cons\052");
lf[271]=C_h_intern(&lf[271],9,"\004corebind");
lf[272]=C_h_intern(&lf[272],10,"\004coreunbox");
lf[273]=C_h_intern(&lf[273],16,"\004corelet_unboxed");
lf[274]=C_h_intern(&lf[274],8,"\004coreref");
lf[275]=C_h_intern(&lf[275],11,"\004coreupdate");
lf[276]=C_h_intern(&lf[276],13,"\004coreupdate_i");
lf[277]=C_h_intern(&lf[277],8,"\004corebox");
lf[278]=C_h_intern(&lf[278],9,"\004corecond");
lf[279]=C_h_intern(&lf[279],21,"\010compilerfold-boolean");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[281]=C_h_intern(&lf[281],31,"\010compilerinline-lambda-bindings");
lf[282]=C_h_intern(&lf[282],8,"split-at");
lf[283]=C_h_intern(&lf[283],10,"fold-right");
lf[284]=C_h_intern(&lf[284],4,"take");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[286]=C_h_intern(&lf[286],34,"\010compilercopy-node-tree-and-rename");
lf[287]=C_h_intern(&lf[287],9,"alist-ref");
lf[288]=C_h_intern(&lf[288],16,"inline-transient");
lf[289]=C_h_intern(&lf[289],1,"f");
lf[290]=C_h_intern(&lf[290],18,"\010compilertree-copy");
lf[291]=C_h_intern(&lf[291],9,"copy-node");
lf[292]=C_h_intern(&lf[292],19,"\010compilercopy-node!");
lf[293]=C_h_intern(&lf[293],20,"\010compilernode->sexpr");
lf[294]=C_h_intern(&lf[294],20,"\010compilersexpr->node");
lf[295]=C_h_intern(&lf[295],32,"\010compileremit-global-inline-file");
lf[296]=C_h_intern(&lf[296],5,"print");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[298]=C_h_intern(&lf[298],1,"i");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[300]=C_h_intern(&lf[300],12,"delete-file\052");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[302]=C_h_intern(&lf[302],2,"pp");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[305]=C_h_intern(&lf[305],24,"\010compilersource-filename");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[307]=C_h_intern(&lf[307],15,"chicken-version");
lf[308]=C_h_intern(&lf[308],19,"with-output-to-file");
lf[309]=C_h_intern(&lf[309],3,"yes");
lf[310]=C_h_intern(&lf[310],2,"no");
lf[311]=C_h_intern(&lf[311],24,"\010compilerinline-max-size");
lf[312]=C_h_intern(&lf[312],15,"\010compilerinline");
lf[313]=C_h_intern(&lf[313],22,"\010compilerinline-global");
lf[314]=C_h_intern(&lf[314],26,"\010compilervariable-visible\077");
lf[315]=C_h_intern(&lf[315],25,"\010compilerload-inline-file");
lf[316]=C_h_intern(&lf[316],20,"with-input-from-file");
lf[317]=C_h_intern(&lf[317],19,"\010compilermatch-node");
lf[318]=C_h_intern(&lf[318],1,"a");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[320]=C_h_intern(&lf[320],37,"\010compilerexpression-has-side-effects\077");
lf[321]=C_h_intern(&lf[321],24,"foreign-callback-stub-id");
lf[322]=C_h_intern(&lf[322],4,"find");
lf[323]=C_h_intern(&lf[323],22,"foreign-callback-stubs");
lf[324]=C_h_intern(&lf[324],28,"\010compilersimple-lambda-node\077");
lf[325]=C_h_intern(&lf[325],31,"\010compilerdump-undefined-globals");
lf[326]=C_h_intern(&lf[326],8,"keyword\077");
lf[327]=C_h_intern(&lf[327],29,"\010compilerdump-defined-globals");
lf[328]=C_h_intern(&lf[328],25,"\010compilerdump-global-refs");
lf[329]=C_h_intern(&lf[329],28,"\003systoplevel-definition-hook");
lf[330]=C_h_intern(&lf[330],22,"\010compilerhide-variable");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[332]=C_h_intern(&lf[332],36,"\010compilercompute-database-statistics");
lf[333]=C_h_intern(&lf[333],29,"\010compilercurrent-program-size");
lf[334]=C_h_intern(&lf[334],30,"\010compileroriginal-program-size");
lf[335]=C_h_intern(&lf[335],33,"\010compilerprint-program-statistics");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[343]=C_h_intern(&lf[343],1,"s");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[345]=C_h_intern(&lf[345],35,"\010compilerpprint-expressions-to-file");
lf[346]=C_h_intern(&lf[346],17,"close-output-port");
lf[347]=C_h_intern(&lf[347],12,"pretty-print");
lf[348]=C_h_intern(&lf[348],19,"with-output-to-port");
lf[349]=C_h_intern(&lf[349],16,"open-output-file");
lf[350]=C_h_intern(&lf[350],27,"\010compilerforeign-type-check");
lf[351]=C_h_intern(&lf[351],4,"char");
lf[352]=C_h_intern(&lf[352],13,"unsigned-char");
lf[353]=C_h_intern(&lf[353],6,"unsafe");
lf[354]=C_h_intern(&lf[354],25,"\003sysforeign-char-argument");
lf[355]=C_h_intern(&lf[355],3,"int");
lf[356]=C_h_intern(&lf[356],27,"\003sysforeign-fixnum-argument");
lf[357]=C_h_intern(&lf[357],5,"float");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-flonum-argument");
lf[359]=C_h_intern(&lf[359],4,"blob");
lf[360]=C_h_intern(&lf[360],14,"scheme-pointer");
lf[361]=C_h_intern(&lf[361],26,"\003sysforeign-block-argument");
lf[362]=C_h_intern(&lf[362],22,"nonnull-scheme-pointer");
lf[363]=C_h_intern(&lf[363],12,"nonnull-blob");
lf[364]=C_h_intern(&lf[364],14,"pointer-vector");
lf[365]=C_h_intern(&lf[365],35,"\003sysforeign-struct-wrapper-argument");
lf[366]=C_h_intern(&lf[366],22,"nonnull-pointer-vector");
lf[367]=C_h_intern(&lf[367],8,"u8vector");
lf[368]=C_h_intern(&lf[368],16,"nonnull-u8vector");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[370]=C_h_intern(&lf[370],7,"integer");
lf[371]=C_h_intern(&lf[371],28,"\003sysforeign-integer-argument");
lf[372]=C_h_intern(&lf[372],9,"integer64");
lf[373]=C_h_intern(&lf[373],30,"\003sysforeign-integer64-argument");
lf[374]=C_h_intern(&lf[374],16,"unsigned-integer");
lf[375]=C_h_intern(&lf[375],37,"\003sysforeign-unsigned-integer-argument");
lf[376]=C_h_intern(&lf[376],18,"unsigned-integer64");
lf[377]=C_h_intern(&lf[377],39,"\003sysforeign-unsigned-integer64-argument");
lf[378]=C_h_intern(&lf[378],9,"c-pointer");
lf[379]=C_h_intern(&lf[379],28,"\003sysforeign-pointer-argument");
lf[380]=C_h_intern(&lf[380],17,"nonnull-c-pointer");
lf[381]=C_h_intern(&lf[381],8,"c-string");
lf[382]=C_h_intern(&lf[382],17,"\003sysmake-c-string");
lf[383]=C_h_intern(&lf[383],27,"\003sysforeign-string-argument");
lf[384]=C_h_intern(&lf[384],16,"nonnull-c-string");
lf[385]=C_h_intern(&lf[385],6,"symbol");
lf[386]=C_h_intern(&lf[386],18,"\003syssymbol->string");
lf[387]=C_h_intern(&lf[387],3,"ref");
lf[388]=C_h_intern(&lf[388],8,"instance");
lf[389]=C_h_intern(&lf[389],12,"instance-ref");
lf[390]=C_h_intern(&lf[390],4,"this");
lf[391]=C_h_intern(&lf[391],8,"slot-ref");
lf[392]=C_h_intern(&lf[392],16,"nonnull-instance");
lf[393]=C_h_intern(&lf[393],5,"const");
lf[394]=C_h_intern(&lf[394],4,"enum");
lf[395]=C_h_intern(&lf[395],15,"nonnull-pointer");
lf[396]=C_h_intern(&lf[396],7,"pointer");
lf[397]=C_h_intern(&lf[397],8,"function");
lf[398]=C_h_intern(&lf[398],27,"\010compilerforeign-type-table");
lf[399]=C_h_intern(&lf[399],17,"nonnull-c-string\052");
lf[400]=C_h_intern(&lf[400],26,"nonnull-unsigned-c-string\052");
lf[401]=C_h_intern(&lf[401],9,"c-string\052");
lf[402]=C_h_intern(&lf[402],17,"unsigned-c-string");
lf[403]=C_h_intern(&lf[403],18,"unsigned-c-string\052");
lf[404]=C_h_intern(&lf[404],13,"c-string-list");
lf[405]=C_h_intern(&lf[405],14,"c-string-list\052");
lf[406]=C_h_intern(&lf[406],18,"unsigned-integer32");
lf[407]=C_h_intern(&lf[407],13,"unsigned-long");
lf[408]=C_h_intern(&lf[408],4,"long");
lf[409]=C_h_intern(&lf[409],6,"size_t");
lf[410]=C_h_intern(&lf[410],9,"integer32");
lf[411]=C_h_intern(&lf[411],17,"nonnull-u16vector");
lf[412]=C_h_intern(&lf[412],16,"nonnull-s8vector");
lf[413]=C_h_intern(&lf[413],17,"nonnull-s16vector");
lf[414]=C_h_intern(&lf[414],17,"nonnull-u32vector");
lf[415]=C_h_intern(&lf[415],17,"nonnull-s32vector");
lf[416]=C_h_intern(&lf[416],17,"nonnull-f32vector");
lf[417]=C_h_intern(&lf[417],17,"nonnull-f64vector");
lf[418]=C_h_intern(&lf[418],9,"u16vector");
lf[419]=C_h_intern(&lf[419],8,"s8vector");
lf[420]=C_h_intern(&lf[420],9,"s16vector");
lf[421]=C_h_intern(&lf[421],9,"u32vector");
lf[422]=C_h_intern(&lf[422],9,"s32vector");
lf[423]=C_h_intern(&lf[423],9,"f32vector");
lf[424]=C_h_intern(&lf[424],9,"f64vector");
lf[425]=C_h_intern(&lf[425],6,"double");
lf[426]=C_h_intern(&lf[426],6,"number");
lf[427]=C_h_intern(&lf[427],12,"unsigned-int");
lf[428]=C_h_intern(&lf[428],5,"short");
lf[429]=C_h_intern(&lf[429],14,"unsigned-short");
lf[430]=C_h_intern(&lf[430],4,"byte");
lf[431]=C_h_intern(&lf[431],13,"unsigned-byte");
lf[432]=C_h_intern(&lf[432],5,"int32");
lf[433]=C_h_intern(&lf[433],14,"unsigned-int32");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[435]=C_h_intern(&lf[435],36,"\010compilerforeign-type-convert-result");
lf[436]=C_h_intern(&lf[436],38,"\010compilerforeign-type-convert-argument");
lf[437]=C_h_intern(&lf[437],27,"\010compilerfinal-foreign-type");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[439]=C_h_intern(&lf[439],37,"\010compilerestimate-foreign-result-size");
lf[440]=C_h_intern(&lf[440],4,"bool");
lf[441]=C_h_intern(&lf[441],4,"void");
lf[442]=C_h_intern(&lf[442],13,"scheme-object");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[444]=C_h_intern(&lf[444],46,"\010compilerestimate-foreign-result-location-size");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[447]=C_h_intern(&lf[447],30,"\010compilerfinish-foreign-result");
lf[448]=C_h_intern(&lf[448],17,"\003syspeek-c-string");
lf[449]=C_h_intern(&lf[449],25,"\003syspeek-nonnull-c-string");
lf[450]=C_h_intern(&lf[450],26,"\003syspeek-and-free-c-string");
lf[451]=C_h_intern(&lf[451],34,"\003syspeek-and-free-nonnull-c-string");
lf[452]=C_h_intern(&lf[452],17,"\003sysintern-symbol");
lf[453]=C_h_intern(&lf[453],22,"\003syspeek-c-string-list");
lf[454]=C_h_intern(&lf[454],31,"\003syspeek-and-free-c-string-list");
lf[455]=C_h_intern(&lf[455],17,"\003sysnull-pointer\077");
lf[456]=C_h_intern(&lf[456],3,"not");
lf[457]=C_h_intern(&lf[457],4,"make");
lf[458]=C_h_intern(&lf[458],3,"and");
lf[459]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010c-string\376\003\000\000\002\376\001\000\000\011c-string\052\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\003\000\000\002\376\001\000\000\022unsign"
"ed-c-string\052\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\003\000\000\002\376\001\000\000\021nonnull-c-string\052\376\003\000\000\002\376\001\000\000\030nonnu"
"ll-unsigned-string\052\376\377\016");
lf[460]=C_h_intern(&lf[460],16,"\003sysstrip-syntax");
lf[461]=C_h_intern(&lf[461],36,"\010compilerforeign-type->scrutiny-type");
lf[462]=C_h_intern(&lf[462],3,"arg");
lf[463]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\004blob\376\377\016");
lf[464]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\016pointer-vector\376\377\016");
lf[465]=C_h_intern(&lf[465],6,"struct");
lf[466]=C_h_intern(&lf[466],2,"or");
lf[467]=C_h_intern(&lf[467],7,"boolean");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010u8vector\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010s8vector\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u16vector\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s16vector\376\377\016");
lf[472]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u32vector\376\377\016");
lf[473]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s32vector\376\377\016");
lf[474]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f32vector\376\377\016");
lf[475]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[476]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[477]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[478]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007list-of\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[479]=C_h_intern(&lf[479],6,"string");
lf[480]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[481]=C_h_intern(&lf[481],28,"\010compilerscan-used-variables");
lf[482]=C_h_intern(&lf[482],28,"\010compilerscan-free-variables");
lf[483]=C_h_intern(&lf[483],11,"lset-adjoin");
lf[484]=C_h_intern(&lf[484],23,"\010compilerchop-separator");
lf[485]=C_h_intern(&lf[485],9,"substring");
lf[486]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[487]=C_h_intern(&lf[487],23,"\010compilerchop-extension");
lf[488]=C_h_intern(&lf[488],36,"\010compilermake-block-variable-literal");
lf[489]=C_h_intern(&lf[489],22,"block-variable-literal");
lf[490]=C_h_intern(&lf[490],32,"\010compilerblock-variable-literal\077");
lf[491]=C_h_intern(&lf[491],36,"\010compilerblock-variable-literal-name");
lf[492]=C_h_intern(&lf[492],27,"block-variable-literal-name");
lf[493]=C_h_intern(&lf[493],25,"\010compilermake-random-name");
lf[494]=C_h_intern(&lf[494],6,"random");
lf[495]=C_h_intern(&lf[495],15,"current-seconds");
lf[496]=C_h_intern(&lf[496],23,"\010compilerset-real-name!");
lf[497]=C_h_intern(&lf[497],24,"\010compilerreal-name-table");
lf[498]=C_h_intern(&lf[498],19,"real-name-max-depth");
lf[499]=C_h_intern(&lf[499],18,"string-intersperse");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[504]=C_h_intern(&lf[504],19,"\010compilerreal-name2");
lf[505]=C_h_intern(&lf[505],32,"\010compilerdisplay-real-name-table");
lf[506]=C_h_intern(&lf[506],28,"\010compilersource-info->string");
lf[507]=C_h_intern(&lf[507],4,"conc");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[510]=C_h_intern(&lf[510],11,"make-string");
lf[511]=C_h_intern(&lf[511],3,"max");
lf[512]=C_h_intern(&lf[512],26,"\010compilersource-info->line");
lf[513]=C_h_intern(&lf[513],18,"\010compilercall-info");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[516]=C_h_intern(&lf[516],27,"\010compilerconstant-form-eval");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\032folded constant expression");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000Dattempt to constant-fold call to procedure that has multiple results");
lf[519]=C_h_intern(&lf[519],28,"\010compilerencodeable-literal\077");
lf[520]=C_h_intern(&lf[520],22,"get-condition-property");
lf[521]=C_h_intern(&lf[521],3,"exn");
lf[522]=C_h_intern(&lf[522],7,"message");
lf[523]=C_h_intern(&lf[523],8,"\003syslist");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000.attempt to constant-fold call to non-procedure");
lf[525]=C_h_intern(&lf[525],13,"list-tabulate");
lf[526]=C_h_intern(&lf[526],19,"\010compilerdump-nodes");
lf[527]=C_h_intern(&lf[527],19,"\003syswrite-char/port");
lf[528]=C_h_intern(&lf[528],23,"\010compilerread-info-hook");
lf[529]=C_h_intern(&lf[529],27,"\003syscurrent-source-filename");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[531]=C_h_intern(&lf[531],9,"list-info");
lf[532]=C_h_intern(&lf[532],25,"\010compilerread/source-info");
lf[533]=C_h_intern(&lf[533],8,"\003sysread");
lf[534]=C_h_intern(&lf[534],18,"\003sysuser-read-hook");
lf[535]=C_h_intern(&lf[535],15,"foreign-declare");
lf[536]=C_h_intern(&lf[536],7,"declare");
lf[537]=C_h_intern(&lf[537],34,"\010compilerscan-sharp-greater-string");
lf[538]=C_h_intern(&lf[538],18,"\003sysread-char/port");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[540]=C_h_intern(&lf[540],6,"hidden");
lf[541]=C_h_intern(&lf[541],19,"\010compilervisibility");
lf[542]=C_h_intern(&lf[542],24,"\010compilerexport-variable");
lf[543]=C_h_intern(&lf[543],8,"exported");
lf[544]=C_h_intern(&lf[544],25,"\010compilervariable-hidden\077");
lf[545]=C_h_intern(&lf[545],26,"\010compilerblock-compilation");
lf[546]=C_h_intern(&lf[546],22,"\010compilermark-variable");
lf[547]=C_h_intern(&lf[547],22,"\010compilervariable-mark");
lf[548]=C_h_intern(&lf[548],19,"\010compilerintrinsic\077");
lf[549]=C_h_intern(&lf[549],9,"foldable\077");
lf[550]=C_h_intern(&lf[550],33,"\010compilerload-identifier-database");
lf[551]=C_h_intern(&lf[551],7,"\004coredb");
lf[552]=C_h_intern(&lf[552],9,"read-file");
lf[553]=C_h_intern(&lf[553],1,"p");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[556]=C_h_intern(&lf[556],13,"make-pathname");
lf[557]=C_h_intern(&lf[557],15,"repository-path");
lf[558]=C_h_intern(&lf[558],22,"\010compilerprint-version");
lf[559]=C_h_intern(&lf[559],6,"print\052");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000C(c) 2008-2017, The CHICKEN Team\012(c) 2000-2007, Felix L. Winkelmann\012");
lf[561]=C_h_intern(&lf[561],20,"\010compilerprint-usage");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\030\252Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012    -no-feature SYMBOL        "
"   disable built-in feature identifier\012\012  Syntax related options:\012\012    -case-ins"
"ensitive            don\047t preserve case of read symbols\012    -keyword-style STYLE"
"         allow alternative keyword syntax\012                                  (pre"
"fix, suffix or none)\012    -no-parentheses-synonyms     disables list delimiter sy"
"nonyms\012    -no-symbol-escape            disables support for escaped symbols\012   "
" -r5rs-syntax                 disables the CHICKEN extensions to\012               "
"                   R5RS syntax\012    -compile-syntax              macros are made "
"available at run-time\012    -emit-import-library MODULE  write compile-time module"
" information into\012                                  separate file\012    -emit-all-"
"import-libraries   emit import-libraries for all defined modules\012    -no-module-"
"registration      do not generate module registration code\012    -no-compiler-synt"
"ax          disable expansion of compiler-macros\012    -module                    "
"  wrap compiled code into implicit module\012\012  Translation options:\012\012    -explicit"
"-use                do not use units \047library\047 and \047eval\047 by\012                   "
"               default\012    -check-syntax                stop compilation after m"
"acro-expansion\012    -analyze-only                stop compilation after first ana"
"lysis pass\012\012  Debugging options:\012\012    -no-warnings                 disable warni"
"ngs\012    -debug-level NUMBER          set level of available debugging informatio"
"n\012    -no-trace                    disable tracing information\012    -debug-info  "
"                enable debug-information in compiled code for use\012              "
"                    with an external debugger\012    -profile                     e"
"xecutable emits profiling information \012    -profile-name FILENAME       name of "
"the generated profile information file\012    -accumulate-profile          executab"
"le emits profiling information in\012                                  append mode\012"
"    -no-lambda-info              omit additional procedure-information\012    -type"
"s FILENAME              load additional type database\012    -emit-type-file FILENA"
"ME     write type-declaration information into file\012\012  Optimization options:\012\012  "
"  -optimize-level NUMBER       enable certain sets of optimization options\012    -"
"optimize-leaf-routines      enable leaf routine optimization\012    -no-usual-integ"
"rations       standard procedures may be redefined\012    -unsafe                  "
"    disable all safety checks\012    -local                       assume globals ar"
"e only modified in current\012                                  file\012    -block    "
"                   enable block-compilation\012    -disable-interrupts          dis"
"able interrupts in compiled code\012    -fixnum-arithmetic           assume all num"
"bers are fixnums\012    -disable-stack-overflow-checks  disables detection of stack"
"-overflows\012    -inline                      enable inlining\012    -inline-limit LI"
"MIT          set inlining threshold\012    -inline-global               enable cros"
"s-module inlining\012    -specialize                  perform type-based specializa"
"tion of primitive calls\012    -emit-inline-file FILENAME   generate file with glob"
"ally inlinable\012                                  procedures (implies -inline -lo"
"cal)\012    -consult-inline-file FILENAME  explicitly load inline file\012    -no-argc"
"-checks              disable argument count checks\012    -no-bound-checks         "
"    disable bound variable checks\012    -no-procedure-checks         disable proce"
"dure call checks\012    -no-procedure-checks-for-usual-bindings\012                   "
"                disable procedure call checks only for usual\012                   "
"                bindings\012    -no-procedure-checks-for-toplevel-bindings\012        "
"                           disable procedure call checks for toplevel\012          "
"                         bindings\012    -strict-types                assume variab"
"le do not change their type\012    -clustering                  combine groups of l"
"ocal procedures into dispatch\012                                   loop\012    -lfa2 "
"                       perform additional lightweight flow-analysis pass\012\012  Conf"
"iguration options:\012\012    -unit NAME                   compile file as a library u"
"nit\012    -uses NAME                   declare library unit as used.\012    -heap-siz"
"e NUMBER            specifies heap-size of compiled executable\012    -nursery NUMB"
"ER  -stack-size NUMBER\012                                 specifies nursery size o"
"f compiled executable\012    -extend FILENAME             load file before compilat"
"ion commences\012    -prelude EXPRESSION          add expression to front of source"
" file\012    -postlude EXPRESSION         add expression to end of source file\012    "
"-prologue FILENAME           include file before main source file\012    -epilogue "
"FILENAME           include file after main source file\012    -dynamic             "
"        compile as dynamically loadable code\012    -require-extension NAME      re"
"quire and import extension NAME\012\012  Obscure options:\012\012    -debug MODES           "
"      display debugging output for the given modes\012    -raw                     "
"    do not generate implicit init- and exit code                           \012    "
"-emit-external-prototypes-first\012                                 emit prototypes"
" for callbacks before foreign\012                                  declarations\012   "
" -ignore-repository           do not refer to repository for extensions\012    -set"
"up-mode                  prefer the current directory when locating extensions\012");
lf[563]=C_h_intern(&lf[563],28,"\010compilerprint-debug-options");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\007\026\012Available debugging options:\012\012     a          show node-matching during si"
"mplification\012     b          show breakdown of time needed for each compiler pas"
"s\012     c          print every expression before macro-expansion\012     d          "
"lists all assigned global variables\012     e          show information about speci"
"alizations\012     h          you already figured that out\012     i          show inf"
"ormation about inlining\012     m          show GC statistics during compilation\012  "
"   n          print the line-number database \012     o          show performed opt"
"imizations\012     p          display information about what the compiler is curren"
"tly doing\012     r          show invocation parameters\012     s          show progra"
"m-size information and other statistics\012     t          show time needed for com"
"pilation\012     u          lists all unassigned global variable references\012     x "
"         display information about experimental features\012     D          when pr"
"inting nodes, use node-tree output\012     I          show inferred type informatio"
"n for unexported globals\012     M          show syntax-/runtime-requirements\012     "
"N          show the real-name mapping table\012     P          show expressions aft"
"er specialization\012     S          show applications of compiler syntax\012     T   "
"       show expressions after converting to node tree\012     1          show sourc"
"e expressions\012     2          show canonicalized expressions\012     3          sho"
"w expressions converted into CPS\012     4          show database after each analys"
"is pass\012     5          show expressions after each optimization pass\012     6    "
"      show expressions after each inlining pass\012     7          show expressions"
" after complete optimization\012     8          show database after final analysis\012"
"     9          show expressions after closure conversion\012\012");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\007#<node ");
lf[566]=C_h_intern(&lf[566],27,"\003sysregister-record-printer");
lf[567]=C_h_intern(&lf[567],27,"condition-property-accessor");
lf[568]=C_h_intern(&lf[568],19,"condition-predicate");
C_register_lf2(lf,569,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4830,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k13783 in finish-foreign-result in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,2)))){
C_save_and_reclaim((void *)f_13785,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_eqp(t2,lf[381]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[402]));
if(C_truep(t4)){
t5=C_a_i_list(&a,2,lf[97],C_fix(0));
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[448],((C_word*)t0)[3],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(t2,lf[384]);
if(C_truep(t5)){
t6=C_a_i_list(&a,2,lf[97],C_fix(0));
t7=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[449],((C_word*)t0)[3],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_eqp(t2,lf[401]);
t7=(C_truep(t6)?t6:C_eqp(t2,lf[403]));
if(C_truep(t7)){
t8=C_a_i_list(&a,2,lf[97],C_fix(0));
t9=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=C_a_i_list(&a,3,lf[450],((C_word*)t0)[3],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_eqp(t2,lf[399]);
t9=(C_truep(t8)?t8:C_eqp(t2,lf[400]));
if(C_truep(t9)){
t10=C_a_i_list(&a,2,lf[97],C_fix(0));
t11=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_a_i_list(&a,3,lf[451],((C_word*)t0)[3],t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t10=C_eqp(t2,lf[385]);
if(C_truep(t10)){
t11=C_a_i_list(&a,2,lf[97],C_fix(0));
t12=C_a_i_list(&a,3,lf[448],((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=C_a_i_list(&a,2,lf[452],t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t11=C_eqp(t2,lf[404]);
if(C_truep(t11)){
t12=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t13=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=C_a_i_list(&a,3,lf[453],((C_word*)t0)[3],t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t12=C_eqp(t2,lf[405]);
if(C_truep(t12)){
t13=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t14=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t14;
av2[1]=C_a_i_list(&a,3,lf[454],((C_word*)t0)[3],t13);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
if(C_truep(C_i_listp(t2))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13901,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=C_i_car(t2);
t15=C_eqp(t14,lf[393]);
if(C_truep(t15)){
t16=C_i_length(t2);
t17=C_eqp(C_fix(2),t16);
if(C_truep(t17)){
t18=C_i_cadr(t2);
t19=C_u_i_memq(t18,lf[459]);
t20=t13;
f_13901(t20,t19);}
else{
t18=t13;
f_13901(t18,C_SCHEME_FALSE);}}
else{
t16=t13;
f_13901(t16,C_SCHEME_FALSE);}}
else{
t13=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}}}}}}}}

/* k5057 in for-each-loop103 in k5042 in collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5059,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5049(t3,((C_word*)t0)[4],t2);}

/* k5042 in collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5044,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5049,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5049(t5,((C_word*)t0)[3],t1);}

/* for-each-loop103 in k5042 in collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_5049,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5059,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:87: g104 */
t5=((C_word*)t0)[3];
f_5017(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##compiler#get-list in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6718,5,av);}
a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:412: get */
t6=*((C_word*)lf[148]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5028 in k5025 in k5022 in g104 in collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5030,2,av);}
/* support.scm:90: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6745 in k6742 in get-line-2 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6747(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_6747,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:421: g727 */
t3=t2;
f_6751(t3,((C_word*)t0)[3],t1);}
else{
/* support.scm:426: values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* k10622 in map-loop2163 in walk in sexpr->node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10624,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10599(t6,((C_word*)t0)[5],t5);}

/* k6742 in get-line-2 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6744,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6747,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=C_i_cdr(t2);
t5=t3;
f_6747(t5,C_i_assq(((C_word*)t0)[4],t4));}
else{
t4=t3;
f_6747(t4,C_SCHEME_FALSE);}}

/* k16298 in a16292 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16300,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
/* support.scm:512: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5188 in k5185 in k5182 in k5179 in k5176 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5190,2,av);}
/* support.scm:119: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#get-line in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6727,3,av);}
t3=C_i_car(t2);
/* support.scm:419: get */
t4=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=*((C_word*)lf[158]+1);
av2[3]=t3;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6720 in get-list in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6722,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5514 in loop in build-lambda-list in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5516,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5197 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_5199,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:120: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5185 in k5182 in k5179 in k5176 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_5187,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:119: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5182 in k5179 in k5176 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_5184,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:119: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5179 in k5176 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5181,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:119: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[39];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,0,5)))){
C_save_and_reclaim_args((void *)trf_8820,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)((C_word*)t0)[2])[1];
t7=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8833,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8835,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8835(t12,t8,((C_word*)t0)[3]);}
else{
t2=C_eqp(((C_word*)t0)[6],lf[264]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8890,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8892,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8892(t13,t9,((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[6],lf[221]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_car(((C_word*)t0)[7]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[6],lf[97]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[7]);
t6=C_booleanp(t5);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t7;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_u_i_car(((C_word*)t0)[7]);
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_list(&a,2,lf[97],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t7=C_i_stringp(t5);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_u_i_car(((C_word*)t0)[7]);
t9=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_list(&a,2,lf[97],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=C_i_numberp(t5);
t9=(C_truep(t8)?t8:C_charp(t5));
if(C_truep(t9)){
t10=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t10;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_u_i_car(((C_word*)t0)[7]);
t11=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t11;
av2[1]=C_a_i_list(&a,2,lf[97],t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}
else{
t5=C_eqp(((C_word*)t0)[6],lf[109]);
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=((C_word*)t0)[7];
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8990,a[2]=t10,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t8,a[7]=t9,a[8]=t13,a[9]=t15,a[10]=t14,tmp=(C_word)a,a+=11,tmp);
/* support.scm:639: butlast */
t17=*((C_word*)lf[266]+1);{
C_word av2[3];
av2[0]=t17;
av2[1]=t16;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}
else{
t6=C_eqp(((C_word*)t0)[6],lf[133]);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[7]);
t8=(C_truep(t7)?lf[235]:lf[133]);
t9=t8;
t10=C_i_caddr(((C_word*)t0)[7]);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[4],a[3]=t9,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=C_i_car(((C_word*)t0)[3]);
/* support.scm:646: walk */
t14=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
f_8786(3,av2);}}
else{
t7=C_eqp(((C_word*)t0)[6],lf[236]);
if(C_truep(t7)){
t8=C_i_car(((C_word*)t0)[7]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:648: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
f_8786(3,av2);}}
else{
t8=C_eqp(((C_word*)t0)[6],lf[268]);
if(C_truep(t8)){
t9=C_i_car(((C_word*)t0)[3]);
/* support.scm:650: walk */
t10=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t10;
av2[1]=((C_word*)t0)[4];
av2[2]=t9;
f_8786(3,av2);}}
else{
t9=C_eqp(((C_word*)t0)[6],lf[237]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9171,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:653: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
f_8786(3,av2);}}
else{
t10=C_eqp(((C_word*)t0)[6],lf[253]);
if(C_truep(t10)){
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9259,a[2]=t13,a[3]=t18,a[4]=t15,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_9259(t20,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=C_eqp(((C_word*)t0)[6],lf[243]);
if(C_truep(t11)){
t12=C_i_car(((C_word*)t0)[7]);
t13=t12;
t14=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t15=t14;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t16)[1];
t18=((C_word*)((C_word*)t0)[2])[1];
t19=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9314,a[2]=((C_word*)t0)[4],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9316,a[2]=t16,a[3]=t22,a[4]=t18,a[5]=t17,tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_9316(t24,t20,((C_word*)t0)[3]);}
else{
t12=C_eqp(((C_word*)t0)[6],lf[226]);
if(C_truep(t12)){
t13=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t13;
av2[1]=C_a_i_list1(&a,1,((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_eqp(((C_word*)t0)[6],lf[271]);
if(C_truep(t13)){
t14=C_i_car(((C_word*)t0)[7]);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9372,a[2]=((C_word*)t0)[2],a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_9372(t18,((C_word*)t0)[4],t14,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t14=C_eqp(((C_word*)t0)[6],lf[272]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_9424(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[6],lf[274]);
if(C_truep(t16)){
t17=t15;
f_9424(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[6],lf[275]);
t18=t15;
f_9424(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[6],lf[276])));}}}}}}}}}}}}}}}}

/* g727 in k6745 in k6742 in get-line-2 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_6751,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_cdr(t2);
/* support.scm:425: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_values(4,av2);}}

/* k11096 in loop in k11047 in matchn in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11098(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11098,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:864: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11067(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k16307 in k16304 in k16301 in k16298 in a16292 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16309,2,av);}
/* support.scm:512: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(62);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k16304 in k16301 in k16298 in a16292 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_16306,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
/* support.scm:512: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k16301 in k16298 in a16292 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_16303,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:512: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7870 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_7872,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[235],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#get-line-2 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6737,3,av);}
a=C_alloc(5);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6744,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:423: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[158]+1);
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_12113,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1083: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[379],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[381]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_12157(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[401]);
if(C_truep(t5)){
t6=t4;
f_12157(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[402]);
t7=t4;
f_12157(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[403])));}}}}}

/* k12114 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_12116,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[379],t1);
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k8831 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_8833,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1484 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8835(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8835,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8860,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:629: g1490 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8858 in map-loop1484 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8860,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8835(t6,((C_word*)t0)[5],t5);}

/* map-loop1094 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7811,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7836,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(lf[232],t4);
if(C_truep(t5)){
/* support.scm:549: error */
t6=*((C_word*)lf[4]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[233];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=t3;{
C_word av2[2];
av2[0]=t6;
av2[1]=t4;
f_7836(2,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5176 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5178,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:119: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k8888 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_8890,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[264],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1513 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8892(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8892,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:631: g1519 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5573 in k5566 in loop in k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_5575,2,t0,t1);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5579,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5589,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:197: number->string */
t5=*((C_word*)lf[72]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(8);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5577 in k5573 in k5566 in loop in k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5579,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* support.scm:198: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5546(t6,t3,t5);}

/* k7834 in map-loop1094 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7836,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7811(t6,((C_word*)t0)[5],t5);}

/* k5566 in loop in k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_5568,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(8)))){
t3=t2;
f_5575(t3,lf[73]);}
else{
t3=C_fixnum_lessp(((C_word*)t0)[5],C_fix(64));
t4=t2;
f_5575(t4,(C_truep(t3)?lf[74]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* support.scm:199: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5546(t5,t2,t4);}}

/* ##compiler#encodeable-literal? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_15631,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15645,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1523: immediate? */
t4=*((C_word*)lf[101]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* ##compiler#c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5528,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5540,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5544,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=*((C_word*)lf[71]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k15643 in encodeable-literal? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_15645,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_fixnump(((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_flonump(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t4=C_slot(((C_word*)t0)[3],C_fix(1));
t5=C_i_string_length(t4);
t6=((C_word*)t0)[2];
t7=C_a_i_arithmetic_shift(&a,2,t5,C_fix(-24));
t8=t6;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_u_i_zerop(t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
if(C_truep(C_byteblockp(((C_word*)t0)[3]))){
t4=((C_word*)t0)[3];
t5=stub3735(C_SCHEME_UNDEFINED,t4);
t6=((C_word*)t0)[2];
t7=C_a_i_arithmetic_shift(&a,2,t5,C_fix(-24));
t8=t6;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_u_i_zerop(t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t4=((C_word*)t0)[3];
t5=stub3735(C_SCHEME_UNDEFINED,t4);
t6=C_a_i_arithmetic_shift(&a,2,t5,C_fix(-24));
if(C_truep(C_u_i_zerop(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15702,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15704,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1536: list-tabulate */
t9=*((C_word*)lf[525]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t5;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t7=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}}}}}

/* k15924 in user-read-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_15926,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1586: scan-sharp-greater-string */
t3=*((C_word*)lf[537]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k15927 in k15924 in user-read-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,1)))){
C_save_and_reclaim((void *)f_15929,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,2,lf[535],t1);
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[536],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop in k11047 in matchn in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11067(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_11067,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_nullp(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:861: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10954(t4,t1,t3,t2);}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11098,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:863: matchn */
t7=((C_word*)((C_word*)t0)[4])[1];
f_11027(t7,t4,t5,t6);}}}}

/* k15969 in k15952 in loop in k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15971,2,av);}
/* support.scm:1597: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15950(t2,((C_word*)t0)[3]);}

/* loop in k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_5546,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[68];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=C_fix(C_character_code(t4));
t6=t5;
t7=C_fixnum_lessp(t6,C_fix(32));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5568,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5568(t9,t7);}
else{
t9=C_fixnum_greater_or_equal_p(t6,C_fix(127));
if(C_truep(t9)){
t10=t8;
f_5568(t10,t9);}
else{
t10=C_u_i_memq(t4,lf[75]);
t11=t8;
f_5568(t11,t10);}}}}

/* node-subexpressions-set! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7494,4,av);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:505: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(3);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_5544,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5546,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5546(t5,((C_word*)t0)[2],t1);}

/* k5538 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5540,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=*((C_word*)lf[67]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7800 in map-loop1121 in k7739 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7802,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7777(t6,((C_word*)t0)[5],t5);}

/* ##compiler#scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_15941,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15945,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1591: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_15945,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15950,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15950(t6,((C_word*)t0)[3]);}

/* node-subexpressions in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7485,3,av);}
t3=C_i_check_structure_2(t2,lf[211],lf[218]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##sys#user-read-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_15916,4,av);}
a=C_alloc(4);
if(C_truep(C_i_char_equalp(C_make_character(62),t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15926,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t5=*((C_word*)lf[538]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:1588: old-hook */
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* ##compiler#read/source-info in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15910,3,av);}
/* support.scm:1576: ##sys#read */
t3=*((C_word*)lf[533]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[528]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_10637,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
/* support.scm:807: delete-file* */
t3=*((C_word*)lf[300]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10700,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:808: with-output-to-file */
t4=*((C_word*)lf[308]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* ##compiler#emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,4)))){
C_save_and_reclaim((void *)f_10633,4,av);}
a=C_alloc(15);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10637,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10750,a[2]=t5,a[3]=t7,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:787: ##sys#hash-table-for-each */
t10=*((C_word*)lf[162]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* k5089 in k5083 in k5080 in k5077 in k5074 in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5091,2,av);}
if(C_truep(t1)){
/* support.scm:100: collect */
t2=((C_word*)t0)[2];
f_5015(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k9388 in k9384 in loop in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9390,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[271],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10644 in k10638 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10646,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:820: sort-symbols */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5083 in k5080 in k5077 in k5074 in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_5085,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:99: test-debugging-mode */
t3=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10638 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_10640,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:819: debugging */
t3=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[298];
av2[3]=lf[299];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_10646(2,av2);}}}

/* k5080 in k5077 in k5074 in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5082,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:98: flush-output */
t3=*((C_word*)lf[25]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5077 in k5074 in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5079,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:97: display */
t4=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5074 in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_5076,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:96: with-output-to-string */
t3=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:101: test-debugging-mode */
t3=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k10652 in k10644 in k10638 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_10654,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(t1,lf[35]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10662,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10662(t6,((C_word*)t0)[2],t1);}

/* node-class-set! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7458,4,av);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:505: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(1);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k15980 in k15952 in loop in k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_15982,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_eqp(C_make_character(35),t2);
if(C_truep(t3)){
/* support.scm:1601: get-output-string */
t4=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t5=*((C_word*)lf[527]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_make_character(60);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* a6783 in display-line-number-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6784(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6784,4,av);}
a=C_alloc(5);
if(C_truep(t3)){
t4=*((C_word*)lf[16]+1);
t5=*((C_word*)lf[16]+1);
t6=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6794,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:431: ##sys#print */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* for-each-loop2246 in k10652 in k10644 in k10638 in k10635 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_10662,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10672,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:820: g2262 */
t5=*((C_word*)lf[296]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[297];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* node-class in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7449,3,av);}
t3=C_i_check_structure_2(t2,lf[211],lf[213]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* node? in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7443(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7443,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[211]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6668 in k6665 in count! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_6670,2,t0,t1);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=C_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_plus(&a,2,t3,t1);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1),t3);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_i_setslot(((C_word*)t0)[2],C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:409: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* loop in k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_15950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_15950,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15954,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=*((C_word*)lf[538]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k15952 in loop in k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_15954,2,av);}
a=C_alloc(5);
if(C_truep(C_eofp(t1))){
/* support.scm:1594: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[539];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_u_i_char_equalp(t1,C_make_character(10)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1596: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
if(C_truep(C_u_i_char_equalp(t1,C_make_character(60)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=*((C_word*)lf[538]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[527]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}}}

/* ##compiler#count! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +7,c,3)))){
C_save_and_reclaim((void*)f_6663,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+7);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6667,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:403: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k6665 in count! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6667,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6670,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t4=((C_word*)t0)[4];
t5=t3;
f_6670(t5,C_u_i_car(t4));}
else{
t4=t3;
f_6670(t4,C_fix(1));}}

/* for-each-loop168 in k5130 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5151(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_5151,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5161,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:121: g169 */
t5=((C_word*)t0)[3];
f_5133(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* g2307 in resolve in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static C_word C_fcall f_10962(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* k5141 in k5130 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_5143,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5146,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:122: print-call-chain */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=*((C_word*)lf[37]+1);
av2[5]=lf[38];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5144 in k5141 in k5130 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5146(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5146,2,av);}
/* support.scm:123: exit */
t2=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(70);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k14733 in for-each-loop3442 in k14715 in walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14735(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_14735,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14725(t3,((C_word*)t0)[4],t2);}

/* k6792 in a6783 in display-line-number-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6794,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:431: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6795 in k6792 in a6783 in display-line-number-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_6797,2,av);}
a=C_alloc(20);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[4];
t8=C_i_check_list_2(t7,lf[161]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6813,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6815,a[2]=t5,a[3]=t11,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6815(t13,t9,t7);}

/* k15253 in loop in k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15255,2,av);}
/* support.scm:1457: string-intersperse */
t2=*((C_word*)lf[499]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[503];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_15259,2,av);}
a=C_alloc(9);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1446: get */
t5=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[181];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5025 in k5022 in g104 in collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_5027,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:90: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5022 in g104 in collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_5024,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:90: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(124);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10943 in k10909 in loop in a10900 in load-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_10945,2,av);}
a=C_alloc(3);
t2=C_a_i_list(&a,1,t1);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[313];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[313];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k5159 in for-each-loop168 in k5130 in k5127 in syntax-error-hook in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5161,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5151(t3,((C_word*)t0)[4],t2);}

/* k14715 in walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_14717,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=C_i_check_list_2(((C_word*)t0)[4],lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14725,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_14725(t7,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k15995 in k15992 in k15980 in k15952 in loop in k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15997,2,av);}
/* support.scm:1605: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15950(t2,((C_word*)t0)[3]);}

/* k15992 in k15980 in k15952 in loop in k15943 in scan-sharp-greater-string in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_15994,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[527]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5008 in k5001 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5010,2,av);}
/* support.scm:84: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4960(t2,((C_word*)t0)[3],t1);}

/* ##compiler#with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_5012,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5076,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:95: test-debugging-mode */
t6=*((C_word*)lf[11]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=*((C_word*)lf[1]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k10140 in k10132 in k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,3)))){
C_save_and_reclaim((void *)f_10142,2,av);}
a=C_alloc(33);
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10086,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t10=C_i_check_list_2(((C_word*)t0)[7],lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10096,a[2]=((C_word*)t0)[8],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10098,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_10098(t15,t11,((C_word*)t0)[7]);}

/* g104 in collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_5017,3,t0,t1,t2);}
a=C_alloc(5);
t3=*((C_word*)lf[8]+1);
t4=*((C_word*)lf[8]+1);
t5=C_i_check_port_2(*((C_word*)lf[8]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5024,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
/* support.scm:90: ##sys#print */
t9=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t6;
av2[2]=t8;
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[8]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t7=((C_word*)t0)[2];
/* support.scm:90: ##sys#print */
t8=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* collect in with-debugging-output in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_5015,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5044,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:94: string-split */
t5=*((C_word*)lf[27]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[28];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* resolve in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10954(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10954,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10962,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:837: g2307 */
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=(
  /* support.scm:837: g2307 */
  f_10962(t5,t4)
);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(C_i_memq(t2,((C_word*)t0)[3]))){
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t2,t3),((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_eqp(t2,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}

/* k7433 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7435,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_6853(t3,t2);}

/* f_7437 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_7437,5,av);}
a=C_alloc(5);
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[211],t2,t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* ##compiler#match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,4)))){
C_save_and_reclaim((void *)f_10951,5,av);}
a=C_alloc(27);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10954,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10988,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11027,a[2]=t8,a[3]=t12,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11142,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:866: matchn */
t17=((C_word*)t12)[1];
f_11027(t17,t16,t2,t3);}

/* k4998 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5000,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10148 in k10132 in k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10150,2,av);}
/* support.scm:751: build-lambda-list */
t2=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2465 in a11554 in compute-database-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static C_word C_fcall f_11557(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_stack_overflow_check;{}
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_car(t1);
t5=C_eqp(t4,lf[189]);
if(C_truep(t5)){
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
return(t7);}
else{
t6=C_eqp(t4,lf[172]);
if(C_truep(t6)){
t7=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t8=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t7);
t9=t1;
t10=C_u_i_cdr(t9);
t11=C_slot(t10,C_fix(1));
t12=C_eqp(lf[133],t11);
if(C_truep(t12)){
t13=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t14=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t13);
return(t14);}
else{
t13=C_SCHEME_UNDEFINED;
return(t13);}}
else{
t7=C_eqp(t4,lf[177]);
if(C_truep(t7)){
t8=t1;
t9=C_u_i_cdr(t8);
t10=C_i_length(t9);
t11=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[6])[1],t10);
t12=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t11);
return(t12);}
else{
t8=C_SCHEME_UNDEFINED;
return(t8);}}}}

/* k5001 in k4977 in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5003,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:84: text */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4895(t3,t2);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11548 in compute-database-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,8)))){
C_save_and_reclaim((void *)f_11550,2,av);}
/* support.scm:980: values */{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[333]+1);
av2[3]=*((C_word*)lf[334]+1);
av2[4]=((C_word*)((C_word*)t0)[3])[1];
av2[5]=((C_word*)((C_word*)t0)[4])[1];
av2[6]=((C_word*)((C_word*)t0)[5])[1];
av2[7]=((C_word*)((C_word*)t0)[6])[1];
av2[8]=((C_word*)((C_word*)t0)[7])[1];
C_values(9,av2);}}

/* a11554 in compute-database-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_11555,4,av);}
a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_check_list_2(t3,lf[35]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11636,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_11636(t9,t1,t3);}

/* walk in scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14773(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_14773,4,t0,t1,t2,t3);}
a=C_alloc(11);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[97]);
t14=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14807,a[2]=t1,a[3]=t12,a[4]=t9,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t6,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t13)){
t15=t14;
f_14807(t15,t13);}
else{
t15=C_eqp(t12,lf[226]);
if(C_truep(t15)){
t16=t14;
f_14807(t16,t15);}
else{
t16=C_eqp(t12,lf[241]);
if(C_truep(t16)){
t17=t14;
f_14807(t17,t16);}
else{
t17=C_eqp(t12,lf[245]);
t18=t14;
f_14807(t18,(C_truep(t17)?t17:C_eqp(t12,lf[257])));}}}}

/* ##compiler#scan-free-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,4)))){
C_save_and_reclaim((void *)f_14770,3,av);}
a=C_alloc(22);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14773,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14957,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14995,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1381: walk */
t14=((C_word*)t8)[1];
f_14773(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* ##compiler#compute-database-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,4)))){
C_save_and_reclaim((void *)f_11546,3,av);}
a=C_alloc(25);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11550,a[2]=t1,a[3]=t6,a[4]=t4,a[5]=t8,a[6]=t12,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11555,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:966: ##sys#hash-table-for-each */
t15=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t13;
av2[2]=t14;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}

/* k5581 in k5577 in k5573 in k5566 in loop in k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_5583,2,av);}
/* support.scm:193: append */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[70];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k15293 in k15290 in k15287 in a15281 in display-real-name-table in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15295,2,av);}
/* support.scm:1466: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5587 in k5573 in k5566 in loop in k5542 in c-ify-string in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5589,2,av);}
/* string->list */
t2=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k15290 in k15287 in a15281 in display-real-name-table in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_15292,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1466: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10932 in k10909 in loop in a10900 in load-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10934,2,av);}
/* support.scm:832: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10907(t2,((C_word*)t0)[3]);}

/* ##compiler#uncommentify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5476,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:174: ->string */
t4=*((C_word*)lf[60]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5472 in backslashify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5474(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5474,2,av);}
/* support.scm:172: string-translate* */
t2=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[59];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a10900 in load-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_10901,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10907,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_10907(t5,t1);}

/* loop in a10900 in load-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_10907,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10911,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:826: read */
t3=*((C_word*)lf[117]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k15227 in k15214 in loop in k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15229,2,av);}
/* support.scm:1453: string-intersperse */
t2=*((C_word*)lf[499]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[502];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#foreign-type-convert-argument in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_12840,4,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12853,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1159: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[398]+1);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k10909 in loop in a10900 in load-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_10911,2,av);}
a=C_alloc(8);
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10945,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t1);
/* support.scm:831: sexpr->node */
t7=*((C_word*)lf[294]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k12851 in foreign-type-convert-argument in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_12853,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15242 in k15246 in k15214 in loop in k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15244,2,av);}
/* support.scm:1454: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15192(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k15246 in k15214 in loop in k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_15248,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=t2;
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1456: get */
t7=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=lf[181];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* ##compiler#stringify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5402,3,av);}
a=C_alloc(4);
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:164: symbol->string */
t3=*((C_word*)lf[51]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5421,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:165: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k6491 in for-each-loop581 in k6383 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6493(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6493,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6483(t3,((C_word*)t0)[4],t2);}

/* a12876 in final-foreign-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_12877,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12881,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:1168: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[398]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_12881(2,av2);}}}

/* ##compiler#final-foreign-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_12871,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12877,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1165: follow-without-loop */
t5=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k11533 in toplevel-definition-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11535,2,av);}
/* support.scm:944: hide-variable */
t2=*((C_word*)lf[330]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop581 in k6383 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6483(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_6483,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6493,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6404,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_a_i_list(&a,1,lf[146]);
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11521 in a11481 in dump-global-refs in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_11523,2,av);}
a=C_alloc(9);
t2=(C_truep(t1)?C_SCHEME_FALSE:C_i_assq(lf[189],((C_word*)t0)[2]));
if(C_truep(t2)){
t3=C_i_assq(lf[176],((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11495,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=C_i_length(t5);
t7=C_a_i_list2(&a,2,((C_word*)t0)[4],t6);
/* support.scm:933: write */
t8=*((C_word*)lf[207]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(0));
/* support.scm:933: write */
t6=*((C_word*)lf[207]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##sys#toplevel-definition-hook in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11525(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11525,6,av);}
a=C_alloc(4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11535,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:943: debugging */
t8=*((C_word*)lf[14]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[261];
av2[3]=lf[331];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* ##compiler#collapsable-literal? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5914,3,av);}
t3=C_booleanp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eofp(t2);
if(C_truep(t5)){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_numberp(t2);
t7=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=(C_truep(t6)?t6:C_i_symbolp(t2));
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}}

/* k9111 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9113,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8915 in map-loop1513 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8917,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8892(t6,((C_word*)t0)[5],t5);}

/* k10121 in map-loop2000 in k10140 in k10132 in k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10123,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10098(t6,((C_word*)t0)[5],t5);}

/* for-each-loop3442 in k14715 in walk in scan-used-variables in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_14725(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_14725,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14735,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1343: g3443 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10132 in k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_10134,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10142,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10150,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[9])){
t7=((C_word*)t0)[9];
/* support.scm:712: alist-ref */
t8=*((C_word*)lf[287]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[4];
av2[4]=*((C_word*)lf[13]+1);
av2[5]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(6,av2);}}
else{
/* support.scm:751: build-lambda-list */
t7=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[8];
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* ##compiler#constant? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5852,3,av);}
a=C_alloc(4);
t3=C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_booleanp(t2);
if(C_truep(t6)){
t7=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eofp(t2);
if(C_truep(t7)){
t8=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5886,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:257: blob? */
t9=*((C_word*)lf[99]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}}}}

/* k5848 in k5844 in a5837 in sort-symbols in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5850,2,av);}
/* support.scm:246: string<? */
t2=*((C_word*)lf[94]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5425 in k5419 in stringify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5427,2,av);}
/* support.scm:165: get-output-string */
t2=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5419 in stringify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_5421,2,av);}
a=C_alloc(4);
t2=t1;
t3=C_i_check_port_2(t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:165: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* node-parameters-set! in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7476,4,av);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:505: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(2);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k6431 in k6383 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6433,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[140]+1);
t3=C_i_check_list_2(*((C_word*)lf[140]+1),lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6460,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6460(t7,((C_word*)t0)[2],*((C_word*)lf[140]+1));}

/* k5844 in a5837 in sort-symbols in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5846,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5850,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:246: symbol->string */
t4=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10058 in k10055 in g1939 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10060,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5453 in symbolify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_5455,2,av);}
a=C_alloc(4);
t2=t1;
t3=C_i_check_port_2(t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:170: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* ##compiler#foreign-type->scrutiny-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_14049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_14049,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14053,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1273: final-foreign-type */
t5=*((C_word*)lf[437]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* node-parameters in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7467(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7467,3,av);}
t3=C_i_check_structure_2(t2,lf[211],lf[216]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(2));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#sort-symbols in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_5832,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5838,tmp=(C_word)a,a+=2,tmp);
/* support.scm:246: sort */
t4=*((C_word*)lf[95]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a5837 in sort-symbols in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5838,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5846,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:246: symbol->string */
t5=*((C_word*)lf[51]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,4)))){
C_save_and_reclaim((void *)f_10066,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[8];
t9=C_i_check_list_2(t2,lf[161]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10163,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10165,a[2]=t6,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_10165(t14,t10,t8,t2);}

/* k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_10069,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm:750: gensym */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[289];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k9135 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9137,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[267],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#symbolify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5432,3,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_stringp(t2))){
/* support.scm:169: string->symbol */
t3=*((C_word*)lf[56]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5455,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:170: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k6402 in for-each-loop581 in k6383 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6404,2,av);}
a=C_alloc(3);
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[144]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5896 in k5884 in constant? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5898,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_eqp(lf[97],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* ##compiler#basic-literal? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5990,3,av);}
a=C_alloc(4);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6006,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:280: constant? */
t6=*((C_word*)lf[96]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* g2006 in k10140 in k10132 in k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10086(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_10086,3,t0,t1,t2);}
/* support.scm:753: g2023 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9882(t3,t1,t2,((C_word*)t0)[3]);}

/* k5884 in constant? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5886,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_vectorp(((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:259: ##sys#srfi-4-vector? */
t4=*((C_word*)lf[98]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}

/* k13423 in k13386 in k13380 in k13368 in a13359 in estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_13425(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_13425,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:1228: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* support.scm:1207: quit */
t4=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[445];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5986 in immediate? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5988,2,av);}
t2=((C_word*)t0)[2];
f_5948(t2,C_i_not(t1));}

/* k15204 in loop in k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15206,2,av);}
/* support.scm:1449: string-intersperse */
t2=*((C_word*)lf[499]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[500];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop2000 in k10140 in k10132 in k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10098(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10098,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10123,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:753: g2006 */
t5=((C_word*)t0)[4];
f_10086(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10094 in k10140 in k10132 in k10067 in k10064 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_10096,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[133],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8991 in k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_8993,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[161]);
t3=C_i_check_list_2(t1,lf[161]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9012,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_9012(t8,t4,((C_word*)t0)[2],t1);}

/* k8988 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_8990,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9060,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9060(t6,t2,t1);}

/* k9169 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_9171,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9175,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[4]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9183,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9183(t9,t3,t4,t5);}

/* k16242 in k16239 in k16236 in k16233 in k16230 in k16224 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16244,2,av);}
/* support.scm:1653: debugging */
t2=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[553];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k16246 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16248,2,av);}
/* support.scm:1652: file-exists? */
t2=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9173 in k9169 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_9175,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[269],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k16239 in k16236 in k16233 in k16230 in k16224 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16241,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1653: get-output-string */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* loop in k9169 in k8818 in walk in build-expression-tree in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9183(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_9183,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9207,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t3);
/* support.scm:658: walk */
t6=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
f_8786(3,av2);}}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9234,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(t3);
/* support.scm:659: walk */
t8=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
f_8786(3,av2);}}}

/* ##compiler#immediate? in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_5944,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5948,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5988,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:270: big-fixnum? */
t5=*((C_word*)lf[102]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t3;
f_5948(t4,C_SCHEME_FALSE);}}

/* k5946 in immediate? in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,1)))){
C_save_and_reclaim_args((void *)trf_5948,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_nullp(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eofp(((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_charp(((C_word*)t0)[3]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?t5:C_booleanp(((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}

/* k8021 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8023(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_8023,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8003,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8011,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8015,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:572: cadar */
t7=*((C_word*)lf[239]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* ##compiler#print-debug-options in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16287,2,av);}
/* support.scm:1799: display */
t2=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[564];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a5821 in loop in follow-without-loop in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_5822,3,av);}
a=C_alloc(3);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* support.scm:243: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5807(t4,t1,t2,t3);}

/* k16280 in k16277 in print-usage in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16282,2,av);}
/* support.scm:1672: display */
t2=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[562];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#real-name2 in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15264(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_15264,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15268,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1461: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[497]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k8001 in k8021 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8003,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[237],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k15266 in real-name2 in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15268,2,av);}
if(C_truep(t1)){
/* support.scm:1462: real-name */
t2=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k16233 in k16230 in k16224 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16235,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1653: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[554];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* ##compiler#foreign-type-convert-result in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_12809,4,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12822,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1152: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[398]+1);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k16236 in k16233 in k16230 in k16224 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_16238,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1653: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a12802 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_12803,2,av);}
/* support.scm:1145: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[434];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k16230 in k16224 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16232,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1653: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6468 in for-each-loop628 in k6431 in k6383 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6470,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6460(t3,((C_word*)t0)[4],t2);}

/* ##compiler#display-real-name-table in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_15276,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15282,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1465: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[497]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16224 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_16226,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16232,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1653: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[555];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* loop in follow-without-loop in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_5807,4,t0,t1,t2,t3);}
a=C_alloc(5);
if(C_truep(C_i_member(t2,t3))){
/* support.scm:242: abort */
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5822,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:243: proc */
t5=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* ##compiler#follow-without-loop in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5801(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_5801,5,av);}
a=C_alloc(7);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5807,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5807(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* for-each-loop628 in k6431 in k6383 in initialize-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6460(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_6460,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6470,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,lf[141]);
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[143];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t6=C_i_car(t5);
/* tweaks.scm:54: ##sys#put! */
t7=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[143];
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a15281 in display-real-name-table in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_15282,4,av);}
a=C_alloc(5);
t4=*((C_word*)lf[16]+1);
t5=*((C_word*)lf[16]+1);
t6=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15289,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1466: ##sys#print */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,5)))){
C_save_and_reclaim((void *)f_8060,2,av);}
a=C_alloc(10);
t2=C_a_i_list1(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7937(t6,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,t2);}

/* k15287 in a15281 in display-real-name-table in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_15289,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1466: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(9);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16255 in print-version in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16257,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16264,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1667: chicken-version */
t3=*((C_word*)lf[307]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k12820 in foreign-type-convert-result in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_12822,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(2));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#print-version in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,2)))){
C_save_and_reclaim((void*)f_16250,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16257,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
/* support.scm:1666: print* */
t6=*((C_word*)lf[559]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[560];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f17649,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1667: chicken-version */
t7=*((C_word*)lf[307]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k15214 in loop in k15188 in k15257 in k15161 in real-name in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_15216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_15216,2,av);}
a=C_alloc(8);
t2=C_eqp(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15229,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1453: reverse */
t4=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15248,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1454: symbol->string */
t4=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k8009 in k8021 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8011,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:572: reverse */
t3=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8013 in k8021 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8015,2,av);}
/* support.scm:572: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7545(3,av2);}}

/* k9850 in map-loop1800 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9852,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9827(t6,((C_word*)t0)[5],t5);}

/* match1 in match-node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10988(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_10988,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:848: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10954(t4,t1,t3,t2);}
else{
if(C_truep(C_i_not_pair_p(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11010,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:850: match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k8042 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_8044,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:573: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7937(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k8046 in loop in k8058 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8048,2,av);}
/* support.scm:575: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7545(3,av2);}}

/* walk in sexpr->node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_10568,3,av);}
a=C_alloc(18);
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=((C_word*)((C_word*)t0)[2])[1];
t12=t2;
t13=C_u_i_cdr(t12);
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[161]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10597,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10599,a[2]=t9,a[3]=t18,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_10599(t20,t16,t14);}

/* ##compiler#sexpr->node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_10562,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10568,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
f_10568(3,av2);}}

/* rec in simple-lambda-node? in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11305,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(t4,lf[253]);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[221],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=C_eqp(((C_word*)t0)[2],t12);
if(C_truep(t13)){
t14=C_u_i_cdr(t7);
/* support.scm:901: every */
t15=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t11=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t6=C_eqp(t4,lf[243]);
if(C_truep(t6)){
t7=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=t2;
t8=C_slot(t7,C_fix(3));
/* support.scm:903: every */
t9=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}}

/* k5482 in uncommentify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5484,2,av);}
/* support.scm:174: string-translate* */
t2=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[62];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#build-lambda-list in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5486(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5486,5,av);}
a=C_alloc(6);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5492,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5492(t8,t1,t2,t3);}

/* k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,4)))){
C_save_and_reclaim_args((void *)trf_6853,2,t0,t1);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:455: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10551 in map-loop2124 in walk in node->sexpr in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10553,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10528(t6,((C_word*)t0)[5],t5);}

/* a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,2)))){
C_save_and_reclaim((void *)f_6858,4,av);}
a=C_alloc(19);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6868,a[2]=t1,a[3]=t11,a[4]=t13,a[5]=t5,a[6]=t7,a[7]=t9,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* support.scm:463: write */
t15=*((C_word*)lf[207]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t15;
av2[1]=t14;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}

/* g2872 in k12879 in a12876 in final-foreign-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12885(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_12885,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1170: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1170: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k8085 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,3)))){
C_save_and_reclaim_args((void *)trf_8087,2,t0,t1);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=((C_word*)t0)[3];
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_i_check_list_2(t10,lf[161]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8101,a[2]=t5,a[3]=t14,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8101(t16,t12,t10);}

/* k10832 in k10816 in k10813 in k10858 in k10779 in k10891 in k10755 in a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10834,2,av);}
a=C_alloc(9);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k12879 in a12876 in final-foreign-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_12881,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12885,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1167: g2872 */
t3=t2;
f_12885(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5459 in k5453 in symbolify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5461(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5461,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5464,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:170: get-output-string */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* ##compiler#backslashify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5466(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5466,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5474,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:172: ->string */
t4=*((C_word*)lf[60]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5462 in k5459 in k5453 in symbolify in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5464,2,av);}
/* support.scm:170: string->symbol */
t2=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1800 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9827,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9852,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:690: g1806 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11949 in k11934 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,0,1)))){
C_save_and_reclaim_args((void *)trf_11951,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6878 in k6875 in k6872 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6880,2,av);}
/* support.scm:497: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in build-lambda-list in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5492(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_5492,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=C_i_zerop(t3);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=(C_truep(t6)?t6:C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_i_car(t2);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
t11=C_a_i_minus(&a,2,t3,C_fix(1));
/* support.scm:179: loop */
t13=t8;
t14=t10;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_9874,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
/* support.scm:755: walk */
t5=((C_word*)t3)[1];
f_9882(t5,((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_9882(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(10,0,5)))){
C_save_and_reclaim_args((void *)trf_9882,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[97]);
if(C_truep(t13)){
t14=t1;
t15=t14;{
C_word av2[2];
av2[0]=t15;
av2[1]=C_a_i_record4(&a,4,lf[211],t12,t9,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=C_eqp(t12,lf[221]);
if(C_truep(t14)){
t15=C_i_car(t9);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9933,a[2]=t1,a[3]=t3,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9943,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* support.scm:722: get */
t19=*((C_word*)lf[148]+1);{
C_word av2[5];
av2[0]=t19;
av2[1]=t18;
av2[2]=((C_word*)t0)[3];
av2[3]=t16;
av2[4]=lf[190];
((C_proc)(void*)(*((C_word*)t19+1)))(5,av2);}}
else{
t15=C_eqp(t12,lf[246]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9980,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t17=C_i_car(t9);
t18=t3;
/* support.scm:712: alist-ref */
t19=*((C_word*)lf[287]+1);{
C_word av2[6];
av2[0]=t19;
av2[1]=t16;
av2[2]=t17;
av2[3]=t18;
av2[4]=*((C_word*)lf[13]+1);
av2[5]=t17;
((C_proc)(void*)(*((C_word*)t19+1)))(6,av2);}}
else{
t16=C_eqp(t12,lf[109]);
if(C_truep(t16)){
t17=C_i_car(t9);
t18=t17;
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9996,a[2]=t18,a[3]=t3,a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t20=C_i_car(t6);
/* support.scm:731: walk */
t22=t19;
t23=t20;
t24=t3;
t1=t22;
t2=t23;
t3=t24;
goto loop;}
else{
t17=C_eqp(t12,lf[133]);
if(C_truep(t17)){
t18=C_i_caddr(t9);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10048,a[2]=((C_word*)t0)[3],a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:739: decompose-lambda-list */
t20=*((C_word*)lf[124]+1);{
C_word av2[4];
av2[0]=t20;
av2[1]=t1;
av2[2]=t18;
av2[3]=t19;
((C_proc)(void*)(*((C_word*)t20+1)))(4,av2);}}
else{
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10257,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t6,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:754: tree-copy */
t19=*((C_word*)lf[290]+1);{
C_word av2[3];
av2[0]=t19;
av2[1]=t18;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}}}}}}

/* k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_6868,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7046,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_7046(t6,t2,((C_word*)t0)[8]);}

/* k8097 in k8085 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8099,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10858 in k10779 in k10891 in k10755 in a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_10860,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10815,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[3];
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=lf[312];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k6811 in k6795 in k6792 in a6783 in display-line-number-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6813,2,av);}
/* support.scm:431: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* ##compiler#posq in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5334,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5340,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5340(t7,t1,t3,C_fix(0));}

/* map-loop740 in k6795 in k6792 in a6783 in display-line-number-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_6815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_6815,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* for-each-loop2464 in a11554 in compute-database-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_11636(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(20,0,2)))){
C_save_and_reclaim_args((void *)trf_11636,3,t0,t1,t2);}
a=C_alloc(20);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
  /* support.scm:967: g2465 */
  f_11557(C_a_i(&a,20),((C_word*)t0)[2],t3)
);
t5=C_slot(t2,C_fix(1));
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##compiler#display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_6849,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6853,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_6853(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7435,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:452: append */
t5=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[208]+1);
av2[3]=*((C_word*)lf[209]+1);
av2[4]=*((C_word*)lf[140]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* ##compiler#copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,4)))){
C_save_and_reclaim((void *)f_9861,7,av);}
a=C_alloc(18);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=C_i_check_list_2(t3,lf[161]);
t12=C_i_check_list_2(t4,lf[161]);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9874,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10321,a[2]=t9,a[3]=t15,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_10321(t17,t13,t3,t4);}

/* ##compiler#posv in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_5368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5368,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5374,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5374(t7,t1,t3,C_fix(0));}

/* k6872 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_6874,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[4])[1]))){
t3=*((C_word*)lf[16]+1);
t4=*((C_word*)lf[16]+1);
t5=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6908,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:495: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[165];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6877(2,av2);}}}

/* k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_6871,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6918,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
t5=t3;
f_6918(t5,C_i_not(t4));}
else{
t4=t3;
f_6918(t4,C_SCHEME_FALSE);}}

/* k6875 in k6872 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_6877,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t3=*((C_word*)lf[16]+1);
t4=*((C_word*)lf[16]+1);
t5=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6892,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:496: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[164];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* support.scm:497: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12969 in k12963 in k12951 in k12939 in k12930 in a12921 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_12971,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1194: g2991 */
t3=t2;
f_12975(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[387]);
if(C_truep(t4)){
if(C_truep(t4)){
/* support.scm:1200: words->bytes */
t5=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t5=C_eqp(t3,lf[395]);
if(C_truep(t5)){
if(C_truep(t5)){
/* support.scm:1200: words->bytes */
t6=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=C_eqp(t3,lf[396]);
if(C_truep(t6)){
if(C_truep(t6)){
/* support.scm:1200: words->bytes */
t7=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t7=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t7=C_eqp(t3,lf[378]);
if(C_truep(t7)){
if(C_truep(t7)){
/* support.scm:1200: words->bytes */
t8=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t8=C_eqp(t3,lf[380]);
if(C_truep(t8)){
if(C_truep(t8)){
/* support.scm:1200: words->bytes */
t9=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t9=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t9=C_eqp(t3,lf[397]);
if(C_truep(t9)){
if(C_truep(t9)){
/* support.scm:1200: words->bytes */
t10=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t10=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t10=C_eqp(t3,lf[388]);
if(C_truep(t10)){
if(C_truep(t10)){
/* support.scm:1200: words->bytes */
t11=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t11=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t11=C_eqp(t3,lf[389]);
if(C_truep(t11)){
if(C_truep(t11)){
/* support.scm:1200: words->bytes */
t12=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t12=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t12;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}
else{
t12=C_eqp(t3,lf[392]);
if(C_truep(t12)){
/* support.scm:1200: words->bytes */
t13=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}
else{
t13=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}}}}}}}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* ##compiler#load-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,3)))){
C_save_and_reclaim((void *)f_10895,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10901,tmp=(C_word)a,a+=2,tmp);
/* support.scm:823: with-input-from-file */
t4=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10891 in k10755 in a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_10893,2,av);}
a=C_alloc(9);
if(C_truep(C_i_structurep(t1,lf[211]))){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_assq(lf[172],((C_word*)t0)[3]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_10781(t5,t3);}
else{
t5=C_i_cdr(t2);
t6=C_eqp(lf[169],t5);
t7=t4;
f_10781(t7,C_i_not(t6));}}}

/* k16209 in for-each-loop3976 in k16194 in k16166 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16211(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16211,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_16201(t3,((C_word*)t0)[4],t2);}

/* k12243 in k12200 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_12245,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12249,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1107: g2795 */
t3=t2;
f_12249(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[387]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12282,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_12282(t6,t4);}
else{
t6=C_eqp(t3,lf[396]);
if(C_truep(t6)){
t7=t5;
f_12282(t7,t6);}
else{
t7=C_eqp(t3,lf[397]);
t8=t5;
f_12282(t8,(C_truep(t7)?t7:C_eqp(t3,lf[378])));}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* g2795 in k12243 in k12200 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12249(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_12249,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1109: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1109: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k8519 in map-loop1350 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8521,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8496(t6,((C_word*)t0)[5],t5);}

/* k11934 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,2)))){
C_save_and_reclaim((void *)f_11936,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11951,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[353]+1))){
t7=t6;
f_11951(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[97],lf[364]);
t8=t6;
f_11951(t8,C_a_i_list(&a,3,lf[365],t7,t2));}}

/* k11685 in k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_11687,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:992: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[341];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11682 in k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_11684,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:992: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9811 in k9731 in k9728 in a9725 in a9713 in inline-lambda-bindings in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_9813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(34,c,2)))){
C_save_and_reclaim((void *)f_9813,2,av);}
a=C_alloc(34);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
/* support.scm:700: qnode */
t5=*((C_word*)lf[222]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=C_i_length(((C_word*)t0)[4]);
t6=C_a_i_times(&a,2,C_fix(3),t5);
t7=C_a_i_list2(&a,2,lf[285],t6);
t8=((C_word*)t0)[4];
t9=C_a_i_record4(&a,4,lf[211],lf[251],t7,t8);
t10=C_a_i_list2(&a,2,t9,((C_word*)t0)[2]);
t11=((C_word*)t0)[3];
f_9759(t11,C_a_i_record4(&a,4,lf[211],lf[109],t3,t10));}}

/* k8587 in map-loop1396 in k8602 in k8598 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8589,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8564(t6,((C_word*)t0)[5],t5);}

/* g2991 in k12969 in k12963 in k12951 in k12939 in k12930 in a12921 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12975(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_12975,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1196: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1196: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k11676 in a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_11678,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm:992: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[342];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a11670 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_11671,9,av);}
a=C_alloc(10);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11678,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm:991: debugging */
t10=*((C_word*)lf[14]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[343];
av2[3]=lf[344];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* k6798 in k6795 in k6792 in a6783 in display-line-number-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6800,2,av);}
/* support.scm:431: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a11664 in print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11665,2,av);}
/* support.scm:990: compute-database-statistics */
t2=*((C_word*)lf[332]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#print-program-statistics in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,9)))){
C_save_and_reclaim((void *)f_11659,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11671,tmp=(C_word)a,a+=2,tmp);
/* support.scm:988: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* k7765 in k7739 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7767,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7775,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:552: walk */
t4=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
f_7545(3,av2);}}

/* map-loop1396 in k8602 in k8598 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8564(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8564,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8589,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:616: g1402 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8560 in k8602 in k8598 in a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8562,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[253],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8366 in k8382 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8368,2,av);}
/* support.scm:597: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7545(3,av2);}}

/* loop in posq in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5340(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_5340,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:154: loop */
t10=t1;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* k16277 in print-usage in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16279,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1671: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##compiler#print-usage in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16275,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16279,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1670: print-version */
t3=*((C_word*)lf[558]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a12921 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12922(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_12922,4,av);}
a=C_alloc(6);
t4=t2;
t5=C_eqp(t4,lf[351]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12932,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_12932(t7,t5);}
else{
t7=C_eqp(t4,lf[355]);
if(C_truep(t7)){
t8=t6;
f_12932(t8,t7);}
else{
t8=C_eqp(t4,lf[428]);
if(C_truep(t8)){
t9=t6;
f_12932(t9,t8);}
else{
t9=C_eqp(t4,lf[440]);
if(C_truep(t9)){
t10=t6;
f_12932(t10,t9);}
else{
t10=C_eqp(t4,lf[441]);
if(C_truep(t10)){
t11=t6;
f_12932(t11,t10);}
else{
t11=C_eqp(t4,lf[429]);
if(C_truep(t11)){
t12=t6;
f_12932(t12,t11);}
else{
t12=C_eqp(t4,lf[442]);
if(C_truep(t12)){
t13=t6;
f_12932(t13,t12);}
else{
t13=C_eqp(t4,lf[352]);
if(C_truep(t13)){
t14=t6;
f_12932(t14,t13);}
else{
t14=C_eqp(t4,lf[427]);
if(C_truep(t14)){
t15=t6;
f_12932(t15,t14);}
else{
t15=C_eqp(t4,lf[430]);
if(C_truep(t15)){
t16=t6;
f_12932(t16,t15);}
else{
t16=C_eqp(t4,lf[431]);
if(C_truep(t16)){
t17=t6;
f_12932(t17,t16);}
else{
t17=C_eqp(t4,lf[432]);
t18=t6;
f_12932(t18,(C_truep(t17)?t17:C_eqp(t4,lf[433])));}}}}}}}}}}}}

/* k16262 in k16255 in print-version in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16264(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16264,2,av);}
/* support.scm:1667: print */
t2=*((C_word*)lf[296]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8322 in map-loop1270 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8324,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8299(t6,((C_word*)t0)[5],t5);}

/* ##compiler#estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_12916,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12922,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13342,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1178: follow-without-loop */
t5=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* a16292 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_16293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16293,4,av);}
a=C_alloc(5);
t4=t3;
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16300,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:512: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[565];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k10816 in k10813 in k10858 in k10779 in k10891 in k10755 in a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_10818,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_u_i_cdr(((C_word*)t0)[6]);
/* support.scm:804: node->sexpr */
t6=*((C_word*)lf[293]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10813 in k10858 in k10779 in k10891 in k10755 in a10749 in emit-global-inline-file in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_10815,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(t1,lf[309]);
if(C_truep(t3)){
t4=t2;
f_10818(t4,C_SCHEME_TRUE);}
else{
t4=C_eqp(t1,lf[310]);
if(C_truep(t4)){
t5=t2;
f_10818(t5,C_SCHEME_FALSE);}
else{
t5=C_i_cadddr(((C_word*)t0)[7]);
t6=t2;
f_10818(t6,C_i_lessp(t5,*((C_word*)lf[311]+1)));}}}

/* for-each-loop3976 in k16194 in k16166 in k16160 in k16154 in load-identifier-database in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_16201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,3)))){
C_save_and_reclaim_args((void *)trf_16201,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16211,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16180,a[2]=t5,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16184,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1659: ##sys#get */
t11=*((C_word*)lf[255]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t8;
av2[3]=lf[551];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8382 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,2)))){
C_save_and_reclaim((void *)f_8384,2,av);}
a=C_alloc(20);
t2=C_i_cadr(t1);
t3=C_a_i_list4(&a,4,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8364,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8368,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:597: sixth */
t7=*((C_word*)lf[249]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* ##compiler#dump-undefined-globals in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_11398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_11398,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11404,tmp=(C_word)a,a+=2,tmp);
/* support.scm:909: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10524 in walk in node->sexpr in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_10526,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2124 in walk in node->sexpr in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10528(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10528,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10553,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:778: g2130 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8362 in k8382 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_8364,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[248],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* g1127 in k7739 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_7750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_7750,3,t0,t1,t2);}
t3=C_i_cadr(t2);
/* support.scm:551: walk */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
f_7545(3,av2);}}

/* k12200 in k12155 in k12111 in k12084 in k12057 in k12031 in k11989 in k11866 in k11851 in repeat in a11821 in foreign-type-check in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_12202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,3)))){
C_save_and_reclaim_args((void *)trf_12202,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[353]+1))){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[382],((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,2,lf[383],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[382],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[353]+1))){
t3=C_a_i_list(&a,2,lf[386],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[382],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_a_i_list(&a,2,lf[386],((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,lf[383],t3);
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[382],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12245,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* support.scm:1107: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[398]+1);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_12245(2,av2);}}}}}

/* a12909 in final-foreign-type in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_12910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_12910,2,av);}
/* support.scm:1172: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[438];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7743 in k7739 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_7745,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7739 in k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,3)))){
C_save_and_reclaim((void *)f_7741,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7745,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=C_i_cadr(((C_word*)t0)[4]);
t10=C_i_check_list_2(t9,lf[161]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7767,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7777,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_7777(t15,t11,t9);}

/* a8538 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_8539,4,av);}
a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8628,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
/* tweaks.scm:57: ##sys#get */
t7=*((C_word*)lf[255]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=lf[256];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k13899 in k13783 in finish-foreign-result in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_13901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,3)))){
C_save_and_reclaim_args((void *)trf_13901,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* support.scm:1254: finish-foreign-result */
t3=*((C_word*)lf[447]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(3),t2);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=C_eqp(t4,lf[388]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[389]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13929,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1258: gensym */
t8=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(t4,lf[392]);
if(C_truep(t7)){
t8=C_i_caddr(((C_word*)t0)[2]);
t9=C_a_i_list(&a,2,lf[97],lf[390]);
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=C_a_i_list(&a,4,lf[457],t8,t9,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t8=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t8;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}
else{
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k7736 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_7738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_7738,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7811(t6,t2,t1);}

/* a8532 in k8403 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_8533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8533,2,av);}
/* support.scm:604: get-line-2 */
t2=*((C_word*)lf[159]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1933 in a10047 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10213,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10238,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:742: g1939 */
t5=((C_word*)t0)[4];
f_10053(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* dump in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4960,3,t0,t1,t2);}
a=C_alloc(5);
t3=*((C_word*)lf[8]+1);
t4=*((C_word*)lf[8]+1);
t5=C_i_check_port_2(*((C_word*)lf[8]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4967,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:62: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[8]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k4828 */
static void C_ccall f_4830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4830,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k4831 in k4828 */
static void C_ccall f_4833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4833,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k4834 in k4831 in k4828 */
static void C_ccall f_4836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4836,2,av);}
a=C_alloc(7);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4840,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[1] /* ##compiler#debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[2] /* ##compiler#disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate2((C_word*)lf[3]+1 /* (set! ##compiler#bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4845,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:53: open-output-string */
t7=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* map-loop1192 in k8085 in walk in build-node-graph in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_8101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8101,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8126,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:581: g1198 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4930 in for-each-loop50 in k4915 in k4903 in a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4932,2,av);}
/* support.scm:70: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4965 in dump in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4967,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:62: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(124);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* loop in posv in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_5374(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_5374,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_eqvp(((C_word*)t0)[2],t4))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:160: loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* for-each-loop50 in k4915 in k4903 in a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_4937(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,2)))){
C_save_and_reclaim_args((void *)trf_4937,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4947,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=*((C_word*)lf[16]+1);
t7=*((C_word*)lf[16]+1);
t8=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4925,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4932,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm:70: force */
t11=*((C_word*)lf[20]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t10;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10255 in walk in k9872 in copy-node-tree-and-rename in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_10257,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[161]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10272,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10274,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10274(t13,t9,((C_word*)t0)[4]);}

/* k4945 in for-each-loop50 in k4915 in k4903 in a4900 in text in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4947,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4937(t3,((C_word*)t0)[4],t2);}

/* k13927 in k13899 in k13783 in finish-foreign-result in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(60,c,1)))){
C_save_and_reclaim((void *)f_13929,2,av);}
a=C_alloc(60);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[455],t1);
t5=C_a_i_list(&a,2,lf[456],t4);
t6=C_i_caddr(((C_word*)t0)[3]);
t7=C_a_i_list(&a,2,lf[97],lf[390]);
t8=C_a_i_list(&a,4,lf[457],t6,t7,t1);
t9=C_a_i_list(&a,4,lf[458],t1,t5,t8);
t10=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* a13341 in estimate-foreign-result-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_13342,2,av);}
/* support.scm:1203: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[443];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#estimate-foreign-result-location-size in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_13348(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_13348,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13360,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13775,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1208: follow-without-loop */
t5=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k4968 in k4965 in dump in debugging in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_4970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4970,2,av);}
/* support.scm:62: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6890 in k6875 in k6872 in k6869 in k6866 in a6857 in k6851 in display-analysis-database in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_6892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6892,2,av);}
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:496: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10595 in walk in sexpr->node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_ccall f_10597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_10597,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2163 in walk in sexpr->node in k7502 in k6122 in k6119 in k4868 in k4834 in k4831 in k4828 */
static void C_fcall f_10599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10599,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10624,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:782: g2169 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[761] = {
{"f_4985:support_2escm",(void*)f_4985},
{"f_4982:support_2escm",(void*)f_4982},
{"f_11991:support_2escm",(void*)f_11991},
{"f_4979:support_2escm",(void*)f_4979},
{"f_11994:support_2escm",(void*)f_11994},
{"f_12059:support_2escm",(void*)f_12059},
{"f_4892:support_2escm",(void*)f_4892},
{"f_4890:support_2escm",(void*)f_4890},
{"f_4895:support_2escm",(void*)f_4895},
{"f_8126:support_2escm",(void*)f_8126},
{"f_4988:support_2escm",(void*)f_4988},
{"f_11696:support_2escm",(void*)f_11696},
{"f_10482:support_2escm",(void*)f_10482},
{"f_11693:support_2escm",(void*)f_11693},
{"f_11690:support_2escm",(void*)f_11690},
{"f_8186:support_2escm",(void*)f_8186},
{"f_8188:support_2escm",(void*)f_8188},
{"f_12175:support_2escm",(void*)f_12175},
{"f_9759:support_2escm",(void*)f_9759},
{"f_9726:support_2escm",(void*)f_9726},
{"f_9720:support_2escm",(void*)f_9720},
{"f_15334:support_2escm",(void*)f_15334},
{"f_10238:support_2escm",(void*)f_10238},
{"f_4840:support_2escm",(void*)f_4840},
{"f_9738:support_2escm",(void*)f_9738},
{"f_4845:support_2escm",(void*)f_4845},
{"f_9733:support_2escm",(void*)f_9733},
{"f_9730:support_2escm",(void*)f_9730},
{"f_15428:support_2escm",(void*)f_15428},
{"f_12157:support_2escm",(void*)f_12157},
{"f_10437:support_2escm",(void*)f_10437},
{"f_15352:support_2escm",(void*)f_15352},
{"f_4859:support_2escm",(void*)f_4859},
{"f_15359:support_2escm",(void*)f_15359},
{"f_15431:support_2escm",(void*)f_15431},
{"f_12953:support_2escm",(void*)f_12953},
{"f_4925:support_2escm",(void*)f_4925},
{"f_4917:support_2escm",(void*)f_4917},
{"f_12965:support_2escm",(void*)f_12965},
{"f_9763:support_2escm",(void*)f_9763},
{"f_4873:support_2escm",(void*)f_4873},
{"f_4870:support_2escm",(void*)f_4870},
{"f_15451:support_2escm",(void*)f_15451},
{"f_15454:support_2escm",(void*)f_15454},
{"f_12932:support_2escm",(void*)f_12932},
{"f_4901:support_2escm",(void*)f_4901},
{"f_11732:support_2escm",(void*)f_11732},
{"f_11738:support_2escm",(void*)f_11738},
{"f_12941:support_2escm",(void*)f_12941},
{"f_10476:support_2escm",(void*)f_10476},
{"f_11726:support_2escm",(void*)f_11726},
{"f_11720:support_2escm",(void*)f_11720},
{"f_11729:support_2escm",(void*)f_11729},
{"f_4905:support_2escm",(void*)f_4905},
{"f_4908:support_2escm",(void*)f_4908},
{"f_15320:support_2escm",(void*)f_15320},
{"f_15324:support_2escm",(void*)f_15324},
{"f_11758:support_2escm",(void*)f_11758},
{"f_11750:support_2escm",(void*)f_11750},
{"f_11753:support_2escm",(void*)f_11753},
{"f_14248:support_2escm",(void*)f_14248},
{"f_11741:support_2escm",(void*)f_11741},
{"f_11744:support_2escm",(void*)f_11744},
{"f_12086:support_2escm",(void*)f_12086},
{"f_14227:support_2escm",(void*)f_14227},
{"f_11779:support_2escm",(void*)f_11779},
{"f_6044:support_2escm",(void*)f_6044},
{"f_6046:support_2escm",(void*)f_6046},
{"f_11773:support_2escm",(void*)f_11773},
{"f_5714:support_2escm",(void*)f_5714},
{"f_9708:support_2escm",(void*)f_9708},
{"f_7777:support_2escm",(void*)f_7777},
{"f_7775:support_2escm",(void*)f_7775},
{"f_11765:support_2escm",(void*)f_11765},
{"f_11762:support_2escm",(void*)f_11762},
{"f_5702:support_2escm",(void*)f_5702},
{"f_12160:support_2escm",(void*)f_12160},
{"f_9714:support_2escm",(void*)f_9714},
{"f_11790:support_2escm",(void*)f_11790},
{"f_5733:support_2escm",(void*)f_5733},
{"f_6559:support_2escm",(void*)f_6559},
{"f_6551:support_2escm",(void*)f_6551},
{"f_6052:support_2escm",(void*)f_6052},
{"f_9012:support_2escm",(void*)f_9012},
{"f_9010:support_2escm",(void*)f_9010},
{"f_12320:support_2escm",(void*)f_12320},
{"f_6547:support_2escm",(void*)f_6547},
{"f_6006:support_2escm",(void*)f_6006},
{"f_6533:support_2escm",(void*)f_6533},
{"f_5759:support_2escm",(void*)f_5759},
{"f_5745:support_2escm",(void*)f_5745},
{"f17649:support_2escm",(void*)f17649},
{"f_6529:support_2escm",(void*)f_6529},
{"f_7149:support_2escm",(void*)f_7149},
{"f_9002:support_2escm",(void*)f_9002},
{"f_9006:support_2escm",(void*)f_9006},
{"f_6516:support_2escm",(void*)f_6516},
{"f_6506:support_2escm",(void*)f_6506},
{"f_9060:support_2escm",(void*)f_9060},
{"f_7155:support_2escm",(void*)f_7155},
{"f_9783:support_2escm",(void*)f_9783},
{"f_7158:support_2escm",(void*)f_7158},
{"f_4991:support_2escm",(void*)f_4991},
{"f_4994:support_2escm",(void*)f_4994},
{"f_11714:support_2escm",(void*)f_11714},
{"f_11717:support_2escm",(void*)f_11717},
{"f_11705:support_2escm",(void*)f_11705},
{"f_11702:support_2escm",(void*)f_11702},
{"f_11708:support_2escm",(void*)f_11708},
{"f_15300:support_2escm",(void*)f_15300},
{"f_16156:support_2escm",(void*)f_16156},
{"f_7161:support_2escm",(void*)f_7161},
{"f_16152:support_2escm",(void*)f_16152},
{"f_9085:support_2escm",(void*)f_9085},
{"f_10165:support_2escm",(void*)f_10165},
{"f_10163:support_2escm",(void*)f_10163},
{"f_16124:support_2escm",(void*)f_16124},
{"f_6092:support_2escm",(void*)f_6092},
{"f_15413:support_2escm",(void*)f_15413},
{"f_16196:support_2escm",(void*)f_16196},
{"f_6076:support_2escm",(void*)f_6076},
{"f_16141:support_2escm",(void*)f_16141},
{"f_10447:support_2escm",(void*)f_10447},
{"f_6565:support_2escm",(void*)f_6565},
{"f_10441:support_2escm",(void*)f_10441},
{"f_10444:support_2escm",(void*)f_10444},
{"f_6569:support_2escm",(void*)f_6569},
{"f_16130:support_2escm",(void*)f_16130},
{"f_15389:support_2escm",(void*)f_15389},
{"f_14619:support_2escm",(void*)f_14619},
{"f_14615:support_2escm",(void*)f_14615},
{"f_14671:support_2escm",(void*)f_14671},
{"f_9529:support_2escm",(void*)f_9529},
{"f_6012:support_2escm",(void*)f_6012},
{"f_14661:support_2escm",(void*)f_14661},
{"f_10757:support_2escm",(void*)f_10757},
{"f_15493:support_2escm",(void*)f_15493},
{"f_10750:support_2escm",(void*)f_10750},
{"f_5761:support_2escm",(void*)f_5761},
{"f_15499:support_2escm",(void*)f_15499},
{"f_14653:support_2escm",(void*)f_14653},
{"f_10723:support_2escm",(void*)f_10723},
{"f_9580:support_2escm",(void*)f_9580},
{"f_6961:support_2escm",(void*)f_6961},
{"f_15067:support_2escm",(void*)f_15067},
{"f_10733:support_2escm",(void*)f_10733},
{"f_5787:support_2escm",(void*)f_5787},
{"f_9553:support_2escm",(void*)f_9553},
{"f_6955:support_2escm",(void*)f_6955},
{"f_9555:support_2escm",(void*)f_9555},
{"f_10700:support_2escm",(void*)f_10700},
{"f_6027:support_2escm",(void*)f_6027},
{"f_10709:support_2escm",(void*)f_10709},
{"f_10704:support_2escm",(void*)f_10704},
{"f_15088:support_2escm",(void*)f_15088},
{"f_5266:support_2escm",(void*)f_5266},
{"f_5269:support_2escm",(void*)f_5269},
{"f_5254:support_2escm",(void*)f_5254},
{"f_6924:support_2escm",(void*)f_6924},
{"f_5258:support_2escm",(void*)f_5258},
{"f_16109:support_2escm",(void*)f_16109},
{"f_15027:support_2escm",(void*)f_15027},
{"f_6918:support_2escm",(void*)f_6918},
{"f_8628:support_2escm",(void*)f_8628},
{"f_15073:support_2escm",(void*)f_15073},
{"f_10748:support_2escm",(void*)f_10748},
{"f_15079:support_2escm",(void*)f_15079},
{"f_8614:support_2escm",(void*)f_8614},
{"f_5231:support_2escm",(void*)f_5231},
{"f_9504:support_2escm",(void*)f_9504},
{"f_9502:support_2escm",(void*)f_9502},
{"f_14053:support_2escm",(void*)f_14053},
{"f_14621:support_2escm",(void*)f_14621},
{"f_16168:support_2escm",(void*)f_16168},
{"f_10718:support_2escm",(void*)f_10718},
{"f_10715:support_2escm",(void*)f_10715},
{"f_12285:support_2escm",(void*)f_12285},
{"f_12282:support_2escm",(void*)f_12282},
{"f_16162:support_2escm",(void*)f_16162},
{"f_8458:support_2escm",(void*)f_8458},
{"f_9543:support_2escm",(void*)f_9543},
{"f_16184:support_2escm",(void*)f_16184},
{"f_8431:support_2escm",(void*)f_8431},
{"f_8433:support_2escm",(void*)f_8433},
{"f_16180:support_2escm",(void*)f_16180},
{"f_14077:support_2escm",(void*)f_14077},
{"f_6908:support_2escm",(void*)f_6908},
{"f_8604:support_2escm",(void*)f_8604},
{"f_8600:support_2escm",(void*)f_8600},
{"f_8496:support_2escm",(void*)f_8496},
{"f_8494:support_2escm",(void*)f_8494},
{"f_8607:support_2escm",(void*)f_8607},
{"f_11222:support_2escm",(void*)f_11222},
{"f_14685:support_2escm",(void*)f_14685},
{"f_11214:support_2escm",(void*)f_11214},
{"f_8213:support_2escm",(void*)f_8213},
{"f_15010:support_2escm",(void*)f_15010},
{"f_8405:support_2escm",(void*)f_8405},
{"f_5290:support_2escm",(void*)f_5290},
{"f_5281:support_2escm",(void*)f_5281},
{"f_10781:support_2escm",(void*)f_10781},
{"f_15036:support_2escm",(void*)f_15036},
{"f_5277:support_2escm",(void*)f_5277},
{"f_15000:support_2escm",(void*)f_15000},
{"f_14971:support_2escm",(void*)f_14971},
{"f_6992:support_2escm",(void*)f_6992},
{"f_6998:support_2escm",(void*)f_6998},
{"f_10393:support_2escm",(void*)f_10393},
{"f_10399:support_2escm",(void*)f_10399},
{"f_11200:support_2escm",(void*)f_11200},
{"f_9658:support_2escm",(void*)f_9658},
{"f_8297:support_2escm",(void*)f_8297},
{"f_8299:support_2escm",(void*)f_8299},
{"f_5222:support_2escm",(void*)f_5222},
{"f_5225:support_2escm",(void*)f_5225},
{"f_10375:support_2escm",(void*)f_10375},
{"f_9664:support_2escm",(void*)f_9664},
{"f_10389:support_2escm",(void*)f_10389},
{"f_15505:support_2escm",(void*)f_15505},
{"f_5202:support_2escm",(void*)f_5202},
{"f_5205:support_2escm",(void*)f_5205},
{"f_15513:support_2escm",(void*)f_15513},
{"f_15515:support_2escm",(void*)f_15515},
{"f_14995:support_2escm",(void*)f_14995},
{"f_11404:support_2escm",(void*)f_11404},
{"f_15521:support_2escm",(void*)f_15521},
{"f_15527:support_2escm",(void*)f_15527},
{"f_14288:support_2escm",(void*)f_14288},
{"f_11437:support_2escm",(void*)f_11437},
{"f_14981:support_2escm",(void*)f_14981},
{"f_11439:support_2escm",(void*)f_11439},
{"f_14266:support_2escm",(void*)f_14266},
{"f_11414:support_2escm",(void*)f_11414},
{"f_11411:support_2escm",(void*)f_11411},
{"f_5609:support_2escm",(void*)f_5609},
{"f_10321:support_2escm",(void*)f_10321},
{"f_6134:support_2escm",(void*)f_6134},
{"f_11445:support_2escm",(void*)f_11445},
{"f_11476:support_2escm",(void*)f_11476},
{"f_11474:support_2escm",(void*)f_11474},
{"f_8755:support_2escm",(void*)f_8755},
{"f_11455:support_2escm",(void*)f_11455},
{"f_11452:support_2escm",(void*)f_11452},
{"f_11148:support_2escm",(void*)f_11148},
{"f_8730:support_2escm",(void*)f_8730},
{"f_11142:support_2escm",(void*)f_11142},
{"f_14913:support_2escm",(void*)f_14913},
{"f_9234:support_2escm",(void*)f_9234},
{"f_7981:support_2escm",(void*)f_7981},
{"f_14901:support_2escm",(void*)f_14901},
{"f_6167:support_2escm",(void*)f_6167},
{"f_6165:support_2escm",(void*)f_6165},
{"f_5629:support_2escm",(void*)f_5629},
{"f_5625:support_2escm",(void*)f_5625},
{"f_9207:support_2escm",(void*)f_9207},
{"f_8728:support_2escm",(void*)f_8728},
{"f_10299:support_2escm",(void*)f_10299},
{"f_6157:support_2escm",(void*)f_6157},
{"f_6154:support_2escm",(void*)f_6154},
{"f_7960:support_2escm",(void*)f_7960},
{"f_10262:support_2escm",(void*)f_10262},
{"f_6140:support_2escm",(void*)f_6140},
{"f_6146:support_2escm",(void*)f_6146},
{"f_15702:support_2escm",(void*)f_15702},
{"f_15704:support_2escm",(void*)f_15704},
{"f_15800:support_2escm",(void*)f_15800},
{"f_8772:support_2escm",(void*)f_8772},
{"f_15803:support_2escm",(void*)f_15803},
{"f_15806:support_2escm",(void*)f_15806},
{"f_15710:support_2escm",(void*)f_15710},
{"f_15714:support_2escm",(void*)f_15714},
{"f_15719:support_2escm",(void*)f_15719},
{"f_15827:support_2escm",(void*)f_15827},
{"f_15824:support_2escm",(void*)f_15824},
{"f_7612:support_2escm",(void*)f_7612},
{"f_8769:support_2escm",(void*)f_8769},
{"f_7614:support_2escm",(void*)f_7614},
{"f_7059:support_2escm",(void*)f_7059},
{"f_5650:support_2escm",(void*)f_5650},
{"f_9259:support_2escm",(void*)f_9259},
{"f_7046:support_2escm",(void*)f_7046},
{"f_9222:support_2escm",(void*)f_9222},
{"f_9690:support_2escm",(void*)f_9690},
{"f_9694:support_2escm",(void*)f_9694},
{"f_10274:support_2escm",(void*)f_10274},
{"f_10272:support_2escm",(void*)f_10272},
{"f_7906:support_2escm",(void*)f_7906},
{"f_15811:support_2escm",(void*)f_15811},
{"f_15539:support_2escm",(void*)f_15539},
{"f_15533:support_2escm",(void*)f_15533},
{"f_9284:support_2escm",(void*)f_9284},
{"f_7937:support_2escm",(void*)f_7937},
{"f_16054:support_2escm",(void*)f_16054},
{"f_15771:support_2escm",(void*)f_15771},
{"f_15772:support_2escm",(void*)f_15772},
{"f_15788:support_2escm",(void*)f_15788},
{"f_15782:support_2escm",(void*)f_15782},
{"f_15889:support_2escm",(void*)f_15889},
{"f_7675:support_2escm",(void*)f_7675},
{"f_14959:support_2escm",(void*)f_14959},
{"f_14957:support_2escm",(void*)f_14957},
{"f_16074:support_2escm",(void*)f_16074},
{"f_15561:support_2escm",(void*)f_15561},
{"f_15563:support_2escm",(void*)f_15563},
{"f_11277:support_2escm",(void*)f_11277},
{"f_7665:support_2escm",(void*)f_7665},
{"f_7668:support_2escm",(void*)f_7668},
{"f_10005:support_2escm",(void*)f_10005},
{"f_6199:support_2escm",(void*)f_6199},
{"f_6193:support_2escm",(void*)f_6193},
{"f_16010:support_2escm",(void*)f_16010},
{"f_15871:support_2escm",(void*)f_15871},
{"f_15874:support_2escm",(void*)f_15874},
{"f_10025:support_2escm",(void*)f_10025},
{"f_16084:support_2escm",(void*)f_16084},
{"f_16088:support_2escm",(void*)f_16088},
{"f_15747:support_2escm",(void*)f_15747},
{"f_15597:support_2escm",(void*)f_15597},
{"f_16082:support_2escm",(void*)f_16082},
{"f_10369:support_2escm",(void*)f_10369},
{"f_7639:support_2escm",(void*)f_7639},
{"f_15844:support_2escm",(void*)f_15844},
{"f_15759:support_2escm",(void*)f_15759},
{"f_11482:support_2escm",(void*)f_11482},
{"f_15756:support_2escm",(void*)f_15756},
{"f_15893:support_2escm",(void*)f_15893},
{"f_15768:support_2escm",(void*)f_15768},
{"f_15765:support_2escm",(void*)f_15765},
{"f_15762:support_2escm",(void*)f_15762},
{"f_15867:support_2escm",(void*)f_15867},
{"f_10053:support_2escm",(void*)f_10053},
{"f_10048:support_2escm",(void*)f_10048},
{"f_8780:support_2escm",(void*)f_8780},
{"f_8786:support_2escm",(void*)f_8786},
{"f_12356:support_2escm",(void*)f_12356},
{"f_11495:support_2escm",(void*)f_11495},
{"f_7545:support_2escm",(void*)f_7545},
{"f_7542:support_2escm",(void*)f_7542},
{"f_10057:support_2escm",(void*)f_10057},
{"f_14882:support_2escm",(void*)f_14882},
{"f_5682:support_2escm",(void*)f_5682},
{"f_5689:support_2escm",(void*)f_5689},
{"f_9469:support_2escm",(void*)f_9469},
{"f_5673:support_2escm",(void*)f_5673},
{"f_5675:support_2escm",(void*)f_5675},
{"f_9431:support_2escm",(void*)f_9431},
{"f_15854:support_2escm",(void*)f_15854},
{"f_6125:support_2escm",(void*)f_6125},
{"f_6124:support_2escm",(void*)f_6124},
{"f_6121:support_2escm",(void*)f_6121},
{"f_7527:support_2escm",(void*)f_7527},
{"f_6129:support_2escm",(void*)f_6129},
{"f_15144:support_2escm",(void*)f_15144},
{"f_15147:support_2escm",(void*)f_15147},
{"f_9442:support_2escm",(void*)f_9442},
{"f_9444:support_2escm",(void*)f_9444},
{"f_15096:support_2escm",(void*)f_15096},
{"f_7512:support_2escm",(void*)f_7512},
{"f_12009:support_2escm",(void*)f_12009},
{"f_6102:support_2escm",(void*)f_6102},
{"f_7504:support_2escm",(void*)f_7504},
{"f_6107:support_2escm",(void*)f_6107},
{"f_7506:support_2escm",(void*)f_7506},
{"f_6171:support_2escm",(void*)f_6171},
{"f_15137:support_2escm",(void*)f_15137},
{"f_14871:support_2escm",(void*)f_14871},
{"f_6231:support_2escm",(void*)f_6231},
{"f_6237:support_2escm",(void*)f_6237},
{"f_11886:support_2escm",(void*)f_11886},
{"f_12033:support_2escm",(void*)f_12033},
{"f_6225:support_2escm",(void*)f_6225},
{"f_6228:support_2escm",(void*)f_6228},
{"f_15151:support_2escm",(void*)f_15151},
{"f_15157:support_2escm",(void*)f_15157},
{"f_6214:support_2escm",(void*)f_6214},
{"f_6332:support_2escm",(void*)f_6332},
{"f_6336:support_2escm",(void*)f_6336},
{"f_15122:support_2escm",(void*)f_15122},
{"f_15126:support_2escm",(void*)f_15126},
{"f_14807:support_2escm",(void*)f_14807},
{"f_6207:support_2escm",(void*)f_6207},
{"f_6208:support_2escm",(void*)f_6208},
{"f_6279:support_2escm",(void*)f_6279},
{"f_6275:support_2escm",(void*)f_6275},
{"f_6385:support_2escm",(void*)f_6385},
{"f_9413:support_2escm",(void*)f_9413},
{"f_11822:support_2escm",(void*)f_11822},
{"f_11828:support_2escm",(void*)f_11828},
{"f_14152:support_2escm",(void*)f_14152},
{"f_9424:support_2escm",(void*)f_9424},
{"f_7076:support_2escm",(void*)f_7076},
{"f_11816:support_2escm",(void*)f_11816},
{"f_7070:support_2escm",(void*)f_7070},
{"f_16034:support_2escm",(void*)f_16034},
{"f_11174:support_2escm",(void*)f_11174},
{"f_11800:support_2escm",(void*)f_11800},
{"f_11168:support_2escm",(void*)f_11168},
{"f_14826:support_2escm",(void*)f_14826},
{"f_13775:support_2escm",(void*)f_13775},
{"f_13370:support_2escm",(void*)f_13370},
{"f_13382:support_2escm",(void*)f_13382},
{"f_13388:support_2escm",(void*)f_13388},
{"f_15118:support_2escm",(void*)f_15118},
{"f_15111:support_2escm",(void*)f_15111},
{"f_15114:support_2escm",(void*)f_15114},
{"f_16005:support_2escm",(void*)f_16005},
{"f_13360:support_2escm",(void*)f_13360},
{"f_11027:support_2escm",(void*)f_11027},
{"f_11010:support_2escm",(void*)f_11010},
{"f_13392:support_2escm",(void*)f_13392},
{"f_14836:support_2escm",(void*)f_14836},
{"f_14832:support_2escm",(void*)f_14832},
{"f_14862:support_2escm",(void*)f_14862},
{"f_11049:support_2escm",(void*)f_11049},
{"f_15190:support_2escm",(void*)f_15190},
{"f_15192:support_2escm",(void*)f_15192},
{"f_15163:support_2escm",(void*)f_15163},
{"f_6356:support_2escm",(void*)f_6356},
{"f_15105:support_2escm",(void*)f_15105},
{"f_15108:support_2escm",(void*)f_15108},
{"f_15102:support_2escm",(void*)f_15102},
{"f_10672:support_2escm",(void*)f_10672},
{"f_11868:support_2escm",(void*)f_11868},
{"f_11853:support_2escm",(void*)f_11853},
{"f_9933:support_2escm",(void*)f_9933},
{"f_9943:support_2escm",(void*)f_9943},
{"f_9341:support_2escm",(void*)f_9341},
{"f_9940:support_2escm",(void*)f_9940},
{"f_6778:support_2escm",(void*)f_6778},
{"f_5113:support_2escm",(void*)f_5113},
{"f_9314:support_2escm",(void*)f_9314},
{"f_5116:support_2escm",(void*)f_5116},
{"f_9316:support_2escm",(void*)f_9316},
{"f_9996:support_2escm",(void*)f_9996},
{"f_9999:support_2escm",(void*)f_9999},
{"f_5100:support_2escm",(void*)f_5100},
{"f_6611:support_2escm",(void*)f_6611},
{"f_5109:support_2escm",(void*)f_5109},
{"f_5107:support_2escm",(void*)f_5107},
{"f_6615:support_2escm",(void*)f_6615},
{"f_5133:support_2escm",(void*)f_5133},
{"f_5132:support_2escm",(void*)f_5132},
{"f_13781:support_2escm",(void*)f_13781},
{"f_9372:support_2escm",(void*)f_9372},
{"f_9972:support_2escm",(void*)f_9972},
{"f_5129:support_2escm",(void*)f_5129},
{"f_5123:support_2escm",(void*)f_5123},
{"f_5125:support_2escm",(void*)f_5125},
{"f_9980:support_2escm",(void*)f_9980},
{"f_9386:support_2escm",(void*)f_9386},
{"toplevel:support_2escm",(void*)C_support_toplevel},
{"f_13785:support_2escm",(void*)f_13785},
{"f_5059:support_2escm",(void*)f_5059},
{"f_5044:support_2escm",(void*)f_5044},
{"f_5049:support_2escm",(void*)f_5049},
{"f_6718:support_2escm",(void*)f_6718},
{"f_5030:support_2escm",(void*)f_5030},
{"f_6747:support_2escm",(void*)f_6747},
{"f_10624:support_2escm",(void*)f_10624},
{"f_6744:support_2escm",(void*)f_6744},
{"f_16300:support_2escm",(void*)f_16300},
{"f_5190:support_2escm",(void*)f_5190},
{"f_6727:support_2escm",(void*)f_6727},
{"f_6722:support_2escm",(void*)f_6722},
{"f_5516:support_2escm",(void*)f_5516},
{"f_5199:support_2escm",(void*)f_5199},
{"f_5187:support_2escm",(void*)f_5187},
{"f_5184:support_2escm",(void*)f_5184},
{"f_5181:support_2escm",(void*)f_5181},
{"f_8820:support_2escm",(void*)f_8820},
{"f_6751:support_2escm",(void*)f_6751},
{"f_11098:support_2escm",(void*)f_11098},
{"f_16309:support_2escm",(void*)f_16309},
{"f_16306:support_2escm",(void*)f_16306},
{"f_16303:support_2escm",(void*)f_16303},
{"f_7872:support_2escm",(void*)f_7872},
{"f_6737:support_2escm",(void*)f_6737},
{"f_12113:support_2escm",(void*)f_12113},
{"f_12116:support_2escm",(void*)f_12116},
{"f_8833:support_2escm",(void*)f_8833},
{"f_8835:support_2escm",(void*)f_8835},
{"f_8860:support_2escm",(void*)f_8860},
{"f_7811:support_2escm",(void*)f_7811},
{"f_5178:support_2escm",(void*)f_5178},
{"f_8890:support_2escm",(void*)f_8890},
{"f_8892:support_2escm",(void*)f_8892},
{"f_5575:support_2escm",(void*)f_5575},
{"f_5579:support_2escm",(void*)f_5579},
{"f_7836:support_2escm",(void*)f_7836},
{"f_5568:support_2escm",(void*)f_5568},
{"f_15631:support_2escm",(void*)f_15631},
{"f_5528:support_2escm",(void*)f_5528},
{"f_15645:support_2escm",(void*)f_15645},
{"f_15926:support_2escm",(void*)f_15926},
{"f_15929:support_2escm",(void*)f_15929},
{"f_11067:support_2escm",(void*)f_11067},
{"f_15971:support_2escm",(void*)f_15971},
{"f_5546:support_2escm",(void*)f_5546},
{"f_7494:support_2escm",(void*)f_7494},
{"f_5544:support_2escm",(void*)f_5544},
{"f_5540:support_2escm",(void*)f_5540},
{"f_7802:support_2escm",(void*)f_7802},
{"f_15941:support_2escm",(void*)f_15941},
{"f_15945:support_2escm",(void*)f_15945},
{"f_7485:support_2escm",(void*)f_7485},
{"f_15916:support_2escm",(void*)f_15916},
{"f_15910:support_2escm",(void*)f_15910},
{"f_10637:support_2escm",(void*)f_10637},
{"f_10633:support_2escm",(void*)f_10633},
{"f_5091:support_2escm",(void*)f_5091},
{"f_9390:support_2escm",(void*)f_9390},
{"f_10646:support_2escm",(void*)f_10646},
{"f_5085:support_2escm",(void*)f_5085},
{"f_10640:support_2escm",(void*)f_10640},
{"f_5082:support_2escm",(void*)f_5082},
{"f_5079:support_2escm",(void*)f_5079},
{"f_5076:support_2escm",(void*)f_5076},
{"f_10654:support_2escm",(void*)f_10654},
{"f_7458:support_2escm",(void*)f_7458},
{"f_15982:support_2escm",(void*)f_15982},
{"f_6784:support_2escm",(void*)f_6784},
{"f_10662:support_2escm",(void*)f_10662},
{"f_7449:support_2escm",(void*)f_7449},
{"f_7443:support_2escm",(void*)f_7443},
{"f_6670:support_2escm",(void*)f_6670},
{"f_15950:support_2escm",(void*)f_15950},
{"f_15954:support_2escm",(void*)f_15954},
{"f_6663:support_2escm",(void*)f_6663},
{"f_6667:support_2escm",(void*)f_6667},
{"f_5151:support_2escm",(void*)f_5151},
{"f_10962:support_2escm",(void*)f_10962},
{"f_5143:support_2escm",(void*)f_5143},
{"f_5146:support_2escm",(void*)f_5146},
{"f_14735:support_2escm",(void*)f_14735},
{"f_6794:support_2escm",(void*)f_6794},
{"f_6797:support_2escm",(void*)f_6797},
{"f_15255:support_2escm",(void*)f_15255},
{"f_15259:support_2escm",(void*)f_15259},
{"f_5027:support_2escm",(void*)f_5027},
{"f_5024:support_2escm",(void*)f_5024},
{"f_10945:support_2escm",(void*)f_10945},
{"f_5161:support_2escm",(void*)f_5161},
{"f_14717:support_2escm",(void*)f_14717},
{"f_15997:support_2escm",(void*)f_15997},
{"f_15994:support_2escm",(void*)f_15994},
{"f_5010:support_2escm",(void*)f_5010},
{"f_5012:support_2escm",(void*)f_5012},
{"f_10142:support_2escm",(void*)f_10142},
{"f_5017:support_2escm",(void*)f_5017},
{"f_5015:support_2escm",(void*)f_5015},
{"f_10954:support_2escm",(void*)f_10954},
{"f_7435:support_2escm",(void*)f_7435},
{"f_7437:support_2escm",(void*)f_7437},
{"f_10951:support_2escm",(void*)f_10951},
{"f_5000:support_2escm",(void*)f_5000},
{"f_10150:support_2escm",(void*)f_10150},
{"f_11557:support_2escm",(void*)f_11557},
{"f_5003:support_2escm",(void*)f_5003},
{"f_11550:support_2escm",(void*)f_11550},
{"f_11555:support_2escm",(void*)f_11555},
{"f_14773:support_2escm",(void*)f_14773},
{"f_14770:support_2escm",(void*)f_14770},
{"f_11546:support_2escm",(void*)f_11546},
{"f_5583:support_2escm",(void*)f_5583},
{"f_15295:support_2escm",(void*)f_15295},
{"f_5589:support_2escm",(void*)f_5589},
{"f_15292:support_2escm",(void*)f_15292},
{"f_10934:support_2escm",(void*)f_10934},
{"f_5476:support_2escm",(void*)f_5476},
{"f_5474:support_2escm",(void*)f_5474},
{"f_10901:support_2escm",(void*)f_10901},
{"f_10907:support_2escm",(void*)f_10907},
{"f_15229:support_2escm",(void*)f_15229},
{"f_12840:support_2escm",(void*)f_12840},
{"f_10911:support_2escm",(void*)f_10911},
{"f_12853:support_2escm",(void*)f_12853},
{"f_15244:support_2escm",(void*)f_15244},
{"f_15248:support_2escm",(void*)f_15248},
{"f_5402:support_2escm",(void*)f_5402},
{"f_6493:support_2escm",(void*)f_6493},
{"f_12877:support_2escm",(void*)f_12877},
{"f_12871:support_2escm",(void*)f_12871},
{"f_11535:support_2escm",(void*)f_11535},
{"f_6483:support_2escm",(void*)f_6483},
{"f_11523:support_2escm",(void*)f_11523},
{"f_11525:support_2escm",(void*)f_11525},
{"f_5914:support_2escm",(void*)f_5914},
{"f_9113:support_2escm",(void*)f_9113},
{"f_8917:support_2escm",(void*)f_8917},
{"f_10123:support_2escm",(void*)f_10123},
{"f_14725:support_2escm",(void*)f_14725},
{"f_10134:support_2escm",(void*)f_10134},
{"f_5852:support_2escm",(void*)f_5852},
{"f_5850:support_2escm",(void*)f_5850},
{"f_5427:support_2escm",(void*)f_5427},
{"f_5421:support_2escm",(void*)f_5421},
{"f_7476:support_2escm",(void*)f_7476},
{"f_6433:support_2escm",(void*)f_6433},
{"f_5846:support_2escm",(void*)f_5846},
{"f_10060:support_2escm",(void*)f_10060},
{"f_5455:support_2escm",(void*)f_5455},
{"f_14049:support_2escm",(void*)f_14049},
{"f_7467:support_2escm",(void*)f_7467},
{"f_5832:support_2escm",(void*)f_5832},
{"f_5838:support_2escm",(void*)f_5838},
{"f_10066:support_2escm",(void*)f_10066},
{"f_10069:support_2escm",(void*)f_10069},
{"f_9137:support_2escm",(void*)f_9137},
{"f_5432:support_2escm",(void*)f_5432},
{"f_6404:support_2escm",(void*)f_6404},
{"f_5898:support_2escm",(void*)f_5898},
{"f_5990:support_2escm",(void*)f_5990},
{"f_10086:support_2escm",(void*)f_10086},
{"f_5886:support_2escm",(void*)f_5886},
{"f_13425:support_2escm",(void*)f_13425},
{"f_5988:support_2escm",(void*)f_5988},
{"f_15206:support_2escm",(void*)f_15206},
{"f_10098:support_2escm",(void*)f_10098},
{"f_10096:support_2escm",(void*)f_10096},
{"f_8993:support_2escm",(void*)f_8993},
{"f_8990:support_2escm",(void*)f_8990},
{"f_9171:support_2escm",(void*)f_9171},
{"f_16244:support_2escm",(void*)f_16244},
{"f_16248:support_2escm",(void*)f_16248},
{"f_9175:support_2escm",(void*)f_9175},
{"f_16241:support_2escm",(void*)f_16241},
{"f_9183:support_2escm",(void*)f_9183},
{"f_5944:support_2escm",(void*)f_5944},
{"f_5948:support_2escm",(void*)f_5948},
{"f_8023:support_2escm",(void*)f_8023},
{"f_16287:support_2escm",(void*)f_16287},
{"f_5822:support_2escm",(void*)f_5822},
{"f_16282:support_2escm",(void*)f_16282},
{"f_15264:support_2escm",(void*)f_15264},
{"f_8003:support_2escm",(void*)f_8003},
{"f_15268:support_2escm",(void*)f_15268},
{"f_16235:support_2escm",(void*)f_16235},
{"f_12809:support_2escm",(void*)f_12809},
{"f_16238:support_2escm",(void*)f_16238},
{"f_12803:support_2escm",(void*)f_12803},
{"f_16232:support_2escm",(void*)f_16232},
{"f_6470:support_2escm",(void*)f_6470},
{"f_15276:support_2escm",(void*)f_15276},
{"f_16226:support_2escm",(void*)f_16226},
{"f_5807:support_2escm",(void*)f_5807},
{"f_5801:support_2escm",(void*)f_5801},
{"f_6460:support_2escm",(void*)f_6460},
{"f_15282:support_2escm",(void*)f_15282},
{"f_8060:support_2escm",(void*)f_8060},
{"f_15289:support_2escm",(void*)f_15289},
{"f_16257:support_2escm",(void*)f_16257},
{"f_12822:support_2escm",(void*)f_12822},
{"f_16250:support_2escm",(void*)f_16250},
{"f_15216:support_2escm",(void*)f_15216},
{"f_8011:support_2escm",(void*)f_8011},
{"f_8015:support_2escm",(void*)f_8015},
{"f_9852:support_2escm",(void*)f_9852},
{"f_10988:support_2escm",(void*)f_10988},
{"f_8044:support_2escm",(void*)f_8044},
{"f_8048:support_2escm",(void*)f_8048},
{"f_10568:support_2escm",(void*)f_10568},
{"f_10562:support_2escm",(void*)f_10562},
{"f_11305:support_2escm",(void*)f_11305},
{"f_5484:support_2escm",(void*)f_5484},
{"f_5486:support_2escm",(void*)f_5486},
{"f_6853:support_2escm",(void*)f_6853},
{"f_10553:support_2escm",(void*)f_10553},
{"f_6858:support_2escm",(void*)f_6858},
{"f_12885:support_2escm",(void*)f_12885},
{"f_8087:support_2escm",(void*)f_8087},
{"f_10834:support_2escm",(void*)f_10834},
{"f_12881:support_2escm",(void*)f_12881},
{"f_5461:support_2escm",(void*)f_5461},
{"f_5466:support_2escm",(void*)f_5466},
{"f_5464:support_2escm",(void*)f_5464},
{"f_9827:support_2escm",(void*)f_9827},
{"f_11951:support_2escm",(void*)f_11951},
{"f_6880:support_2escm",(void*)f_6880},
{"f_5492:support_2escm",(void*)f_5492},
{"f_9874:support_2escm",(void*)f_9874},
{"f_9882:support_2escm",(void*)f_9882},
{"f_6868:support_2escm",(void*)f_6868},
{"f_8099:support_2escm",(void*)f_8099},
{"f_10860:support_2escm",(void*)f_10860},
{"f_6813:support_2escm",(void*)f_6813},
{"f_5334:support_2escm",(void*)f_5334},
{"f_6815:support_2escm",(void*)f_6815},
{"f_11636:support_2escm",(void*)f_11636},
{"f_6849:support_2escm",(void*)f_6849},
{"f_9861:support_2escm",(void*)f_9861},
{"f_5368:support_2escm",(void*)f_5368},
{"f_6874:support_2escm",(void*)f_6874},
{"f_6871:support_2escm",(void*)f_6871},
{"f_6877:support_2escm",(void*)f_6877},
{"f_12971:support_2escm",(void*)f_12971},
{"f_10895:support_2escm",(void*)f_10895},
{"f_10893:support_2escm",(void*)f_10893},
{"f_16211:support_2escm",(void*)f_16211},
{"f_12245:support_2escm",(void*)f_12245},
{"f_12249:support_2escm",(void*)f_12249},
{"f_8521:support_2escm",(void*)f_8521},
{"f_11936:support_2escm",(void*)f_11936},
{"f_11687:support_2escm",(void*)f_11687},
{"f_11684:support_2escm",(void*)f_11684},
{"f_9813:support_2escm",(void*)f_9813},
{"f_8589:support_2escm",(void*)f_8589},
{"f_12975:support_2escm",(void*)f_12975},
{"f_11678:support_2escm",(void*)f_11678},
{"f_11671:support_2escm",(void*)f_11671},
{"f_6800:support_2escm",(void*)f_6800},
{"f_11665:support_2escm",(void*)f_11665},
{"f_11659:support_2escm",(void*)f_11659},
{"f_7767:support_2escm",(void*)f_7767},
{"f_8564:support_2escm",(void*)f_8564},
{"f_8562:support_2escm",(void*)f_8562},
{"f_8368:support_2escm",(void*)f_8368},
{"f_5340:support_2escm",(void*)f_5340},
{"f_16279:support_2escm",(void*)f_16279},
{"f_16275:support_2escm",(void*)f_16275},
{"f_12922:support_2escm",(void*)f_12922},
{"f_16264:support_2escm",(void*)f_16264},
{"f_8324:support_2escm",(void*)f_8324},
{"f_12916:support_2escm",(void*)f_12916},
{"f_16293:support_2escm",(void*)f_16293},
{"f_10818:support_2escm",(void*)f_10818},
{"f_10815:support_2escm",(void*)f_10815},
{"f_16201:support_2escm",(void*)f_16201},
{"f_8384:support_2escm",(void*)f_8384},
{"f_11398:support_2escm",(void*)f_11398},
{"f_10526:support_2escm",(void*)f_10526},
{"f_10528:support_2escm",(void*)f_10528},
{"f_8364:support_2escm",(void*)f_8364},
{"f_7750:support_2escm",(void*)f_7750},
{"f_12202:support_2escm",(void*)f_12202},
{"f_12910:support_2escm",(void*)f_12910},
{"f_7745:support_2escm",(void*)f_7745},
{"f_7741:support_2escm",(void*)f_7741},
{"f_8539:support_2escm",(void*)f_8539},
{"f_13901:support_2escm",(void*)f_13901},
{"f_7738:support_2escm",(void*)f_7738},
{"f_8533:support_2escm",(void*)f_8533},
{"f_10213:support_2escm",(void*)f_10213},
{"f_4960:support_2escm",(void*)f_4960},
{"f_4830:support_2escm",(void*)f_4830},
{"f_4833:support_2escm",(void*)f_4833},
{"f_4836:support_2escm",(void*)f_4836},
{"f_8101:support_2escm",(void*)f_8101},
{"f_4932:support_2escm",(void*)f_4932},
{"f_4967:support_2escm",(void*)f_4967},
{"f_5374:support_2escm",(void*)f_5374},
{"f_4937:support_2escm",(void*)f_4937},
{"f_10257:support_2escm",(void*)f_10257},
{"f_4947:support_2escm",(void*)f_4947},
{"f_13929:support_2escm",(void*)f_13929},
{"f_13342:support_2escm",(void*)f_13342},
{"f_13348:support_2escm",(void*)f_13348},
{"f_4970:support_2escm",(void*)f_4970},
{"f_6892:support_2escm",(void*)f_6892},
{"f_10597:support_2escm",(void*)f_10597},
{"f_10599:support_2escm",(void*)f_10599},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		30
S|  sprintf		4
S|  fprintf		5
S|  printf		19
S|  for-each		15
o|eliminated procedure checks: 438 
o|specializations:
o|  1 (eqv? (not float) *)
o|  1 (zero? number)
o|  1 (length list)
o|  4 (= fixnum fixnum)
o|  1 (assq * (list-of pair))
o|  1 (current-output-port)
o|  1 (second (pair * pair))
o|  3 (first pair)
o|  5 (cddr (pair * pair))
o|  1 (caddr (pair * (pair * pair)))
o|  354 (eqv? * (not float))
o|  1 (##sys#call-with-values (procedure () *) *)
o|  1 (cadr (pair * pair))
o|  1 (current-input-port)
o|  5 (char=? char char)
o|  3 (memq * list)
o|  1 (>= fixnum fixnum)
o|  3 (< fixnum fixnum)
o|  2 (current-error-port)
o|  8 (##sys#check-list (or pair list) *)
o|  28 (##sys#check-output-port * * *)
o|  32 (cdr pair)
o|  28 (car pair)
(o e)|safe calls: 1528 
(o e)|assignments to immediate values: 3 
o|safe globals: (##compiler#bomb ##compiler#disabled-warnings ##compiler#debugging-chicken ##compiler#compiler-cleanup-hook constant25 constant22) 
o|Removed `not' forms: 7 
o|removed side-effect free assignment to unused variable: constant22 
o|inlining procedure: k4847 
o|inlining procedure: k4847 
o|inlining procedure: k4875 
o|inlining procedure: k4875 
o|inlining procedure: k4906 
o|inlining procedure: k4939 
o|contracted procedure: "(support.scm:69) g5158" 
o|propagated global variable: out6165 ##sys#standard-output 
o|substituted constant variable: a4921 
o|substituted constant variable: a4922 
o|inlining procedure: k4939 
o|inlining procedure: k4906 
o|propagated global variable: out7781 ##compiler#collected-debugging-output 
o|substituted constant variable: a4963 
o|substituted constant variable: a4964 
o|propagated global variable: out7781 ##compiler#collected-debugging-output 
o|inlining procedure: k4974 
o|inlining procedure: k4974 
o|propagated global variable: out114118 ##compiler#collected-debugging-output 
o|substituted constant variable: a5020 
o|substituted constant variable: a5021 
o|inlining procedure: k5035 
o|inlining procedure: k5035 
o|inlining procedure: k5051 
o|inlining procedure: k5051 
o|inlining procedure: k5071 
o|inlining procedure: k5071 
o|inlining procedure: k5153 
o|inlining procedure: k5153 
o|substituted constant variable: a5174 
o|substituted constant variable: a5175 
o|substituted constant variable: a5195 
o|substituted constant variable: a5196 
o|inlining procedure: k5233 
o|inlining procedure: k5233 
o|inlining procedure: k5292 
o|inlining procedure: k5292 
o|inlining procedure: k5313 
o|inlining procedure: k5313 
o|inlining procedure: k5342 
o|inlining procedure: k5342 
o|inlining procedure: k5376 
o|inlining procedure: k5376 
o|inlining procedure: k5404 
o|inlining procedure: k5404 
o|substituted constant variable: a5423 
o|substituted constant variable: a5424 
o|inlining procedure: k5434 
o|inlining procedure: k5434 
o|substituted constant variable: a5457 
o|substituted constant variable: a5458 
o|inlining procedure: k5494 
o|inlining procedure: k5494 
o|inlining procedure: k5548 
o|inlining procedure: k5548 
o|inlining procedure: k5593 
o|inlining procedure: k5593 
o|substituted constant variable: a5600 
o|substituted constant variable: a5602 
o|inlining procedure: k5615 
o|inlining procedure: k5615 
o|substituted constant variable: a5619 
o|substituted constant variable: a5621 
o|substituted constant variable: a5623 
o|inlining procedure: k5630 
o|inlining procedure: k5655 
o|inlining procedure: k5655 
o|substituted constant variable: a5664 
o|substituted constant variable: a5668 
o|inlining procedure: k5630 
o|inlining procedure: k5691 
o|propagated global variable: r569216385 ##sys#standard-input 
o|inlining procedure: k5691 
o|inlining procedure: k5706 
o|inlining procedure: k5706 
o|inlining procedure: k5735 
o|inlining procedure: k5735 
o|inlining procedure: k5747 
o|inlining procedure: k5747 
o|inlining procedure: k5767 
o|inlining procedure: k5767 
o|inlining procedure: k5809 
o|inlining procedure: k5809 
o|inlining procedure: k5857 
o|inlining procedure: k5857 
o|inlining procedure: k5869 
o|inlining procedure: k5869 
o|inlining procedure: k5881 
o|inlining procedure: k5881 
o|inlining procedure: k5893 
o|inlining procedure: k5893 
o|inlining procedure: k5902 
o|inlining procedure: k5902 
o|inlining procedure: k5919 
o|inlining procedure: k5919 
o|inlining procedure: k5931 
o|inlining procedure: k5931 
o|inlining procedure: k5949 
o|inlining procedure: k5949 
o|inlining procedure: k5961 
o|inlining procedure: k5961 
o|inlining procedure: k5973 
o|inlining procedure: k5973 
o|inlining procedure: k5995 
o|inlining procedure: k5995 
o|inlining procedure: k6007 
o|inlining procedure: k6007 
o|inlining procedure: k6016 
o|inlining procedure: k6016 
o|inlining procedure: k6054 
o|inlining procedure: k6054 
o|inlining procedure: k6067 
o|inlining procedure: k6067 
o|inlining procedure: k6108 
o|inlining procedure: k6108 
o|inlining procedure: k6152 
o|inlining procedure: k6152 
o|inlining procedure: k6172 
o|inlining procedure: k6172 
o|merged explicitly consed rest parameter: args485501 
o|consed rest parameter at call site: tmp24371 1 
o|inlining procedure: k6239 
o|inlining procedure: k6239 
o|inlining procedure: k6254 
o|inlining procedure: k6254 
o|inlining procedure: k6334 
o|inlining procedure: k6462 
o|contracted procedure: "(support.scm:368) g629636" 
o|contracted procedure: "(support.scm:370) g639640" 
o|inlining procedure: k6462 
o|propagated global variable: g635637 ##compiler#internal-bindings 
o|inlining procedure: k6485 
o|contracted procedure: "(support.scm:362) g582589" 
o|inlining procedure: k6405 
o|contracted procedure: "(support.scm:366) g606607" 
o|inlining procedure: k6405 
o|contracted procedure: "(support.scm:364) g592593" 
o|inlining procedure: k6485 
o|propagated global variable: g588590 extended-bindings 
o|inlining procedure: k6508 
o|contracted procedure: "(support.scm:356) g535542" 
o|inlining procedure: k6357 
o|contracted procedure: "(support.scm:360) g559560" 
o|inlining procedure: k6357 
o|contracted procedure: "(support.scm:358) g545546" 
o|inlining procedure: k6508 
o|propagated global variable: g541543 standard-bindings 
o|inlining procedure: k6334 
o|inlining procedure: k6534 
o|inlining procedure: k6534 
o|inlining procedure: k6552 
o|inlining procedure: k6552 
o|inlining procedure: k6570 
o|inlining procedure: k6582 
o|inlining procedure: k6582 
o|inlining procedure: k6570 
o|inlining procedure: k6616 
o|inlining procedure: k6616 
o|inlining procedure: k6671 
o|inlining procedure: k6671 
o|inlining procedure: k6723 
o|inlining procedure: k6723 
o|inlining procedure: k6748 
o|inlining procedure: k6748 
o|propagated global variable: out733737 ##sys#standard-output 
o|substituted constant variable: a6790 
o|substituted constant variable: a6791 
o|inlining procedure: k6786 
o|inlining procedure: k6817 
o|inlining procedure: k6817 
o|propagated global variable: out733737 ##sys#standard-output 
o|inlining procedure: k6786 
o|inlining procedure: k6860 
o|inlining procedure: k6860 
o|propagated global variable: out942946 ##sys#standard-output 
o|substituted constant variable: a6888 
o|substituted constant variable: a6889 
o|propagated global variable: out942946 ##sys#standard-output 
o|propagated global variable: out935939 ##sys#standard-output 
o|substituted constant variable: a6904 
o|substituted constant variable: a6905 
o|propagated global variable: out935939 ##sys#standard-output 
o|propagated global variable: out894898 ##sys#standard-output 
o|substituted constant variable: a6920 
o|substituted constant variable: a6921 
o|contracted procedure: "(support.scm:490) g902903" 
o|contracted procedure: "(support.scm:490) g899900" 
o|propagated global variable: out894898 ##sys#standard-output 
o|propagated global variable: out908912 ##sys#standard-output 
o|substituted constant variable: a6957 
o|substituted constant variable: a6958 
o|inlining procedure: k6950 
o|contracted procedure: "(support.scm:492) g916917" 
o|contracted procedure: "(support.scm:492) g913914" 
o|propagated global variable: out908912 ##sys#standard-output 
o|inlining procedure: k6950 
o|propagated global variable: out922926 ##sys#standard-output 
o|substituted constant variable: a6994 
o|substituted constant variable: a6995 
o|contracted procedure: "(support.scm:494) g930931" 
o|contracted procedure: "(support.scm:494) g927928" 
o|propagated global variable: out922926 ##sys#standard-output 
o|inlining procedure: k7048 
o|propagated global variable: out847851 ##sys#standard-output 
o|substituted constant variable: a7072 
o|substituted constant variable: a7073 
o|substituted constant variable: names769 
o|propagated global variable: out847851 ##sys#standard-output 
o|inlining procedure: k7092 
o|inlining procedure: k7092 
o|inlining procedure: k7105 
o|inlining procedure: k7105 
o|inlining procedure: k7115 
o|inlining procedure: k7115 
o|propagated global variable: out878882 ##sys#standard-output 
o|substituted constant variable: a7151 
o|substituted constant variable: a7152 
o|inlining procedure: k7141 
o|propagated global variable: out878882 ##sys#standard-output 
o|inlining procedure: k7141 
o|inlining procedure: k7183 
o|inlining procedure: k7183 
o|substituted constant variable: a7199 
o|substituted constant variable: a7201 
o|inlining procedure: k7205 
o|inlining procedure: k7205 
o|inlining procedure: k7217 
o|inlining procedure: k7217 
o|inlining procedure: k7229 
o|inlining procedure: k7229 
o|inlining procedure: k7241 
o|inlining procedure: k7241 
o|substituted constant variable: a7248 
o|substituted constant variable: a7250 
o|substituted constant variable: a7252 
o|substituted constant variable: a7254 
o|substituted constant variable: a7256 
o|substituted constant variable: a7258 
o|substituted constant variable: a7260 
o|substituted constant variable: a7262 
o|substituted constant variable: a7264 
o|substituted constant variable: a7266 
o|substituted constant variable: a7268 
o|substituted constant variable: a7270 
o|substituted constant variable: a7272 
o|inlining procedure: k7276 
o|inlining procedure: k7276 
o|inlining procedure: k7288 
o|inlining procedure: k7288 
o|inlining procedure: k7300 
o|inlining procedure: k7300 
o|inlining procedure: k7312 
o|inlining procedure: k7312 
o|inlining procedure: k7324 
o|inlining procedure: k7324 
o|inlining procedure: k7336 
o|inlining procedure: k7336 
o|inlining procedure: k7348 
o|inlining procedure: k7348 
o|inlining procedure: k7360 
o|inlining procedure: k7360 
o|inlining procedure: k7372 
o|inlining procedure: k7372 
o|inlining procedure: k7384 
o|inlining procedure: k7384 
o|substituted constant variable: a7391 
o|substituted constant variable: a7393 
o|substituted constant variable: a7395 
o|substituted constant variable: a7397 
o|substituted constant variable: a7399 
o|substituted constant variable: a7401 
o|substituted constant variable: a7403 
o|substituted constant variable: a7405 
o|substituted constant variable: a7407 
o|substituted constant variable: a7409 
o|substituted constant variable: a7411 
o|substituted constant variable: a7413 
o|substituted constant variable: a7415 
o|substituted constant variable: a7417 
o|substituted constant variable: a7419 
o|substituted constant variable: a7421 
o|substituted constant variable: a7423 
o|substituted constant variable: a7425 
o|substituted constant variable: a7427 
o|substituted constant variable: a7429 
o|substituted constant variable: a7431 
o|inlining procedure: k7048 
o|contracted procedure: "(support.scm:518) g10171018" 
o|contracted procedure: "(support.scm:519) g10241025" 
o|inlining procedure: k7547 
o|inlining procedure: k7547 
o|inlining procedure: k7567 
o|inlining procedure: k7567 
o|inlining procedure: k7583 
o|contracted procedure: "(support.scm:529) g10501051" 
o|inlining procedure: k7616 
o|inlining procedure: k7616 
o|inlining procedure: k7583 
o|inlining procedure: k7660 
o|inlining procedure: k7660 
o|inlining procedure: k7679 
o|inlining procedure: k7679 
o|inlining procedure: k7692 
o|contracted procedure: "(support.scm:545) g10871088" 
o|inlining procedure: k7779 
o|inlining procedure: k7779 
o|inlining procedure: k7813 
o|contracted procedure: "(support.scm:547) g11001109" 
o|inlining procedure: k7727 
o|inlining procedure: k7727 
o|inlining procedure: k7813 
o|inlining procedure: k7692 
o|contracted procedure: "(support.scm:554) g11491150" 
o|inlining procedure: k7881 
o|contracted procedure: "(support.scm:556) g11541155" 
o|inlining procedure: k7881 
o|inlining procedure: k7939 
o|contracted procedure: "(support.scm:563) g11671168" 
o|contracted procedure: "(support.scm:567) g11721173" 
o|inlining procedure: k7939 
o|contracted procedure: "(support.scm:569) g11771178" 
o|inlining procedure: k8065 
o|contracted procedure: "(support.scm:578) g11841185" 
o|inlining procedure: k8103 
o|inlining procedure: k8103 
o|inlining procedure: k8135 
o|inlining procedure: k8135 
o|inlining procedure: k8065 
o|contracted procedure: "(support.scm:583) g12191220" 
o|inlining procedure: k8190 
o|inlining procedure: k8190 
o|inlining procedure: k8225 
o|contracted procedure: "(support.scm:585) g12501251" 
o|inlining procedure: k8225 
o|contracted procedure: "(support.scm:587) g12551256" 
o|inlining procedure: k8265 
o|contracted procedure: "(support.scm:589) g12631264" 
o|inlining procedure: k8301 
o|inlining procedure: k8301 
o|inlining procedure: k8265 
o|contracted procedure: "(support.scm:594) g12951296" 
o|inlining procedure: k8397 
o|contracted procedure: "(support.scm:600) g13121313" 
o|inlining procedure: k8435 
o|inlining procedure: k8435 
o|inlining procedure: k8397 
o|contracted procedure: "(support.scm:602) g13431344" 
o|inlining procedure: k8498 
o|inlining procedure: k8498 
o|contracted procedure: "(support.scm:605) g13761377" 
o|inlining procedure: k8566 
o|inlining procedure: k8566 
o|inlining procedure: k8602 
o|inlining procedure: k8612 
o|inlining procedure: k8612 
o|inlining procedure: k8602 
o|contracted procedure: "(support.scm:607) g13851386" 
o|substituted constant variable: a8634 
o|inlining procedure: k8638 
o|inlining procedure: k8638 
o|inlining procedure: k8650 
o|inlining procedure: k8650 
o|substituted constant variable: a8657 
o|substituted constant variable: a8659 
o|substituted constant variable: a8661 
o|substituted constant variable: a8663 
o|substituted constant variable: a8665 
o|substituted constant variable: a8667 
o|substituted constant variable: a8672 
o|substituted constant variable: a8674 
o|substituted constant variable: a8676 
o|substituted constant variable: a8678 
o|substituted constant variable: a8683 
o|substituted constant variable: a8685 
o|substituted constant variable: a8687 
o|substituted constant variable: a8689 
o|substituted constant variable: a8691 
o|substituted constant variable: a8696 
o|substituted constant variable: a8698 
o|substituted constant variable: a8700 
o|substituted constant variable: a8702 
o|substituted constant variable: a8707 
o|substituted constant variable: a8709 
o|contracted procedure: "(support.scm:617) g14201421" 
o|inlining procedure: k8732 
o|inlining procedure: k8732 
o|contracted procedure: "(support.scm:525) g10381039" 
o|inlining procedure: k8770 
o|inlining procedure: k8770 
o|inlining procedure: k8812 
o|inlining procedure: k8837 
o|inlining procedure: k8837 
o|inlining procedure: k8812 
o|inlining procedure: k8894 
o|inlining procedure: k8894 
o|inlining procedure: k8925 
o|inlining procedure: k8925 
o|inlining procedure: k8943 
o|inlining procedure: k8943 
o|inlining procedure: k8960 
o|inlining procedure: k8960 
o|inlining procedure: k8972 
o|inlining procedure: k9014 
o|inlining procedure: k9014 
o|inlining procedure: k9062 
o|inlining procedure: k9062 
o|inlining procedure: k8972 
o|inlining procedure: k9121 
o|inlining procedure: k9121 
o|inlining procedure: k9155 
o|inlining procedure: k9185 
o|inlining procedure: k9185 
o|inlining procedure: k9155 
o|inlining procedure: k9261 
o|inlining procedure: k9261 
o|inlining procedure: k9292 
o|inlining procedure: k9318 
o|inlining procedure: k9318 
o|inlining procedure: k9292 
o|inlining procedure: k9358 
o|inlining procedure: k9374 
o|inlining procedure: k9374 
o|inlining procedure: k9358 
o|inlining procedure: k9446 
o|inlining procedure: k9446 
o|inlining procedure: k9481 
o|inlining procedure: k9506 
o|inlining procedure: k9506 
o|inlining procedure: k9481 
o|inlining procedure: k9557 
o|inlining procedure: k9557 
o|substituted constant variable: a9592 
o|substituted constant variable: a9594 
o|inlining procedure: k9598 
o|inlining procedure: k9598 
o|substituted constant variable: a9611 
o|substituted constant variable: a9613 
o|substituted constant variable: a9615 
o|substituted constant variable: a9617 
o|substituted constant variable: a9619 
o|substituted constant variable: a9621 
o|substituted constant variable: a9623 
o|substituted constant variable: a9625 
o|substituted constant variable: a9627 
o|substituted constant variable: a9629 
o|substituted constant variable: a9631 
o|substituted constant variable: a9633 
o|substituted constant variable: a9635 
o|substituted constant variable: a9637 
o|substituted constant variable: a9639 
o|substituted constant variable: a9641 
o|inlining procedure: k9645 
o|inlining procedure: k9645 
o|substituted constant variable: a9652 
o|substituted constant variable: a9654 
o|substituted constant variable: a9656 
o|contracted procedure: "(support.scm:627) g14671468" 
o|contracted procedure: "(support.scm:626) g14641465" 
o|contracted procedure: "(support.scm:625) g14611462" 
o|inlining procedure: k9666 
o|inlining procedure: k9666 
o|contracted procedure: "(support.scm:680) g17791780" 
o|contracted procedure: "(support.scm:695) g18281829" 
o|contracted procedure: "(support.scm:697) g18331834" 
o|inlining procedure: k9781 
o|inlining procedure: k9781 
o|contracted procedure: "(support.scm:701) g18381839" 
o|inlining procedure: k9829 
o|inlining procedure: k9829 
o|inlining procedure: k9908 
o|contracted procedure: "(support.scm:719) g19051906" 
o|inlining procedure: k9908 
o|inlining procedure: "(support.scm:724) rename1881" 
o|inlining procedure: k9947 
o|contracted procedure: "(support.scm:726) g19121913" 
o|inlining procedure: "(support.scm:727) rename1881" 
o|inlining procedure: k9947 
o|contracted procedure: "(support.scm:735) g19211922" 
o|inlining procedure: k10034 
o|contracted procedure: "(support.scm:748) g19921993" 
o|inlining procedure: k10100 
o|inlining procedure: k10100 
o|inlining procedure: k10148 
o|inlining procedure: "(support.scm:751) rename1881" 
o|inlining procedure: k10148 
o|inlining procedure: k10167 
o|inlining procedure: k10167 
o|inlining procedure: k10215 
o|inlining procedure: k10215 
o|inlining procedure: k10034 
o|contracted procedure: "(support.scm:754) g20322033" 
o|inlining procedure: k10276 
o|inlining procedure: k10276 
o|substituted constant variable: a10308 
o|substituted constant variable: a10310 
o|substituted constant variable: a10312 
o|substituted constant variable: a10314 
o|substituted constant variable: a10316 
o|contracted procedure: "(support.scm:716) g18961897" 
o|contracted procedure: "(support.scm:715) g18931894" 
o|contracted procedure: "(support.scm:714) g18901891" 
o|inlining procedure: k10323 
o|inlining procedure: k10323 
o|inlining procedure: k10377 
o|inlining procedure: k10377 
o|contracted procedure: "(support.scm:764) g20802081" 
o|contracted procedure: "(support.scm:766) g20912092" 
o|contracted procedure: "(support.scm:765) g20882089" 
o|contracted procedure: "(support.scm:764) g20852086" 
o|contracted procedure: "(support.scm:771) g21032104" 
o|contracted procedure: "(support.scm:770) g21002101" 
o|contracted procedure: "(support.scm:769) g20972098" 
o|inlining procedure: k10530 
o|inlining procedure: k10530 
o|contracted procedure: "(support.scm:778) g21412142" 
o|contracted procedure: "(support.scm:777) g21192120" 
o|contracted procedure: "(support.scm:776) g21162117" 
o|contracted procedure: "(support.scm:782) g21562157" 
o|inlining procedure: k10601 
o|inlining procedure: k10601 
o|inlining procedure: k10641 
o|inlining procedure: k10664 
o|contracted procedure: "(support.scm:820) g22472254" 
o|inlining procedure: k10664 
o|inlining procedure: k10641 
o|inlining procedure: k10725 
o|contracted procedure: "(support.scm:812) g22252232" 
o|inlining procedure: k10725 
o|inlining procedure: k10752 
o|contracted procedure: k10767 
o|inlining procedure: k10764 
o|inlining procedure: k10764 
o|inlining procedure: k10782 
o|contracted procedure: k10802 
o|inlining procedure: k10799 
o|inlining procedure: k10799 
o|inlining procedure: k10840 
o|inlining procedure: k10840 
o|substituted constant variable: a10854 
o|substituted constant variable: a10856 
o|contracted procedure: "(support.scm:798) g22172218" 
o|contracted procedure: "(support.scm:796) g22082209" 
o|inlining procedure: k10782 
o|contracted procedure: "(support.scm:791) g21962197" 
o|contracted procedure: "(support.scm:791) g21992200" 
o|inlining procedure: k10752 
o|inlining procedure: k10912 
o|inlining procedure: k10912 
o|contracted procedure: "(support.scm:828) g22752276" 
o|inlining procedure: k10959 
o|inlining procedure: k10959 
o|inlining procedure: k10990 
o|inlining procedure: k10990 
o|inlining procedure: k11005 
o|inlining procedure: k11005 
o|inlining procedure: k11029 
o|inlining procedure: k11029 
o|inlining procedure: k11044 
o|inlining procedure: k11069 
o|inlining procedure: k11069 
o|inlining procedure: k11087 
o|inlining procedure: k11087 
o|contracted procedure: "(support.scm:858) g23362337" 
o|inlining procedure: k11044 
o|contracted procedure: "(support.scm:857) g23242325" 
o|contracted procedure: "(support.scm:856) g23202321" 
o|inlining procedure: k11143 
o|contracted procedure: "(support.scm:869) g23442345" 
o|contracted procedure: "(support.scm:869) g23412342" 
o|inlining procedure: k11143 
o|inlining procedure: k11192 
o|inlining procedure: k11192 
o|contracted procedure: "(support.scm:881) g23792380" 
o|inlining procedure: k11232 
o|inlining procedure: k11232 
o|substituted constant variable: a11248 
o|substituted constant variable: a11250 
o|substituted constant variable: a11252 
o|inlining procedure: k11256 
o|inlining procedure: k11256 
o|substituted constant variable: a11269 
o|substituted constant variable: a11271 
o|substituted constant variable: a11273 
o|substituted constant variable: a11275 
o|contracted procedure: "(support.scm:878) g23662367" 
o|contracted procedure: "(support.scm:877) g23572358" 
o|inlining procedure: k11293 
o|inlining procedure: k11315 
o|inlining procedure: k11338 
o|inlining procedure: k11338 
o|contracted procedure: "(support.scm:900) g24192420" 
o|contracted procedure: "(support.scm:899) g24152416" 
o|contracted procedure: "(support.scm:897) g24102411" 
o|inlining procedure: k11315 
o|contracted procedure: "(support.scm:903) g24222423" 
o|substituted constant variable: a11390 
o|substituted constant variable: a11392 
o|contracted procedure: "(support.scm:895) g24062407" 
o|inlining procedure: k11293 
o|contracted procedure: "(support.scm:889) g23902391" 
o|inlining procedure: k11406 
o|inlining procedure: k11406 
o|contracted procedure: k11418 
o|inlining procedure: k11421 
o|inlining procedure: k11421 
o|inlining procedure: k11447 
o|inlining procedure: k11447 
o|contracted procedure: k11459 
o|inlining procedure: k11462 
o|inlining procedure: k11462 
o|inlining procedure: k11484 
o|inlining procedure: k11504 
o|inlining procedure: k11504 
o|inlining procedure: k11484 
o|contracted procedure: k11514 
o|inlining procedure: k11527 
o|inlining procedure: k11527 
o|contracted procedure: k11539 
o|inlining procedure: k11566 
o|inlining procedure: k11566 
o|inlining procedure: k11586 
o|inlining procedure: k11586 
o|contracted procedure: "(support.scm:975) g24812482" 
o|inlining procedure: k11607 
o|inlining procedure: k11607 
o|substituted constant variable: a11624 
o|substituted constant variable: a11626 
o|substituted constant variable: a11628 
o|inlining procedure: k11638 
o|inlining procedure: k11638 
o|propagated global variable: out25012505 ##sys#standard-output 
o|substituted constant variable: a11680 
o|substituted constant variable: a11681 
o|propagated global variable: out25112515 ##sys#standard-output 
o|substituted constant variable: a11698 
o|substituted constant variable: a11699 
o|propagated global variable: out25192523 ##sys#standard-output 
o|substituted constant variable: a11710 
o|substituted constant variable: a11711 
o|propagated global variable: out25272531 ##sys#standard-output 
o|substituted constant variable: a11722 
o|substituted constant variable: a11723 
o|propagated global variable: out25352539 ##sys#standard-output 
o|substituted constant variable: a11734 
o|substituted constant variable: a11735 
o|propagated global variable: out25432547 ##sys#standard-output 
o|substituted constant variable: a11746 
o|substituted constant variable: a11747 
o|inlining procedure: k11673 
o|propagated global variable: out25432547 ##sys#standard-output 
o|propagated global variable: out25352539 ##sys#standard-output 
o|propagated global variable: out25272531 ##sys#standard-output 
o|propagated global variable: out25192523 ##sys#standard-output 
o|propagated global variable: out25112515 ##sys#standard-output 
o|propagated global variable: out25012505 ##sys#standard-output 
o|inlining procedure: k11673 
o|inlining procedure: k11766 
o|inlining procedure: k11766 
o|inlining procedure: k11792 
o|contracted procedure: "(support.scm:1005) g25632570" 
o|inlining procedure: k11792 
o|inlining procedure: k11830 
o|inlining procedure: k11830 
o|inlining procedure: k11854 
o|inlining procedure: k11854 
o|inlining procedure: k11860 
o|inlining procedure: k11860 
o|inlining procedure: k11913 
o|inlining procedure: k11913 
o|inlining procedure: k11967 
o|inlining procedure: k11967 
o|inlining procedure: k12025 
o|substituted constant variable: tmap2581 
o|substituted constant variable: tmap2581 
o|inlining procedure: k12025 
o|inlining procedure: k12060 
o|inlining procedure: k12060 
o|inlining procedure: k12066 
o|inlining procedure: k12066 
o|inlining procedure: k12087 
o|inlining procedure: k12087 
o|inlining procedure: k12093 
o|inlining procedure: k12093 
o|inlining procedure: k12140 
o|inlining procedure: k12140 
o|inlining procedure: k12194 
o|inlining procedure: k12194 
o|inlining procedure: k12222 
o|inlining procedure: k12222 
o|inlining procedure: k12255 
o|inlining procedure: k12255 
o|inlining procedure: k12246 
o|inlining procedure: k12246 
o|inlining procedure: k12274 
o|inlining procedure: k12274 
o|inlining procedure: k12348 
o|inlining procedure: k12348 
o|inlining procedure: k12389 
o|inlining procedure: k12389 
o|inlining procedure: k12395 
o|inlining procedure: k12395 
o|inlining procedure: k12421 
o|inlining procedure: k12421 
o|substituted constant variable: a12449 
o|substituted constant variable: a12451 
o|substituted constant variable: a12453 
o|substituted constant variable: a12455 
o|substituted constant variable: a12457 
o|substituted constant variable: a12459 
o|substituted constant variable: a12461 
o|substituted constant variable: a12466 
o|substituted constant variable: a12468 
o|inlining procedure: k12472 
o|inlining procedure: k12472 
o|substituted constant variable: a12485 
o|substituted constant variable: a12487 
o|substituted constant variable: a12489 
o|substituted constant variable: a12491 
o|substituted constant variable: a12499 
o|inlining procedure: k12503 
o|inlining procedure: k12503 
o|substituted constant variable: a12510 
o|substituted constant variable: a12512 
o|substituted constant variable: a12514 
o|inlining procedure: k12518 
o|inlining procedure: k12518 
o|substituted constant variable: a12531 
o|substituted constant variable: a12533 
o|substituted constant variable: a12535 
o|substituted constant variable: a12537 
o|substituted constant variable: a12539 
o|inlining procedure: k12543 
o|inlining procedure: k12543 
o|substituted constant variable: a12550 
o|substituted constant variable: a12552 
o|substituted constant variable: a12554 
o|substituted constant variable: a12556 
o|inlining procedure: k12560 
o|inlining procedure: k12560 
o|substituted constant variable: a12567 
o|substituted constant variable: a12569 
o|substituted constant variable: a12571 
o|substituted constant variable: a12573 
o|inlining procedure: k12577 
o|inlining procedure: k12577 
o|substituted constant variable: a12590 
o|substituted constant variable: a12592 
o|substituted constant variable: a12594 
o|substituted constant variable: a12596 
o|inlining procedure: k12600 
o|inlining procedure: k12600 
o|inlining procedure: k12612 
o|inlining procedure: k12612 
o|inlining procedure: k12624 
o|inlining procedure: k12624 
o|substituted constant variable: a12637 
o|substituted constant variable: a12639 
o|substituted constant variable: a12641 
o|substituted constant variable: a12643 
o|substituted constant variable: a12645 
o|substituted constant variable: a12647 
o|substituted constant variable: a12649 
o|substituted constant variable: a12651 
o|inlining procedure: k12655 
o|inlining procedure: k12655 
o|inlining procedure: k12667 
o|inlining procedure: k12667 
o|inlining procedure: k12679 
o|inlining procedure: k12679 
o|substituted constant variable: a12692 
o|substituted constant variable: a12694 
o|substituted constant variable: a12696 
o|substituted constant variable: a12698 
o|substituted constant variable: a12700 
o|substituted constant variable: a12702 
o|substituted constant variable: a12704 
o|substituted constant variable: a12706 
o|substituted constant variable: a12708 
o|substituted constant variable: a12710 
o|substituted constant variable: a12715 
o|substituted constant variable: a12717 
o|substituted constant variable: a12722 
o|substituted constant variable: a12724 
o|inlining procedure: k12728 
o|inlining procedure: k12728 
o|substituted constant variable: a12735 
o|substituted constant variable: a12737 
o|substituted constant variable: a12739 
o|inlining procedure: k12743 
o|inlining procedure: k12743 
o|inlining procedure: k12755 
o|inlining procedure: k12755 
o|inlining procedure: k12767 
o|inlining procedure: k12767 
o|substituted constant variable: a12780 
o|substituted constant variable: a12782 
o|substituted constant variable: a12784 
o|substituted constant variable: a12786 
o|substituted constant variable: a12788 
o|substituted constant variable: a12790 
o|substituted constant variable: a12792 
o|substituted constant variable: a12794 
o|substituted constant variable: a12799 
o|substituted constant variable: a12801 
o|inlining procedure: k12814 
o|inlining procedure: k12814 
o|inlining procedure: k12823 
o|inlining procedure: k12823 
o|inlining procedure: k12845 
o|inlining procedure: k12845 
o|inlining procedure: k12854 
o|inlining procedure: k12854 
o|inlining procedure: k12891 
o|inlining procedure: k12891 
o|inlining procedure: k12882 
o|inlining procedure: k12882 
o|inlining procedure: k12924 
o|inlining procedure: k12924 
o|inlining procedure: k12945 
o|inlining procedure: k12945 
o|inlining procedure: k12981 
o|inlining procedure: k12981 
o|inlining procedure: k12972 
o|inlining procedure: k12972 
o|inlining procedure: k13000 
o|inlining procedure: k13000 
o|inlining procedure: k13015 
o|inlining procedure: k13015 
o|inlining procedure: k13027 
o|inlining procedure: k13027 
o|inlining procedure: k13039 
o|inlining procedure: k13039 
o|inlining procedure: k13051 
o|inlining procedure: k13051 
o|substituted constant variable: a13058 
o|substituted constant variable: a13060 
o|substituted constant variable: a13062 
o|substituted constant variable: a13064 
o|substituted constant variable: a13066 
o|substituted constant variable: a13068 
o|substituted constant variable: a13070 
o|substituted constant variable: a13072 
o|substituted constant variable: a13074 
o|inlining procedure: k13084 
o|inlining procedure: k13084 
o|inlining procedure: k13096 
o|inlining procedure: k13096 
o|substituted constant variable: a13103 
o|substituted constant variable: a13105 
o|substituted constant variable: a13107 
o|substituted constant variable: a13109 
o|substituted constant variable: a13111 
o|inlining procedure: k13115 
o|inlining procedure: k13115 
o|inlining procedure: k13127 
o|inlining procedure: k13127 
o|inlining procedure: k13139 
o|inlining procedure: k13139 
o|substituted constant variable: a13146 
o|substituted constant variable: a13148 
o|substituted constant variable: a13150 
o|substituted constant variable: a13152 
o|substituted constant variable: a13154 
o|substituted constant variable: a13156 
o|substituted constant variable: a13158 
o|inlining procedure: k13162 
o|inlining procedure: k13162 
o|inlining procedure: k13174 
o|inlining procedure: k13174 
o|inlining procedure: k13186 
o|inlining procedure: k13186 
o|inlining procedure: k13198 
o|inlining procedure: k13198 
o|inlining procedure: k13210 
o|inlining procedure: k13210 
o|substituted constant variable: a13223 
o|substituted constant variable: a13225 
o|substituted constant variable: a13227 
o|substituted constant variable: a13229 
o|substituted constant variable: a13231 
o|substituted constant variable: a13233 
o|substituted constant variable: a13235 
o|substituted constant variable: a13237 
o|substituted constant variable: a13239 
o|substituted constant variable: a13241 
o|substituted constant variable: a13243 
o|substituted constant variable: a13245 
o|inlining procedure: k13249 
o|inlining procedure: k13249 
o|inlining procedure: k13261 
o|inlining procedure: k13261 
o|inlining procedure: k13273 
o|inlining procedure: k13273 
o|inlining procedure: k13285 
o|inlining procedure: k13285 
o|inlining procedure: k13297 
o|inlining procedure: k13297 
o|inlining procedure: k13309 
o|inlining procedure: k13309 
o|substituted constant variable: a13316 
o|substituted constant variable: a13318 
o|substituted constant variable: a13320 
o|substituted constant variable: a13322 
o|substituted constant variable: a13324 
o|substituted constant variable: a13326 
o|substituted constant variable: a13328 
o|substituted constant variable: a13330 
o|substituted constant variable: a13332 
o|substituted constant variable: a13334 
o|substituted constant variable: a13336 
o|substituted constant variable: a13338 
o|substituted constant variable: a13340 
o|inlining procedure: k13362 
o|inlining procedure: k13362 
o|inlining procedure: k13398 
o|inlining procedure: k13398 
o|inlining procedure: k13389 
o|inlining procedure: k13389 
o|inlining procedure: k13417 
o|inlining procedure: k13417 
o|inlining procedure: "(support.scm:1229) err3026" 
o|inlining procedure: k13435 
o|inlining procedure: k13435 
o|inlining procedure: k13447 
o|inlining procedure: k13447 
o|inlining procedure: k13459 
o|inlining procedure: k13459 
o|substituted constant variable: a13472 
o|substituted constant variable: a13474 
o|substituted constant variable: a13476 
o|substituted constant variable: a13478 
o|substituted constant variable: a13480 
o|substituted constant variable: a13482 
o|substituted constant variable: a13484 
o|substituted constant variable: a13486 
o|inlining procedure: "(support.scm:1230) err3026" 
o|inlining procedure: k13499 
o|inlining procedure: k13499 
o|substituted constant variable: a13512 
o|substituted constant variable: a13514 
o|substituted constant variable: a13516 
o|substituted constant variable: a13518 
o|inlining procedure: k13522 
o|inlining procedure: k13522 
o|inlining procedure: k13534 
o|inlining procedure: k13534 
o|inlining procedure: k13546 
o|inlining procedure: k13546 
o|inlining procedure: k13558 
o|inlining procedure: k13558 
o|inlining procedure: k13570 
o|inlining procedure: k13570 
o|inlining procedure: k13582 
o|inlining procedure: k13582 
o|inlining procedure: k13594 
o|inlining procedure: k13594 
o|inlining procedure: k13606 
o|inlining procedure: k13606 
o|inlining procedure: k13618 
o|inlining procedure: k13618 
o|inlining procedure: k13630 
o|inlining procedure: k13630 
o|inlining procedure: k13642 
o|inlining procedure: k13642 
o|inlining procedure: k13654 
o|inlining procedure: k13654 
o|inlining procedure: k13666 
o|inlining procedure: k13666 
o|inlining procedure: k13678 
o|inlining procedure: k13678 
o|inlining procedure: k13690 
o|inlining procedure: k13690 
o|inlining procedure: k13702 
o|inlining procedure: k13702 
o|substituted constant variable: a13709 
o|substituted constant variable: a13711 
o|substituted constant variable: a13713 
o|substituted constant variable: a13715 
o|substituted constant variable: a13717 
o|substituted constant variable: a13719 
o|substituted constant variable: a13721 
o|substituted constant variable: a13723 
o|substituted constant variable: a13725 
o|substituted constant variable: a13727 
o|substituted constant variable: a13729 
o|substituted constant variable: a13731 
o|substituted constant variable: a13733 
o|substituted constant variable: a13735 
o|substituted constant variable: a13737 
o|substituted constant variable: a13739 
o|substituted constant variable: a13741 
o|substituted constant variable: a13743 
o|substituted constant variable: a13745 
o|substituted constant variable: a13747 
o|substituted constant variable: a13749 
o|substituted constant variable: a13751 
o|substituted constant variable: a13753 
o|substituted constant variable: a13755 
o|substituted constant variable: a13757 
o|substituted constant variable: a13759 
o|substituted constant variable: a13761 
o|substituted constant variable: a13763 
o|substituted constant variable: a13765 
o|substituted constant variable: a13767 
o|substituted constant variable: a13769 
o|substituted constant variable: a13771 
o|substituted constant variable: a13773 
o|inlining procedure: k13786 
o|inlining procedure: k13786 
o|inlining procedure: k13815 
o|inlining procedure: k13815 
o|inlining procedure: k13847 
o|inlining procedure: k13847 
o|inlining procedure: k13877 
o|inlining procedure: k13877 
o|inlining procedure: k13896 
o|inlining procedure: k13896 
o|inlining procedure: k13918 
o|inlining procedure: k13918 
o|substituted constant variable: a13983 
o|substituted constant variable: a13988 
o|substituted constant variable: a13990 
o|substituted constant variable: a13991 
o|inlining procedure: k13999 
o|substituted constant variable: a14009 
o|inlining procedure: k13999 
o|substituted constant variable: a14010 
o|substituted constant variable: a14020 
o|substituted constant variable: a14022 
o|substituted constant variable: a14024 
o|substituted constant variable: a14029 
o|substituted constant variable: a14031 
o|substituted constant variable: a14036 
o|substituted constant variable: a14038 
o|substituted constant variable: a14040 
o|substituted constant variable: a14045 
o|substituted constant variable: a14047 
o|inlining procedure: k14054 
o|inlining procedure: k14054 
o|inlining procedure: k14069 
o|inlining procedure: k14069 
o|inlining procedure: k14087 
o|inlining procedure: k14087 
o|substituted constant variable: a14094 
o|inlining procedure: k14095 
o|inlining procedure: k14095 
o|inlining procedure: k14110 
o|inlining procedure: k14110 
o|substituted constant variable: a14117 
o|inlining procedure: k14118 
o|inlining procedure: k14118 
o|inlining procedure: k14130 
o|inlining procedure: k14130 
o|substituted constant variable: a14137 
o|inlining procedure: k14138 
o|inlining procedure: k14138 
o|inlining procedure: k14153 
o|inlining procedure: k14153 
o|substituted constant variable: a14170 
o|inlining procedure: k14171 
o|inlining procedure: k14171 
o|inlining procedure: k14183 
o|inlining procedure: k14183 
o|inlining procedure: k14195 
o|inlining procedure: k14195 
o|inlining procedure: k14207 
o|inlining procedure: k14207 
o|inlining procedure: k14219 
o|inlining procedure: k14219 
o|inlining procedure: k14234 
o|inlining procedure: k14234 
o|inlining procedure: k14249 
o|inlining procedure: k14249 
o|inlining procedure: k14267 
o|inlining procedure: k14267 
o|inlining procedure: k14280 
o|inlining procedure: k14280 
o|inlining procedure: k14302 
o|inlining procedure: k14302 
o|inlining procedure: k14314 
o|inlining procedure: k14314 
o|substituted constant variable: a14321 
o|substituted constant variable: a14323 
o|substituted constant variable: a14325 
o|substituted constant variable: a14327 
o|inlining procedure: k14331 
o|inlining procedure: k14331 
o|substituted constant variable: a14344 
o|substituted constant variable: a14346 
o|substituted constant variable: a14348 
o|substituted constant variable: a14350 
o|substituted constant variable: a14352 
o|inlining procedure: k14356 
o|inlining procedure: k14356 
o|substituted constant variable: a14363 
o|substituted constant variable: a14365 
o|substituted constant variable: a14367 
o|substituted constant variable: a14372 
o|substituted constant variable: a14374 
o|inlining procedure: k14378 
o|inlining procedure: k14378 
o|substituted constant variable: a14391 
o|substituted constant variable: a14393 
o|substituted constant variable: a14395 
o|substituted constant variable: a14397 
o|substituted constant variable: a14399 
o|substituted constant variable: a14401 
o|inlining procedure: k14405 
o|inlining procedure: k14405 
o|inlining procedure: k14417 
o|inlining procedure: k14417 
o|inlining procedure: k14429 
o|inlining procedure: k14429 
o|substituted constant variable: a14442 
o|substituted constant variable: a14444 
o|substituted constant variable: a14446 
o|substituted constant variable: a14448 
o|substituted constant variable: a14450 
o|substituted constant variable: a14452 
o|substituted constant variable: a14454 
o|substituted constant variable: a14456 
o|substituted constant variable: a14458 
o|substituted constant variable: a14460 
o|substituted constant variable: a14462 
o|substituted constant variable: a14464 
o|substituted constant variable: a14466 
o|substituted constant variable: a14468 
o|substituted constant variable: a14470 
o|substituted constant variable: a14472 
o|inlining procedure: k14476 
o|inlining procedure: k14476 
o|inlining procedure: k14488 
o|inlining procedure: k14488 
o|inlining procedure: k14500 
o|inlining procedure: k14500 
o|substituted constant variable: a14513 
o|substituted constant variable: a14515 
o|substituted constant variable: a14517 
o|substituted constant variable: a14519 
o|substituted constant variable: a14521 
o|substituted constant variable: a14523 
o|substituted constant variable: a14525 
o|substituted constant variable: a14527 
o|substituted constant variable: a14529 
o|substituted constant variable: a14531 
o|substituted constant variable: a14533 
o|substituted constant variable: a14535 
o|substituted constant variable: a14540 
o|substituted constant variable: a14542 
o|substituted constant variable: a14547 
o|substituted constant variable: a14549 
o|inlining procedure: k14553 
o|inlining procedure: k14553 
o|inlining procedure: k14565 
o|inlining procedure: k14565 
o|inlining procedure: k14577 
o|inlining procedure: k14577 
o|substituted constant variable: a14590 
o|substituted constant variable: a14592 
o|substituted constant variable: a14594 
o|substituted constant variable: a14596 
o|substituted constant variable: a14598 
o|substituted constant variable: a14600 
o|substituted constant variable: a14602 
o|substituted constant variable: a14604 
o|substituted constant variable: a14609 
o|substituted constant variable: a14611 
o|substituted constant variable: a14613 
o|inlining procedure: k14639 
o|inlining procedure: k14663 
o|inlining procedure: k14663 
o|contracted procedure: "(support.scm:1338) g34123413" 
o|inlining procedure: k14639 
o|inlining procedure: k14727 
o|inlining procedure: k14727 
o|inlining procedure: k14750 
o|inlining procedure: k14750 
o|substituted constant variable: a14757 
o|substituted constant variable: a14759 
o|substituted constant variable: a14761 
o|substituted constant variable: a14766 
o|substituted constant variable: a14768 
o|contracted procedure: "(support.scm:1336) g34053406" 
o|contracted procedure: "(support.scm:1335) g33963397" 
o|inlining procedure: k14799 
o|inlining procedure: k14799 
o|inlining procedure: k14817 
o|inlining procedure: k14817 
o|inlining procedure: k14837 
o|inlining procedure: k14837 
o|inlining procedure: k14887 
o|inlining procedure: k14887 
o|substituted constant variable: a14918 
o|substituted constant variable: a14920 
o|substituted constant variable: a14922 
o|substituted constant variable: a14924 
o|inlining procedure: k14928 
o|inlining procedure: k14928 
o|inlining procedure: k14940 
o|inlining procedure: k14940 
o|substituted constant variable: a14947 
o|substituted constant variable: a14949 
o|substituted constant variable: a14951 
o|substituted constant variable: a14953 
o|substituted constant variable: a14955 
o|contracted procedure: "(support.scm:1356) g34813482" 
o|contracted procedure: "(support.scm:1355) g34723473" 
o|contracted procedure: "(support.scm:1354) g34693470" 
o|inlining procedure: k14973 
o|inlining procedure: k14973 
o|inlining procedure: k15005 
o|inlining procedure: k15005 
o|substituted constant variable: a15021 
o|inlining procedure: k15038 
o|inlining procedure: k15038 
o|substituted constant variable: a15047 
o|substituted constant variable: a15098 
o|substituted constant variable: a15099 
o|inlining procedure: k15124 
o|inlining procedure: k15124 
o|inlining procedure: k15152 
o|inlining procedure: k15152 
o|contracted procedure: k15167 
o|inlining procedure: k15164 
o|inlining procedure: k15194 
o|inlining procedure: k15194 
o|inlining procedure: k15217 
o|inlining procedure: k15217 
o|inlining procedure: k15164 
o|inlining procedure: k15269 
o|inlining procedure: k15269 
o|propagated global variable: out36113615 ##sys#standard-output 
o|substituted constant variable: a15285 
o|substituted constant variable: a15286 
o|propagated global variable: out36113615 ##sys#standard-output 
o|inlining procedure: k15302 
o|inlining procedure: k15302 
o|inlining procedure: k15336 
o|inlining procedure: k15336 
o|inlining procedure: k15360 
o|inlining procedure: k15360 
o|inlining procedure: k15363 
o|inlining procedure: k15363 
o|inlining procedure: k15420 
o|inlining procedure: k15446 
o|inlining procedure: k15446 
o|substituted constant variable: a15474 
o|substituted constant variable: a15487 
o|contracted procedure: "(support.scm:1503) g37193720" 
o|inlining procedure: k15420 
o|inlining procedure: k15565 
o|contracted procedure: "(support.scm:1495) g36823691" 
o|inlining procedure: k15565 
o|inlining procedure: k15599 
o|contracted procedure: "(support.scm:1494) g36513660" 
o|contracted procedure: "(support.scm:1494) g36633664" 
o|inlining procedure: k15599 
o|inlining procedure: k15646 
o|inlining procedure: k15646 
o|inlining procedure: k15658 
o|inlining procedure: k15658 
o|inlining procedure: "(support.scm:1528) fits?3733" 
o|inlining procedure: k15677 
o|inlining procedure: "(support.scm:1530) fits?3733" 
o|inlining procedure: "(support.scm:1530) getsize3732" 
o|inlining procedure: k15677 
o|inlining procedure: "(support.scm:1533) fits?3733" 
o|inlining procedure: "(support.scm:1532) getsize3732" 
o|propagated global variable: out37713775 ##sys#standard-output 
o|substituted constant variable: a15752 
o|substituted constant variable: a15753 
o|propagated global variable: out38083812 ##sys#standard-output 
o|substituted constant variable: a15796 
o|substituted constant variable: a15797 
o|inlining procedure: k15786 
o|inlining procedure: k15813 
o|propagated global variable: out38183822 ##sys#standard-output 
o|substituted constant variable: a15820 
o|substituted constant variable: a15821 
o|inlining procedure: k15813 
o|propagated global variable: out38183822 ##sys#standard-output 
o|propagated global variable: out38083812 ##sys#standard-output 
o|inlining procedure: k15786 
o|inlining procedure: k15846 
o|inlining procedure: k15846 
o|propagated global variable: out37713775 ##sys#standard-output 
o|contracted procedure: "(support.scm:1546) g37683769" 
o|contracted procedure: "(support.scm:1545) g37653766" 
o|contracted procedure: "(support.scm:1544) g37623763" 
o|inlining procedure: k15869 
o|inlining procedure: k15894 
o|inlining procedure: k15894 
o|inlining procedure: k15869 
o|inlining procedure: k15918 
o|inlining procedure: k15918 
o|inlining procedure: k15955 
o|inlining procedure: k15955 
o|substituted constant variable: a15968 
o|substituted constant variable: a15979 
o|inlining procedure: k15975 
o|substituted constant variable: a16001 
o|inlining procedure: k15975 
o|inlining procedure: k16012 
o|inlining procedure: k16027 
o|inlining procedure: k16027 
o|inlining procedure: k16012 
o|contracted procedure: "(support.scm:1623) g38773878" 
o|contracted procedure: "(support.scm:1626) g38933894" 
o|inlining procedure: k16089 
o|inlining procedure: k16089 
o|substituted constant variable: a16105 
o|substituted constant variable: a16107 
o|contracted procedure: "(support.scm:1644) g39413942" 
o|contracted procedure: "(support.scm:1645) g39523953" 
o|inlining procedure: k16157 
o|inlining procedure: k16203 
o|contracted procedure: "(support.scm:1654) g39773984" 
o|inlining procedure: k16203 
o|substituted constant variable: a16228 
o|substituted constant variable: a16229 
o|inlining procedure: k16157 
o|substituted constant variable: constant25 
o|substituted constant variable: a16296 
o|substituted constant variable: a16297 
o|contracted procedure: "(support.scm:513) g10031004" 
o|contracted procedure: "(support.scm:513) g10001001" 
o|replaced variables: 2937 
o|removed binding forms: 629 
o|removed side-effect free assignment to unused variable: constant25 
o|propagated global variable: out6165 ##sys#standard-output 
o|propagated global variable: out7781 ##compiler#collected-debugging-output 
o|substituted constant variable: r497516347 
o|inlining procedure: k4989 
o|substituted constant variable: r497516348 
o|inlining procedure: k4998 
o|propagated global variable: out114118 ##compiler#collected-debugging-output 
o|converted assignments to bindings: (collect99) 
o|substituted constant variable: r523416359 
o|converted assignments to bindings: (err211) 
o|substituted constant variable: r534316365 
o|substituted constant variable: r537716367 
o|substituted constant variable: r554916375 
o|substituted constant variable: r559416377 
o|substituted constant variable: r559416378 
o|substituted constant variable: r563116384 
o|substituted constant variable: r590316408 
o|substituted constant variable: r601716424 
o|substituted constant variable: r605516425 
o|substituted constant variable: r617316435 
o|substituted constant variable: mark646 
o|substituted constant variable: mark613 
o|substituted constant variable: mark599 
o|substituted constant variable: mark566 
o|substituted constant variable: mark552 
o|substituted constant variable: r653516458 
o|substituted constant variable: r655316460 
o|substituted constant variable: r672416470 
o|propagated global variable: out733737 ##sys#standard-output 
o|propagated global variable: out942946 ##sys#standard-output 
o|inlining procedure: k6878 
o|propagated global variable: out935939 ##sys#standard-output 
o|propagated global variable: out894898 ##sys#standard-output 
o|propagated global variable: out908912 ##sys#standard-output 
o|propagated global variable: out922926 ##sys#standard-output 
o|propagated global variable: out847851 ##sys#standard-output 
o|propagated global variable: out878882 ##sys#standard-output 
o|substituted constant variable: c1019 
o|substituted constant variable: s1021 
o|substituted constant variable: c1026 
o|substituted constant variable: s1028 
o|substituted constant variable: p1053 
o|substituted constant variable: r768016534 
o|substituted constant variable: c1089 
o|substituted constant variable: c1151 
o|substituted constant variable: c1156 
o|substituted constant variable: c1169 
o|substituted constant variable: c1174 
o|substituted constant variable: p1175 
o|substituted constant variable: s1176 
o|substituted constant variable: c1179 
o|substituted constant variable: s1254 
o|substituted constant variable: c1257 
o|substituted constant variable: s1259 
o|substituted constant variable: c1265 
o|substituted constant variable: c1297 
o|substituted constant variable: c1345 
o|substituted constant variable: c1378 
o|substituted constant variable: mark1388 
o|substituted constant variable: c1422 
o|substituted constant variable: c1781 
o|substituted constant variable: p1782 
o|substituted constant variable: c1830 
o|substituted constant variable: c1835 
o|substituted constant variable: c1840 
o|removed side-effect free assignment to unused variable: rename1881 
o|substituted constant variable: s1909 
o|substituted constant variable: c1914 
o|substituted constant variable: c1923 
o|substituted constant variable: c1994 
o|substituted constant variable: r1014916670 
o|substituted constant variable: r1014916670 
o|substituted constant variable: r1076516694 
o|substituted constant variable: r1080016697 
o|substituted constant variable: r1084116699 
o|substituted constant variable: mark2220 
o|substituted constant variable: r1078316701 
o|substituted constant variable: mark2202 
o|substituted constant variable: mark2282 
o|substituted constant variable: r1100616710 
o|substituted constant variable: r1108816716 
o|substituted constant variable: r1104516718 
o|substituted constant variable: r1114416720 
o|substituted constant variable: r1119316721 
o|substituted constant variable: r1123316724 
o|substituted constant variable: r1133916730 
o|substituted constant variable: r1129416732 
o|substituted constant variable: r1142216736 
o|substituted constant variable: r1146316740 
o|substituted constant variable: r1150516744 
o|substituted constant variable: r1150516744 
o|propagated global variable: out25012505 ##sys#standard-output 
o|propagated global variable: out25112515 ##sys#standard-output 
o|propagated global variable: out25192523 ##sys#standard-output 
o|propagated global variable: out25272531 ##sys#standard-output 
o|propagated global variable: out25352539 ##sys#standard-output 
o|propagated global variable: out25432547 ##sys#standard-output 
o|substituted constant variable: r1282416840 
o|substituted constant variable: r1285516844 
o|substituted constant variable: r1292516851 
o|substituted constant variable: r1300116862 
o|removed side-effect free assignment to unused variable: err3026 
o|substituted constant variable: r1400016976 
o|substituted constant variable: r1405516977 
o|substituted constant variable: r1407016979 
o|substituted constant variable: r1408816981 
o|substituted constant variable: r1408816982 
o|substituted constant variable: r1409616983 
o|substituted constant variable: r1411116985 
o|substituted constant variable: r1411116986 
o|substituted constant variable: r1411916987 
o|substituted constant variable: r1413116989 
o|substituted constant variable: r1413116990 
o|substituted constant variable: r1413916991 
o|substituted constant variable: r1417216995 
o|substituted constant variable: r1418416997 
o|substituted constant variable: r1419616999 
o|substituted constant variable: r1420817001 
o|substituted constant variable: r1422017003 
o|substituted constant variable: r1423517005 
o|substituted constant variable: r1425017007 
o|substituted constant variable: r1426817009 
o|substituted constant variable: r1428117011 
o|substituted constant variable: r1430317013 
o|substituted constant variable: r1480017049 
o|converted assignments to bindings: (resolve3581) 
o|substituted constant variable: r1527017080 
o|propagated global variable: out36113615 ##sys#standard-output 
o|substituted constant variable: r1536417088 
o|removed side-effect free assignment to unused variable: getsize3732 
o|removed side-effect free assignment to unused variable: fits?3733 
o|propagated global variable: out37713775 ##sys#standard-output 
o|propagated global variable: out38083812 ##sys#standard-output 
o|propagated global variable: out38183822 ##sys#standard-output 
o|substituted constant variable: r1589517143 
o|substituted constant variable: r1589517143 
o|substituted constant variable: r1601317156 
o|substituted constant variable: mark3884 
o|substituted constant variable: mark3900 
o|substituted constant variable: r1609017157 
o|substituted constant variable: mark3944 
o|substituted constant variable: mark3955 
o|substituted constant variable: r1615817162 
o|simplifications: ((let . 3)) 
o|replaced variables: 78 
o|removed binding forms: 2861 
o|substituted constant variable: r49751634717168 
o|substituted constant variable: r49751634817170 
o|inlining procedure: k6438 
o|inlining procedure: k6413 
o|inlining procedure: k6390 
o|inlining procedure: k6365 
o|inlining procedure: k6342 
o|inlining procedure: k7057 
o|inlining procedure: k7057 
o|inlining procedure: k7057 
o|inlining procedure: k7057 
o|inlining procedure: k7057 
o|inlining procedure: k7057 
o|inlining procedure: k7057 
o|inlining procedure: k7057 
o|inlining procedure: k10920 
o|inlining procedure: k11238 
o|inlining procedure: k12439 
o|inlining procedure: k12811 
o|inlining procedure: k12811 
o|inlining procedure: k12811 
o|inlining procedure: k12842 
o|inlining procedure: k12842 
o|inlining procedure: k12842 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|inlining procedure: k14846 
o|inlining procedure: k14846 
o|inlining procedure: k15357 
o|inlining procedure: k15357 
o|inlining procedure: k16038 
o|inlining procedure: k16058 
o|inlining procedure: k16111 
o|inlining procedure: k16255 
o|replaced variables: 108 
o|removed binding forms: 207 
o|substituted constant variable: r643917433 
o|substituted constant variable: r641417436 
o|substituted constant variable: r639117437 
o|substituted constant variable: r636617440 
o|substituted constant variable: r634317441 
o|inlining procedure: k8138 
o|substituted constant variable: r1092117552 
o|substituted constant variable: r1281217570 
o|substituted constant variable: r1281217570 
o|substituted constant variable: r1281217570 
o|substituted constant variable: r1281217573 
o|substituted constant variable: r1281217573 
o|substituted constant variable: r1281217573 
o|substituted constant variable: r1281217576 
o|substituted constant variable: r1281217576 
o|substituted constant variable: r1281217576 
o|substituted constant variable: r1284317579 
o|substituted constant variable: r1284317579 
o|substituted constant variable: r1284317579 
o|substituted constant variable: r1284317582 
o|substituted constant variable: r1284317582 
o|substituted constant variable: r1284317582 
o|substituted constant variable: r1284317585 
o|substituted constant variable: r1284317585 
o|substituted constant variable: r1284317585 
o|substituted constant variable: r1535817624 
o|substituted constant variable: r1535817624 
o|substituted constant variable: r1535817624 
o|substituted constant variable: r1535817627 
o|substituted constant variable: r1535817627 
o|substituted constant variable: r1535817627 
o|contracted procedure: k15684 
o|contracted procedure: k15687 
o|substituted constant variable: r1603917642 
o|substituted constant variable: r1605917643 
o|substituted constant variable: r1611217644 
o|replaced variables: 7 
o|removed binding forms: 132 
o|removed conditional forms: 8 
o|substituted constant variable: r813917697 
o|removed binding forms: 25 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 70) (##core#call . 1451)) 
o|  call simplifications:
o|    ##sys#fudge
o|    char=?
o|    read-char	3
o|    ##sys#size
o|    fx>	2
o|    write-char	6
o|    flonum?
o|    arithmetic-shift	3
o|    procedure?
o|    fx+	2
o|    string-length	4
o|    >	2
o|    string-ref	2
o|    list?	4
o|    vector-ref	6
o|    <
o|    *
o|    -	2
o|    first	19
o|    positive?
o|    not-pair?	5
o|    ##sys#call-with-values	5
o|    cdddr
o|    second	10
o|    third	6
o|    fourth	4
o|    caddr	4
o|    cadr	24
o|    integer?
o|    inexact->exact
o|    ##sys#check-structure	7
o|    ##sys#block-ref	4
o|    ##sys#structure?	5
o|    ##sys#make-structure	33
o|    cdar	6
o|    caar	5
o|    length	8
o|    values	4
o|    +	7
o|    ##sys#setslot	36
o|    assq	17
o|    alist-cons	8
o|    atom?
o|    ##sys#apply	2
o|    ##sys#cons	7
o|    equal?	3
o|    ##sys#list	131
o|    fixnum?	3
o|    number?	4
o|    char?	4
o|    boolean?	4
o|    eof-object?	5
o|    vector?	8
o|    member
o|    cddr	3
o|    list	50
o|    string=?	2
o|    not	12
o|    ##sys#foreign-fixnum-argument	2
o|    char-alphabetic?	2
o|    char-numeric?
o|    char->integer
o|    fx>=	2
o|    fx<	4
o|    string->list	3
o|    list->string
o|    zero?	3
o|    sub1	4
o|    string?	4
o|    eqv?
o|    eq?	382
o|    add1	4
o|    null?	41
o|    cons	91
o|    car	52
o|    cdr	20
o|    ##sys#check-list	40
o|    ##sys#slot	187
o|    symbol?	19
o|    memq	9
o|    pair?	69
o|    apply	5
o|contracted procedure: k4850 
o|contracted procedure: k4878 
o|contracted procedure: k4912 
o|contracted procedure: k4942 
o|contracted procedure: k4952 
o|contracted procedure: k4956 
o|contracted procedure: k5038 
o|propagated global variable: out114118 ##compiler#collected-debugging-output 
o|contracted procedure: k5054 
o|contracted procedure: k5064 
o|contracted procedure: k5068 
o|contracted procedure: k5138 
o|contracted procedure: k5156 
o|contracted procedure: k5166 
o|contracted procedure: k5170 
o|contracted procedure: k5209 
o|contracted procedure: k5213 
o|contracted procedure: k5217 
o|contracted procedure: k5236 
o|contracted procedure: k5242 
o|contracted procedure: k5262 
o|contracted procedure: k5283 
o|contracted procedure: k5295 
o|contracted procedure: k5301 
o|contracted procedure: k5307 
o|contracted procedure: k5316 
o|contracted procedure: k5326 
o|contracted procedure: k5330 
o|contracted procedure: k5345 
o|contracted procedure: k5364 
o|contracted procedure: k5351 
o|contracted procedure: k5360 
o|contracted procedure: k5379 
o|contracted procedure: k5398 
o|contracted procedure: k5385 
o|contracted procedure: k5394 
o|contracted procedure: k5407 
o|contracted procedure: k5413 
o|contracted procedure: k5437 
o|contracted procedure: k5443 
o|contracted procedure: k5497 
o|contracted procedure: k5500 
o|contracted procedure: k5510 
o|contracted procedure: k5520 
o|contracted procedure: k5534 
o|contracted procedure: k5551 
o|contracted procedure: k5554 
o|contracted procedure: k5557 
o|contracted procedure: k5563 
o|contracted procedure: k5590 
o|contracted procedure: k5596 
o|contracted procedure: k5612 
o|contracted procedure: k5633 
o|contracted procedure: k5640 
o|contracted procedure: k5643 
o|contracted procedure: k5652 
o|contracted procedure: k5658 
o|contracted procedure: k5678 
o|contracted procedure: k5685 
o|contracted procedure: k5694 
o|contracted procedure: k5709 
o|contracted procedure: k5722 
o|contracted procedure: k5729 
o|contracted procedure: k5738 
o|contracted procedure: k5797 
o|contracted procedure: k5750 
o|contracted procedure: k5793 
o|contracted procedure: k5770 
o|inlining procedure: k5767 
o|inlining procedure: k5767 
o|contracted procedure: k5812 
o|contracted procedure: k5828 
o|contracted procedure: k5854 
o|contracted procedure: k5860 
o|contracted procedure: k5866 
o|contracted procedure: k5872 
o|contracted procedure: k5878 
o|contracted procedure: k5890 
o|contracted procedure: k5905 
o|contracted procedure: k5916 
o|contracted procedure: k5922 
o|contracted procedure: k5928 
o|contracted procedure: k5934 
o|contracted procedure: k5952 
o|contracted procedure: k5958 
o|contracted procedure: k5964 
o|contracted procedure: k5970 
o|contracted procedure: k5979 
o|contracted procedure: k5992 
o|contracted procedure: k5998 
o|contracted procedure: k6019 
o|contracted procedure: k6035 
o|contracted procedure: k6057 
o|contracted procedure: k6115 
o|contracted procedure: k6063 
o|contracted procedure: k6071 
o|contracted procedure: k6096 
o|contracted procedure: k6086 
o|contracted procedure: k6175 
o|contracted procedure: k6189 
o|contracted procedure: k6181 
o|contracted procedure: k6242 
o|contracted procedure: k6248 
o|contracted procedure: k6257 
o|contracted procedure: k6267 
o|contracted procedure: k6271 
o|contracted procedure: k6281 
o|contracted procedure: k6285 
o|contracted procedure: k6328 
o|contracted procedure: k6324 
o|contracted procedure: k6296 
o|contracted procedure: k6320 
o|contracted procedure: k6316 
o|contracted procedure: k6300 
o|contracted procedure: k6312 
o|contracted procedure: k6308 
o|contracted procedure: k6304 
o|contracted procedure: k6292 
o|contracted procedure: k6380 
o|contracted procedure: k6428 
o|contracted procedure: k6453 
o|contracted procedure: k6465 
o|contracted procedure: k6475 
o|contracted procedure: k6479 
o|contracted procedure: k6444 
o|contracted procedure: k6438 
o|propagated global variable: g635637 ##compiler#internal-bindings 
o|contracted procedure: k6488 
o|contracted procedure: k6498 
o|contracted procedure: k6502 
o|contracted procedure: k6408 
o|contracted procedure: k6419 
o|contracted procedure: k6413 
o|contracted procedure: k6396 
o|contracted procedure: k6390 
o|propagated global variable: g588590 extended-bindings 
o|contracted procedure: k6511 
o|contracted procedure: k6521 
o|contracted procedure: k6525 
o|contracted procedure: k6360 
o|contracted procedure: k6371 
o|contracted procedure: k6365 
o|contracted procedure: k6348 
o|contracted procedure: k6342 
o|propagated global variable: g541543 standard-bindings 
o|contracted procedure: k6537 
o|contracted procedure: k6573 
o|contracted procedure: k6593 
o|contracted procedure: k6589 
o|contracted procedure: k6607 
o|contracted procedure: k6603 
o|contracted procedure: k6619 
o|contracted procedure: k6633 
o|contracted procedure: k6629 
o|contracted procedure: k6644 
o|contracted procedure: k6648 
o|contracted procedure: k6640 
o|contracted procedure: k6659 
o|contracted procedure: k6655 
o|contracted procedure: k6674 
o|contracted procedure: k6688 
o|contracted procedure: k6684 
o|contracted procedure: k6699 
o|contracted procedure: k6695 
o|contracted procedure: k6710 
o|contracted procedure: k6706 
o|contracted procedure: k6713 
o|contracted procedure: k6733 
o|contracted procedure: k6739 
o|contracted procedure: k6757 
o|contracted procedure: k6761 
o|contracted procedure: k6774 
o|contracted procedure: k6805 
o|contracted procedure: k6808 
o|contracted procedure: k6820 
o|contracted procedure: k6842 
o|contracted procedure: k6838 
o|contracted procedure: k6823 
o|contracted procedure: k6826 
o|contracted procedure: k6834 
o|contracted procedure: k6863 
o|contracted procedure: k6884 
o|contracted procedure: k6897 
o|contracted procedure: k6900 
o|contracted procedure: k6913 
o|contracted procedure: k6938 
o|contracted procedure: k6947 
o|contracted procedure: k6929 
o|contracted procedure: k6975 
o|contracted procedure: k6984 
o|contracted procedure: k6966 
o|contracted procedure: k7012 
o|contracted procedure: k7021 
o|contracted procedure: k7003 
o|contracted procedure: k7028 
o|contracted procedure: k7035 
o|contracted procedure: k7042 
o|contracted procedure: k7051 
o|contracted procedure: k7054 
o|contracted procedure: k7065 
o|contracted procedure: k7089 
o|contracted procedure: k7085 
o|contracted procedure: k7081 
o|contracted procedure: k7095 
o|contracted procedure: k7102 
o|contracted procedure: k7108 
o|contracted procedure: k7112 
o|contracted procedure: k7118 
o|contracted procedure: k7124 
o|contracted procedure: k7128 
o|contracted procedure: k7134 
o|contracted procedure: k7138 
o|contracted procedure: k7144 
o|contracted procedure: k7166 
o|contracted procedure: k7170 
o|contracted procedure: k7176 
o|contracted procedure: k7180 
o|contracted procedure: k7186 
o|contracted procedure: k7190 
o|contracted procedure: k7202 
o|contracted procedure: k7208 
o|contracted procedure: k7214 
o|contracted procedure: k7220 
o|contracted procedure: k7226 
o|contracted procedure: k7232 
o|contracted procedure: k7238 
o|contracted procedure: k7273 
o|contracted procedure: k7279 
o|contracted procedure: k7285 
o|contracted procedure: k7291 
o|contracted procedure: k7297 
o|contracted procedure: k7303 
o|contracted procedure: k7309 
o|contracted procedure: k7315 
o|contracted procedure: k7321 
o|contracted procedure: k7327 
o|contracted procedure: k7333 
o|contracted procedure: k7339 
o|contracted procedure: k7345 
o|contracted procedure: k7351 
o|contracted procedure: k7357 
o|contracted procedure: k7363 
o|contracted procedure: k7369 
o|contracted procedure: k7375 
o|contracted procedure: k7381 
o|contracted procedure: k7451 
o|contracted procedure: k7460 
o|contracted procedure: k7469 
o|contracted procedure: k7478 
o|contracted procedure: k7487 
o|contracted procedure: k7496 
o|contracted procedure: k7523 
o|contracted procedure: k7538 
o|contracted procedure: k7550 
o|contracted procedure: k7564 
o|contracted procedure: k7570 
o|contracted procedure: k8764 
o|contracted procedure: k7579 
o|contracted procedure: k7586 
o|contracted procedure: k7589 
o|contracted procedure: k7603 
o|contracted procedure: k7607 
o|contracted procedure: k7619 
o|contracted procedure: k7622 
o|contracted procedure: k7625 
o|contracted procedure: k7633 
o|contracted procedure: k7641 
o|contracted procedure: k7650 
o|contracted procedure: k7653 
o|contracted procedure: k7660 
o|contracted procedure: k7676 
o|contracted procedure: k7682 
o|contracted procedure: k7689 
o|contracted procedure: k7695 
o|contracted procedure: k7698 
o|contracted procedure: k7701 
o|contracted procedure: k7707 
o|contracted procedure: k7722 
o|contracted procedure: k7747 
o|contracted procedure: k7756 
o|contracted procedure: k7759 
o|contracted procedure: k7762 
o|contracted procedure: k7769 
o|contracted procedure: k7782 
o|contracted procedure: k7785 
o|contracted procedure: k7788 
o|contracted procedure: k7796 
o|contracted procedure: k7804 
o|contracted procedure: k7816 
o|contracted procedure: k7819 
o|contracted procedure: k7822 
o|contracted procedure: k7830 
o|contracted procedure: k7838 
o|contracted procedure: k7730 
o|contracted procedure: k7847 
o|contracted procedure: k7850 
o|contracted procedure: k7878 
o|contracted procedure: k7862 
o|contracted procedure: k7866 
o|contracted procedure: k7874 
o|contracted procedure: k7884 
o|contracted procedure: k7912 
o|contracted procedure: k7916 
o|contracted procedure: k7896 
o|contracted procedure: k7900 
o|contracted procedure: k7908 
o|contracted procedure: k7922 
o|contracted procedure: k7929 
o|contracted procedure: k7933 
o|contracted procedure: k7942 
o|contracted procedure: k7975 
o|contracted procedure: k7954 
o|contracted procedure: k7971 
o|contracted procedure: k7962 
o|contracted procedure: k8054 
o|contracted procedure: k7985 
o|contracted procedure: k8017 
o|contracted procedure: k7997 
o|contracted procedure: k8005 
o|contracted procedure: k8025 
o|contracted procedure: k8050 
o|contracted procedure: k8034 
o|contracted procedure: k8038 
o|contracted procedure: k8068 
o|contracted procedure: k8071 
o|contracted procedure: k8089 
o|contracted procedure: k8094 
o|contracted procedure: k8106 
o|contracted procedure: k8109 
o|contracted procedure: k8112 
o|contracted procedure: k8120 
o|contracted procedure: k8128 
o|contracted procedure: k8144 
o|contracted procedure: k8138 
o|contracted procedure: k8135 
o|contracted procedure: k8155 
o|contracted procedure: k8158 
o|contracted procedure: k8222 
o|contracted procedure: k8172 
o|contracted procedure: k8176 
o|contracted procedure: k8181 
o|contracted procedure: k8193 
o|contracted procedure: k8196 
o|contracted procedure: k8199 
o|contracted procedure: k8207 
o|contracted procedure: k8215 
o|contracted procedure: k8228 
o|contracted procedure: k8246 
o|contracted procedure: k8262 
o|contracted procedure: k8258 
o|contracted procedure: k8268 
o|contracted procedure: k8271 
o|contracted procedure: k8333 
o|contracted procedure: k8283 
o|contracted procedure: k8287 
o|contracted procedure: k8292 
o|contracted procedure: k8304 
o|contracted procedure: k8307 
o|contracted procedure: k8310 
o|contracted procedure: k8318 
o|contracted procedure: k8326 
o|contracted procedure: k8339 
o|contracted procedure: k8394 
o|contracted procedure: k8342 
o|contracted procedure: k8390 
o|contracted procedure: k8370 
o|contracted procedure: k8386 
o|contracted procedure: k8374 
o|contracted procedure: k8378 
o|contracted procedure: k8354 
o|contracted procedure: k8358 
o|contracted procedure: k8400 
o|contracted procedure: k8417 
o|contracted procedure: k8421 
o|contracted procedure: k8426 
o|contracted procedure: k8438 
o|contracted procedure: k8441 
o|contracted procedure: k8444 
o|contracted procedure: k8452 
o|contracted procedure: k8460 
o|contracted procedure: k8469 
o|contracted procedure: k8481 
o|contracted procedure: k8485 
o|contracted procedure: k8489 
o|contracted procedure: k8501 
o|contracted procedure: k8504 
o|contracted procedure: k8507 
o|contracted procedure: k8515 
o|contracted procedure: k8523 
o|contracted procedure: k8550 
o|contracted procedure: k8554 
o|contracted procedure: k8557 
o|contracted procedure: k8569 
o|contracted procedure: k8572 
o|contracted procedure: k8575 
o|contracted procedure: k8583 
o|contracted procedure: k8591 
o|contracted procedure: k8630 
o|contracted procedure: k8635 
o|contracted procedure: k8641 
o|contracted procedure: k8647 
o|contracted procedure: k8719 
o|contracted procedure: k8723 
o|contracted procedure: k8735 
o|contracted procedure: k8738 
o|contracted procedure: k8741 
o|contracted procedure: k8749 
o|contracted procedure: k8757 
o|contracted procedure: k8773 
o|contracted procedure: k8793 
o|contracted procedure: k8801 
o|contracted procedure: k8809 
o|contracted procedure: k8815 
o|contracted procedure: k8825 
o|contracted procedure: k8828 
o|contracted procedure: k8840 
o|contracted procedure: k8843 
o|contracted procedure: k8846 
o|contracted procedure: k8854 
o|contracted procedure: k8862 
o|contracted procedure: k8871 
o|contracted procedure: k8882 
o|contracted procedure: k8885 
o|contracted procedure: k8878 
o|contracted procedure: k8897 
o|contracted procedure: k8900 
o|contracted procedure: k8903 
o|contracted procedure: k8911 
o|contracted procedure: k8919 
o|contracted procedure: k8928 
o|contracted procedure: k8937 
o|contracted procedure: k8940 
o|contracted procedure: k8946 
o|inlining procedure: k8949 
o|contracted procedure: k8957 
o|inlining procedure: k8949 
o|contracted procedure: k8963 
o|inlining procedure: k8949 
o|contracted procedure: k8975 
o|contracted procedure: k8982 
o|contracted procedure: k8985 
o|contracted procedure: k8994 
o|contracted procedure: k8997 
o|contracted procedure: k9053 
o|contracted procedure: k9017 
o|contracted procedure: k9043 
o|contracted procedure: k9047 
o|contracted procedure: k9039 
o|contracted procedure: k9020 
o|contracted procedure: k9023 
o|contracted procedure: k9031 
o|contracted procedure: k9035 
o|contracted procedure: k9065 
o|contracted procedure: k9068 
o|contracted procedure: k9071 
o|contracted procedure: k9079 
o|contracted procedure: k9087 
o|contracted procedure: k9096 
o|contracted procedure: k9118 
o|contracted procedure: k9103 
o|contracted procedure: k9107 
o|contracted procedure: k9115 
o|contracted procedure: k9124 
o|contracted procedure: k9131 
o|contracted procedure: k9139 
o|contracted procedure: k9145 
o|contracted procedure: k9152 
o|contracted procedure: k9158 
o|contracted procedure: k9165 
o|contracted procedure: k9177 
o|contracted procedure: k9188 
o|contracted procedure: k9194 
o|contracted procedure: k9201 
o|contracted procedure: k9209 
o|contracted procedure: k9228 
o|contracted procedure: k9216 
o|contracted procedure: k9236 
o|contracted procedure: k9240 
o|contracted procedure: k9246 
o|contracted procedure: k9249 
o|contracted procedure: k9252 
o|contracted procedure: k9264 
o|contracted procedure: k9267 
o|contracted procedure: k9270 
o|contracted procedure: k9278 
o|contracted procedure: k9286 
o|contracted procedure: k9295 
o|contracted procedure: k9302 
o|contracted procedure: k9306 
o|contracted procedure: k9309 
o|contracted procedure: k9321 
o|contracted procedure: k9324 
o|contracted procedure: k9327 
o|contracted procedure: k9335 
o|contracted procedure: k9343 
o|contracted procedure: k9352 
o|contracted procedure: k9361 
o|contracted procedure: k9368 
o|contracted procedure: k9377 
o|contracted procedure: k9392 
o|contracted procedure: k9399 
o|contracted procedure: k9403 
o|contracted procedure: k9407 
o|contracted procedure: k9419 
o|contracted procedure: k9433 
o|contracted procedure: k9437 
o|contracted procedure: k9449 
o|contracted procedure: k9452 
o|contracted procedure: k9455 
o|contracted procedure: k9463 
o|contracted procedure: k9471 
o|contracted procedure: k9478 
o|contracted procedure: k9484 
o|contracted procedure: k9487 
o|contracted procedure: k9494 
o|contracted procedure: k9497 
o|contracted procedure: k9509 
o|contracted procedure: k9512 
o|contracted procedure: k9515 
o|contracted procedure: k9523 
o|contracted procedure: k9531 
o|contracted procedure: k9545 
o|contracted procedure: k9548 
o|contracted procedure: k9560 
o|contracted procedure: k9563 
o|contracted procedure: k9566 
o|contracted procedure: k9574 
o|contracted procedure: k9582 
o|contracted procedure: k9595 
o|contracted procedure: k9601 
o|contracted procedure: k9642 
o|contracted procedure: k9704 
o|contracted procedure: k9669 
o|contracted procedure: k9684 
o|contracted procedure: k9700 
o|contracted procedure: k9749 
o|contracted procedure: k9753 
o|contracted procedure: k9773 
o|contracted procedure: k9777 
o|contracted procedure: k9784 
o|contracted procedure: k9807 
o|contracted procedure: k9803 
o|contracted procedure: k9799 
o|contracted procedure: k9817 
o|contracted procedure: k9820 
o|contracted procedure: k9832 
o|contracted procedure: k9835 
o|contracted procedure: k9838 
o|contracted procedure: k9846 
o|contracted procedure: k9854 
o|contracted procedure: k9863 
o|contracted procedure: k9866 
o|contracted procedure: k9869 
o|contracted procedure: k9889 
o|contracted procedure: k9897 
o|contracted procedure: k9905 
o|contracted procedure: k9911 
o|contracted procedure: k9925 
o|contracted procedure: k9928 
o|contracted procedure: k9950 
o|contracted procedure: k9962 
o|contracted procedure: k9966 
o|contracted procedure: k9974 
o|contracted procedure: k9982 
o|contracted procedure: k9988 
o|contracted procedure: k9991 
o|contracted procedure: k10000 
o|contracted procedure: k10015 
o|contracted procedure: k10019 
o|contracted procedure: k10027 
o|contracted procedure: k10031 
o|contracted procedure: k10037 
o|contracted procedure: k10044 
o|contracted procedure: k10050 
o|contracted procedure: k10061 
o|contracted procedure: k10136 
o|contracted procedure: k10144 
o|contracted procedure: k10079 
o|contracted procedure: k10083 
o|contracted procedure: k10091 
o|contracted procedure: k10103 
o|contracted procedure: k10106 
o|contracted procedure: k10109 
o|contracted procedure: k10117 
o|contracted procedure: k10125 
o|contracted procedure: k10155 
o|contracted procedure: k10158 
o|contracted procedure: k10206 
o|contracted procedure: k10170 
o|contracted procedure: k10196 
o|contracted procedure: k10200 
o|contracted procedure: k10192 
o|contracted procedure: k10173 
o|contracted procedure: k10176 
o|contracted procedure: k10184 
o|contracted procedure: k10188 
o|contracted procedure: k10218 
o|contracted procedure: k10221 
o|contracted procedure: k10224 
o|contracted procedure: k10232 
o|contracted procedure: k10240 
o|contracted procedure: k10259 
o|contracted procedure: k10267 
o|contracted procedure: k10279 
o|contracted procedure: k10282 
o|contracted procedure: k10285 
o|contracted procedure: k10293 
o|contracted procedure: k10301 
o|contracted procedure: k10362 
o|contracted procedure: k10326 
o|contracted procedure: k10352 
o|contracted procedure: k10356 
o|contracted procedure: k10348 
o|contracted procedure: k10329 
o|contracted procedure: k10332 
o|contracted procedure: k10340 
o|contracted procedure: k10344 
o|contracted procedure: k10380 
o|contracted procedure: k10415 
o|contracted procedure: k10424 
o|contracted procedure: k10433 
o|contracted procedure: k10454 
o|contracted procedure: k10463 
o|contracted procedure: k10472 
o|contracted procedure: k10493 
o|contracted procedure: k10506 
o|contracted procedure: k10510 
o|contracted procedure: k10518 
o|contracted procedure: k10521 
o|contracted procedure: k10497 
o|contracted procedure: k10533 
o|contracted procedure: k10536 
o|contracted procedure: k10539 
o|contracted procedure: k10547 
o|contracted procedure: k10555 
o|contracted procedure: k10579 
o|contracted procedure: k10583 
o|contracted procedure: k10587 
o|contracted procedure: k10592 
o|contracted procedure: k10604 
o|contracted procedure: k10607 
o|contracted procedure: k10610 
o|contracted procedure: k10618 
o|contracted procedure: k10626 
o|contracted procedure: k10655 
o|contracted procedure: k10667 
o|contracted procedure: k10677 
o|contracted procedure: k10681 
o|contracted procedure: k10684 
o|contracted procedure: k10690 
o|contracted procedure: k10728 
o|contracted procedure: k10738 
o|contracted procedure: k10742 
o|contracted procedure: k10758 
o|contracted procedure: k10882 
o|contracted procedure: k10773 
o|contracted procedure: k10776 
o|contracted procedure: k10785 
o|contracted procedure: k10862 
o|contracted procedure: k10793 
o|contracted procedure: k10820 
o|contracted procedure: k10828 
o|contracted procedure: k10824 
o|contracted procedure: k10837 
o|contracted procedure: k10843 
o|contracted procedure: k10850 
o|contracted procedure: k10873 
o|contracted procedure: k10869 
o|contracted procedure: k10915 
o|contracted procedure: k10939 
o|contracted procedure: k10926 
o|contracted procedure: k10920 
o|contracted procedure: k10947 
o|contracted procedure: k10956 
o|contracted procedure: k10968 
o|contracted procedure: k10977 
o|contracted procedure: k10981 
o|contracted procedure: k10993 
o|contracted procedure: k11002 
o|contracted procedure: k11019 
o|contracted procedure: k11023 
o|contracted procedure: k11032 
o|contracted procedure: k11133 
o|contracted procedure: k11137 
o|contracted procedure: k11041 
o|contracted procedure: k11059 
o|contracted procedure: k11063 
o|contracted procedure: k11072 
o|contracted procedure: k11081 
o|contracted procedure: k11090 
o|contracted procedure: k11107 
o|contracted procedure: k11111 
o|contracted procedure: k11120 
o|contracted procedure: k11124 
o|contracted procedure: k11155 
o|contracted procedure: k11164 
o|contracted procedure: k11181 
o|contracted procedure: k11189 
o|contracted procedure: k11195 
o|contracted procedure: k11204 
o|contracted procedure: k11229 
o|contracted procedure: k11207 
o|contracted procedure: k11235 
o|contracted procedure: k11238 
o|contracted procedure: k11253 
o|contracted procedure: k11259 
o|contracted procedure: k11284 
o|contracted procedure: k11287 
o|contracted procedure: k11393 
o|contracted procedure: k11290 
o|contracted procedure: k11312 
o|contracted procedure: k11318 
o|contracted procedure: k11326 
o|contracted procedure: k11329 
o|contracted procedure: k11368 
o|contracted procedure: k11335 
o|contracted procedure: k11359 
o|contracted procedure: k11350 
o|contracted procedure: k11341 
o|contracted procedure: k11374 
o|contracted procedure: k11386 
o|contracted procedure: k11424 
o|contracted procedure: k11431 
o|contracted procedure: k11465 
o|contracted procedure: k11487 
o|contracted procedure: k11490 
o|contracted procedure: k11511 
o|contracted procedure: k11504 
o|inlining procedure: k11500 
o|inlining procedure: k11500 
o|contracted procedure: k11530 
o|contracted procedure: k11560 
o|contracted procedure: k11563 
o|contracted procedure: k11569 
o|contracted procedure: k11573 
o|contracted procedure: k11579 
o|contracted procedure: k11583 
o|contracted procedure: k11602 
o|contracted procedure: k11589 
o|contracted procedure: k11593 
o|contracted procedure: k11610 
o|contracted procedure: k11618 
o|contracted procedure: k11614 
o|contracted procedure: k11629 
o|contracted procedure: k11641 
o|contracted procedure: k11651 
o|contracted procedure: k11655 
o|contracted procedure: k11783 
o|contracted procedure: k11795 
o|contracted procedure: k11805 
o|contracted procedure: k11809 
o|contracted procedure: k11833 
o|contracted procedure: k11836 
o|contracted procedure: k11848 
o|contracted procedure: k11863 
o|contracted procedure: k11878 
o|contracted procedure: k11881 
o|contracted procedure: k11910 
o|contracted procedure: k11891 
o|contracted procedure: k11899 
o|contracted procedure: k11903 
o|contracted procedure: k11895 
o|contracted procedure: k11916 
o|contracted procedure: k11919 
o|contracted procedure: k11931 
o|contracted procedure: k11964 
o|contracted procedure: k11941 
o|contracted procedure: k11953 
o|contracted procedure: k11945 
o|contracted procedure: k11960 
o|contracted procedure: k11970 
o|contracted procedure: k11980 
o|contracted procedure: k11986 
o|contracted procedure: k12022 
o|contracted procedure: k11999 
o|contracted procedure: k12011 
o|contracted procedure: k12003 
o|contracted procedure: k12018 
o|contracted procedure: k12028 
o|contracted procedure: k12045 
o|contracted procedure: k12041 
o|contracted procedure: k12054 
o|contracted procedure: k12069 
o|contracted procedure: k12081 
o|contracted procedure: k12096 
o|contracted procedure: k12108 
o|contracted procedure: k12137 
o|contracted procedure: k12121 
o|contracted procedure: k12129 
o|contracted procedure: k12133 
o|contracted procedure: k12125 
o|contracted procedure: k12143 
o|contracted procedure: k12152 
o|contracted procedure: k12191 
o|contracted procedure: k12165 
o|contracted procedure: k12177 
o|contracted procedure: k12169 
o|contracted procedure: k12187 
o|contracted procedure: k12197 
o|contracted procedure: k12213 
o|contracted procedure: k12219 
o|contracted procedure: k12229 
o|contracted procedure: k12240 
o|contracted procedure: k12236 
o|contracted procedure: k12258 
o|contracted procedure: k12255 
o|contracted procedure: k12270 
o|contracted procedure: k12277 
o|contracted procedure: k12306 
o|contracted procedure: k12290 
o|contracted procedure: k12298 
o|contracted procedure: k12302 
o|contracted procedure: k12294 
o|contracted procedure: k12312 
o|contracted procedure: k12315 
o|contracted procedure: k12345 
o|contracted procedure: k12325 
o|contracted procedure: k12341 
o|contracted procedure: k12333 
o|contracted procedure: k12337 
o|contracted procedure: k12329 
o|contracted procedure: k12351 
o|contracted procedure: k12380 
o|contracted procedure: k12361 
o|contracted procedure: k12369 
o|contracted procedure: k12373 
o|contracted procedure: k12365 
o|contracted procedure: k12386 
o|contracted procedure: k12398 
o|contracted procedure: k12405 
o|contracted procedure: k12411 
o|contracted procedure: k12418 
o|contracted procedure: k12424 
o|contracted procedure: k12436 
o|contracted procedure: k12439 
o|contracted procedure: k12469 
o|contracted procedure: k12475 
o|contracted procedure: k12492 
o|contracted procedure: k12500 
o|contracted procedure: k12515 
o|contracted procedure: k12521 
o|contracted procedure: k12540 
o|contracted procedure: k12557 
o|contracted procedure: k12574 
o|contracted procedure: k12580 
o|contracted procedure: k12597 
o|contracted procedure: k12603 
o|contracted procedure: k12609 
o|contracted procedure: k12615 
o|contracted procedure: k12621 
o|contracted procedure: k12627 
o|contracted procedure: k12652 
o|contracted procedure: k12658 
o|contracted procedure: k12664 
o|contracted procedure: k12670 
o|contracted procedure: k12676 
o|contracted procedure: k12682 
o|contracted procedure: k12725 
o|contracted procedure: k12740 
o|contracted procedure: k12746 
o|contracted procedure: k12752 
o|contracted procedure: k12758 
o|contracted procedure: k12764 
o|contracted procedure: k12770 
o|contracted procedure: k12817 
o|contracted procedure: k12829 
o|contracted procedure: k12836 
o|contracted procedure: k12811 
o|contracted procedure: k12848 
o|contracted procedure: k12860 
o|contracted procedure: k12867 
o|contracted procedure: k12842 
o|contracted procedure: k12894 
o|contracted procedure: k12891 
o|contracted procedure: k12903 
o|contracted procedure: k12927 
o|contracted procedure: k12936 
o|contracted procedure: k12948 
o|contracted procedure: k12960 
o|contracted procedure: k12984 
o|contracted procedure: k12981 
o|contracted procedure: k12996 
o|contracted procedure: k13003 
o|contracted procedure: k13012 
o|contracted procedure: k13018 
o|contracted procedure: k13024 
o|contracted procedure: k13030 
o|contracted procedure: k13036 
o|contracted procedure: k13042 
o|contracted procedure: k13048 
o|contracted procedure: k13006 
o|contracted procedure: k13075 
o|contracted procedure: k13081 
o|contracted procedure: k13087 
o|contracted procedure: k13093 
o|contracted procedure: k13112 
o|contracted procedure: k13118 
o|contracted procedure: k13124 
o|contracted procedure: k13130 
o|contracted procedure: k13136 
o|contracted procedure: k13159 
o|contracted procedure: k13165 
o|contracted procedure: k13171 
o|contracted procedure: k13177 
o|contracted procedure: k13183 
o|contracted procedure: k13189 
o|contracted procedure: k13195 
o|contracted procedure: k13201 
o|contracted procedure: k13207 
o|contracted procedure: k13213 
o|contracted procedure: k13246 
o|contracted procedure: k13252 
o|contracted procedure: k13258 
o|contracted procedure: k13264 
o|contracted procedure: k13270 
o|contracted procedure: k13276 
o|contracted procedure: k13282 
o|contracted procedure: k13288 
o|contracted procedure: k13294 
o|contracted procedure: k13300 
o|contracted procedure: k13306 
o|contracted procedure: k13365 
o|contracted procedure: k13377 
o|contracted procedure: k13401 
o|contracted procedure: k13398 
o|contracted procedure: k13413 
o|contracted procedure: k13420 
o|contracted procedure: k13432 
o|contracted procedure: k13438 
o|contracted procedure: k13444 
o|contracted procedure: k13450 
o|contracted procedure: k13456 
o|contracted procedure: k13462 
o|contracted procedure: k13490 
o|contracted procedure: k13496 
o|contracted procedure: k13502 
o|contracted procedure: k13519 
o|contracted procedure: k13525 
o|contracted procedure: k13531 
o|contracted procedure: k13537 
o|contracted procedure: k13543 
o|contracted procedure: k13549 
o|contracted procedure: k13555 
o|contracted procedure: k13561 
o|contracted procedure: k13567 
o|contracted procedure: k13573 
o|contracted procedure: k13579 
o|contracted procedure: k13585 
o|contracted procedure: k13591 
o|contracted procedure: k13597 
o|contracted procedure: k13603 
o|contracted procedure: k13609 
o|contracted procedure: k13615 
o|contracted procedure: k13621 
o|contracted procedure: k13627 
o|contracted procedure: k13633 
o|contracted procedure: k13639 
o|contracted procedure: k13645 
o|contracted procedure: k13651 
o|contracted procedure: k13657 
o|contracted procedure: k13663 
o|contracted procedure: k13669 
o|contracted procedure: k13675 
o|contracted procedure: k13681 
o|contracted procedure: k13687 
o|contracted procedure: k13693 
o|contracted procedure: k13699 
o|contracted procedure: k13789 
o|contracted procedure: k13792 
o|contracted procedure: k13799 
o|contracted procedure: k13805 
o|contracted procedure: k13812 
o|contracted procedure: k13818 
o|contracted procedure: k13821 
o|contracted procedure: k13828 
o|contracted procedure: k13834 
o|contracted procedure: k13837 
o|contracted procedure: k13844 
o|contracted procedure: k13850 
o|contracted procedure: k13861 
o|contracted procedure: k13857 
o|contracted procedure: k13867 
o|contracted procedure: k13874 
o|contracted procedure: k13880 
o|contracted procedure: k13887 
o|contracted procedure: k13893 
o|contracted procedure: k13906 
o|contracted procedure: k13993 
o|contracted procedure: k13912 
o|contracted procedure: k13915 
o|contracted procedure: k13921 
o|contracted procedure: k13924 
o|contracted procedure: k13962 
o|contracted procedure: k13934 
o|contracted procedure: k13958 
o|contracted procedure: k13942 
o|contracted procedure: k13950 
o|contracted procedure: k13954 
o|contracted procedure: k13946 
o|contracted procedure: k13938 
o|contracted procedure: k13968 
o|contracted procedure: k13975 
o|contracted procedure: k13979 
o|contracted procedure: k14016 
o|contracted procedure: k13996 
o|contracted procedure: k14012 
o|contracted procedure: k14002 
o|contracted procedure: k14006 
o|contracted procedure: k14057 
o|contracted procedure: k14063 
o|contracted procedure: k14066 
o|contracted procedure: k14072 
o|contracted procedure: k14081 
o|contracted procedure: k14084 
o|contracted procedure: k14090 
o|contracted procedure: k14098 
o|contracted procedure: k14101 
o|contracted procedure: k14107 
o|contracted procedure: k14113 
o|contracted procedure: k14121 
o|contracted procedure: k14127 
o|contracted procedure: k14133 
o|contracted procedure: k14141 
o|contracted procedure: k14147 
o|contracted procedure: k14156 
o|contracted procedure: k14163 
o|contracted procedure: k14174 
o|contracted procedure: k14180 
o|contracted procedure: k14186 
o|contracted procedure: k14192 
o|contracted procedure: k14198 
o|contracted procedure: k14204 
o|contracted procedure: k14210 
o|contracted procedure: k14216 
o|contracted procedure: k14222 
o|contracted procedure: k14231 
o|contracted procedure: k14237 
o|contracted procedure: k14243 
o|contracted procedure: k14252 
o|contracted procedure: k14255 
o|contracted procedure: k14261 
o|contracted procedure: k14270 
o|contracted procedure: k14276 
o|contracted procedure: k14283 
o|contracted procedure: k14292 
o|contracted procedure: k14299 
o|contracted procedure: k14305 
o|contracted procedure: k14311 
o|contracted procedure: k14314 
o|contracted procedure: k14328 
o|contracted procedure: k14334 
o|contracted procedure: k14353 
o|contracted procedure: k14375 
o|contracted procedure: k14381 
o|contracted procedure: k14402 
o|contracted procedure: k14408 
o|contracted procedure: k14414 
o|contracted procedure: k14420 
o|contracted procedure: k14426 
o|contracted procedure: k14432 
o|contracted procedure: k14473 
o|contracted procedure: k14479 
o|contracted procedure: k14485 
o|contracted procedure: k14491 
o|contracted procedure: k14497 
o|contracted procedure: k14503 
o|contracted procedure: k14550 
o|contracted procedure: k14556 
o|contracted procedure: k14562 
o|contracted procedure: k14568 
o|contracted procedure: k14574 
o|contracted procedure: k14580 
o|contracted procedure: k14628 
o|contracted procedure: k14636 
o|contracted procedure: k14642 
o|contracted procedure: k14645 
o|contracted procedure: k14706 
o|contracted procedure: k14648 
o|contracted procedure: k14654 
o|contracted procedure: k14666 
o|contracted procedure: k14676 
o|contracted procedure: k14680 
o|contracted procedure: k14687 
o|contracted procedure: k14690 
o|contracted procedure: k14697 
o|contracted procedure: k14712 
o|contracted procedure: k14718 
o|contracted procedure: k14730 
o|contracted procedure: k14740 
o|contracted procedure: k14744 
o|contracted procedure: k14747 
o|contracted procedure: k14780 
o|contracted procedure: k14788 
o|contracted procedure: k14796 
o|contracted procedure: k14802 
o|contracted procedure: k14811 
o|contracted procedure: k14814 
o|contracted procedure: k14820 
o|contracted procedure: k14840 
o|contracted procedure: k14843 
o|contracted procedure: k14856 
o|contracted procedure: k1485317613 
o|contracted procedure: k1485317617 
o|contracted procedure: k14866 
o|contracted procedure: k14876 
o|contracted procedure: k14884 
o|contracted procedure: k14890 
o|contracted procedure: k14897 
o|contracted procedure: k14907 
o|contracted procedure: k14925 
o|contracted procedure: k14931 
o|contracted procedure: k14937 
o|contracted procedure: k14964 
o|contracted procedure: k14976 
o|contracted procedure: k14986 
o|contracted procedure: k14990 
o|contracted procedure: k15023 
o|contracted procedure: k15002 
o|contracted procedure: k15014 
o|contracted procedure: k15018 
o|contracted procedure: k15063 
o|contracted procedure: k15029 
o|contracted procedure: k15041 
o|contracted procedure: k15049 
o|contracted procedure: k15059 
o|contracted procedure: k15081 
o|contracted procedure: k15127 
o|inlining procedure: k15124 
o|contracted procedure: k15176 
o|contracted procedure: k15184 
o|contracted procedure: k15197 
o|contracted procedure: k15208 
o|contracted procedure: k15220 
o|contracted procedure: k15234 
o|contracted procedure: k15238 
o|contracted procedure: k15305 
o|contracted procedure: k15308 
o|contracted procedure: k15311 
o|contracted procedure: k15330 
o|contracted procedure: k15326 
o|contracted procedure: k15339 
o|contracted procedure: k15385 
o|contracted procedure: k15378 
o|contracted procedure: k15354 
o|contracted procedure: k15366 
o|contracted procedure: k15369 
o|contracted procedure: k15372 
o|contracted procedure: k15391 
o|contracted procedure: k15408 
o|contracted procedure: k15548 
o|contracted procedure: k15556 
o|contracted procedure: k15414 
o|contracted procedure: k15417 
o|contracted procedure: k15423 
o|contracted procedure: k15440 
o|contracted procedure: k15459 
o|contracted procedure: k15465 
o|contracted procedure: k15489 
o|contracted procedure: k15477 
o|contracted procedure: k15484 
o|contracted procedure: k15568 
o|contracted procedure: k15590 
o|contracted procedure: k15586 
o|contracted procedure: k15571 
o|contracted procedure: k15574 
o|contracted procedure: k15582 
o|contracted procedure: k15602 
o|contracted procedure: k15605 
o|contracted procedure: k15608 
o|contracted procedure: k15616 
o|contracted procedure: k15624 
o|contracted procedure: k15405 
o|contracted procedure: k15649 
o|contracted procedure: k15655 
o|contracted procedure: k15664 
o|contracted procedure: k15667 
o|contracted procedure: k15674 
o|contracted procedure: k1564017106 
o|contracted procedure: k1564017113 
o|contracted procedure: k1564017122 
o|contracted procedure: k15726 
o|contracted procedure: k15734 
o|contracted procedure: k15742 
o|contracted procedure: k15748 
o|contracted procedure: k15777 
o|contracted procedure: k15783 
o|contracted procedure: k15792 
o|contracted procedure: k15816 
o|contracted procedure: k15832 
o|contracted procedure: k15836 
o|contracted procedure: k15840 
o|contracted procedure: k15849 
o|contracted procedure: k15859 
o|contracted procedure: k15863 
o|contracted procedure: k15879 
o|inlining procedure: k15883 
o|inlining procedure: k15883 
o|contracted procedure: k15899 
o|contracted procedure: k15906 
o|contracted procedure: k15921 
o|contracted procedure: k15934 
o|contracted procedure: k15958 
o|contracted procedure: k15986 
o|contracted procedure: k16015 
o|contracted procedure: k16021 
o|contracted procedure: k16024 
o|contracted procedure: k16044 
o|contracted procedure: k16038 
o|contracted procedure: k16064 
o|contracted procedure: k16058 
o|contracted procedure: k16092 
o|contracted procedure: k16098 
o|contracted procedure: k16117 
o|contracted procedure: k16111 
o|contracted procedure: k16206 
o|contracted procedure: k16216 
o|contracted procedure: k16220 
o|contracted procedure: k16171 
o|contracted procedure: k16185 
o|contracted procedure: k16189 
o|contracted procedure: k16268 
o|contracted procedure: k16252 
o|contracted procedure: k16319 
o|contracted procedure: k16328 
o|simplifications: ((let . 157)) 
o|removed binding forms: 1210 
o|inlining procedure: k9781 
o|replaced variables: 444 
o|removed binding forms: 4 
o|simplifications: ((if . 17)) 
o|replaced variables: 7 
o|removed binding forms: 283 
o|contracted procedure: k15620 
o|contracted procedure: k15693 
o|simplifications: ((let . 1)) 
o|removed binding forms: 3 
o|replaced variables: 2 
o|removed binding forms: 1 
o|direct leaf routine/allocation: loop508 0 
o|direct leaf routine/allocation: g23072308 0 
o|direct leaf routine/allocation: g24652472 20 
o|converted assignments to bindings: (loop508) 
o|contracted procedure: "(support.scm:967) k11644" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
o|customizable procedures: (for-each-loop39763991 loop3856 k15872 g37853792 for-each-loop37843802 doloop38153816 loop3754 map-loop36453666 map-loop36763697 resolve3581 loop3593 loop3534 k15008 g35093516 for-each-loop35083519 k14805 walkeach3464 walk3463 k14715 for-each-loop34423452 k14683 k14651 for-each-loop34183428 k14075 k14150 k14225 k14246 k14264 k14286 k13899 k13368 k13380 k13423 g31483149 k12930 k12939 k12951 k12963 g29912992 g28722873 k11851 k11866 k11989 k12031 k12057 k12084 k12111 k12155 k12200 k12280 repeat2586 g27952796 k12173 k12007 k11949 for-each-loop25622574 for-each-loop24642486 k11450 k11409 k11198 matchn2298 loop2327 match12297 resolve2296 loop2273 k10779 k10816 for-each-loop22242236 for-each-loop22462264 map-loop21632180 map-loop21242144 rec2075 map-loop18521871 g20452054 map-loop20392064 g19391948 map-loop19331953 map-loop19631982 g20062015 map-loop20002025 walk1882 map-loop18001817 k9757 fold1777 k8818 k9422 map-loop17491766 map-loop17231740 map-loop16941711 loop1675 map-loop16511668 map-loop16251642 loop1616 map-loop15761593 map-loop15551600 map-loop15131530 map-loop14841501 map-loop14271444 k8403 k8598 map-loop13961413 map-loop13501367 map-loop13191336 map-loop12701287 map-loop12261243 k8085 map-loop11921209 loop1159 map-loop10941112 g11271136 map-loop11211139 k7663 map-loop10571074 k6851 k7068 k7147 loop779 k6916 k6953 k6990 map-loop740757 k6745 g727728 k6668 for-each-loop534574 for-each-loop581621 for-each-loop628653 tmp14370 tmp24371 k6074 loop463 k5946 loop376 fold369 k5712 k5566 k5573 loop305 loop288 loop238 loop227 loop212 err211 loop200 k5127 g169176 for-each-loop168186 collect99 g104111 for-each-loop103123 text46 dump47 for-each-loop5068) 
o|calls to known targets: 490 
o|identified direct recursive calls: f_5290 1 
o|identified direct recursive calls: f_5340 1 
o|identified direct recursive calls: f_5374 1 
o|identified direct recursive calls: f_5492 1 
o|identified direct recursive calls: f_5761 1 
o|identified direct recursive calls: f_6237 1 
o|identified direct recursive calls: f_6815 1 
o|identified direct recursive calls: f_7545 4 
o|identified direct recursive calls: f_9012 1 
o|identified direct recursive calls: f_10165 1 
o|identified direct recursive calls: f_9882 1 
o|identified direct recursive calls: f_10321 1 
o|identified direct recursive calls: f_10375 1 
o|identified direct recursive calls: f_10988 1 
o|identified direct recursive calls: f_11636 1 
o|identified direct recursive calls: f_15036 1 
o|identified direct recursive calls: f_15563 1 
o|identified direct recursive calls: f_15597 1 
o|fast box initializations: 85 
o|dropping unused closure argument: f_15147 
o|dropping unused closure argument: f_6237 
*/
/* end of file */
