/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-cc.org
   2017-02-19 13:17
   Version 4.12.0 (rev 6ea24b6)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2017-02-19 on yves.more-magic.net (Linux)
   command line: expand.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[358];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,108,111,111,107,117,112,32,115,101,50,52,55,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,26),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,50,54,50,32,115,101,50,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,51,49,32,105,51,51,51,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,51,48,50,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,21),40,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,50,57,57,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,49,55,32,103,52,50,57,52,51,57,32,103,52,51,48,52,52,48,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,56,48,32,103,51,56,55,52,48,56,32,103,51,56,56,52,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,53,52,32,103,51,54,54,51,55,50,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,101,120,116,101,110,100,45,115,101,32,115,101,51,52,52,32,118,97,114,115,51,52,53,32,46,32,116,109,112,51,52,51,51,52,54,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,11),40,103,52,54,52,32,97,52,54,54,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,101,52,54,56,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,49,32,115,121,109,52,53,51,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,103,108,111,98,97,108,105,122,101,32,115,121,109,52,53,48,32,115,101,52,53,49,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,101,110,115,117,114,101,45,116,114,97,110,115,102,111,114,109,101,114,32,116,52,56,52,32,46,32,116,109,112,52,56,51,52,56,53,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,103,53,48,55,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,61),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,52,57,54,32,115,101,52,57,55,32,116,114,97,110,115,102,111,114,109,101,114,52,57,56,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,53,49,53,32,110,101,119,53,49,54,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,109,97,99,114,111,63,32,115,121,109,53,50,51,32,46,32,116,109,112,53,50,50,53,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,53,51,56,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,53,51,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,53,52,54,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,53,55,50,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,51,53,57,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,13),40,97,52,51,53,51,32,101,120,53,54,57,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,17),40,102,95,52,52,56,56,32,105,110,112,117,116,53,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,52,52,57,51,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,52,52,57,56,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,52,53,48,52,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,10),40,116,109,112,49,51,48,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,52,53,49,55,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,21),40,116,109,112,50,51,48,56,53,32,97,114,103,115,53,54,51,53,57,53,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,52,53,52,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,97,52,51,52,55,32,107,53,54,50,53,54,56,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,52),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,53,53,51,32,104,97,110,100,108,101,114,53,53,52,32,101,120,112,53,53,53,32,115,101,53,53,54,32,99,115,53,53,55,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,53,57,56,32,101,120,112,53,57,57,32,109,100,101,102,54,48,48,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,54,50,32,103,54,55,52,54,56,48,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,51,53,32,103,54,52,55,54,53,52,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,103,54,57,53,32,99,115,54,57,55,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,54,48,57,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,53,52,56,32,100,115,101,53,52,57,32,99,115,63,53,53,48,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,52,56,53,48,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,32),40,97,52,56,53,54,32,101,120,112,50,55,50,57,55,51,48,55,51,51,32,109,55,51,49,55,51,50,55,51,52,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,55,50,56,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,27),40,101,120,112,97,110,100,32,101,120,112,55,49,53,32,46,32,116,109,112,55,49,52,55,49,54,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,55,52,50,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,55,52,48,41,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,55,54,53,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,11),40,103,55,57,54,32,107,56,48,55,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,57,48,32,103,56,48,50,56,49,57,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,55,55,53,32,114,101,113,55,55,54,32,111,112,116,55,55,55,32,107,101,121,55,55,56,32,108,108,105,115,116,55,55,57,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,55,53,57,32,98,111,100,121,55,54,48,32,101,114,114,104,55,54,49,32,115,101,55,54,50,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,100,101,102,106,97,109,45,101,114,114,111,114,32,102,111,114,109,56,56,55,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,57,50,55,32,103,57,51,57,57,53,50,32,103,57,52,48,57,53,51,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,56,57,56,32,103,57,49,48,57,49,54,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,31),40,97,53,53,53,53,32,118,97,114,115,56,57,49,32,97,114,103,99,56,57,50,32,114,101,115,116,56,57,51,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,60),40,35,35,115,121,115,35,101,120,112,97,110,100,45,109,117,108,116,105,112,108,101,45,118,97,108,117,101,115,45,97,115,115,105,103,110,109,101,110,116,32,102,111,114,109,97,108,115,56,56,57,32,101,120,112,114,56,57,48,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,99,111,109,112,32,105,100,57,57,51,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,98,111,100,121,50,49,48,49,48,32,101,120,112,115,49,48,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,44),40,109,97,112,45,108,111,111,112,49,48,55,52,32,103,49,48,56,54,49,49,48,50,32,103,49,48,56,55,49,49,48,51,32,103,49,48,56,56,49,49,48,52,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,50,54,32,103,49,48,51,56,49,48,54,54,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,97,54,48,56,49,32,97,49,48,54,48,32,95,49,48,54,49,32,95,49,48,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,31),40,102,111,108,100,108,49,48,52,57,32,103,49,48,53,48,49,48,53,52,32,103,49,48,52,56,49,48,53,53,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,43),40,102,105,110,105,32,118,97,114,115,49,48,48,52,32,118,97,108,115,49,48,48,53,32,109,118,97,114,115,49,48,48,54,32,98,111,100,121,49,48,48,55,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,51,52,32,103,49,49,52,54,49,49,53,50,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,108,111,111,112,32,98,111,100,121,49,49,50,50,32,100,101,102,115,49,49,50,51,32,100,111,110,101,49,49,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,50),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,49,49,49,55,32,118,97,108,115,49,49,49,56,32,109,118,97,114,115,49,49,49,57,32,98,111,100,121,49,49,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,50,32,120,49,49,56,56,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,43),40,108,111,111,112,32,98,111,100,121,49,49,55,50,32,118,97,114,115,49,49,55,51,32,118,97,108,115,49,49,55,52,32,109,118,97,114,115,49,49,55,53,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,17),40,101,120,112,97,110,100,32,98,111,100,121,49,49,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,57,55,54,32,46,32,116,109,112,57,55,53,57,55,55,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,103,49,50,51,48,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,19),40,109,119,97,108,107,32,120,49,50,49,56,32,112,49,50,49,57,41,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,43),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,49,50,49,50,32,112,97,116,49,50,49,51,32,118,97,114,115,49,50,49,52,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,104,101,97,100,49,50,52,50,32,98,111,100,121,49,50,52,51,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,49,50,51,55,32,98,111,100,121,49,50,51,56,32,115,101,49,50,51,57,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,25),40,115,121,110,116,97,120,45,101,114,114,111,114,32,46,32,97,114,103,115,49,50,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,16),40,111,117,116,115,116,114,32,115,116,114,49,50,55,54,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,49,50,57,53,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,100,101,102,115,49,50,54,53,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,99,120,49,50,55,56,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,47,99,111,110,116,101,120,116,32,109,115,103,49,50,54,48,32,97,114,103,49,50,54,49,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,115,121,110,116,97,120,45,114,117,108,101,115,45,109,105,115,109,97,116,99,104,32,105,110,112,117,116,49,51,48,56,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,103,49,51,50,49,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,49,51,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,51,52,57,32,112,114,101,100,49,51,53,48,32,109,115,103,49,51,53,49,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,51,53,50,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,51,54,48,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,51,53,53,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,51,55,50,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,51,57,56,32,120,49,52,48,48,32,110,49,52,48,49,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,97,55,51,54,49,32,121,49,52,49,52,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,51,56,52,32,112,49,51,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,51,51,49,32,101,120,112,49,51,51,50,32,112,97,116,49,51,51,51,32,46,32,116,109,112,49,51,51,48,49,51,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,13),40,103,49,52,53,50,32,97,49,52,53,52,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,52,51,56,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,53,48,53,32,105,49,53,48,55,32,102,49,53,48,56,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,103,49,53,54,48,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,7),40,103,49,53,54,57,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,52,57,51,32,115,50,49,52,57,52,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,20),40,97,115,115,113,45,114,101,118,101,114,115,101,32,108,49,53,56,51,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,23),40,109,105,114,114,111,114,45,114,101,110,97,109,101,32,115,121,109,49,53,56,56,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,31),40,97,55,52,55,55,32,102,111,114,109,49,52,50,55,32,115,101,49,52,50,56,32,100,115,101,49,52,50,57,41,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,59),40,109,97,107,101,45,101,114,47,105,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,52,50,53,32,101,120,112,108,105,99,105,116,45,114,101,110,97,109,105,110,103,63,49,52,50,54,41,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,34),40,101,114,45,109,97,99,114,111,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,54,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,34),40,105,114,45,109,97,99,114,111,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,54,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,33),40,108,111,111,112,32,98,115,49,55,56,52,32,115,101,101,110,49,55,56,53,32,119,97,114,110,101,100,49,55,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,59),40,99,104,101,99,107,45,102,111,114,45,109,117,108,116,105,112,108,101,45,98,105,110,100,105,110,103,115,32,98,105,110,100,105,110,103,115,49,55,56,48,32,102,111,114,109,49,55,56,49,32,108,111,99,49,55,56,50,41,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,14),40,102,95,56,51,50,54,32,120,50,52,53,55,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,52,54,52,32,103,50,52,55,54,50,52,56,50,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,18),40,102,95,56,51,51,50,32,114,117,108,101,115,50,52,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,13),40,97,56,52,54,51,32,120,50,52,57,54,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,17),40,102,95,56,52,50,54,32,114,117,108,101,50,52,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,48),40,102,95,56,52,57,50,32,105,110,112,117,116,50,52,57,55,32,112,97,116,116,101,114,110,50,52,57,56,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,52,57,57,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,30),40,102,95,56,54,55,51,32,105,110,112,117,116,50,53,51,55,32,112,97,116,116,101,114,110,50,53,51,56,41,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,13),40,97,56,56,53,56,32,120,50,53,53,57,41,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,57),40,102,95,56,56,48,48,32,112,97,116,116,101,114,110,50,53,52,54,32,112,97,116,104,50,53,52,55,32,109,97,112,105,116,50,53,52,56,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,53,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,53,57,56,32,100,50,54,48,48,32,103,101,110,50,54,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,37),40,102,95,56,57,52,48,32,116,101,109,112,108,97,116,101,50,53,55,53,32,100,105,109,50,53,55,54,32,101,110,118,50,53,55,55,41,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,55),40,102,95,57,49,51,50,32,112,97,116,116,101,114,110,50,54,49,56,32,100,105,109,50,54,49,57,32,118,97,114,115,50,54,50,48,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,54,50,49,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,46),40,102,95,57,50,48,57,32,116,101,109,112,108,97,116,101,50,54,50,54,32,100,105,109,50,54,50,55,32,101,110,118,50,54,50,56,32,102,114,101,101,50,54,50,57,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,32),40,102,95,57,50,57,56,32,112,50,54,51,55,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,54,51,56,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,50,54,32,112,97,116,116,101,114,110,50,54,52,52,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,53,48,32,112,97,116,116,101,114,110,50,54,52,55,41,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,55,48,32,112,97,116,116,101,114,110,50,54,52,56,41,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,52,48,48,32,114,117,108,101,115,50,52,48,49,32,115,117,98,107,101,121,119,111,114,100,115,50,52,48,50,32,114,50,52,48,51,32,99,50,52,48,52,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,50,55,50,48,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,50,55,49,49,32,46,32,116,109,112,50,55,49,48,50,55,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,16),40,103,50,55,52,49,32,115,100,101,102,50,55,53,48,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,55,52,48,32,103,50,55,52,55,50,55,53,50,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,102,105,120,117,112,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,115,101,50,55,51,48,32,46,32,116,109,112,50,55,50,57,50,55,51,49,41,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,27),40,97,57,53,53,55,32,101,120,112,50,51,56,56,32,114,50,51,56,57,32,99,50,51,57,48,41,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,25),40,97,57,53,57,51,32,120,50,51,56,50,32,114,50,51,56,51,32,99,50,51,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,25),40,97,57,54,50,48,32,120,50,51,55,49,32,114,50,51,55,50,32,99,50,51,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,25),40,97,57,54,53,48,32,120,50,51,51,51,32,114,50,51,51,52,32,99,50,51,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,25),40,97,57,56,51,48,32,120,50,51,50,55,32,114,50,51,50,56,32,99,50,51,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,25),40,97,57,56,53,54,32,120,50,51,50,48,32,114,50,51,50,49,32,99,50,51,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,25),40,97,57,56,54,57,32,120,50,51,49,51,32,114,50,51,49,52,32,99,50,51,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,50,51,55,41,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,50,51,56,41,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,50,55,49,32,103,50,50,56,51,50,50,57,48,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,50,54,52,41};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,28),40,97,57,56,56,50,32,102,111,114,109,50,50,50,55,32,114,50,50,50,56,32,99,50,50,50,57,41,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,29),40,97,49,48,49,55,52,32,102,111,114,109,50,50,50,48,32,114,50,50,50,49,32,99,50,50,50,50,41,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,29),40,97,49,48,49,57,53,32,102,111,114,109,50,50,49,51,32,114,50,50,49,52,32,99,50,50,49,53,41,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,50,49,51,56,32,110,50,49,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,50,49,52,48,32,110,50,49,52,49,41,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,15),40,103,50,49,57,49,32,101,110,118,50,49,57,51,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,15),40,103,50,49,57,56,32,101,110,118,50,50,48,48,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,50,49,56,52,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,29),40,97,49,48,50,50,56,32,102,111,114,109,50,49,50,57,32,114,50,49,51,48,32,99,50,49,51,49,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,49,48,51,32,103,50,49,49,53,50,49,50,50,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,48,54,57,32,103,50,48,56,49,50,48,56,56,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,29),40,97,49,48,53,49,57,32,102,111,114,109,50,48,53,55,32,114,50,48,53,56,32,99,50,48,53,57,41,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,50,48,52,56,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,29),40,97,49,48,55,49,53,32,102,111,114,109,50,48,52,50,32,114,50,48,52,51,32,99,50,48,52,52,41,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,7),40,103,50,48,49,48,41,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,48,48,52,32,103,50,48,49,54,50,48,50,54,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,57,56,49,32,101,108,115,101,63,49,57,56,50,41,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,29),40,97,49,48,55,54,54,32,102,111,114,109,49,57,54,55,32,114,49,57,54,56,32,99,49,57,54,57,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,56,54,32,101,108,115,101,63,49,56,56,55,41,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,29),40,97,49,48,57,57,49,32,102,111,114,109,49,56,55,56,32,114,49,56,55,57,32,99,49,56,56,48,41,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,29),40,97,49,49,51,54,51,32,102,111,114,109,49,56,54,56,32,114,49,56,54,57,32,99,49,56,55,48,41,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,29),40,97,49,49,52,49,53,32,102,111,114,109,49,56,53,57,32,114,49,56,54,48,32,99,49,56,54,49,41,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,53,50,32,120,49,56,52,51,32,114,49,56,52,52,32,99,49,56,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,57,54,32,120,49,56,51,53,32,114,49,56,51,54,32,99,49,56,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,49,56,32,120,49,56,50,55,32,114,49,56,50,56,32,99,49,56,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,52,48,32,120,49,56,49,57,32,114,49,56,50,48,32,99,49,56,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,54,50,32,120,49,56,49,49,32,114,49,56,49,50,32,99,49,56,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,56,52,32,120,49,55,57,55,32,114,49,55,57,56,32,99,49,55,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,29),40,97,49,49,54,51,54,32,102,111,114,109,49,55,52,57,32,114,49,55,53,48,32,99,49,55,53,49,41,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,55,50,49,41,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,51,57,32,120,49,55,49,55,32,114,49,55,49,56,32,99,49,55,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,26),40,97,49,49,56,53,56,32,120,49,55,49,48,32,114,49,55,49,49,32,99,49,55,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,26),40,97,49,49,56,55,53,32,120,49,55,48,51,32,114,49,55,48,52,32,99,49,55,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,26),40,97,49,49,56,57,50,32,120,49,54,57,54,32,114,49,54,57,55,32,99,49,54,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,48,57,32,120,49,54,56,57,32,114,49,54,57,48,32,99,49,54,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,50,54,32,120,49,54,56,50,32,114,49,54,56,51,32,99,49,54,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,50),40,97,49,49,57,52,51,32,103,49,54,55,48,49,54,55,49,49,54,55,54,32,103,49,54,55,50,49,54,55,51,49,54,55,55,32,103,49,54,55,52,49,54,55,53,49,54,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,50),40,97,49,49,57,53,51,32,103,49,54,53,54,49,54,53,55,49,54,54,50,32,103,49,54,53,56,49,54,53,57,49,54,54,51,32,103,49,54,54,48,49,54,54,49,49,54,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,50),40,97,49,49,57,54,51,32,103,49,54,52,50,49,54,52,51,49,54,52,56,32,103,49,54,52,52,49,54,52,53,49,54,52,57,32,103,49,54,52,54,49,54,52,55,49,54,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word *av) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word *av) C_noret;
C_noret_decl(f_4919)
static void C_fcall f_4919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9000)
static void C_ccall f_9000(C_word c,C_word *av) C_noret;
C_noret_decl(f_9003)
static void C_fcall f_9003(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word *av) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word *av) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word *av) C_noret;
C_noret_decl(f_11775)
static void C_ccall f_11775(C_word c,C_word *av) C_noret;
C_noret_decl(f_11778)
static void C_ccall f_11778(C_word c,C_word *av) C_noret;
C_noret_decl(f_6288)
static void C_fcall f_6288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11910)
static void C_ccall f_11910(C_word c,C_word *av) C_noret;
C_noret_decl(f_11914)
static void C_ccall f_11914(C_word c,C_word *av) C_noret;
C_noret_decl(f_9050)
static void C_fcall f_9050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word *av) C_noret;
C_noret_decl(f_4388)
static void C_fcall f_4388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11416)
static void C_ccall f_11416(C_word c,C_word *av) C_noret;
C_noret_decl(f_11414)
static void C_ccall f_11414(C_word c,C_word *av) C_noret;
C_noret_decl(f_11908)
static void C_ccall f_11908(C_word c,C_word *av) C_noret;
C_noret_decl(f_5852)
static void C_ccall f_5852(C_word c,C_word *av) C_noret;
C_noret_decl(f_4371)
static void C_fcall f_4371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11447)
static void C_ccall f_11447(C_word c,C_word *av) C_noret;
C_noret_decl(f_10730)
static void C_fcall f_10730(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11952)
static void C_ccall f_11952(C_word c,C_word *av) C_noret;
C_noret_decl(f_10720)
static void C_ccall f_10720(C_word c,C_word *av) C_noret;
C_noret_decl(f_11954)
static void C_ccall f_11954(C_word c,C_word *av) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word *av) C_noret;
C_noret_decl(f_11942)
static void C_ccall f_11942(C_word c,C_word *av) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word *av) C_noret;
C_noret_decl(f_10714)
static void C_ccall f_10714(C_word c,C_word *av) C_noret;
C_noret_decl(f_11944)
static void C_ccall f_11944(C_word c,C_word *av) C_noret;
C_noret_decl(f_5810)
static void C_fcall f_5810(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9029)
static void C_fcall f_9029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10716)
static void C_ccall f_10716(C_word c,C_word *av) C_noret;
C_noret_decl(f_9027)
static void C_ccall f_9027(C_word c,C_word *av) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word *av) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word *av) C_noret;
C_noret_decl(f_5195)
static void C_fcall f_5195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word *av) C_noret;
C_noret_decl(f_11931)
static void C_ccall f_11931(C_word c,C_word *av) C_noret;
C_noret_decl(f_11406)
static void C_ccall f_11406(C_word c,C_word *av) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word *av) C_noret;
C_noret_decl(f_5841)
static void C_fcall f_5841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word *av) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word *av) C_noret;
C_noret_decl(f_11134)
static void C_ccall f_11134(C_word c,C_word *av) C_noret;
C_noret_decl(f_11927)
static void C_ccall f_11927(C_word c,C_word *av) C_noret;
C_noret_decl(f_11925)
static void C_ccall f_11925(C_word c,C_word *av) C_noret;
C_noret_decl(f_5130)
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9944)
static void C_ccall f_9944(C_word c,C_word *av) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word *av) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word *av) C_noret;
C_noret_decl(f_10767)
static void C_ccall f_10767(C_word c,C_word *av) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word *av) C_noret;
C_noret_decl(f_10755)
static void C_ccall f_10755(C_word c,C_word *av) C_noret;
C_noret_decl(f_11364)
static void C_ccall f_11364(C_word c,C_word *av) C_noret;
C_noret_decl(f_11362)
static void C_ccall f_11362(C_word c,C_word *av) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word *av) C_noret;
C_noret_decl(f_10489)
static void C_ccall f_10489(C_word c,C_word *av) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word *av) C_noret;
C_noret_decl(f_9901)
static void C_fcall f_9901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word *av) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word *av) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word *av) C_noret;
C_noret_decl(f_9281)
static void C_ccall f_9281(C_word c,C_word *av) C_noret;
C_noret_decl(f_7921)
static void C_ccall f_7921(C_word c,C_word *av) C_noret;
C_noret_decl(f_11453)
static void C_ccall f_11453(C_word c,C_word *av) C_noret;
C_noret_decl(f_11457)
static void C_ccall f_11457(C_word c,C_word *av) C_noret;
C_noret_decl(f_11451)
static void C_ccall f_11451(C_word c,C_word *av) C_noret;
C_noret_decl(f_11328)
static void C_ccall f_11328(C_word c,C_word *av) C_noret;
C_noret_decl(f_10791)
static void C_ccall f_10791(C_word c,C_word *av) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word *av) C_noret;
C_noret_decl(f_11312)
static void C_ccall f_11312(C_word c,C_word *av) C_noret;
C_noret_decl(f_6135)
static void C_fcall f_6135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8426)
static void C_ccall f_8426(C_word c,C_word *av) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word *av) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word *av) C_noret;
C_noret_decl(f_7903)
static void C_fcall f_7903(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11300)
static void C_ccall f_11300(C_word c,C_word *av) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word *av) C_noret;
C_noret_decl(f_5692)
static void C_fcall f_5692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word *av) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454(C_word c,C_word *av) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word *av) C_noret;
C_noret_decl(f_8433)
static void C_fcall f_8433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9962)
static void C_ccall f_9962(C_word c,C_word *av) C_noret;
C_noret_decl(f_8464)
static void C_ccall f_8464(C_word c,C_word *av) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word *av) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word *av) C_noret;
C_noret_decl(f_8168)
static void C_ccall f_8168(C_word c,C_word *av) C_noret;
C_noret_decl(f_10400)
static void C_ccall f_10400(C_word c,C_word *av) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word *av) C_noret;
C_noret_decl(f_9982)
static void C_ccall f_9982(C_word c,C_word *av) C_noret;
C_noret_decl(f_9911)
static void C_fcall f_9911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6108)
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word *av) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word *av) C_noret;
C_noret_decl(f_9925)
static void C_ccall f_9925(C_word c,C_word *av) C_noret;
C_noret_decl(f_10788)
static void C_ccall f_10788(C_word c,C_word *av) C_noret;
C_noret_decl(f_10785)
static void C_ccall f_10785(C_word c,C_word *av) C_noret;
C_noret_decl(f_10418)
static void C_ccall f_10418(C_word c,C_word *av) C_noret;
C_noret_decl(f_10782)
static void C_ccall f_10782(C_word c,C_word *av) C_noret;
C_noret_decl(f_8129)
static void C_ccall f_8129(C_word c,C_word *av) C_noret;
C_noret_decl(f_10414)
static void C_fcall f_10414(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9831)
static void C_ccall f_9831(C_word c,C_word *av) C_noret;
C_noret_decl(f_9839)
static void C_ccall f_9839(C_word c,C_word *av) C_noret;
C_noret_decl(f_10779)
static void C_ccall f_10779(C_word c,C_word *av) C_noret;
C_noret_decl(f_10771)
static void C_ccall f_10771(C_word c,C_word *av) C_noret;
C_noret_decl(f_11880)
static void C_ccall f_11880(C_word c,C_word *av) C_noret;
C_noret_decl(f_5626)
static void C_fcall f_5626(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word *av) C_noret;
C_noret_decl(f_8302)
static void C_ccall f_8302(C_word c,C_word *av) C_noret;
C_noret_decl(f_8109)
static void C_fcall f_8109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11891)
static void C_ccall f_11891(C_word c,C_word *av) C_noret;
C_noret_decl(f_11893)
static void C_ccall f_11893(C_word c,C_word *av) C_noret;
C_noret_decl(f_10422)
static void C_fcall f_10422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9821)
static void C_ccall f_9821(C_word c,C_word *av) C_noret;
C_noret_decl(f_11863)
static void C_ccall f_11863(C_word c,C_word *av) C_noret;
C_noret_decl(f_9829)
static void C_ccall f_9829(C_word c,C_word *av) C_noret;
C_noret_decl(f_11897)
static void C_ccall f_11897(C_word c,C_word *av) C_noret;
C_noret_decl(f_9298)
static void C_ccall f_9298(C_word c,C_word *av) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word *av) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word *av) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word *av) C_noret;
C_noret_decl(f_11874)
static void C_ccall f_11874(C_word c,C_word *av) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word *av) C_noret;
C_noret_decl(f_8859)
static void C_ccall f_8859(C_word c,C_word *av) C_noret;
C_noret_decl(f_9807)
static void C_ccall f_9807(C_word c,C_word *av) C_noret;
C_noret_decl(f_4405)
static void C_fcall f_4405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word *av) C_noret;
C_noret_decl(f_11876)
static void C_ccall f_11876(C_word c,C_word *av) C_noret;
C_noret_decl(f_6022)
static void C_fcall f_6022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9592)
static void C_ccall f_9592(C_word c,C_word *av) C_noret;
C_noret_decl(f_9594)
static void C_ccall f_9594(C_word c,C_word *av) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word *av) C_noret;
C_noret_decl(f_9857)
static void C_ccall f_9857(C_word c,C_word *av) C_noret;
C_noret_decl(f_6182)
static void C_fcall f_6182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9598)
static void C_ccall f_9598(C_word c,C_word *av) C_noret;
C_noret_decl(f_9868)
static void C_ccall f_9868(C_word c,C_word *av) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word *av) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word *av) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word *av) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word *av) C_noret;
C_noret_decl(f_9127)
static void C_ccall f_9127(C_word c,C_word *av) C_noret;
C_noret_decl(f_10448)
static void C_fcall f_10448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8370)
static void C_ccall f_8370(C_word c,C_word *av) C_noret;
C_noret_decl(f_10444)
static void C_ccall f_10444(C_word c,C_word *av) C_noret;
C_noret_decl(f_9326)
static void C_ccall f_9326(C_word c,C_word *av) C_noret;
C_noret_decl(f_4944)
static void C_fcall f_4944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9556)
static void C_ccall f_9556(C_word c,C_word *av) C_noret;
C_noret_decl(f_8384)
static void C_fcall f_8384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9552)
static void C_ccall f_9552(C_word c,C_word *av) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word *av) C_noret;
C_noret_decl(f_9548)
static void C_ccall f_9548(C_word c,C_word *av) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word *av) C_noret;
C_noret_decl(f_8909)
static void C_ccall f_8909(C_word c,C_word *av) C_noret;
C_noret_decl(f_9562)
static void C_ccall f_9562(C_word c,C_word *av) C_noret;
C_noret_decl(f_6056)
static void C_fcall f_6056(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9558)
static void C_ccall f_9558(C_word c,C_word *av) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word *av) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word *av) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word *av) C_noret;
C_noret_decl(f_9173)
static void C_ccall f_9173(C_word c,C_word *av) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word *av) C_noret;
C_noret_decl(f_9350)
static void C_ccall f_9350(C_word c,C_word *av) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word *av) C_noret;
C_noret_decl(f_9579)
static void C_ccall f_9579(C_word c,C_word *av) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word *av) C_noret;
C_noret_decl(f_10297)
static void C_ccall f_10297(C_word c,C_word *av) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word *av) C_noret;
C_noret_decl(f_9192)
static void C_ccall f_9192(C_word c,C_word *av) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word *av) C_noret;
C_noret_decl(f_10288)
static void C_ccall f_10288(C_word c,C_word *av) C_noret;
C_noret_decl(f_6098)
static void C_fcall f_6098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word *av) C_noret;
C_noret_decl(f_9601)
static void C_ccall f_9601(C_word c,C_word *av) C_noret;
C_noret_decl(f_9604)
static void C_ccall f_9604(C_word c,C_word *av) C_noret;
C_noret_decl(f_9611)
static void C_ccall f_9611(C_word c,C_word *av) C_noret;
C_noret_decl(f_9619)
static void C_ccall f_9619(C_word c,C_word *av) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word *av) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word *av) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word *av) C_noret;
C_noret_decl(f_8640)
static void C_fcall f_8640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word *av) C_noret;
C_noret_decl(f_4647)
static void C_fcall f_4647(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10227)
static void C_ccall f_10227(C_word c,C_word *av) C_noret;
C_noret_decl(f_10229)
static void C_ccall f_10229(C_word c,C_word *av) C_noret;
C_noret_decl(f_10200)
static void C_ccall f_10200(C_word c,C_word *av) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word *av) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word *av) C_noret;
C_noret_decl(f_5002)
static void C_fcall f_5002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word *av) C_noret;
C_noret_decl(f_9407)
static void C_ccall f_9407(C_word c,C_word *av) C_noret;
C_noret_decl(f_9651)
static void C_ccall f_9651(C_word c,C_word *av) C_noret;
C_noret_decl(f_9658)
static void C_ccall f_9658(C_word c,C_word *av) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word *av) C_noret;
C_noret_decl(f_10207)
static void C_ccall f_10207(C_word c,C_word *av) C_noret;
C_noret_decl(f_9621)
static void C_ccall f_9621(C_word c,C_word *av) C_noret;
C_noret_decl(f_9625)
static void C_ccall f_9625(C_word c,C_word *av) C_noret;
C_noret_decl(f_9628)
static void C_ccall f_9628(C_word c,C_word *av) C_noret;
C_noret_decl(f_10251)
static void C_fcall f_10251(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10269)
static void C_ccall f_10269(C_word c,C_word *av) C_noret;
C_noret_decl(f_10265)
static void C_ccall f_10265(C_word c,C_word *av) C_noret;
C_noret_decl(f_10241)
static void C_fcall f_10241(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word *av) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word *av) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word *av) C_noret;
C_noret_decl(f_10925)
static C_word C_fcall f_10925(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word *av) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word *av) C_noret;
C_noret_decl(f_11183)
static void C_ccall f_11183(C_word c,C_word *av) C_noret;
C_noret_decl(f_11180)
static void C_ccall f_11180(C_word c,C_word *av) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word *av) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word *av) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word *av) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word *av) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word *av) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word *av) C_noret;
C_noret_decl(f_11539)
static void C_ccall f_11539(C_word c,C_word *av) C_noret;
C_noret_decl(f_10233)
static void C_ccall f_10233(C_word c,C_word *av) C_noret;
C_noret_decl(f_11655)
static void C_ccall f_11655(C_word c,C_word *av) C_noret;
C_noret_decl(f_11652)
static void C_ccall f_11652(C_word c,C_word *av) C_noret;
C_noret_decl(f_11857)
static void C_ccall f_11857(C_word c,C_word *av) C_noret;
C_noret_decl(f_11859)
static void C_ccall f_11859(C_word c,C_word *av) C_noret;
C_noret_decl(f_11526)
static void C_ccall f_11526(C_word c,C_word *av) C_noret;
C_noret_decl(f_11523)
static void C_ccall f_11523(C_word c,C_word *av) C_noret;
C_noret_decl(f_10236)
static void C_ccall f_10236(C_word c,C_word *av) C_noret;
C_noret_decl(f_10239)
static void C_ccall f_10239(C_word c,C_word *av) C_noret;
C_noret_decl(f_6820)
static void C_fcall f_6820(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6827)
static void C_ccall f_6827(C_word c,C_word *av) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word *av) C_noret;
C_noret_decl(f_11517)
static void C_ccall f_11517(C_word c,C_word *av) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word *av) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word *av) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word *av) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word *av) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word *av) C_noret;
C_noret_decl(f_11519)
static void C_ccall f_11519(C_word c,C_word *av) C_noret;
C_noret_decl(f_11504)
static void C_ccall f_11504(C_word c,C_word *av) C_noret;
C_noret_decl(f_11501)
static void C_ccall f_11501(C_word c,C_word *av) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word *av) C_noret;
C_noret_decl(f_11669)
static void C_ccall f_11669(C_word c,C_word *av) C_noret;
C_noret_decl(f_11666)
static void C_ccall f_11666(C_word c,C_word *av) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word *av) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word *av) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word *av) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word *av) C_noret;
C_noret_decl(f_3697)
static void C_fcall f_3697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11812)
static void C_ccall f_11812(C_word c,C_word *av) C_noret;
C_noret_decl(f_11610)
static void C_ccall f_11610(C_word c,C_word *av) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word *av) C_noret;
C_noret_decl(f_11819)
static void C_ccall f_11819(C_word c,C_word *av) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word *av) C_noret;
C_noret_decl(f_11563)
static void C_ccall f_11563(C_word c,C_word *av) C_noret;
C_noret_decl(f_3751)
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11567)
static void C_ccall f_11567(C_word c,C_word *av) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word *av) C_noret;
C_noret_decl(f_11561)
static void C_ccall f_11561(C_word c,C_word *av) C_noret;
C_noret_decl(f_11803)
static void C_ccall f_11803(C_word c,C_word *av) C_noret;
C_noret_decl(f_11600)
static void C_ccall f_11600(C_word c,C_word *av) C_noret;
C_noret_decl(f_4845)
static void C_fcall f_4845(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4333)
static void C_fcall f_4333(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word *av) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word *av) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word *av) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word *av) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word *av) C_noret;
C_noret_decl(f_4599)
static void C_fcall f_4599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11545)
static void C_ccall f_11545(C_word c,C_word *av) C_noret;
C_noret_decl(f_11548)
static void C_ccall f_11548(C_word c,C_word *av) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word *av) C_noret;
C_noret_decl(f_11541)
static void C_ccall f_11541(C_word c,C_word *av) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word *av) C_noret;
C_noret_decl(f_3687)
static void C_fcall f_3687(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10194)
static void C_ccall f_10194(C_word c,C_word *av) C_noret;
C_noret_decl(f_10196)
static void C_ccall f_10196(C_word c,C_word *av) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word *av) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word *av) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word *av) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word *av) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word *av) C_noret;
C_noret_decl(f_10942)
static void C_fcall f_10942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10940)
static void C_ccall f_10940(C_word c,C_word *av) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word *av) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word *av) C_noret;
C_noret_decl(f_11495)
static void C_ccall f_11495(C_word c,C_word *av) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word *av) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word *av) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word *av) C_noret;
C_noret_decl(f_10173)
static void C_ccall f_10173(C_word c,C_word *av) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word *av) C_noret;
C_noret_decl(f_6998)
static void C_ccall f_6998(C_word c,C_word *av) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word *av) C_noret;
C_noret_decl(f_11497)
static void C_ccall f_11497(C_word c,C_word *av) C_noret;
C_noret_decl(f_10179)
static void C_ccall f_10179(C_word c,C_word *av) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word *av) C_noret;
C_noret_decl(f_4084)
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5960)
static void C_fcall f_5960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word *av) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word *av) C_noret;
C_noret_decl(f_5967)
static void C_fcall f_5967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_ccall f_6890(C_word c,C_word *av) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word *av) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word *av) C_noret;
C_noret_decl(f_4293)
static void C_fcall f_4293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word *av) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word *av) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word *av) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word *av) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word *av) C_noret;
C_noret_decl(f_10626)
static void C_ccall f_10626(C_word c,C_word *av) C_noret;
C_noret_decl(f_10628)
static void C_fcall f_10628(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9516)
static void C_ccall f_9516(C_word c,C_word *av) C_noret;
C_noret_decl(f_4068)
static void C_fcall f_4068(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word *av) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word *av) C_noret;
C_noret_decl(f_9209)
static void C_ccall f_9209(C_word c,C_word *av) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word *av) C_noret;
C_noret_decl(f_9251)
static void C_ccall f_9251(C_word c,C_word *av) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word *av) C_noret;
C_noret_decl(f_10137)
static void C_ccall f_10137(C_word c,C_word *av) C_noret;
C_noret_decl(f_11387)
static void C_ccall f_11387(C_word c,C_word *av) C_noret;
C_noret_decl(f_11635)
static void C_ccall f_11635(C_word c,C_word *av) C_noret;
C_noret_decl(f_11637)
static void C_ccall f_11637(C_word c,C_word *av) C_noret;
C_noret_decl(f_3670)
static C_word C_fcall f_3670(C_word t0,C_word t1);
C_noret_decl(f_5923)
static void C_ccall f_5923(C_word c,C_word *av) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word *av) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word *av) C_noret;
C_noret_decl(f_9544)
static void C_ccall f_9544(C_word c,C_word *av) C_noret;
C_noret_decl(f_9540)
static void C_ccall f_9540(C_word c,C_word *av) C_noret;
C_noret_decl(f_11822)
static void C_ccall f_11822(C_word c,C_word *av) C_noret;
C_noret_decl(f_10653)
static void C_fcall f_10653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word *av) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word *av) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word *av) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word *av) C_noret;
C_noret_decl(f_4025)
static void C_fcall f_4025(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word *av) C_noret;
C_noret_decl(f_11052)
static void C_ccall f_11052(C_word c,C_word *av) C_noret;
C_noret_decl(f_11049)
static void C_ccall f_11049(C_word c,C_word *av) C_noret;
C_noret_decl(f_11046)
static void C_ccall f_11046(C_word c,C_word *av) C_noret;
C_noret_decl(f_11043)
static void C_ccall f_11043(C_word c,C_word *av) C_noret;
C_noret_decl(f_11074)
static void C_ccall f_11074(C_word c,C_word *av) C_noret;
C_noret_decl(f_9504)
static void C_ccall f_9504(C_word c,C_word *av) C_noret;
C_noret_decl(f_9506)
static void C_fcall f_9506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8627)
static void C_ccall f_8627(C_word c,C_word *av) C_noret;
C_noret_decl(f_8332)
static void C_ccall f_8332(C_word c,C_word *av) C_noret;
C_noret_decl(f_10992)
static void C_ccall f_10992(C_word c,C_word *av) C_noret;
C_noret_decl(f_10999)
static void C_ccall f_10999(C_word c,C_word *av) C_noret;
C_noret_decl(f_10990)
static void C_ccall f_10990(C_word c,C_word *av) C_noret;
C_noret_decl(f_11065)
static void C_ccall f_11065(C_word c,C_word *av) C_noret;
C_noret_decl(f_11068)
static void C_ccall f_11068(C_word c,C_word *av) C_noret;
C_noret_decl(f_11062)
static void C_ccall f_11062(C_word c,C_word *av) C_noret;
C_noret_decl(f_11480)
static void C_ccall f_11480(C_word c,C_word *av) C_noret;
C_noret_decl(f_11010)
static void C_fcall f_11010(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8319)
static void C_ccall f_8319(C_word c,C_word *av) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word *av) C_noret;
C_noret_decl(f_8311)
static void C_ccall f_8311(C_word c,C_word *av) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word *av) C_noret;
C_noret_decl(f_11005)
static void C_ccall f_11005(C_word c,C_word *av) C_noret;
C_noret_decl(f_11002)
static void C_ccall f_11002(C_word c,C_word *av) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word *av) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word *av) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word *av) C_noret;
C_noret_decl(f_11033)
static void C_ccall f_11033(C_word c,C_word *av) C_noret;
C_noret_decl(f_11037)
static void C_ccall f_11037(C_word c,C_word *av) C_noret;
C_noret_decl(f_11030)
static void C_ccall f_11030(C_word c,C_word *av) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word *av) C_noret;
C_noret_decl(f_11024)
static void C_ccall f_11024(C_word c,C_word *av) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word *av) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word *av) C_noret;
C_noret_decl(f_3928)
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word *av) C_noret;
C_noret_decl(f_8830)
static void C_ccall f_8830(C_word c,C_word *av) C_noret;
C_noret_decl(f_8824)
static void C_ccall f_8824(C_word c,C_word *av) C_noret;
C_noret_decl(f_8800)
static void C_ccall f_8800(C_word c,C_word *av) C_noret;
C_noret_decl(f_8228)
static void C_ccall f_8228(C_word c,C_word *av) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word *av) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word *av) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word *av) C_noret;
C_noret_decl(f_8286)
static void C_ccall f_8286(C_word c,C_word *av) C_noret;
C_noret_decl(f_8282)
static void C_ccall f_8282(C_word c,C_word *av) C_noret;
C_noret_decl(f_10678)
static void C_fcall f_10678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word *av) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word *av) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word *av) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word *av) C_noret;
C_noret_decl(f_8290)
static void C_ccall f_8290(C_word c,C_word *av) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word *av) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717(C_word c,C_word *av) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word *av) C_noret;
C_noret_decl(f_6767)
static void C_fcall f_6767(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9158)
static void C_ccall f_9158(C_word c,C_word *av) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word *av) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word *av) C_noret;
C_noret_decl(f_8270)
static void C_ccall f_8270(C_word c,C_word *av) C_noret;
C_noret_decl(f_8847)
static void C_ccall f_8847(C_word c,C_word *av) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word *av) C_noret;
C_noret_decl(f_8843)
static void C_ccall f_8843(C_word c,C_word *av) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word *av) C_noret;
C_noret_decl(f_9102)
static void C_ccall f_9102(C_word c,C_word *av) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word *av) C_noret;
C_noret_decl(f_11964)
static void C_ccall f_11964(C_word c,C_word *av) C_noret;
C_noret_decl(f_11962)
static void C_ccall f_11962(C_word c,C_word *av) C_noret;
C_noret_decl(f_9123)
static void C_ccall f_9123(C_word c,C_word *av) C_noret;
C_noret_decl(f_3850)
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9444)
static void C_ccall f_9444(C_word c,C_word *av) C_noret;
C_noret_decl(f_9414)
static void C_ccall f_9414(C_word c,C_word *av) C_noret;
C_noret_decl(f_7139)
static C_word C_fcall f_7139(C_word t0);
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word *av) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word *av) C_noret;
C_noret_decl(f_7700)
static void C_fcall f_7700(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9423)
static void C_fcall f_9423(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9421)
static void C_ccall f_9421(C_word c,C_word *av) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word *av) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word *av) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word *av) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word *av) C_noret;
C_noret_decl(f_9464)
static void C_ccall f_9464(C_word c,C_word *av) C_noret;
C_noret_decl(f_9465)
static void C_fcall f_9465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word *av) C_noret;
C_noret_decl(f_6337)
static void C_fcall f_6337(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5322)
static void C_fcall f_5322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_fcall f_5325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_ccall f_8566(C_word c,C_word *av) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word *av) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570(C_word c,C_word *av) C_noret;
C_noret_decl(f_5364)
static void C_fcall f_5364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_fcall f_6314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6806)
static void C_ccall f_6806(C_word c,C_word *av) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word *av) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word *av) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word *av) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word *av) C_noret;
C_noret_decl(f_6688)
static void C_fcall f_6688(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word *av) C_noret;
C_noret_decl(f_6683)
static void C_ccall f_6683(C_word c,C_word *av) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word *av) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word *av) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word *av) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word *av) C_noret;
C_noret_decl(f_6836)
static void C_fcall f_6836(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11679)
static void C_ccall f_11679(C_word c,C_word *av) C_noret;
C_noret_decl(f_4531)
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10837)
static void C_ccall f_10837(C_word c,C_word *av) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word *av) C_noret;
C_noret_decl(f_10831)
static void C_ccall f_10831(C_word c,C_word *av) C_noret;
C_noret_decl(f_10827)
static void C_ccall f_10827(C_word c,C_word *av) C_noret;
C_noret_decl(f_10824)
static void C_ccall f_10824(C_word c,C_word *av) C_noret;
C_noret_decl(f_10818)
static void C_ccall f_10818(C_word c,C_word *av) C_noret;
C_noret_decl(f_7184)
static void C_fcall f_7184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word *av) C_noret;
C_noret_decl(f_6933)
static void C_fcall f_6933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4575)
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word *av) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word *av) C_noret;
C_noret_decl(f_10804)
static void C_fcall f_10804(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word *av) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word *av) C_noret;
C_noret_decl(f_7165)
static void C_fcall f_7165(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7160)
static void C_fcall f_7160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word *av) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word *av) C_noret;
C_noret_decl(f_3976)
static void C_fcall f_3976(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word *av) C_noret;
C_noret_decl(f_11686)
static void C_ccall f_11686(C_word c,C_word *av) C_noret;
C_noret_decl(f_11699)
static void C_ccall f_11699(C_word c,C_word *av) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word *av) C_noret;
C_noret_decl(f_4512)
static void C_fcall f_4512(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11696)
static void C_ccall f_11696(C_word c,C_word *av) C_noret;
C_noret_decl(f_11693)
static void C_ccall f_11693(C_word c,C_word *av) C_noret;
C_noret_decl(f_11690)
static void C_ccall f_11690(C_word c,C_word *av) C_noret;
C_noret_decl(f_4201)
static C_word C_fcall f_4201(C_word t0,C_word t1);
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word *av) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word *av) C_noret;
C_noret_decl(f_11738)
static void C_ccall f_11738(C_word c,C_word *av) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word *av) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word *av) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word *av) C_noret;
C_noret_decl(f_11764)
static void C_ccall f_11764(C_word c,C_word *av) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word *av) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word *av) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word *av) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word *av) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word *av) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word *av) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word *av) C_noret;
C_noret_decl(f_8040)
static void C_ccall f_8040(C_word c,C_word *av) C_noret;
C_noret_decl(f_4716)
static void C_fcall f_4716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word *av) C_noret;
C_noret_decl(f_7878)
static C_word C_fcall f_7878(C_word t0,C_word t1);
C_noret_decl(f_5744)
static C_word C_fcall f_5744(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word *av) C_noret;
C_noret_decl(f_7501)
static void C_ccall f_7501(C_word c,C_word *av) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word *av) C_noret;
C_noret_decl(f_10846)
static void C_ccall f_10846(C_word c,C_word *av) C_noret;
C_noret_decl(f_10840)
static void C_ccall f_10840(C_word c,C_word *av) C_noret;
C_noret_decl(f_8055)
static void C_ccall f_8055(C_word c,C_word *av) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word *av) C_noret;
C_noret_decl(f_11597)
static void C_fcall f_11597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10074)
static void C_fcall f_10074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10072)
static void C_ccall f_10072(C_word c,C_word *av) C_noret;
C_noret_decl(f_8035)
static void C_ccall f_8035(C_word c,C_word *av) C_noret;
C_noret_decl(f_8031)
static void C_ccall f_8031(C_word c,C_word *av) C_noret;
C_noret_decl(f_11210)
static void C_ccall f_11210(C_word c,C_word *av) C_noret;
C_noret_decl(f_8061)
static void C_ccall f_8061(C_word c,C_word *av) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word *av) C_noret;
C_noret_decl(f_10047)
static void C_fcall f_10047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11744)
static void C_ccall f_11744(C_word c,C_word *av) C_noret;
C_noret_decl(f_11749)
static void C_fcall f_11749(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7828)
static C_word C_fcall f_7828(C_word t0,C_word t1);
C_noret_decl(f_11740)
static void C_ccall f_11740(C_word c,C_word *av) C_noret;
C_noret_decl(f_8096)
static void C_fcall f_8096(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7574)
static void C_fcall f_7574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word *av) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word *av) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word *av) C_noret;
C_noret_decl(f_11237)
static void C_ccall f_11237(C_word c,C_word *av) C_noret;
C_noret_decl(f_8068)
static void C_ccall f_8068(C_word c,C_word *av) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word *av) C_noret;
C_noret_decl(f_7522)
static void C_ccall f_7522(C_word c,C_word *av) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word *av) C_noret;
C_noret_decl(f_7526)
static void C_ccall f_7526(C_word c,C_word *av) C_noret;
C_noret_decl(f_7800)
static C_word C_fcall f_7800(C_word t0,C_word t1);
C_noret_decl(f_8077)
static void C_ccall f_8077(C_word c,C_word *av) C_noret;
C_noret_decl(f_8074)
static void C_ccall f_8074(C_word c,C_word *av) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word *av) C_noret;
C_noret_decl(f_7556)
static void C_fcall f_7556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10585)
static void C_fcall f_10585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10564)
static void C_ccall f_10564(C_word c,C_word *av) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word *av) C_noret;
C_noret_decl(f_7760)
static void C_fcall f_7760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word *av) C_noret;
C_noret_decl(f_10892)
static void C_ccall f_10892(C_word c,C_word *av) C_noret;
C_noret_decl(f_8255)
static void C_ccall f_8255(C_word c,C_word *av) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word *av) C_noret;
C_noret_decl(f_7752)
static void C_fcall f_7752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11570)
static void C_ccall f_11570(C_word c,C_word *av) C_noret;
C_noret_decl(f_10885)
static void C_fcall f_10885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10889)
static void C_ccall f_10889(C_word c,C_word *av) C_noret;
C_noret_decl(f_11585)
static void C_ccall f_11585(C_word c,C_word *av) C_noret;
C_noret_decl(f_11583)
static void C_ccall f_11583(C_word c,C_word *av) C_noret;
C_noret_decl(f_11589)
static void C_ccall f_11589(C_word c,C_word *av) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word *av) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word *av) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word *av) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word *av) C_noret;
C_noret_decl(f_10524)
static void C_ccall f_10524(C_word c,C_word *av) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word *av) C_noret;
C_noret_decl(f_10520)
static void C_ccall f_10520(C_word c,C_word *av) C_noret;
C_noret_decl(f_9732)
static void C_ccall f_9732(C_word c,C_word *av) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word *av) C_noret;
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word *av) C_noret;
C_noret_decl(f_8219)
static void C_ccall f_8219(C_word c,C_word *av) C_noret;
C_noret_decl(f_8216)
static void C_ccall f_8216(C_word c,C_word *av) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word *av) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word *av) C_noret;
C_noret_decl(f_10518)
static void C_ccall f_10518(C_word c,C_word *av) C_noret;
C_noret_decl(f_8409)
static void C_ccall f_8409(C_word c,C_word *av) C_noret;
C_noret_decl(f_8264)
static void C_ccall f_8264(C_word c,C_word *av) C_noret;
C_noret_decl(f_9729)
static void C_ccall f_9729(C_word c,C_word *av) C_noret;
C_noret_decl(f_10507)
static void C_ccall f_10507(C_word c,C_word *av) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word *av) C_noret;
C_noret_decl(f_9726)
static void C_ccall f_9726(C_word c,C_word *av) C_noret;
C_noret_decl(f_8080)
static void C_ccall f_8080(C_word c,C_word *av) C_noret;
C_noret_decl(f_9773)
static void C_fcall f_9773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732(C_word c,C_word *av) C_noret;
C_noret_decl(f_8090)
static void C_fcall f_8090(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word *av) C_noret;
C_noret_decl(f_5822)
static void C_fcall f_5822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word *av) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word *av) C_noret;
C_noret_decl(f_4102)
static void C_fcall f_4102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word *av) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word *av) C_noret;
C_noret_decl(f_8177)
static void C_ccall f_8177(C_word c,C_word *av) C_noret;
C_noret_decl(f_8171)
static void C_ccall f_8171(C_word c,C_word *av) C_noret;
C_noret_decl(f_8174)
static void C_ccall f_8174(C_word c,C_word *av) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word *av) C_noret;
C_noret_decl(f_4118)
static void C_fcall f_4118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word *av) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word *av) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word *av) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word *av) C_noret;
C_noret_decl(f_8183)
static void C_ccall f_8183(C_word c,C_word *av) C_noret;
C_noret_decl(f_8180)
static void C_ccall f_8180(C_word c,C_word *av) C_noret;
C_noret_decl(f_9899)
static void C_ccall f_9899(C_word c,C_word *av) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word *av) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word *av) C_noret;
C_noret_decl(f_10381)
static void C_ccall f_10381(C_word c,C_word *av) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word *av) C_noret;
C_noret_decl(f_9883)
static void C_ccall f_9883(C_word c,C_word *av) C_noret;
C_noret_decl(f_7002)
static C_word C_fcall f_7002(C_word t0,C_word t1);
C_noret_decl(f_10396)
static void C_ccall f_10396(C_word c,C_word *av) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word *av) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word *av) C_noret;
C_noret_decl(f_8192)
static void C_ccall f_8192(C_word c,C_word *av) C_noret;
C_noret_decl(f_8940)
static void C_ccall f_8940(C_word c,C_word *av) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word *av) C_noret;
C_noret_decl(f_7044)
static void C_fcall f_7044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word *av) C_noret;
C_noret_decl(f_7032)
static void C_fcall f_7032(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word *av) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word *av) C_noret;
C_noret_decl(f_4754)
static void C_fcall f_4754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_fcall f_4758(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word *av) C_noret;
C_noret_decl(f_5288)
static void C_fcall f_5288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10362)
static void C_ccall f_10362(C_word c,C_word *av) C_noret;
C_noret_decl(f_5275)
static void C_fcall f_5275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_ccall f_8982(C_word c,C_word *av) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word *av) C_noret;
C_noret_decl(f_6620)
static C_word C_fcall f_6620(C_word t0,C_word t1);
C_noret_decl(f_10311)
static void C_ccall f_10311(C_word c,C_word *av) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word *av) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word *av) C_noret;
C_noret_decl(f_10342)
static void C_ccall f_10342(C_word c,C_word *av) C_noret;
C_noret_decl(f_9688)
static void C_ccall f_9688(C_word c,C_word *av) C_noret;
C_noret_decl(f_10373)
static void C_ccall f_10373(C_word c,C_word *av) C_noret;
C_noret_decl(f_6606)
static void C_fcall f_6606(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6603)
static void C_fcall f_6603(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9691)
static void C_ccall f_9691(C_word c,C_word *av) C_noret;
C_noret_decl(f_9664)
static void C_ccall f_9664(C_word c,C_word *av) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word *av) C_noret;
C_noret_decl(f_9667)
static void C_ccall f_9667(C_word c,C_word *av) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word *av) C_noret;
C_noret_decl(f_10351)
static void C_ccall f_10351(C_word c,C_word *av) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word *av) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word *av) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word *av) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word *av) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word *av) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word *av) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word *av) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word *av) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word *av) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word *av) C_noret;
C_noret_decl(f_9370)
static void C_ccall f_9370(C_word c,C_word *av) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word *av) C_noret;
C_noret_decl(f_4972)
static void C_fcall f_4972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9387)
static void C_ccall f_9387(C_word c,C_word *av) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word *av) C_noret;
C_noret_decl(f_9380)
static void C_fcall f_9380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4457)
static void C_fcall f_4457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word *av) C_noret;
C_noret_decl(f_4990)
static void C_fcall f_4990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word *av) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word *av) C_noret;
C_noret_decl(f_10321)
static void C_ccall f_10321(C_word c,C_word *av) C_noret;
C_noret_decl(f_11117)
static void C_ccall f_11117(C_word c,C_word *av) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word *av) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word *av) C_noret;
C_noret_decl(f_11162)
static void C_ccall f_11162(C_word c,C_word *av) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word *av) C_noret;
C_noret_decl(f_7083)
static void C_fcall f_7083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4900)
static void C_fcall f_4900(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9997)
static void C_ccall f_9997(C_word c,C_word *av) C_noret;
C_noret_decl(f_5451)
static void C_fcall f_5451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7075)
static void C_ccall f_7075(C_word c,C_word *av) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word *av) C_noret;
C_noret_decl(f_11792)
static void C_ccall f_11792(C_word c,C_word *av) C_noret;
C_noret_decl(f_11799)
static void C_ccall f_11799(C_word c,C_word *av) C_noret;
C_noret_decl(f_11143)
static void C_ccall f_11143(C_word c,C_word *av) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word *av) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word *av) C_noret;
C_noret_decl(f_6294)
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_4919)
static void C_ccall trf_4919(C_word c,C_word *av) C_noret;
static void C_ccall trf_4919(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4919(t0,t1);}

C_noret_decl(trf_9003)
static void C_ccall trf_9003(C_word c,C_word *av) C_noret;
static void C_ccall trf_9003(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9003(t0,t1);}

C_noret_decl(trf_6288)
static void C_ccall trf_6288(C_word c,C_word *av) C_noret;
static void C_ccall trf_6288(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6288(t0,t1,t2);}

C_noret_decl(trf_9050)
static void C_ccall trf_9050(C_word c,C_word *av) C_noret;
static void C_ccall trf_9050(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9050(t0,t1);}

C_noret_decl(trf_4388)
static void C_ccall trf_4388(C_word c,C_word *av) C_noret;
static void C_ccall trf_4388(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4388(t0,t1,t2);}

C_noret_decl(trf_4371)
static void C_ccall trf_4371(C_word c,C_word *av) C_noret;
static void C_ccall trf_4371(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4371(t0,t1);}

C_noret_decl(trf_10730)
static void C_ccall trf_10730(C_word c,C_word *av) C_noret;
static void C_ccall trf_10730(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10730(t0,t1,t2);}

C_noret_decl(trf_5810)
static void C_ccall trf_5810(C_word c,C_word *av) C_noret;
static void C_ccall trf_5810(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_5810(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_9029)
static void C_ccall trf_9029(C_word c,C_word *av) C_noret;
static void C_ccall trf_9029(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9029(t0,t1,t2,t3);}

C_noret_decl(trf_5195)
static void C_ccall trf_5195(C_word c,C_word *av) C_noret;
static void C_ccall trf_5195(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5195(t0,t1,t2);}

C_noret_decl(trf_5841)
static void C_ccall trf_5841(C_word c,C_word *av) C_noret;
static void C_ccall trf_5841(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5841(t0,t1);}

C_noret_decl(trf_5130)
static void C_ccall trf_5130(C_word c,C_word *av) C_noret;
static void C_ccall trf_5130(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5130(t0,t1,t2);}

C_noret_decl(trf_9901)
static void C_ccall trf_9901(C_word c,C_word *av) C_noret;
static void C_ccall trf_9901(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9901(t0,t1,t2);}

C_noret_decl(trf_6135)
static void C_ccall trf_6135(C_word c,C_word *av) C_noret;
static void C_ccall trf_6135(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6135(t0,t1,t2);}

C_noret_decl(trf_7903)
static void C_ccall trf_7903(C_word c,C_word *av) C_noret;
static void C_ccall trf_7903(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7903(t0,t1,t2);}

C_noret_decl(trf_5692)
static void C_ccall trf_5692(C_word c,C_word *av) C_noret;
static void C_ccall trf_5692(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5692(t0,t1,t2);}

C_noret_decl(trf_8433)
static void C_ccall trf_8433(C_word c,C_word *av) C_noret;
static void C_ccall trf_8433(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8433(t0,t1);}

C_noret_decl(trf_9911)
static void C_ccall trf_9911(C_word c,C_word *av) C_noret;
static void C_ccall trf_9911(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9911(t0,t1,t2);}

C_noret_decl(trf_6108)
static void C_ccall trf_6108(C_word c,C_word *av) C_noret;
static void C_ccall trf_6108(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_6108(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10414)
static void C_ccall trf_10414(C_word c,C_word *av) C_noret;
static void C_ccall trf_10414(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10414(t0,t1,t2);}

C_noret_decl(trf_5626)
static void C_ccall trf_5626(C_word c,C_word *av) C_noret;
static void C_ccall trf_5626(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5626(t0,t1,t2,t3);}

C_noret_decl(trf_8109)
static void C_ccall trf_8109(C_word c,C_word *av) C_noret;
static void C_ccall trf_8109(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8109(t0,t1);}

C_noret_decl(trf_10422)
static void C_ccall trf_10422(C_word c,C_word *av) C_noret;
static void C_ccall trf_10422(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10422(t0,t1,t2);}

C_noret_decl(trf_4405)
static void C_ccall trf_4405(C_word c,C_word *av) C_noret;
static void C_ccall trf_4405(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4405(t0,t1);}

C_noret_decl(trf_6022)
static void C_ccall trf_6022(C_word c,C_word *av) C_noret;
static void C_ccall trf_6022(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6022(t0,t1,t2);}

C_noret_decl(trf_6182)
static void C_ccall trf_6182(C_word c,C_word *av) C_noret;
static void C_ccall trf_6182(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6182(t0,t1);}

C_noret_decl(trf_10448)
static void C_ccall trf_10448(C_word c,C_word *av) C_noret;
static void C_ccall trf_10448(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10448(t0,t1,t2);}

C_noret_decl(trf_4944)
static void C_ccall trf_4944(C_word c,C_word *av) C_noret;
static void C_ccall trf_4944(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4944(t0,t1,t2);}

C_noret_decl(trf_8384)
static void C_ccall trf_8384(C_word c,C_word *av) C_noret;
static void C_ccall trf_8384(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8384(t0,t1,t2);}

C_noret_decl(trf_6056)
static void C_ccall trf_6056(C_word c,C_word *av) C_noret;
static void C_ccall trf_6056(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6056(t0,t1,t2,t3);}

C_noret_decl(trf_6098)
static void C_ccall trf_6098(C_word c,C_word *av) C_noret;
static void C_ccall trf_6098(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_6098(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8640)
static void C_ccall trf_8640(C_word c,C_word *av) C_noret;
static void C_ccall trf_8640(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8640(t0,t1);}

C_noret_decl(trf_4647)
static void C_ccall trf_4647(C_word c,C_word *av) C_noret;
static void C_ccall trf_4647(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4647(t0,t1,t2);}

C_noret_decl(trf_5002)
static void C_ccall trf_5002(C_word c,C_word *av) C_noret;
static void C_ccall trf_5002(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5002(t0,t1);}

C_noret_decl(trf_10251)
static void C_ccall trf_10251(C_word c,C_word *av) C_noret;
static void C_ccall trf_10251(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10251(t0,t1,t2,t3);}

C_noret_decl(trf_10241)
static void C_ccall trf_10241(C_word c,C_word *av) C_noret;
static void C_ccall trf_10241(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10241(t0,t1,t2,t3);}

C_noret_decl(trf_6820)
static void C_ccall trf_6820(C_word c,C_word *av) C_noret;
static void C_ccall trf_6820(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6820(t0,t1,t2);}

C_noret_decl(trf_3697)
static void C_ccall trf_3697(C_word c,C_word *av) C_noret;
static void C_ccall trf_3697(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3697(t0,t1);}

C_noret_decl(trf_3751)
static void C_ccall trf_3751(C_word c,C_word *av) C_noret;
static void C_ccall trf_3751(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3751(t0,t1,t2);}

C_noret_decl(trf_4845)
static void C_ccall trf_4845(C_word c,C_word *av) C_noret;
static void C_ccall trf_4845(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4845(t0,t1,t2);}

C_noret_decl(trf_4333)
static void C_ccall trf_4333(C_word c,C_word *av) C_noret;
static void C_ccall trf_4333(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_4333(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4599)
static void C_ccall trf_4599(C_word c,C_word *av) C_noret;
static void C_ccall trf_4599(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4599(t0,t1);}

C_noret_decl(trf_3687)
static void C_ccall trf_3687(C_word c,C_word *av) C_noret;
static void C_ccall trf_3687(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3687(t0,t1,t2);}

C_noret_decl(trf_10942)
static void C_ccall trf_10942(C_word c,C_word *av) C_noret;
static void C_ccall trf_10942(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10942(t0,t1,t2);}

C_noret_decl(trf_4084)
static void C_ccall trf_4084(C_word c,C_word *av) C_noret;
static void C_ccall trf_4084(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4084(t0,t1,t2);}

C_noret_decl(trf_5960)
static void C_ccall trf_5960(C_word c,C_word *av) C_noret;
static void C_ccall trf_5960(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_5960(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5967)
static void C_ccall trf_5967(C_word c,C_word *av) C_noret;
static void C_ccall trf_5967(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5967(t0,t1);}

C_noret_decl(trf_4293)
static void C_ccall trf_4293(C_word c,C_word *av) C_noret;
static void C_ccall trf_4293(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4293(t0,t1,t2);}

C_noret_decl(trf_10628)
static void C_ccall trf_10628(C_word c,C_word *av) C_noret;
static void C_ccall trf_10628(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10628(t0,t1,t2);}

C_noret_decl(trf_4068)
static void C_ccall trf_4068(C_word c,C_word *av) C_noret;
static void C_ccall trf_4068(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4068(t0,t1,t2);}

C_noret_decl(trf_10653)
static void C_ccall trf_10653(C_word c,C_word *av) C_noret;
static void C_ccall trf_10653(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10653(t0,t1);}

C_noret_decl(trf_4025)
static void C_ccall trf_4025(C_word c,C_word *av) C_noret;
static void C_ccall trf_4025(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4025(t0,t1,t2);}

C_noret_decl(trf_9506)
static void C_ccall trf_9506(C_word c,C_word *av) C_noret;
static void C_ccall trf_9506(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9506(t0,t1,t2);}

C_noret_decl(trf_11010)
static void C_ccall trf_11010(C_word c,C_word *av) C_noret;
static void C_ccall trf_11010(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11010(t0,t1,t2,t3);}

C_noret_decl(trf_3928)
static void C_ccall trf_3928(C_word c,C_word *av) C_noret;
static void C_ccall trf_3928(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3928(t0,t1,t2,t3);}

C_noret_decl(trf_10678)
static void C_ccall trf_10678(C_word c,C_word *av) C_noret;
static void C_ccall trf_10678(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10678(t0,t1,t2);}

C_noret_decl(trf_6767)
static void C_ccall trf_6767(C_word c,C_word *av) C_noret;
static void C_ccall trf_6767(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6767(t0,t1,t2);}

C_noret_decl(trf_3850)
static void C_ccall trf_3850(C_word c,C_word *av) C_noret;
static void C_ccall trf_3850(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3850(t0,t1,t2);}

C_noret_decl(trf_7700)
static void C_ccall trf_7700(C_word c,C_word *av) C_noret;
static void C_ccall trf_7700(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7700(t0,t1,t2,t3);}

C_noret_decl(trf_9423)
static void C_ccall trf_9423(C_word c,C_word *av) C_noret;
static void C_ccall trf_9423(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9423(t0,t1,t2);}

C_noret_decl(trf_9465)
static void C_ccall trf_9465(C_word c,C_word *av) C_noret;
static void C_ccall trf_9465(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9465(t0,t1,t2);}

C_noret_decl(trf_6337)
static void C_ccall trf_6337(C_word c,C_word *av) C_noret;
static void C_ccall trf_6337(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6337(t0,t1,t2);}

C_noret_decl(trf_5322)
static void C_ccall trf_5322(C_word c,C_word *av) C_noret;
static void C_ccall trf_5322(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5322(t0,t1);}

C_noret_decl(trf_5325)
static void C_ccall trf_5325(C_word c,C_word *av) C_noret;
static void C_ccall trf_5325(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5325(t0,t1);}

C_noret_decl(trf_5364)
static void C_ccall trf_5364(C_word c,C_word *av) C_noret;
static void C_ccall trf_5364(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5364(t0,t1);}

C_noret_decl(trf_6314)
static void C_ccall trf_6314(C_word c,C_word *av) C_noret;
static void C_ccall trf_6314(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6314(t0,t1);}

C_noret_decl(trf_6688)
static void C_ccall trf_6688(C_word c,C_word *av) C_noret;
static void C_ccall trf_6688(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6688(t0,t1,t2,t3);}

C_noret_decl(trf_6836)
static void C_ccall trf_6836(C_word c,C_word *av) C_noret;
static void C_ccall trf_6836(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6836(t0,t1,t2);}

C_noret_decl(trf_4531)
static void C_ccall trf_4531(C_word c,C_word *av) C_noret;
static void C_ccall trf_4531(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4531(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7184)
static void C_ccall trf_7184(C_word c,C_word *av) C_noret;
static void C_ccall trf_7184(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7184(t0,t1);}

C_noret_decl(trf_7189)
static void C_ccall trf_7189(C_word c,C_word *av) C_noret;
static void C_ccall trf_7189(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7189(t0,t1,t2,t3);}

C_noret_decl(trf_6933)
static void C_ccall trf_6933(C_word c,C_word *av) C_noret;
static void C_ccall trf_6933(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6933(t0,t1,t2);}

C_noret_decl(trf_4575)
static void C_ccall trf_4575(C_word c,C_word *av) C_noret;
static void C_ccall trf_4575(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4575(t0,t1,t2);}

C_noret_decl(trf_10804)
static void C_ccall trf_10804(C_word c,C_word *av) C_noret;
static void C_ccall trf_10804(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10804(t0,t1,t2,t3);}

C_noret_decl(trf_7165)
static void C_ccall trf_7165(C_word c,C_word *av) C_noret;
static void C_ccall trf_7165(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7165(t0,t1,t2,t3);}

C_noret_decl(trf_7160)
static void C_ccall trf_7160(C_word c,C_word *av) C_noret;
static void C_ccall trf_7160(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7160(t0,t1);}

C_noret_decl(trf_3976)
static void C_ccall trf_3976(C_word c,C_word *av) C_noret;
static void C_ccall trf_3976(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3976(t0,t1,t2,t3);}

C_noret_decl(trf_4512)
static void C_ccall trf_4512(C_word c,C_word *av) C_noret;
static void C_ccall trf_4512(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4512(t0,t1,t2);}

C_noret_decl(trf_4716)
static void C_ccall trf_4716(C_word c,C_word *av) C_noret;
static void C_ccall trf_4716(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4716(t0,t1,t2);}

C_noret_decl(trf_11597)
static void C_ccall trf_11597(C_word c,C_word *av) C_noret;
static void C_ccall trf_11597(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11597(t0,t1);}

C_noret_decl(trf_10074)
static void C_ccall trf_10074(C_word c,C_word *av) C_noret;
static void C_ccall trf_10074(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10074(t0,t1,t2);}

C_noret_decl(trf_10047)
static void C_ccall trf_10047(C_word c,C_word *av) C_noret;
static void C_ccall trf_10047(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10047(t0,t1,t2);}

C_noret_decl(trf_11749)
static void C_ccall trf_11749(C_word c,C_word *av) C_noret;
static void C_ccall trf_11749(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11749(t0,t1,t2);}

C_noret_decl(trf_8096)
static void C_ccall trf_8096(C_word c,C_word *av) C_noret;
static void C_ccall trf_8096(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8096(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7574)
static void C_ccall trf_7574(C_word c,C_word *av) C_noret;
static void C_ccall trf_7574(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7574(t0,t1);}

C_noret_decl(trf_7556)
static void C_ccall trf_7556(C_word c,C_word *av) C_noret;
static void C_ccall trf_7556(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7556(t0,t1,t2);}

C_noret_decl(trf_10585)
static void C_ccall trf_10585(C_word c,C_word *av) C_noret;
static void C_ccall trf_10585(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10585(t0,t1);}

C_noret_decl(trf_7760)
static void C_ccall trf_7760(C_word c,C_word *av) C_noret;
static void C_ccall trf_7760(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7760(t0,t1);}

C_noret_decl(trf_7752)
static void C_ccall trf_7752(C_word c,C_word *av) C_noret;
static void C_ccall trf_7752(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7752(t0,t1);}

C_noret_decl(trf_10885)
static void C_ccall trf_10885(C_word c,C_word *av) C_noret;
static void C_ccall trf_10885(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10885(t0,t1);}

C_noret_decl(trf_9773)
static void C_ccall trf_9773(C_word c,C_word *av) C_noret;
static void C_ccall trf_9773(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9773(t0,t1);}

C_noret_decl(trf_8090)
static void C_ccall trf_8090(C_word c,C_word *av) C_noret;
static void C_ccall trf_8090(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_8090(t0,t1,t2,t3);}

C_noret_decl(trf_5822)
static void C_ccall trf_5822(C_word c,C_word *av) C_noret;
static void C_ccall trf_5822(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5822(t0,t1,t2,t3);}

C_noret_decl(trf_4102)
static void C_ccall trf_4102(C_word c,C_word *av) C_noret;
static void C_ccall trf_4102(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4102(t0,t1,t2);}

C_noret_decl(trf_4118)
static void C_ccall trf_4118(C_word c,C_word *av) C_noret;
static void C_ccall trf_4118(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4118(t0,t1);}

C_noret_decl(trf_7044)
static void C_ccall trf_7044(C_word c,C_word *av) C_noret;
static void C_ccall trf_7044(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7044(t0,t1,t2);}

C_noret_decl(trf_7032)
static void C_ccall trf_7032(C_word c,C_word *av) C_noret;
static void C_ccall trf_7032(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_7032(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4754)
static void C_ccall trf_4754(C_word c,C_word *av) C_noret;
static void C_ccall trf_4754(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4754(t0,t1);}

C_noret_decl(trf_4758)
static void C_ccall trf_4758(C_word c,C_word *av) C_noret;
static void C_ccall trf_4758(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4758(t0,t1,t2);}

C_noret_decl(trf_5288)
static void C_ccall trf_5288(C_word c,C_word *av) C_noret;
static void C_ccall trf_5288(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5288(t0,t1);}

C_noret_decl(trf_5275)
static void C_ccall trf_5275(C_word c,C_word *av) C_noret;
static void C_ccall trf_5275(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5275(t0,t1);}

C_noret_decl(trf_6606)
static void C_ccall trf_6606(C_word c,C_word *av) C_noret;
static void C_ccall trf_6606(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6606(t0,t1,t2,t3);}

C_noret_decl(trf_6603)
static void C_ccall trf_6603(C_word c,C_word *av) C_noret;
static void C_ccall trf_6603(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6603(t0,t1,t2,t3);}

C_noret_decl(trf_4972)
static void C_ccall trf_4972(C_word c,C_word *av) C_noret;
static void C_ccall trf_4972(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_4972(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_9380)
static void C_ccall trf_9380(C_word c,C_word *av) C_noret;
static void C_ccall trf_9380(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9380(t0,t1,t2);}

C_noret_decl(trf_4457)
static void C_ccall trf_4457(C_word c,C_word *av) C_noret;
static void C_ccall trf_4457(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4457(t0,t1);}

C_noret_decl(trf_4990)
static void C_ccall trf_4990(C_word c,C_word *av) C_noret;
static void C_ccall trf_4990(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4990(t0,t1);}

C_noret_decl(trf_7083)
static void C_ccall trf_7083(C_word c,C_word *av) C_noret;
static void C_ccall trf_7083(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7083(t0,t1,t2);}

C_noret_decl(trf_4900)
static void C_ccall trf_4900(C_word c,C_word *av) C_noret;
static void C_ccall trf_4900(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4900(t0,t1,t2);}

C_noret_decl(trf_5451)
static void C_ccall trf_5451(C_word c,C_word *av) C_noret;
static void C_ccall trf_5451(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5451(t0,t1);}

C_noret_decl(trf_6294)
static void C_ccall trf_6294(C_word c,C_word *av) C_noret;
static void C_ccall trf_6294(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_6294(t0,t1,t2,t3,t4,t5);}

/* k7067 in k7046 in err in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_7069,2,av);}
/* expand.scm:730: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[148];
av2[3]=t1;
av2[4]=lf[149];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k6408 in k6401 in loop2 in k6330 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6410,2,av);}
/* expand.scm:578: loop2 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6337(t2,((C_word*)t0)[3],t1);}

/* k4917 in loop in extended-lambda-list? in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_4919,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* expand.scm:336: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4900(t4,((C_word*)t0)[2],t3);}}

/* k8998 in k8986 in k8980 in k8977 */
static void C_ccall f_9000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_9000,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9050,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[10]))){
t5=C_u_i_cdr(((C_word*)t0)[10]);
if(C_truep(C_i_nullp(t5))){
if(C_truep(C_i_symbolp(t2))){
t6=C_u_i_car(((C_word*)t0)[10]);
t7=t4;
f_9050(t7,C_eqp(t2,t6));}
else{
t6=t4;
f_9050(t6,C_SCHEME_FALSE);}}
else{
t6=t4;
f_9050(t6,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9050(t5,C_SCHEME_FALSE);}}

/* k9001 in k8998 in k8986 in k8980 in k8977 */
static void C_fcall f_9003(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,4)))){
C_save_and_reclaim_args((void *)trf_9003,2,t0,t1);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9029,a[2]=t4,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9029(t6,t2,((C_word*)t0)[8],t1);}

/* k6415 in loop2 in k6330 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6417(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,5)))){
C_save_and_reclaim((void *)f_6417,2,av);}
a=C_alloc(18);
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_a_i_list1(&a,1,t2);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_i_cddr(((C_word*)t0)[4]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,lf[72],t7);
t9=C_a_i_cons(&a,2,t8,((C_word*)t0)[5]);
t10=C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[6]);
/* expand.scm:584: loop */
t11=((C_word*)((C_word*)t0)[7])[1];
f_6294(t11,((C_word*)t0)[8],((C_word*)t0)[9],t4,t9,t10);}

/* k7053 in k7046 in err in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7055,2,av);}
/* expand.scm:727: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9004 in k9001 in k8998 in k8986 in k8980 in k8977 */
static void C_ccall f_9006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_9006,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9027,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* synrules.scm:231: segment-tail */
t4=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k11773 in k11762 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_11775,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11792,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11799,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1009: r */
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[101];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k11776 in k11773 in k11762 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_11778,2,av);}
a=C_alloc(9);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[95],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[95],((C_word*)t0)[4],lf[344]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,6)))){
C_save_and_reclaim_args((void *)trf_6288,3,t0,t1,t2);}
a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_6294(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a11909 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11910,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11914,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:968: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[210];
av2[3]=t2;
av2[4]=lf[351];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11912 in a11909 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_11914,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[71],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9048 in k8998 in k8986 in k8980 in k8977 */
static void C_fcall f_9050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,1)))){
C_save_and_reclaim_args((void *)trf_9050,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_9003(t2,((C_word*)t0)[3]);}
else{
t2=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_9003(t4,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t3));}}

/* k4380 in k4369 in a4359 in a4353 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4382,2,av);}
a=C_alloc(4);
t2=C_a_i_record3(&a,3,lf[33],((C_word*)t0)[2],t1);
/* expand.scm:210: ##sys#abort */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* copy in k4369 in a4359 in a4353 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4388,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4405,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_equalp(lf[39],t3))){
if(C_truep(C_i_pairp(t5))){
t7=C_u_i_car(t5);
t8=t6;
f_4405(t8,C_i_stringp(t7));}
else{
t7=t6;
f_4405(t7,C_SCHEME_FALSE);}}
else{
t7=t6;
f_4405(t7,C_SCHEME_FALSE);}}}

/* a11415 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in ... */
static void C_ccall f_11416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_11416,5,av);}
a=C_alloc(5);
t5=C_i_cdr(t2);
if(C_truep(C_i_nullp(t5))){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_cdr(t5);
t7=t6;
t8=C_u_i_car(t5);
if(C_truep(C_i_nullp(t7))){
t9=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11447,a[2]=t7,a[3]=t1,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1134: r */
t10=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[230];
((C_proc)C_fast_retrieve_proc(t10))(3,av2);}}}}

/* k11412 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in ... */
static void C_ccall f_11414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11414,2,av);}
/* expand.scm:1122: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[230];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11906 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11908,2,av);}
/* expand.scm:963: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[210];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5850 in k5839 in loop in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5852,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:496: expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6288(t4,t3,((C_word*)t0)[4]);}

/* k4369 in a4359 in a4353 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_4371,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4382,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[4],a[3]=t7,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4388(t9,t4,t5);}
else{
t2=((C_word*)t0)[2];
/* expand.scm:210: ##sys#abort */
t3=*((C_word*)lf[34]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k11445 in a11415 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in ... */
static void C_ccall f_11447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,1)))){
C_save_and_reclaim((void *)f_11447,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,4,lf[293],((C_word*)t0)[4],t2,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* expand in k10718 in a10715 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in ... */
static void C_fcall f_10730(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_10730,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_cons(&a,2,lf[50],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10755,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:1268: expand */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k11950 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11952,2,av);}
/* expand.scm:939: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[355];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10718 in a10715 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in ... */
static void C_ccall f_10720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_10720,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10730,a[2]=t5,a[3]=t7,a[4]=((C_word)li155),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10730(t9,((C_word*)t0)[3],t2);}

/* a11953 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,9)))){
C_save_and_reclaim((void *)f_11954,5,av);}
t5=*((C_word*)lf[354]+1);
/* expand.scm:942: g1665 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[354]+1));
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=*((C_word*)lf[354]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
av2[5]=*((C_word*)lf[2]+1);
av2[6]=*((C_word*)lf[233]+1);
av2[7]=C_SCHEME_TRUE;
av2[8]=C_SCHEME_FALSE;
av2[9]=lf[355];
tp(10,av2);}}

/* k4618 in k4606 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,3)))){
C_save_and_reclaim((void *)f_4620,2,av);}
a=C_alloc(19);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(t3,lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4716,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4716(t13,t9,t3);}

/* k11940 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11942,2,av);}
/* expand.scm:946: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[353];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9021 in k9025 in k9004 in k9001 in k8998 in k8986 in k8980 in k8977 */
static void C_ccall f_9023(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9023,2,av);}
/* synrules.scm:233: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k10712 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in ... */
static void C_ccall f_10714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10714,2,av);}
/* expand.scm:1257: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[88];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11943 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,9)))){
C_save_and_reclaim((void *)f_11944,5,av);}
t5=*((C_word*)lf[354]+1);
/* expand.scm:949: g1679 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[354]+1));
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=*((C_word*)lf[354]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
av2[5]=*((C_word*)lf[1]+1);
av2[6]=*((C_word*)lf[19]+1);
av2[7]=C_SCHEME_FALSE;
av2[8]=C_SCHEME_TRUE;
av2[9]=lf[353];
tp(10,av2);}}

/* fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5810(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,4)))){
C_save_and_reclaim_args((void *)trf_5810,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(14);
t6=C_i_nullp(t2);
t7=(C_truep(t6)?C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li57),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5822(t11,t1,t5,C_SCHEME_END_OF_LIST);}
else{
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5914,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t10,a[8]=t11,tmp=(C_word)a,a+=9,tmp);
/* expand.scm:507: reverse */
t13=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t13;
av2[1]=t12;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}}

/* doloop2598 in k9001 in k8998 in k8986 in k8980 in k8977 */
static void C_fcall f_9029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_9029,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=t2;
t5=C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t3;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_fixnum_difference(t2,C_fix(1));
t7=C_a_i_list(&a,3,lf[215],lf[70],t3);
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* a10715 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in ... */
static void C_ccall f_10716(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_10716,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10720,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1262: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[88];
av2[3]=t2;
av2[4]=lf[297];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9025 in k9004 in k9001 in k8998 in k8986 in k8980 in k8977 */
static void C_ccall f_9027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_9027,2,av);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9023,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:233: segment-tail */
t4=((C_word*)((C_word*)t0)[7])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}}

/* k5191 in k5188 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_5193,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
f_4990(t4,C_a_i_list(&a,1,t3));}

/* k5188 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_5190,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5195(t6,t2,t1);}

/* map-loop790 in k5188 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_5195,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:363: g796 */
t5=((C_word*)t0)[4];
f_5130(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5185 in g796 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5187,2,av);}
t2=C_slot(t1,C_fix(1));
/* expand.scm:342: string->keyword */
t3=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11929 in a11926 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11931,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[72],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k11404 in k11385 in a11363 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in ... */
static void C_ccall f_11406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,1)))){
C_save_and_reclaim((void *)f_11406,2,av);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,4,lf[293],((C_word*)t0)[3],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[50],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4606 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4608,2,av);}
a=C_alloc(5);
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:278: ##sys#check-syntax */
t5=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[56];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(7,av2);}}
else{
/* expand.scm:289: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* k5839 in loop in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_5841,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5852,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:496: reverse */
t4=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
/* expand.scm:497: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5822(t5,((C_word*)t0)[2],t3,t4);}}

/* k5846 in k5839 in loop in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5848,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,lf[104],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5181 in g796 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,1)))){
C_save_and_reclaim((void *)f_5183,2,av);}
a=C_alloc(30);
t2=C_a_i_list(&a,2,lf[71],t1);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_truep(t3)?t3:((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t6))){
t7=((C_word*)t0)[4];
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t8);
t10=C_a_i_cons(&a,2,lf[72],t9);
t11=C_a_i_list(&a,1,t10);
t12=C_a_i_cons(&a,2,t4,t11);
t13=C_a_i_cons(&a,2,t2,t12);
t14=C_a_i_cons(&a,2,lf[73],t13);
t15=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t15;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[6],t14);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t7=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t2,t7);
t9=C_a_i_cons(&a,2,lf[73],t8);
t10=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[6],t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}

/* k11132 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_11134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_11134,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a11926 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11927,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11931,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:960: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[223];
av2[3]=t2;
av2[4]=lf[352];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11923 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11925,2,av);}
/* expand.scm:955: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[223];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g796 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_5130,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5187,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:366: ##sys#strip-syntax */
t7=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k9942 in test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_9944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_9944,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1392: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9911(t5,t3,t4);}
else{
/* expand.scm:1394: err */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9901(t3,((C_word*)t0)[3],((C_word*)t0)[7]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:1395: c */
t3=((C_word*)t0)[9];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[11];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* k10763 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in ... */
static void C_ccall f_10765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10765,2,av);}
/* expand.scm:1215: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[298];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5858 in k5850 in k5839 in loop in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_5860,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* expand.scm:496: ##sys#append */
t3=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in ... */
static void C_ccall f_10767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_10767,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10771,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1220: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[298];
av2[3]=t2;
av2[4]=lf[305];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* ##sys#extended-lambda-list? in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_4894,3,av);}
a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4900,a[2]=t4,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4900(t6,t1,t2);}

/* k10753 in expand in k10718 in a10715 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_10755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10755,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[50],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a11363 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in ... */
static void C_ccall f_11364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_11364,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
if(C_truep(C_i_nullp(t5))){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_cdr(t5);
t7=t6;
t8=C_u_i_car(t5);
if(C_truep(C_i_nullp(t7))){
t9=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11387,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1148: r */
t10=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t10))(3,av2);}}}}

/* k11360 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in ... */
static void C_ccall f_11362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11362,2,av);}
/* expand.scm:1136: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[221];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
av[0]=t0;
av[1]=t1;
av[2]=t2;
C_save_and_reclaim((void *)f_7487,3,av);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7501,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* expand.scm:808: rename */
t7=t3;
t8=t5;
t1=t7;
t2=t8;
c=3;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7522,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7526,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:810: vector->list */
t5=*((C_word*)lf[179]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=t1;
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(
  /* expand.scm:816: lookup */
  f_3670(t2,((C_word*)t0)[4])
);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7556,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li94),tmp=(C_word)a,a+=6,tmp);
/* expand.scm:803: g1452 */
t6=t5;
f_7556(t6,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7624,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:837: macro-alias */
f_3687(t5,t2,((C_word*)t0)[4]);}}}
else{
t3=t2;
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* k10487 in k10442 in k10416 in simplify in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_10489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10489,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_assq(lf[282],t3);
t5=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_i_cdr(t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(40,c,4)))){
C_save_and_reclaim((void *)f_7485,2,av);}
a=C_alloc(40);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7487,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li95),tmp=(C_word)a,a+=6,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7641,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7878,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7903,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=((C_word)li101),tmp=(C_word)a,a+=8,tmp));
if(C_truep(((C_word*)t0)[5])){
/* expand.scm:916: handler */
t14=((C_word*)t0)[6];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t14;
av2[1]=((C_word*)t0)[7];
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t3)[1];
av2[4]=((C_word*)t5)[1];
((C_proc)C_fast_retrieve_proc(t14))(5,av2);}}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8031,a[2]=t9,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8035,a[2]=((C_word*)t0)[6],a[3]=t14,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:922: rename */
t16=((C_word*)t3)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=t15;
av2[2]=((C_word*)t0)[8];
f_7487(3,av2);}}}

/* err in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_fcall f_9901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,4)))){
C_save_and_reclaim_args((void *)trf_9901,3,t0,t1,t2);}
a=C_alloc(3);
t3=C_a_i_cons(&a,2,lf[265],((C_word*)t0)[2]);
/* expand.scm:1380: ##sys#error */
t4=*((C_word*)lf[25]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[266];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,5)))){
C_save_and_reclaim((void *)f_7472,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7478,a[2]=t3,a[3]=t2,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp);
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_a_i_record2(&a,2,lf[24],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_7478,5,av);}
a=C_alloc(11);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_listp(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7485,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t7)){
t9=t8;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t7;
f_7485(2,av2);}}
else{
/* expand.scm:803: ##sys#error */
t9=*((C_word*)lf[25]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[182];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}

/* k9017 in k9025 in k9004 in k9001 in k8998 in k8986 in k8980 in k8977 */
static void C_ccall f_9019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9019,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[70],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9279 in k9249 */
static void C_ccall f_9281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9281,2,av);}
/* synrules.scm:276: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=t1;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k7919 in k7915 in mirror-rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7921,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a11452 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 in ... */
static void C_ccall f_11453(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11453,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11457,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1115: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[315];
av2[3]=t2;
av2[4]=lf[317];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11455 in a11452 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in ... */
static void C_ccall f_11457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_11457,2,av);}
a=C_alloc(13);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t2))){
t4=C_u_i_car(t2);
t5=C_a_i_list(&a,2,lf[316],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11480,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_u_i_cdr(t2);
t9=C_a_i_list(&a,1,t3);
/* expand.scm:1110: ##sys#append */
t10=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=t8;
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[95],t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11449 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 in ... */
static void C_ccall f_11451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11451,2,av);}
/* expand.scm:1110: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[315];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11326 in k11310 in k11298 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_11328(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11328,2,av);}
t2=C_i_caar(((C_word*)t0)[2]);
/* expand.scm:1184: c */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_10791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,4)))){
C_save_and_reclaim((void *)f_10791,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10802,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10804,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word)li159),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_10804(t10,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}

/* k7915 in mirror-rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7917,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7921,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:891: mirror-rename */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7903(t6,t3,t5);}

/* k11310 in k11298 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_11312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_11312,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=t1;
f_11065(2,av2);}}
else{
t2=C_u_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1184: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[210];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_11065(2,av2);}}}}

/* map-loop1134 in k6128 in loop in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_6135,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* f_8426 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_8426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_8426,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8433,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t5))){
t6=C_i_cddr(t2);
t7=t3;
f_8433(t7,C_i_nullp(t6));}
else{
t6=t3;
f_8433(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8433(t4,C_SCHEME_FALSE);}}

/* k6131 in k6128 in loop in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_6133,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[106],t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6128 in loop in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_6130,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6135(t6,t2,t1);}

/* mirror-rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7903(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_7903,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7917,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* expand.scm:891: mirror-rename */
t9=t3;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7938,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7942,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:893: vector->list */
t5=*((C_word*)lf[179]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t3=(
  /* expand.scm:896: lookup */
  f_3670(t2,((C_word*)t0)[3])
);
t4=(
  /* expand.scm:897: assq-reverse */
  f_7878(t2,((C_word*)((C_word*)t0)[5])[1])
);
if(C_truep(t4)){
t5=t1;
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_i_car(t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(t3)){
if(C_truep(C_i_pairp(t3))){
/* expand.scm:903: rename */
t5=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[3];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
f_7487(3,av2);}}
else{
t5=t2;
t6=C_i_getprop(t5,lf[7],C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
/* expand.scm:910: rename */
t7=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[3];
av2[0]=t7;
av2[1]=t1;
av2[2]=t2;
f_7487(3,av2);}}}}
else{
/* expand.scm:901: rename */
t5=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[3];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
f_7487(3,av2);}}}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* k11298 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_11300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_11300,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=t1;
f_11065(2,av2);}}
else{
t2=C_u_i_car(((C_word*)t0)[3]);
t3=C_i_vectorp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
f_11065(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=C_u_i_car(((C_word*)t0)[3]);
/* expand.scm:1182: ##sys#srfi-4-vector? */
t6=*((C_word*)lf[311]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k4815 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4817,2,av);}
t2=(
  /* expand.scm:273: lookup */
  f_3670(((C_word*)((C_word*)t0)[2])[1],t1)
);
if(C_truep(t2)){
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_4599(t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
t5=((C_word*)t0)[3];
f_4599(t5,t4);}}

/* map-loop898 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_5692,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5717,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:451: g904 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8460 in k8452 in k8467 in k8431 */
static void C_ccall f_8462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8462,2,av);}
/* synrules.scm:124: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=C_fix(0);
av2[4]=t1;
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k8452 in k8467 in k8431 */
static void C_ccall f_8454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_8454,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8458,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8462,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:126: meta-variables */
t5=((C_word*)((C_word*)t0)[7])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
av2[3]=C_fix(0);
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t5))(6,av2);}}

/* k8456 in k8452 in k8467 in k8431 */
static void C_ccall f_8458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,1)))){
C_save_and_reclaim((void *)f_8458,2,av);}
a=C_alloc(15);
t2=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8431 */
static void C_fcall f_8433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_8433,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_i_cdar(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* synrules.scm:120: process-match */
t7=((C_word*)((C_word*)t0)[10])[1];{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)((C_word*)t0)[9])[1];
av2[3]=t3;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(5,av2);}}
else{
/* synrules.scm:127: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[5];
av2[2]=lf[208];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k9960 in k9942 in test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9962,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* expand.scm:1393: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9911(t4,((C_word*)t0)[5],t3);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a8463 in k8467 in k8431 */
static void C_ccall f_8464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8464,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8467 in k8431 */
static void C_ccall f_8469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,5)))){
C_save_and_reclaim((void *)f_8469,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8464,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
/* synrules.scm:121: process-pattern */
t6=((C_word*)((C_word*)t0)[9])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)((C_word*)t0)[10])[1];
av2[4]=t5;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}

/* k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8165,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11561,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11563,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1077: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8168,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8171,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11539,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11541,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1086: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10398 in k10394 in k10340 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_10400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10400,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[201],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5991 in k5965 in map-loop1074 in k5953 in k5950 in k5947 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_5993,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_slot(((C_word*)t0)[4],C_fix(1));
t7=C_slot(((C_word*)t0)[5],C_fix(1));
t8=((C_word*)((C_word*)t0)[6])[1];
f_5960(t8,((C_word*)t0)[7],t5,t6,t7);}

/* k9980 in k9942 in test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_9982,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1398: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9911(t5,t3,t4);}
else{
/* expand.scm:1400: err */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9901(t3,((C_word*)t0)[3],((C_word*)t0)[7]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1401: c */
t3=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[10];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_fcall f_9911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_9911,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9925,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1384: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9944,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1389: c */
t8=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[2];
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t8))(4,av2);}}
else{
/* expand.scm:1385: err */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9901(t3,t1,t2);}}}

/* loop in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_6108,5,t0,t1,t2,t3,t4);}
a=C_alloc(11);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6130,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:526: reverse */
t10=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6182,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t2);
if(C_truep(C_i_listp(t6))){
t7=t2;
t8=C_u_i_car(t7);
t9=C_i_length(t8);
if(C_truep(C_fixnum_greater_or_equal_p(C_fix(3),t9))){
t10=C_i_caar(t2);
if(C_truep(C_i_symbolp(t10))){
t11=t2;
t12=C_u_i_car(t11);
t13=C_u_i_car(t12);
/* expand.scm:531: comp */
t14=t5;
f_6182(t14,(
  /* expand.scm:531: comp */
  f_5744(((C_word*)((C_word*)t0)[3])[1],lf[102],t13)
));}
else{
t11=t5;
f_6182(t11,C_SCHEME_FALSE);}}
else{
t10=t5;
f_6182(t10,C_SCHEME_FALSE);}}
else{
t7=t5;
f_6182(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm:527: loop */
t15=t1;
t16=t2;
t17=t3;
t18=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}

/* k6104 in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6106,2,av);}
/* expand.scm:522: fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5810(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1);}

/* k5602 in k5580 in k5561 in k5558 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_5604,2,av);}
a=C_alloc(12);
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
/* expand.scm:450: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=lf[94];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
/* expand.scm:450: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_a_i_list(&a,3,lf[95],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
/* expand.scm:450: ##sys#append */
t4=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* k9923 in test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_9925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9925,2,av);}
/* expand.scm:1384: ##sys#feature? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[267]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[267]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_10788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_10788,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1227: r */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[227];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_10785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_10785,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1226: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[303];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10416 in simplify in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_10418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_10418,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10422,a[2]=((C_word*)t0)[2],a[3]=((C_word)li148),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1303: g2191 */
t3=t2;
f_10422(t3,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1338: match-expression */
f_6603(t2,((C_word*)t0)[4],lf[286],lf[287]);}}

/* k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in ... */
static void C_ccall f_10782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_10782,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:1225: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[304];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8127 in k8107 in loop in check-for-multiple-bindings in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8129,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_u_i_car(t3);
/* expand.scm:1054: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[188]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[188]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t4;
av2[4]=((C_word*)t0)[4];
tp(5,av2);}}

/* simplify in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_fcall f_10414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_10414,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10418,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1336: match-expression */
f_6603(t3,t2,lf[288],lf[289]);}

/* a9830 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_9831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_9831,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9839,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1444: r */
t6=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[244];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k9837 in a9830 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_9839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_9839,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1444: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[262];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in ... */
static void C_ccall f_10779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_10779,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10782,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1224: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[221];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in ... */
static void C_ccall f_10771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_10771,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10779,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1223: r */
t8=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}

/* k11878 in a11875 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11880,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[293],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop927 in k5580 in k5561 in k5558 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5626(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_5626,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[95],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in ... */
static void C_ccall f_8307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8307,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[2],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:97: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[220];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in ... */
static void C_ccall f_8302(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8302,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,lf[207]);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:96: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[210];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8107 in loop in check-for-multiple-bindings in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_8109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_8109,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8129,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1055: string-append */
t4=*((C_word*)lf[36]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[189];
av2[3]=((C_word*)t0)[8];
av2[4]=lf[190];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_caar(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm:1059: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8096(t6,((C_word*)t0)[5],t3,t5,((C_word*)t0)[3]);}}

/* k11889 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11891,2,av);}
/* expand.scm:971: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[138];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11892 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11893,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11897,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:976: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[138];
av2[3]=t2;
av2[4]=lf[350];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* g2191 in k10416 in simplify in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_fcall f_10422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10422,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_assq(lf[282],t2);
t4=C_i_cdr(t3);
t5=C_a_i_list(&a,2,lf[275],t4);
/* expand.scm:1337: simplify */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10414(t6,t1,t5);}

/* k9819 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_9821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9821,2,av);}
t2=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1453: c */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k11861 in a11858 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11863,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[104],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9827 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_9829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9829,2,av);}
/* expand.scm:1439: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[261];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11895 in a11892 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_11897,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[209],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* f_9298 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_9298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_9298,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9305,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:285: segment-template? */
t5=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k9294 in k9249 */
static void C_ccall f_9296(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9296,2,av);}
/* synrules.scm:281: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k4414 in k4403 in copy in k4369 in a4359 in a4353 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_4416,2,av);}
a=C_alloc(6);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[35],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a9869 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_9870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9870,5,av);}
a=C_alloc(9);
t5=C_i_cdr(t2);
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[263],t5,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k11872 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11874,2,av);}
/* expand.scm:979: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[310];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_5917,2,av);}
a=C_alloc(15);
t2=C_i_check_list_2(t1,lf[16]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6022,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6022(t7,t3,t1);}

/* a8858 in k8828 */
static void C_ccall f_8859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(21,c,2)))){
C_save_and_reclaim((void *)f_8859,3,av);}
a=C_alloc(21);
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],t2);
if(C_truep(t3)){
/* synrules.scm:184: mapit */
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t4=C_a_i_list(&a,1,((C_word*)((C_word*)t0)[2])[1]);
t5=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[5])[1],t4,t2);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],t5,((C_word*)t0)[4]);
/* synrules.scm:184: mapit */
t7=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t1;
av2[2]=t6;
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}}

/* k9805 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9807(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9807,2,av);}
/* expand.scm:1493: ##sys#validate-exports */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[243]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[243]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[248];
tp(4,av2);}}

/* k4403 in copy in k4369 in a4359 in a4353 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,5)))){
C_save_and_reclaim_args((void *)trf_4405,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_i_car(((C_word*)t0)[2]);
/* expand.scm:226: string-append */
t5=*((C_word*)lf[36]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[37];
av2[3]=t3;
av2[4]=lf[38];
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
/* expand.scm:232: copy */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4388(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,4)))){
C_save_and_reclaim((void *)f_5914,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6056,a[2]=t4,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6056(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* a11875 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11876,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11880,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:984: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[310];
av2[3]=t2;
av2[4]=lf[349];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* map-loop1026 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6022(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_6022,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,t3,lf[105]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9590 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_9592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9592,2,av);}
/* expand.scm:1516: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[239];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9593 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_9594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_9594,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9598,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9611,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_cdr(t2);
/* expand.scm:1523: ##sys#strip-syntax */
t8=*((C_word*)lf[12]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k9853 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_9855(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9855,2,av);}
/* expand.scm:1431: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[262];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9856 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_9857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9857,5,av);}
a=C_alloc(9);
t5=C_i_cdr(t2);
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[263],t5,C_SCHEME_TRUE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k6180 in loop in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,4)))){
C_save_and_reclaim_args((void *)trf_6182,2,t0,t1);}
a=C_alloc(13);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cadr(t3);
if(C_truep(C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6206,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:537: caadr */
t9=*((C_word*)lf[107]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t8=C_u_i_car(t3);
t9=C_u_i_cdr(t3);
t10=C_u_i_car(t9);
t11=C_eqp(t8,t10);
if(C_truep(t11)){
/* expand.scm:543: ##sys#defjam-error */
t12=*((C_word*)lf[90]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=t6;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t12=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* expand.scm:533: loop */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6108(t13,((C_word*)t0)[5],t5,t12,C_SCHEME_FALSE);}}}
else{
/* expand.scm:547: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6108(t2,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_TRUE);}}

/* k9596 in a9593 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_9598,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9601,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1525: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[242]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[242]+1);
av2[1]=t3;
tp(2,av2);}}

/* k9866 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_9868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9868,2,av);}
/* expand.scm:1423: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[264];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a6081 in foldl1049 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6082,5,av);}
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6078 in foldl1049 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6080,2,av);}
/* expand.scm:504: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6084 in foldl1049 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6086(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6086,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_6056(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k6789 in k6785 in loop in k6760 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6791,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9125 in k8977 */
static void C_ccall f_9127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9127,2,av);}
/* synrules.scm:240: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* g2198 in k10442 in k10416 in simplify in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_fcall f_10448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10448,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_assq(lf[283],t2);
t4=C_i_length(t3);
if(C_truep(C_fixnum_lessp(t4,C_fix(32)))){
t5=C_i_assq(lf[282],t2);
t6=C_i_cdr(t5);
t7=C_u_i_cdr(t3);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,lf[275],t8);
/* expand.scm:1342: simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_10414(t10,t1,t9);}
else{
t5=((C_word*)t0)[3];
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k8368 */
static void C_ccall f_8370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_8370,2,av);}
a=C_alloc(15);
t2=C_a_i_list(&a,2,lf[45],((C_word*)((C_word*)t0)[2])[1]);
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,1,t3);
/* synrules.scm:61: ##sys#append */
t5=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k10442 in k10416 in simplify in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_10444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_10444,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li149),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1303: g2198 */
t3=t2;
f_10448(t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10489,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1345: match-expression */
f_6603(t2,((C_word*)t0)[3],lf[284],lf[285]);}}

/* f_9326 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_9326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9326,3,av);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_cdr(t3);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(t2);
/* synrules.scm:296: ellipsis? */
t6=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t1;
av2[2]=t5;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}
else{
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* err in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_4944,3,t0,t1,t2);}
/* expand.scm:341: errh */
t3=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k9554 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9556,2,av);}
/* synrules.scm:44: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[235];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop2464 */
static void C_fcall f_8384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8384,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8409,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* synrules.scm:110: g2470 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9550 in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9552,2,av);}
/* expand.scm:1559: ##sys#fixup-macro-environment */
t2=*((C_word*)lf[232]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##sys#expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_4941,6,av);}
a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4944,a[2]=t4,a[3]=t2,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4961,a[2]=t8,a[3]=t10,a[4]=t3,a[5]=t6,a[6]=t5,a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* expand.scm:346: macro-alias */
f_3687(t11,lf[88],*((C_word*)lf[89]+1));}

/* k9546 in k9538 in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9548,2,av);}
/* expand.scm:1561: make-parameter */
t2=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8903 in k8828 */
static void C_ccall f_8905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,5)))){
C_save_and_reclaim((void *)f_8905,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8909,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);
/* synrules.scm:193: process-pattern */
t7=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t5;
av2[3]=t6;
av2[4]=((C_word*)t0)[7];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}

/* k8907 in k8903 in k8828 */
static void C_ccall f_8909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8909,2,av);}
/* synrules.scm:192: append */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9560 in a9557 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,6)))){
C_save_and_reclaim((void *)f_9562,2,av);}
a=C_alloc(14);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[236];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9579,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:54: ##sys#check-syntax */
t12=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=lf[235];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[237];
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}
else{
/* synrules.scm:58: ##sys#process-syntax-rules */
t11=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t11;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t10)[1];
av2[3]=((C_word*)t8)[1];
av2[4]=((C_word*)t4)[1];
av2[5]=((C_word*)t0)[4];
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t11+1)))(7,av2);}}}

/* foldl1049 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6056(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,5)))){
C_save_and_reclaim_args((void *)trf_6056,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(0));
t8=t6;
t9=t3;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6080,a[2]=t8,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6082,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:504: ##sys#decompose-lambda-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[96]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[96]+1);
av2[1]=t10;
av2[2]=t7;
av2[3]=t11;
tp(4,av2);}}
else{
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* a9557 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_9558,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9562,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:49: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[235];
av2[3]=t2;
av2[4]=lf[238];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7622 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_7624,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_4964,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4967,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:349: macro-alias */
f_3687(t3,lf[86],*((C_word*)lf[20]+1));}

/* k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,7)))){
C_save_and_reclaim((void *)f_4967,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],a[11]=((C_word)li49),tmp=(C_word)a,a+=12,tmp));
t6=((C_word*)t4)[1];
f_4972(t6,((C_word*)t0)[9],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[10]);}

/* k9171 in k9156 */
static void C_ccall f_9173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9173,2,av);}
/* synrules.scm:252: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=t1;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4961(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_4961,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:348: macro-alias */
f_3687(t3,lf[87],*((C_word*)lf[20]+1));}

/* f_9350 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_9350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_9350,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9357,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:301: segment-template? */
t4=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k9355 */
static void C_ccall f_9357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9357,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* synrules.scm:302: segment-depth */
t4=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k9577 in k9560 in a9557 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,6)))){
C_save_and_reclaim((void *)f_9579,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
/* synrules.scm:58: ##sys#process-syntax-rules */
t7=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
av2[4]=((C_word*)((C_word*)t0)[3])[1];
av2[5]=((C_word*)t0)[6];
av2[6]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}

/* k7605 in g1452 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_7607,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k10295 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_10297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10297,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_i_car(((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9362 in k9355 */
static void C_ccall f_9364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9364,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_fixnum_plus(C_fix(1),t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9190 in k9156 */
static void C_ccall f_9192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9192,2,av);}
/* synrules.scm:255: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=t1;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k6194 in k6180 in loop in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6196,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* expand.scm:533: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6108(t3,((C_word*)t0)[4],((C_word*)t0)[5],t2,C_SCHEME_FALSE);}

/* k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_10288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_10288,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1317: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[278];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[279];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=C_a_i_list(&a,2,lf[71],((C_word*)t0)[6]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10311,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* expand.scm:1320: walk */
t7=((C_word*)((C_word*)t0)[7])[1];
f_10241(t7,t5,((C_word*)t0)[4],t6);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10321,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1321: c */
t3=((C_word*)t0)[11];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[9];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,5)))){
C_save_and_reclaim_args((void *)trf_6098,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(14);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6108,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_6108(t10,t6,t5,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5218 in map-loop790 in k5188 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5220,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5195(t6,((C_word*)t0)[5],t5);}

/* k9599 in k9596 in a9593 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_9601,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* expand.scm:1527: ##sys#add-to-export-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[241]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[241]+1);
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9602 in k9599 in k9596 in a9593 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9604,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9609 in a9593 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9611,2,av);}
/* expand.scm:1522: ##sys#validate-exports */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[243]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[243]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[239];
tp(4,av2);}}

/* k9617 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_9619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9619,2,av);}
/* expand.scm:1507: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[244];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8675 */
static void C_ccall f_8677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(75,c,4)))){
C_save_and_reclaim((void *)f_8677,2,av);}
a=C_alloc(75);
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],t5);
t7=C_a_i_list(&a,1,t6);
t8=t7;
t9=C_i_cddr(((C_word*)t0)[6]);
t10=C_i_length(t9);
t11=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[5])[1],t10);
t12=t11;
t13=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[3]);
t14=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[5])[1]);
t15=C_a_i_list(&a,2,t13,t14);
t16=t15;
t17=((C_word*)t0)[6];
t18=C_u_i_cdr(t17);
t19=C_u_i_cdr(t18);
t20=C_i_length(t19);
t21=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],t20);
t22=t21;
t23=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8756,a[2]=t22,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=t16,a[9]=t12,a[10]=t8,a[11]=t4,a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[5],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
t24=((C_word*)t0)[6];
t25=C_u_i_cdr(t24);
t26=C_u_i_cdr(t25);
/* synrules.scm:162: process-match */
t27=((C_word*)((C_word*)t0)[18])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t27;
av2[1]=t23;
av2[2]=((C_word*)((C_word*)t0)[8])[1];
av2[3]=t26;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t27))(5,av2);}}

/* f_8673 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_8673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(25,c,4)))){
C_save_and_reclaim((void *)f_8673,4,av);}
a=C_alloc(25);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8677,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[16])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=C_i_car(t3);
/* synrules.scm:154: process-match */
t7=((C_word*)((C_word*)t0)[15])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t5;
av2[3]=t6;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(5,av2);}}

/* k5232 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5234,2,av);}
/* expand.scm:358: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8638 in k8524 */
static void C_fcall f_8640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,1)))){
C_save_and_reclaim_args((void *)trf_8640,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_a_i_list(&a,2,lf[210],((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,2,lf[210],((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4643 in k4708 in k4618 in k4606 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_4645,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[53],t2);
/* expand.scm:280: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
C_values(4,av2);}}

/* map-loop662 in k4708 in k4618 in k4606 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4647(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_4647,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10225 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in ... */
static void C_ccall f_10227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10227,2,av);}
/* expand.scm:1299: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[277];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in ... */
static void C_ccall f_10229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_10229,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10233,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1304: r */
t6=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[277];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k10198 in a10195 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_10200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_10200,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1357: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[271];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* k6785 in loop in k6760 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6787,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6791,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:659: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6767(t6,t3,t5);}

/* k9647 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_9649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9649,2,av);}
/* expand.scm:1446: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[248];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5000 in k4988 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,2)))){
C_save_and_reclaim_args((void *)trf_5002,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:375: cadar */
t5=*((C_word*)lf[68]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)((C_word*)t0)[8])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:C_i_nullp(((C_word*)t0)[9]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:379: reverse */
t5=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5077,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:382: reverse */
t6=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k7206 in doloop1398 in k7182 in walk in k7158 in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7208,2,av);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_7189(t4,((C_word*)t0)[5],t2,t3);}

/* ##sys#macro-subset in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9407(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,2)))){
C_save_and_reclaim((void*)f_9407,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9414,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9421,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1539: ##sys#macro-environment */
t9=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}

/* a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_9651(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_9651,5,av);}
a=C_alloc(7);
t5=C_i_length(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9658,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1452: ##sys#check-syntax */
t8=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[248];
av2[3]=t2;
av2[4]=lf[260];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_9658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_9658,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(4)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9821,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1453: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[250];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_9664(2,av2);}}}

/* k5381 in k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5383,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5364(t3,t2);}

/* k10205 in k10198 in a10195 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_10207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,1)))){
C_save_and_reclaim((void *)f_10207,2,av);}
a=C_alloc(30);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_list(&a,3,lf[93],t3,lf[275]);
t5=C_a_i_list(&a,2,lf[272],t4);
t6=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_a_i_list(&a,2,t1,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* a9620 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_9621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_9621,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9625,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1512: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[244];
av2[3]=t2;
av2[4]=lf[247];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9623 in a9620 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_9625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_9625,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,lf[104],t3);
/* expand.scm:1513: ##sys#register-meta-expression */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[246]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[246]+1);
av2[1]=t2;
av2[2]=t4;
tp(3,av2);}}

/* k9626 in k9623 in a9620 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9628,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,lf[104],t3);
t5=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[245],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_fcall f_10251(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_10251,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10265,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10269,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1310: vector->list */
t6=*((C_word*)lf[179]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10288,a[2]=t3,a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=t5,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1315: c */
t9=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[3];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[71],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k10267 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_10269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10269,2,av);}
/* expand.scm:1310: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10241(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k10263 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_10265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_10265,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[197],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* walk in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_fcall f_10241(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_10241,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10249,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1307: walk1 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10251(t5,t4,t2,t3);}

/* k6348 in loop2 in k6330 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_6350,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,((C_word*)t0)[2]);
if(C_truep(t5)){
/* expand.scm:568: ##sys#defjam-error */
t6=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_6353(2,av2);}}}

/* k6351 in k6348 in loop2 in k6330 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,5)))){
C_save_and_reclaim((void *)f_6353,2,av);}
a=C_alloc(12);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_cddr(((C_word*)t0)[4]);
if(C_truep(C_i_pairp(t4))){
t5=C_i_caddr(((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
t7=C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[6]);
/* expand.scm:569: loop */
t8=((C_word*)((C_word*)t0)[7])[1];
f_6294(t8,((C_word*)t0)[8],((C_word*)t0)[9],t3,t6,t7);}
else{
t5=C_a_i_cons(&a,2,lf[111],((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[6]);
/* expand.scm:569: loop */
t7=((C_word*)((C_word*)t0)[7])[1];
f_6294(t7,((C_word*)t0)[8],((C_word*)t0)[9],t3,t5,t6);}}

/* k10247 in walk in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_10249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10249,2,av);}
/* expand.scm:1307: simplify */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10414(t2,((C_word*)t0)[3],t1);}

/* g2010 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static C_word C_fcall f_10925(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_a_i_list(&a,2,lf[210],t1);
return(C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t2));}

/* k7940 in mirror-rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7942,2,av);}
/* expand.scm:893: mirror-rename */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7903(t2,((C_word*)t0)[3],t1);}

/* k9479 in g2741 in k9462 in fixup-macro-environment in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in ... */
static void C_ccall f_9481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9481,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_i_set_car(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11181 in k11178 in k11138 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_11183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(34,c,3)))){
C_save_and_reclaim((void *)f_11183,2,av);}
a=C_alloc(34);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t3);
t5=t4;
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[215],t6,t2);
t8=t7;
t9=C_i_cadddr(((C_word*)t0)[2]);
t10=C_a_i_list(&a,3,lf[215],t9,t2);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11210,a[2]=t8,a[3]=t11,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1210: expand */
t13=((C_word*)((C_word*)t0)[4])[1];
f_11010(t13,t12,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k11178 in k11138 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_11180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_11180,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1203: r */
t3=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}
else{
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_u_i_cdr(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,lf[104],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11237,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1213: expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_11010(t8,t7,((C_word*)t0)[5],C_SCHEME_FALSE);}}

/* k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_6887,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:680: ##sys#print */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7936 in mirror-rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7938,2,av);}
/* expand.scm:893: list->vector */
t2=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6884,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:679: outstr */
t3=((C_word*)t0)[3];
f_6820(t3,t2,lf[137]);}

/* k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6875,2,av);}
a=C_alloc(8);
t2=t1;
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6884,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:678: outstr */
t4=((C_word*)t0)[2];
f_6820(t4,t3,((C_word*)t0)[7]);}
else{
t3=((C_word*)t0)[8];
t4=C_u_i_cdr(t3);
/* expand.scm:699: loop */
t5=((C_word*)((C_word*)t0)[9])[1];
f_6836(t5,((C_word*)t0)[3],t4);}}

/* k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_6872,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6762,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6806,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:656: ##sys#strip-syntax */
t7=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k6204 in k6180 in loop in fini/syntax in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,4)))){
C_save_and_reclaim((void *)f_6206,2,av);}
a=C_alloc(24);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_u_i_car(t2);
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,t4,t6);
t8=C_a_i_cons(&a,2,lf[72],t7);
t9=C_a_i_list(&a,2,lf[23],t8);
t10=C_a_i_list(&a,3,lf[102],t1,t9);
t11=C_a_i_cons(&a,2,t10,((C_word*)t0)[3]);
/* expand.scm:533: loop */
t12=((C_word*)((C_word*)t0)[4])[1];
f_6108(t12,((C_word*)t0)[5],((C_word*)t0)[6],t11,C_SCHEME_FALSE);}

/* k11537 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11539,2,av);}
/* expand.scm:1083: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[325];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_10233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_10233,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10236,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1305: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[278];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k11653 in k11650 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_11655,2,av);}
a=C_alloc(12);
t2=C_i_getprop(((C_word*)t0)[2],lf[5],C_SCHEME_FALSE);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11690,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1033: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[242]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[242]+1);
av2[1]=t6;
tp(2,av2);}}

/* k11650 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_11652,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1031: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[102];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[341];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11855 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11857,2,av);}
/* expand.scm:987: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[347];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11858 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11859,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11863,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:992: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[347];
av2[3]=t2;
av2[4]=lf[348];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11524 in k11521 in a11518 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 in ... */
static void C_ccall f_11526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11526,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[322],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11521 in a11518 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11523,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1098: check-for-multiple-bindings */
f_8090(t2,t3,((C_word*)t0)[2],lf[323]);}

/* k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_10236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_10236,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10239,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1306: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[280];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_10239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,4)))){
C_save_and_reclaim((void *)f_10239,2,av);}
a=C_alloc(28);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10241,a[2]=t8,a[3]=t6,a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10251,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word)li147),tmp=(C_word)a,a+=8,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10414,a[2]=t8,a[3]=((C_word)li150),tmp=(C_word)a,a+=4,tmp));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10507,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1348: ##sys#check-syntax */
t13=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=lf[277];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[290];
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}

/* outstr in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6820(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_6820,3,t0,t1,t2);}
/* expand.scm:665: ##sys#print */
t3=*((C_word*)lf[124]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6825 in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6827,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:700: get-output-string */
t3=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5584 in k5580 in k5561 in k5558 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,1)))){
C_save_and_reclaim((void *)f_5586,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[72],t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[93],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11515 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11517,2,av);}
/* expand.scm:1092: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[321];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* ##sys#undefine-macro! in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4324,3,av);}
/* expand.scm:198: ##sys#unregister-macro */
t3=*((C_word*)lf[30]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5580 in k5561 in k5558 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,4)))){
C_save_and_reclaim((void *)f_5582,2,av);}
a=C_alloc(24);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5586,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[4];
t9=C_i_check_list_2(t8,lf[16]);
t10=C_i_check_list_2(((C_word*)t0)[5],lf[16]);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5626,a[2]=t6,a[3]=t13,a[4]=t7,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_5626(t15,t11,t8,((C_word*)t0)[5]);}

/* k4555 in expand in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4557(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4557,2,av);}
/* expand.scm:261: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
C_values(4,av2);}}

/* a4850 in loop in k4829 in expand in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4851,2,av);}
/* expand.scm:311: ##sys#expand-0 */
t2=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_6818,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6820,a[2]=t2,a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6827,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6836,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word)li79),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6836(t8,t4,*((C_word*)lf[119]+1));}

/* a11518 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11519(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11519,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11523,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1097: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[321];
av2[3]=t2;
av2[4]=lf[324];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11502 in k11499 in a11496 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in ... */
static void C_ccall f_11504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11504,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[106],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11499 in a11496 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 in ... */
static void C_ccall f_11501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11501,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1107: check-for-multiple-bindings */
f_8090(t2,t3,((C_word*)t0)[2],lf[319]);}

/* k4314 in loop in k4289 in unregister-macro in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4316(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4316,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11667 in k11664 in k11653 in k11650 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_11669,2,av);}
a=C_alloc(9);
t2=C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[336],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k11664 in k11653 in k11650 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11666(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,2)))){
C_save_and_reclaim((void *)f_11666,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11679,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11686,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1034: r */
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[102];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* strip-syntax in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_3745,3,av);}
a=C_alloc(9);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3751,a[2]=t4,a[3]=t6,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3751(t8,t1,t2);}

/* a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4348(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_4348,3,av);}
a=C_alloc(15);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li31),tmp=(C_word)a,a+=10,tmp);
/* expand.scm:207: with-exception-handler */
t5=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4341 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4343,2,av);}
/* expand.scm:207: g566 */
t2=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k3692 in macro-alias in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3694,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3697(t3,t1);}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_block_size(t3);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
t5=C_subchar(t3,C_fix(0));
t6=t2;
f_3697(t6,C_i_char_equalp(C_make_character(35),t5));}
else{
t5=t2;
f_3697(t5,C_SCHEME_FALSE);}}}

/* k3695 in k3692 in macro-alias in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_3697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3697,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:91: gensym */
t3=*((C_word*)lf[8]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k11810 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11812,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1016: ##sys#expand-curried-define */
t3=*((C_word*)lf[108]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11608 in k11595 in a11584 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11610,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1071: check-for-multiple-bindings */
f_8090(((C_word*)t0)[3],t2,((C_word*)t0)[2],lf[334]);}

/* a4856 in loop in k4829 in expand in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4857,4,av);}
if(C_truep(t3)){
/* expand.scm:313: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4845(t4,t1,t2);}
else{
t4=t2;
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k11817 in k11810 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11819,2,av);}
/* expand.scm:1016: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_11749(t2,((C_word*)t0)[3],t1);}

/* k4829 in expand in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4831,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4845,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4845(t13,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a11562 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11563,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11567,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1079: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[329];
av2[3]=t2;
av2[4]=lf[331];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* walk in strip-syntax in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(16,0,2)))){
C_save_and_reclaim_args((void *)trf_3751,3,t0,t1,t2);}
a=C_alloc(16);
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t4=t2;
t5=C_i_getprop(t4,lf[5],C_SCHEME_FALSE);
t6=t2;
t7=C_i_getprop(t6,lf[7],C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
if(C_truep(t5)){
if(C_truep(C_i_pairp(t5))){
t8=t2;
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=t4;
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[2])[1]);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t7);
t9=t5;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3823,a[2]=t9,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=C_u_i_car(t11);
/* expand.scm:116: walk */
t14=t10;
t15=t12;
t1=t14;
t2=t15;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t4=C_block_size(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3841,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:121: make-vector */
t7=*((C_word*)lf[11]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}}

/* k11565 in a11562 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11567,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1080: check-for-multiple-bindings */
f_8090(t2,t3,((C_word*)t0)[2],lf[330]);}

/* k6925 in k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6927,2,av);}
/* expand.scm:690: outstr */
t2=((C_word*)t0)[2];
f_6820(t2,((C_word*)t0)[3],t1);}

/* k11559 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11561,2,av);}
/* expand.scm:1074: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[329];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11801 in k11762 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11803,2,av);}
/* expand.scm:1008: ##sys#register-export */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[340]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[340]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k11598 in k11595 in a11584 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11600,2,av);}
t2=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1068: check-for-multiple-bindings */
f_8090(((C_word*)t0)[3],t2,((C_word*)t0)[2],lf[332]);}

/* loop in k4829 in expand in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4845(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_4845,3,t0,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4851,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[4],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:309: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4333(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_4333,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(12);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4343,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4348,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t3,a[6]=t5,a[7]=((C_word*)t0)[2],a[8]=((C_word)li32),tmp=(C_word)a,a+=9,tmp);
/* expand.scm:207: call-with-current-continuation */
t9=*((C_word*)lf[48]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_5556,5,av);}
a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t6=t5;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_END_OF_LIST;
f_5560(2,av2);}}
else{
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=*((C_word*)lf[8]+1);
t11=((C_word*)t0)[3];
t12=C_i_check_list_2(t11,lf[16]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5692,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=t9,a[6]=((C_word)li53),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_5692(t16,t5,t11);}}

/* ##sys#expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(22,c,7)))){
C_save_and_reclaim((void *)f_4330,5,av);}
a=C_alloc(22);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4333,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=t6,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4575,a[2]=t3,a[3]=t8,a[4]=t12,a[5]=t6,a[6]=t4,a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp));
t14=((C_word*)t12)[1];
f_4575(t14,t1,t2);}

/* ##sys#expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,5)))){
C_save_and_reclaim((void *)f_5550,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5556,a[2]=t3,a[3]=t2,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:448: ##sys#decompose-lambda-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[96]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[96]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
tp(4,av2);}}

/* a4359 in a4353 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4360,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4371,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[33]))){
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=t2;
f_4371(t4,C_i_memq(lf[40],t3));}
else{
t3=t2;
f_4371(t3,C_SCHEME_FALSE);}}

/* ##sys#defjam-error in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5544,3,av);}
/* expand.scm:438: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[91];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,6)))){
C_save_and_reclaim_args((void *)trf_4599,2,t0,t1);}
a=C_alloc(9);
t2=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[50]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:275: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[57];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[11])){
if(C_truep(C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t4=((C_word*)((C_word*)t0)[2])[1];
t5=t3;
f_4754(t5,C_i_getprop(t4,lf[59],C_SCHEME_FALSE));}
else{
t4=t3;
f_4754(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4754(t4,C_SCHEME_FALSE);}}}

/* k11543 in a11540 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11545,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1089: check-for-multiple-bindings */
f_8090(t2,t3,((C_word*)t0)[2],lf[327]);}

/* k11546 in k11543 in a11540 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11548,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[326],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a4353 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4354,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4360,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:207: k562 */
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a11540 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11541(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11541,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11545,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1088: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[325];
av2[3]=t2;
av2[4]=lf[328];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* expand in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2)))){
C_save_and_reclaim((void*)f_4827,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4831,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* expand.scm:309: ##sys#current-environment */
t6=*((C_word*)lf[1]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=t5;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_i_car(t4);
f_4831(2,av2);}}}

/* macro-alias in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_3687(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3687,3,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3694,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:85: ##sys#qualified-symbol? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[9]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[9]+1);
av2[1]=t4;
av2[2]=t2;
tp(3,av2);}}

/* k10192 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_10194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10194,2,av);}
/* expand.scm:1351: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[274];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a10195 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_10196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_10196,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10200,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1356: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[274];
av2[3]=t2;
av2[4]=lf[276];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* get-line-number in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_6978,3,av);}
a=C_alloc(4);
if(C_truep(*((C_word*)lf[117]+1))){
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
if(C_truep(C_i_symbolp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6998,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:710: ##sys#hash-table-ref */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[144]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[144]+1);
av2[1]=t5;
av2[2]=*((C_word*)lf[117]+1);
av2[3]=t4;
tp(4,av2);}}
else{
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##sys#syntax-rules-mismatch in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6972,3,av);}
/* expand.scm:703: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[142];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4285 in unregister-macro in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4287,2,av);}
/* expand.scm:190: ##sys#macro-environment */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3698 in k3695 in k3692 in macro-alias in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,1)))){
C_save_and_reclaim((void *)f_3700,2,av);}
a=C_alloc(16);
t2=(
  /* expand.scm:92: lookup */
  f_3670(((C_word*)t0)[2],((C_word*)t0)[3])
);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_i_getprop(t4,lf[7],C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_a_i_putprop(&a,3,t1,lf[5],t3);
t7=C_a_i_putprop(&a,3,t1,lf[7],t5);
t8=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t6=((C_word*)t0)[2];
t7=C_a_i_putprop(&a,3,t1,lf[5],t3);
t8=C_a_i_putprop(&a,3,t1,lf[7],t6);
t9=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k3654 */
static void C_ccall f_3656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3656,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##sys#features ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:73: make-parameter */
t4=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop2004 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_fcall f_10942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(18,0,2)))){
C_save_and_reclaim_args((void *)trf_10942,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
  /* expand.scm:1248: g2010 */
  f_10925(C_a_i(&a,15),((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10938 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_10940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_10940,2,av);}
a=C_alloc(14);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10885,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10892,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=C_i_length(((C_word*)t0)[6]);
t7=C_eqp(t6,C_fix(3));
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[6]);
/* expand.scm:1252: c */
t9=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=((C_word*)t0)[9];
av2[3]=t8;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}
else{
t8=t5;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_10892(2,av2);}}}

/* k5561 in k5558 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_5563,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:456: append */
t6=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5558 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5560,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[6];
if(C_truep(t4)){
/* expand.scm:452: gensym */
t5=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
f_5563(2,av2);}}}

/* k11493 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11495,2,av);}
/* expand.scm:1101: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[318];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3662 in k3658 in k3654 */
static void C_ccall f_3664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3664,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[2]+1 /* (set! ##sys#current-meta-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:77: make-parameter */
t4=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[1]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3658 in k3654 */
static void C_ccall f_3660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3660,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:74: make-parameter */
t4=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,4)))){
C_save_and_reclaim((void *)f_3668,2,av);}
a=C_alloc(18);
t2=C_mutate2((C_word*)lf[3]+1 /* (set! ##sys#active-eval-environment ...) */,t1);
t3=C_mutate2(&lf[4] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2(&lf[6] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[10]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3745,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[12]+1 /* (set! ##sys#strip-syntax ...) */,*((C_word*)lf[10]+1));
t7=C_mutate2((C_word*)lf[13]+1 /* (set! ##sys#extend-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3882,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[17]+1 /* (set! ##sys#globalize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4146,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:156: make-parameter */
t10=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k10171 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_10173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10173,2,av);}
/* expand.scm:1361: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[271];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4266 in k4244 in macro? in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4268,2,av);}
t2=(
  /* expand.scm:186: lookup */
  f_3670(((C_word*)t0)[2],t1)
);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=(C_truep(t2)?C_i_pairp(t2):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6996 in get-line-number in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6998,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7002,a[2]=((C_word*)t0)[2],a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:705: g1321 */
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=(
  /* expand.scm:705: g1321 */
  f_7002(t2,t1)
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7417 in walk in k7158 in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7419,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:795: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7165(t6,((C_word*)t0)[5],t3,t5);}

/* a11496 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_11497,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11501,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1106: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[318];
av2[3]=t2;
av2[4]=lf[320];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10177 in a10174 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_10179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,1)))){
C_save_and_reclaim((void *)f_10179,2,av);}
a=C_alloc(15);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[272],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a10174 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_10175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_10175,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10179,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1366: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[271];
av2[3]=t2;
av2[4]=lf[273];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* g464 in loop1 in globalize in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_4084,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
/* expand.scm:145: loop1 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4068(t3,t1,t2);}
else{
t3=((C_word*)t0)[3];
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop1074 in k5953 in k5950 in k5947 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_5960,5,t0,t1,t2,t3,t4);}
a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_5967(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_5967(t6,C_SCHEME_FALSE);}}

/* k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6896,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:683: outstr */
t3=((C_word*)t0)[3];
f_6820(t3,t2,lf[135]);}

/* k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6893,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:682: ##sys#print */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5965 in map-loop1074 in k5953 in k5950 in k5947 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,0,3)))){
C_save_and_reclaim_args((void *)trf_5967,2,t0,t1);}
a=C_alloc(17);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(0));
t4=C_slot(((C_word*)t0)[4],C_fix(0));
if(C_truep(C_slot(((C_word*)t0)[5],C_fix(0)))){
/* expand.scm:513: ##sys#expand-multiple-values-assignment */
t5=*((C_word*)lf[92]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=C_i_car(t3);
t6=t2;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[95],t5,t4);
f_5993(2,av2);}}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[8],C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_6890,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:681: outstr */
t3=((C_word*)t0)[3];
f_6820(t3,t2,lf[136]);}

/* k5056 in k5000 in k4988 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_5058,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
/* expand.scm:357: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=t5;
C_values(4,av2);}}

/* ##sys#globalize in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4062,4,av);}
a=C_alloc(7);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4068,a[2]=t5,a[3]=t3,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4068(t7,t1,t2);}

/* loop in k4289 in unregister-macro in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_4293,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_caar(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_u_i_cdr(t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4316,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:195: loop */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}}

/* k4289 in unregister-macro in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4291,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4293(t5,((C_word*)t0)[3],t1);}

/* k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_6899,2,av);}
a=C_alloc(13);
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6916,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_car(((C_word*)t0)[2]);
/* expand.scm:688: symbol->string */
t7=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6931,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6933,a[2]=t7,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6933(t9,t5,((C_word*)t0)[2]);}}

/* k10151 in k10135 in expand in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_10153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10153,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[104],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* expand.scm:1421: expand */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10047(t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k5079 in k5000 in k4988 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_5081,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,t2);
/* expand.scm:382: ##sys#append */
t4=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=C_a_i_list1(&a,1,t3);
/* expand.scm:382: ##sys#append */
t5=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k4048 in map-loop354 in extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4050,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4025(t6,((C_word*)t0)[5],t5);}

/* k10624 in k10583 in k10562 in k10534 in k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_10626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(39,c,1)))){
C_save_and_reclaim((void *)f_10626,2,av);}
a=C_alloc(39);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[53],t2);
t4=C_a_i_list(&a,3,lf[104],((C_word*)t0)[3],t3);
t5=C_a_i_list(&a,4,lf[293],((C_word*)t0)[4],((C_word*)t0)[5],t4);
t6=((C_word*)t0)[6];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[50],((C_word*)t0)[2],((C_word*)t0)[7],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* map-loop2103 in k10583 in k10562 in k10534 in k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_fcall f_10628(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10628,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10653,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_cdr(t4);
t6=C_i_cdr(t5);
t7=C_eqp(t6,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=C_u_i_car(t4);
t9=t3;
f_10653(t9,t8);}
else{
t8=C_u_i_cdr(t4);
t9=C_i_cdr(t8);
t10=t3;
f_10653(t10,C_i_car(t9));}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9514 in for-each-loop2740 in k9462 in fixup-macro-environment in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in ... */
static void C_ccall f_9516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9516,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9506(t3,((C_word*)t0)[4],t2);}

/* loop1 in globalize in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4068(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_4068,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=C_i_getprop(t3,lf[5],C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:141: g464 */
t6=t5;
f_4084(t6,t1,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4102,a[2]=t2,a[3]=t6,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4102(t8,t1,((C_word*)t0)[3]);}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5075 in k5000 in k4988 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_5077,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
/* expand.scm:357: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=t5;
C_values(4,av2);}}

/* k9205 in k9156 */
static void C_ccall f_9207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9207,2,av);}
/* synrules.scm:258: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* f_9209 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_9209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_9209,6,av);}
a=C_alloc(8);
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,t5))){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_assq(t2,t4);
if(C_truep(t6)){
t7=C_i_cdr(t6);
t8=t3;
t9=C_fixnum_greater_or_equal_p(t7,t8);
t10=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=(C_truep(t9)?C_a_i_cons(&a,2,t2,t5):t5);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t7=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9251,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=t4,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:270: segment-template? */
t7=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}}

/* a7361 in walk in k7158 in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7362,3,av);}
t3=(C_truep(C_i_symbolp(t2))?(
  /* expand.scm:787: lookup */
  f_3670(t2,((C_word*)t0)[2])
):C_SCHEME_FALSE);
if(C_truep(C_i_symbolp(t3))){
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_eqp(t3,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_eqp(t4,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k9249 */
static void C_ccall f_9251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_9251,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_cddr(((C_word*)t0)[2]);
/* synrules.scm:273: free-meta-variables */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9281,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* synrules.scm:278: free-meta-variables */
t7=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:281: vector->list */
t3=*((C_word*)lf[179]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* k5925 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_5927,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[50],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10135 in expand in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_10137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_10137,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(C_truep(t3)?lf[269]:C_a_i_cons(&a,2,lf[104],t2));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1420: test */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9911(t3,t2,((C_word*)t0)[7]);}}

/* k11385 in a11363 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in ... */
static void C_ccall f_11387(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_11387,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11406,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1150: r */
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[221];
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}

/* k11633 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11635(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11635,2,av);}
/* expand.scm:1022: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[102];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_11637,5,av);}
a=C_alloc(8);
t5=C_i_cadr(t2);
t6=t5;
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
if(C_truep(C_i_pairp(t6))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11693,a[2]=t6,a[3]=t9,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1038: ##sys#check-syntax */
t11=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[102];
av2[3]=t6;
av2[4]=lf[339];
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11652,a[2]=t6,a[3]=t9,a[4]=t1,a[5]=t2,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1030: ##sys#check-syntax */
t11=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[102];
av2[3]=t6;
av2[4]=lf[162];
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}}

/* lookup in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_3670(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
t3=C_u_i_assq(t1,t2);
if(C_truep(t3)){
return(C_i_cdr(t3));}
else{
t4=t1;
t5=C_i_getprop(t4,lf[5],C_SCHEME_FALSE);
return((C_truep(t5)?t5:C_SCHEME_FALSE));}}

/* k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,2)))){
C_save_and_reclaim((void *)f_5923,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5927,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5949,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:515: reverse */
t9=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k9260 in k9249 */
static void C_ccall f_9262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9262,2,av);}
/* synrules.scm:271: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=t1;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k5956 in k5953 in k5950 in k5947 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5958,2,av);}
/* expand.scm:471: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9542 in k9538 in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9544,2,av);}
t2=C_mutate2((C_word*)lf[233]+1 /* (set! ##sys#meta-macro-environment ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9538 in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_9540,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[89]+1 /* (set! ##sys#default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9548,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1561: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k11820 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_11822,2,av);}
a=C_alloc(15);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_car(((C_word*)t0)[3]);
t4=C_u_i_cdr(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,lf[72],t5);
t7=C_a_i_list3(&a,3,t2,t3,t6);
/* expand.scm:1019: loop */
t8=((C_word*)((C_word*)t0)[5])[1];
f_11749(t8,((C_word*)t0)[6],t7);}

/* k10651 in map-loop2103 in k10583 in k10562 in k10534 in k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_fcall f_10653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10653,2,t0,t1);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10628(t6,((C_word*)t0)[5],t5);}

/* k5950 in k5947 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5952,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:517: reverse */
t4=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5953 in k5950 in k5947 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,5)))){
C_save_and_reclaim((void *)f_5955,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5960(t6,t2,((C_word*)t0)[6],((C_word*)t0)[7],t1);}

/* k5947 in k5921 in k5915 in k5912 in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5949,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:516: reverse */
t4=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5031 in k5000 in k4988 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,3)))){
C_save_and_reclaim((void *)f_5033,2,av);}
a=C_alloc(27);
t2=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,lf[50],t5);
t7=C_a_i_list(&a,1,t6);
/* expand.scm:357: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[6];
av2[2]=((C_word*)t0)[7];
av2[3]=t7;
C_values(4,av2);}}

/* map-loop354 in extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4025(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4025,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:130: g360 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11054 in k11050 in k11047 in k11044 in k11041 in k11035 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_11056(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11056,2,av);}
/* expand.scm:1168: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[188]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[188]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k11050 in k11047 in k11044 in k11041 in k11035 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_11052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_11052,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11056,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1170: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k11047 in k11044 in k11041 in k11035 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_11049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_11049,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1169: get-output-string */
t3=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11044 in k11041 in k11035 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_11046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_11046,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1169: ##sys#print */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[308];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11041 in k11035 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_11043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_11043,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1169: ##sys#print */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11072 in k11066 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_11074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_11074,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=C_u_i_car(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=C_u_i_car(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[104],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k9502 in k9462 in fixup-macro-environment in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in ... */
static void C_ccall f_9504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9504,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop2740 in k9462 in fixup-macro-environment in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in ... */
static void C_fcall f_9506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_9506,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9516,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:1545: g2741 */
t5=((C_word*)t0)[3];
f_9465(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8625 in k8524 */
static void C_ccall f_8627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8627,2,av);}
/* synrules.scm:146: process-match */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t1;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* f_8332 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_8332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(51,c,3)))){
C_save_and_reclaim((void *)f_8332,3,av);}
a=C_alloc(51);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[2])[1]);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],t5);
t7=C_a_i_list(&a,1,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8360,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=((C_word*)t12)[1];
t14=((C_word*)((C_word*)t0)[10])[1];
t15=C_i_check_list_2(t2,lf[16]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8384,a[2]=t12,a[3]=t18,a[4]=t14,a[5]=t13,a[6]=((C_word)li109),tmp=(C_word)a,a+=7,tmp));
t20=((C_word*)t18)[1];
f_8384(t20,t16,t2);}

/* a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in ... */
static void C_ccall f_10992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_10992,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10999,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1158: r */
t8=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[304];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}

/* k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in ... */
static void C_ccall f_10999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_10999,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11002,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1159: r */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[221];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10988 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in ... */
static void C_ccall f_10990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10990,2,av);}
/* expand.scm:1152: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[228];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_11065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_11065,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11117,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1185: strip-syntax */
t5=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=C_u_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=C_u_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1193: expand */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11010(t5,t4,((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=C_i_length(((C_word*)t0)[2]);
t5=C_eqp(t4,C_fix(3));
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1195: c */
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}
else{
t6=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_11140(2,av2);}}}}}

/* k11066 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_11068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_11068,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(3));
if(C_truep(t4)){
t5=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1187: c */
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}
else{
t5=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_11074(2,av2);}}}

/* k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_11062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_11062,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t1;
f_11065(2,av2);}}
else{
t3=C_u_i_car(((C_word*)t0)[2]);
t4=C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t4)){
t5=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
f_11065(2,av2);}}
else{
t5=C_u_i_car(((C_word*)t0)[2]);
t6=C_i_numberp(t5);
if(C_truep(t6)){
t7=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
f_11065(2,av2);}}
else{
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_charp(t7);
if(C_truep(t8)){
t9=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
f_11065(2,av2);}}
else{
t9=C_u_i_car(((C_word*)t0)[2]);
t10=C_i_stringp(t9);
if(C_truep(t10)){
t11=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t11;
av2[1]=t10;
f_11065(2,av2);}}
else{
t11=C_u_i_car(((C_word*)t0)[2]);
t12=C_eofp(t11);
if(C_truep(t12)){
t13=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=t12;
f_11065(2,av2);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11300,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t14=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1180: blob? */
t15=*((C_word*)lf[312]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t13;
av2[2]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}}}}}}

/* k11478 in k11455 in a11452 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in ... */
static void C_ccall f_11480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11480,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in ... */
static void C_fcall f_11010(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_11010,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11024,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1166: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[228];
av2[3]=t5;
av2[4]=lf[313];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[314];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in ... */
static void C_ccall f_8319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(51,c,2)))){
C_save_and_reclaim((void *)f_8319,2,av);}
a=C_alloc(51);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|50,a[1]=(C_word)f_8324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[2],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],tmp=(C_word)a,a+=51,tmp);
/* synrules.scm:101: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[52];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in ... */
static void C_ccall f_8315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8315,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:99: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[218];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in ... */
static void C_ccall f_8311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8311,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:98: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[219];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k7661 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7663,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:846: compare */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[5];
av2[2]=t3;
av2[3]=t5;
f_7641(4,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in ... */
static void C_ccall f_11005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_11005,2,av);}
a=C_alloc(11);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11010,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word)li161),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_11010(t6,((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_FALSE);}

/* k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in ... */
static void C_ccall f_11002(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_11002,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1160: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[227];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in ... */
static void C_ccall f_8324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(119,c,6)))){
C_save_and_reclaim((void *)f_8324,2,av);}
a=C_alloc(119);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp));
t4=C_mutate2(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8332,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word)li110),tmp=(C_word)a,a+=13,tmp));
t5=C_mutate2(((C_word *)((C_word*)t0)[14])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8426,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[19],a[6]=((C_word*)t0)[20],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[21],a[9]=((C_word)li112),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate2(((C_word *)((C_word*)t0)[21])+1,(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8492,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[23],a[6]=((C_word*)t0)[24],a[7]=((C_word*)t0)[25],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[26],a[13]=((C_word*)t0)[27],a[14]=((C_word*)t0)[28],a[15]=((C_word*)t0)[29],a[16]=((C_word*)t0)[30],a[17]=((C_word*)t0)[31],a[18]=((C_word)li113),tmp=(C_word)a,a+=19,tmp));
t7=C_mutate2(((C_word *)((C_word*)t0)[23])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8673,a[2]=((C_word*)t0)[32],a[3]=((C_word*)t0)[33],a[4]=((C_word*)t0)[34],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[36],a[7]=((C_word*)t0)[37],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[38],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[39],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[26],a[17]=((C_word)li114),tmp=(C_word)a,a+=18,tmp));
t8=C_mutate2(((C_word *)((C_word*)t0)[20])+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8800,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[24],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[26],a[9]=((C_word*)t0)[28],a[10]=((C_word*)t0)[31],a[11]=((C_word)li116),tmp=(C_word)a,a+=12,tmp));
t9=C_mutate2(((C_word *)((C_word*)t0)[18])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8940,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[18],a[4]=((C_word*)t0)[41],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[42],a[7]=((C_word*)t0)[43],a[8]=((C_word*)t0)[44],a[9]=((C_word*)t0)[45],a[10]=((C_word*)t0)[46],a[11]=((C_word*)t0)[47],a[12]=((C_word*)t0)[48],a[13]=((C_word)li118),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate2(((C_word *)((C_word*)t0)[19])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9132,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[31],a[5]=((C_word)li119),tmp=(C_word)a,a+=6,tmp));
t11=C_mutate2(((C_word *)((C_word*)t0)[43])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9209,a[2]=((C_word*)t0)[43],a[3]=((C_word*)t0)[48],a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate2(((C_word *)((C_word*)t0)[31])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9298,a[2]=((C_word*)t0)[48],a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t13=C_mutate2(((C_word *)((C_word*)t0)[48])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9326,a[2]=((C_word*)t0)[3],a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate2(((C_word *)((C_word*)t0)[44])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9350,a[2]=((C_word*)t0)[44],a[3]=((C_word*)t0)[48],a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate2(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9370,a[2]=((C_word*)t0)[3],a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp));
/* synrules.scm:314: make-transformer */
t16=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=((C_word*)t0)[49];
av2[2]=((C_word*)t0)[50];
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}

/* f_8326 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_8326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8326,3,av);}
/* synrules.scm:104: c */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k8617 in k8524 */
static void C_ccall f_8619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,1)))){
C_save_and_reclaim((void *)f_8619,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[6];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_a_i_list(&a,1,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k11031 in k11028 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_11033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11033,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[306];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11035 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_11037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_11037,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[307]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1169: ##sys#print */
t6=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[309];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11028 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_11030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_11030,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1171: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11010(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7641(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
av[0]=t0;
av[1]=t1;
av[2]=t2;
av[3]=t3;
C_save_and_reclaim((void *)f_7641,4,av);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7663,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=t3;
t8=C_u_i_car(t7);
/* expand.scm:845: compare */
t14=t4;
t15=t6;
t16=t8;
t1=t14;
t2=t15;
t3=t16;
c=4;
goto loop;}
else{
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
if(C_truep(C_i_vectorp(t2))){
if(C_truep(C_i_vectorp(t3))){
t4=t2;
t5=C_block_size(t4);
t6=t5;
t7=t3;
t8=C_block_size(t7);
t9=C_eqp(t6,t8);
if(C_truep(t9)){
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7700,a[2]=t6,a[3]=t11,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word)li96),tmp=(C_word)a,a+=8,tmp));
t13=((C_word*)t11)[1];
f_7700(t13,t1,C_fix(0),C_SCHEME_TRUE);}
else{
t10=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t10;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_i_symbolp(t2);
t5=(C_truep(t4)?C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t2;
t7=C_i_getprop(t6,lf[5],C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7752,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_7752(t9,t7);}
else{
t9=t2;
t10=((C_word*)t0)[3];
t11=(
  /* expand.scm:877: lookup */
  f_3670(t9,t10)
);
if(C_truep(t11)){
t12=t8;
f_7752(t12,t11);}
else{
t12=t2;
t13=t8;
f_7752(t13,t12);}}}
else{
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_eqp(t2,t3);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}

/* k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_11024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_11024,2,av);}
a=C_alloc(11);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11037,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1169: open-output-string */
t4=*((C_word*)lf[141]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11062,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* expand.scm:1173: c */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[11];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}}

/* k3909 in k3884 in extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,4)))){
C_save_and_reclaim((void *)f_3911,2,av);}
a=C_alloc(17);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3928,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3928(t11,t7,t6,((C_word*)t0)[5]);}

/* k3924 in k3909 in k3884 in extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3926,2,av);}
/* expand.scm:136: append */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop417 in k3909 in k3884 in extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3928,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k8358 */
static void C_ccall f_8360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,1)))){
C_save_and_reclaim((void *)f_8360,2,av);}
a=C_alloc(27);
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],t3);
t5=((C_word*)t0)[7];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[23],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k8828 */
static void C_ccall f_8830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,5)))){
C_save_and_reclaim((void *)f_8830,2,av);}
a=C_alloc(25);
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_i_length(t2);
t4=t3;
t5=C_eqp(t4,C_fix(0));
t6=(C_truep(t5)?((C_word*)t0)[3]:C_a_i_list(&a,3,lf[211],((C_word*)t0)[3],t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8843,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t9=((C_word*)t0)[2];
t10=C_u_i_car(t9);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8859,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t7,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word)li115),tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:181: process-pattern */
t12=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t12;
av2[1]=t8;
av2[2]=t10;
av2[3]=((C_word*)((C_word*)t0)[7])[1];
av2[4]=t11;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t12))(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[3]);
/* synrules.scm:192: process-pattern */
t6=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=t4;
av2[3]=t5;
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:195: vector->list */
t3=*((C_word*)lf[179]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* k8822 */
static void C_ccall f_8824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_8824,2,av);}
a=C_alloc(9);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list1(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* f_8800 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_8800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_8800,6,av);}
a=C_alloc(13);
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8824,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* synrules.scm:174: mapit */
t7=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8830,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* synrules.scm:175: segment-pattern? */
t7=((C_word*)((C_word*)t0)[10])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_8228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8228,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8231,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9556,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9558,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
/* synrules.scm:47: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_8225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8225,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9594,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1519: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_8222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8222,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9619,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9621,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1510: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* f_9132 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_9132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_9132,6,av);}
a=C_alloc(7);
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_a_i_cons(&a,2,t2,t3);
t7=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_cons(&a,2,t6,t4);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9158,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:251: segment-pattern? */
t7=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in ... */
static void C_ccall f_8286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8286,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[2],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:88: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[88];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in ... */
static void C_ccall f_8282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8282,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8286,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[2],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:87: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[55];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* map-loop2069 in k10534 in k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_fcall f_10678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_10678,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_u_i_cdr(t3);
t6=C_i_car(t5);
t7=C_a_i_list2(&a,2,t4,t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* syntax-error in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2)))){
C_save_and_reclaim((void*)f_6740,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6748,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:649: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6746 in syntax-error in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6748,2,av);}{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[121]+1);
av2[3]=lf[122];
av2[4]=t1;
C_apply(5,av2);}}

/* ##sys#canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2)))){
C_save_and_reclaim((void*)f_5729,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5733,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* expand.scm:472: ##sys#current-environment */
t6=*((C_word*)lf[1]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=t5;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_i_car(t4);
f_5733(2,av2);}}}

/* k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in ... */
static void C_ccall f_8295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8295,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[205]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[206]);
t5=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8302,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],a[26]=((C_word*)t0)[29],a[27]=((C_word*)t0)[30],a[28]=((C_word*)t0)[31],a[29]=((C_word*)t0)[32],a[30]=((C_word*)t0)[33],a[31]=((C_word*)t0)[34],a[32]=((C_word*)t0)[35],a[33]=((C_word*)t0)[36],a[34]=((C_word*)t0)[37],a[35]=((C_word*)t0)[38],a[36]=((C_word*)t0)[39],a[37]=((C_word*)t0)[40],a[38]=((C_word*)t0)[41],a[39]=((C_word*)t0)[2],a[40]=((C_word*)t0)[42],a[41]=((C_word*)t0)[3],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[4],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:94: r */
t6=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[221];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in ... */
static void C_ccall f_8290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8290,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[204]);
t4=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8295,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[2],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:90: r */
t5=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[222];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k6730 in expand-curried-define in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_6732,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,lf[101],((C_word*)((C_word*)t0)[3])[1],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5715 in map-loop898 in a5555 in expand-multiple-values-assignment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5717,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5692(t6,((C_word*)t0)[5],t5);}

/* k6760 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6762,2,av);}
a=C_alloc(6);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6767,a[2]=t4,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6767(t6,((C_word*)t0)[2],t2);}

/* loop in k6760 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6767(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6767,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_caar(t2);
t4=C_eqp(lf[138],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6787,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:659: cadar */
t6=*((C_word*)lf[68]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* expand.scm:660: loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k9156 */
static void C_ccall f_9158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_9158,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cddr(((C_word*)t0)[2]);
/* synrules.scm:253: meta-variables */
t8=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t8))(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* synrules.scm:256: meta-variables */
t7=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9207,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:258: vector->list */
t3=*((C_word*)lf[179]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in ... */
static void C_ccall f_8278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8278,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[2],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:86: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[223];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in ... */
static void C_ccall f_8274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8274,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[2],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:85: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[224];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in ... */
static void C_ccall f_8270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8270,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[2],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:84: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[225];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8845 in k8841 in k8828 */
static void C_ccall f_8847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8847,2,av);}
/* synrules.scm:180: append */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##sys#syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6751,4,av);}
a=C_alloc(5);
if(C_truep(C_i_nullp(*((C_word*)lf[119]+1)))){
/* expand.scm:662: ##sys#syntax-error-hook */
t4=*((C_word*)lf[41]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6818,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:663: open-output-string */
t5=*((C_word*)lf[141]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k8841 in k8828 */
static void C_ccall f_8843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,5)))){
C_save_and_reclaim((void *)f_8843,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8847,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_a_i_list(&a,3,lf[212],((C_word*)t0)[4],((C_word*)t0)[5]);
/* synrules.scm:189: process-pattern */
t6=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
av2[4]=((C_word*)t0)[7];
av2[5]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}

/* k9104 in k9100 in k8977 */
static void C_ccall f_9106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9106,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9100 in k8977 */
static void C_ccall f_9102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_9102,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* synrules.scm:237: process-template */
t6=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t6))(5,av2);}}

/* k7101 in loop in k7073 in lambda-list? in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7103,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a11963 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,9)))){
C_save_and_reclaim((void *)f_11964,5,av);}
t5=*((C_word*)lf[354]+1);
/* expand.scm:936: g1651 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[354]+1));
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=*((C_word*)lf[354]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
av2[5]=*((C_word*)lf[1]+1);
av2[6]=*((C_word*)lf[19]+1);
av2[7]=C_SCHEME_FALSE;
av2[8]=C_SCHEME_FALSE;
av2[9]=lf[356];
tp(10,av2);}}

/* k11960 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11962,2,av);}
/* expand.scm:933: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[356];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9121 in k8977 */
static void C_ccall f_9123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_9123,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* doloop331 in k3839 in walk in strip-syntax in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_3850,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
/* expand.scm:125: walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3751(t5,t3,t4);}}

/* k9442 in loop in k9419 in macro-subset in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in ... */
static void C_ccall f_9444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9444,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9412 in macro-subset in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9414,2,av);}
/* expand.scm:1543: ##sys#fixup-macro-environment */
t2=*((C_word*)lf[232]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* loop in proper-list? in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_7139(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
t2=C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep(C_i_pairp(t1))){
t3=t1;
t4=C_u_i_cdr(t3);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k7129 in loop in k7073 in lambda-list? in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7131(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7131,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* expand.scm:741: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7083(t4,((C_word*)t0)[2],t3);}}

/* proper-list? in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7133,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7139,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(
  f_7139(t2)
);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* doloop1505 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7700(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_7700,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:C_i_not(t3));
if(C_truep(t5)){
t6=t3;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_fixnum_plus(t2,C_fix(1));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7721,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=C_i_vector_ref(((C_word*)t0)[4],t2);
t10=C_i_vector_ref(((C_word*)t0)[5],t2);
/* expand.scm:852: compare */
t11=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[4];
av2[0]=t11;
av2[1]=t8;
av2[2]=t9;
av2[3]=t10;
f_7641(4,av2);}}}

/* loop in k9419 in macro-subset in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in ... */
static void C_fcall f_9423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_9423,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?t3:C_eqp(t2,((C_word*)t0)[2]));
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_i_car(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9444,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:1542: loop */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k9419 in macro-subset in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_9421,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9423,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li127),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9423(t5,((C_word*)t0)[3],t1);}

/* k3839 in walk in strip-syntax in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_3841,2,av);}
a=C_alloc(16);
t2=t1;
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word)li2),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_3850(t9,((C_word*)t0)[6],C_fix(0));}

/* k3821 in walk in strip-syntax in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3823,2,av);}
a=C_alloc(5);
t2=C_i_setslot(((C_word*)t0)[2],C_fix(0),t1);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3816,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* expand.scm:117: walk */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3751(t7,t4,t6);}

/* k5302 in k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5304,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5288(t3,t2);}

/* ##sys#fixup-macro-environment in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,3)))){
C_save_and_reclaim((void*)f_9457,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9464,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
/* expand.scm:1546: ##sys#append */
t7=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t6;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t2;
f_9464(2,av2);}}}

/* k9462 in fixup-macro-environment in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_9464,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9465,a[2]=t2,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=C_i_check_list_2(t4,lf[14]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9506,a[2]=t8,a[3]=t3,a[4]=((C_word)li130),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_9506(t10,t6,t4);}

/* g2741 in k9462 in fixup-macro-environment in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in ... */
static void C_fcall f_9465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_9465,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9481,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
if(C_truep(C_i_nullp(t7))){
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_i_set_car(t5,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=t2;
t9=C_u_i_cdr(t8);
t10=C_u_i_car(t9);
/* expand.scm:1554: ##sys#append */
t11=*((C_word*)lf[70]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=t6;
av2[2]=t10;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k6330 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_6332,2,av);}
a=C_alloc(12);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6337,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li66),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6337(t5,((C_word*)t0)[8],((C_word*)t0)[9]);}

/* loop2 in k6330 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,6)))){
C_save_and_reclaim_args((void *)trf_6337,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_cadr(t2);
t4=t3;
if(C_truep(C_i_pairp(t4))){
t5=C_i_car(t4);
if(C_truep(C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6403,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:576: ##sys#check-syntax */
t7=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[101];
av2[3]=t2;
av2[4]=lf[109];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6417,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:581: ##sys#check-syntax */
t7=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[101];
av2[3]=t2;
av2[4]=lf[110];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6350,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:566: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[101];
av2[3]=t2;
av2[4]=lf[112];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(7,av2);}}}

/* k5320 in k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_5322,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t3)){
t4=t2;
f_5325(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_i_car(((C_word*)t0)[2]);
t5=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t4);
t6=t2;
f_5325(t6,t5);}}
else{
/* expand.scm:410: err */
t2=((C_word*)t0)[9];
f_4944(t2,((C_word*)t0)[5],lf[78]);}}

/* k5323 in k5320 in k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,6)))){
C_save_and_reclaim_args((void *)trf_5325,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_u_i_cdr(((C_word*)t0)[2]);
/* expand.scm:409: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4972(t5,((C_word*)t0)[5],C_fix(2),((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_END_OF_LIST,t4);}

/* k8564 in k8524 */
static void C_ccall f_8566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_8566,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8570,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* synrules.scm:142: process-match */
t7=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=t6;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(5,av2);}}

/* k8560 in k8524 */
static void C_ccall f_8562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,1)))){
C_save_and_reclaim((void *)f_8562,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[6];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_a_i_list(&a,1,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k8568 in k8564 in k8524 */
static void C_ccall f_8570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8570,2,av);}
/* expand.scm:1533: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5362 in k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,6)))){
C_save_and_reclaim_args((void *)trf_5364,2,t0,t1);}
if(C_truep(C_fixnum_less_or_equal_p(((C_word*)t0)[2],C_fix(2)))){
/* expand.scm:415: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4972(t2,((C_word*)t0)[4],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}
else{
/* expand.scm:416: err */
t2=((C_word*)t0)[8];
f_4944(t2,((C_word*)t0)[4],lf[80]);}}

/* k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,6)))){
C_save_and_reclaim_args((void *)trf_6314,2,t0,t1);}
a=C_alloc(14);
if(C_truep(C_i_symbolp(t1))){
t2=(
  /* expand.scm:561: comp */
  f_5744(((C_word*)((C_word*)t0)[2])[1],lf[101],t1)
);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6332,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:562: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[101];
av2[3]=((C_word*)t0)[10];
av2[4]=lf[113];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}
else{
t3=(
  /* expand.scm:588: comp */
  f_5744(((C_word*)((C_word*)t0)[2])[1],lf[102],t1)
);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:589: ##sys#check-syntax */
t5=*((C_word*)lf[54]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[102];
av2[3]=((C_word*)t0)[10];
av2[4]=lf[114];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
t4=(
  /* expand.scm:591: comp */
  f_5744(((C_word*)((C_word*)t0)[2])[1],lf[103],t1)
);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6481,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:593: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[103];
av2[3]=((C_word*)t0)[10];
av2[4]=lf[115];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(7,av2);}}
else{
t5=(
  /* expand.scm:595: comp */
  f_5744(((C_word*)((C_word*)t0)[2])[1],lf[104],t1)
);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_i_cdr(((C_word*)t0)[10]);
/* expand.scm:596: ##sys#append */
t8=*((C_word*)lf[70]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t6=C_a_i_list1(&a,1,t1);
if(C_truep(C_i_member(t6,((C_word*)t0)[4]))){
/* expand.scm:599: fini */
t7=((C_word*)((C_word*)t0)[13])[1];
f_5810(t7,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[12]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6533,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:600: ##sys#expand-0 */
t8=*((C_word*)lf[32]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[10];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[14];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}}}}}
else{
/* expand.scm:559: fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_5810(t2,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[12]);}}

/* k6804 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6806,2,av);}
/* expand.scm:656: ##sys#get */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[139]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[139]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[140];
tp(4,av2);}}

/* k6863 in k6853 in k6850 in k6847 in k6844 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6865,2,av);}
/* expand.scm:672: ##sys#print */
t2=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6850 in k6847 in k6844 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6852,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:671: outstr */
t3=((C_word*)t0)[2];
f_6820(t3,t2,lf[127]);}

/* k6853 in k6850 in k6847 in k6844 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6855(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6855,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6865,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(*((C_word*)lf[119]+1));
/* expand.scm:672: ##sys#strip-syntax */
t5=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6856 in k6853 in k6850 in k6847 in k6844 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6858,2,av);}
/* expand.scm:673: outstr */
t2=((C_word*)t0)[2];
f_6820(t2,((C_word*)t0)[3],lf[126]);}

/* loop in expand-curried-define in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6688(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_6688,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_car(t5));
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t8,t3);
t10=t1;{
C_word av2[2];
av2[0]=t10;
av2[1]=C_a_i_cons(&a,2,lf[72],t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t8,t3);
t10=C_a_i_cons(&a,2,lf[72],t9);
t11=C_a_i_list(&a,1,t10);
/* expand.scm:636: loop */
t13=t1;
t14=t6;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* ##sys#expand-curried-define in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_6685,5,av);}
a=C_alloc(13);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6688,a[2]=t6,a[3]=t8,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6732,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:637: loop */
t11=((C_word*)t8)[1];
f_6688(t11,t10,t2,t3);}

/* k6681 in match-expression in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6683,2,av);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a4504 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4505,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[45]+1));
t3=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6844 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6846,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:669: outstr */
t3=((C_word*)t0)[2];
f_6820(t3,t2,lf[128]);}

/* k6847 in k6844 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6849,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:670: ##sys#print */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6832 in k6825 in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6834,2,av);}
/* expand.scm:700: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6836(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_6836,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6846,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:668: outstr */
t4=((C_word*)t0)[2];
f_6820(t4,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6872,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(t2);
/* expand.scm:675: ##sys#strip-syntax */
t5=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k11677 in k11664 in k11653 in k11650 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_11679,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
/* expand.scm:1035: ##sys#defjam-error */
t2=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_i_car(((C_word*)t0)[4]);
t3=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[336],((C_word*)t0)[6],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* expand in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,6)))){
C_save_and_reclaim_args((void *)trf_4531,5,t0,t1,t2,t3,t4);}
a=C_alloc(3);
if(C_truep(C_i_listp(t3))){
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4557,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cadr(t4);
t7=t4;
t8=C_u_i_car(t7);
/* expand.scm:263: call-handler */
t9=((C_word*)((C_word*)t0)[2])[1];
f_4333(t9,t5,t2,t6,t3,t8,C_SCHEME_FALSE);}
else{
/* expand.scm:265: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}
else{
/* expand.scm:259: ##sys#syntax-error-hook */
t5=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[49];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_10837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,3)))){
C_save_and_reclaim((void *)f_10837,2,av);}
a=C_alloc(29);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1242: expand */
t3=((C_word*)((C_word*)t0)[7])[1];
f_10804(t3,t2,((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10925,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=((C_word)li157),tmp=(C_word)a,a+=5,tmp);
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10940,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10942,a[2]=t6,a[3]=t4,a[4]=t11,a[5]=t5,a[6]=((C_word)li158),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_10942(t13,t9,t7);}}

/* k4527 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4529,2,av);}
a=C_alloc(3);
/* tmp23085 */
t2=((C_word*)t0)[2];
f_4512(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k10829 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_10831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10831,2,av);}
/* expand.scm:1236: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[188]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[188]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[300];
av2[3]=t1;
tp(4,av2);}}

/* k10825 in k10822 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_10827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10827,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[299];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10822 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_10824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_10824,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1239: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10804(t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE);}

/* k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_10818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_10818,2,av);}
a=C_alloc(11);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10831,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1238: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10837,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* expand.scm:1241: c */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[12];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}}

/* k7182 in walk in k7158 in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_7184,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li90),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_7189(t6,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(0));}

/* doloop1398 in k7182 in walk in k7158 in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7189,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
/* expand.scm:765: err */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7044(t5,t1,lf[151]);}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7208,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
/* expand.scm:767: err */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7044(t6,t5,lf[152]);}
else{
if(C_truep(C_i_pairp(t2))){
t6=C_i_car(t2);
/* expand.scm:770: walk */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7165(t7,t5,t6,((C_word*)t0)[7]);}
else{
/* expand.scm:769: err */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7044(t6,t5,lf[153]);}}}}

/* k6929 in k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6931,2,av);}
/* expand.scm:691: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[131];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* loop in k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6933,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[132];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6947,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* expand.scm:697: symbol->string */
t5=*((C_word*)lf[44]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,3)))){
C_save_and_reclaim_args((void *)trf_4575,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=t2;
t6=C_u_i_cdr(t5);
if(C_truep(C_i_symbolp(t4))){
t7=(
  /* expand.scm:271: lookup */
  f_3670(t4,((C_word*)t0)[2])
);
t8=(C_truep(t7)?t7:t4);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4599,a[2]=t10,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_pairp(((C_word*)t10)[1]))){
t12=t11;
f_4599(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4817,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:273: ##sys#macro-environment */
t13=*((C_word*)lf[19]+1);{
C_word av2[2];
av2[0]=t13;
av2[1]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}
else{
/* expand.scm:299: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}
else{
/* expand.scm:300: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* k3869 in doloop331 in k3839 in walk in strip-syntax in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3871,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3850(t4,((C_word*)t0)[5],t3);}

/* k10800 in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_10802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10802,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[55],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_fcall f_10804(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,4)))){
C_save_and_reclaim_args((void *)trf_10804,4,t0,t1,t2,t3);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10818,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* expand.scm:1234: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[298];
av2[3]=t5;
av2[4]=lf[301];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[302];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4772 in k4760 in g695 in k4752 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4774,2,av);}
/* expand.scm:297: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4575(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* ##sys#extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +19,c,3)))){
C_save_and_reclaim((void*)f_3882,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+19);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3886,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=*((C_word*)lf[8]+1);
t11=t3;
t12=C_i_check_list_2(t11,lf[16]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4025,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=t9,a[6]=((C_word)li7),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_4025(t16,t5,t11);}
else{
t6=t5;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_i_car(t4);
f_3886(2,av2);}}}

/* walk in k7158 in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7165(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_7165,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_vectorp(t3))){
t4=C_i_vector_ref(t3,C_fix(0));
t5=t4;
t6=C_block_size(t3);
t7=C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7184,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=C_eqp(t6,C_fix(1));
if(C_truep(t11)){
t12=t10;
f_7184(t12,C_fix(1));}
else{
t12=C_fixnum_greaterp(t6,C_fix(2));
t13=t10;
f_7184(t13,(C_truep(t12)?C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep(C_immp(t3))){
t4=C_eqp(t3,t2);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* expand.scm:772: err */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7044(t5,t1,lf[154]);}}
else{
if(C_truep(C_i_symbolp(t3))){
t4=t3;
t5=C_eqp(t4,lf[155]);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(t4,lf[156]);
if(C_truep(t6)){
/* expand.scm:776: test */
t7=((C_word*)((C_word*)t0)[4])[1];
f_7032(t7,t1,t2,*((C_word*)lf[157]+1),lf[158]);}
else{
t7=C_eqp(t4,lf[159]);
if(C_truep(t7)){
/* expand.scm:777: test */
t8=((C_word*)((C_word*)t0)[4])[1];
f_7032(t8,t1,t2,*((C_word*)lf[160]+1),lf[161]);}
else{
t8=C_eqp(t4,lf[162]);
if(C_truep(t8)){
/* expand.scm:778: test */
t9=((C_word*)((C_word*)t0)[4])[1];
f_7032(t9,t1,t2,*((C_word*)lf[160]+1),lf[163]);}
else{
t9=C_eqp(t4,lf[164]);
if(C_truep(t9)){
/* expand.scm:779: test */
t10=((C_word*)((C_word*)t0)[4])[1];
f_7032(t10,t1,t2,((C_word*)((C_word*)t0)[5])[1],lf[165]);}
else{
t10=C_eqp(t4,lf[166]);
if(C_truep(t10)){
/* expand.scm:780: test */
t11=((C_word*)((C_word*)t0)[4])[1];
f_7032(t11,t1,t2,*((C_word*)lf[167]+1),lf[168]);}
else{
t11=C_eqp(t4,lf[169]);
if(C_truep(t11)){
/* expand.scm:781: test */
t12=((C_word*)((C_word*)t0)[4])[1];
f_7032(t12,t1,t2,*((C_word*)lf[170]+1),lf[171]);}
else{
t12=C_eqp(t4,lf[172]);
if(C_truep(t12)){
/* expand.scm:782: test */
t13=((C_word*)((C_word*)t0)[4])[1];
f_7032(t13,t1,t2,((C_word*)((C_word*)t0)[6])[1],lf[173]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7362,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:784: test */
t14=((C_word*)((C_word*)t0)[4])[1];
f_7032(t14,t1,t2,t13,lf[174]);}}}}}}}}}
else{
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7419,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* expand.scm:794: walk */
t15=t4;
t16=t5;
t17=t6;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
/* expand.scm:792: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7044(t4,t1,lf[175]);}}
else{
/* expand.scm:791: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7044(t4,t1,lf[176]);}}}}}

/* k7158 in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_7160,2,t0,t1);}
a=C_alloc(11);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7165,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li92),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7165(t5,((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9]);}

/* k3884 in extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_3886,2,av);}
a=C_alloc(12);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_check_list_2(t2,lf[14]);
t5=C_i_check_list_2(t3,lf[14]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3976,a[2]=t8,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3976(t10,t6,t2,t3);}

/* k6949 in k6945 in loop in k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6951,2,av);}
/* expand.scm:696: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[133];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[134];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* for-each-loop380 in k3884 in extend-se in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_3976(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_3976,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_i_getprop(t7,lf[7],C_SCHEME_FALSE);
t9=(C_truep(t8)?C_a_i_putprop(&a,3,t6,lf[7],t8):C_a_i_putprop(&a,3,t6,lf[7],t7));
t10=C_slot(t2,C_fix(1));
t11=C_slot(t3,C_fix(1));
t13=t1;
t14=t10;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* a4517 in tmp23085 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4518,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k11684 in k11664 in k11653 in k11650 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11686,2,av);}
/* expand.scm:1034: c */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t2))(4,av2);}}

/* k11697 in k11694 in k11691 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,1)))){
C_save_and_reclaim((void *)f_11699,2,av);}
a=C_alloc(21);
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,lf[72],t4);
t6=C_a_i_list(&a,2,lf[23],t5);
t7=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[336],t2,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k6945 in loop in k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6947,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6951,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:698: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6933(t6,t3,t5);}

/* tmp23085 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4512(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_4512,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4518,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:207: k562 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k11694 in k11691 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11696,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=C_u_i_car(t3);
t5=C_i_car(((C_word*)t0)[2]);
t6=C_eqp(t4,t5);
if(C_truep(t6)){
/* expand.scm:1041: ##sys#syntax-error-hook */
t7=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[337];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_11699(2,av2);}}}

/* k11691 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_11693,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1039: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[102];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[338];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11688 in k11653 in k11650 in a11636 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11690,2,av);}
/* expand.scm:1033: ##sys#register-export */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[340]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[340]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* g507 in k4192 in k4189 in extend-macro-environment in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_4201(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
t2=C_i_set_car(t1,((C_word*)t0)[2]);
t3=t1;
t4=C_u_i_cdr(t3);
t5=C_i_set_car(t4,((C_word*)t0)[3]);
return(t1);}

/* k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_5733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,6)))){
C_save_and_reclaim((void *)f_5733,2,av);}
a=C_alloc(30);
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5744,a[2]=t2,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t19=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5810,a[2]=t17,a[3]=t11,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t20=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6098,a[2]=t13,a[3]=t11,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t21=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6288,a[2]=t11,a[3]=t2,a[4]=t15,a[5]=t13,a[6]=t7,a[7]=((C_word)li68),tmp=(C_word)a,a+=8,tmp));
/* expand.scm:605: expand */
t22=((C_word*)t17)[1];
f_6288(t22,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k6910 in k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6912,2,av);}
/* expand.scm:685: outstr */
t2=((C_word*)t0)[2];
f_6820(t2,((C_word*)t0)[3],t1);}

/* k11736 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11738,2,av);}
/* expand.scm:996: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[101];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6914 in k6897 in k6894 in k6891 in k6888 in k6885 in k6882 in k6873 in k6870 in loop in k6816 in syntax-error/context in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6916,2,av);}
/* expand.scm:686: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[129];
av2[3]=t1;
av2[4]=lf[130];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3814 in k3821 in walk in strip-syntax in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_3816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3816,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4217 in k4192 in k4189 in extend-macro-environment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4219,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11762 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_11764,2,av);}
a=C_alloc(12);
t2=C_i_getprop(((C_word*)t0)[2],lf[5],C_SCHEME_FALSE);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11803,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1008: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[242]+1));
C_word *av2=av; /* Re-use our own argvector */
av2[0]=*((C_word*)lf[242]+1);
av2[1]=t6;
tp(2,av2);}}

/* k6479 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_6481,2,av);}
a=C_alloc(9);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,C_SCHEME_TRUE,((C_word*)t0)[5]);
/* expand.scm:594: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_6294(t7,((C_word*)t0)[7],((C_word*)t0)[8],t3,t5,t6);}

/* k4244 in macro? in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4246,2,av);}
a=C_alloc(4);
t2=(
  /* expand.scm:184: lookup */
  f_3670(((C_word*)t0)[2],t1)
);
t3=C_i_pairp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:186: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k4238 in copy-macro in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4240,2,av);}
t2=(
  /* expand.scm:180: lookup */
  f_3670(((C_word*)t0)[2],t1)
);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=*((C_word*)lf[27]+1);
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
C_apply(5,av2);}}

/* ##sys#macro? in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,2)))){
C_save_and_reclaim((void*)f_4242,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4246,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* expand.scm:183: ##sys#current-environment */
t5=*((C_word*)lf[1]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t4;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_i_car(t3);
f_4246(2,av2);}}}

/* ##sys#unregister-macro in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4279,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4287,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4291,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:192: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6467 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6469,2,av);}
/* expand.scm:590: fini/syntax */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6098(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* ##sys#copy-macro in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4229,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4240,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:180: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* er-macro-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8040,3,av);}
/* expand.scm:924: make-er/ir-transformer */
t3=*((C_word*)lf[177]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* map-loop635 in k4618 in k4606 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_4716,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4708 in k4618 in k4606 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(41,c,3)))){
C_save_and_reclaim((void *)f_4710,2,av);}
a=C_alloc(41);
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,lf[51],t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_list(&a,3,lf[52],t6,((C_word*)t0)[3]);
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4647,a[2]=t11,a[3]=t15,a[4]=t12,a[5]=((C_word)li35),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_4647(t17,t13,((C_word*)t0)[5]);}

/* assq-reverse in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_7878(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_i_cdar(t2);
t4=C_eqp(t3,t1);
if(C_truep(t4)){
t5=t2;
return(C_u_i_car(t5));}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* comp in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_5744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;{}
t3=(
  /* expand.scm:474: lookup */
  f_3670(t2,((C_word*)t0)[2])
);
t4=C_eqp(t1,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=t1;
t6=C_eqp(t5,lf[101]);
if(C_truep(t6)){
return((C_truep(t3)?C_eqp(t3,*((C_word*)lf[97]+1)):C_eqp(t1,t2)));}
else{
t7=C_eqp(t5,lf[102]);
if(C_truep(t7)){
return((C_truep(t3)?C_eqp(t3,*((C_word*)lf[98]+1)):C_eqp(t1,t2)));}
else{
t8=C_eqp(t5,lf[103]);
return((C_truep(t8)?(C_truep(t3)?C_eqp(t3,*((C_word*)lf[99]+1)):C_eqp(t1,t2)):C_eqp(t1,t2)));}}}}

/* ir-macro-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8046,3,av);}
/* expand.scm:925: make-er/ir-transformer */
t3=*((C_word*)lf[177]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7499 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7501,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7505,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:808: rename */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
f_7487(3,av2);}}

/* k7503 in k7499 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7505,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10844 in k10838 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_10846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_10846,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,t2,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[104],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10838 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_10840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_10840,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(3));
if(C_truep(t4)){
t5=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1244: c */
t6=((C_word*)t0)[5];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}
else{
t5=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_10846(2,av2);}}}

/* k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8055,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11952,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11954,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:941: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8058,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11942,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11944,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:948: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k11595 in a11584 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_11597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,4)))){
C_save_and_reclaim_args((void *)trf_11597,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1067: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[333];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1070: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[335];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* map-loop2271 in expand in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_fcall f_10074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10074,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10070 in expand in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_10072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10072,2,av);}{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[25]+1);
av2[3]=lf[268];
av2[4]=t1;
C_apply(5,av2);}}

/* k8033 in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8035,2,av);}
/* expand.scm:922: handler */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[4])[1];
av2[4]=((C_word*)((C_word*)t0)[5])[1];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k8029 in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8031,2,av);}
/* expand.scm:922: mirror-rename */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7903(t2,((C_word*)t0)[3],t1);}

/* k11208 in k11181 in k11178 in k11138 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_11210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,1)))){
C_save_and_reclaim((void *)f_11210,2,av);}
a=C_alloc(30);
t2=C_a_i_list(&a,4,lf[310],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_a_i_list(&a,3,lf[72],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[93],((C_word*)t0)[6],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8061,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:953: ##sys#macro-environment */
t3=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6515 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6517,2,av);}
/* expand.scm:596: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6294(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* expand in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_fcall f_10047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,0,3)))){
C_save_and_reclaim_args((void *)trf_10047,3,t0,t1,t2);}
a=C_alloc(16);
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10072,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10074,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li141),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10074(t13,t9,((C_word*)t0)[2]);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
if(C_truep(C_i_pairp(t5))){
t8=C_i_car(t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10137,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t9,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1415: c */
t11=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
av2[3]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t11))(4,av2);}}
else{
/* expand.scm:1413: err */
t8=((C_word*)((C_word*)t0)[7])[1];
f_9901(t8,t1,t5);}}
else{
/* expand.scm:1408: err */
t4=((C_word*)((C_word*)t0)[7])[1];
f_9901(t4,t1,t2);}}}

/* k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_11744,2,av);}
a=C_alloc(9);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11749,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li172),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_11749(t5,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_11749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_11749,3,t0,t1,t2);}
a=C_alloc(8);
t3=C_i_cadr(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
if(C_truep(C_i_pairp(t4))){
t8=C_i_car(t4);
if(C_truep(C_i_pairp(t8))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11812,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1015: ##sys#check-syntax */
t10=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[101];
av2[3]=t2;
av2[4]=lf[342];
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11822,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1018: ##sys#check-syntax */
t10=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[101];
av2[3]=t2;
av2[4]=lf[343];
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11764,a[2]=t4,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1006: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[101];
av2[3]=t2;
av2[4]=lf[345];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* g1569 in k7841 in k7758 in k7750 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_7828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_eqp(((C_word*)t0)[2],t2));}

/* a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_11740,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11744,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1001: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[101];
av2[3]=t2;
av2[4]=lf[346];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* loop in check-for-multiple-bindings in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_8096(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_8096,5,t0,t1,t2,t3,t4);}
a=C_alloc(9);
t5=C_i_nullp(t2);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8109,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=C_i_caar(t2);
if(C_truep(C_i_memq(t7,t3))){
t8=t2;
t9=C_u_i_car(t8);
t10=C_u_i_car(t9);
t11=C_i_memq(t10,t4);
t12=t6;
f_8109(t12,C_i_not(t11));}
else{
t8=t6;
f_8109(t8,C_SCHEME_FALSE);}}}

/* k7572 in g1452 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7574,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:824: macro-alias */
f_3687(t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8071,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8074,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11891,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11893,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:974: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7575 in k7572 in g1452 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_7577,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_expand_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,3));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void*)C_expand_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(3232))){
C_save(t1);
C_rereclaim2(3232*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,358);
lf[0]=C_h_intern(&lf[0],12,"\003sysfeatures");
lf[1]=C_h_intern(&lf[1],23,"\003syscurrent-environment");
lf[2]=C_h_intern(&lf[2],28,"\003syscurrent-meta-environment");
lf[3]=C_h_intern(&lf[3],27,"\003sysactive-eval-environment");
lf[5]=C_h_intern(&lf[5],16,"\004coremacro-alias");
lf[7]=C_h_intern(&lf[7],14,"\004corereal-name");
lf[8]=C_h_intern(&lf[8],6,"gensym");
lf[9]=C_h_intern(&lf[9],21,"\003sysqualified-symbol\077");
lf[10]=C_h_intern(&lf[10],12,"strip-syntax");
lf[11]=C_h_intern(&lf[11],11,"make-vector");
lf[12]=C_h_intern(&lf[12],16,"\003sysstrip-syntax");
lf[13]=C_h_intern(&lf[13],13,"\003sysextend-se");
lf[14]=C_h_intern(&lf[14],8,"for-each");
lf[15]=C_h_intern(&lf[15],6,"append");
lf[16]=C_h_intern(&lf[16],3,"map");
lf[17]=C_h_intern(&lf[17],13,"\003sysglobalize");
lf[18]=C_h_intern(&lf[18],21,"\003sysalias-global-hook");
lf[19]=C_h_intern(&lf[19],21,"\003sysmacro-environment");
lf[20]=C_h_intern(&lf[20],29,"\003syschicken-macro-environment");
lf[21]=C_h_intern(&lf[21],33,"\003syschicken-ffi-macro-environment");
lf[22]=C_h_intern(&lf[22],22,"\003sysensure-transformer");
lf[23]=C_h_intern(&lf[23],18,"\003syser-transformer");
lf[24]=C_h_intern(&lf[24],11,"transformer");
lf[25]=C_h_intern(&lf[25],9,"\003syserror");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000$expected syntax-transformer, but got");
lf[27]=C_h_intern(&lf[27],28,"\003sysextend-macro-environment");
lf[28]=C_h_intern(&lf[28],14,"\003syscopy-macro");
lf[29]=C_h_intern(&lf[29],10,"\003sysmacro\077");
lf[30]=C_h_intern(&lf[30],20,"\003sysunregister-macro");
lf[31]=C_h_intern(&lf[31],19,"\003sysundefine-macro!");
lf[32]=C_h_intern(&lf[32],12,"\003sysexpand-0");
lf[33]=C_h_intern(&lf[33],9,"condition");
lf[34]=C_h_intern(&lf[34],9,"\003sysabort");
lf[35]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[36]=C_h_intern(&lf[36],13,"string-append");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[39]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[40]=C_h_intern(&lf[40],3,"exn");
lf[41]=C_h_intern(&lf[41],21,"\003syssyntax-error-hook");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\030syntax transformer for `");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000@\047 returns original form, which would result in endless expansion");
lf[44]=C_h_intern(&lf[44],14,"symbol->string");
lf[45]=C_h_intern(&lf[45],25,"\003syssyntax-rules-mismatch");
lf[46]=C_h_intern(&lf[46],16,"\003sysdynamic-wind");
lf[47]=C_h_intern(&lf[47],22,"with-exception-handler");
lf[48]=C_h_intern(&lf[48],30,"call-with-current-continuation");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[50]=C_h_intern(&lf[50],8,"\004corelet");
lf[51]=C_h_intern(&lf[51],16,"\004coreloop-lambda");
lf[52]=C_h_intern(&lf[52],12,"\004coreletrec\052");
lf[53]=C_h_intern(&lf[53],8,"\004coreapp");
lf[54]=C_h_intern(&lf[54],16,"\003syscheck-syntax");
lf[55]=C_h_intern(&lf[55],3,"let");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[57]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[58]=C_h_intern(&lf[58],24,"\003syscompiler-syntax-hook");
lf[59]=C_h_intern(&lf[59],24,"\010compilercompiler-syntax");
lf[60]=C_h_intern(&lf[60],25,"\003sysenable-runtime-macros");
lf[61]=C_h_intern(&lf[61],6,"expand");
lf[62]=C_h_intern(&lf[62],10,"\003sysexpand");
lf[63]=C_h_intern(&lf[63],25,"\003sysextended-lambda-list\077");
lf[64]=C_h_intern(&lf[64],6,"#!rest");
lf[65]=C_h_intern(&lf[65],10,"#!optional");
lf[66]=C_h_intern(&lf[66],5,"#!key");
lf[67]=C_h_intern(&lf[67],31,"\003sysexpand-extended-lambda-list");
lf[68]=C_h_intern(&lf[68],5,"cadar");
lf[69]=C_h_intern(&lf[69],7,"reverse");
lf[70]=C_h_intern(&lf[70],10,"\003sysappend");
lf[71]=C_h_intern(&lf[71],10,"\004corequote");
lf[72]=C_h_intern(&lf[72],11,"\004corelambda");
lf[73]=C_h_intern(&lf[73],15,"\003sysget-keyword");
lf[74]=C_h_intern(&lf[74],15,"string->keyword");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[77]=C_h_intern(&lf[77],3,"tmp");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[86]=C_h_intern(&lf[86],14,"let-optionals\052");
lf[87]=C_h_intern(&lf[87],8,"optional");
lf[88]=C_h_intern(&lf[88],4,"let\052");
lf[89]=C_h_intern(&lf[89],29,"\003sysdefault-macro-environment");
lf[90]=C_h_intern(&lf[90],16,"\003sysdefjam-error");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000,redefinition of currently used defining form");
lf[92]=C_h_intern(&lf[92],37,"\003sysexpand-multiple-values-assignment");
lf[93]=C_h_intern(&lf[93],20,"\003syscall-with-values");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[95]=C_h_intern(&lf[95],9,"\004coreset!");
lf[96]=C_h_intern(&lf[96],25,"\003sysdecompose-lambda-list");
lf[97]=C_h_intern(&lf[97],21,"\003sysdefine-definition");
lf[98]=C_h_intern(&lf[98],28,"\003sysdefine-syntax-definition");
lf[99]=C_h_intern(&lf[99],28,"\003sysdefine-values-definition");
lf[100]=C_h_intern(&lf[100],21,"\003syscanonicalize-body");
lf[101]=C_h_intern(&lf[101],6,"define");
lf[102]=C_h_intern(&lf[102],13,"define-syntax");
lf[103]=C_h_intern(&lf[103],13,"define-values");
lf[104]=C_h_intern(&lf[104],10,"\004corebegin");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[106]=C_h_intern(&lf[106],18,"\004coreletrec-syntax");
lf[107]=C_h_intern(&lf[107],5,"caadr");
lf[108]=C_h_intern(&lf[108],25,"\003sysexpand-curried-define");
lf[109]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[110]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[117]=C_h_intern(&lf[117],24,"\003sysline-number-database");
lf[118]=C_h_intern(&lf[118],24,"\003syssyntax-error-culprit");
lf[119]=C_h_intern(&lf[119],18,"\003syssyntax-context");
lf[120]=C_h_intern(&lf[120],12,"syntax-error");
lf[121]=C_h_intern(&lf[121],15,"\003syssignal-hook");
lf[122]=C_h_intern(&lf[122],13,"\000syntax-error");
lf[123]=C_h_intern(&lf[123],24,"\003syssyntax-error/context");
lf[124]=C_h_intern(&lf[124],9,"\003sysprint");
lf[125]=C_h_intern(&lf[125],17,"get-output-string");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\006 ...)\047");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\025\012inside expression `(");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\027  Suggesting: `(import ");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\025  Suggesting one of:\012");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\017\012      (import ");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000# ...)\047 without importing it first.\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000-\012\012  Perhaps you intended to use the syntax `(");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[138]=C_h_intern(&lf[138],6,"syntax");
lf[139]=C_h_intern(&lf[139],7,"\003sysget");
lf[140]=C_h_intern(&lf[140],7,"\004coredb");
lf[141]=C_h_intern(&lf[141],18,"open-output-string");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[143]=C_h_intern(&lf[143],15,"get-line-number");
lf[144]=C_h_intern(&lf[144],18,"\003syshash-table-ref");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\006) in `");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\004\047 - ");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\004in `");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\004\047 - ");
lf[150]=C_h_intern(&lf[150],8,"keyword\077");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[155]=C_h_intern(&lf[155],1,"_");
lf[156]=C_h_intern(&lf[156],4,"pair");
lf[157]=C_h_intern(&lf[157],5,"pair\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[159]=C_h_intern(&lf[159],8,"variable");
lf[160]=C_h_intern(&lf[160],7,"symbol\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[162]=C_h_intern(&lf[162],6,"symbol");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[164]=C_h_intern(&lf[164],4,"list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[166]=C_h_intern(&lf[166],6,"number");
lf[167]=C_h_intern(&lf[167],7,"number\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[169]=C_h_intern(&lf[169],6,"string");
lf[170]=C_h_intern(&lf[170],7,"string\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[172]=C_h_intern(&lf[172],11,"lambda-list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[177]=C_h_intern(&lf[177],22,"make-er/ir-transformer");
lf[178]=C_h_intern(&lf[178],12,"list->vector");
lf[179]=C_h_intern(&lf[179],12,"vector->list");
lf[180]=C_h_intern(&lf[180],12,"\004corealiased");
lf[181]=C_h_intern(&lf[181],14,"\004coreprimitive");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\033(expand.scm:805) not a list");
lf[183]=C_h_intern(&lf[183],20,"er-macro-transformer");
lf[184]=C_h_intern(&lf[184],20,"ir-macro-transformer");
lf[185]=C_h_intern(&lf[185],18,"\003sysir-transformer");
lf[186]=C_h_intern(&lf[186],29,"\003sysinitial-macro-environment");
lf[188]=C_h_intern(&lf[188],8,"\003syswarn");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000!variable bound multiple times in ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\012 construct");
lf[191]=C_h_intern(&lf[191],24,"\003sysprocess-syntax-rules");
lf[192]=C_h_intern(&lf[192],7,"\003syscar");
lf[193]=C_h_intern(&lf[193],7,"\003syscdr");
lf[194]=C_h_intern(&lf[194],10,"\003syslength");
lf[195]=C_h_intern(&lf[195],11,"\003sysvector\077");
lf[196]=C_h_intern(&lf[196],16,"\003sysvector->list");
lf[197]=C_h_intern(&lf[197],16,"\003syslist->vector");
lf[198]=C_h_intern(&lf[198],6,"\003sys>=");
lf[199]=C_h_intern(&lf[199],5,"\003sys=");
lf[200]=C_h_intern(&lf[200],5,"\003sys+");
lf[201]=C_h_intern(&lf[201],8,"\003syscons");
lf[202]=C_h_intern(&lf[202],7,"\003syseq\077");
lf[203]=C_h_intern(&lf[203],10,"\003sysequal\077");
lf[204]=C_h_intern(&lf[204],9,"\003syslist\077");
lf[205]=C_h_intern(&lf[205],7,"\003sysmap");
lf[206]=C_h_intern(&lf[206],9,"\003sysmap-n");
lf[207]=C_h_intern(&lf[207],9,"\003syspair\077");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[209]=C_h_intern(&lf[209],11,"\004coresyntax");
lf[210]=C_h_intern(&lf[210],5,"quote");
lf[211]=C_h_intern(&lf[211],14,"\003sysdrop-right");
lf[212]=C_h_intern(&lf[212],14,"\003systake-right");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[215]=C_h_intern(&lf[215],9,"\003sysapply");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000%Only one segment per level is allowed");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\047Cannot combine dotted tail and ellipsis");
lf[218]=C_h_intern(&lf[218],4,"temp");
lf[219]=C_h_intern(&lf[219],4,"tail");
lf[220]=C_h_intern(&lf[220],6,"rename");
lf[221]=C_h_intern(&lf[221],2,"or");
lf[222]=C_h_intern(&lf[222],4,"loop");
lf[223]=C_h_intern(&lf[223],6,"lambda");
lf[224]=C_h_intern(&lf[224],3,"len");
lf[225]=C_h_intern(&lf[225],1,"l");
lf[226]=C_h_intern(&lf[226],5,"input");
lf[227]=C_h_intern(&lf[227],4,"else");
lf[228]=C_h_intern(&lf[228],4,"cond");
lf[229]=C_h_intern(&lf[229],7,"compare");
lf[230]=C_h_intern(&lf[230],3,"and");
lf[231]=C_h_intern(&lf[231],16,"\003sysmacro-subset");
lf[232]=C_h_intern(&lf[232],27,"\003sysfixup-macro-environment");
lf[233]=C_h_intern(&lf[233],26,"\003sysmeta-macro-environment");
lf[234]=C_h_intern(&lf[234],14,"make-parameter");
lf[235]=C_h_intern(&lf[235],12,"syntax-rules");
lf[236]=C_h_intern(&lf[236],3,"...");
lf[237]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[238]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[239]=C_h_intern(&lf[239],6,"export");
lf[240]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[241]=C_h_intern(&lf[241],22,"\003sysadd-to-export-list");
lf[242]=C_h_intern(&lf[242],18,"\003syscurrent-module");
lf[243]=C_h_intern(&lf[243],20,"\003sysvalidate-exports");
lf[244]=C_h_intern(&lf[244],16,"begin-for-syntax");
lf[245]=C_h_intern(&lf[245],24,"\004coreelaborationtimeonly");
lf[246]=C_h_intern(&lf[246],28,"\003sysregister-meta-expression");
lf[247]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[248]=C_h_intern(&lf[248],6,"module");
lf[249]=C_h_intern(&lf[249],1,"\052");
lf[250]=C_h_intern(&lf[250],1,"=");
lf[251]=C_h_intern(&lf[251],14,"string->symbol");
lf[252]=C_h_intern(&lf[252],17,"\003sysstring-append");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[255]=C_h_intern(&lf[255],25,"\003sysregister-module-alias");
lf[256]=C_h_intern(&lf[256],23,"\003sysinstantiate-functor");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\016"
);
lf[258]=C_h_intern(&lf[258],12,"\004coreinclude");
lf[259]=C_h_intern(&lf[259],11,"\004coremodule");
lf[260]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[261]=C_h_intern(&lf[261],28,"require-extension-for-syntax");
lf[262]=C_h_intern(&lf[262],17,"require-extension");
lf[263]=C_h_intern(&lf[263],22,"\004corerequire-extension");
lf[264]=C_h_intern(&lf[264],15,"require-library");
lf[265]=C_h_intern(&lf[265],11,"cond-expand");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[267]=C_h_intern(&lf[267],12,"\003sysfeature\077");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[270]=C_h_intern(&lf[270],3,"not");
lf[271]=C_h_intern(&lf[271],11,"delay-force");
lf[272]=C_h_intern(&lf[272],16,"\003sysmake-promise");
lf[273]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[274]=C_h_intern(&lf[274],5,"delay");
lf[275]=C_h_intern(&lf[275],8,"\003syslist");
lf[276]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[277]=C_h_intern(&lf[277],10,"quasiquote");
lf[278]=C_h_intern(&lf[278],7,"unquote");
lf[279]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[280]=C_h_intern(&lf[280],16,"unquote-splicing");
lf[281]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[282]=C_h_intern(&lf[282],1,"a");
lf[283]=C_h_intern(&lf[283],1,"b");
lf[284]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[286]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[287]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[288]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[290]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[291]=C_h_intern(&lf[291],2,"do");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[293]=C_h_intern(&lf[293],7,"\004coreif");
lf[294]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[295]=C_h_intern(&lf[295],6,"doloop");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[298]=C_h_intern(&lf[298],4,"case");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000(clause following `else\047 clause in `case\047");
lf[301]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[302]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[303]=C_h_intern(&lf[303],4,"eqv\077");
lf[304]=C_h_intern(&lf[304],2,"=>");
lf[305]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[307]=C_h_intern(&lf[307],7,"sprintf");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\022\047 clause in `cond\047");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\022clause following `");
lf[310]=C_h_intern(&lf[310],2,"if");
lf[311]=C_h_intern(&lf[311],18,"\003syssrfi-4-vector\077");
lf[312]=C_h_intern(&lf[312],5,"blob\077");
lf[313]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[314]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[315]=C_h_intern(&lf[315],4,"set!");
lf[316]=C_h_intern(&lf[316],10,"\003syssetter");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[318]=C_h_intern(&lf[318],13,"letrec-syntax");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\015letrec-syntax");
lf[320]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[321]=C_h_intern(&lf[321],10,"let-syntax");
lf[322]=C_h_intern(&lf[322],15,"\004corelet-syntax");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\012let-syntax");
lf[324]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[325]=C_h_intern(&lf[325],6,"letrec");
lf[326]=C_h_intern(&lf[326],11,"\004coreletrec");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\006letrec");
lf[328]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[329]=C_h_intern(&lf[329],7,"letrec\052");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\007letrec\052");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\003let");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\003let");
lf[335]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[336]=C_h_intern(&lf[336],18,"\004coredefine-syntax");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000@redefinition of `define-syntax\047 not allowed in syntax-definition");
lf[338]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[339]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[340]=C_h_intern(&lf[340],19,"\003sysregister-export");
lf[341]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[343]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[344]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[345]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[347]=C_h_intern(&lf[347],5,"begin");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[352]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[353]=C_h_intern(&lf[353],8,"reexport");
lf[354]=C_h_intern(&lf[354],17,"\003sysexpand-import");
lf[355]=C_h_intern(&lf[355],17,"import-for-syntax");
lf[356]=C_h_intern(&lf[356],6,"import");
lf[357]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\007\000srf"
"i-2\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-46\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001"
"\000\000\010\000srfi-61\376\377\016");
C_register_lf2(lf,358,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3656,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:55: append */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[357];
av2[3]=*((C_word*)lf[0]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7813 in k7758 in k7750 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7815,2,av);}
a=C_alloc(4);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[3],a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:862: g1560 */
t4=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(
  /* expand.scm:862: g1560 */
  f_7800(t3,t2)
);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8065,2,av);}
a=C_alloc(9);
t2=C_mutate2((C_word*)lf[186]+1 /* (set! ##sys#initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8068,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11925,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11927,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:958: ##sys#er-transformer */
t6=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k11235 in k11178 in k11138 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_11237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,1)))){
C_save_and_reclaim((void *)f_11237,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[293],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8068,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8071,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11908,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11910,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:966: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10029 in k10022 in k9980 in k9942 in test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_10031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10031,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7520 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7522,2,av);}
/* expand.scm:810: list->vector */
t2=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6531 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_6533,2,av);}
a=C_alloc(3);
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
/* expand.scm:602: fini */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5810(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}
else{
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[9]);
/* expand.scm:603: loop */
t4=((C_word*)((C_word*)t0)[10])[1];
f_6294(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* k7524 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7526,2,av);}
/* expand.scm:810: rename */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7487(3,av2);}}

/* g1560 in k7813 in k7758 in k7750 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_7800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_eqp(t2,((C_word*)t0)[2]));}

/* k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8077,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11857,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11859,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:990: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8074,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11874,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11876,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:982: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10022 in k9980 in k9942 in test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_10024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10024,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* expand.scm:1401: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9911(t4,t2,t3);}
else{
/* expand.scm:1402: err */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9901(t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* g1452 in rename in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_7556,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=C_i_getprop(t3,lf[180],C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_7574(t6,t4);}
else{
t6=t2;
t7=t5;
f_7574(t7,C_i_getprop(t6,lf[181],C_SCHEME_FALSE));}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:832: macro-alias */
f_3687(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k10583 in k10562 in k10534 in k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_fcall f_10585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,0,3)))){
C_save_and_reclaim_args((void *)trf_10585,2,t0,t1);}
a=C_alloc(21);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10626,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10628,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li152),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_10628(t11,t7,((C_word*)t0)[7]);}

/* k10562 in k10534 in k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_10564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,2)))){
C_save_and_reclaim((void *)f_10564,2,av);}
a=C_alloc(17);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_eqp(t5,C_SCHEME_END_OF_LIST);
t7=(C_truep(t6)?lf[292]:C_a_i_cons(&a,2,lf[104],t5));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10585,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t10=C_eqp(((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
if(C_truep(t10)){
t11=t9;
f_10585(t11,lf[294]);}
else{
t11=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[6]);
t12=t9;
f_10585(t12,C_a_i_cons(&a,2,lf[50],t11));}}

/* k8524 */
static void C_ccall f_8526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(35,c,4)))){
C_save_and_reclaim((void *)f_8526,2,av);}
a=C_alloc(35);
if(C_truep(t1)){
/* synrules.scm:137: process-segment-match */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(4,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8562,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8566,a[2]=t7,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t9=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[12])[1],((C_word*)((C_word*)t0)[6])[1]);
t10=((C_word*)t0)[5];
t11=C_u_i_car(t10);
/* synrules.scm:141: process-match */
t12=((C_word*)((C_word*)t0)[11])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t8;
av2[2]=t9;
av2[3]=t11;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t12))(5,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[5]))){
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[13])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8619,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[14])[1],((C_word*)((C_word*)t0)[6])[1]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8627,a[2]=((C_word*)t0)[11],a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:147: vector->list */
t11=*((C_word*)lf[179]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t2=C_i_nullp(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8640,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8640(t4,t2);}
else{
t4=C_booleanp(((C_word*)t0)[5]);
t5=t3;
f_8640(t5,(C_truep(t4)?t4:C_charp(((C_word*)t0)[5])));}}}}}

/* k7758 in k7750 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7760,2,t0,t1);}
a=C_alloc(5);
t2=t1;
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
if(C_truep(C_i_symbolp(t2))){
t3=C_i_getprop(((C_word*)t0)[2],lf[181],C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=C_i_getprop(t2,lf[181],C_SCHEME_FALSE);
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?C_eqp(t4,t5):C_eqp(t4,t2));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7815,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:865: ##sys#macro-environment */
t4=*((C_word*)lf[19]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7843,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:869: ##sys#macro-environment */
t4=*((C_word*)lf[19]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_eqp(((C_word*)t0)[2],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}

/* k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_8240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8240,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[192]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[193]);
t5=C_mutate2(((C_word *)((C_word*)t0)[5])+1,lf[194]);
t6=C_mutate2(((C_word *)((C_word*)t0)[6])+1,lf[195]);
t7=C_mutate2(((C_word *)((C_word*)t0)[7])+1,lf[196]);
t8=C_mutate2(((C_word *)((C_word*)t0)[8])+1,lf[197]);
t9=C_mutate2(((C_word *)((C_word*)t0)[9])+1,lf[198]);
t10=C_mutate2(((C_word *)((C_word*)t0)[10])+1,lf[199]);
t11=C_mutate2(((C_word *)((C_word*)t0)[11])+1,lf[200]);
t12=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8255,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[19],a[10]=((C_word*)t0)[20],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[22],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[25],a[16]=((C_word*)t0)[26],a[17]=((C_word*)t0)[27],a[18]=((C_word*)t0)[28],a[19]=((C_word*)t0)[29],a[20]=((C_word*)t0)[30],a[21]=((C_word*)t0)[31],a[22]=((C_word*)t0)[32],a[23]=((C_word*)t0)[33],a[24]=((C_word*)t0)[34],a[25]=((C_word*)t0)[35],a[26]=((C_word*)t0)[36],a[27]=((C_word*)t0)[4],a[28]=((C_word*)t0)[37],a[29]=((C_word*)t0)[2],a[30]=((C_word*)t0)[38],a[31]=((C_word*)t0)[39],a[32]=((C_word*)t0)[40],a[33]=((C_word*)t0)[41],a[34]=((C_word*)t0)[42],a[35]=((C_word*)t0)[43],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[6],a[38]=((C_word*)t0)[7],a[39]=((C_word*)t0)[44],a[40]=((C_word*)t0)[5],a[41]=((C_word*)t0)[9],a[42]=((C_word*)t0)[10],a[43]=((C_word*)t0)[11],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[8],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:77: r */
t13=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=lf[229];
((C_proc)C_fast_retrieve_proc(t13))(3,av2);}}

/* k10890 in k10938 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_10892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_10892,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10885(t3,C_a_i_list(&a,2,t2,((C_word*)t0)[4]));}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10885(t3,C_a_i_cons(&a,2,lf[104],t2));}}

/* k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in ... */
static void C_ccall f_8255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8255,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:78: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[228];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in ... */
static void C_ccall f_8259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8259,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[201]);
t4=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8264,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],a[24]=((C_word*)t0)[26],a[25]=((C_word*)t0)[27],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[3],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:80: r */
t5=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[227];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k7750 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_7752,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_getprop(t3,lf[5],C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7760,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7760(t6,t4);}
else{
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[4];
t8=(
  /* expand.scm:877: lookup */
  f_3670(t6,t7)
);
if(C_truep(t8)){
t9=t5;
f_7760(t9,t8);}
else{
t9=((C_word*)t0)[2];
t10=t5;
f_7760(t10,t9);}}}

/* k11568 in k11565 in a11562 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11570,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[52],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10883 in k10938 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_fcall f_10885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_10885,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1255: expand */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10804(t4,t3,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k10887 in k10883 in k10938 in k10835 in k10816 in expand in k10789 in k10786 in k10783 in k10780 in k10777 in k10769 in a10766 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_10889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,1)))){
C_save_and_reclaim((void *)f_10889,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[293],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a11584 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_11585,5,av);}
a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11589,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11597,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(t2);
if(C_truep(C_i_pairp(t7))){
t8=C_i_cadr(t2);
t9=t6;
f_11597(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_11597(t8,C_SCHEME_FALSE);}}

/* k11581 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11583,2,av);}
/* expand.scm:1061: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[55];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11587 in a11584 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11589,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[50],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* f_8492 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_8492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_8492,5,av);}
a=C_alloc(24);
if(C_truep(C_i_symbolp(t3))){
if(C_truep(C_i_memq(t3,((C_word*)t0)[2]))){
t5=C_a_i_list(&a,2,lf[209],t3);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],t2,t6);
t8=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_a_i_list(&a,1,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t5=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* synrules.scm:136: segment-pattern? */
t6=((C_word*)((C_word*)t0)[17])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}}

/* k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_8231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,7)))){
C_save_and_reclaim((void *)f_8231,2,av);}
a=C_alloc(15);
t2=C_mutate2((C_word*)lf[191]+1 /* (set! ##sys#process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8233,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[231]+1 /* (set! ##sys#macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9407,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[232]+1 /* (set! ##sys#fixup-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9457,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9552,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1559: ##sys#macro-environment */
t7=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* ##sys#process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_8233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word *a;
if(c!=7) C_bad_argc_2(c,7,t0);
if(C_unlikely(!C_demand(C_calculate_demand(143,c,2)))){
C_save_and_reclaim((void *)f_8233,7,av);}
a=C_alloc(143);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8240,a[2]=t8,a[3]=t10,a[4]=t12,a[5]=t14,a[6]=t16,a[7]=t18,a[8]=t20,a[9]=t22,a[10]=t24,a[11]=t26,a[12]=t28,a[13]=t30,a[14]=t32,a[15]=t34,a[16]=t36,a[17]=t38,a[18]=t40,a[19]=t42,a[20]=t44,a[21]=t46,a[22]=t48,a[23]=t50,a[24]=t52,a[25]=t54,a[26]=t56,a[27]=t58,a[28]=t60,a[29]=t62,a[30]=t64,a[31]=t66,a[32]=t68,a[33]=t70,a[34]=t72,a[35]=t6,a[36]=t74,a[37]=t76,a[38]=t84,a[39]=t86,a[40]=t82,a[41]=t78,a[42]=t4,a[43]=t80,a[44]=t90,a[45]=t96,a[46]=t88,a[47]=t94,a[48]=t92,a[49]=t1,a[50]=t3,a[51]=t5,a[52]=t2,tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:65: r */
t98=t5;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t98;
av2[1]=t97;
av2[2]=lf[230];
((C_proc)C_fast_retrieve_proc(t98))(3,av2);}}

/* k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in ... */
static void C_ccall f_8207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8207,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9881,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9883,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1372: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in ... */
static void C_ccall f_10524(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_10524,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10536,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1279: r */
t11=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[295];
((C_proc)C_fast_retrieve_proc(t11))(3,av2);}}

/* k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_8204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8204,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10173,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10175,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1364: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in ... */
static void C_ccall f_10520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_10520,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10524,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1275: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[291];
av2[3]=t2;
av2[4]=lf[296];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9730 in k9665 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9732,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
/* expand.scm:1486: ##sys#instantiate-functor */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[256]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[256]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
av2[4]=t3;
tp(5,av2);}}

/* k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in ... */
static void C_ccall f_8201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8201,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10194,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10196,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1354: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7719 in doloop1505 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7721,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_7700(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_8219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8219,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9649,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9651,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1449: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_8216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8216,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9829,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9831,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1442: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_8213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8213,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9857,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1434: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_8210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8210,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9868,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9870,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1426: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10516 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in ... */
static void C_ccall f_10518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10518,2,av);}
/* expand.scm:1270: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[291];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8407 in map-loop2464 */
static void C_ccall f_8409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8409,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8384(t6,((C_word*)t0)[5],t5);}

/* k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in k8220 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in ... */
static void C_ccall f_8264(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,c,2)))){
C_save_and_reclaim((void *)f_8264,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[202]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[203]);
t5=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8270,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[2],a[26]=((C_word*)t0)[28],a[27]=((C_word*)t0)[29],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[34],a[33]=((C_word*)t0)[35],a[34]=((C_word*)t0)[36],a[35]=((C_word*)t0)[37],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[4],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:83: r */
t6=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[226];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k9727 in k9665 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9729,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[254];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10505 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_10507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10507,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1349: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10241(t3,((C_word*)t0)[4],t2,C_fix(0));}

/* k9720 in k9665 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9722,2,av);}
/* expand.scm:1472: string->symbol */
t2=*((C_word*)lf[251]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9724 in k9665 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9726,2,av);}
/* expand.scm:1473: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[252]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[252]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[253];
av2[3]=t1;
tp(4,av2);}}

/* k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8080,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11738,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11740,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:999: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9771 in k9742 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_fcall f_9773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,1)))){
C_save_and_reclaim_args((void *)trf_9773,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[258],t2);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_cons(&a,2,lf[259],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[259],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8730 in k8754 in k8675 */
static void C_ccall f_8732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(60,c,1)))){
C_save_and_reclaim((void *)f_8732,2,av);}
a=C_alloc(60);
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=C_a_i_list(&a,4,((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[8],t4);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[9],t5);
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[10],t6);
t8=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[11],t7);
t9=((C_word*)t0)[12];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=C_a_i_list(&a,1,t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}

/* check-for-multiple-bindings in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_8090(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,5)))){
C_save_and_reclaim_args((void *)trf_8090,4,t1,t2,t3,t4);}
a=C_alloc(8);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8096,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word)li106),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8096(t8,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k9742 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_9744,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_eqp(lf[249],t1);
t5=(C_truep(t4)?C_SCHEME_TRUE:t1);
t6=t5;
t7=C_i_cdddr(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9773,a[2]=t8,a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t8))){
t10=C_u_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
t11=C_u_i_car(t8);
t12=t9;
f_9773(t12,C_i_stringp(t11));}
else{
t11=t9;
f_9773(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_9773(t10,C_SCHEME_FALSE);}}

/* loop in fini in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_5822,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5841,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t5,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_u_i_car(t5);
if(C_truep(C_i_symbolp(t7))){
t8=(
  /* expand.scm:492: comp */
  f_5744(((C_word*)((C_word*)t0)[4])[1],lf[101],t7)
);
t9=t6;
f_5841(t9,(C_truep(t8)?t8:(
  /* expand.scm:493: comp */
  f_5744(((C_word*)((C_word*)t0)[4])[1],lf[103],t7)
)));}
else{
t8=t6;
f_5841(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_5841(t7,C_SCHEME_FALSE);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[104],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8084,2,av);}
a=C_alloc(9);
t2=C_mutate2((C_word*)lf[97]+1 /* (set! ##sys#define-definition ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11635,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11637,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1025: ##sys#er-transformer */
t6=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,5)))){
C_save_and_reclaim((void *)f_8088,2,av);}
a=C_alloc(12);
t2=C_mutate2((C_word*)lf[98]+1 /* (set! ##sys#define-syntax-definition ...) */,t1);
t3=C_mutate2(&lf[187] /* (set! check-for-multiple-bindings ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8090,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8165,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11583,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11585,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1064: ##sys#er-transformer */
t7=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* loop in loop1 in globalize in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4102,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
/* expand.scm:149: ##sys#alias-global-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[18]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[18]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
tp(5,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4118,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_car(t6);
t8=C_u_i_cdr(t7);
t9=t3;
f_4118(t9,C_i_symbolp(t8));}
else{
t6=t3;
f_4118(t6,C_SCHEME_FALSE);}}}

/* k8110 in k8107 in loop in check-for-multiple-bindings in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_8112,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_caar(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
/* expand.scm:1058: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8096(t6,((C_word*)t0)[5],t3,((C_word*)t0)[6],t5);}

/* k10534 in k10522 in a10519 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in ... */
static void C_ccall f_10536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_10536,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10564,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10678,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li153),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_10678(t12,t8,((C_word*)t0)[2]);}

/* k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8177,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11451,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11453,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1113: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8171,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11519,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1095: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_8174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8174,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11495,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11497,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1104: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9845 in k9837 in a9830 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_9847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9847,2,av);}
a=C_alloc(9);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4116 in loop in loop1 in globalize in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_4118,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_u_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* expand.scm:151: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4102(t4,((C_word*)t0)[3],t3);}}

/* k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_9890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_9890,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9893,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1376: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[270];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in ... */
static void C_ccall f_8189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8189,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8192,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10765,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10767,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1218: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_9893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_9893,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1377: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[227];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in ... */
static void C_ccall f_8186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8186,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8189,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10990,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10992,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1155: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in ... */
static void C_ccall f_8183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8183,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11362,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11364,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1139: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 in ... */
static void C_ccall f_8180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8180,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11414,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11416,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1125: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_9899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,3)))){
C_save_and_reclaim((void *)f_9899,2,av);}
a=C_alloc(28);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9901,a[2]=((C_word*)t0)[2],a[3]=((C_word)li139),tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9911,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li140),tmp=(C_word)a,a+=9,tmp));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10047,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word)li142),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_10047(t12,((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_9896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_9896,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1378: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[230];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8754 in k8675 */
static void C_ccall f_8756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(43,c,3)))){
C_save_and_reclaim((void *)f_8756,2,av);}
a=C_alloc(43);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[13])[1],((C_word*)((C_word*)t0)[14])[1]);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[15])[1],((C_word*)((C_word*)t0)[16])[1],C_fix(-1));
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[7])[1],t5,t6);
t8=C_a_i_list(&a,1,t7);
/* synrules.scm:61: ##sys#append */
t9=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t4;
av2[2]=((C_word*)t0)[17];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* k10379 in k10340 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_10381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_10381,2,av);}
a=C_alloc(13);
t2=C_a_i_list(&a,3,lf[201],((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10373,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1332: walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10241(t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k9879 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_9881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9881,2,av);}
/* expand.scm:1369: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[265];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in ... */
static void C_ccall f_9883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_9883,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9890,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1375: r */
t8=t3;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[221];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}

/* g1321 in k6996 in get-line-number in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_7002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_assq(((C_word*)t0)[2],t1);
return((C_truep(t2)?C_i_cdr(t2):C_SCHEME_FALSE));}

/* k10394 in k10340 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_10396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_10396,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10400,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1334: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10241(t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in ... */
static void C_ccall f_8198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8198,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8201,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10227,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10229,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1302: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in ... */
static void C_ccall f_8195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8195,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10518,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10520,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1273: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in ... */
static void C_ccall f_8192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_8192,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10716,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1260: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* f_8940 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_8940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_8940,5,av);}
a=C_alloc(15);
if(C_truep(C_i_symbolp(t2))){
t5=C_i_assq(t2,t4);
if(C_truep(t5)){
t6=C_i_cdr(t5);
t7=t3;
if(C_truep(C_fixnum_less_or_equal_p(t6,t7))){
t8=t2;
t9=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
/* synrules.scm:207: ##sys#syntax-error-hook */
t8=*((C_word*)lf[41]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=t1;
av2[2]=lf[213];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}
else{
t6=C_a_i_list(&a,2,lf[209],t2);
t7=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8979,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* synrules.scm:210: segment-template? */
t6=((C_word*)((C_word*)t0)[12])[1];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}}

/* k7046 in err in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7048,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7062,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:729: symbol->string */
t5=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7069,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:730: symbol->string */
t5=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* err in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7044,3,t0,t1,t2);}
a=C_alloc(6);
t3=*((C_word*)lf[118]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7048,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:726: get-line-number */
t5=*((C_word*)lf[143]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[118]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7037 in test in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7039,2,av);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* expand.scm:722: err */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7044(t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* test in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7032(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7032,5,t0,t1,t2,t3,t4);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7039,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:722: pred */
t6=t3;{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k8932 in k8828 */
static void C_ccall f_8934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_8934,2,av);}
a=C_alloc(6);
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);
/* synrules.scm:195: process-pattern */
t3=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[5];
av2[2]=t1;
av2[3]=t2;
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t3))(6,av2);}}

/* k4760 in g695 in k4752 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4762,2,av);}
a=C_alloc(5);
t2=t1;
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
/* expand.scm:293: expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4531(t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[58]+1))){
/* expand.scm:296: ##sys#compiler-syntax-hook */
t5=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
/* expand.scm:297: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_4575(t5,((C_word*)t0)[4],t2);}}}

/* k4752 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_4754,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp);
/* expand.scm:274: g695 */
t3=t2;
f_4758(t3,((C_word*)t0)[8],t1);}
else{
/* expand.scm:298: expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4531(t2,((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}}

/* g695 in k4752 in k4597 in loop in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4758(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,6)))){
C_save_and_reclaim_args((void *)trf_4758,3,t0,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
/* expand.scm:292: call-handler */
t7=((C_word*)((C_word*)t0)[7])[1];
f_4333(t7,t3,((C_word*)t0)[4],t4,((C_word*)t0)[2],t6,C_SCHEME_TRUE);}

/* k10330 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_10332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10332,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,lf[201],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5286 in k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,6)))){
C_save_and_reclaim_args((void *)trf_5288,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
/* expand.scm:401: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4972(t3,((C_word*)t0)[4],C_fix(1),((C_word*)t0)[5],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[6]);}
else{
/* expand.scm:402: err */
t3=((C_word*)t0)[7];
f_4944(t3,((C_word*)t0)[4],lf[76]);}}

/* k10360 in k10349 in k10340 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_10362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10362,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[70],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,6)))){
C_save_and_reclaim_args((void *)trf_5275,2,t0,t1);}
a=C_alloc(13);
t2=(C_truep(t1)?t1:((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_eqp(t2,lf[65]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5288,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t7=t6;
f_5288(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5304,a[2]=((C_word*)t0)[9],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:399: macro-alias */
f_3687(t7,lf[77],((C_word*)t0)[10]);}}
else{
t6=C_eqp(t2,lf[64]);
if(C_truep(t6)){
if(C_truep(C_fixnum_less_or_equal_p(((C_word*)t0)[4],C_fix(1)))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5322,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_pairp(t4))){
t8=C_u_i_car(t4);
t9=t7;
f_5322(t9,C_i_symbolp(t8));}
else{
t8=t7;
f_5322(t8,C_SCHEME_FALSE);}}
else{
/* expand.scm:411: err */
t7=((C_word*)t0)[8];
f_4944(t7,((C_word*)t0)[6],lf[79]);}}
else{
t7=C_eqp(t2,lf[66]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5364,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[12],a[7]=t4,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t9=((C_word*)((C_word*)t0)[9])[1];
if(C_truep(t9)){
t10=t8;
f_5364(t10,C_SCHEME_UNDEFINED);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5383,a[2]=((C_word*)t0)[9],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:413: macro-alias */
f_3687(t10,lf[77],((C_word*)t0)[10]);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
t8=((C_word*)t0)[4];
switch(t8){
case C_fix(0):
t9=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[7]);
/* expand.scm:420: loop */
t10=((C_word*)((C_word*)t0)[5])[1];
f_4972(t10,((C_word*)t0)[6],C_fix(0),t9,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t4);
case C_fix(1):
t9=C_a_i_list2(&a,2,((C_word*)t0)[2],C_SCHEME_FALSE);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[12]);
/* expand.scm:421: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_4972(t11,((C_word*)t0)[6],C_fix(1),((C_word*)t0)[7],t10,C_SCHEME_END_OF_LIST,t4);
case C_fix(2):
/* expand.scm:422: err */
t9=((C_word*)t0)[8];
f_4944(t9,((C_word*)t0)[6],lf[81]);
default:
t9=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[13]);
/* expand.scm:423: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_4972(t11,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[7],((C_word*)t0)[12],t10,t4);}}
else{
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5451,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t9=C_u_i_length(((C_word*)t0)[2]);
t10=C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=C_i_car(((C_word*)t0)[2]);
t12=t8;
f_5451(t12,C_i_symbolp(t11));}
else{
t11=t8;
f_5451(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_5451(t9,C_SCHEME_FALSE);}}}}}}

/* k8980 in k8977 */
static void C_ccall f_8982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,5)))){
C_save_and_reclaim((void *)f_8982,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_fixnum_plus(((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t6=C_i_car(((C_word*)t0)[4]);
/* synrules.scm:214: free-meta-variables */
t7=((C_word*)((C_word*)t0)[10])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=t4;
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_END_OF_LIST;
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}

/* k8986 in k8980 in k8977 */
static void C_ccall f_8988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_8988,2,av);}
a=C_alloc(12);
t2=t1;
if(C_truep(C_i_nullp(t2))){
/* synrules.scm:216: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[214];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* synrules.scm:217: process-template */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=((C_word*)t0)[11];
av2[4]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t6))(5,av2);}}}

/* g1230 in mwalk in match-expression in k4144 in k3666 in k3662 in k3658 in k3654 */
static C_word C_fcall f_6620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* k10309 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_10311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10311,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,lf[201],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9303 */
static void C_ccall f_9305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9305,2,av);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
/* synrules.scm:288: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[216];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* synrules.scm:290: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[217];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k8977 */
static void C_ccall f_8979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_8979,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* synrules.scm:211: segment-depth */
t3=((C_word*)((C_word*)t0)[11])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
/* synrules.scm:236: process-template */
t5=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=((C_word*)t0)[2];
av2[4]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t5))(5,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9127,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:240: vector->list */
t4=*((C_word*)lf[179]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[14])[1],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* k10340 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in ... */
static void C_ccall f_10342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_10342,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1326: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[280];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[281];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=C_a_i_list(&a,2,lf[71],((C_word*)t0)[7]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10381,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=C_i_cdr(((C_word*)t0)[3]);
t7=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* expand.scm:1331: walk */
t8=((C_word*)((C_word*)t0)[5])[1];
f_10241(t8,t5,t6,t7);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10396,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1334: walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10241(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k9686 in k9665 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_9688,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9691,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1476: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[248];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10371 in k10379 in k10340 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_10373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10373,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[201],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* mwalk in match-expression in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6606(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_6606,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6660,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=C_i_car(t3);
/* expand.scm:621: mwalk */
t9=t4;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6620,a[2]=t2,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:615: g1230 */
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=(
  /* expand.scm:615: g1230 */
  f_6620(t5,t4)
);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(C_i_memq(t3,((C_word*)t0)[4]))){
t5=C_a_i_cons(&a,2,t3,t2);
t6=C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_eqp(t2,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}}

/* match-expression in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6603(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,4)))){
C_save_and_reclaim_args((void *)trf_6603,4,t1,t2,t3,t4);}
a=C_alloc(14);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6606,a[2]=t8,a[3]=t6,a[4]=t4,a[5]=((C_word)li71),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6683,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:624: mwalk */
t11=((C_word*)t8)[1];
f_6606(t11,t10,t2,t3);}

/* k9689 in k9686 in k9665 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in ... */
static void C_ccall f_9691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,c,1)))){
C_save_and_reclaim((void *)f_9691,2,av);}
a=C_alloc(36);
t2=C_i_cddddr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[249],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t7=C_a_i_list(&a,4,t1,((C_word*)t0)[5],lf[250],t6);
t8=((C_word*)t0)[6];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[104],t5,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in ... */
static void C_ccall f_9664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_9664,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1454: ##sys#strip-syntax */
t3=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9744,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9807,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_caddr(((C_word*)t0)[5]);
/* expand.scm:1494: ##sys#strip-syntax */
t5=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4146(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(78,c,6)))){
C_save_and_reclaim((void *)f_4146,2,av);}
a=C_alloc(78);
t2=C_mutate2((C_word*)lf[19]+1 /* (set! ##sys#macro-environment ...) */,t1);
t3=C_set_block_item(lf[20] /* ##sys#chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[21] /* ##sys#chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate2((C_word*)lf[22]+1 /* (set! ##sys#ensure-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4150,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[27]+1 /* (set! ##sys#extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4187,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[28]+1 /* (set! ##sys#copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[29]+1 /* (set! ##sys#macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[30]+1 /* (set! ##sys#unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4279,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[31]+1 /* (set! ##sys#undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4324,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[32]+1 /* (set! ##sys#expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(lf[58] /* ##sys#compiler-syntax-hook */,0,C_SCHEME_FALSE);
t13=C_set_block_item(lf[60] /* ##sys#enable-runtime-macros */,0,C_SCHEME_FALSE);
t14=C_mutate2((C_word*)lf[61]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4827,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[62]+1 /* (set! ##sys#expand ...) */,*((C_word*)lf[61]+1));
t16=C_mutate2((C_word*)lf[63]+1 /* (set! ##sys#extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4894,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[67]+1 /* (set! ##sys#expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4941,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[90]+1 /* (set! ##sys#defjam-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5544,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[92]+1 /* (set! ##sys#expand-multiple-values-assignment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5550,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t20=C_set_block_item(lf[97] /* ##sys#define-definition */,0,C_SCHEME_UNDEFINED);
t21=C_set_block_item(lf[98] /* ##sys#define-syntax-definition */,0,C_SCHEME_UNDEFINED);
t22=C_set_block_item(lf[99] /* ##sys#define-values-definition */,0,C_SCHEME_UNDEFINED);
t23=C_mutate2((C_word*)lf[100]+1 /* (set! ##sys#canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5729,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2(&lf[116] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6603,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate2((C_word*)lf[108]+1 /* (set! ##sys#expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6685,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t26=C_set_block_item(lf[117] /* ##sys#line-number-database */,0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[118] /* ##sys#syntax-error-culprit */,0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[119] /* ##sys#syntax-context */,0,C_SCHEME_END_OF_LIST);
t29=C_mutate2((C_word*)lf[120]+1 /* (set! syntax-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6740,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate2((C_word*)lf[41]+1 /* (set! ##sys#syntax-error-hook ...) */,*((C_word*)lf[120]+1));
t31=C_mutate2((C_word*)lf[123]+1 /* (set! ##sys#syntax-error/context ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6751,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6972,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[143]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6978,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[54]+1 /* (set! ##sys#check-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7017,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[177]+1 /* (set! make-er/ir-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7472,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[183]+1 /* (set! er-macro-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8040,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[184]+1 /* (set! ir-macro-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8046,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[23]+1 /* (set! ##sys#er-transformer ...) */,*((C_word*)lf[183]+1));
t39=C_mutate2((C_word*)lf[185]+1 /* (set! ##sys#ir-transformer ...) */,*((C_word*)lf[184]+1));
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t41=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11962,a[2]=t40,tmp=(C_word)a,a+=3,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11964,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:935: ##sys#er-transformer */
t43=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t43;
av2[1]=t41;
av2[2]=t42;
((C_proc)(void*)(*((C_word*)t43+1)))(3,av2);}}

/* k9665 in k9662 in k9656 in a9650 in k8217 in k8214 in k8211 in k8208 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in ... */
static void C_ccall f_9667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_9667,2,av);}
a=C_alloc(13);
t2=t1;
t3=C_i_cadr(t2);
t4=t3;
t5=C_i_cadddr(t2);
t6=t5;
if(C_truep(C_i_symbolp(t6))){
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[2],C_fix(4)))){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9688,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9722,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9726,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1475: symbol->string */
t10=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9729,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1481: ##sys#register-module-alias */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[255]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[255]+1);
av2[1]=t7;
av2[2]=t4;
av2[3]=t6;
tp(4,av2);}}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9732,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1484: ##sys#check-syntax */
t8=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[248];
av2[3]=t2;
av2[4]=lf[257];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* k6658 in mwalk in match-expression in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6660,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:622: mwalk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6606(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10349 in k10340 in k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in ... */
static void C_ccall f_10351(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_10351,2,av);}
a=C_alloc(4);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10362,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1327: walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10241(t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k4479 in k4459 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4481,2,av);}
/* expand.scm:242: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[42];
av2[3]=t1;
av2[4]=lf[43];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4493 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4494,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[45]+1));
t3=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a4498 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4499,2,av);}
/* expand.scm:238: handler */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k4165 in ensure-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4167,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_slot(t1,C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7841 in k7758 in k7750 in compare in k7483 in a7477 in make-er/ir-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7843,2,av);}
a=C_alloc(4);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[3],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:869: g1569 */
t4=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=(
  /* expand.scm:869: g1569 */
  f_7828(t3,t2)
);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* f_4488 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4488,3,av);}
t3=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,3)))){
C_save_and_reclaim((void *)f_4986,2,av);}
a=C_alloc(28);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[7]))){
t4=t3;
f_4990(t4,((C_word*)t0)[9]);}
else{
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:370: reverse */
t10=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}}

/* k4459 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4461(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_4461,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=(C_truep(t4)?C_SCHEME_FALSE:C_eqp(((C_word*)t0)[4],t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4477,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4481,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:243: symbol->string */
t8=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t6=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* ##sys#ensure-transformer in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +3,c,4)))){
C_save_and_reclaim((void*)f_4150,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+3);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
if(C_truep(C_i_closurep(t2))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4167,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:161: ##sys#er-transformer */
t7=*((C_word*)lf[23]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
if(C_truep(C_i_structurep(t2,lf[24]))){
t6=t1;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* expand.scm:163: ##sys#error */
t6=*((C_word*)lf[25]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t5;
av2[3]=lf[26];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}}

/* k4475 in k4459 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4477,2,av);}
/* expand.scm:241: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f_9370 in k8322 in k8317 in k8313 in k8309 in k8305 in k8300 in k8293 in k8288 in k8284 in k8280 in k8276 in k8272 in k8268 in k8262 in k8257 in k8253 in k8238 in process-syntax-rules in k8229 in k8226 in k8223 in ... */
static void C_ccall f_9370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_9370,3,av);}
a=C_alloc(7);
t3=C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9380,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9380(t7,t1,t3);}

/* ##sys#extend-macro-environment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_4187,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4191,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:166: ##sys#macro-environment */
t6=*((C_word*)lf[19]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(15,0,6)))){
C_save_and_reclaim_args((void *)trf_4972,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(15);
if(C_truep(C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4986,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5234,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:358: reverse */
t9=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
/* expand.scm:358: reverse */
t8=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}
else{
if(C_truep(C_i_symbolp(t6))){
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm:386: err */
t7=((C_word*)t0)[8];
f_4944(t7,t1,lf[75]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t7=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t6);
/* expand.scm:390: loop */
t12=t1;
t13=C_fix(4);
t14=t3;
t15=t4;
t16=C_SCHEME_END_OF_LIST;
t17=C_SCHEME_END_OF_LIST;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
t5=t16;
t6=t17;
goto loop;}
else{
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t6);
/* expand.scm:390: loop */
t12=t1;
t13=C_fix(4);
t14=t3;
t15=t4;
t16=C_SCHEME_END_OF_LIST;
t17=C_SCHEME_END_OF_LIST;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
t5=t16;
t6=t17;
goto loop;}}}
else{
if(C_truep(C_i_pairp(t6))){
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5275,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[4],a[12]=t4,a[13]=t5,tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_symbolp(t8))){
t10=C_eqp(C_fix(3),t2);
t11=t9;
f_5275(t11,(C_truep(t10)?C_SCHEME_FALSE:(
  /* expand.scm:395: lookup */
  f_3670(t8,((C_word*)t0)[10])
)));}
else{
t10=t9;
f_5275(t10,C_SCHEME_FALSE);}}
else{
/* expand.scm:392: err */
t7=((C_word*)t0)[8];
f_4944(t7,t1,lf[85]);}}}}

/* k9385 in loop */
static void C_ccall f_9387(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9387,2,av);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
/* synrules.scm:311: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9380(t3,((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4462 in k4459 in tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4464,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop */
static void C_fcall f_9380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_9380,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9387,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
/* synrules.scm:310: ellipsis? */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_9387(2,av2);}}}

/* tmp13084 in a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(31,0,4)))){
C_save_and_reclaim_args((void *)trf_4457,2,t0,t1);}
a=C_alloc(31);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4461,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[3],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4494,a[2]=t6,a[3]=t4,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li26),tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=t4,a[3]=t6,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:237: ##sys#dynamic-wind */
t10=*((C_word*)lf[46]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t2;
av2[2]=t7;
av2[3]=t8;
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
/* expand.scm:239: handler */
t3=((C_word*)t0)[5];{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}}

/* a4454 in a4347 in call-handler in expand-0 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_4455,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li28),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[8],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4529,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp13084 */
t5=t2;
f_4457(t5,t4);}

/* k4988 in k4984 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_4990,2,t0,t1);}
a=C_alloc(11);
t2=t1;
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
/* expand.scm:357: values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
C_values(4,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=((C_word*)((C_word*)t0)[7])[1];
if(C_truep(t4)){
t5=t3;
f_5002(t5,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[8]))){
t5=C_i_cdr(((C_word*)t0)[2]);
t6=t3;
f_5002(t6,C_i_nullp(t5));}
else{
t5=t3;
f_5002(t5,C_SCHEME_FALSE);}}}}

/* k4192 in k4189 in extend-macro-environment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_4194,2,av);}
a=C_alloc(16);
t2=t1;
t3=(
  /* expand.scm:168: lookup */
  f_3670(((C_word*)t0)[2],((C_word*)t0)[3])
);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:165: g507 */
t5=((C_word*)t0)[5];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=(
  /* expand.scm:165: g507 */
  f_4201(t4,t3)
);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
/* expand.scm:175: ##sys#macro-environment */
t9=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t6;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* k4189 in extend-macro-environment in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_4191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_4191,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4194,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:167: ##sys#ensure-transformer */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10319 in k10286 in walk1 in k10237 in k10234 in k10231 in a10228 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_10321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_10321,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_a_i_list(&a,2,lf[71],((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10332,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* expand.scm:1323: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10241(t6,t4,((C_word*)t0)[6],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10342,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[7]))){
t3=C_u_i_car(((C_word*)t0)[7]);
/* expand.scm:1324: c */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}
else{
t3=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_10342(2,av2);}}}}

/* k11115 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_11117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11117,2,av);}
/* expand.scm:1185: expand */
t2=((C_word*)((C_word*)t0)[2])[1];
f_11010(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,5)))){
C_save_and_reclaim((void *)f_7027,2,av);}
a=C_alloc(33);
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7032,a[2]=t8,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7071,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7133,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7160,a[2]=t8,a[3]=t6,a[4]=t12,a[5]=t10,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
t18=C_mutate2((C_word*)lf[118]+1 /* (set! ##sys#syntax-error-culprit ...) */,((C_word*)t0)[7]);
t19=t17;
f_7160(t19,t18);}
else{
t18=t17;
f_7160(t18,C_SCHEME_UNDEFINED);}}

/* ##sys#check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7017(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +8,c,2)))){
C_save_and_reclaim((void*)f_7017,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+8);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t6=C_i_nullp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:C_i_car(t5));
t8=t7;
t9=C_i_nullp(t5);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_cdr(t5));
t11=t10;
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7027,a[2]=t11,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t11))){
/* expand.scm:719: ##sys#current-environment */
t13=*((C_word*)lf[1]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=t12;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t13;
av2[1]=C_i_car(t11);
f_7027(2,av2);}}}

/* k11160 in k11141 in k11138 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in ... */
static void C_ccall f_11162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,1)))){
C_save_and_reclaim((void *)f_11162,2,av);}
a=C_alloc(21);
t2=C_a_i_list(&a,4,lf[293],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[50],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6401 in loop2 in k6330 in k6312 in loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_6403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_6403,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[4]);
/* expand.scm:579: ##sys#expand-curried-define */
t4=*((C_word*)lf[108]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* loop in k7073 in lambda-list? in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_7083(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7083,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7103,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:737: keyword? */
t5=*((C_word*)lf[150]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
if(C_truep(C_i_symbolp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7131,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:740: keyword? */
t7=*((C_word*)lf[150]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* loop in extended-lambda-list? in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_4900(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_4900,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_eqp(t3,lf[64]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4919,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4919(t6,t4);}
else{
t6=C_eqp(t3,lf[65]);
t7=t5;
f_4919(t7,(C_truep(t6)?t6:C_eqp(t3,lf[66])));}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9995 in k9980 in k9942 in test in k9897 in k9894 in k9891 in k9888 in a9882 in k8205 in k8202 in k8199 in k8196 in k8193 in k8190 in k8187 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in ... */
static void C_ccall f_9997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9997,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_u_i_cdr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* expand.scm:1399: test */
t4=((C_word*)((C_word*)t0)[5])[1];
f_9911(t4,((C_word*)t0)[2],t3);}}

/* k5449 in k5273 in loop in k4965 in k4962 in k4959 in expand-extended-lambda-list in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_5451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,6)))){
C_save_and_reclaim_args((void *)trf_5451,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
switch(t2){
case C_fix(0):
/* expand.scm:426: err */
t3=((C_word*)t0)[3];
f_4944(t3,((C_word*)t0)[4],lf[82]);
case C_fix(1):
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* expand.scm:427: loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4972(t4,((C_word*)t0)[4],C_fix(1),((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[9]);
case C_fix(2):
/* expand.scm:428: err */
t3=((C_word*)t0)[3];
f_4944(t3,((C_word*)t0)[4],lf[83]);
default:
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[10]);
/* expand.scm:429: loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4972(t4,((C_word*)t0)[4],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[6],t3,((C_word*)t0)[9]);}}
else{
/* expand.scm:430: err */
t2=((C_word*)t0)[3];
f_4944(t2,((C_word*)t0)[4],lf[84]);}}

/* k7073 in lambda-list? in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7075,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7083,a[2]=t3,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7083(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* lambda-list? in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7071,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7075,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:734: ##sys#extended-lambda-list? */
t4=*((C_word*)lf[63]+1);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k11790 in k11773 in k11762 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11792,2,av);}
if(C_truep(t1)){
/* expand.scm:1010: ##sys#defjam-error */
t2=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_11778(2,av2);}}}

/* k11797 in k11773 in k11762 in loop in k11742 in a11739 in k8078 in k8075 in k8072 in k8069 in k8066 in k8063 in k8059 in k8056 in k8053 in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_11799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11799,2,av);}
/* expand.scm:1009: c */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t2))(4,av2);}}

/* k11141 in k11138 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in ... */
static void C_ccall f_11143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_11143,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=C_i_caddr(((C_word*)t0)[2]);
t8=C_a_i_list(&a,2,t7,t2);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11162,a[2]=t2,a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1200: expand */
t11=((C_word*)((C_word*)t0)[4])[1];
f_11010(t11,t10,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k11138 in k11063 in k11060 in k11022 in expand in k11003 in k11000 in k10997 in a10991 in k8184 in k8181 in k8178 in k8175 in k8172 in k8169 in k8166 in k8163 in k8086 in k8082 in k8078 in k8075 in k8072 in ... */
static void C_ccall f_11140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_11140,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1196: r */
t3=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_u_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1202: c */
t6=((C_word*)t0)[7];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}
else{
t5=t2;{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_11180(2,av2);}}}}

/* k7060 in k7046 in err in k7025 in check-syntax in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_ccall f_7062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_7062,2,av);}
/* expand.scm:729: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[145];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[146];
av2[5]=t1;
av2[6]=lf[147];
av2[7]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}

/* loop in expand in k5731 in canonicalize-body in k4144 in k3666 in k3662 in k3658 in k3654 */
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,5)))){
C_save_and_reclaim_args((void *)trf_6294,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(15);
if(C_truep(C_i_pairp(t2))){
t6=C_i_car(t2);
t7=t6;
t8=t2;
t9=C_u_i_cdr(t8);
t10=C_i_pairp(t7);
t11=(C_truep(t10)?C_u_i_car(t7):C_SCHEME_FALSE);
t12=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=t9,a[9]=t1,a[10]=t7,a[11]=((C_word*)t0)[5],a[12]=t2,a[13]=((C_word*)t0)[6],a[14]=((C_word*)t0)[7],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t11)){
t13=C_i_symbolp(t11);
t14=t12;
f_6314(t14,(C_truep(t13)?t11:C_SCHEME_FALSE));}
else{
t13=t12;
f_6314(t13,C_SCHEME_FALSE);}}
else{
/* expand.scm:553: fini */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5810(t6,t1,t3,t4,t5,t2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[670] = {
{"f_7069:expand_2escm",(void*)f_7069},
{"f_6410:expand_2escm",(void*)f_6410},
{"f_4919:expand_2escm",(void*)f_4919},
{"f_9000:expand_2escm",(void*)f_9000},
{"f_9003:expand_2escm",(void*)f_9003},
{"f_6417:expand_2escm",(void*)f_6417},
{"f_7055:expand_2escm",(void*)f_7055},
{"f_9006:expand_2escm",(void*)f_9006},
{"f_11775:expand_2escm",(void*)f_11775},
{"f_11778:expand_2escm",(void*)f_11778},
{"f_6288:expand_2escm",(void*)f_6288},
{"f_11910:expand_2escm",(void*)f_11910},
{"f_11914:expand_2escm",(void*)f_11914},
{"f_9050:expand_2escm",(void*)f_9050},
{"f_4382:expand_2escm",(void*)f_4382},
{"f_4388:expand_2escm",(void*)f_4388},
{"f_11416:expand_2escm",(void*)f_11416},
{"f_11414:expand_2escm",(void*)f_11414},
{"f_11908:expand_2escm",(void*)f_11908},
{"f_5852:expand_2escm",(void*)f_5852},
{"f_4371:expand_2escm",(void*)f_4371},
{"f_11447:expand_2escm",(void*)f_11447},
{"f_10730:expand_2escm",(void*)f_10730},
{"f_11952:expand_2escm",(void*)f_11952},
{"f_10720:expand_2escm",(void*)f_10720},
{"f_11954:expand_2escm",(void*)f_11954},
{"f_4620:expand_2escm",(void*)f_4620},
{"f_11942:expand_2escm",(void*)f_11942},
{"f_9023:expand_2escm",(void*)f_9023},
{"f_10714:expand_2escm",(void*)f_10714},
{"f_11944:expand_2escm",(void*)f_11944},
{"f_5810:expand_2escm",(void*)f_5810},
{"f_9029:expand_2escm",(void*)f_9029},
{"f_10716:expand_2escm",(void*)f_10716},
{"f_9027:expand_2escm",(void*)f_9027},
{"f_5193:expand_2escm",(void*)f_5193},
{"f_5190:expand_2escm",(void*)f_5190},
{"f_5195:expand_2escm",(void*)f_5195},
{"f_5187:expand_2escm",(void*)f_5187},
{"f_11931:expand_2escm",(void*)f_11931},
{"f_11406:expand_2escm",(void*)f_11406},
{"f_4608:expand_2escm",(void*)f_4608},
{"f_5841:expand_2escm",(void*)f_5841},
{"f_5848:expand_2escm",(void*)f_5848},
{"f_5183:expand_2escm",(void*)f_5183},
{"f_11134:expand_2escm",(void*)f_11134},
{"f_11927:expand_2escm",(void*)f_11927},
{"f_11925:expand_2escm",(void*)f_11925},
{"f_5130:expand_2escm",(void*)f_5130},
{"f_9944:expand_2escm",(void*)f_9944},
{"f_10765:expand_2escm",(void*)f_10765},
{"f_5860:expand_2escm",(void*)f_5860},
{"f_10767:expand_2escm",(void*)f_10767},
{"f_4894:expand_2escm",(void*)f_4894},
{"f_10755:expand_2escm",(void*)f_10755},
{"f_11364:expand_2escm",(void*)f_11364},
{"f_11362:expand_2escm",(void*)f_11362},
{"f_7487:expand_2escm",(void*)f_7487},
{"f_10489:expand_2escm",(void*)f_10489},
{"f_7485:expand_2escm",(void*)f_7485},
{"f_9901:expand_2escm",(void*)f_9901},
{"f_7472:expand_2escm",(void*)f_7472},
{"f_7478:expand_2escm",(void*)f_7478},
{"f_9019:expand_2escm",(void*)f_9019},
{"f_9281:expand_2escm",(void*)f_9281},
{"f_7921:expand_2escm",(void*)f_7921},
{"f_11453:expand_2escm",(void*)f_11453},
{"f_11457:expand_2escm",(void*)f_11457},
{"f_11451:expand_2escm",(void*)f_11451},
{"f_11328:expand_2escm",(void*)f_11328},
{"f_10791:expand_2escm",(void*)f_10791},
{"f_7917:expand_2escm",(void*)f_7917},
{"f_11312:expand_2escm",(void*)f_11312},
{"f_6135:expand_2escm",(void*)f_6135},
{"f_8426:expand_2escm",(void*)f_8426},
{"f_6133:expand_2escm",(void*)f_6133},
{"f_6130:expand_2escm",(void*)f_6130},
{"f_7903:expand_2escm",(void*)f_7903},
{"f_11300:expand_2escm",(void*)f_11300},
{"f_4817:expand_2escm",(void*)f_4817},
{"f_5692:expand_2escm",(void*)f_5692},
{"f_8462:expand_2escm",(void*)f_8462},
{"f_8454:expand_2escm",(void*)f_8454},
{"f_8458:expand_2escm",(void*)f_8458},
{"f_8433:expand_2escm",(void*)f_8433},
{"f_9962:expand_2escm",(void*)f_9962},
{"f_8464:expand_2escm",(void*)f_8464},
{"f_8469:expand_2escm",(void*)f_8469},
{"f_8165:expand_2escm",(void*)f_8165},
{"f_8168:expand_2escm",(void*)f_8168},
{"f_10400:expand_2escm",(void*)f_10400},
{"f_5993:expand_2escm",(void*)f_5993},
{"f_9982:expand_2escm",(void*)f_9982},
{"f_9911:expand_2escm",(void*)f_9911},
{"f_6108:expand_2escm",(void*)f_6108},
{"f_6106:expand_2escm",(void*)f_6106},
{"f_5604:expand_2escm",(void*)f_5604},
{"f_9925:expand_2escm",(void*)f_9925},
{"f_10788:expand_2escm",(void*)f_10788},
{"f_10785:expand_2escm",(void*)f_10785},
{"f_10418:expand_2escm",(void*)f_10418},
{"f_10782:expand_2escm",(void*)f_10782},
{"f_8129:expand_2escm",(void*)f_8129},
{"f_10414:expand_2escm",(void*)f_10414},
{"f_9831:expand_2escm",(void*)f_9831},
{"f_9839:expand_2escm",(void*)f_9839},
{"f_10779:expand_2escm",(void*)f_10779},
{"f_10771:expand_2escm",(void*)f_10771},
{"f_11880:expand_2escm",(void*)f_11880},
{"f_5626:expand_2escm",(void*)f_5626},
{"f_8307:expand_2escm",(void*)f_8307},
{"f_8302:expand_2escm",(void*)f_8302},
{"f_8109:expand_2escm",(void*)f_8109},
{"f_11891:expand_2escm",(void*)f_11891},
{"f_11893:expand_2escm",(void*)f_11893},
{"f_10422:expand_2escm",(void*)f_10422},
{"f_9821:expand_2escm",(void*)f_9821},
{"f_11863:expand_2escm",(void*)f_11863},
{"f_9829:expand_2escm",(void*)f_9829},
{"f_11897:expand_2escm",(void*)f_11897},
{"f_9298:expand_2escm",(void*)f_9298},
{"f_9296:expand_2escm",(void*)f_9296},
{"f_4416:expand_2escm",(void*)f_4416},
{"f_9870:expand_2escm",(void*)f_9870},
{"f_11874:expand_2escm",(void*)f_11874},
{"f_5917:expand_2escm",(void*)f_5917},
{"f_8859:expand_2escm",(void*)f_8859},
{"f_9807:expand_2escm",(void*)f_9807},
{"f_4405:expand_2escm",(void*)f_4405},
{"f_5914:expand_2escm",(void*)f_5914},
{"f_11876:expand_2escm",(void*)f_11876},
{"f_6022:expand_2escm",(void*)f_6022},
{"f_9592:expand_2escm",(void*)f_9592},
{"f_9594:expand_2escm",(void*)f_9594},
{"f_9855:expand_2escm",(void*)f_9855},
{"f_9857:expand_2escm",(void*)f_9857},
{"f_6182:expand_2escm",(void*)f_6182},
{"f_9598:expand_2escm",(void*)f_9598},
{"f_9868:expand_2escm",(void*)f_9868},
{"f_6082:expand_2escm",(void*)f_6082},
{"f_6080:expand_2escm",(void*)f_6080},
{"f_6086:expand_2escm",(void*)f_6086},
{"f_6791:expand_2escm",(void*)f_6791},
{"f_9127:expand_2escm",(void*)f_9127},
{"f_10448:expand_2escm",(void*)f_10448},
{"f_8370:expand_2escm",(void*)f_8370},
{"f_10444:expand_2escm",(void*)f_10444},
{"f_9326:expand_2escm",(void*)f_9326},
{"f_4944:expand_2escm",(void*)f_4944},
{"f_9556:expand_2escm",(void*)f_9556},
{"f_8384:expand_2escm",(void*)f_8384},
{"f_9552:expand_2escm",(void*)f_9552},
{"f_4941:expand_2escm",(void*)f_4941},
{"f_9548:expand_2escm",(void*)f_9548},
{"f_8905:expand_2escm",(void*)f_8905},
{"f_8909:expand_2escm",(void*)f_8909},
{"f_9562:expand_2escm",(void*)f_9562},
{"f_6056:expand_2escm",(void*)f_6056},
{"f_9558:expand_2escm",(void*)f_9558},
{"f_7624:expand_2escm",(void*)f_7624},
{"f_4964:expand_2escm",(void*)f_4964},
{"f_4967:expand_2escm",(void*)f_4967},
{"f_9173:expand_2escm",(void*)f_9173},
{"f_4961:expand_2escm",(void*)f_4961},
{"f_9350:expand_2escm",(void*)f_9350},
{"f_9357:expand_2escm",(void*)f_9357},
{"f_9579:expand_2escm",(void*)f_9579},
{"f_7607:expand_2escm",(void*)f_7607},
{"f_10297:expand_2escm",(void*)f_10297},
{"f_9364:expand_2escm",(void*)f_9364},
{"f_9192:expand_2escm",(void*)f_9192},
{"f_6196:expand_2escm",(void*)f_6196},
{"f_10288:expand_2escm",(void*)f_10288},
{"f_6098:expand_2escm",(void*)f_6098},
{"f_5220:expand_2escm",(void*)f_5220},
{"f_9601:expand_2escm",(void*)f_9601},
{"f_9604:expand_2escm",(void*)f_9604},
{"f_9611:expand_2escm",(void*)f_9611},
{"f_9619:expand_2escm",(void*)f_9619},
{"f_8677:expand_2escm",(void*)f_8677},
{"f_8673:expand_2escm",(void*)f_8673},
{"f_5234:expand_2escm",(void*)f_5234},
{"f_8640:expand_2escm",(void*)f_8640},
{"f_4645:expand_2escm",(void*)f_4645},
{"f_4647:expand_2escm",(void*)f_4647},
{"f_10227:expand_2escm",(void*)f_10227},
{"f_10229:expand_2escm",(void*)f_10229},
{"f_10200:expand_2escm",(void*)f_10200},
{"f_6787:expand_2escm",(void*)f_6787},
{"f_9649:expand_2escm",(void*)f_9649},
{"f_5002:expand_2escm",(void*)f_5002},
{"f_7208:expand_2escm",(void*)f_7208},
{"f_9407:expand_2escm",(void*)f_9407},
{"f_9651:expand_2escm",(void*)f_9651},
{"f_9658:expand_2escm",(void*)f_9658},
{"f_5383:expand_2escm",(void*)f_5383},
{"f_10207:expand_2escm",(void*)f_10207},
{"f_9621:expand_2escm",(void*)f_9621},
{"f_9625:expand_2escm",(void*)f_9625},
{"f_9628:expand_2escm",(void*)f_9628},
{"f_10251:expand_2escm",(void*)f_10251},
{"f_10269:expand_2escm",(void*)f_10269},
{"f_10265:expand_2escm",(void*)f_10265},
{"f_10241:expand_2escm",(void*)f_10241},
{"f_6350:expand_2escm",(void*)f_6350},
{"f_6353:expand_2escm",(void*)f_6353},
{"f_10249:expand_2escm",(void*)f_10249},
{"f_10925:expand_2escm",(void*)f_10925},
{"f_7942:expand_2escm",(void*)f_7942},
{"f_9481:expand_2escm",(void*)f_9481},
{"f_11183:expand_2escm",(void*)f_11183},
{"f_11180:expand_2escm",(void*)f_11180},
{"f_6887:expand_2escm",(void*)f_6887},
{"f_7938:expand_2escm",(void*)f_7938},
{"f_6884:expand_2escm",(void*)f_6884},
{"f_6875:expand_2escm",(void*)f_6875},
{"f_6872:expand_2escm",(void*)f_6872},
{"f_6206:expand_2escm",(void*)f_6206},
{"f_11539:expand_2escm",(void*)f_11539},
{"f_10233:expand_2escm",(void*)f_10233},
{"f_11655:expand_2escm",(void*)f_11655},
{"f_11652:expand_2escm",(void*)f_11652},
{"f_11857:expand_2escm",(void*)f_11857},
{"f_11859:expand_2escm",(void*)f_11859},
{"f_11526:expand_2escm",(void*)f_11526},
{"f_11523:expand_2escm",(void*)f_11523},
{"f_10236:expand_2escm",(void*)f_10236},
{"f_10239:expand_2escm",(void*)f_10239},
{"f_6820:expand_2escm",(void*)f_6820},
{"f_6827:expand_2escm",(void*)f_6827},
{"f_5586:expand_2escm",(void*)f_5586},
{"f_11517:expand_2escm",(void*)f_11517},
{"f_4324:expand_2escm",(void*)f_4324},
{"f_5582:expand_2escm",(void*)f_5582},
{"f_4557:expand_2escm",(void*)f_4557},
{"f_4851:expand_2escm",(void*)f_4851},
{"f_6818:expand_2escm",(void*)f_6818},
{"f_11519:expand_2escm",(void*)f_11519},
{"f_11504:expand_2escm",(void*)f_11504},
{"f_11501:expand_2escm",(void*)f_11501},
{"f_4316:expand_2escm",(void*)f_4316},
{"f_11669:expand_2escm",(void*)f_11669},
{"f_11666:expand_2escm",(void*)f_11666},
{"f_3745:expand_2escm",(void*)f_3745},
{"f_4348:expand_2escm",(void*)f_4348},
{"f_4343:expand_2escm",(void*)f_4343},
{"f_3694:expand_2escm",(void*)f_3694},
{"f_3697:expand_2escm",(void*)f_3697},
{"f_11812:expand_2escm",(void*)f_11812},
{"f_11610:expand_2escm",(void*)f_11610},
{"f_4857:expand_2escm",(void*)f_4857},
{"f_11819:expand_2escm",(void*)f_11819},
{"f_4831:expand_2escm",(void*)f_4831},
{"f_11563:expand_2escm",(void*)f_11563},
{"f_3751:expand_2escm",(void*)f_3751},
{"f_11567:expand_2escm",(void*)f_11567},
{"f_6927:expand_2escm",(void*)f_6927},
{"f_11561:expand_2escm",(void*)f_11561},
{"f_11803:expand_2escm",(void*)f_11803},
{"f_11600:expand_2escm",(void*)f_11600},
{"f_4845:expand_2escm",(void*)f_4845},
{"f_4333:expand_2escm",(void*)f_4333},
{"f_5556:expand_2escm",(void*)f_5556},
{"f_4330:expand_2escm",(void*)f_4330},
{"f_5550:expand_2escm",(void*)f_5550},
{"f_4360:expand_2escm",(void*)f_4360},
{"f_5544:expand_2escm",(void*)f_5544},
{"f_4599:expand_2escm",(void*)f_4599},
{"f_11545:expand_2escm",(void*)f_11545},
{"f_11548:expand_2escm",(void*)f_11548},
{"f_4354:expand_2escm",(void*)f_4354},
{"f_11541:expand_2escm",(void*)f_11541},
{"f_4827:expand_2escm",(void*)f_4827},
{"f_3687:expand_2escm",(void*)f_3687},
{"f_10194:expand_2escm",(void*)f_10194},
{"f_10196:expand_2escm",(void*)f_10196},
{"f_6978:expand_2escm",(void*)f_6978},
{"f_6972:expand_2escm",(void*)f_6972},
{"f_4287:expand_2escm",(void*)f_4287},
{"f_3700:expand_2escm",(void*)f_3700},
{"f_3656:expand_2escm",(void*)f_3656},
{"f_10942:expand_2escm",(void*)f_10942},
{"f_10940:expand_2escm",(void*)f_10940},
{"f_5563:expand_2escm",(void*)f_5563},
{"f_5560:expand_2escm",(void*)f_5560},
{"f_11495:expand_2escm",(void*)f_11495},
{"f_3664:expand_2escm",(void*)f_3664},
{"f_3660:expand_2escm",(void*)f_3660},
{"f_3668:expand_2escm",(void*)f_3668},
{"f_10173:expand_2escm",(void*)f_10173},
{"f_4268:expand_2escm",(void*)f_4268},
{"f_6998:expand_2escm",(void*)f_6998},
{"f_7419:expand_2escm",(void*)f_7419},
{"f_11497:expand_2escm",(void*)f_11497},
{"f_10179:expand_2escm",(void*)f_10179},
{"f_10175:expand_2escm",(void*)f_10175},
{"f_4084:expand_2escm",(void*)f_4084},
{"f_5960:expand_2escm",(void*)f_5960},
{"f_6896:expand_2escm",(void*)f_6896},
{"f_6893:expand_2escm",(void*)f_6893},
{"f_5967:expand_2escm",(void*)f_5967},
{"f_6890:expand_2escm",(void*)f_6890},
{"f_5058:expand_2escm",(void*)f_5058},
{"f_4062:expand_2escm",(void*)f_4062},
{"f_4293:expand_2escm",(void*)f_4293},
{"f_4291:expand_2escm",(void*)f_4291},
{"f_6899:expand_2escm",(void*)f_6899},
{"f_10153:expand_2escm",(void*)f_10153},
{"f_5081:expand_2escm",(void*)f_5081},
{"f_4050:expand_2escm",(void*)f_4050},
{"f_10626:expand_2escm",(void*)f_10626},
{"f_10628:expand_2escm",(void*)f_10628},
{"f_9516:expand_2escm",(void*)f_9516},
{"f_4068:expand_2escm",(void*)f_4068},
{"f_5077:expand_2escm",(void*)f_5077},
{"f_9207:expand_2escm",(void*)f_9207},
{"f_9209:expand_2escm",(void*)f_9209},
{"f_7362:expand_2escm",(void*)f_7362},
{"f_9251:expand_2escm",(void*)f_9251},
{"f_5927:expand_2escm",(void*)f_5927},
{"f_10137:expand_2escm",(void*)f_10137},
{"f_11387:expand_2escm",(void*)f_11387},
{"f_11635:expand_2escm",(void*)f_11635},
{"f_11637:expand_2escm",(void*)f_11637},
{"f_3670:expand_2escm",(void*)f_3670},
{"f_5923:expand_2escm",(void*)f_5923},
{"f_9262:expand_2escm",(void*)f_9262},
{"f_5958:expand_2escm",(void*)f_5958},
{"f_9544:expand_2escm",(void*)f_9544},
{"f_9540:expand_2escm",(void*)f_9540},
{"f_11822:expand_2escm",(void*)f_11822},
{"f_10653:expand_2escm",(void*)f_10653},
{"f_5952:expand_2escm",(void*)f_5952},
{"f_5955:expand_2escm",(void*)f_5955},
{"f_5949:expand_2escm",(void*)f_5949},
{"f_5033:expand_2escm",(void*)f_5033},
{"f_4025:expand_2escm",(void*)f_4025},
{"f_11056:expand_2escm",(void*)f_11056},
{"f_11052:expand_2escm",(void*)f_11052},
{"f_11049:expand_2escm",(void*)f_11049},
{"f_11046:expand_2escm",(void*)f_11046},
{"f_11043:expand_2escm",(void*)f_11043},
{"f_11074:expand_2escm",(void*)f_11074},
{"f_9504:expand_2escm",(void*)f_9504},
{"f_9506:expand_2escm",(void*)f_9506},
{"f_8627:expand_2escm",(void*)f_8627},
{"f_8332:expand_2escm",(void*)f_8332},
{"f_10992:expand_2escm",(void*)f_10992},
{"f_10999:expand_2escm",(void*)f_10999},
{"f_10990:expand_2escm",(void*)f_10990},
{"f_11065:expand_2escm",(void*)f_11065},
{"f_11068:expand_2escm",(void*)f_11068},
{"f_11062:expand_2escm",(void*)f_11062},
{"f_11480:expand_2escm",(void*)f_11480},
{"f_11010:expand_2escm",(void*)f_11010},
{"f_8319:expand_2escm",(void*)f_8319},
{"f_8315:expand_2escm",(void*)f_8315},
{"f_8311:expand_2escm",(void*)f_8311},
{"f_7663:expand_2escm",(void*)f_7663},
{"f_11005:expand_2escm",(void*)f_11005},
{"f_11002:expand_2escm",(void*)f_11002},
{"f_8324:expand_2escm",(void*)f_8324},
{"f_8326:expand_2escm",(void*)f_8326},
{"f_8619:expand_2escm",(void*)f_8619},
{"f_11033:expand_2escm",(void*)f_11033},
{"f_11037:expand_2escm",(void*)f_11037},
{"f_11030:expand_2escm",(void*)f_11030},
{"f_7641:expand_2escm",(void*)f_7641},
{"f_11024:expand_2escm",(void*)f_11024},
{"f_3911:expand_2escm",(void*)f_3911},
{"f_3926:expand_2escm",(void*)f_3926},
{"f_3928:expand_2escm",(void*)f_3928},
{"f_8360:expand_2escm",(void*)f_8360},
{"f_8830:expand_2escm",(void*)f_8830},
{"f_8824:expand_2escm",(void*)f_8824},
{"f_8800:expand_2escm",(void*)f_8800},
{"f_8228:expand_2escm",(void*)f_8228},
{"f_8225:expand_2escm",(void*)f_8225},
{"f_8222:expand_2escm",(void*)f_8222},
{"f_9132:expand_2escm",(void*)f_9132},
{"f_8286:expand_2escm",(void*)f_8286},
{"f_8282:expand_2escm",(void*)f_8282},
{"f_10678:expand_2escm",(void*)f_10678},
{"f_6740:expand_2escm",(void*)f_6740},
{"f_6748:expand_2escm",(void*)f_6748},
{"f_5729:expand_2escm",(void*)f_5729},
{"f_8295:expand_2escm",(void*)f_8295},
{"f_8290:expand_2escm",(void*)f_8290},
{"f_6732:expand_2escm",(void*)f_6732},
{"f_5717:expand_2escm",(void*)f_5717},
{"f_6762:expand_2escm",(void*)f_6762},
{"f_6767:expand_2escm",(void*)f_6767},
{"f_9158:expand_2escm",(void*)f_9158},
{"f_8278:expand_2escm",(void*)f_8278},
{"f_8274:expand_2escm",(void*)f_8274},
{"f_8270:expand_2escm",(void*)f_8270},
{"f_8847:expand_2escm",(void*)f_8847},
{"f_6751:expand_2escm",(void*)f_6751},
{"f_8843:expand_2escm",(void*)f_8843},
{"f_9106:expand_2escm",(void*)f_9106},
{"f_9102:expand_2escm",(void*)f_9102},
{"f_7103:expand_2escm",(void*)f_7103},
{"f_11964:expand_2escm",(void*)f_11964},
{"f_11962:expand_2escm",(void*)f_11962},
{"f_9123:expand_2escm",(void*)f_9123},
{"f_3850:expand_2escm",(void*)f_3850},
{"f_9444:expand_2escm",(void*)f_9444},
{"f_9414:expand_2escm",(void*)f_9414},
{"f_7139:expand_2escm",(void*)f_7139},
{"f_7131:expand_2escm",(void*)f_7131},
{"f_7133:expand_2escm",(void*)f_7133},
{"f_7700:expand_2escm",(void*)f_7700},
{"f_9423:expand_2escm",(void*)f_9423},
{"f_9421:expand_2escm",(void*)f_9421},
{"f_3841:expand_2escm",(void*)f_3841},
{"f_3823:expand_2escm",(void*)f_3823},
{"f_5304:expand_2escm",(void*)f_5304},
{"f_9457:expand_2escm",(void*)f_9457},
{"f_9464:expand_2escm",(void*)f_9464},
{"f_9465:expand_2escm",(void*)f_9465},
{"f_6332:expand_2escm",(void*)f_6332},
{"f_6337:expand_2escm",(void*)f_6337},
{"f_5322:expand_2escm",(void*)f_5322},
{"f_5325:expand_2escm",(void*)f_5325},
{"f_8566:expand_2escm",(void*)f_8566},
{"f_8562:expand_2escm",(void*)f_8562},
{"f_8570:expand_2escm",(void*)f_8570},
{"f_5364:expand_2escm",(void*)f_5364},
{"f_6314:expand_2escm",(void*)f_6314},
{"f_6806:expand_2escm",(void*)f_6806},
{"f_6865:expand_2escm",(void*)f_6865},
{"f_6852:expand_2escm",(void*)f_6852},
{"f_6855:expand_2escm",(void*)f_6855},
{"f_6858:expand_2escm",(void*)f_6858},
{"f_6688:expand_2escm",(void*)f_6688},
{"f_6685:expand_2escm",(void*)f_6685},
{"f_6683:expand_2escm",(void*)f_6683},
{"f_4505:expand_2escm",(void*)f_4505},
{"f_6846:expand_2escm",(void*)f_6846},
{"f_6849:expand_2escm",(void*)f_6849},
{"f_6834:expand_2escm",(void*)f_6834},
{"f_6836:expand_2escm",(void*)f_6836},
{"f_11679:expand_2escm",(void*)f_11679},
{"f_4531:expand_2escm",(void*)f_4531},
{"f_10837:expand_2escm",(void*)f_10837},
{"f_4529:expand_2escm",(void*)f_4529},
{"f_10831:expand_2escm",(void*)f_10831},
{"f_10827:expand_2escm",(void*)f_10827},
{"f_10824:expand_2escm",(void*)f_10824},
{"f_10818:expand_2escm",(void*)f_10818},
{"f_7184:expand_2escm",(void*)f_7184},
{"f_7189:expand_2escm",(void*)f_7189},
{"f_6931:expand_2escm",(void*)f_6931},
{"f_6933:expand_2escm",(void*)f_6933},
{"f_4575:expand_2escm",(void*)f_4575},
{"f_3871:expand_2escm",(void*)f_3871},
{"f_10802:expand_2escm",(void*)f_10802},
{"f_10804:expand_2escm",(void*)f_10804},
{"f_4774:expand_2escm",(void*)f_4774},
{"f_3882:expand_2escm",(void*)f_3882},
{"f_7165:expand_2escm",(void*)f_7165},
{"f_7160:expand_2escm",(void*)f_7160},
{"f_3886:expand_2escm",(void*)f_3886},
{"f_6951:expand_2escm",(void*)f_6951},
{"f_3976:expand_2escm",(void*)f_3976},
{"f_4518:expand_2escm",(void*)f_4518},
{"f_11686:expand_2escm",(void*)f_11686},
{"f_11699:expand_2escm",(void*)f_11699},
{"f_6947:expand_2escm",(void*)f_6947},
{"f_4512:expand_2escm",(void*)f_4512},
{"f_11696:expand_2escm",(void*)f_11696},
{"f_11693:expand_2escm",(void*)f_11693},
{"f_11690:expand_2escm",(void*)f_11690},
{"f_4201:expand_2escm",(void*)f_4201},
{"f_5733:expand_2escm",(void*)f_5733},
{"f_6912:expand_2escm",(void*)f_6912},
{"f_11738:expand_2escm",(void*)f_11738},
{"f_6916:expand_2escm",(void*)f_6916},
{"f_3816:expand_2escm",(void*)f_3816},
{"f_4219:expand_2escm",(void*)f_4219},
{"f_11764:expand_2escm",(void*)f_11764},
{"f_6481:expand_2escm",(void*)f_6481},
{"f_4246:expand_2escm",(void*)f_4246},
{"f_4240:expand_2escm",(void*)f_4240},
{"f_4242:expand_2escm",(void*)f_4242},
{"f_4279:expand_2escm",(void*)f_4279},
{"f_6469:expand_2escm",(void*)f_6469},
{"f_4229:expand_2escm",(void*)f_4229},
{"f_8040:expand_2escm",(void*)f_8040},
{"f_4716:expand_2escm",(void*)f_4716},
{"f_4710:expand_2escm",(void*)f_4710},
{"f_7878:expand_2escm",(void*)f_7878},
{"f_5744:expand_2escm",(void*)f_5744},
{"f_8046:expand_2escm",(void*)f_8046},
{"f_7501:expand_2escm",(void*)f_7501},
{"f_7505:expand_2escm",(void*)f_7505},
{"f_10846:expand_2escm",(void*)f_10846},
{"f_10840:expand_2escm",(void*)f_10840},
{"f_8055:expand_2escm",(void*)f_8055},
{"f_8058:expand_2escm",(void*)f_8058},
{"f_11597:expand_2escm",(void*)f_11597},
{"f_10074:expand_2escm",(void*)f_10074},
{"f_10072:expand_2escm",(void*)f_10072},
{"f_8035:expand_2escm",(void*)f_8035},
{"f_8031:expand_2escm",(void*)f_8031},
{"f_11210:expand_2escm",(void*)f_11210},
{"f_8061:expand_2escm",(void*)f_8061},
{"f_6517:expand_2escm",(void*)f_6517},
{"f_10047:expand_2escm",(void*)f_10047},
{"f_11744:expand_2escm",(void*)f_11744},
{"f_11749:expand_2escm",(void*)f_11749},
{"f_7828:expand_2escm",(void*)f_7828},
{"f_11740:expand_2escm",(void*)f_11740},
{"f_8096:expand_2escm",(void*)f_8096},
{"f_7574:expand_2escm",(void*)f_7574},
{"f_8071:expand_2escm",(void*)f_8071},
{"f_7577:expand_2escm",(void*)f_7577},
{"toplevel:expand_2escm",(void*)C_expand_toplevel},
{"f_7815:expand_2escm",(void*)f_7815},
{"f_8065:expand_2escm",(void*)f_8065},
{"f_11237:expand_2escm",(void*)f_11237},
{"f_8068:expand_2escm",(void*)f_8068},
{"f_10031:expand_2escm",(void*)f_10031},
{"f_7522:expand_2escm",(void*)f_7522},
{"f_6533:expand_2escm",(void*)f_6533},
{"f_7526:expand_2escm",(void*)f_7526},
{"f_7800:expand_2escm",(void*)f_7800},
{"f_8077:expand_2escm",(void*)f_8077},
{"f_8074:expand_2escm",(void*)f_8074},
{"f_10024:expand_2escm",(void*)f_10024},
{"f_7556:expand_2escm",(void*)f_7556},
{"f_10585:expand_2escm",(void*)f_10585},
{"f_10564:expand_2escm",(void*)f_10564},
{"f_8526:expand_2escm",(void*)f_8526},
{"f_7760:expand_2escm",(void*)f_7760},
{"f_8240:expand_2escm",(void*)f_8240},
{"f_10892:expand_2escm",(void*)f_10892},
{"f_8255:expand_2escm",(void*)f_8255},
{"f_8259:expand_2escm",(void*)f_8259},
{"f_7752:expand_2escm",(void*)f_7752},
{"f_11570:expand_2escm",(void*)f_11570},
{"f_10885:expand_2escm",(void*)f_10885},
{"f_10889:expand_2escm",(void*)f_10889},
{"f_11585:expand_2escm",(void*)f_11585},
{"f_11583:expand_2escm",(void*)f_11583},
{"f_11589:expand_2escm",(void*)f_11589},
{"f_8492:expand_2escm",(void*)f_8492},
{"f_8231:expand_2escm",(void*)f_8231},
{"f_8233:expand_2escm",(void*)f_8233},
{"f_8207:expand_2escm",(void*)f_8207},
{"f_10524:expand_2escm",(void*)f_10524},
{"f_8204:expand_2escm",(void*)f_8204},
{"f_10520:expand_2escm",(void*)f_10520},
{"f_9732:expand_2escm",(void*)f_9732},
{"f_8201:expand_2escm",(void*)f_8201},
{"f_7721:expand_2escm",(void*)f_7721},
{"f_8219:expand_2escm",(void*)f_8219},
{"f_8216:expand_2escm",(void*)f_8216},
{"f_8213:expand_2escm",(void*)f_8213},
{"f_8210:expand_2escm",(void*)f_8210},
{"f_10518:expand_2escm",(void*)f_10518},
{"f_8409:expand_2escm",(void*)f_8409},
{"f_8264:expand_2escm",(void*)f_8264},
{"f_9729:expand_2escm",(void*)f_9729},
{"f_10507:expand_2escm",(void*)f_10507},
{"f_9722:expand_2escm",(void*)f_9722},
{"f_9726:expand_2escm",(void*)f_9726},
{"f_8080:expand_2escm",(void*)f_8080},
{"f_9773:expand_2escm",(void*)f_9773},
{"f_8732:expand_2escm",(void*)f_8732},
{"f_8090:expand_2escm",(void*)f_8090},
{"f_9744:expand_2escm",(void*)f_9744},
{"f_5822:expand_2escm",(void*)f_5822},
{"f_8084:expand_2escm",(void*)f_8084},
{"f_8088:expand_2escm",(void*)f_8088},
{"f_4102:expand_2escm",(void*)f_4102},
{"f_8112:expand_2escm",(void*)f_8112},
{"f_10536:expand_2escm",(void*)f_10536},
{"f_8177:expand_2escm",(void*)f_8177},
{"f_8171:expand_2escm",(void*)f_8171},
{"f_8174:expand_2escm",(void*)f_8174},
{"f_9847:expand_2escm",(void*)f_9847},
{"f_4118:expand_2escm",(void*)f_4118},
{"f_9890:expand_2escm",(void*)f_9890},
{"f_8189:expand_2escm",(void*)f_8189},
{"f_9893:expand_2escm",(void*)f_9893},
{"f_8186:expand_2escm",(void*)f_8186},
{"f_8183:expand_2escm",(void*)f_8183},
{"f_8180:expand_2escm",(void*)f_8180},
{"f_9899:expand_2escm",(void*)f_9899},
{"f_9896:expand_2escm",(void*)f_9896},
{"f_8756:expand_2escm",(void*)f_8756},
{"f_10381:expand_2escm",(void*)f_10381},
{"f_9881:expand_2escm",(void*)f_9881},
{"f_9883:expand_2escm",(void*)f_9883},
{"f_7002:expand_2escm",(void*)f_7002},
{"f_10396:expand_2escm",(void*)f_10396},
{"f_8198:expand_2escm",(void*)f_8198},
{"f_8195:expand_2escm",(void*)f_8195},
{"f_8192:expand_2escm",(void*)f_8192},
{"f_8940:expand_2escm",(void*)f_8940},
{"f_7048:expand_2escm",(void*)f_7048},
{"f_7044:expand_2escm",(void*)f_7044},
{"f_7039:expand_2escm",(void*)f_7039},
{"f_7032:expand_2escm",(void*)f_7032},
{"f_8934:expand_2escm",(void*)f_8934},
{"f_4762:expand_2escm",(void*)f_4762},
{"f_4754:expand_2escm",(void*)f_4754},
{"f_4758:expand_2escm",(void*)f_4758},
{"f_10332:expand_2escm",(void*)f_10332},
{"f_5288:expand_2escm",(void*)f_5288},
{"f_10362:expand_2escm",(void*)f_10362},
{"f_5275:expand_2escm",(void*)f_5275},
{"f_8982:expand_2escm",(void*)f_8982},
{"f_8988:expand_2escm",(void*)f_8988},
{"f_6620:expand_2escm",(void*)f_6620},
{"f_10311:expand_2escm",(void*)f_10311},
{"f_9305:expand_2escm",(void*)f_9305},
{"f_8979:expand_2escm",(void*)f_8979},
{"f_10342:expand_2escm",(void*)f_10342},
{"f_9688:expand_2escm",(void*)f_9688},
{"f_10373:expand_2escm",(void*)f_10373},
{"f_6606:expand_2escm",(void*)f_6606},
{"f_6603:expand_2escm",(void*)f_6603},
{"f_9691:expand_2escm",(void*)f_9691},
{"f_9664:expand_2escm",(void*)f_9664},
{"f_4146:expand_2escm",(void*)f_4146},
{"f_9667:expand_2escm",(void*)f_9667},
{"f_6660:expand_2escm",(void*)f_6660},
{"f_10351:expand_2escm",(void*)f_10351},
{"f_4481:expand_2escm",(void*)f_4481},
{"f_4494:expand_2escm",(void*)f_4494},
{"f_4499:expand_2escm",(void*)f_4499},
{"f_4167:expand_2escm",(void*)f_4167},
{"f_7843:expand_2escm",(void*)f_7843},
{"f_4488:expand_2escm",(void*)f_4488},
{"f_4986:expand_2escm",(void*)f_4986},
{"f_4461:expand_2escm",(void*)f_4461},
{"f_4150:expand_2escm",(void*)f_4150},
{"f_4477:expand_2escm",(void*)f_4477},
{"f_9370:expand_2escm",(void*)f_9370},
{"f_4187:expand_2escm",(void*)f_4187},
{"f_4972:expand_2escm",(void*)f_4972},
{"f_9387:expand_2escm",(void*)f_9387},
{"f_4464:expand_2escm",(void*)f_4464},
{"f_9380:expand_2escm",(void*)f_9380},
{"f_4457:expand_2escm",(void*)f_4457},
{"f_4455:expand_2escm",(void*)f_4455},
{"f_4990:expand_2escm",(void*)f_4990},
{"f_4194:expand_2escm",(void*)f_4194},
{"f_4191:expand_2escm",(void*)f_4191},
{"f_10321:expand_2escm",(void*)f_10321},
{"f_11117:expand_2escm",(void*)f_11117},
{"f_7027:expand_2escm",(void*)f_7027},
{"f_7017:expand_2escm",(void*)f_7017},
{"f_11162:expand_2escm",(void*)f_11162},
{"f_6403:expand_2escm",(void*)f_6403},
{"f_7083:expand_2escm",(void*)f_7083},
{"f_4900:expand_2escm",(void*)f_4900},
{"f_9997:expand_2escm",(void*)f_9997},
{"f_5451:expand_2escm",(void*)f_5451},
{"f_7075:expand_2escm",(void*)f_7075},
{"f_7071:expand_2escm",(void*)f_7071},
{"f_11792:expand_2escm",(void*)f_11792},
{"f_11799:expand_2escm",(void*)f_11799},
{"f_11143:expand_2escm",(void*)f_11143},
{"f_11140:expand_2escm",(void*)f_11140},
{"f_7062:expand_2escm",(void*)f_7062},
{"f_6294:expand_2escm",(void*)f_6294},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  sprintf		1
S|  foldl		1
S|  ##sys#map		5
S|  for-each		2
S|  map		10
o|eliminated procedure checks: 564 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (zero? fixnum)
o|  1 (cdddr (pair * (pair * pair)))
o|  1 (##sys#check-output-port * * *)
o|  2 (vector-length vector)
o|  8 (eqv? (not float) *)
o|  2 (cadr (pair * pair))
o|  8 (cddr (pair * pair))
o|  1 (cdadr (pair * (pair pair *)))
o|  3 (caar (pair pair *))
o|  1 (>= fixnum fixnum)
o|  2 (length list)
o|  15 (eqv? * (not float))
o|  1 (##sys#call-with-values (procedure () *) *)
o|  2 (cdar (pair pair *))
o|  10 (##sys#check-list (or pair list) *)
o|  1 (set-cdr! pair *)
o|  75 (cdr pair)
o|  1 (set-car! pair *)
o|  58 (car pair)
(o e)|safe calls: 1154 
(o e)|assignments to immediate values: 3 
o|Removed `not' forms: 36 
o|inlining procedure: k3672 
o|inlining procedure: k3672 
o|contracted procedure: "(expand.scm:81) g257258" 
o|inlining procedure: k3689 
o|inlining procedure: k3689 
o|contracted procedure: "(expand.scm:95) g288289" 
o|contracted procedure: "(expand.scm:94) g283284" 
o|contracted procedure: "(expand.scm:93) g279280" 
o|inlining procedure: k3734 
o|inlining procedure: k3734 
o|inlining procedure: k3756 
o|inlining procedure: k3756 
o|inlining procedure: k3778 
o|inlining procedure: k3778 
o|contracted procedure: k3784 
o|inlining procedure: k3787 
o|inlining procedure: k3787 
o|contracted procedure: "(expand.scm:109) g321322" 
o|contracted procedure: "(expand.scm:108) g310311" 
o|inlining procedure: k3793 
o|inlining procedure: k3793 
o|inlining procedure: k3852 
o|inlining procedure: k3852 
o|inlining procedure: k3930 
o|contracted procedure: "(expand.scm:136) g423433" 
o|inlining procedure: k3930 
o|inlining procedure: k3978 
o|contracted procedure: "(expand.scm:130) g381389" 
o|contracted procedure: "(expand.scm:134) g399400" 
o|contracted procedure: "(expand.scm:133) g395396" 
o|inlining procedure: k3978 
o|inlining procedure: k4027 
o|inlining procedure: k4027 
o|contracted procedure: k4073 
o|inlining procedure: k4070 
o|inlining procedure: k4086 
o|inlining procedure: k4086 
o|inlining procedure: k4104 
o|inlining procedure: k4104 
o|contracted procedure: "(expand.scm:144) g460461" 
o|inlining procedure: k4070 
o|inlining procedure: k4155 
o|inlining procedure: k4155 
o|inlining procedure: k4198 
o|inlining procedure: k4198 
o|inlining procedure: k4253 
o|inlining procedure: k4253 
o|removed unused formal parameters: (me2539) 
o|inlining procedure: k4295 
o|inlining procedure: k4295 
o|removed unused parameter to known procedure: me2539 loop537 
o|inlining procedure: k4366 
o|inlining procedure: k4390 
o|inlining procedure: k4390 
o|inlining procedure: k4433 
o|inlining procedure: k4433 
o|inlining procedure: k4366 
o|inlining procedure: k4462 
o|inlining procedure: k4462 
o|contracted procedure: k4482 
o|merged explicitly consed rest parameter: args563595 
o|consed rest parameter at call site: tmp23085 1 
o|contracted procedure: k4539 
o|inlining procedure: k4536 
o|inlining procedure: k4536 
o|inlining procedure: k4577 
o|inlining procedure: k4600 
o|inlining procedure: k4649 
o|inlining procedure: k4649 
o|inlining procedure: k4718 
o|contracted procedure: "(expand.scm:285) g641650" 
o|inlining procedure: k4718 
o|inlining procedure: k4600 
o|inlining procedure: k4763 
o|inlining procedure: k4763 
o|inlining procedure: k4793 
o|contracted procedure: "(expand.scm:290) g691692" 
o|inlining procedure: k4793 
o|inlining procedure: k4811 
o|inlining procedure: k4811 
o|inlining procedure: k4577 
o|inlining procedure: k4859 
o|inlining procedure: k4859 
o|inlining procedure: k4902 
o|inlining procedure: k4928 
o|inlining procedure: k4928 
o|substituted constant variable: a4935 
o|substituted constant variable: a4937 
o|substituted constant variable: a4939 
o|inlining procedure: k4902 
o|inlining procedure: k4974 
o|inlining procedure: k4991 
o|inlining procedure: k4991 
o|substituted constant variable: %let773 
o|inlining procedure: k5034 
o|inlining procedure: k5034 
o|inlining procedure: k5087 
o|inlining procedure: k5087 
o|contracted procedure: k5090 
o|contracted procedure: k5096 
o|inlining procedure: k5099 
o|inlining procedure: k5099 
o|inlining procedure: k5159 
o|substituted constant variable: %lambda770 
o|inlining procedure: k5159 
o|contracted procedure: "(expand.scm:366) ->keyword764" 
o|inlining procedure: k5197 
o|inlining procedure: k5197 
o|inlining procedure: k4974 
o|inlining procedure: k5244 
o|inlining procedure: k5244 
o|contracted procedure: k5264 
o|inlining procedure: k5261 
o|inlining procedure: k5289 
o|inlining procedure: k5289 
o|inlining procedure: k5305 
o|inlining procedure: k5317 
o|contracted procedure: k5335 
o|inlining procedure: k5317 
o|inlining procedure: k5305 
o|inlining procedure: k5365 
o|inlining procedure: k5365 
o|contracted procedure: k5377 
o|inlining procedure: k5384 
o|inlining procedure: k5403 
o|inlining procedure: k5403 
o|substituted constant variable: a5441 
o|substituted constant variable: a5443 
o|substituted constant variable: a5445 
o|inlining procedure: k5384 
o|inlining procedure: k5452 
o|inlining procedure: k5452 
o|inlining procedure: k5474 
o|inlining procedure: k5474 
o|substituted constant variable: a5491 
o|substituted constant variable: a5493 
o|substituted constant variable: a5495 
o|inlining procedure: k5502 
o|inlining procedure: k5502 
o|substituted constant variable: a5518 
o|substituted constant variable: a5520 
o|substituted constant variable: a5522 
o|contracted procedure: k5529 
o|inlining procedure: k5526 
o|inlining procedure: k5526 
o|inlining procedure: k5261 
o|inlining procedure: k5606 
o|inlining procedure: k5606 
o|inlining procedure: k5628 
o|contracted procedure: "(expand.scm:457) g933943" 
o|inlining procedure: k5628 
o|contracted procedure: k5673 
o|inlining procedure: k5694 
o|inlining procedure: k5694 
o|inlining procedure: k5752 
o|inlining procedure: k5752 
o|inlining procedure: k5761 
o|inlining procedure: k5761 
o|inlining procedure: k5770 
o|inlining procedure: k5770 
o|inlining procedure: k5791 
o|inlining procedure: k5791 
o|substituted constant variable: a5804 
o|substituted constant variable: a5806 
o|substituted constant variable: a5808 
o|inlining procedure: k5812 
o|contracted procedure: k5827 
o|inlining procedure: k5824 
o|inlining procedure: k5874 
o|inlining procedure: k5874 
o|inlining procedure: k5824 
o|inlining procedure: k5812 
o|inlining procedure: k5962 
o|contracted procedure: "(expand.scm:508) g10801091" 
o|inlining procedure: k5934 
o|inlining procedure: k5934 
o|inlining procedure: k5962 
o|inlining procedure: k6012 
o|inlining procedure: k6012 
o|inlining procedure: k6024 
o|contracted procedure: "(expand.scm:500) g10321041" 
o|inlining procedure: k6024 
o|inlining procedure: k6058 
o|contracted procedure: "(expand.scm:503) g10561057" 
o|inlining procedure: k6058 
o|substituted constant variable: g10481051 
o|inlining procedure: k6110 
o|inlining procedure: k6137 
o|inlining procedure: k6137 
o|inlining procedure: k6110 
o|contracted procedure: k6171 
o|inlining procedure: k6177 
o|inlining procedure: k6194 
o|inlining procedure: k6194 
o|inlining procedure: k6177 
o|inlining procedure: k6250 
o|inlining procedure: k6250 
o|substituted constant variable: a6272 
o|contracted procedure: k6299 
o|inlining procedure: k6296 
o|contracted procedure: k6318 
o|inlining procedure: k6324 
o|contracted procedure: k6345 
o|inlining procedure: k6342 
o|inlining procedure: k6342 
o|inlining procedure: k6370 
o|inlining procedure: k6370 
o|inlining procedure: k6324 
o|inlining procedure: k6473 
o|inlining procedure: k6473 
o|inlining procedure: k6522 
o|inlining procedure: k6522 
o|inlining procedure: k6558 
o|inlining procedure: k6558 
o|inlining procedure: k6296 
o|contracted procedure: k6611 
o|inlining procedure: k6608 
o|inlining procedure: k6655 
o|inlining procedure: k6655 
o|inlining procedure: k6608 
o|inlining procedure: k6632 
o|inlining procedure: k6632 
o|inlining procedure: k6678 
o|inlining procedure: k6678 
o|inlining procedure: k6690 
o|inlining procedure: k6690 
o|inlining procedure: k6807 
o|inlining procedure: k6807 
o|inlining procedure: k6838 
o|inlining procedure: k6838 
o|inlining procedure: k6900 
o|inlining procedure: k6900 
o|inlining procedure: k6935 
o|inlining procedure: k6935 
o|contracted procedure: "(expand.scm:676) syntax-imports1262" 
o|inlining procedure: k6769 
o|inlining procedure: k6769 
o|inlining procedure: k6980 
o|inlining procedure: k6990 
o|inlining procedure: k7007 
o|inlining procedure: k7007 
o|inlining procedure: k6990 
o|inlining procedure: k6980 
o|inlining procedure: k7034 
o|inlining procedure: k7034 
o|inlining procedure: k7053 
o|inlining procedure: k7053 
o|propagated global variable: sexp1353 ##sys#syntax-error-culprit 
o|inlining procedure: k7076 
o|inlining procedure: k7076 
o|inlining procedure: k7088 
o|inlining procedure: k7088 
o|inlining procedure: k7104 
o|contracted procedure: k7120 
o|inlining procedure: k7117 
o|inlining procedure: k7117 
o|inlining procedure: k7104 
o|inlining procedure: k7144 
o|inlining procedure: k7144 
o|inlining procedure: k7167 
o|inlining procedure: k7191 
o|inlining procedure: k7191 
o|contracted procedure: k7229 
o|inlining procedure: k7226 
o|inlining procedure: k7226 
o|inlining procedure: k7249 
o|inlining procedure: k7249 
o|inlining procedure: k7167 
o|contracted procedure: k7273 
o|inlining procedure: k7270 
o|inlining procedure: k7270 
o|inlining procedure: k7283 
o|inlining procedure: k7295 
o|inlining procedure: k7295 
o|inlining procedure: k7313 
o|inlining procedure: k7313 
o|inlining procedure: k7331 
o|inlining procedure: k7331 
o|inlining procedure: k7349 
o|inlining procedure: k7349 
o|inlining procedure: k7371 
o|inlining procedure: k7371 
o|substituted constant variable: a7384 
o|substituted constant variable: a7386 
o|substituted constant variable: a7388 
o|substituted constant variable: a7390 
o|substituted constant variable: a7392 
o|substituted constant variable: a7394 
o|substituted constant variable: a7396 
o|substituted constant variable: a7398 
o|inlining procedure: k7283 
o|contracted procedure: k7402 
o|contracted procedure: k7411 
o|inlining procedure: k7408 
o|inlining procedure: k7408 
o|inlining procedure: k7489 
o|inlining procedure: k7489 
o|contracted procedure: k7530 
o|inlining procedure: k7527 
o|contracted procedure: "(expand.scm:803) g14451446" 
o|inlining procedure: k7558 
o|contracted procedure: "(expand.scm:823) g14701471" 
o|contracted procedure: "(expand.scm:822) g14661467" 
o|inlining procedure: k7558 
o|inlining procedure: k7553 
o|inlining procedure: k7553 
o|inlining procedure: k7527 
o|inlining procedure: k7643 
o|inlining procedure: k7658 
o|inlining procedure: k7658 
o|inlining procedure: k7643 
o|inlining procedure: k7681 
o|inlining procedure: k7702 
o|inlining procedure: k7702 
o|inlining procedure: k7681 
o|inlining procedure: k7739 
o|inlining procedure: k7767 
o|inlining procedure: k7791 
o|inlining procedure: k7791 
o|contracted procedure: "(expand.scm:864) g15551556" 
o|contracted procedure: "(expand.scm:863) g15481549" 
o|inlining procedure: k7767 
o|inlining procedure: k7816 
o|inlining procedure: k7816 
o|inlining procedure: k7850 
o|inlining procedure: k7850 
o|removed unused parameter to known procedure: n1575 "(expand.scm:859) lookup21435" 
o|contracted procedure: "(expand.scm:858) g15291530" 
o|inlining procedure: k7856 
o|inlining procedure: k7856 
o|removed unused parameter to known procedure: n1575 "(expand.scm:856) lookup21435" 
o|contracted procedure: "(expand.scm:855) g15191520" 
o|inlining procedure: k7739 
o|removed unused formal parameters: (n1575) 
o|inlining procedure: k7880 
o|inlining procedure: k7880 
o|inlining procedure: k7905 
o|inlining procedure: k7905 
o|contracted procedure: k7946 
o|inlining procedure: k7943 
o|contracted procedure: "(expand.scm:896) g16001601" 
o|contracted procedure: k7972 
o|inlining procedure: k7969 
o|inlining procedure: k7998 
o|contracted procedure: "(expand.scm:896) g16171618" 
o|inlining procedure: k7998 
o|contracted procedure: "(expand.scm:904) g16131614" 
o|inlining procedure: k7969 
o|inlining procedure: k7943 
o|inlining procedure: k8019 
o|inlining procedure: k8019 
o|inlining procedure: k8101 
o|inlining procedure: k8101 
o|removed side-effect free assignment to unused variable: %vector-length2412 
o|removed side-effect free assignment to unused variable: %vector-ref2413 
o|removed side-effect free assignment to unused variable: %null?2435 
o|removed side-effect free assignment to unused variable: %or2436 
o|removed side-effect free assignment to unused variable: %syntax-error2442 
o|inlining procedure: k8386 
o|inlining procedure: k8386 
o|inlining procedure: k8428 
o|inlining procedure: k8428 
o|inlining procedure: k8476 
o|inlining procedure: k8476 
o|inlining procedure: k8494 
o|inlining procedure: k8494 
o|inlining procedure: k8530 
o|inlining procedure: k8530 
o|inlining procedure: k8632 
o|inlining procedure: k8632 
o|inlining procedure: k8666 
o|inlining procedure: k8666 
o|inlining procedure: k8802 
o|inlining procedure: k8802 
o|inlining procedure: k8865 
o|inlining procedure: k8865 
o|inlining procedure: k8893 
o|inlining procedure: k8893 
o|inlining procedure: k8942 
o|inlining procedure: k8954 
o|inlining procedure: k8954 
o|inlining procedure: k8942 
o|inlining procedure: k8989 
o|inlining procedure: k8989 
o|substituted constant variable: %append2405 
o|inlining procedure: k9031 
o|inlining procedure: k9031 
o|substituted constant variable: %apply2406 
o|substituted constant variable: %append2405 
o|inlining procedure: k9065 
o|inlining procedure: k9065 
o|inlining procedure: k9090 
o|inlining procedure: k9090 
o|inlining procedure: k9134 
o|inlining procedure: k9134 
o|inlining procedure: k9178 
o|inlining procedure: k9178 
o|inlining procedure: k9211 
o|contracted procedure: k9226 
o|inlining procedure: k9232 
o|inlining procedure: k9232 
o|inlining procedure: k9211 
o|inlining procedure: k9267 
o|inlining procedure: k9267 
o|inlining procedure: k9300 
o|contracted procedure: k9315 
o|inlining procedure: k9312 
o|inlining procedure: k9312 
o|inlining procedure: k9300 
o|inlining procedure: k9328 
o|inlining procedure: k9328 
o|inlining procedure: k9352 
o|inlining procedure: k9352 
o|inlining procedure: k9382 
o|inlining procedure: k9382 
o|inlining procedure: k9425 
o|inlining procedure: k9425 
o|inlining procedure: k9467 
o|inlining procedure: k9479 
o|inlining procedure: k9479 
o|inlining procedure: k9467 
o|inlining procedure: k9508 
o|inlining procedure: k9508 
o|inlining procedure: k9602 
o|inlining procedure: k9602 
o|inlining procedure: k9659 
o|inlining procedure: k9680 
o|inlining procedure: k9680 
o|inlining procedure: k9659 
o|inlining procedure: k9768 
o|inlining procedure: k9768 
o|inlining procedure: k9788 
o|inlining procedure: k9788 
o|inlining procedure: k9913 
o|inlining procedure: k9913 
o|contracted procedure: k9929 
o|inlining procedure: k9939 
o|inlining procedure: k9951 
o|inlining procedure: k9951 
o|inlining procedure: k9939 
o|contracted procedure: k9986 
o|inlining procedure: k9983 
o|inlining procedure: k9983 
o|inlining procedure: k9998 
o|inlining procedure: k9998 
o|inlining procedure: k10019 
o|inlining procedure: k10019 
o|inlining procedure: k10049 
o|inlining procedure: k10076 
o|contracted procedure: "(expand.scm:1407) g22772286" 
o|inlining procedure: k10076 
o|inlining procedure: k10049 
o|contracted procedure: k10110 
o|contracted procedure: k10123 
o|inlining procedure: k10120 
o|inlining procedure: k10139 
o|inlining procedure: k10139 
o|inlining procedure: k10148 
o|inlining procedure: k10148 
o|inlining procedure: k10120 
o|inlining procedure: k10253 
o|inlining procedure: k10253 
o|contracted procedure: k10273 
o|inlining procedure: k10283 
o|inlining procedure: k10283 
o|inlining procedure: k10337 
o|inlining procedure: k10337 
o|inlining procedure: k10419 
o|inlining procedure: k10419 
o|inlining procedure: k10453 
o|inlining procedure: k10453 
o|inlining procedure: k10490 
o|contracted procedure: "(expand.scm:1303) g22062207" 
o|inlining procedure: k10490 
o|inlining procedure: k10630 
o|contracted procedure: "(expand.scm:1293) g21092118" 
o|inlining procedure: k10600 
o|inlining procedure: k10600 
o|inlining procedure: k10630 
o|inlining procedure: k10680 
o|contracted procedure: "(expand.scm:1282) g20752084" 
o|inlining procedure: k10680 
o|inlining procedure: k10732 
o|inlining procedure: k10732 
o|contracted procedure: k10809 
o|inlining procedure: k10806 
o|inlining procedure: k10832 
o|inlining procedure: k10832 
o|inlining procedure: k10944 
o|inlining procedure: k10944 
o|inlining procedure: k10806 
o|contracted procedure: k11015 
o|inlining procedure: k11012 
o|substituted constant variable: a11039 
o|substituted constant variable: a11040 
o|inlining procedure: k11057 
o|inlining procedure: k11084 
o|inlining procedure: k11084 
o|inlining procedure: k11057 
o|inlining procedure: k11135 
o|inlining procedure: k11135 
o|inlining procedure: k11271 
o|inlining procedure: k11271 
o|inlining procedure: k11283 
o|inlining procedure: k11283 
o|inlining procedure: k11295 
o|inlining procedure: k11295 
o|inlining procedure: k11307 
o|inlining procedure: k11307 
o|inlining procedure: k11316 
o|inlining procedure: k11316 
o|inlining procedure: k11012 
o|inlining procedure: k11369 
o|inlining procedure: k11369 
o|inlining procedure: k11421 
o|inlining procedure: k11421 
o|inlining procedure: k11464 
o|inlining procedure: k11464 
o|contracted procedure: k11647 
o|inlining procedure: k11644 
o|inlining procedure: k11644 
o|contracted procedure: "(expand.scm:1032) g17621763" 
o|contracted procedure: k11759 
o|inlining procedure: k11756 
o|inlining procedure: k11756 
o|inlining procedure: k11783 
o|inlining procedure: k11783 
o|contracted procedure: "(expand.scm:1007) g17321733" 
o|propagated global variable: g16791680 ##sys#expand-import 
o|propagated global variable: g16651666 ##sys#expand-import 
o|propagated global variable: g16511652 ##sys#expand-import 
o|replaced variables: 1623 
o|removed binding forms: 489 
o|substituted constant variable: prop260 
o|removed call to pure procedure with unused result: "(expand.scm:96) void" 
o|substituted constant variable: prop291 
o|substituted constant variable: prop286 
o|substituted constant variable: prop282 
o|substituted constant variable: r373511974 
o|substituted constant variable: prop324 
o|substituted constant variable: prop313 
o|substituted constant variable: prop402 
o|inlining procedure: k3900 
o|inlining procedure: k3900 
o|substituted constant variable: prop398 
o|substituted constant variable: prop463 
o|substituted constant variable: r429612003 
o|substituted constant variable: r439112007 
o|substituted constant variable: r443412010 
o|removed call to pure procedure with unused result: "(expand.scm:246) void" 
o|removed call to pure procedure with unused result: "(expand.scm:206) void" 
o|removed call to pure procedure with unused result: "(expand.scm:203) void" 
o|removed call to pure procedure with unused result: "(expand.scm:203) void" 
o|inlining procedure: k4772 
o|substituted constant variable: prop694 
o|substituted constant variable: r479412037 
o|substituted constant variable: r490312048 
o|substituted constant variable: r510012061 
o|substituted constant variable: r516012064 
o|substituted constant variable: r516012064 
o|substituted constant variable: r550312089 
o|substituted constant variable: r552712090 
o|converted assignments to bindings: (err763) 
o|substituted constant variable: r560712093 
o|substituted constant variable: r560712093 
o|inlining procedure: k5606 
o|substituted constant variable: r587512112 
o|removed call to pure procedure with unused result: "(expand.scm:498) void" 
o|substituted constant variable: r601312120 
o|inlining procedure: k6194 
o|substituted constant variable: r625112136 
o|substituted constant variable: r637112143 
o|substituted constant variable: r637112143 
o|substituted constant variable: r655912151 
o|substituted constant variable: r665612155 
o|substituted constant variable: r663312157 
o|substituted constant variable: r667912160 
o|substituted constant variable: r693612169 
o|substituted constant variable: r677012171 
o|converted assignments to bindings: (outstr1275) 
o|substituted constant variable: r700812176 
o|substituted constant variable: r699112177 
o|substituted constant variable: r698112178 
o|substituted constant variable: r711812190 
o|substituted constant variable: r710512192 
o|substituted constant variable: r725012201 
o|removed call to pure procedure with unused result: "(expand.scm:813) void" 
o|removed call to pure procedure with unused result: "(expand.scm:824) void" 
o|removed call to pure procedure with unused result: "(expand.scm:828) void" 
o|substituted constant variable: prop1473 
o|substituted constant variable: prop1469 
o|removed call to pure procedure with unused result: "(expand.scm:832) void" 
o|removed call to pure procedure with unused result: "(expand.scm:837) void" 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|inlining procedure: k7643 
o|substituted constant variable: r765912236 
o|inlining procedure: k7643 
o|inlining procedure: k7643 
o|inlining procedure: k7643 
o|substituted constant variable: r768212246 
o|substituted constant variable: prop1558 
o|substituted constant variable: prop1551 
o|inlining procedure: k7643 
o|inlining procedure: k7643 
o|substituted constant variable: prop1532 
o|substituted constant variable: prop1522 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|substituted constant variable: r788112261 
o|removed call to pure procedure with unused result: "(expand.scm:898) void" 
o|removed call to pure procedure with unused result: "(expand.scm:903) void" 
o|removed call to pure procedure with unused result: "(expand.scm:905) void" 
o|removed call to pure procedure with unused result: "(expand.scm:910) void" 
o|substituted constant variable: prop1616 
o|removed call to pure procedure with unused result: "(expand.scm:901) void" 
o|removed side-effect free assignment to unused variable: %append2405 
o|removed side-effect free assignment to unused variable: %apply2406 
o|substituted constant variable: r847712280 
o|substituted constant variable: r906612306 
o|substituted constant variable: r923312315 
o|substituted constant variable: r931312320 
o|substituted constant variable: r930112322 
o|substituted constant variable: r932912324 
o|substituted constant variable: r935312326 
o|substituted constant variable: r942612329 
o|substituted constant variable: r968112345 
o|substituted constant variable: r978912352 
o|substituted constant variable: r998412359 
o|substituted constant variable: r1014012370 
o|substituted constant variable: r1080712400 
o|substituted constant variable: r1131712417 
o|substituted constant variable: r1101312418 
o|substituted constant variable: r1137012419 
o|substituted constant variable: r1142212421 
o|substituted constant variable: prop1765 
o|substituted constant variable: r1178412431 
o|substituted constant variable: r1178412431 
o|substituted constant variable: prop1735 
o|simplifications: ((let . 2)) 
o|replaced variables: 68 
o|removed binding forms: 1516 
o|inlining procedure: k3680 
o|contracted procedure: k3725 
o|substituted constant variable: prop40212447 
o|substituted constant variable: prop40212453 
o|contracted procedure: k4335 
o|contracted procedure: k4338 
o|contracted procedure: k4465 
o|removed call to pure procedure with unused result: "(expand.scm:246) void" 
o|contracted procedure: k4533 
o|inlining procedure: k5253 
o|inlining procedure: k5253 
o|contracted procedure: k5896 
o|contracted procedure: k7541 
o|contracted procedure: k7578 
o|contracted procedure: k7589 
o|contracted procedure: k7608 
o|contracted procedure: k7625 
o|contracted procedure: k7646 
o|substituted constant variable: r764412568 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|substituted constant variable: r764412573 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|substituted constant variable: r764412582 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|substituted constant variable: r764412587 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|substituted constant variable: r764412592 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|substituted constant variable: r764412597 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|contracted procedure: k7874 
o|contracted procedure: k7960 
o|contracted procedure: k7987 
o|contracted procedure: k8003 
o|contracted procedure: k8012 
o|contracted procedure: k7975 
o|inlining procedure: k9220 
o|inlining procedure: k9220 
o|inlining procedure: k9568 
o|inlining procedure: k9568 
o|replaced variables: 49 
o|removed binding forms: 166 
o|contracted procedure: k3709 
o|contracted procedure: k3717 
o|contracted procedure: k3722 
o|contracted procedure: k3770 
o|contracted procedure: k3775 
o|contracted procedure: k3891 
o|contracted procedure: k4078 
o|contracted procedure: k446512024 
o|substituted constant variable: r560712507 
o|contracted procedure: k7569 
o|contracted procedure: k764612572 
o|substituted constant variable: result149512569 
o|contracted procedure: k764612577 
o|substituted constant variable: result149512574 
o|contracted procedure: k764612586 
o|substituted constant variable: result149512583 
o|contracted procedure: k764612591 
o|substituted constant variable: result149512588 
o|contracted procedure: k7747 
o|contracted procedure: k7755 
o|contracted procedure: k7779 
o|contracted procedure: k7788 
o|contracted procedure: k764612596 
o|substituted constant variable: result149512593 
o|contracted procedure: k764612601 
o|substituted constant variable: result149512598 
o|inlining procedure: "(expand.scm:859) lookup21435" 
o|inlining procedure: "(expand.scm:856) lookup21435" 
o|contracted procedure: k7995 
o|substituted constant variable: r922112729 
o|substituted constant variable: r922112730 
o|contracted procedure: k11658 
o|contracted procedure: k11767 
o|replaced variables: 4 
o|removed binding forms: 104 
o|removed conditional forms: 2 
o|removed side-effect free assignment to unused variable: lookup21435 
o|replaced variables: 15 
o|removed binding forms: 21 
o|replaced variables: 10 
o|removed binding forms: 13 
o|inlining procedure: k3712 
o|inlining procedure: k3712 
o|replaced variables: 2 
o|removed binding forms: 3 
o|replaced variables: 1 
o|removed binding forms: 3 
o|replaced variables: 4 
o|removed binding forms: 1 
o|removed binding forms: 3 
o|simplifications: ((if . 48) (##core#call . 1024)) 
o|  call simplifications:
o|    number?
o|    eof-object?
o|    fx-	2
o|    cdddr
o|    cadddr	2
o|    cddddr
o|    >=
o|    +	3
o|    =
o|    -
o|    <=
o|    boolean?
o|    char?	2
o|    cdar	2
o|    ##sys#immediate?
o|    vector-ref	5
o|    fx<	2
o|    not	4
o|    fx=	7
o|    memq	7
o|    member
o|    caddr	12
o|    length	11
o|    fx<=	2
o|    ##sys#call-with-values
o|    cddr	10
o|    ##sys#list	163
o|    ##sys#cons	87
o|    list?	5
o|    cadr	36
o|    values	8
o|    ##sys#apply	2
o|    memv
o|    equal?	2
o|    string?	3
o|    ##sys#make-structure	2
o|    apply	2
o|    list	16
o|    set-car!	4
o|    procedure?
o|    ##sys#structure?	2
o|    caar	9
o|    eq?	74
o|    null?	51
o|    car	66
o|    ##sys#check-list	13
o|    assq	12
o|    symbol?	42
o|    vector?	13
o|    fx>=	5
o|    fx+	4
o|    cons	82
o|    ##sys#setslot	18
o|    pair?	87
o|    ##sys#slot	71
o|    ##sys#size	5
o|    fx>	5
o|    char=?
o|    cdr	49
o|contracted procedure: k3704 
o|contracted procedure: k3728 
o|contracted procedure: k3731 
o|contracted procedure: k3737 
o|contracted procedure: k3753 
o|contracted procedure: k3765 
o|contracted procedure: k3790 
o|contracted procedure: k3796 
o|contracted procedure: k3799 
o|contracted procedure: k3827 
o|contracted procedure: k3803 
o|contracted procedure: k3806 
o|contracted procedure: k3809 
o|contracted procedure: k3833 
o|contracted procedure: k3836 
o|contracted procedure: k3877 
o|contracted procedure: k3843 
o|contracted procedure: k3855 
o|contracted procedure: k3858 
o|contracted procedure: k3865 
o|contracted procedure: k3873 
o|contracted procedure: k3903 
o|contracted procedure: k3906 
o|contracted procedure: k3916 
o|contracted procedure: k3969 
o|contracted procedure: k3933 
o|contracted procedure: k3959 
o|contracted procedure: k3963 
o|contracted procedure: k3955 
o|contracted procedure: k3936 
o|contracted procedure: k3939 
o|contracted procedure: k3947 
o|contracted procedure: k3951 
o|contracted procedure: k4006 
o|contracted procedure: k3981 
o|contracted procedure: k3999 
o|contracted procedure: k4003 
o|contracted procedure: k3984 
o|contracted procedure: k3991 
o|contracted procedure: k3995 
o|contracted procedure: k4012 
o|contracted procedure: k4015 
o|contracted procedure: k4018 
o|contracted procedure: k4030 
o|contracted procedure: k4033 
o|contracted procedure: k4036 
o|contracted procedure: k4044 
o|contracted procedure: k4052 
o|contracted procedure: k4140 
o|contracted procedure: k4089 
o|contracted procedure: k4107 
o|contracted procedure: k4136 
o|contracted procedure: k4126 
o|contracted procedure: k4180 
o|contracted procedure: k4152 
o|contracted procedure: k4158 
o|contracted procedure: k4171 
o|contracted procedure: k4203 
o|contracted procedure: k4206 
o|contracted procedure: k4214 
o|contracted procedure: k4225 
o|contracted procedure: k4221 
o|contracted procedure: k4250 
o|contracted procedure: k4269 
o|contracted procedure: k4298 
o|contracted procedure: k4320 
o|contracted procedure: k4304 
o|contracted procedure: k4376 
o|contracted procedure: k4366 
o|contracted procedure: k4384 
o|contracted procedure: k4393 
o|contracted procedure: k4396 
o|contracted procedure: k4410 
o|contracted procedure: k4420 
o|contracted procedure: k4424 
o|contracted procedure: k4430 
o|contracted procedure: k4436 
o|contracted procedure: k4444 
o|contracted procedure: k4451 
o|contracted procedure: k4468 
o|contracted procedure: k4568 
o|contracted procedure: k4548 
o|contracted procedure: k4559 
o|contracted procedure: k4580 
o|contracted procedure: k4588 
o|contracted procedure: k4594 
o|contracted procedure: k4603 
o|contracted procedure: k4609 
o|contracted procedure: k4615 
o|contracted procedure: k4621 
o|contracted procedure: k4697 
o|contracted procedure: k4705 
o|contracted procedure: k4712 
o|contracted procedure: k4693 
o|contracted procedure: k4689 
o|contracted procedure: k4685 
o|contracted procedure: k4681 
o|contracted procedure: k4636 
o|contracted procedure: k4640 
o|contracted procedure: k4632 
o|contracted procedure: k4628 
o|contracted procedure: k4652 
o|contracted procedure: k4674 
o|contracted procedure: k4670 
o|contracted procedure: k4655 
o|contracted procedure: k4658 
o|contracted procedure: k4666 
o|contracted procedure: k4721 
o|contracted procedure: k4743 
o|contracted procedure: k4739 
o|contracted procedure: k4724 
o|contracted procedure: k4727 
o|contracted procedure: k4735 
o|contracted procedure: k4766 
o|contracted procedure: k4782 
o|contracted procedure: k4796 
o|contracted procedure: k4804 
o|contracted procedure: k4877 
o|contracted procedure: k4832 
o|contracted procedure: k4871 
o|contracted procedure: k4835 
o|contracted procedure: k4865 
o|contracted procedure: k4838 
o|contracted procedure: k4883 
o|contracted procedure: k4905 
o|contracted procedure: k4908 
o|contracted procedure: k4914 
o|contracted procedure: k4925 
o|contracted procedure: k4977 
o|contracted procedure: k4994 
o|contracted procedure: k5023 
o|contracted procedure: k5027 
o|contracted procedure: k5019 
o|contracted procedure: k5015 
o|contracted procedure: k5011 
o|contracted procedure: k5007 
o|inlining procedure: k4991 
o|contracted procedure: k5037 
o|contracted procedure: k5052 
o|contracted procedure: k5048 
o|contracted procedure: k5044 
o|inlining procedure: k4991 
o|contracted procedure: k5071 
o|contracted procedure: k5067 
o|contracted procedure: k5063 
o|inlining procedure: k4991 
o|inlining procedure: k5083 
o|inlining procedure: k5083 
o|contracted procedure: k5102 
o|contracted procedure: k5109 
o|contracted procedure: k5112 
o|contracted procedure: k5127 
o|contracted procedure: k5132 
o|contracted procedure: k5147 
o|contracted procedure: k5143 
o|contracted procedure: k5139 
o|contracted procedure: k5155 
o|contracted procedure: k5162 
o|contracted procedure: k5173 
o|contracted procedure: k5169 
o|contracted procedure: k5159 
o|contracted procedure: k4956 
o|contracted procedure: k5123 
o|contracted procedure: k5119 
o|contracted procedure: k5200 
o|contracted procedure: k5203 
o|contracted procedure: k5206 
o|contracted procedure: k5214 
o|contracted procedure: k5222 
o|contracted procedure: k5241 
o|contracted procedure: k5247 
o|contracted procedure: k5540 
o|contracted procedure: k5270 
o|contracted procedure: k5276 
o|contracted procedure: k5283 
o|contracted procedure: k5292 
o|contracted procedure: k5308 
o|contracted procedure: k5314 
o|contracted procedure: k5327 
o|contracted procedure: k5339 
o|contracted procedure: k5345 
o|contracted procedure: k5359 
o|contracted procedure: k5368 
o|contracted procedure: k5387 
o|contracted procedure: k5393 
o|contracted procedure: k5400 
o|contracted procedure: k5406 
o|contracted procedure: k5417 
o|contracted procedure: k5413 
o|contracted procedure: k5423 
o|contracted procedure: k5437 
o|contracted procedure: k5433 
o|contracted procedure: k5455 
o|contracted procedure: k5464 
o|contracted procedure: k5471 
o|contracted procedure: k5477 
o|contracted procedure: k5487 
o|contracted procedure: k5499 
o|contracted procedure: k5505 
o|contracted procedure: k5512 
o|contracted procedure: k5523 
o|contracted procedure: k5536 
o|contracted procedure: k5568 
o|contracted procedure: k5576 
o|contracted procedure: k5572 
o|contracted procedure: k5588 
o|contracted procedure: k5596 
o|contracted procedure: k5599 
o|contracted procedure: k5609 
o|contracted procedure: k5615 
o|contracted procedure: k5622 
o|contracted procedure: k5606 
o|contracted procedure: k5667 
o|contracted procedure: k5631 
o|contracted procedure: k5657 
o|contracted procedure: k5661 
o|contracted procedure: k5653 
o|contracted procedure: k5634 
o|contracted procedure: k5637 
o|contracted procedure: k5645 
o|contracted procedure: k5649 
o|contracted procedure: k5679 
o|contracted procedure: k5682 
o|contracted procedure: k5685 
o|contracted procedure: k5697 
o|contracted procedure: k5700 
o|contracted procedure: k5703 
o|contracted procedure: k5711 
o|contracted procedure: k5719 
o|contracted procedure: k6587 
o|contracted procedure: k5734 
o|contracted procedure: k6581 
o|contracted procedure: k5737 
o|contracted procedure: k6575 
o|contracted procedure: k5740 
o|contracted procedure: k5749 
o|contracted procedure: k5758 
o|contracted procedure: k5773 
o|contracted procedure: k5788 
o|contracted procedure: k6091 
o|contracted procedure: k5815 
o|contracted procedure: k5890 
o|contracted procedure: k5833 
o|contracted procedure: k5854 
o|contracted procedure: k5867 
o|contracted procedure: k5870 
o|contracted procedure: k5877 
o|contracted procedure: k5904 
o|contracted procedure: k5918 
o|contracted procedure: k5900 
o|contracted procedure: k5929 
o|contracted procedure: k5968 
o|contracted procedure: k5971 
o|contracted procedure: k5979 
o|contracted procedure: k5983 
o|contracted procedure: k5987 
o|contracted procedure: k5995 
o|contracted procedure: k5999 
o|contracted procedure: k6003 
o|contracted procedure: k5944 
o|contracted procedure: k6009 
o|contracted procedure: k6015 
o|contracted procedure: k6027 
o|contracted procedure: k6049 
o|contracted procedure: k6045 
o|contracted procedure: k6030 
o|contracted procedure: k6033 
o|contracted procedure: k6041 
o|contracted procedure: k6061 
o|contracted procedure: k6068 
o|contracted procedure: k6088 
o|contracted procedure: k6125 
o|contracted procedure: k6121 
o|contracted procedure: k6117 
o|contracted procedure: k6140 
o|contracted procedure: k6162 
o|contracted procedure: k6158 
o|contracted procedure: k6143 
o|contracted procedure: k6146 
o|contracted procedure: k6154 
o|contracted procedure: k6284 
o|inlining procedure: k6190 
o|contracted procedure: k6241 
o|contracted procedure: k6197 
o|contracted procedure: k6216 
o|contracted procedure: k6212 
o|contracted procedure: k6208 
o|contracted procedure: k6229 
o|inlining procedure: k6190 
o|contracted procedure: k6280 
o|contracted procedure: k6247 
o|contracted procedure: k6274 
o|contracted procedure: k6253 
o|contracted procedure: k6269 
o|contracted procedure: k6259 
o|contracted procedure: k6569 
o|contracted procedure: k6305 
o|contracted procedure: k6564 
o|contracted procedure: k6309 
o|contracted procedure: k6555 
o|contracted procedure: k6339 
o|contracted procedure: k6458 
o|contracted procedure: k6454 
o|contracted procedure: k6398 
o|contracted procedure: k6412 
o|contracted procedure: k6448 
o|contracted procedure: k6422 
o|contracted procedure: k6444 
o|contracted procedure: k6438 
o|contracted procedure: k6434 
o|contracted procedure: k6426 
o|contracted procedure: k6430 
o|contracted procedure: k6384 
o|contracted procedure: k6358 
o|contracted procedure: k6366 
o|contracted procedure: k6380 
o|contracted procedure: k6373 
o|contracted procedure: k6370 
o|contracted procedure: k6387 
o|contracted procedure: k6502 
o|contracted procedure: k6486 
o|contracted procedure: k6498 
o|contracted procedure: k6490 
o|contracted procedure: k6494 
o|contracted procedure: k6519 
o|contracted procedure: k6551 
o|contracted procedure: k6525 
o|contracted procedure: k6537 
o|contracted procedure: k6547 
o|contracted procedure: k6561 
o|contracted procedure: k6593 
o|contracted procedure: k6675 
o|contracted procedure: k6652 
o|contracted procedure: k6671 
o|contracted procedure: k6614 
o|contracted procedure: k6626 
o|contracted procedure: k6635 
o|contracted procedure: k6643 
o|contracted procedure: k6639 
o|contracted procedure: k6727 
o|contracted procedure: k6693 
o|contracted procedure: k6702 
o|contracted procedure: k6721 
o|contracted procedure: k6717 
o|contracted procedure: k6713 
o|contracted procedure: k6810 
o|contracted procedure: k6841 
o|contracted procedure: k6867 
o|contracted procedure: k6879 
o|contracted procedure: k6959 
o|contracted procedure: k6903 
o|contracted procedure: k6918 
o|contracted procedure: k6938 
o|contracted procedure: k6955 
o|contracted procedure: k6763 
o|contracted procedure: k6772 
o|contracted procedure: k6800 
o|contracted procedure: k6778 
o|contracted procedure: k6968 
o|contracted procedure: k6986 
o|contracted procedure: k6993 
o|contracted procedure: k7004 
o|contracted procedure: k7465 
o|contracted procedure: k7019 
o|contracted procedure: k7459 
o|contracted procedure: k7022 
o|contracted procedure: k7444 
o|contracted procedure: k7028 
o|contracted procedure: k7085 
o|contracted procedure: k7094 
o|contracted procedure: k7107 
o|contracted procedure: k7114 
o|contracted procedure: k7141 
o|contracted procedure: k7150 
o|contracted procedure: k7170 
o|contracted procedure: k7173 
o|contracted procedure: k7176 
o|contracted procedure: k7258 
o|contracted procedure: k7179 
o|contracted procedure: k7194 
o|contracted procedure: k7200 
o|contracted procedure: k7213 
o|contracted procedure: k7217 
o|contracted procedure: k7220 
o|contracted procedure: k7243 
o|contracted procedure: k7239 
o|contracted procedure: k7246 
o|contracted procedure: k7252 
o|contracted procedure: k7267 
o|contracted procedure: k7280 
o|contracted procedure: k7286 
o|contracted procedure: k7292 
o|contracted procedure: k7298 
o|contracted procedure: k7307 
o|contracted procedure: k7316 
o|contracted procedure: k7325 
o|contracted procedure: k7334 
o|contracted procedure: k7343 
o|contracted procedure: k7352 
o|contracted procedure: k7374 
o|contracted procedure: k7377 
o|contracted procedure: k7440 
o|contracted procedure: k7436 
o|contracted procedure: k7428 
o|contracted procedure: k7432 
o|contracted procedure: k7450 
o|contracted procedure: k7480 
o|contracted procedure: k7492 
o|contracted procedure: k7513 
o|contracted procedure: k7637 
o|contracted procedure: k7533 
o|contracted procedure: k7561 
o|contracted procedure: k7586 
o|contracted procedure: k7582 
o|contracted procedure: k7597 
o|contracted procedure: k7593 
o|contracted procedure: k7616 
o|contracted procedure: k7612 
o|contracted procedure: k7633 
o|contracted procedure: k7629 
o|contracted procedure: k7649 
o|contracted procedure: k7655 
o|contracted procedure: k7678 
o|contracted procedure: k7684 
o|contracted procedure: k7687 
o|contracted procedure: k7734 
o|contracted procedure: k7693 
o|contracted procedure: k7705 
o|contracted procedure: k7708 
o|contracted procedure: k7715 
o|contracted procedure: k7723 
o|contracted procedure: k7727 
o|contracted procedure: k7862 
o|contracted procedure: k7742 
o|contracted procedure: k7764 
o|contracted procedure: k7770 
o|contracted procedure: k7782 
o|contracted procedure: k7794 
o|contracted procedure: k7806 
o|contracted procedure: k7819 
o|contracted procedure: k7822 
o|contracted procedure: k7834 
o|contracted procedure: k7883 
o|contracted procedure: k7899 
o|contracted procedure: k7889 
o|contracted procedure: k7908 
o|contracted procedure: k7929 
o|contracted procedure: k8016 
o|contracted procedure: k7984 
o|contracted procedure: k8098 
o|contracted procedure: k8123 
o|contracted procedure: k8119 
o|contracted procedure: k8143 
o|contracted procedure: k8139 
o|contracted procedure: k8160 
o|contracted procedure: k8146 
o|contracted procedure: k8153 
o|contracted procedure: k8342 
o|contracted procedure: k8422 
o|contracted procedure: k8418 
o|contracted procedure: k8350 
o|contracted procedure: k8354 
o|contracted procedure: k8346 
o|contracted procedure: k8338 
o|contracted procedure: k8362 
o|contracted procedure: k8365 
o|contracted procedure: k8380 
o|contracted procedure: k8376 
o|contracted procedure: k8372 
o|contracted procedure: k8389 
o|contracted procedure: k8392 
o|contracted procedure: k8395 
o|contracted procedure: k8403 
o|contracted procedure: k8411 
o|contracted procedure: k8434 
o|contracted procedure: k8437 
o|contracted procedure: k8444 
o|contracted procedure: k8448 
o|contracted procedure: k8473 
o|contracted procedure: k8479 
o|contracted procedure: k8486 
o|contracted procedure: k8497 
o|contracted procedure: k8503 
o|contracted procedure: k8518 
o|contracted procedure: k8514 
o|contracted procedure: k8510 
o|contracted procedure: k8533 
o|contracted procedure: k8584 
o|contracted procedure: k8544 
o|contracted procedure: k8556 
o|contracted procedure: k8552 
o|contracted procedure: k8548 
o|contracted procedure: k8540 
o|contracted procedure: k8572 
o|contracted procedure: k8578 
o|contracted procedure: k8590 
o|contracted procedure: k8629 
o|contracted procedure: k8601 
o|contracted procedure: k8613 
o|contracted procedure: k8609 
o|contracted procedure: k8605 
o|contracted procedure: k8597 
o|contracted procedure: k8621 
o|contracted procedure: k8635 
o|contracted procedure: k8649 
o|contracted procedure: k8645 
o|contracted procedure: k8660 
o|contracted procedure: k8656 
o|contracted procedure: k8663 
o|contracted procedure: k8686 
o|contracted procedure: k8788 
o|contracted procedure: k8784 
o|contracted procedure: k8694 
o|contracted procedure: k8780 
o|contracted procedure: k8776 
o|contracted procedure: k8702 
o|contracted procedure: k8768 
o|contracted procedure: k8772 
o|contracted procedure: k8710 
o|contracted procedure: k8761 
o|contracted procedure: k8750 
o|contracted procedure: k8718 
o|contracted procedure: k8726 
o|contracted procedure: k8722 
o|contracted procedure: k8714 
o|contracted procedure: k8706 
o|contracted procedure: k8698 
o|contracted procedure: k8690 
o|contracted procedure: k8682 
o|contracted procedure: k8742 
o|contracted procedure: k8746 
o|contracted procedure: k8738 
o|contracted procedure: k8734 
o|contracted procedure: k8792 
o|contracted procedure: k8796 
o|contracted procedure: k8805 
o|contracted procedure: k8811 
o|contracted procedure: k8818 
o|contracted procedure: k8890 
o|contracted procedure: k8831 
o|contracted procedure: k8882 
o|contracted procedure: k8834 
o|contracted procedure: k8849 
o|contracted procedure: k8853 
o|contracted procedure: k8868 
o|contracted procedure: k8879 
o|contracted procedure: k8875 
o|contracted procedure: k8865 
o|contracted procedure: k8896 
o|contracted procedure: k8913 
o|contracted procedure: k8919 
o|contracted procedure: k8925 
o|contracted procedure: k8936 
o|contracted procedure: k8945 
o|contracted procedure: k8948 
o|contracted procedure: k8964 
o|contracted procedure: k8957 
o|contracted procedure: k8971 
o|contracted procedure: k8983 
o|contracted procedure: k8992 
o|contracted procedure: k9010 
o|contracted procedure: k9034 
o|substituted constant variable: g13674 
o|contracted procedure: k9041 
o|contracted procedure: k9045 
o|contracted procedure: k9059 
o|contracted procedure: k9055 
o|contracted procedure: k9062 
o|contracted procedure: k9068 
o|contracted procedure: k9074 
o|contracted procedure: k9087 
o|contracted procedure: k9093 
o|contracted procedure: k9114 
o|contracted procedure: k9137 
o|contracted procedure: k9143 
o|contracted procedure: k9150 
o|contracted procedure: k9163 
o|contracted procedure: k9167 
o|contracted procedure: k9175 
o|contracted procedure: k9181 
o|contracted procedure: k9198 
o|contracted procedure: k9214 
o|contracted procedure: k9243 
o|contracted procedure: k9229 
o|contracted procedure: k9239 
o|contracted procedure: k9220 
o|contracted procedure: k9256 
o|contracted procedure: k9264 
o|contracted procedure: k9270 
o|contracted procedure: k9287 
o|contracted procedure: k9322 
o|contracted procedure: k9331 
o|contracted procedure: k9337 
o|contracted procedure: k9344 
o|contracted procedure: k9366 
o|contracted procedure: k9376 
o|contracted procedure: k9392 
o|contracted procedure: k9395 
o|contracted procedure: k9450 
o|contracted procedure: k9409 
o|contracted procedure: k9428 
o|contracted procedure: k9431 
o|contracted procedure: k9438 
o|contracted procedure: k9531 
o|contracted procedure: k9459 
o|contracted procedure: k9496 
o|contracted procedure: k9470 
o|contracted procedure: k9492 
o|contracted procedure: k9482 
o|contracted procedure: k9499 
o|contracted procedure: k9511 
o|contracted procedure: k9521 
o|contracted procedure: k9525 
o|contracted procedure: k9563 
o|contracted procedure: k9574 
o|contracted procedure: k9582 
o|contracted procedure: k9586 
o|contracted procedure: k9613 
o|contracted procedure: k9633 
o|contracted procedure: k9643 
o|contracted procedure: k9639 
o|contracted procedure: k9653 
o|contracted procedure: k9668 
o|contracted procedure: k9671 
o|contracted procedure: k9677 
o|contracted procedure: k9683 
o|contracted procedure: k9716 
o|contracted procedure: k9712 
o|contracted procedure: k9708 
o|contracted procedure: k9696 
o|contracted procedure: k9704 
o|contracted procedure: k9700 
o|contracted procedure: k9737 
o|contracted procedure: k9753 
o|contracted procedure: k9749 
o|contracted procedure: k9801 
o|contracted procedure: k9761 
o|contracted procedure: k9765 
o|contracted procedure: k9782 
o|contracted procedure: k9778 
o|contracted procedure: k9768 
o|contracted procedure: k9785 
o|contracted procedure: k9791 
o|contracted procedure: k9809 
o|contracted procedure: k9812 
o|contracted procedure: k9823 
o|contracted procedure: k9849 
o|contracted procedure: k9841 
o|contracted procedure: k9859 
o|contracted procedure: k9872 
o|contracted procedure: k9885 
o|contracted procedure: k9907 
o|contracted procedure: k9916 
o|contracted procedure: k10040 
o|contracted procedure: k9935 
o|contracted procedure: k9945 
o|contracted procedure: k9954 
o|contracted procedure: k9967 
o|contracted procedure: k10016 
o|contracted procedure: k9992 
o|contracted procedure: k10005 
o|contracted procedure: k10033 
o|contracted procedure: k10052 
o|contracted procedure: k10059 
o|contracted procedure: k10067 
o|contracted procedure: k10079 
o|contracted procedure: k10101 
o|contracted procedure: k10097 
o|contracted procedure: k10082 
o|contracted procedure: k10085 
o|contracted procedure: k10093 
o|contracted procedure: k10167 
o|contracted procedure: k10116 
o|contracted procedure: k10163 
o|contracted procedure: k10129 
o|contracted procedure: k10142 
o|contracted procedure: k10188 
o|contracted procedure: k10184 
o|contracted procedure: k10221 
o|contracted procedure: k10217 
o|contracted procedure: k10213 
o|contracted procedure: k10209 
o|contracted procedure: k10256 
o|contracted procedure: k10410 
o|contracted procedure: k10279 
o|contracted procedure: k10292 
o|contracted procedure: k10305 
o|contracted procedure: k10313 
o|contracted procedure: k10326 
o|contracted procedure: k10334 
o|contracted procedure: k10346 
o|contracted procedure: k10356 
o|contracted procedure: k10375 
o|contracted procedure: k10367 
o|contracted procedure: k10383 
o|contracted procedure: k10387 
o|contracted procedure: k10401 
o|contracted procedure: k10436 
o|contracted procedure: k10432 
o|contracted procedure: k10428 
o|contracted procedure: k10450 
o|contracted procedure: k10481 
o|contracted procedure: k10456 
o|contracted procedure: k10477 
o|contracted procedure: k10471 
o|contracted procedure: k10467 
o|contracted procedure: k10463 
o|contracted procedure: k10499 
o|contracted procedure: k10512 
o|contracted procedure: k10525 
o|contracted procedure: k10528 
o|contracted procedure: k10541 
o|contracted procedure: k10559 
o|contracted procedure: k10570 
o|contracted procedure: k10671 
o|contracted procedure: k10575 
o|contracted procedure: k10595 
o|contracted procedure: k10591 
o|contracted procedure: k10587 
o|contracted procedure: k10579 
o|contracted procedure: k10566 
o|contracted procedure: k10633 
o|contracted procedure: k10636 
o|contracted procedure: k10639 
o|contracted procedure: k10647 
o|contracted procedure: k10655 
o|contracted procedure: k10621 
o|contracted procedure: k10617 
o|contracted procedure: k10603 
o|contracted procedure: k10611 
o|contracted procedure: k10661 
o|contracted procedure: k10668 
o|contracted procedure: k10683 
o|contracted procedure: k10686 
o|contracted procedure: k10689 
o|contracted procedure: k10697 
o|contracted procedure: k10705 
o|contracted procedure: k10550 
o|contracted procedure: k10554 
o|contracted procedure: k10721 
o|contracted procedure: k10735 
o|contracted procedure: k10742 
o|contracted procedure: k10759 
o|contracted procedure: k10749 
o|contracted procedure: k10772 
o|contracted procedure: k10984 
o|contracted procedure: k10796 
o|contracted procedure: k10980 
o|contracted procedure: k10812 
o|contracted procedure: k10851 
o|contracted procedure: k10858 
o|contracted procedure: k10872 
o|contracted procedure: k10861 
o|contracted procedure: k10868 
o|contracted procedure: k10922 
o|contracted procedure: k10931 
o|contracted procedure: k10935 
o|contracted procedure: k10879 
o|contracted procedure: k10897 
o|contracted procedure: k10904 
o|contracted procedure: k10918 
o|contracted procedure: k10907 
o|contracted procedure: k10914 
o|contracted procedure: k10947 
o|contracted procedure: k10950 
o|contracted procedure: k10953 
o|contracted procedure: k10961 
o|contracted procedure: k10969 
o|contracted procedure: k10976 
o|contracted procedure: k10994 
o|contracted procedure: k11356 
o|contracted procedure: k11018 
o|contracted procedure: k11079 
o|contracted procedure: k11097 
o|contracted procedure: k11087 
o|contracted procedure: k11111 
o|contracted procedure: k11100 
o|contracted procedure: k11107 
o|contracted procedure: k11123 
o|contracted procedure: k11172 
o|contracted procedure: k11168 
o|contracted procedure: k11148 
o|contracted procedure: k11164 
o|contracted procedure: k11156 
o|contracted procedure: k11152 
o|contracted procedure: k11220 
o|contracted procedure: k11188 
o|contracted procedure: k11216 
o|contracted procedure: k11200 
o|contracted procedure: k11212 
o|contracted procedure: k11204 
o|contracted procedure: k11196 
o|contracted procedure: k11192 
o|contracted procedure: k11227 
o|contracted procedure: k11231 
o|contracted procedure: k11240 
o|contracted procedure: k11247 
o|contracted procedure: k11263 
o|contracted procedure: k11252 
o|contracted procedure: k11259 
o|contracted procedure: k11268 
o|contracted procedure: k11274 
o|contracted procedure: k11280 
o|contracted procedure: k11286 
o|contracted procedure: k11292 
o|contracted procedure: k11304 
o|contracted procedure: k11319 
o|contracted procedure: k11330 
o|contracted procedure: k11352 
o|contracted procedure: k11366 
o|contracted procedure: k11372 
o|contracted procedure: k11375 
o|contracted procedure: k11382 
o|contracted procedure: k11408 
o|contracted procedure: k11392 
o|contracted procedure: k11400 
o|contracted procedure: k11396 
o|contracted procedure: k11418 
o|contracted procedure: k11424 
o|contracted procedure: k11427 
o|contracted procedure: k11434 
o|contracted procedure: k11441 
o|contracted procedure: k11458 
o|contracted procedure: k11461 
o|contracted procedure: k11467 
o|contracted procedure: k11474 
o|contracted procedure: k11484 
o|contracted procedure: k11511 
o|contracted procedure: k11533 
o|contracted procedure: k11555 
o|contracted procedure: k11577 
o|contracted procedure: k11605 
o|contracted procedure: k11615 
o|contracted procedure: k11629 
o|contracted procedure: k11618 
o|contracted procedure: k11625 
o|contracted procedure: k11639 
o|contracted procedure: k11732 
o|contracted procedure: k11714 
o|contracted procedure: k11710 
o|contracted procedure: k11706 
o|contracted procedure: k11728 
o|contracted procedure: k11719 
o|contracted procedure: k11661 
o|contracted procedure: k11674 
o|contracted procedure: k11751 
o|contracted procedure: k11851 
o|contracted procedure: k11847 
o|contracted procedure: k11807 
o|contracted procedure: k11831 
o|contracted procedure: k11841 
o|contracted procedure: k11837 
o|contracted procedure: k11827 
o|contracted procedure: k11770 
o|contracted procedure: k11786 
o|contracted procedure: k11868 
o|contracted procedure: k11885 
o|contracted procedure: k11902 
o|contracted procedure: k11919 
o|contracted procedure: k11936 
o|simplifications: ((let . 185)) 
o|replaced variables: 2 
o|removed binding forms: 852 
o|inlining procedure: k5151 
o|inlining procedure: k5151 
o|inlining procedure: k6194 
o|inlining procedure: k6362 
o|inlining procedure: k6362 
o|inlining procedure: k9757 
o|inlining procedure: k9757 
o|inlining procedure: k11667 
o|replaced variables: 187 
o|removed binding forms: 6 
o|simplifications: ((let . 1) (if . 2)) 
o|replaced variables: 4 
o|removed binding forms: 110 
o|contracted procedure: k10701 
o|replaced variables: 4 
o|removed binding forms: 4 
o|removed binding forms: 2 
o|direct leaf routine/allocation: lookup 0 
o|direct leaf routine/allocation: g507508 0 
o|direct leaf routine/allocation: g12301231 0 
o|direct leaf routine/allocation: g13211322 0 
o|direct leaf routine/allocation: loop1373 0 
o|direct leaf routine/allocation: g15601561 0 
o|direct leaf routine/allocation: g15691570 0 
o|direct leaf routine/allocation: assq-reverse1436 0 
o|direct leaf routine/allocation: g20102019 15 
o|contracted procedure: "(expand.scm:92) k3701" 
o|contracted procedure: "(expand.scm:168) k4195" 
o|contracted procedure: "(expand.scm:180) k4231" 
o|contracted procedure: "(expand.scm:184) k4247" 
o|contracted procedure: "(expand.scm:186) k4256" 
o|contracted procedure: "(expand.scm:271) k4591" 
o|contracted procedure: "(expand.scm:273) k4808" 
o|contracted procedure: "(expand.scm:474) k5746" 
o|converted assignments to bindings: (loop1373) 
o|contracted procedure: "(expand.scm:816) k7550" 
o|contracted procedure: "(expand.scm:877) k7847" 
o|contracted procedure: "(expand.scm:877) k7853" 
o|contracted procedure: "(expand.scm:896) k7949" 
o|contracted procedure: "(expand.scm:897) k7952" 
o|contracted procedure: "(expand.scm:1248) k10965" 
o|simplifications: ((let . 1) (if . 2)) 
o|removed binding forms: 14 
o|contracted procedure: "(expand.scm:787) k7364" 
o|replaced variables: 12 
o|removed binding forms: 1 
o|removed binding forms: 6 
o|direct leaf routine/allocation: comp988 0 
o|contracted procedure: "(expand.scm:492) k5880" 
o|contracted procedure: "(expand.scm:561) k6327" 
o|contracted procedure: "(expand.scm:588) k6464" 
o|contracted procedure: "(expand.scm:591) k6476" 
o|contracted procedure: "(expand.scm:595) k6508" 
o|simplifications: ((if . 1)) 
o|removed binding forms: 5 
o|replaced variables: 6 
o|removed binding forms: 1 
o|customizable procedures: (loop1720 k11595 check-for-multiple-bindings expand1885 map-loop20042025 k10883 expand1980 expand2047 map-loop20692087 k10583 k10651 map-loop21032121 match-expression g21982199 g21912192 walk2135 walk12136 simplify2137 expand2263 map-loop22712289 err2235 test2236 k9771 g27412748 for-each-loop27402751 loop2719 loop2649 k9048 k9001 doloop25982599 k8638 k8431 map-loop24642481 k8107 loop1783 mirror-rename1437 k7750 k7758 doloop15051506 g14521453 k7572 k7158 test1345 k7182 walk1383 doloop13981399 loop1359 err1346 loop1264 loop1277 loop1294 outstr1275 loop1241 mwalk1217 k6312 fini/syntax990 loop1171 loop21187 k6180 loop1121 map-loop11341151 fini989 foldl10491053 map-loop10261065 k5965 map-loop10741101 k5839 loop1009 expand991 map-loop898915 map-loop927951 k5273 k5449 k5362 k5320 k5323 macro-alias k5286 loop774 err763 g796805 map-loop790818 k4988 k5000 k4917 loop741 loop727 k4597 k4752 g695696 loop608 expand552 map-loop635653 map-loop662679 call-handler551 tmp13084 tmp23085 k4369 k4403 copy571 loop537 k4116 loop467 g464465 loop1452 map-loop354371 for-each-loop380407 map-loop417438 doloop331332 walk301 k3695) 
o|calls to known targets: 360 
o|identified direct recursive calls: f_3751 1 
o|identified direct recursive calls: f_3928 1 
o|identified direct recursive calls: f_3976 1 
o|identified direct recursive calls: f_4293 1 
o|identified direct recursive calls: f_4647 1 
o|identified direct recursive calls: f_4716 1 
o|identified direct recursive calls: f_4972 2 
o|identified direct recursive calls: f_5626 1 
o|identified direct recursive calls: f_6022 1 
o|identified direct recursive calls: f_6135 1 
o|identified direct recursive calls: f_6108 1 
o|identified direct recursive calls: f_6606 1 
o|identified direct recursive calls: f_6688 1 
o|identified direct recursive calls: f_6767 1 
o|identified direct recursive calls: f_7139 1 
o|identified direct recursive calls: f_7165 1 
o|identified direct recursive calls: f_7487 1 
o|identified direct recursive calls: f_7641 1 
o|identified direct recursive calls: f_7878 1 
o|identified direct recursive calls: f_7903 1 
o|identified direct recursive calls: f_9029 1 
o|identified direct recursive calls: f_9423 1 
o|identified direct recursive calls: f_10074 1 
o|identified direct recursive calls: f_10678 1 
o|identified direct recursive calls: f_10730 1 
o|identified direct recursive calls: f_10942 1 
o|fast box initializations: 69 
o|fast global references: 31 
o|fast global assignments: 4 
o|dropping unused closure argument: f_3687 
o|dropping unused closure argument: f_3670 
o|dropping unused closure argument: f_7139 
o|dropping unused closure argument: f_7878 
o|dropping unused closure argument: f_8090 
o|dropping unused closure argument: f_6603 
*/
/* end of file */
