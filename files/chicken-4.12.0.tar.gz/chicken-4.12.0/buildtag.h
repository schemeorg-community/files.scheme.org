#define C_BUILD_TAG "compiled 2017-02-19 on yves.more-magic.net (Linux)"
