/* Generated from lfa2.scm by the CHICKEN compiler
   http://www.call-cc.org
   2017-02-19 13:18
   Version 4.12.0 (rev 6ea24b6)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2017-02-19 on yves.more-magic.net (Linux)
   command line: lfa2.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file lfa2.c
   unit: lfa2
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[72];
static double C_possibly_force_alignment;


C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word *av) C_noret;
C_noret_decl(f_1514)
static void C_fcall f_1514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_fcall f_1160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word *av) C_noret;
C_noret_decl(f_1967)
static void C_fcall f_1967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1805)
static void C_fcall f_1805(C_word t0,C_word t1) C_noret;
C_noret_decl(C_lfa2_toplevel)
C_externexport void C_ccall C_lfa2_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_1170)
static void C_fcall f_1170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word *av) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word *av) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word *av) C_noret;
C_noret_decl(f_1252)
static void C_fcall f_1252(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word *av) C_noret;
C_noret_decl(f_1196)
static void C_fcall f_1196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word *av) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word *av) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word *av) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word *av) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word *av) C_noret;
C_noret_decl(f_941)
static void C_fcall f_941(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1630)
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_947)
static void C_fcall f_947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word *av) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word *av) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word *av) C_noret;
C_noret_decl(f_1737)
static void C_fcall f_1737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word *av) C_noret;
C_noret_decl(f_1354)
static void C_fcall f_1354(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_fcall f_1033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1870)
static void C_fcall f_1870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word *av) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word *av) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word *av) C_noret;
C_noret_decl(f_1860)
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1008)
static void C_fcall f_1008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word *av) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word *av) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word *av) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word *av) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word *av) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word *av) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word *av) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word *av) C_noret;
C_noret_decl(f_1492)
static void C_fcall f_1492(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word *av) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word *av) C_noret;
C_noret_decl(f_1020)
static void C_fcall f_1020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1475)
static void C_fcall f_1475(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word *av) C_noret;
C_noret_decl(f_1109)
static void C_fcall f_1109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word *av) C_noret;
C_noret_decl(f_1933)
static void C_fcall f_1933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1582)
static void C_fcall f_1582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word *av) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word *av) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word *av) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word *av) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word *av) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word *av) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word *av) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word *av) C_noret;
C_noret_decl(f_1955)
static void C_fcall f_1955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2078)
static void C_fcall f_2078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_912)
static void C_fcall f_912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word *av) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word *av) C_noret;

C_noret_decl(trf_1514)
static void C_ccall trf_1514(C_word c,C_word *av) C_noret;
static void C_ccall trf_1514(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1514(t0,t1);}

C_noret_decl(trf_1160)
static void C_ccall trf_1160(C_word c,C_word *av) C_noret;
static void C_ccall trf_1160(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1160(t0,t1,t2);}

C_noret_decl(trf_1967)
static void C_ccall trf_1967(C_word c,C_word *av) C_noret;
static void C_ccall trf_1967(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1967(t0,t1,t2);}

C_noret_decl(trf_1805)
static void C_ccall trf_1805(C_word c,C_word *av) C_noret;
static void C_ccall trf_1805(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1805(t0,t1);}

C_noret_decl(trf_1170)
static void C_ccall trf_1170(C_word c,C_word *av) C_noret;
static void C_ccall trf_1170(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1170(t0,t1);}

C_noret_decl(trf_1252)
static void C_ccall trf_1252(C_word c,C_word *av) C_noret;
static void C_ccall trf_1252(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1252(t0,t1);}

C_noret_decl(trf_1196)
static void C_ccall trf_1196(C_word c,C_word *av) C_noret;
static void C_ccall trf_1196(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1196(t0,t1,t2,t3,t4);}

C_noret_decl(trf_941)
static void C_ccall trf_941(C_word c,C_word *av) C_noret;
static void C_ccall trf_941(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_941(t0,t1,t2);}

C_noret_decl(trf_1630)
static void C_ccall trf_1630(C_word c,C_word *av) C_noret;
static void C_ccall trf_1630(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1630(t0,t1,t2);}

C_noret_decl(trf_947)
static void C_ccall trf_947(C_word c,C_word *av) C_noret;
static void C_ccall trf_947(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_947(t0,t1,t2);}

C_noret_decl(trf_1737)
static void C_ccall trf_1737(C_word c,C_word *av) C_noret;
static void C_ccall trf_1737(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1737(t0,t1);}

C_noret_decl(trf_1354)
static void C_ccall trf_1354(C_word c,C_word *av) C_noret;
static void C_ccall trf_1354(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1354(t0,t1);}

C_noret_decl(trf_1033)
static void C_ccall trf_1033(C_word c,C_word *av) C_noret;
static void C_ccall trf_1033(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1033(t0,t1,t2);}

C_noret_decl(trf_1870)
static void C_ccall trf_1870(C_word c,C_word *av) C_noret;
static void C_ccall trf_1870(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1870(t0,t1);}

C_noret_decl(trf_1860)
static void C_ccall trf_1860(C_word c,C_word *av) C_noret;
static void C_ccall trf_1860(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1860(t0,t1,t2);}

C_noret_decl(trf_1008)
static void C_ccall trf_1008(C_word c,C_word *av) C_noret;
static void C_ccall trf_1008(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1008(t0,t1);}

C_noret_decl(trf_1492)
static void C_ccall trf_1492(C_word c,C_word *av) C_noret;
static void C_ccall trf_1492(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1492(t0,t1,t2);}

C_noret_decl(trf_1020)
static void C_ccall trf_1020(C_word c,C_word *av) C_noret;
static void C_ccall trf_1020(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1020(t0,t1,t2,t3);}

C_noret_decl(trf_1475)
static void C_ccall trf_1475(C_word c,C_word *av) C_noret;
static void C_ccall trf_1475(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1475(t0,t1,t2);}

C_noret_decl(trf_1109)
static void C_ccall trf_1109(C_word c,C_word *av) C_noret;
static void C_ccall trf_1109(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1109(t0,t1,t2);}

C_noret_decl(trf_1933)
static void C_ccall trf_1933(C_word c,C_word *av) C_noret;
static void C_ccall trf_1933(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1933(t0,t1,t2);}

C_noret_decl(trf_1582)
static void C_ccall trf_1582(C_word c,C_word *av) C_noret;
static void C_ccall trf_1582(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1582(t0,t1);}

C_noret_decl(trf_1955)
static void C_ccall trf_1955(C_word c,C_word *av) C_noret;
static void C_ccall trf_1955(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1955(t0,t1,t2);}

C_noret_decl(trf_2078)
static void C_ccall trf_2078(C_word c,C_word *av) C_noret;
static void C_ccall trf_2078(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2078(t0,t1,t2);}

C_noret_decl(trf_912)
static void C_ccall trf_912(C_word c,C_word *av) C_noret;
static void C_ccall trf_912(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_912(t0,t1,t2);}

/* k1065 in k1048 in k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_1067,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* lfa2.scm:213: node-parameters-set! */
t3=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1512 in k1494 in g307 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_1514,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(2));
t4=C_i_car(t3);
if(C_truep(C_i_symbolp(t4))){
t5=C_i_cadr(((C_word*)t0)[3]);
t6=C_eqp(t4,t5);
if(C_truep(t6)){
/* lfa2.scm:294: extinguish! */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1020(t7,((C_word*)t0)[5],((C_word*)t0)[6],lf[55]);}
else{
t7=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t7;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t5=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* loop in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_1160,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1170,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cdar(t2);
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_car(t6);
t8=C_u_i_car(t7);
t9=t3;
f_1170(t9,C_i_assq(t8,((C_word*)t0)[4]));}
else{
t6=t3;
f_1170(t6,C_SCHEME_FALSE);}}}

/* k1963 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1965,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop389 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_1967,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1977,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:350: g390 */
t5=((C_word*)t0)[3];
f_1955(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1803 in k1723 in g328 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_1805,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_memq(lf[25],t3))){
/* lfa2.scm:333: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1020(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[60]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[25];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_member(((C_word*)t0)[7],t3))){
/* lfa2.scm:336: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1020(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[61]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[25];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_lfa2_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("lfa2_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_lfa2_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(1775))){
C_save(t1);
C_rereclaim2(1775*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,72);
lf[0]=C_h_intern(&lf[0],17,"+constructor-map+");
lf[1]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record1\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record2\376\003\000"
"\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record3\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000"
"\000\015C_a_i_record4\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record5\376\003\000\000\002\376\001\000\000\010\052struc"
"t\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record6\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_recor"
"d7\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record8\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376B\000\000\014C_a_i_record\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_a_i_string\376\003\000\000\002\376\001\000\000\006str"
"ing\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_a_i_port\376\003\000\000\002\376\001\000\000\004port\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector1\376\003\000\000"
"\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector2\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a"
"_i_vector3\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector4\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\015C_a_i_vector5\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector6\376\003\000\000\002\376\001\000\000"
"\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector7\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_ve"
"ctor8\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_a_pair\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C"
"_a_i_bytevector\376\003\000\000\002\376\001\000\000\004blob\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_a_i_make_locative\376\003\000\000\002\376\001\000\000\010loca"
"tive\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_a_i_vector\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list1\376"
"\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list2\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_"
"list3\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list4\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013"
"C_a_i_list5\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list6\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000"
"\002\376B\000\000\013C_a_i_list7\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list8\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000"
"\000\002\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_a_i_flonum\376\003\000\000\002\376\001\000\000\006flon"
"um\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_fix_to_flo\376\003\000\000\002\376\001\000\000\006flonum\376\377\016\376\377\016");
lf[2]=C_h_intern(&lf[2],40,"\010compilerperform-secondary-flow-analysis");
lf[3]=C_h_intern(&lf[3],12,"\010compilerget");
lf[4]=C_h_intern(&lf[4],8,"assigned");
lf[5]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\016\004coreprimitive\376\003\000\000\002\376\001\000\000\013\004corela"
"mbda\376\377\016");
lf[6]=C_h_intern(&lf[6],13,"\004corevariable");
lf[7]=C_h_intern(&lf[7],7,"\003sysget");
lf[8]=C_h_intern(&lf[8],21,"\010compileralways-bound");
lf[9]=C_h_intern(&lf[9],6,"global");
lf[10]=C_h_intern(&lf[10],24,"node-subexpressions-set!");
lf[11]=C_h_intern(&lf[11],20,"node-parameters-set!");
lf[12]=C_h_intern(&lf[12],15,"node-class-set!");
lf[13]=C_h_intern(&lf[13],14,"\004coreundefined");
lf[14]=C_h_intern(&lf[14],8,"for-each");
lf[15]=C_h_intern(&lf[15],13,"string-append");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[19]=C_h_intern(&lf[19],13,"\010compilerbomb");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\0005bad number of arguments to extinguished ##core#inline");
lf[21]=C_h_intern(&lf[21],1,"\052");
lf[22]=C_h_intern(&lf[22],2,"if");
lf[23]=C_h_intern(&lf[23],9,"\004corecond");
lf[24]=C_h_intern(&lf[24],6,"append");
lf[25]=C_h_intern(&lf[25],7,"boolean");
lf[26]=C_h_intern(&lf[26],5,"quote");
lf[27]=C_h_intern(&lf[27],6,"string");
lf[28]=C_h_intern(&lf[28],6,"symbol");
lf[29]=C_h_intern(&lf[29],6,"fixnum");
lf[30]=C_h_intern(&lf[30],5,"float");
lf[31]=C_h_intern(&lf[31],11,"number-type");
lf[32]=C_h_intern(&lf[32],6,"flonum");
lf[33]=C_h_intern(&lf[33],6,"number");
lf[34]=C_h_intern(&lf[34],4,"null");
lf[35]=C_h_intern(&lf[35],4,"list");
lf[36]=C_h_intern(&lf[36],4,"pair");
lf[37]=C_h_intern(&lf[37],3,"eof");
lf[38]=C_h_intern(&lf[38],6,"vector");
lf[39]=C_h_intern(&lf[39],6,"struct");
lf[40]=C_h_intern(&lf[40],4,"char");
lf[41]=C_h_intern(&lf[41],3,"let");
lf[42]=C_h_intern(&lf[42],11,"\004corelambda");
lf[43]=C_h_intern(&lf[43],18,"\004coredirect_lambda");
lf[44]=C_h_intern(&lf[44],9,"procedure");
lf[45]=C_h_intern(&lf[45],4,"set!");
lf[46]=C_h_intern(&lf[46],9,"\004coreset!");
lf[47]=C_h_intern(&lf[47],9,"undefined");
lf[48]=C_h_intern(&lf[48],14,"\004coreprimitive");
lf[49]=C_h_intern(&lf[49],11,"\004coreinline");
lf[50]=C_h_intern(&lf[50],20,"\004coreinline_allocate");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_closure\376\003\000\000\002\376\001\000\000\011procedure\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\017C_i_check_e"
"xact\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_inexact\376\003\000\000\002\376\001\000\000\006flonum\376\377\016\376\003\000\000\002\376"
"\003\000\000\002\376B\000\000\020C_i_check_number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006number\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\020C_i_check_string\376\003\000\000\002\376\001\000\000\006string\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\024C_i_check_bytevecto"
"r\376\003\000\000\002\376\001\000\000\004blob\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\003\000\000\002\376\003\000\000\002\376B"
"\000\000\016C_i_check_list\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004pair\376\003\000\000\002\376\001\000\000\004list\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\016C_i"
"_check_pair\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_locative\376\003\000\000\002\376\001\000\000\010locative\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_boolean\376\003\000\000\002\376\001\000\000\007boolean\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_v"
"ector\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_i_check_structure\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376B\000\000\016C_i_check_char\376\003\000\000\002\376\001\000\000\004char\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_i_check_closure_2\376"
"\003\000\000\002\376\001\000\000\011procedure\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_exact_2\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376B\000\000\023C_i_check_inexact_2\376\003\000\000\002\376\001\000\000\006flonum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_number_2\376\003"
"\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006number\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_string"
"_2\376\003\000\000\002\376\001\000\000\006string\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\026C_i_check_bytevector_2\376\003\000\000\002\376\001\000\000\004blob\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376B\000\000\022C_i_check_symbol_2\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_list_2\376\003"
"\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004pair\376\003\000\000\002\376\001\000\000\004list\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_pair_2\376\003\000\000\002\376"
"\001\000\000\004pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\024C_i_check_locative_2\376\003\000\000\002\376\001\000\000\010locative\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000"
"\000\023C_i_check_boolean_2\376\003\000\000\002\376\001\000\000\007boolean\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_vector_2\376\003\000\000\002\376"
"\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_i_check_structure_2\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376B\000\000\020C_i_check_char_2\376\003\000\000\002\376\001\000\000\004char\376\377\016\376\377\016");
lf[52]=C_h_intern(&lf[52],6,"unsafe");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_noop");
lf[54]=C_h_intern(&lf[54],8,"\052struct\052");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_noop");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_noop");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_noop");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_i_closurep\376\003\000\000\002\376\001\000\000\011procedure\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_fixnump\376\003\000\000\002\376\001"
"\000\000\006fixnum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_i_flonump\376\003\000\000\002\376\001\000\000\006flonum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_i_numb"
"erp\376\003\000\000\002\376\001\000\000\006number\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_stringp\376\003\000\000\002\376\001\000\000\006string\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015"
"C_bytevectorp\376\003\000\000\002\376\001\000\000\004blob\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_i_symbolp\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376B\000\000\011C_i_listp\376\003\000\000\002\376\001\000\000\004list\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_i_pairp\376\003\000\000\002\376\001\000\000\004pair\376\377\016\376\003\000"
"\000\002\376\003\000\000\002\376B\000\000\013C_locativep\376\003\000\000\002\376\001\000\000\010locative\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_booleanp\376\003\000\000\002\376\001\000\000\007b"
"oolean\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_i_vectorp\376\003\000\000\002\376\001\000\000\006vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_structure"
"p\376\003\000\000\002\376\001\000\000\006struct\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\016C_i_structurep\376\003\000\000\002\376\001\000\000\010\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376B\000\000\007C_charp\376\003\000\000\002\376\001\000\000\004char\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_i_portp\376\003\000\000\002\376\001\000\000\004port\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376B\000\000\011C_i_nullp\376\003\000\000\002\376\001\000\000\004null\376\377\016\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_true");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_true");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_true");
lf[62]=C_h_intern(&lf[62],19,"\003sysstandard-output");
lf[63]=C_h_intern(&lf[63],6,"printf");
lf[64]=C_h_intern(&lf[64],16,"\003syswrite-char-0");
lf[65]=C_h_intern(&lf[65],9,"\003sysprint");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\002:\011");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[68]=C_h_intern(&lf[68],5,"print");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\027eliminated type checks:");
lf[70]=C_h_intern(&lf[70],30,"\010compilerwith-debugging-output");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001x\376\003\000\000\002\376\001\000\000\001o\376\377\016");
C_register_lf2(lf,72,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k1168 in loop in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_1170,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_i_cdr(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* lfa2.scm:232: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1160(t4,((C_word*)t0)[2],t3);}}

/* k1334 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_1336,2,av);}
a=C_alloc(11);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* lfa2.scm:259: assigned? */
t6=((C_word*)((C_word*)t0)[9])[1];
f_941(t6,t5,((C_word*)t0)[4]);}

/* k1276 in k1250 in k1244 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_1278,2,av);}
/* lfa2.scm:244: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1196(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* k1244 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_1246,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_u_i_car(t2);
t5=t3;
f_1252(t5,C_eqp(lf[25],t4));}
else{
t4=t3;
f_1252(t4,C_SCHEME_FALSE);}}

/* k1250 in k1244 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,4)))){
C_save_and_reclaim_args((void *)trf_1252,2,t0,t1);}
a=C_alloc(14);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1278,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=C_i_cadr(((C_word*)t0)[6]);
/* lfa2.scm:245: append */
t7=*((C_word*)lf[24]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* lfa2.scm:251: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1196(t4,t2,t3,((C_word*)t0)[7],((C_word*)t0)[5]);}}

/* k1253 in k1250 in k1244 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_1255,2,av);}
a=C_alloc(6);
t2=C_i_caddr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=C_i_caddr(((C_word*)t0)[6]);
/* lfa2.scm:248: append */
t6=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(21,0,4)))){
C_save_and_reclaim_args((void *)trf_1196,5,t0,t1,t2,t3,t4);}
a=C_alloc(21);
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(3));
t12=t11;
t13=C_eqp(t6,lf[6]);
if(C_truep(t13)){
t14=C_i_car(t9);
t15=t1;
t16=t14;
t17=t3;
t18=t4;
t19=C_i_assq(t16,t17);
if(C_truep(t19)){
t20=t15;{
C_word av2[2];
av2[0]=t20;
av2[1]=C_i_cdr(t19);
((C_proc)(void*)(*((C_word*)t20+1)))(2,av2);}}
else{
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1160,a[2]=t21,a[3]=t16,a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t23=((C_word*)t21)[1];
f_1160(t23,t15,t18);}}
else{
t14=C_eqp(t6,lf[22]);
t15=(C_truep(t14)?t14:C_eqp(t6,lf[23]));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1246,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t17=C_i_car(t12);
/* lfa2.scm:242: walk */
t33=t16;
t34=t17;
t35=t3;
t36=t4;
t1=t33;
t2=t34;
t3=t35;
t4=t36;
goto loop;}
else{
t16=C_eqp(t6,lf[26]);
if(C_truep(t16)){
t17=C_i_car(t9);
t18=t1;
if(C_truep(C_i_stringp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[27];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[28];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_fixnump(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[29];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_i_flonump(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_i_numberp(t17))){
t19=*((C_word*)lf[31]+1);
t20=*((C_word*)lf[31]+1);
t21=C_eqp(*((C_word*)lf[31]+1),lf[29]);
if(C_truep(t21)){
t22=t18;{
C_word av2[2];
av2[0]=t22;
av2[1]=lf[29];
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}
else{
t22=C_eqp(t19,lf[32]);
t23=t18;{
C_word av2[2];
av2[0]=t23;
av2[1]=(C_truep(t22)?lf[32]:lf[33]);
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}}
else{
if(C_truep(C_booleanp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[25];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_i_listp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[35];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[36];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_eofp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[37];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
if(C_truep(C_i_vectorp(t17))){
t19=t18;{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[38];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
t19=C_immp(t17);
t20=(C_truep(t19)?C_SCHEME_FALSE:C_structurep(t17));
if(C_truep(t20)){
t21=C_slot(t17,C_fix(0));
t22=t18;{
C_word av2[2];
av2[0]=t22;
av2[1]=C_a_i_list(&a,2,lf[39],t21);
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}
else{
t21=C_charp(t17);
t22=t18;{
C_word av2[2];
av2[0]=t22;
av2[1]=(C_truep(t21)?lf[40]:lf[21]);
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}}}}}}}}}}}}}
else{
t17=C_eqp(t6,lf[41]);
if(C_truep(t17)){
t18=C_i_car(t12);
t19=t18;
t20=C_i_car(t9);
t21=t20;
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1336,a[2]=t12,a[3]=t3,a[4]=t21,a[5]=t19,a[6]=t4,a[7]=((C_word*)t0)[2],a[8]=t1,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* lfa2.scm:257: walk */
t33=t22;
t34=t19;
t35=t3;
t36=t4;
t1=t33;
t2=t34;
t3=t35;
t4=t36;
goto loop;}
else{
t18=C_eqp(t6,lf[42]);
t19=(C_truep(t18)?t18:C_eqp(t6,lf[43]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1433,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t21=C_i_car(t12);
/* lfa2.scm:272: walk */
t33=t20;
t34=t21;
t35=C_SCHEME_END_OF_LIST;
t36=C_SCHEME_END_OF_LIST;
t1=t33;
t2=t34;
t3=t35;
t4=t36;
goto loop;}
else{
t20=C_eqp(t6,lf[45]);
t21=(C_truep(t20)?t20:C_eqp(t6,lf[46]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1449,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t23=C_i_car(t12);
/* lfa2.scm:275: walk */
t33=t22;
t34=t23;
t35=t3;
t36=t4;
t1=t33;
t2=t34;
t3=t35;
t4=t36;
goto loop;}
else{
t22=C_eqp(t6,lf[13]);
if(C_truep(t22)){
t23=t1;{
C_word av2[2];
av2[0]=t23;
av2[1]=lf[47];
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}
else{
t23=C_eqp(t6,lf[48]);
if(C_truep(t23)){
t24=t1;{
C_word av2[2];
av2[0]=t24;
av2[1]=lf[44];
((C_proc)(void*)(*((C_word*)t24+1)))(2,av2);}}
else{
t24=C_eqp(t6,lf[49]);
t25=(C_truep(t24)?t24:C_eqp(t6,lf[50]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t27=C_i_check_list_2(t12,lf[14]);
t28=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1485,a[2]=t9,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t12,a[6]=((C_word*)t0)[2],a[7]=t3,a[8]=t4,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_set_block_item(t30,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1933,a[2]=t30,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t32=((C_word*)t30)[1];
f_1933(t32,t28,t12);}
else{
t26=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t27=C_i_check_list_2(t12,lf[14]);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1965,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_set_block_item(t30,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=t30,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t32=((C_word*)t30)[1];
f_1967(t32,t28,t12);}}}}}}}}}}

/* k2042 in a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_2044,2,av);}
a=C_alloc(5);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(t2,lf[14]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2078(t7,((C_word*)t0)[3],t2);}

/* a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2040,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:358: print */
t3=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[69];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2053 in k2050 in for-each-loop415 in k2042 in a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_2055,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:360: ##sys#print */
t3=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[66];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2056 in k2053 in k2050 in for-each-loop415 in k2042 in a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_2058,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* lfa2.scm:360: ##sys#print */
t4=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2050 in for-each-loop415 in k2042 in a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_2052,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* lfa2.scm:360: ##sys#print */
t4=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* assigned? in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_941(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_941,3,t0,t1,t2);}
/* lfa2.scm:186: get */
t3=*((C_word*)lf[3]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=lf[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* g328 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,0,4)))){
C_save_and_reclaim_args((void *)trf_1630,3,t0,t1,t2);}
a=C_alloc(21);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[6],t4);
if(C_truep(t5)){
t6=C_slot(t3,C_fix(2));
t7=C_i_car(t6);
t8=C_i_cadr(t2);
t9=C_eqp(lf[54],t8);
if(C_truep(t9)){
t10=C_i_cadr(((C_word*)t0)[2]);
t11=C_slot(t10,C_fix(1));
t12=C_eqp(lf[26],t11);
if(C_truep(t12)){
t13=C_i_cadr(((C_word*)t0)[2]);
t14=C_slot(t13,C_fix(2));
t15=C_i_car(t14);
if(C_truep(C_i_symbolp(t15))){
t16=C_a_i_list(&a,2,lf[39],t15);
t17=C_a_i_cons(&a,2,t7,t16);
t18=C_a_i_list(&a,1,t17);
t19=t1;{
C_word av2[2];
av2[0]=t19;
av2[1]=C_a_i_list(&a,3,lf[25],t18,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
t16=C_a_i_cons(&a,2,t7,lf[39]);
t17=C_a_i_list(&a,1,t16);
t18=t1;{
C_word av2[2];
av2[0]=t18;
av2[1]=C_a_i_list(&a,3,lf[25],t17,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}}
else{
t13=C_a_i_cons(&a,2,t7,lf[39]);
t14=C_a_i_list(&a,1,t13);
t15=t1;{
C_word av2[2];
av2[0]=t15;
av2[1]=C_a_i_list(&a,3,lf[25],t14,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}}
else{
t10=C_i_cadr(t2);
t11=C_a_i_cons(&a,2,t7,t10);
t12=C_a_i_list(&a,1,t11);
t13=t1;{
C_word av2[2];
av2[0]=t13;
av2[1]=C_a_i_list(&a,3,lf[25],t12,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1725,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t7=C_u_i_car(((C_word*)t0)[2]);
/* lfa2.scm:320: walk */
t8=((C_word*)((C_word*)t0)[5])[1];
f_1196(t8,t6,t7,((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* droppable? in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_947(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,4)))){
C_save_and_reclaim_args((void *)trf_947,3,t0,t1,t2);}
a=C_alloc(4);
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_u_i_memq(t4,lf[5]);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=C_eqp(lf[6],t7);
if(C_truep(t8)){
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_car(t10);
t12=t11;
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_988,a[2]=t1,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:193: get */
t14=*((C_word*)lf[3]+1);{
C_word av2[5];
av2[0]=t14;
av2[1]=t13;
av2[2]=((C_word*)t0)[2];
av2[3]=t12;
av2[4]=lf[9];
((C_proc)(void*)(*((C_word*)t14+1)))(5,av2);}}
else{
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}}

/* k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_2029,2,av);}
a=C_alloc(3);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:355: with-debugging-output */
t3=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[71];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1431 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1433,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[44];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1975 in for-each-loop389 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_1977,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1967(t3,((C_word*)t0)[4],t2);}

/* k1735 in k1723 in g328 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_1737,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(2));
t4=C_i_car(t3);
if(C_truep(C_i_symbolp(t4))){
t5=C_i_cadr(((C_word*)t0)[3]);
t6=C_eqp(t4,t5);
if(C_truep(t6)){
/* lfa2.scm:330: extinguish! */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1020(t7,((C_word*)t0)[5],((C_word*)t0)[6],lf[59]);}
else{
t7=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t7;
av2[1]=lf[25];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t5=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[25];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[25];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k1447 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1449,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[47];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1352 in k1416 in k1334 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_1354,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_car(t2);
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t3,((C_word*)t0)[3]),((C_word*)t0)[4]);
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[3],t3),t4);
/* lfa2.scm:258: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_1196(t6,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],t5);}
else{
t2=((C_word*)t0)[4];
/* lfa2.scm:258: walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1196(t3,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],t2);}}

/* g173 in k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_1033,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:207: droppable? */
t4=((C_word*)((C_word*)t0)[4])[1];
f_947(t4,t3,t2);}

/* k1868 in g369 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,1)))){
C_save_and_reclaim_args((void *)trf_1870,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_car(t2);
t4=C_i_symbolp(t3);
t5=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t5;
av2[1]=(C_truep(t4)?C_a_i_list(&a,2,lf[39],t3):lf[39]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_i_cadr(((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k740 */
static void C_ccall f_742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_742,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k743 in k740 */
static void C_ccall f_745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_745,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k746 in k743 in k740 */
static void C_ccall f_748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_748,2,av);}
a=C_alloc(2);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! +constructor-map+ ...) */,lf[1]);
t3=C_mutate2((C_word*)lf[2]+1 /* (set! ##compiler#perform-secondary-flow-analysis ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_795,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* g369 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_1860,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_u_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1870,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_cadr(t2);
t8=C_eqp(lf[54],t7);
if(C_truep(t8)){
t9=C_slot(t5,C_fix(1));
t10=t6;
f_1870(t10,C_eqp(lf[26],t9));}
else{
t9=t6;
f_1870(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1870(t7,C_SCHEME_FALSE);}}

/* drop! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1008(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_1008,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1012,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:197: node-class-set! */
t4=*((C_word*)lf[12]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[13];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1726 in k1723 in g328 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1728,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[25];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1010 in drop! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_1012,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:198: node-parameters-set! */
t3=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1013 in k1010 in drop! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_1015,2,av);}
/* lfa2.scm:199: node-subexpressions-set! */
t2=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1723 in g328 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_1725,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
t5=C_eqp(lf[54],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_car(t2);
t8=C_eqp(lf[39],t7);
if(C_truep(t8)){
t9=C_i_cadr(((C_word*)t0)[4]);
t10=C_slot(t9,C_fix(1));
t11=t6;
f_1737(t11,C_eqp(lf[26],t10));}
else{
t9=t6;
f_1737(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1737(t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_car(t2);
t8=t6;
f_1805(t8,C_eqp(lf[25],t7));}
else{
t7=t6;
f_1805(t7,C_SCHEME_FALSE);}}}

/* k1072 in k1048 in k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_1074,2,av);}
/* lfa2.scm:216: string-append */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1497 in k1494 in g307 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1499,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t2;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1494 in g307 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_1496,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[52]+1))){
/* lfa2.scm:285: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1020(t4,t3,((C_word*)t0)[4],lf[53]);}
else{
t4=C_i_cadr(((C_word*)t0)[5]);
t5=C_eqp(lf[54],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_car(t2);
t8=C_eqp(lf[39],t7);
if(C_truep(t8)){
t9=C_i_cadr(((C_word*)t0)[6]);
t10=C_slot(t9,C_fix(1));
t11=t6;
f_1514(t11,C_eqp(lf[26],t10));}
else{
t9=t6;
f_1514(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1514(t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_car(t2);
t8=t6;
f_1582(t8,C_eqp(lf[25],t7));}
else{
t7=t6;
f_1582(t7,C_SCHEME_FALSE);}}}}

/* k1038 in g173 in k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_1040,2,av);}
if(C_truep(t1)){
/* lfa2.scm:208: drop! */
f_1008(((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g307 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1492(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,4)))){
C_save_and_reclaim_args((void *)trf_1492,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1496,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_i_car(((C_word*)t0)[4]);
/* lfa2.scm:283: walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1196(t5,t3,t4,((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k986 in droppable? in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_988,2,av);}
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=((C_word*)t0)[2];
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[8];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k1048 in k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_1050,2,av);}
a=C_alloc(8);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* lfa2.scm:212: drop! */
f_1008(((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[5];
t4=C_slot(t3,C_fix(3));
t5=C_i_length(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1074,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
switch(t5){
case C_fix(1):
/* lfa2.scm:216: string-append */
t7=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[16];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}
case C_fix(2):
/* lfa2.scm:216: string-append */
t7=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[17];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}
case C_fix(3):
/* lfa2.scm:216: string-append */
t7=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[18];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}
default:
/* lfa2.scm:222: bomb */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[20];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}}

/* extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_1020,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1024,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=C_i_car(t6);
/* lfa2.scm:202: report */
t8=((C_word*)((C_word*)t0)[4])[1];
f_912(t8,t4,t7);}

/* g279 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1475(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_1475,3,t0,t1,t2);}
/* lfa2.scm:280: g294 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1196(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_1024,2,av);}
a=C_alloc(20);
t2=((C_word*)t0)[2];
t3=C_slot(t2,C_fix(3));
t4=C_SCHEME_TRUE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=C_i_check_list_2(t3,lf[14]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1050,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1109,a[2]=t10,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_1109(t12,t8,t3);}

/* for-each-loop172 in k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_1109,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1119,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:203: g173 */
t5=((C_word*)t0)[3];
f_1033(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1387 in k1404 in k1416 in k1334 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_1389,2,av);}
t2=((C_word*)t0)[2];
f_1354(t2,C_i_not(t1));}

/* for-each-loop278 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_1933,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1943,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:280: g279 */
t5=((C_word*)t0)[3];
f_1475(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1580 in k1494 in g307 in k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_1582,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_memq(lf[25],t3))){
/* lfa2.scm:297: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1020(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[56]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_member(((C_word*)t0)[7],t3))){
/* lfa2.scm:300: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1020(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[57]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k2086 in for-each-loop415 in k2042 in a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_2088,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2078(t3,((C_word*)t0)[4],t2);}

/* k1483 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_1485,2,av);}
a=C_alloc(8);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_assoc(t2,lf[51]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* lfa2.scm:281: g307 */
t5=t4;
f_1492(t5,((C_word*)t0)[9],t3);}
else{
t4=C_u_i_car(((C_word*)t0)[2]);
t5=C_i_assoc(t4,lf[58]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* lfa2.scm:281: g328 */
t7=t6;
f_1630(t7,((C_word*)t0)[9],t5);}
else{
t6=C_u_i_car(((C_word*)t0)[2]);
t7=C_i_assoc(t6,*((C_word*)lf[0]+1));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:281: g369 */
t9=t8;
f_1860(t9,((C_word*)t0)[9],t7);}
else{
t8=((C_word*)t0)[9];{
C_word *av2=av; /* Re-use our own argvector */
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}}

/* k1416 in k1334 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,2)))){
C_save_and_reclaim((void *)f_1418,2,av);}
a=C_alloc(20);
t2=(C_truep(t1)?((C_word*)t0)[2]:C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),((C_word*)t0)[2]));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1354,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
t6=C_eqp(lf[6],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1406,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:263: assigned? */
t8=((C_word*)((C_word*)t0)[10])[1];
f_941(t8,t7,((C_word*)t0)[3]);}
else{
t7=t4;
f_1354(t7,C_SCHEME_FALSE);}}

/* k1264 in k1253 in k1250 in k1244 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_1266,2,av);}
/* lfa2.scm:247: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1196(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* k1117 in for-each-loop172 in k1022 in extinguish! in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1119(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_1119,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1109(t3,((C_word*)t0)[4],t2);}

/* ##compiler#perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(39,c,5)))){
C_save_and_reclaim((void *)f_795,4,av);}
a=C_alloc(39);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_912,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_941,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t20=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_947,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t21=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1008,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1020,a[2]=t13,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t23=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=t17,a[3]=t9,a[4]=t15,tmp=(C_word)a,a+=5,tmp));
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2029,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:353: walk */
t25=((C_word*)t17)[1];
f_1196(t25,t24,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k1941 in for-each-loop278 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1943(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_1943,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1933(t3,((C_word*)t0)[4],t2);}

/* k2059 in k2056 in k2053 in k2050 in for-each-loop415 in k2042 in a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_2061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2061,2,av);}
/* lfa2.scm:360: ##sys#write-char-0 */
t2=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* g390 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_1955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_1955,3,t0,t1,t2);}
/* lfa2.scm:350: g405 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1196(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* for-each-loop415 in k2042 in a2039 in k2027 in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_2078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_2078,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=*((C_word*)lf[62]+1);
t8=*((C_word*)lf[62]+1);
t9=C_i_check_port_2(*((C_word*)lf[62]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[63]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2052,a[2]=t5,a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:360: ##sys#print */
t11=*((C_word*)lf[65]+1);{
C_word av2[5];
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[67];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[62]+1);
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* report in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_fcall f_912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,1)))){
C_save_and_reclaim_args((void *)trf_912,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_assoc(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t3)){
t4=t1;
t5=C_i_cdr(t3);
t6=C_a_i_plus(&a,2,t5,C_fix(1));
t7=t4;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_i_set_cdr(t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t2,C_fix(1)),((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k1283 in k1250 in k1244 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1285(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_1285,2,av);}
t2=C_i_caddr(((C_word*)t0)[2]);
/* lfa2.scm:252: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1196(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1404 in k1416 in k1334 in walk in perform-secondary-flow-analysis in k746 in k743 in k740 */
static void C_ccall f_1406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1406,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_1354(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(2));
t4=C_i_car(t3);
/* lfa2.scm:264: assigned? */
t5=((C_word*)((C_word*)t0)[4])[1];
f_941(t5,t2,t4);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[67] = {
{"f_1067:lfa2_2escm",(void*)f_1067},
{"f_1514:lfa2_2escm",(void*)f_1514},
{"f_1160:lfa2_2escm",(void*)f_1160},
{"f_1965:lfa2_2escm",(void*)f_1965},
{"f_1967:lfa2_2escm",(void*)f_1967},
{"f_1805:lfa2_2escm",(void*)f_1805},
{"toplevel:lfa2_2escm",(void*)C_lfa2_toplevel},
{"f_1170:lfa2_2escm",(void*)f_1170},
{"f_1336:lfa2_2escm",(void*)f_1336},
{"f_1278:lfa2_2escm",(void*)f_1278},
{"f_1246:lfa2_2escm",(void*)f_1246},
{"f_1252:lfa2_2escm",(void*)f_1252},
{"f_1255:lfa2_2escm",(void*)f_1255},
{"f_1196:lfa2_2escm",(void*)f_1196},
{"f_2044:lfa2_2escm",(void*)f_2044},
{"f_2040:lfa2_2escm",(void*)f_2040},
{"f_2055:lfa2_2escm",(void*)f_2055},
{"f_2058:lfa2_2escm",(void*)f_2058},
{"f_2052:lfa2_2escm",(void*)f_2052},
{"f_941:lfa2_2escm",(void*)f_941},
{"f_1630:lfa2_2escm",(void*)f_1630},
{"f_947:lfa2_2escm",(void*)f_947},
{"f_2029:lfa2_2escm",(void*)f_2029},
{"f_1433:lfa2_2escm",(void*)f_1433},
{"f_1977:lfa2_2escm",(void*)f_1977},
{"f_1737:lfa2_2escm",(void*)f_1737},
{"f_1449:lfa2_2escm",(void*)f_1449},
{"f_1354:lfa2_2escm",(void*)f_1354},
{"f_1033:lfa2_2escm",(void*)f_1033},
{"f_1870:lfa2_2escm",(void*)f_1870},
{"f_742:lfa2_2escm",(void*)f_742},
{"f_745:lfa2_2escm",(void*)f_745},
{"f_748:lfa2_2escm",(void*)f_748},
{"f_1860:lfa2_2escm",(void*)f_1860},
{"f_1008:lfa2_2escm",(void*)f_1008},
{"f_1728:lfa2_2escm",(void*)f_1728},
{"f_1012:lfa2_2escm",(void*)f_1012},
{"f_1015:lfa2_2escm",(void*)f_1015},
{"f_1725:lfa2_2escm",(void*)f_1725},
{"f_1074:lfa2_2escm",(void*)f_1074},
{"f_1499:lfa2_2escm",(void*)f_1499},
{"f_1496:lfa2_2escm",(void*)f_1496},
{"f_1040:lfa2_2escm",(void*)f_1040},
{"f_1492:lfa2_2escm",(void*)f_1492},
{"f_988:lfa2_2escm",(void*)f_988},
{"f_1050:lfa2_2escm",(void*)f_1050},
{"f_1020:lfa2_2escm",(void*)f_1020},
{"f_1475:lfa2_2escm",(void*)f_1475},
{"f_1024:lfa2_2escm",(void*)f_1024},
{"f_1109:lfa2_2escm",(void*)f_1109},
{"f_1389:lfa2_2escm",(void*)f_1389},
{"f_1933:lfa2_2escm",(void*)f_1933},
{"f_1582:lfa2_2escm",(void*)f_1582},
{"f_2088:lfa2_2escm",(void*)f_2088},
{"f_1485:lfa2_2escm",(void*)f_1485},
{"f_1418:lfa2_2escm",(void*)f_1418},
{"f_1266:lfa2_2escm",(void*)f_1266},
{"f_1119:lfa2_2escm",(void*)f_1119},
{"f_795:lfa2_2escm",(void*)f_795},
{"f_1943:lfa2_2escm",(void*)f_1943},
{"f_2061:lfa2_2escm",(void*)f_2061},
{"f_1955:lfa2_2escm",(void*)f_1955},
{"f_2078:lfa2_2escm",(void*)f_2078},
{"f_912:lfa2_2escm",(void*)f_912},
{"f_1285:lfa2_2escm",(void*)f_1285},
{"f_1406:lfa2_2escm",(void*)f_1406},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		4
S|  printf		2
o|eliminated procedure checks: 45 
o|specializations:
o|  6 (first pair)
o|  3 (car pair)
o|  6 (cdr pair)
o|  1 (caar (pair pair *))
o|  3 (eqv? (not float) *)
o|  1 (memq * list)
o|  15 (eqv? * (not float))
o|  1 (make-string fixnum char)
o|  2 (##sys#check-output-port * * *)
(o e)|safe calls: 178 
(o e)|assignments to immediate values: 1 
o|safe globals: (##compiler#perform-secondary-flow-analysis +constructor-map+ +predicate-map+ +type-check-map+ dd d lfa2-debug d-depth) 
o|Removed `not' forms: 2 
o|removed side-effect free assignment to unused variable: lfa2-debug 
o|propagated global variable: out2832 ##sys#standard-output 
o|substituted constant variable: a761 
o|substituted constant variable: a762 
o|inlining procedure: k754 
o|substituted constant variable: d-depth 
o|substituted constant variable: d-depth 
o|substituted constant variable: a786 
o|substituted constant variable: d-depth 
o|propagated global variable: out2832 ##sys#standard-output 
o|inlining procedure: k754 
o|removed side-effect free assignment to unused variable: dd 
o|inlining procedure: k917 
o|contracted procedure: "(lfa2.scm:155) g131132" 
o|inlining procedure: k917 
o|substituted constant variable: a958 
o|inlining procedure: k959 
o|inlining procedure: k959 
o|inlining procedure: k974 
o|inlining procedure: k974 
o|contracted procedure: "(lfa2.scm:194) g153154" 
o|contracted procedure: "(lfa2.scm:192) g147148" 
o|contracted procedure: "(lfa2.scm:191) g143144" 
o|contracted procedure: "(lfa2.scm:189) g139140" 
o|inlining procedure: k1035 
o|inlining procedure: k1035 
o|inlining procedure: k1051 
o|inlining procedure: k1051 
o|inlining procedure: k1072 
o|inlining procedure: k1072 
o|inlining procedure: k1084 
o|inlining procedure: k1084 
o|substituted constant variable: a1094 
o|substituted constant variable: a1096 
o|substituted constant variable: a1098 
o|contracted procedure: "(lfa2.scm:218) g194195" 
o|inlining procedure: k1111 
o|inlining procedure: k1111 
o|contracted procedure: "(lfa2.scm:203) g167168" 
o|contracted procedure: "(lfa2.scm:202) g162163" 
o|inlining procedure: k1222 
o|contracted procedure: "(lfa2.scm:240) vartype107" 
o|inlining procedure: k1150 
o|inlining procedure: k1150 
o|inlining procedure: k1162 
o|inlining procedure: k1162 
o|inlining procedure: k1222 
o|inlining procedure: k1247 
o|inlining procedure: k1247 
o|inlining procedure: k1309 
o|contracted procedure: "(lfa2.scm:253) constant-result101" 
o|inlining procedure: k800 
o|inlining procedure: k800 
o|inlining procedure: k812 
o|inlining procedure: k812 
o|inlining procedure: k824 
o|inlining procedure: k836 
o|inlining procedure: k836 
o|substituted constant variable: a843 
o|propagated global variable: tmp114119 number-type 
o|substituted constant variable: a845 
o|inlining procedure: k824 
o|inlining procedure: k852 
o|inlining procedure: k852 
o|inlining procedure: k864 
o|inlining procedure: k864 
o|inlining procedure: k876 
o|inlining procedure: k876 
o|inlining procedure: k895 
o|inlining procedure: k895 
o|contracted procedure: k901 
o|inlining procedure: k1309 
o|inlining procedure: k1349 
o|contracted procedure: "(lfa2.scm:265) g262263" 
o|inlining procedure: k1349 
o|contracted procedure: k1380 
o|inlining procedure: k1377 
o|inlining procedure: k1377 
o|contracted procedure: "(lfa2.scm:264) g258259" 
o|contracted procedure: "(lfa2.scm:262) g254255" 
o|inlining procedure: k1422 
o|inlining procedure: k1422 
o|inlining procedure: k1454 
o|inlining procedure: k1454 
o|inlining procedure: k1466 
o|inlining procedure: k1497 
o|inlining procedure: k1497 
o|inlining procedure: k1509 
o|contracted procedure: "(lfa2.scm:291) g321322" 
o|inlining procedure: k1509 
o|inlining procedure: k1553 
o|contracted procedure: "(lfa2.scm:290) g317318" 
o|inlining procedure: k1553 
o|inlining procedure: k1577 
o|inlining procedure: k1577 
o|inlining procedure: k1635 
o|inlining procedure: k1657 
o|inlining procedure: k1672 
o|inlining procedure: k1672 
o|contracted procedure: "(lfa2.scm:312) g345346" 
o|contracted procedure: "(lfa2.scm:310) g341342" 
o|inlining procedure: k1657 
o|contracted procedure: "(lfa2.scm:307) g338339" 
o|inlining procedure: k1635 
o|inlining procedure: k1732 
o|contracted procedure: "(lfa2.scm:327) g362363" 
o|inlining procedure: k1732 
o|inlining procedure: k1776 
o|contracted procedure: "(lfa2.scm:325) g358359" 
o|inlining procedure: k1776 
o|inlining procedure: k1800 
o|inlining procedure: k1800 
o|contracted procedure: "(lfa2.scm:305) g332333" 
o|inlining procedure: k1627 
o|inlining procedure: k1627 
o|inlining procedure: k1865 
o|contracted procedure: "(lfa2.scm:344) g380381" 
o|inlining procedure: k1865 
o|inlining procedure: k1895 
o|contracted procedure: "(lfa2.scm:343) g376377" 
o|inlining procedure: k1895 
o|substituted constant variable: +predicate-map+ 
o|substituted constant variable: +type-check-map+ 
o|inlining procedure: k1935 
o|inlining procedure: k1935 
o|inlining procedure: k1466 
o|inlining procedure: k1969 
o|inlining procedure: k1969 
o|substituted constant variable: a1993 
o|substituted constant variable: a1995 
o|substituted constant variable: a1997 
o|substituted constant variable: a1999 
o|substituted constant variable: a2004 
o|substituted constant variable: a2006 
o|substituted constant variable: a2011 
o|substituted constant variable: a2013 
o|substituted constant variable: a2015 
o|substituted constant variable: a2017 
o|substituted constant variable: a2022 
o|substituted constant variable: a2024 
o|substituted constant variable: a2026 
o|contracted procedure: "(lfa2.scm:237) g230231" 
o|contracted procedure: "(lfa2.scm:236) g227228" 
o|contracted procedure: "(lfa2.scm:235) g224225" 
o|inlining procedure: k2030 
o|inlining procedure: k2080 
o|contracted procedure: "(lfa2.scm:359) g416423" 
o|propagated global variable: out426430 ##sys#standard-output 
o|substituted constant variable: a2048 
o|substituted constant variable: a2049 
o|propagated global variable: out426430 ##sys#standard-output 
o|inlining procedure: k2080 
o|inlining procedure: k2030 
o|replaced variables: 298 
o|removed binding forms: 84 
o|removed side-effect free assignment to unused variable: d-depth 
o|removed side-effect free assignment to unused variable: d 
o|removed side-effect free assignment to unused variable: +type-check-map+ 
o|removed side-effect free assignment to unused variable: +predicate-map+ 
o|substituted constant variable: mark156 
o|substituted constant variable: r10732112 
o|substituted constant variable: r10732112 
o|inlining procedure: k1072 
o|inlining procedure: k1072 
o|substituted constant variable: r10852116 
o|substituted constant variable: r11632123 
o|substituted constant variable: r8012129 
o|substituted constant variable: r8132131 
o|substituted constant variable: r8372134 
o|substituted constant variable: r8372135 
o|propagated global variable: tmp114119 number-type 
o|substituted constant variable: r8532137 
o|substituted constant variable: r8652139 
o|substituted constant variable: r8772141 
o|substituted constant variable: r8962143 
o|substituted constant variable: r8962144 
o|substituted constant variable: r13782150 
o|substituted constant variable: r14232152 
o|substituted constant variable: r14552154 
o|inlining procedure: k1497 
o|inlining procedure: k1497 
o|substituted constant variable: r15542164 
o|inlining procedure: k1497 
o|inlining procedure: k1497 
o|inlining procedure: k1657 
o|substituted constant variable: r16732171 
o|inlining procedure: k1657 
o|substituted constant variable: r16362174 
o|inlining procedure: k1726 
o|inlining procedure: k1726 
o|substituted constant variable: r17772178 
o|inlining procedure: k1726 
o|inlining procedure: k1726 
o|substituted constant variable: r18962186 
o|substituted constant variable: r14672189 
o|propagated global variable: out426430 ##sys#standard-output 
o|replaced variables: 13 
o|removed binding forms: 282 
o|inlining procedure: k1521 
o|substituted constant variable: r16582210 
o|substituted constant variable: r16582212 
o|substituted constant variable: r163621742215 
o|substituted constant variable: r163621742217 
o|substituted constant variable: r163621742219 
o|substituted constant variable: r163621742221 
o|replaced variables: 30 
o|removed binding forms: 52 
o|substituted constant variable: r10732196 
o|substituted constant variable: r10732198 
o|substituted constant variable: r15222234 
o|inlining procedure: k1744 
o|removed binding forms: 39 
o|removed conditional forms: 1 
o|substituted constant variable: r17452246 
o|removed binding forms: 4 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 10) (##core#call . 175)) 
o|  call simplifications:
o|    car
o|    ##sys#cons	3
o|    cadr	6
o|    member	2
o|    memq	2
o|    string?
o|    symbol?	5
o|    fixnum?
o|    flonum?
o|    number?
o|    boolean?
o|    list?
o|    eof-object?
o|    vector?
o|    ##sys#immediate?
o|    ##sys#generic-structure?
o|    char?
o|    ##sys#list	5
o|    second	12
o|    third	3
o|    null?	2
o|    cdar
o|    assq	2
o|    ##sys#check-list	4
o|    pair?	12
o|    length
o|    list
o|    eq?	37
o|    ##sys#slot	31
o|    first	19
o|    not	2
o|    assoc	4
o|    alist-cons	4
o|    cdr	3
o|    add1
o|    set-cdr!
o|contracted procedure: k914 
o|contracted procedure: k930 
o|contracted procedure: k926 
o|contracted procedure: k937 
o|contracted procedure: k955 
o|contracted procedure: k1004 
o|contracted procedure: k965 
o|contracted procedure: k995 
o|contracted procedure: k968 
o|contracted procedure: k971 
o|contracted procedure: k1030 
o|contracted procedure: k1045 
o|contracted procedure: k1061 
o|contracted procedure: k1105 
o|contracted procedure: k1069 
o|contracted procedure: k1075 
o|contracted procedure: k1081 
o|contracted procedure: k1087 
o|contracted procedure: k1114 
o|contracted procedure: k1124 
o|contracted procedure: k1128 
o|contracted procedure: k1141 
o|contracted procedure: k1132 
o|contracted procedure: k1203 
o|contracted procedure: k1211 
o|contracted procedure: k1219 
o|contracted procedure: k1225 
o|contracted procedure: k1232 
o|contracted procedure: k1147 
o|contracted procedure: k1165 
o|contracted procedure: k1192 
o|contracted procedure: k1182 
o|contracted procedure: k1238 
o|contracted procedure: k1241 
o|contracted procedure: k1260 
o|contracted procedure: k1268 
o|contracted procedure: k1272 
o|contracted procedure: k1280 
o|contracted procedure: k1290 
o|contracted procedure: k1294 
o|contracted procedure: k1297 
o|contracted procedure: k1306 
o|contracted procedure: k1312 
o|contracted procedure: k1319 
o|contracted procedure: k803 
o|contracted procedure: k809 
o|contracted procedure: k815 
o|contracted procedure: k821 
o|contracted procedure: k827 
o|contracted procedure: k833 
o|contracted procedure: k839 
o|contracted procedure: k849 
o|contracted procedure: k855 
o|contracted procedure: k861 
o|contracted procedure: k867 
o|contracted procedure: k873 
o|contracted procedure: k879 
o|contracted procedure: k908 
o|contracted procedure: k885 
o|contracted procedure: k892 
o|contracted procedure: k898 
o|contracted procedure: k1325 
o|contracted procedure: k1328 
o|contracted procedure: k1331 
o|contracted procedure: k1341 
o|contracted procedure: k1345 
o|contracted procedure: k1371 
o|contracted procedure: k1355 
o|contracted procedure: k1362 
o|contracted procedure: k1349 
o|contracted procedure: k1413 
o|contracted procedure: k1374 
o|contracted procedure: k1400 
o|contracted procedure: k1391 
o|contracted procedure: k1425 
o|contracted procedure: k1428 
o|contracted procedure: k1435 
o|contracted procedure: k1441 
o|contracted procedure: k1444 
o|contracted procedure: k1451 
o|contracted procedure: k1457 
o|contracted procedure: k1463 
o|contracted procedure: k1469 
o|contracted procedure: k1472 
o|contracted procedure: k1480 
o|contracted procedure: k1929 
o|contracted procedure: k1486 
o|contracted procedure: k1614 
o|contracted procedure: k1506 
o|contracted procedure: k1547 
o|contracted procedure: k1543 
o|contracted procedure: k1515 
o|contracted procedure: k1527 
o|contracted procedure: k1534 
o|contracted procedure: k1521 
o|contracted procedure: k1550 
o|contracted procedure: k1556 
o|contracted procedure: k1572 
o|contracted procedure: k1568 
o|contracted procedure: k1586 
o|contracted procedure: k1597 
o|contracted procedure: k1605 
o|contracted procedure: k1618 
o|contracted procedure: k1624 
o|contracted procedure: k1632 
o|contracted procedure: k1848 
o|contracted procedure: k1638 
o|contracted procedure: k1645 
o|contracted procedure: k1720 
o|contracted procedure: k1653 
o|contracted procedure: k1711 
o|contracted procedure: k1660 
o|contracted procedure: k1704 
o|contracted procedure: k1700 
o|contracted procedure: k1666 
o|contracted procedure: k1691 
o|contracted procedure: k1687 
o|contracted procedure: k1669 
o|contracted procedure: k1675 
o|inlining procedure: k1657 
o|inlining procedure: k1657 
o|contracted procedure: k1837 
o|contracted procedure: k1729 
o|contracted procedure: k1770 
o|contracted procedure: k1766 
o|contracted procedure: k1738 
o|contracted procedure: k1750 
o|contracted procedure: k1757 
o|contracted procedure: k1744 
o|contracted procedure: k1773 
o|contracted procedure: k1779 
o|contracted procedure: k1795 
o|contracted procedure: k1791 
o|contracted procedure: k1809 
o|contracted procedure: k1820 
o|contracted procedure: k1828 
o|contracted procedure: k1854 
o|contracted procedure: k1917 
o|contracted procedure: k1862 
o|contracted procedure: k1889 
o|contracted procedure: k1871 
o|contracted procedure: k1877 
o|contracted procedure: k1914 
o|contracted procedure: k1898 
o|contracted procedure: k1910 
o|contracted procedure: k1938 
o|contracted procedure: k1948 
o|contracted procedure: k1952 
o|contracted procedure: k1960 
o|contracted procedure: k1972 
o|contracted procedure: k1982 
o|contracted procedure: k1986 
o|contracted procedure: k2033 
o|contracted procedure: k2071 
o|contracted procedure: k2083 
o|contracted procedure: k2093 
o|contracted procedure: k2097 
o|contracted procedure: k2068 
o|simplifications: ((let . 31)) 
o|removed binding forms: 156 
o|inlining procedure: k1649 
o|inlining procedure: k1649 
o|inlining procedure: k1649 
o|inlining procedure: k1649 
o|replaced variables: 51 
o|removed binding forms: 1 
o|replaced variables: 4 
o|removed binding forms: 16 
o|removed binding forms: 1 
o|customizable procedures: (for-each-loop415436 g390397 for-each-loop389407 g279286 for-each-loop278296 g369370 k1868 g328329 k1803 k1735 g307308 k1580 k1512 extinguish!106 assigned?103 k1352 k1250 walk108 k1168 loop208 report102 g173180 for-each-loop172183 droppable?104 drop!105) 
o|calls to known targets: 65 
o|identified direct recursive calls: f_1196 4 
o|fast box initializations: 11 
o|dropping unused closure argument: f_1008 
*/
/* end of file */
