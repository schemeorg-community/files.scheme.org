/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:50
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[416];
static double C_possibly_force_alignment;


C_noret_decl(f5700)
static void C_ccall f5700(C_word c,C_word *av) C_noret;
C_noret_decl(f_3880)
static void C_fcall f_3880(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word *av) C_noret;
C_noret_decl(f_4373)
static void C_fcall f_4373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5774)
static void C_ccall f5774(C_word c,C_word *av) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word *av) C_noret;
C_noret_decl(f_4509)
static void C_fcall f_4509(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word *av) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word *av) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word *av) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word *av) C_noret;
C_noret_decl(f_3219)
static void C_fcall f_3219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word *av) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word *av) C_noret;
C_noret_decl(f5792)
static void C_ccall f5792(C_word c,C_word *av) C_noret;
C_noret_decl(f5798)
static void C_ccall f5798(C_word c,C_word *av) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word *av) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word *av) C_noret;
C_noret_decl(f_3836)
static void C_fcall f_3836(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word *av) C_noret;
C_noret_decl(f5644)
static void C_ccall f5644(C_word c,C_word *av) C_noret;
C_noret_decl(f5764)
static void C_ccall f5764(C_word c,C_word *av) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word *av) C_noret;
C_noret_decl(f5752)
static void C_ccall f5752(C_word c,C_word *av) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word *av) C_noret;
C_noret_decl(f5758)
static void C_ccall f5758(C_word c,C_word *av) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word *av) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word *av) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word *av) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word *av) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word *av) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word *av) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word *av) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word *av) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word *av) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word *av) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word *av) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word *av) C_noret;
C_noret_decl(f_2484)
static void C_fcall f_2484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word *av) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word *av) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word *av) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word *av) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word *av) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word *av) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word *av) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word *av) C_noret;
C_noret_decl(f_2456)
static void C_fcall f_2456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word *av) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word *av) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word *av) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word *av) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word *av) C_noret;
C_noret_decl(f_4396)
static void C_fcall f_4396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5662)
static void C_ccall f5662(C_word c,C_word *av) C_noret;
C_noret_decl(f5668)
static void C_ccall f5668(C_word c,C_word *av) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word *av) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word *av) C_noret;
C_noret_decl(f5656)
static void C_ccall f5656(C_word c,C_word *av) C_noret;
C_noret_decl(f5650)
static void C_ccall f5650(C_word c,C_word *av) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word *av) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word *av) C_noret;
C_noret_decl(f5680)
static void C_ccall f5680(C_word c,C_word *av) C_noret;
C_noret_decl(f5688)
static void C_ccall f5688(C_word c,C_word *av) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word *av) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word *av) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word *av) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word *av) C_noret;
C_noret_decl(f_3747)
static void C_fcall f_3747(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word *av) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word *av) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word *av) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word *av) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word *av) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word *av) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word *av) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word *av) C_noret;
C_noret_decl(f_2150)
static void C_fcall f_2150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word *av) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word *av) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word *av) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word *av) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word *av) C_noret;
C_noret_decl(f_2431)
static void C_fcall f_2431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word *av) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word *av) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word *av) C_noret;
C_noret_decl(f_1805)
static void C_fcall f_1805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_fcall f_2145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word *av) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word *av) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word *av) C_noret;
C_noret_decl(f_2122)
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2120)
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word *av) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word *av) C_noret;
C_noret_decl(f_3255)
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word *av) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word *av) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word *av) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word *av) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word *av) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word *av) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word *av) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word *av) C_noret;
C_noret_decl(f_3679)
static void C_fcall f_3679(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word *av) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word *av) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word *av) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word *av) C_noret;
C_noret_decl(f_2583)
static void C_fcall f_2583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word *av) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word *av) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word *av) C_noret;
C_noret_decl(f_2186)
static void C_fcall f_2186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word *av) C_noret;
C_noret_decl(f_2574)
static void C_fcall f_2574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_fcall f_2189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word *av) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word *av) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word *av) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word *av) C_noret;
C_noret_decl(f_2565)
static void C_fcall f_2565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word *av) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word *av) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word *av) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word *av) C_noret;
C_noret_decl(f_3324)
static void C_fcall f_3324(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word *av) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word *av) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word *av) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word *av) C_noret;
C_noret_decl(f_4446)
static void C_fcall f_4446(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word *av) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word *av) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word *av) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word *av) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word *av) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word *av) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word *av) C_noret;
C_noret_decl(f_3951)
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2041)
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word *av) C_noret;
C_noret_decl(f_2049)
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word *av) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word *av) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word *av) C_noret;
C_noret_decl(f_3917)
static void C_fcall f_3917(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word *av) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word *av) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word *av) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word *av) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word *av) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word *av) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word *av) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word *av) C_noret;
C_noret_decl(f_2080)
static void C_fcall f_2080(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word *av) C_noret;
C_noret_decl(f_2070)
static void C_fcall f_2070(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word *av) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word *av) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word *av) C_noret;
C_noret_decl(f_4010)
static void C_fcall f_4010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word *av) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word *av) C_noret;
C_noret_decl(f_3572)
static void C_fcall f_3572(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_fcall f_2035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word *av) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word *av) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word *av) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word *av) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word *av) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word *av) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word *av) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word *av) C_noret;
C_noret_decl(f_2322)
static void C_fcall f_2322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_fcall f_2317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_fcall f_2312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word *av) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word *av) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word *av) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word *av) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word *av) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word *av) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word *av) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word *av) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word *av) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word *av) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word *av) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word *av) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word *av) C_noret;
C_noret_decl(f_3113)
static void C_fcall f_3113(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word *av) C_noret;
C_noret_decl(f_2362)
static void C_fcall f_2362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_fcall f_2365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word *av) C_noret;
C_noret_decl(f_2356)
static void C_fcall f_2356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word *av) C_noret;
C_noret_decl(f_2359)
static void C_fcall f_2359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word *av) C_noret;
C_noret_decl(f_2353)
static void C_fcall f_2353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_fcall f_1779(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word *av) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word *av) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word *av) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word *av) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word *av) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word *av) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word *av) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word *av) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word *av) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word *av) C_noret;
C_noret_decl(f_2301)
static void C_fcall f_2301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_fcall f_2304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word *av) C_noret;
C_noret_decl(f_3496)
static void C_fcall f_3496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word *av) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word *av) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word *av) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word *av) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word *av) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word *av) C_noret;
C_noret_decl(f_2262)
static void C_fcall f_2262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_fcall f_2265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_fcall f_2268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word *av) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word *av) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word *av) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word *av) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word *av) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word *av) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word *av) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word *av) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word *av) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word *av) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word *av) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word *av) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word *av) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word *av) C_noret;
C_noret_decl(f_2244)
static void C_fcall f_2244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word *av) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word *av) C_noret;
C_noret_decl(f_4797)
static void C_fcall f_4797(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word *av) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word *av) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word *av) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word *av) C_noret;
C_noret_decl(f_2271)
static void C_fcall f_2271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_fcall f_3444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word *av) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word *av) C_noret;
C_noret_decl(f_2274)
static void C_fcall f_2274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word *av) C_noret;
C_noret_decl(f_2277)
static void C_fcall f_2277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word *av) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word *av) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word *av) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word *av) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word *av) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word *av) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word *av) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word *av) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word *av) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word *av) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word *av) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word *av) C_noret;
C_noret_decl(f_2250)
static void C_fcall f_2250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word *av) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word *av) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word *av) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word *av) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word *av) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word *av) C_noret;
C_noret_decl(f_2237)
static void C_fcall f_2237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_fcall f_2286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_fcall f_2283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word *av) C_noret;
C_noret_decl(f_2280)
static void C_fcall f_2280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_fcall f_2289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word *av) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word *av) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word *av) C_noret;
C_noret_decl(f_4215)
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2295)
static void C_fcall f_2295(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_fcall f_2292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_fcall f_2298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word *av) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word *av) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word *av) C_noret;
C_noret_decl(f_4192)
static void C_fcall f_4192(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word *av) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word *av) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word *av) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word *av) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word *av) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word *av) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word *av) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word *av) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word *av) C_noret;
C_noret_decl(f_4869)
static void C_fcall f_4869(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word *av) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word *av) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word *av) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word *av) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word *av) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word *av) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word *av) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word *av) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word *av) C_noret;
C_noret_decl(f_4733)
static void C_fcall f_4733(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word *av) C_noret;
C_noret_decl(f_4158)
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word *av) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word *av) C_noret;
C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_3165)
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word *av) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word *av) C_noret;
C_noret_decl(f_3713)
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word *av) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word *av) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word *av) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word *av) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word *av) C_noret;
C_noret_decl(f5816)
static void C_ccall f5816(C_word c,C_word *av) C_noret;
C_noret_decl(f5810)
static void C_ccall f5810(C_word c,C_word *av) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word *av) C_noret;
C_noret_decl(f5804)
static void C_ccall f5804(C_word c,C_word *av) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word *av) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word *av) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word *av) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word *av) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word *av) C_noret;
C_noret_decl(f_1945)
static void C_fcall f_1945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word *av) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word *av) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word *av) C_noret;
C_noret_decl(f_2665)
static void C_fcall f_2665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word *av) C_noret;
C_noret_decl(f_1922)
static void C_fcall f_1922(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word *av) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word *av) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word *av) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word *av) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word *av) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word *av) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_fcall f_3090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word *av) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word *av) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word *av) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word *av) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word *av) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word *av) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word *av) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word *av) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word *av) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word *av) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word *av) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word *av) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word *av) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word *av) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word *av) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word *av) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word *av) C_noret;
C_noret_decl(f_4248)
static void C_fcall f_4248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word *av) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word *av) C_noret;
C_noret_decl(f_3616)
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2688)
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word *av) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word *av) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word *av) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word *av) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word *av) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word *av) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word *av) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word *av) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word *av) C_noret;
C_noret_decl(f5247)
static void C_ccall f5247(C_word c,C_word *av) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word *av) C_noret;
C_noret_decl(f_1872)
static void C_fcall f_1872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word *av) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word *av) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word *av) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word *av) C_noret;
C_noret_decl(f_4909)
static void C_fcall f_4909(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1899)
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word *av) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word *av) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word *av) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word *av) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word *av) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word *av) C_noret;
C_noret_decl(f5726)
static void C_ccall f5726(C_word c,C_word *av) C_noret;
C_noret_decl(f5720)
static void C_ccall f5720(C_word c,C_word *av) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word *av) C_noret;
C_noret_decl(f_1850)
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word *av) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word *av) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word *av) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word *av) C_noret;
C_noret_decl(f_1823)
static void C_fcall f_1823(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word *av) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word *av) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word *av) C_noret;
C_noret_decl(f5746)
static void C_ccall f5746(C_word c,C_word *av) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word *av) C_noret;
C_noret_decl(f5740)
static void C_ccall f5740(C_word c,C_word *av) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word *av) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word *av) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word *av) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word *av) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word *av) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word *av) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word *av) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word *av) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word *av) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word *av) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word *av) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word *av) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word *av) C_noret;

C_noret_decl(trf_3880)
static void C_ccall trf_3880(C_word c,C_word *av) C_noret;
static void C_ccall trf_3880(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3880(t0,t1,t2);}

C_noret_decl(trf_4373)
static void C_ccall trf_4373(C_word c,C_word *av) C_noret;
static void C_ccall trf_4373(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4373(t0,t1,t2);}

C_noret_decl(trf_4509)
static void C_ccall trf_4509(C_word c,C_word *av) C_noret;
static void C_ccall trf_4509(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4509(t0,t1,t2);}

C_noret_decl(trf_3219)
static void C_ccall trf_3219(C_word c,C_word *av) C_noret;
static void C_ccall trf_3219(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3219(t0,t1,t2);}

C_noret_decl(trf_3836)
static void C_ccall trf_3836(C_word c,C_word *av) C_noret;
static void C_ccall trf_3836(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3836(t0,t1,t2);}

C_noret_decl(trf_2484)
static void C_ccall trf_2484(C_word c,C_word *av) C_noret;
static void C_ccall trf_2484(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2484(t0,t1);}

C_noret_decl(trf_2456)
static void C_ccall trf_2456(C_word c,C_word *av) C_noret;
static void C_ccall trf_2456(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2456(t0,t1);}

C_noret_decl(trf_4396)
static void C_ccall trf_4396(C_word c,C_word *av) C_noret;
static void C_ccall trf_4396(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4396(t0,t1,t2);}

C_noret_decl(trf_3747)
static void C_ccall trf_3747(C_word c,C_word *av) C_noret;
static void C_ccall trf_3747(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3747(t0,t1,t2);}

C_noret_decl(trf_2150)
static void C_ccall trf_2150(C_word c,C_word *av) C_noret;
static void C_ccall trf_2150(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2150(t0,t1);}

C_noret_decl(trf_2431)
static void C_ccall trf_2431(C_word c,C_word *av) C_noret;
static void C_ccall trf_2431(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2431(t0,t1);}

C_noret_decl(trf_1805)
static void C_ccall trf_1805(C_word c,C_word *av) C_noret;
static void C_ccall trf_1805(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1805(t0,t1);}

C_noret_decl(trf_2145)
static void C_ccall trf_2145(C_word c,C_word *av) C_noret;
static void C_ccall trf_2145(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2145(t0,t1,t2);}

C_noret_decl(trf_2122)
static void C_ccall trf_2122(C_word c,C_word *av) C_noret;
static void C_ccall trf_2122(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2122(t0,t1,t2,t3);}

C_noret_decl(trf_2120)
static void C_ccall trf_2120(C_word c,C_word *av) C_noret;
static void C_ccall trf_2120(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2120(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3255)
static void C_ccall trf_3255(C_word c,C_word *av) C_noret;
static void C_ccall trf_3255(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3255(t0,t1,t2);}

C_noret_decl(trf_3679)
static void C_ccall trf_3679(C_word c,C_word *av) C_noret;
static void C_ccall trf_3679(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3679(t0,t1,t2);}

C_noret_decl(trf_2583)
static void C_ccall trf_2583(C_word c,C_word *av) C_noret;
static void C_ccall trf_2583(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2583(t0,t1);}

C_noret_decl(trf_2186)
static void C_ccall trf_2186(C_word c,C_word *av) C_noret;
static void C_ccall trf_2186(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2186(t0,t1);}

C_noret_decl(trf_2574)
static void C_ccall trf_2574(C_word c,C_word *av) C_noret;
static void C_ccall trf_2574(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2574(t0,t1);}

C_noret_decl(trf_2189)
static void C_ccall trf_2189(C_word c,C_word *av) C_noret;
static void C_ccall trf_2189(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2189(t0,t1);}

C_noret_decl(trf_2565)
static void C_ccall trf_2565(C_word c,C_word *av) C_noret;
static void C_ccall trf_2565(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2565(t0,t1);}

C_noret_decl(trf_3324)
static void C_ccall trf_3324(C_word c,C_word *av) C_noret;
static void C_ccall trf_3324(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3324(t0,t1,t2);}

C_noret_decl(trf_4446)
static void C_ccall trf_4446(C_word c,C_word *av) C_noret;
static void C_ccall trf_4446(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4446(t0,t1,t2);}

C_noret_decl(trf_3951)
static void C_ccall trf_3951(C_word c,C_word *av) C_noret;
static void C_ccall trf_3951(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3951(t0,t1,t2);}

C_noret_decl(trf_2041)
static void C_ccall trf_2041(C_word c,C_word *av) C_noret;
static void C_ccall trf_2041(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2041(t0,t1,t2);}

C_noret_decl(trf_2049)
static void C_ccall trf_2049(C_word c,C_word *av) C_noret;
static void C_ccall trf_2049(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2049(t0,t1,t2);}

C_noret_decl(trf_3917)
static void C_ccall trf_3917(C_word c,C_word *av) C_noret;
static void C_ccall trf_3917(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3917(t0,t1,t2);}

C_noret_decl(trf_2080)
static void C_ccall trf_2080(C_word c,C_word *av) C_noret;
static void C_ccall trf_2080(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2080(t0,t1,t2);}

C_noret_decl(trf_2070)
static void C_ccall trf_2070(C_word c,C_word *av) C_noret;
static void C_ccall trf_2070(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2070(t0,t1);}

C_noret_decl(trf_4010)
static void C_ccall trf_4010(C_word c,C_word *av) C_noret;
static void C_ccall trf_4010(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4010(t0,t1);}

C_noret_decl(trf_3572)
static void C_ccall trf_3572(C_word c,C_word *av) C_noret;
static void C_ccall trf_3572(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3572(t0,t1);}

C_noret_decl(trf_2035)
static void C_ccall trf_2035(C_word c,C_word *av) C_noret;
static void C_ccall trf_2035(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2035(t0,t1,t2);}

C_noret_decl(trf_2322)
static void C_ccall trf_2322(C_word c,C_word *av) C_noret;
static void C_ccall trf_2322(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2322(t0,t1);}

C_noret_decl(trf_2317)
static void C_ccall trf_2317(C_word c,C_word *av) C_noret;
static void C_ccall trf_2317(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2317(t0,t1);}

C_noret_decl(trf_2312)
static void C_ccall trf_2312(C_word c,C_word *av) C_noret;
static void C_ccall trf_2312(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2312(t0,t1);}

C_noret_decl(trf_3113)
static void C_ccall trf_3113(C_word c,C_word *av) C_noret;
static void C_ccall trf_3113(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3113(t0,t1,t2);}

C_noret_decl(trf_2362)
static void C_ccall trf_2362(C_word c,C_word *av) C_noret;
static void C_ccall trf_2362(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2362(t0,t1);}

C_noret_decl(trf_2365)
static void C_ccall trf_2365(C_word c,C_word *av) C_noret;
static void C_ccall trf_2365(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2365(t0,t1);}

C_noret_decl(trf_2356)
static void C_ccall trf_2356(C_word c,C_word *av) C_noret;
static void C_ccall trf_2356(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2356(t0,t1);}

C_noret_decl(trf_2359)
static void C_ccall trf_2359(C_word c,C_word *av) C_noret;
static void C_ccall trf_2359(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2359(t0,t1);}

C_noret_decl(trf_2353)
static void C_ccall trf_2353(C_word c,C_word *av) C_noret;
static void C_ccall trf_2353(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2353(t0,t1);}

C_noret_decl(trf_1779)
static void C_ccall trf_1779(C_word c,C_word *av) C_noret;
static void C_ccall trf_1779(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1779(t0,t1);}

C_noret_decl(trf_2301)
static void C_ccall trf_2301(C_word c,C_word *av) C_noret;
static void C_ccall trf_2301(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2301(t0,t1);}

C_noret_decl(trf_2307)
static void C_ccall trf_2307(C_word c,C_word *av) C_noret;
static void C_ccall trf_2307(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2307(t0,t1);}

C_noret_decl(trf_2304)
static void C_ccall trf_2304(C_word c,C_word *av) C_noret;
static void C_ccall trf_2304(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2304(t0,t1);}

C_noret_decl(trf_3496)
static void C_ccall trf_3496(C_word c,C_word *av) C_noret;
static void C_ccall trf_3496(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3496(t0,t1,t2);}

C_noret_decl(trf_2262)
static void C_ccall trf_2262(C_word c,C_word *av) C_noret;
static void C_ccall trf_2262(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2262(t0,t1);}

C_noret_decl(trf_2265)
static void C_ccall trf_2265(C_word c,C_word *av) C_noret;
static void C_ccall trf_2265(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2265(t0,t1);}

C_noret_decl(trf_2268)
static void C_ccall trf_2268(C_word c,C_word *av) C_noret;
static void C_ccall trf_2268(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2268(t0,t1);}

C_noret_decl(trf_2244)
static void C_ccall trf_2244(C_word c,C_word *av) C_noret;
static void C_ccall trf_2244(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2244(t0,t1);}

C_noret_decl(trf_4797)
static void C_ccall trf_4797(C_word c,C_word *av) C_noret;
static void C_ccall trf_4797(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4797(t0,t1,t2);}

C_noret_decl(trf_2271)
static void C_ccall trf_2271(C_word c,C_word *av) C_noret;
static void C_ccall trf_2271(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2271(t0,t1);}

C_noret_decl(trf_3444)
static void C_ccall trf_3444(C_word c,C_word *av) C_noret;
static void C_ccall trf_3444(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3444(t0,t1,t2);}

C_noret_decl(trf_2274)
static void C_ccall trf_2274(C_word c,C_word *av) C_noret;
static void C_ccall trf_2274(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2274(t0,t1);}

C_noret_decl(trf_2277)
static void C_ccall trf_2277(C_word c,C_word *av) C_noret;
static void C_ccall trf_2277(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2277(t0,t1);}

C_noret_decl(trf_2250)
static void C_ccall trf_2250(C_word c,C_word *av) C_noret;
static void C_ccall trf_2250(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2250(t0,t1);}

C_noret_decl(trf_2237)
static void C_ccall trf_2237(C_word c,C_word *av) C_noret;
static void C_ccall trf_2237(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2237(t0,t1);}

C_noret_decl(trf_2286)
static void C_ccall trf_2286(C_word c,C_word *av) C_noret;
static void C_ccall trf_2286(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2286(t0,t1);}

C_noret_decl(trf_2283)
static void C_ccall trf_2283(C_word c,C_word *av) C_noret;
static void C_ccall trf_2283(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2283(t0,t1);}

C_noret_decl(trf_2280)
static void C_ccall trf_2280(C_word c,C_word *av) C_noret;
static void C_ccall trf_2280(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2280(t0,t1);}

C_noret_decl(trf_2289)
static void C_ccall trf_2289(C_word c,C_word *av) C_noret;
static void C_ccall trf_2289(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2289(t0,t1);}

C_noret_decl(trf_4215)
static void C_ccall trf_4215(C_word c,C_word *av) C_noret;
static void C_ccall trf_4215(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4215(t0,t1,t2);}

C_noret_decl(trf_2295)
static void C_ccall trf_2295(C_word c,C_word *av) C_noret;
static void C_ccall trf_2295(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2295(t0,t1);}

C_noret_decl(trf_2292)
static void C_ccall trf_2292(C_word c,C_word *av) C_noret;
static void C_ccall trf_2292(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2292(t0,t1);}

C_noret_decl(trf_2298)
static void C_ccall trf_2298(C_word c,C_word *av) C_noret;
static void C_ccall trf_2298(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2298(t0,t1);}

C_noret_decl(trf_4192)
static void C_ccall trf_4192(C_word c,C_word *av) C_noret;
static void C_ccall trf_4192(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4192(t0,t1,t2);}

C_noret_decl(trf_4869)
static void C_ccall trf_4869(C_word c,C_word *av) C_noret;
static void C_ccall trf_4869(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4869(t0,t1,t2);}

C_noret_decl(trf_4733)
static void C_ccall trf_4733(C_word c,C_word *av) C_noret;
static void C_ccall trf_4733(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4733(t0,t1,t2);}

C_noret_decl(trf_4158)
static void C_ccall trf_4158(C_word c,C_word *av) C_noret;
static void C_ccall trf_4158(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4158(t0,t1,t2);}

C_noret_decl(trf_3165)
static void C_ccall trf_3165(C_word c,C_word *av) C_noret;
static void C_ccall trf_3165(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3165(t0,t1,t2);}

C_noret_decl(trf_3713)
static void C_ccall trf_3713(C_word c,C_word *av) C_noret;
static void C_ccall trf_3713(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3713(t0,t1,t2);}

C_noret_decl(trf_1945)
static void C_ccall trf_1945(C_word c,C_word *av) C_noret;
static void C_ccall trf_1945(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1945(t0,t1);}

C_noret_decl(trf_2665)
static void C_ccall trf_2665(C_word c,C_word *av) C_noret;
static void C_ccall trf_2665(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2665(t0,t1);}

C_noret_decl(trf_1922)
static void C_ccall trf_1922(C_word c,C_word *av) C_noret;
static void C_ccall trf_1922(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1922(t0,t1,t2);}

C_noret_decl(trf_1718)
static void C_ccall trf_1718(C_word c,C_word *av) C_noret;
static void C_ccall trf_1718(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1718(t0,t1);}

C_noret_decl(trf_3090)
static void C_ccall trf_3090(C_word c,C_word *av) C_noret;
static void C_ccall trf_3090(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3090(t0,t1,t2);}

C_noret_decl(trf_4248)
static void C_ccall trf_4248(C_word c,C_word *av) C_noret;
static void C_ccall trf_4248(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4248(t0,t1,t2);}

C_noret_decl(trf_3616)
static void C_ccall trf_3616(C_word c,C_word *av) C_noret;
static void C_ccall trf_3616(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3616(t0,t1,t2);}

C_noret_decl(trf_2688)
static void C_ccall trf_2688(C_word c,C_word *av) C_noret;
static void C_ccall trf_2688(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_2688(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1872)
static void C_ccall trf_1872(C_word c,C_word *av) C_noret;
static void C_ccall trf_1872(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_1872(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4909)
static void C_ccall trf_4909(C_word c,C_word *av) C_noret;
static void C_ccall trf_4909(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4909(t0,t1,t2);}

C_noret_decl(trf_1899)
static void C_ccall trf_1899(C_word c,C_word *av) C_noret;
static void C_ccall trf_1899(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1899(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1850)
static void C_ccall trf_1850(C_word c,C_word *av) C_noret;
static void C_ccall trf_1850(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1850(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1823)
static void C_ccall trf_1823(C_word c,C_word *av) C_noret;
static void C_ccall trf_1823(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1823(t0,t1,t2);}

/* f5700 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in ... */
static void C_ccall f5700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5700,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in ... */
static void C_fcall f_3880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,3))){
C_save_and_reclaim_args((void *)trf_3880,3,t0,t1,t2);}
a=C_alloc(22);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[252]+1);
t9=C_i_check_list_2(((C_word*)t0)[3],lf[57]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3951,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_3951(t14,t10,((C_word*)t0)[3]);}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3989,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:423: check-and-open-input-file */
t6=*((C_word*)lf[258]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k3227 in for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in ... */
static void C_ccall f_3229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3229,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3219(t3,((C_word*)t0)[4],t2);}

/* for-each-loop468 in k4327 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in ... */
static void C_fcall f_4373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_4373,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4383,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4348,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[319]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[321];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[319]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[321];
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* f5774 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in ... */
static void C_ccall f5774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5774,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4505 in k4499 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in ... */
static void C_ccall f_4507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4507,2,av);}
/* batch-driver.scm:277: append */
t2=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[66]+1);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop364 in k4499 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in ... */
static void C_fcall f_4509(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4509,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:277: g370 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3208 in for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in ... */
static void C_ccall f_3210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3210,2,av);}
/* batch-driver.scm:534: ##sys#resolve-include-filename */
t2=*((C_word*)lf[186]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3873 in k3869 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in ... */
static void C_ccall f_3875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3875,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_2559(2,av2);}}

/* k3212 in for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in ... */
static void C_ccall f_3214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3214,2,av);}
/* batch-driver.scm:535: make-pathname */
t2=*((C_word*)lf[171]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=t1;
av2[4]=lf[187];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3869 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in ... */
static void C_ccall f_3871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3871,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:414: proc */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in ... */
static void C_fcall f_3219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,2))){
C_save_and_reclaim_args((void *)trf_3219,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3229,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3191,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:535: symbol->string */
t9=*((C_word*)lf[173]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2493 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in ... */
static void C_ccall f_2495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2495,2,av);}
/* batch-driver.scm:385: newline */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4381 in for-each-loop468 in k4327 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in ... */
static void C_ccall f_4383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4383,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4373(t3,((C_word*)t0)[4],t2);}

/* f5792 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in ... */
static void C_ccall f5792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5792,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f5798 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in ... */
static void C_ccall f5798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5798,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in ... */
static void C_ccall f_2738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_2738,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:626: print-node */
t3=((C_word*)((C_word*)t0)[13])[1];
f_1850(t3,t2,lf[107],lf[108],((C_word*)t0)[6]);}

/* a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f_2734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_2734,4,av);}
a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2738,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:625: end-time */
t5=((C_word*)((C_word*)t0)[7])[1];
f_2080(t5,t4,lf[109]);}

/* map-loop735 in k3822 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in ... */
static void C_fcall f_3836(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3836,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:437: g741 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3832 in k3822 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in ... */
static void C_ccall f_3834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3834,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_2565(t3,t2);}

/* f5644 in k2893 in k2890 in k2887 in k2884 in k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in ... */
static void C_ccall f5644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5644,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f5764 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in ... */
static void C_ccall f5764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5764,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3859 in map-loop735 in k3822 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in ... */
static void C_ccall f_3861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3861,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3836(t6,((C_word*)t0)[5],t5);}

/* f5752 in k4069 in k4063 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in ... */
static void C_ccall f5752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5752,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in ... */
static void C_ccall f_2741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,6))){C_save_and_reclaim((void *)f_2741,2,av);}
a=C_alloc(10);
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* batch-driver.scm:628: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2688(t3,((C_word*)t0)[5],t2,((C_word*)t0)[6],C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)t0)[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:630: debugging */
t5=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[36];
av2[3]=lf[99];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=*((C_word*)lf[100]+1);
if(C_truep(*((C_word*)lf[100]+1))){
if(C_truep(*((C_word*)lf[101]+1))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:637: begin-time */
t6=((C_word*)((C_word*)t0)[11])[1];
f_2070(t6,t5);}
else{
t5=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* batch-driver.scm:650: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2688(t6,((C_word*)t0)[5],t5,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:633: debugging */
t6=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[36];
av2[3]=lf[106];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}}}

/* f5758 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in ... */
static void C_ccall f5758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5758,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a4237 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in ... */
static void C_ccall f_4238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4238,3,av);}
t3=*((C_word*)lf[311]+1);
/* batch-driver.scm:315: g559 */
t4=*((C_word*)lf[311]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[312];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3807 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in ... */
static void C_ccall f_3809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_3809,2,av);}
a=C_alloc(12);
t2=C_mutate2((C_word*)lf[245]+1 /* (set! ##sys#explicit-library-modules ...) */,t1);
t3=C_a_i_cons(&a,2,lf[246],((C_word*)((C_word*)t0)[2])[1]);
t4=C_a_i_list(&a,2,lf[247],t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[4];
f_2574(t7,t6);}

/* k2774 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in ... */
static void C_ccall f_2776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,6))){C_save_and_reclaim((void *)f_2776,2,av);}
a=C_alloc(4);
t2=C_set_block_item(lf[100] /* ##compiler#inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* batch-driver.scm:635: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2688(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[6]);}

/* k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in ... */
static void C_ccall f_2428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,2))){C_save_and_reclaim((void *)f_2428,2,av);}
a=C_alloc(32);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[2],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
t4=((C_word*)t0)[3];
if(C_truep(C_u_i_memq(lf[300],t4))){
t5=C_set_block_item(lf[301] /* ##sys#enable-runtime-macros */,0,C_SCHEME_TRUE);
t6=t3;
f_2431(t6,t5);}
else{
t5=t3;
f_2431(t5,C_SCHEME_UNDEFINED);}}

/* k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in ... */
static void C_ccall f_2424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(43,c,2))){C_save_and_reclaim((void *)f_2424,2,av);}
a=C_alloc(43);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4150,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:336: collect-options */
t9=((C_word*)((C_word*)t0)[20])[1];
f_2035(t9,t8,lf[304]);}

/* k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in ... */
static void C_ccall f_2420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,3))){C_save_and_reclaim((void *)f_2420,2,av);}
a=C_alloc(32);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm:329: append */
t4=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=*((C_word*)lf[305]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a2721 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f_2722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2722,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm:623: determine-loop-and-dispatch */
t2=*((C_word*)lf[97]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
/* batch-driver.scm:624: perform-high-level-optimizations */
t2=*((C_word*)lf[98]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k4256 in for-each-loop518 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in ... */
static void C_ccall f_4258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4258,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4248(t3,((C_word*)t0)[4],t2);}

/* k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in ... */
static void C_ccall f_2412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,2))){C_save_and_reclaim((void *)f_2412,2,av);}
a=C_alloc(36);
t2=C_mutate2((C_word*)lf[70]+1 /* (set! ##sys#features ...) */,t1);
t3=C_a_i_cons(&a,2,lf[71],*((C_word*)lf[70]+1));
t4=C_mutate2((C_word*)lf[70]+1 /* (set! ##sys#features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:326: user-post-analysis-pass */
t6=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k3046 in for-each-loop1098 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in ... */
static void C_ccall f_3048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3048,2,av);}
/* batch-driver.scm:562: load-type-database */
t2=*((C_word*)lf[170]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3822 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f_3824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_3824,2,av);}
a=C_alloc(17);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)t0)[2];
t7=((C_word*)((C_word*)t0)[3])[1];
t8=C_i_check_list_2(t7,lf[57]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3836,a[2]=t4,a[3]=t11,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3836(t13,t9,t7);}

/* k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in ... */
static void C_ccall f_3039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_3039,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3090,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3090(t6,t2,((C_word*)t0)[11]);}

/* k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in ... */
static void C_fcall f_2484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(33,0,4))){
C_save_and_reclaim_args((void *)trf_2484,2,t0,t1);}
a=C_alloc(33);
if(C_truep(t1)){
/* batch-driver.scm:382: print-usage */
t2=*((C_word*)lf[82]+1);{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
if(C_truep(C_u_i_memq(lf[83],t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2502,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:384: chicken-version */
t5=*((C_word*)lf[85]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[2],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[3],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
t5=t4;
t6=C_a_i_list(&a,1,((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5740,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t7;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[270];
av2[4]=t6;
C_apply(5,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:387: print-version */
t5=*((C_word*)lf[80]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}}}

/* k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in ... */
static void C_ccall f_3033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_3033,2,av);}
a=C_alloc(17);
t2=C_i_check_list_2(t1,lf[43]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3113,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3113(t7,t3,t1);}

/* k3067 in k3064 in k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in ... */
static void C_ccall f_3069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3069,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:569: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2070(t3,t2);}

/* k2471 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in ... */
static void C_ccall f_2473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2473,2,av);}
/* batch-driver.scm:380: newline */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in ... */
static void C_ccall f_3063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_3063,2,av);}
a=C_alloc(9);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:567: print-db */
t4=((C_word*)((C_word*)t0)[9])[1];
f_1872(t4,t3,lf[167],lf[168],((C_word*)((C_word*)t0)[2])[1],C_fix(0));}

/* k3064 in k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in ... */
static void C_ccall f_3066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3066,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:568: end-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2080(t3,t2,lf[166]);}

/* k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in ... */
static void C_ccall f_2462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,2))){C_save_and_reclaim((void *)f_2462,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:376: load-identifier-database */
t3=*((C_word*)lf[277]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[278];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in ... */
static void C_ccall f_2465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,2))){C_save_and_reclaim((void *)f_2465,2,av);}
a=C_alloc(27);
t2=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[79],t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:379: print-version */
t4=*((C_word*)lf[80]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[81],t3);
t5=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t4)){
t6=t5;
f_2484(t6,t4);}
else{
t6=((C_word*)t0)[2];
t7=C_u_i_memq(lf[274],t6);
if(C_truep(t7)){
t8=t5;
f_2484(t8,t7);}
else{
t8=((C_word*)t0)[2];
t9=C_u_i_memq(lf[275],t8);
if(C_truep(t9)){
t10=t5;
f_2484(t10,t9);}
else{
t10=((C_word*)t0)[2];
t11=t5;
f_2484(t11,C_u_i_memq(lf[276],t10));}}}}}

/* k4346 in for-each-loop468 in k4327 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in ... */
static void C_ccall f_4348(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4348,2,av);}
t2=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[319]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[320];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[319]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[320];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in ... */
static void C_fcall f_2456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(34,0,4))){
C_save_and_reclaim_args((void *)trf_2456,2,t0,t1);}
a=C_alloc(34);
t2=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(*((C_word*)lf[75]+1))){
t3=t2;
t4=C_a_i_list(&a,1,lf[288]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5758,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[289];
av2[4]=t4;
C_apply(5,av2);}}
else{
t3=t2;
t4=C_a_i_list(&a,1,lf[290]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5764,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[289];
av2[4]=t4;
C_apply(5,av2);}}}

/* k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in ... */
static void C_ccall f_2459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,2))){C_save_and_reclaim((void *)f_2459,2,av);}
a=C_alloc(32);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[27])){
t3=C_i_car(((C_word*)t0)[27]);
t4=C_eqp(lf[279],t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[24],a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
if(C_truep(((C_word*)t0)[22])){
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_4065(2,av2);}}
else{
/* batch-driver.scm:362: quit */
t7=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[287];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}
else{
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_4065(2,av2);}}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2462(2,av2);}}}

/* k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in ... */
static void C_ccall f_2450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,2))){C_save_and_reclaim((void *)f_2450,2,av);}
a=C_alloc(28);
t2=C_mutate2((C_word*)lf[78]+1 /* (set! ##compiler#bootstrap-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(C_i_memq(lf[296],*((C_word*)lf[30]+1)))){
/* batch-driver.scm:349: set-gc-report! */
t4=*((C_word*)lf[297]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2453(2,av2);}}}

/* k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in ... */
static void C_ccall f_2453(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,2))){C_save_and_reclaim((void *)f_2453,2,av);}
a=C_alloc(28);
t2=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[291],t3))){
t4=C_set_block_item(((C_word*)t0)[18],0,C_SCHEME_FALSE);
t5=t2;
f_2456(t5,t4);}
else{
t4=C_mutate2((C_word*)lf[292]+1 /* (set! standard-bindings ...) */,*((C_word*)lf[293]+1));
t5=C_mutate2((C_word*)lf[294]+1 /* (set! extended-bindings ...) */,*((C_word*)lf[295]+1));
t6=t2;
f_2456(t6,t5);}}

/* k4327 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in ... */
static void C_ccall f_4329(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4329,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[295]+1);
t3=C_i_check_list_2(*((C_word*)lf[295]+1),lf[43]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4373,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4373(t7,((C_word*)t0)[2],*((C_word*)lf[295]+1));}

/* k1909 in for-each-loop164 in k1904 in print-expr in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1911,2,av);}
/* batch-driver.scm:133: newline */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop419 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in ... */
static void C_fcall f_4396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_4396,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4406,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[319]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[321];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[319]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[321];
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* f5662 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f5662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5662,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f5668 in k2968 in k2965 in k2962 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in ... */
static void C_ccall f5668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5668,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4611 in k4608 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in ... */
static void C_ccall f_4613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4613,2,av);}
/* batch-driver.scm:255: case-sensitive */
t2=*((C_word*)lf[339]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4608 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in ... */
static void C_ccall f_4610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4610,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:254: register-feature! */
t3=*((C_word*)lf[67]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[352];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* f5656 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in ... */
static void C_ccall f5656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5656,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f5650 */
static void C_ccall f5650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5650,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3408 in a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in ... */
static void C_ccall f_3410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3410,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[217]+1);
t3=C_i_check_list_2(*((C_word*)lf[217]+1),lf[43]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3444,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3444(t7,((C_word*)t0)[2],*((C_word*)lf[217]+1));}

/* k3416 in for-each-loop925 in k3408 in a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in ... */
static void C_ccall f_3418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3418,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm:490: ##sys#print */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* f5680 in for-each-loop1054 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_ccall f5680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5680,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f5688 in k3198 in k3189 in for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_ccall f5688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5688,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in ... */
static void C_ccall f_3406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3406,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3410,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:488: print */
t3=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[221];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3770 in map-loop767 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in ... */
static void C_ccall f_3772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3772,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3747(t6,((C_word*)t0)[5],t5);}

/* k2400 in for-each-loop569 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in ... */
static void C_ccall f_2402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2402,2,av);}
/* batch-driver.scm:322: load */
t2=*((C_word*)lf[308]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in ... */
static void C_ccall f_2408(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,4))){C_save_and_reclaim((void *)f_2408,2,av);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:324: delete */
t3=*((C_word*)lf[306]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[69];
av2[3]=*((C_word*)lf[70]+1);
av2[4]=*((C_word*)lf[307]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* map-loop767 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in ... */
static void C_fcall f_3747(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3747,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:446: g773 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2800 in k2797 in k2794 in k2791 in k2788 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in ... */
static void C_ccall f_2802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2802,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:643: end-time */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2080(t4,t3,lf[102]);}

/* k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in ... */
static void C_ccall f_2805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,6))){C_save_and_reclaim((void *)f_2805,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* batch-driver.scm:644: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2688(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[7]);}

/* k3198 in k3189 in for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in ... */
static void C_ccall f_3200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_3200,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=t2;
t4=C_a_i_list(&a,1,((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5688,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[184];
av2[4]=t4;
C_apply(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3201 in k3198 in k3189 in for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_ccall f_3203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3203,2,av);}
/* batch-driver.scm:539: load-inline-file */
t2=*((C_word*)lf[180]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in ... */
static void C_ccall f_2559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,2))){C_save_and_reclaim((void *)f_2559,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:434: user-preprocessor-pass */
t3=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in ... */
static void C_ccall f_2556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(38,c,4))){C_save_and_reclaim((void *)f_2556,2,av);}
a=C_alloc(38);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[25],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[27],a[6]=((C_word*)t0)[28],a[7]=((C_word*)t0)[29],tmp=(C_word)a,a+=8,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5726,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[251];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3880,a[2]=((C_word*)t0)[25],a[3]=((C_word*)t0)[27],a[4]=((C_word*)t0)[29],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3880(t7,t3,((C_word*)t0)[28]);}}

/* k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in ... */
static void C_ccall f_2550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(34,c,2))){C_save_and_reclaim((void *)f_2550,2,av);}
a=C_alloc(34);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=t2,tmp=(C_word)a,a+=29,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[18],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:407: collect-options */
t5=((C_word*)((C_word*)t0)[18])[1];
f_2035(t5,t4,lf[260]);}

/* k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in ... */
static void C_ccall f_2553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,2))){C_save_and_reclaim((void *)f_2553,2,av);}
a=C_alloc(30);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=t2,a[29]=((C_word*)t0)[28],tmp=(C_word)a,a+=30,tmp);
/* batch-driver.scm:411: user-read-pass */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* def-no230 in analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_2150,2,t0,t1);}
/* batch-driver.scm:56: def-contf231 */
t2=((C_word*)t0)[2];
f_2145(t2,t1,C_fix(0));}

/* k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in ... */
static void C_ccall f_2547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,2))){C_save_and_reclaim((void *)f_2547,2,av);}
a=C_alloc(28);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=t2,tmp=(C_word)a,a+=28,tmp);
/* batch-driver.scm:405: collect-options */
t4=((C_word*)((C_word*)t0)[18])[1];
f_2035(t4,t3,lf[261]);}

/* k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in ... */
static void C_ccall f_2544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,2))){C_save_and_reclaim((void *)f_2544,2,av);}
a=C_alloc(27);
t2=C_mutate2((C_word*)lf[87]+1 /* (set! ##sys#line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:404: collect-options */
t4=((C_word*)((C_word*)t0)[18])[1];
f_2035(t4,t3,lf[262]);}

/* k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in ... */
static void C_ccall f_2540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_2540,2,av);}
a=C_alloc(27);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:403: make-vector */
t4=*((C_word*)lf[263]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[264]+1);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in ... */
static void C_ccall f_2439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,2))){C_save_and_reclaim((void *)f_2439,2,av);}
a=C_alloc(28);
t2=C_mutate2((C_word*)lf[73]+1 /* (set! ##compiler#target-stack-size ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[74],t3);
t5=C_i_not(t4);
t6=C_mutate2((C_word*)lf[75]+1 /* (set! ##compiler#emit-trace-info ...) */,t5);
t7=((C_word*)t0)[2];
t8=C_mutate2((C_word*)lf[76]+1 /* (set! ##compiler#disable-stack-overflow-checking ...) */,C_u_i_memq(lf[77],t7));
t9=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
/* batch-driver.scm:348: feature? */
t10=*((C_word*)lf[298]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[299];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in ... */
static void C_ccall f_2435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,2))){C_save_and_reclaim((void *)f_2435,2,av);}
a=C_alloc(32);
t2=C_mutate2((C_word*)lf[72]+1 /* (set! ##compiler#target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[28])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4120,a[2]=((C_word*)t0)[29],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:345: option-arg */
f_1718(t4,((C_word*)t0)[28]);}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_2439(2,av2);}}}

/* k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in ... */
static void C_fcall f_2431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(35,0,2))){
C_save_and_reclaim_args((void *)trf_2431,2,t0,t1);}
a=C_alloc(35);
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_2435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[31])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4127,a[2]=((C_word*)t0)[29],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:342: option-arg */
f_1718(t3,((C_word*)t0)[31]);}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_2435(2,av2);}}}

/* a2133 in k2124 in body228 in analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2134,4,av);}
t4=*((C_word*)lf[51]+1);
/* batch-driver.scm:166: g249 */
t5=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in ... */
static void C_ccall f_2536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,2))){C_save_and_reclaim((void *)f_2536,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:105: current-milliseconds */
t3=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a2139 in k2124 in body228 in analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_2140,5,av);}
t5=*((C_word*)lf[52]+1);
/* batch-driver.scm:167: g263 */
t6=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=t3;
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}

/* k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word *a;
if(!C_demand(C_calculate_demand(94,0,6))){
C_save_and_reclaim_args((void *)trf_1805,2,t0,t1);}
a=C_alloc(94);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1823,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t23=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1945,tmp=(C_word)a,a+=2,tmp));
t26=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t27=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t28=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t29=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp));
t30=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=t18,a[13]=t16,a[14]=t20,a[15]=t6,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=t8,a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=t14,a[25]=t10,a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=t2,a[32]=t12,a[33]=((C_word*)t0)[3],a[34]=((C_word*)t0)[27],a[35]=((C_word*)t0)[28],a[36]=((C_word*)t0)[29],a[37]=((C_word*)t0)[5],tmp=(C_word)a,a+=38,tmp);
if(C_truep(((C_word*)t0)[30])){
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4851,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=t32,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:172: option-arg */
f_1718(t33,((C_word*)t0)[30]);}
else{
t31=t30;
f_2186(t31,C_SCHEME_UNDEFINED);}}

/* def-contf231 in analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_2145,3,t0,t1,t2);}
/* batch-driver.scm:56: body228 */
t3=((C_word*)t0)[2];
f_2122(t3,t1,t2,C_SCHEME_TRUE);}

/* k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in ... */
static void C_ccall f_2533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_2533,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:399: debugging */
t3=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[265];
av2[3]=lf[266];
av2[4]=*((C_word*)lf[73]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in ... */
static void C_ccall f_2530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_2530,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:398: debugging */
t3=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[265];
av2[3]=lf[267];
av2[4]=*((C_word*)lf[72]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2124 in body228 in analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,8))){C_save_and_reclaim((void *)f_2126,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:165: upap */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
av2[4]=((C_word*)t0)[5];
av2[5]=t4;
av2[6]=t5;
av2[7]=((C_word*)t0)[6];
av2[8]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t6+1)))(9,av2);}}
else{
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* body228 in analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_2122,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2126,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:163: analyze-expression */
t5=*((C_word*)lf[53]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_2120,5,t0,t1,t2,t3,t4);}
a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2145,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* batch-driver.scm:56: def-no230 */
t8=t7;
f_2150(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_u_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* batch-driver.scm:56: def-contf231 */
t10=t6;
f_2145(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_u_i_cdr(t9);
/* batch-driver.scm:56: body228 */
t12=t5;
f_2122(t12,t1,t8,t10);}}}

/* k3304 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in ... */
static void C_ccall f_3306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3306,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:513: begin-time */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2070(t3,t2);}

/* k3307 in k3304 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in ... */
static void C_ccall f_3309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_3309,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)t0)[2];
t7=((C_word*)((C_word*)t0)[3])[1];
t8=C_i_check_list_2(t7,lf[57]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3324,a[2]=t4,a[3]=t11,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3324(t13,t9,t7);}

/* map-loop1007 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in ... */
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_3255,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3251 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in ... */
static void C_ccall f_3253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3253,2,av);}
/* batch-driver.scm:528: concatenate */
t2=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in ... */
static void C_ccall f_2527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_2527,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:397: debugging */
t3=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[265];
av2[3]=lf[268];
av2[4]=*((C_word*)lf[30]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in ... */
static void C_ccall f_2523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_2523,2,av);}
a=C_alloc(27);
t2=C_mutate2((C_word*)lf[86]+1 /* (set! ##compiler#source-filename ...) */,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:396: debugging */
t4=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[265];
av2[3]=lf[269];
av2[4]=((C_word*)t0)[19];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2127 in k2124 in body228 in analyze in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2129,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3301 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in ... */
static void C_ccall f_3303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3303,2,av);}
/* batch-driver.scm:520: build-node-graph */
t2=*((C_word*)lf[197]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2116 in k2094 in k2091 in k2088 in end-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2118,2,av);}
a=C_alloc(4);
t2=C_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm:159: round */
t3=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2108 in k2094 in k2091 in k2088 in end-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2110,2,av);}
t2=C_i_inexact_to_exact(t1);
/* batch-driver.scm:157: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in ... */
static void C_ccall f_2592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(41,c,3))){C_save_and_reclaim((void *)f_2592,2,av);}
a=C_alloc(41);
t2=C_i_length(*((C_word*)lf[89]+1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=*((C_word*)lf[228]+1);
t10=C_i_check_list_2(*((C_word*)lf[228]+1),lf[57]);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3553,a[2]=t4,a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[22],a[6]=t3,a[7]=((C_word*)t0)[23],tmp=(C_word)a,a+=8,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3713,a[2]=t7,a[3]=t13,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_3713(t15,t11,*((C_word*)lf[228]+1));}

/* map-loop830 in k3551 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_fcall f_3679(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_3679,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,lf[238],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in ... */
static void C_ccall f_2598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,3))){C_save_and_reclaim((void *)f_2598,2,av);}
a=C_alloc(42);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=t3,a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_i_nullp(*((C_word*)lf[58]+1)))){
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2601(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3475,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=*((C_word*)lf[58]+1);
t11=C_i_check_list_2(*((C_word*)lf[58]+1),lf[57]);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3496,a[2]=t8,a[3]=t14,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_3496(t16,t12,*((C_word*)lf[58]+1));}}

/* k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in ... */
static void C_ccall f_2589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_2589,2,av);}
a=C_alloc(24);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:453: gensym */
t4=*((C_word*)lf[239]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(44,c,3))){C_save_and_reclaim((void *)f_2192,2,av);}
a=C_alloc(44);
t2=((C_word*)t0)[2];
t3=C_mutate2((C_word*)lf[54]+1 /* (set! ##compiler#enable-specialization ...) */,C_u_i_memq(lf[55],t2));
t4=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4776,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4833,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:184: collect-options */
t7=((C_word*)((C_word*)t0)[24])[1];
f_2035(t7,t6,lf[396]);}

/* k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in ... */
static void C_ccall f_2580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(50,c,2))){C_save_and_reclaim((void *)f_2580,2,av);}
a=C_alloc(50);
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[26])){
t3=C_a_i_list(&a,3,lf[240],lf[241],lf[242]);
t4=C_a_i_cons(&a,2,t3,t1);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[243],t5);
t7=C_a_i_cons(&a,2,lf[244],t6);
t8=t2;
f_2583(t8,C_a_i_list(&a,1,t7));}
else{
t3=t2;
f_2583(t3,t1);}}

/* k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in ... */
static void C_fcall f_2583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(31,0,3))){
C_save_and_reclaim_args((void *)trf_2583,2,t0,t1);}
a=C_alloc(31);
t2=C_i_check_list_2(t1,lf[57]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[23],a[3]=t5,a[4]=((C_word*)t0)[24],a[5]=((C_word*)t0)[25],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3747(t7,t3,t1);}

/* k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(41,c,2))){C_save_and_reclaim((void *)f_2199,2,av);}
a=C_alloc(41);
t2=C_mutate2((C_word*)lf[30]+1 /* (set! ##compiler#debugging-chicken ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
if(C_truep(C_i_memq(lf[275],*((C_word*)lf[30]+1)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4771,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:186: print-debug-options */
t5=*((C_word*)lf[394]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2202(2,av2);}}}

/* k4469 in map-loop393 in k4439 in a4433 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in ... */
static void C_ccall f_4471(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4471,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4446(t6,((C_word*)t0)[5],t5);}

/* k3317 in k3307 in k3304 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in ... */
static void C_ccall f_3319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3319,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* batch-driver.scm:515: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2080(t3,((C_word*)t0)[4],lf[199]);}

/* k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(38,0,2))){
C_save_and_reclaim_args((void *)trf_2186,2,t0,t1);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=*((C_word*)lf[205]+1);
if(C_truep(*((C_word*)lf[205]+1))){
t4=*((C_word*)lf[205]+1);
if(C_truep(*((C_word*)lf[205]+1))){
t5=C_set_block_item(lf[399] /* ##compiler#standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_2189(t6,t5);}
else{
t5=t2;
f_2189(t5,C_SCHEME_UNDEFINED);}}
else{
if(C_truep(((C_word*)t0)[17])){
t4=C_set_block_item(lf[399] /* ##compiler#standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_2189(t5,t4);}
else{
t4=t2;
f_2189(t4,C_SCHEME_UNDEFINED);}}}

/* k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in ... */
static void C_ccall f_2571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(31,c,3))){C_save_and_reclaim((void *)f_2571,2,av);}
a=C_alloc(31);
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[26])[1]))){
t3=t2;
f_2574(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3809,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[25],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:443: append */
t4=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[245]+1);
av2[3]=((C_word*)((C_word*)t0)[26])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in ... */
static void C_fcall f_2574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(32,0,3))){
C_save_and_reclaim_args((void *)trf_2574,2,t0,t1);}
a=C_alloc(32);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=*((C_word*)lf[88]+1);
t7=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=t4,a[24]=t6,a[25]=t5,a[26]=((C_word*)t0)[23],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:447: append */
t8=*((C_word*)lf[230]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)((C_word*)t0)[24])[1];
av2[3]=((C_word*)((C_word*)t0)[25])[1];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(38,0,2))){
C_save_and_reclaim_args((void *)trf_2189,2,t0,t1);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[176],t3))){
t4=C_set_block_item(lf[397] /* ##sys#dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm:177: repository-path */
t5=*((C_word*)lf[398]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2192(2,av2);}}}

/* k4480 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in ... */
static void C_ccall f_4482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4482,2,av);}
/* batch-driver.scm:283: append-map */
t2=*((C_word*)lf[313]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3289 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in ... */
static void C_ccall f_3291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3291,2,av);}
/* batch-driver.scm:527: concatenate */
t2=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in ... */
static void C_ccall f_3299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,4))){C_save_and_reclaim((void *)f_3299,2,av);}
a=C_alloc(32);
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_record4(&a,4,lf[91],lf[92],lf[93],t2);
t4=t3;
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t4,a[18]=((C_word*)t0)[17],a[19]=t6,a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:523: print-node */
t8=((C_word*)((C_word*)t0)[6])[1];
f_1850(t8,t7,lf[195],lf[196],t4);}

/* k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in ... */
static void C_ccall f_2568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,2))){C_save_and_reclaim((void *)f_2568,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:440: begin-time */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2070(t3,t2);}

/* k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_fcall f_2565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,0,4))){
C_save_and_reclaim_args((void *)trf_2565,2,t0,t1);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:439: print-expr */
t3=((C_word*)((C_word*)t0)[20])[1];
f_1899(t3,t2,lf[248],lf[249],((C_word*)((C_word*)t0)[25])[1]);}

/* k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in ... */
static void C_ccall f_2562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(35,c,4))){C_save_and_reclaim((void *)f_2562,2,av);}
a=C_alloc(35);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3824,a[2]=t2,a[3]=((C_word*)t0)[25],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5720,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[250];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t3;
f_2565(t4,C_SCHEME_UNDEFINED);}}

/* k3241 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in ... */
static void C_ccall f_3243(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3243,2,av);}
if(C_truep(t1)){
/* batch-driver.scm:530: pp */
t2=*((C_word*)lf[188]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_2653(2,av2);}}}

/* k3990 in k3987 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f_3992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3992,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3880(t4,((C_word*)t0)[4],t3);}

/* a3998 in k3987 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f_3999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3999,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[254]+1));
t3=C_mutate2((C_word*)lf[254]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-loop969 in k3307 in k3304 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in ... */
static void C_fcall f_3324(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3324,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:514: g975 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a4433 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in ... */
static void C_ccall f_4434(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4434,3,av);}
a=C_alloc(10);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4441,a[2]=t5,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:284: string-split */
t8=*((C_word*)lf[311]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=lf[332];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k4304 in for-each-loop419 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in ... */
static void C_ccall f_4306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4306,2,av);}
t2=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[319]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[320];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[319]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[320];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k3987 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in ... */
static void C_ccall f_3989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_3989,2,av);}
a=C_alloc(22);
t2=t1;
t3=((C_word*)t0)[2];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3999,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4004,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4032,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:416: ##sys#dynamic-wind */
t11=*((C_word*)lf[257]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t11;
av2[1]=t7;
av2[2]=t8;
av2[3]=t9;
av2[4]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}

/* k4439 in a4433 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in ... */
static void C_ccall f_4441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4441,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4446(t5,((C_word*)t0)[4],t1);}

/* map-loop393 in k4439 in a4433 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in ... */
static void C_fcall f_4446(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4446,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:284: g399 */
t5=*((C_word*)lf[303]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3974 in map-loop660 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f_3976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3976,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3951(t6,((C_word*)t0)[5],t5);}

/* k2515 in k2512 in k2509 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in ... */
static void C_ccall f_2517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2517,2,av);}
/* batch-driver.scm:390: display */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[271];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2512 in k2509 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in ... */
static void C_ccall f_2514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2514,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:389: display */
t3=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[272];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2509 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in ... */
static void C_ccall f_2511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2511,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:388: display */
t3=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[273];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2059 in k2055 in g208 in loop in collect-options in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_2061,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2500 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in ... */
static void C_ccall f_2502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2502,2,av);}
/* batch-driver.scm:384: display */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2055 in g208 in loop in collect-options in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2057,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm:149: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2041(t5,t3,t4);}

/* map-loop660 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in ... */
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3951,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:419: g666 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in collect-options in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_2041,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_memq(((C_word*)t0)[2],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:56: g208 */
t5=t4;
f_2049(t5,t1,t3);}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3940 in map-loop686 in k3903 in k3899 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in ... */
static void C_ccall f_3942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3942,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3917(t6,((C_word*)t0)[5],t5);}

/* g208 in loop in collect-options in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2049,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2057,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:149: option-arg */
f_1718(t3,t2);}

/* k2012 in arg-val in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2014,2,av);}
a=C_alloc(8);
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
t3=C_a_i_times(&a,2,t2,C_fix(1024));
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* batch-driver.scm:145: quit */
t4=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[45];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k4499 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in ... */
static void C_ccall f_4501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_4501,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[57]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4509(t7,t3,t1);}

/* k2091 in k2088 in end-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2093,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:157: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[49];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* map-loop686 in k3903 in k3899 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in ... */
static void C_fcall f_3917(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3917,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:421: g692 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2094 in k2091 in k2088 in end-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2096,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:105: current-milliseconds */
t5=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k3913 in k3903 in k3899 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in ... */
static void C_ccall f_3915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3915,2,av);}
/* batch-driver.scm:419: append */
t2=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2088 in end-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2090,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:157: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2097 in k2094 in k2091 in k2088 in end-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2099,2,av);}
/* batch-driver.scm:157: ##sys#write-char-0 */
t2=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in ... */
static void C_ccall f_2393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(38,c,3))){C_save_and_reclaim((void *)f_2393,2,av);}
a=C_alloc(38);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[43]);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4192,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4192(t7,t3,((C_word*)t0)[2]);}

/* k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in ... */
static void C_ccall f_2390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(37,c,4))){C_save_and_reclaim((void *)f_2390,2,av);}
a=C_alloc(37);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2393,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5774,a[2]=t4,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[309];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}

/* k3899 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in ... */
static void C_ccall f_3901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3901,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:420: reverse */
t4=*((C_word*)lf[253]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3903 in k3899 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f_3905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_3905,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[252]+1);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[57]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3917,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3917(t13,t9,((C_word*)t0)[2]);}

/* end-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2080(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_2080,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=*((C_word*)lf[31]+1);
t4=*((C_word*)lf[31]+1);
t5=C_i_check_port_2(*((C_word*)lf[31]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2090,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:157: ##sys#print */
t7=*((C_word*)lf[34]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[50];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[31]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a4003 in k3987 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f_4004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4004,2,av);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4010(t5,t1);}

/* begin-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_2070,2,t0,t1);}
a=C_alloc(4);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:105: current-milliseconds */
t3=*((C_word*)lf[47]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4561 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in ... */
static void C_ccall f_4563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4563,2,av);}
/* batch-driver.scm:267: symbol-escape */
t2=*((C_word*)lf[336]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2076 in begin-time in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2078,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4012 in loop in a4003 in k3987 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in ... */
static void C_ccall f_4014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4014,2,av);}
a=C_alloc(3);
if(C_truep(C_eofp(t1))){
/* batch-driver.scm:428: close-checked-input-file */
t2=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t2);
/* batch-driver.scm:431: loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_4010(t4,((C_word*)t0)[2]);}}

/* loop in a4003 in k3987 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in ... */
static void C_fcall f_4010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_4010,2,t0,t1);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4014,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:426: read/source-info */
t3=*((C_word*)lf[256]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4569 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in ... */
static void C_ccall f_4571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4571,2,av);}
/* batch-driver.scm:264: parenthesis-synonyms */
t2=*((C_word*)lf[344]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4575 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in ... */
static void C_ccall f_4577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4577,2,av);}
if(C_truep(C_i_string_equal_p(lf[346],t1))){
/* batch-driver.scm:258: keyword-style */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[347];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[348],t1))){
/* batch-driver.scm:259: keyword-style */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[338];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[349],t1))){
/* batch-driver.scm:260: keyword-style */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[350];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
/* batch-driver.scm:261: quit */
t2=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[351];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}}}

/* k3570 in k3566 in k3551 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in ... */
static void C_fcall f_3572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,3))){
C_save_and_reclaim_args((void *)trf_3572,2,t0,t1);}
a=C_alloc(21);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[89]+1);
t8=C_i_check_list_2(*((C_word*)lf[89]+1),lf[57]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3616,a[2]=t5,a[3]=t11,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3616(t13,t9,*((C_word*)lf[89]+1));}

/* collect-options in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_2035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_2035,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2041,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2041(t6,t1,((C_word*)t0)[3]);}

/* k4550 in k4547 in k4544 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in ... */
static void C_ccall f_4552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4552,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:272: parentheses-synonyms */
t3=*((C_word*)lf[337]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4553 in k4550 in k4547 in k4544 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in ... */
static void C_ccall f_4555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4555,2,av);}
/* batch-driver.scm:273: symbol-escape */
t2=*((C_word*)lf[336]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4544 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in ... */
static void C_ccall f_4546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4546,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4549,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:270: case-sensitive */
t3=*((C_word*)lf[339]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4547 in k4544 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in ... */
static void C_ccall f_4549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4549,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:271: keyword-style */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[338];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3566 in k3551 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_ccall f_3568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(41,c,2))){C_save_and_reclaim((void *)f_3568,2,av);}
a=C_alloc(41);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[235]+1))){
t4=C_a_i_list(&a,2,lf[232],((C_word*)t0)[7]);
t5=*((C_word*)lf[205]+1);
t6=(C_truep(*((C_word*)lf[205]+1))?C_a_i_list(&a,2,lf[232],C_SCHEME_FALSE):(C_truep(((C_word*)t0)[8])?C_a_i_list(&a,2,lf[232],((C_word*)t0)[8]):C_a_i_list(&a,2,lf[232],C_SCHEME_TRUE)));
t7=C_a_i_list(&a,3,lf[236],t4,t6);
t8=C_a_i_list(&a,3,lf[237],*((C_word*)lf[234]+1),t7);
t9=t3;
f_3572(t9,C_a_i_list(&a,1,t8));}
else{
t4=t3;
f_3572(t4,C_SCHEME_END_OF_LIST);}}

/* k4532 in map-loop364 in k4499 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in ... */
static void C_ccall f_4534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4534,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4509(t6,((C_word*)t0)[5],t5);}

/* k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in ... */
static void C_ccall f_2325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(38,c,2))){C_save_and_reclaim((void *)f_2325,2,av);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[35])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:257: option-arg */
f_1718(t3,((C_word*)t0)[35]);}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2328(2,av2);}}}

/* k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in ... */
static void C_ccall f_2328(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(41,c,4))){C_save_and_reclaim((void *)f_2328,2,av);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[343],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4571,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5804,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[345];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2331(2,av2);}}}

/* k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in ... */
static void C_fcall f_2322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(42,0,4))){
C_save_and_reclaim_args((void *)trf_2322,2,t0,t1);}
a=C_alloc(42);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[352],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4610,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5810,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[353];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2325(2,av2);}}}

/* k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in ... */
static void C_fcall f_2317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(39,0,2))){
C_save_and_reclaim_args((void *)trf_2317,2,t0,t1);}
a=C_alloc(39);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[63],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:249: option-arg */
f_1718(t5,t3);}
else{
t5=t4;
f_2322(t5,C_SCHEME_FALSE);}}

/* k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in ... */
static void C_fcall f_2312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(40,0,2))){
C_save_and_reclaim_args((void *)trf_2312,2,t0,t1);}
a=C_alloc(40);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[62],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[21],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:246: option-arg */
f_1718(t5,t3);}
else{
t5=t4;
f_2317(t5,C_SCHEME_FALSE);}}

/* k4118 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in ... */
static void C_ccall f_4120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4120,2,av);}
/* batch-driver.scm:345: arg-val */
f_1945(((C_word*)t0)[3],t1);}

/* k3378 in k3375 in k3369 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in ... */
static void C_ccall f_3380(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3380,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:499: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[208];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3381 in k3378 in k3375 in k3369 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in ... */
static void C_ccall f_3383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3383,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:499: get-output-string */
t3=*((C_word*)lf[207]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3384 in k3381 in k3378 in k3375 in k3369 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in ... */
static void C_ccall f_3386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3386,2,av);}
/* batch-driver.scm:498: ##sys#notice */
t2=*((C_word*)lf[206]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3387 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in ... */
static void C_ccall f_3389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3389,2,av);}
if(C_truep(t1)){
/* batch-driver.scm:495: display-line-number-database */
t2=*((C_word*)lf[211]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_2610(2,av2);}}}

/* k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in ... */
static void C_ccall f_2380(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(39,c,3))){C_save_and_reclaim((void *)f_2380,2,av);}
a=C_alloc(39);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4215,a[2]=t4,a[3]=((C_word*)t0)[33],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4215(t6,t2,t1);}

/* k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in ... */
static void C_ccall f_2383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,2))){C_save_and_reclaim((void *)f_2383,2,av);}
a=C_alloc(36);
t2=C_a_i_cons(&a,2,lf[69],*((C_word*)lf[70]+1));
t3=C_mutate2((C_word*)lf[70]+1 /* (set! ##sys#features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:319: collect-options */
t5=((C_word*)((C_word*)t0)[21])[1];
f_2035(t5,t4,lf[310]);}

/* k3519 in map-loop898 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in ... */
static void C_ccall f_3521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3521,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3496(t6,((C_word*)t0)[5],t5);}

/* k3121 in for-each-loop1077 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in ... */
static void C_ccall f_3123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3123,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3113(t3,((C_word*)t0)[4],t2);}

/* k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in ... */
static void C_ccall f_2377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(40,c,3))){C_save_and_reclaim((void *)f_2377,2,av);}
a=C_alloc(40);
t2=*((C_word*)lf[68]+1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=t2,tmp=(C_word)a,a+=34,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4238,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4246,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:315: collect-options */
t6=((C_word*)((C_word*)t0)[21])[1];
f_2035(t6,t5,lf[314]);}

/* k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in ... */
static void C_ccall f_2371(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(40,c,3))){C_save_and_reclaim((void *)f_2371,2,av);}
a=C_alloc(40);
t2=*((C_word*)lf[67]+1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=t2,tmp=(C_word)a,a+=34,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4271,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:312: collect-options */
t6=((C_word*)((C_word*)t0)[21])[1];
f_2035(t6,t5,lf[316]);}

/* k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in ... */
static void C_ccall f_2374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(39,c,3))){C_save_and_reclaim((void *)f_2374,2,av);}
a=C_alloc(39);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4248,a[2]=t4,a[3]=((C_word*)t0)[33],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4248(t6,t2,t1);}

/* k4125 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in ... */
static void C_ccall f_4127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4127,2,av);}
/* batch-driver.scm:342: arg-val */
f_1945(((C_word*)t0)[3],t1);}

/* for-each-loop1077 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in ... */
static void C_fcall f_3113(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_3113,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3123,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3024,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:557: load-type-database */
t8=*((C_word*)lf[170]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in ... */
static void C_ccall f_2368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,2))){C_save_and_reclaim((void *)f_2368,2,av);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[36],*((C_word*)lf[30]+1)))){
/* batch-driver.scm:307: load-verbose */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2371(2,av2);}}}

/* k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in ... */
static void C_fcall f_2362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(33,0,2))){
C_save_and_reclaim_args((void *)trf_2362,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[322],t3))){
t4=C_set_block_item(lf[323] /* ##compiler#no-global-procedure-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2365(t5,t4);}
else{
t4=t2;
f_2365(t4,C_SCHEME_UNDEFINED);}}

/* k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in ... */
static void C_fcall f_2365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(41,0,3))){
C_save_and_reclaim_args((void *)trf_2365,2,t0,t1);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[318],t3))){
t4=*((C_word*)lf[293]+1);
t5=C_i_check_list_2(*((C_word*)lf[293]+1),lf[43]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4329,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4396,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t8)[1];
f_4396(t10,t6,*((C_word*)lf[293]+1));}
else{
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2368(2,av2);}}}

/* k3098 in for-each-loop1098 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in ... */
static void C_ccall f_3100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3100,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3090(t3,((C_word*)t0)[4],t2);}

/* k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in ... */
static void C_fcall f_2356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(33,0,2))){
C_save_and_reclaim_args((void *)trf_2356,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[326],t3))){
t4=C_set_block_item(lf[327] /* ##compiler#no-bound-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2359(t5,t4);}
else{
t4=t2;
f_2359(t4,C_SCHEME_UNDEFINED);}}

/* k3393 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in ... */
static void C_ccall f_3395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3395,2,av);}
if(C_truep(t1)){
/* batch-driver.scm:493: display-real-name-table */
t2=*((C_word*)lf[214]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_2607(2,av2);}}}

/* k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in ... */
static void C_fcall f_2359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(33,0,2))){
C_save_and_reclaim_args((void *)trf_2359,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[324],t3))){
t4=C_set_block_item(lf[325] /* ##compiler#no-procedure-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2362(t5,t4);}
else{
t4=t2;
f_2362(t4,C_SCHEME_UNDEFINED);}}

/* k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in ... */
static void C_ccall f_2350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,2))){C_save_and_reclaim((void *)f_2350,2,av);}
a=C_alloc(33);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[2],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=((C_word*)t0)[5];
if(C_truep(C_u_i_memq(lf[330],t4))){
t5=C_set_block_item(lf[331] /* ##compiler#undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t6=t3;
f_2353(t6,t5);}
else{
t5=t3;
f_2353(t5,C_SCHEME_UNDEFINED);}}

/* k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in ... */
static void C_fcall f_2353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(33,0,2))){
C_save_and_reclaim_args((void *)trf_2353,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[328],t3))){
t4=C_set_block_item(lf[329] /* ##compiler#no-argc-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2356(t5,t4);}
else{
t4=t2;
f_2356(t4,C_SCHEME_UNDEFINED);}}

/* k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1779(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(!C_demand(C_calculate_demand(41,0,2))){
C_save_and_reclaim_args((void *)trf_1779,2,t0,t1);}
a=C_alloc(41);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[20],t3);
t5=(C_truep(t4)?C_i_cadr(t4):C_SCHEME_FALSE);
t6=t5;
t7=((C_word*)t0)[2];
t8=C_u_i_memq(lf[21],t7);
t9=((C_word*)t0)[2];
t10=C_u_i_memq(lf[22],t9);
t11=((C_word*)t0)[2];
t12=C_u_i_memq(lf[23],t11);
t13=C_SCHEME_END_OF_LIST;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t0)[2];
t16=C_u_i_memq(lf[24],t15);
t17=((C_word*)t0)[2];
t18=C_u_i_memq(lf[25],t17);
t19=((C_word*)t0)[2];
t20=C_u_i_memq(lf[26],t19);
t21=C_SCHEME_TRUE;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=((C_word*)t0)[2];
t24=C_u_i_memq(lf[27],t23);
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_FALSE;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=((C_word*)t0)[2];
t32=C_u_i_memq(lf[28],t31);
t33=((C_word*)t0)[2];
t34=C_u_i_memq(lf[29],t33);
t35=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1805,a[2]=t26,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t30,a[8]=((C_word*)t0)[6],a[9]=t14,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t28,a[14]=t12,a[15]=((C_word*)t0)[10],a[16]=t20,a[17]=t18,a[18]=((C_word*)t0)[11],a[19]=t24,a[20]=((C_word*)t0)[12],a[21]=t22,a[22]=((C_word*)t0)[13],a[23]=t6,a[24]=t32,a[25]=((C_word*)t0)[14],a[26]=t2,a[27]=t8,a[28]=((C_word*)t0)[15],a[29]=t10,a[30]=t16,tmp=(C_word)a,a+=31,tmp);
if(C_truep(t34)){
t36=t35;
f_1805(t36,t34);}
else{
t36=((C_word*)t0)[2];
t37=t35;
f_1805(t37,C_u_i_memq(lf[402],t36));}}

/* k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_1771,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4869(t6,t2,t1);}

/* k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,2))){C_save_and_reclaim((void *)f_1774,2,av);}
a=C_alloc(28);
t2=t1;
t3=*((C_word*)lf[17]+1);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=lf[18];
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=((C_word*)t0)[2];
t17=C_u_i_memq(lf[19],t16);
t18=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t11,a[12]=t13,a[13]=t15,a[14]=t9,a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t17)){
t19=t18;
f_1779(t19,t17);}
else{
t19=((C_word*)t0)[2];
t20=C_u_i_memq(lf[279],t19);
if(C_truep(t20)){
t21=t18;
f_1779(t21,t20);}
else{
t21=((C_word*)t0)[2];
t22=C_u_i_memq(lf[20],t21);
t23=t18;
f_1779(t23,t22);}}}

/* k3347 in map-loop969 in k3307 in k3304 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in ... */
static void C_ccall f_3349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3349,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3324(t6,((C_word*)t0)[5],t5);}

/* k4666 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in ... */
static void C_ccall f_4668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4668,2,av);}
t2=C_set_block_item(lf[127] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_2283(t4,t3);}

/* k1904 in print-expr in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1906,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[43]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_1922(t7,((C_word*)t0)[3],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3369 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in ... */
static void C_ccall f_3371(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3371,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[112]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:499: ##sys#print */
t6=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[209];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3375 in k3369 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in ... */
static void C_ccall f_3377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3377,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:499: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[205]+1);
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3551 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in ... */
static void C_ccall f_3553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_3553,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[229]+1);
t8=C_i_check_list_2(*((C_word*)lf[229]+1),lf[57]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3679,a[2]=t5,a[3]=t11,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3679(t13,t9,*((C_word*)lf[229]+1));}

/* k3473 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_ccall f_3475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3475,2,av);}
/* batch-driver.scm:478: quit */
t2=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[224];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4618 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in ... */
static void C_ccall f_4620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4620,2,av);}
a=C_alloc(7);
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=C_mutate2((C_word*)lf[354]+1 /* (set! ##compiler#inline-max-size ...) */,t2);
t5=((C_word*)t0)[2];
f_2322(t5,t4);}
else{
/* batch-driver.scm:251: quit */
t4=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[355];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in ... */
static void C_fcall f_2301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2301,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[358],t3))){
t4=C_set_block_item(lf[359] /* ##compiler#external-protos-first */,0,C_SCHEME_TRUE);
t5=t2;
f_2304(t5,t4);}
else{
t4=t2;
f_2304(t4,C_SCHEME_UNDEFINED);}}

/* k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in ... */
static void C_fcall f_2307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(40,0,2))){
C_save_and_reclaim_args((void *)trf_2307,2,t0,t1);}
a=C_alloc(40);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[61],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=C_set_block_item(lf[179] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t6=C_set_block_item(lf[356] /* ##compiler#local-definitions */,0,C_SCHEME_TRUE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[19],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:244: option-arg */
f_1718(t7,t3);}
else{
t5=t4;
f_2312(t5,C_SCHEME_FALSE);}}

/* k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in ... */
static void C_fcall f_2304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2304,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[357],t3))){
t4=C_set_block_item(lf[179] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t5=t2;
f_2307(t5,t4);}
else{
t4=t2;
f_2307(t4,C_SCHEME_UNDEFINED);}}

/* k4624 in k4618 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in ... */
static void C_ccall f_4626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4626,2,av);}
t2=C_mutate2((C_word*)lf[354]+1 /* (set! ##compiler#inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_2322(t3,t2);}

/* map-loop898 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_fcall f_3496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3496,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
/* batch-driver.scm:481: ->string */
t6=*((C_word*)lf[227]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3492 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_ccall f_3494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3494,2,av);}
/* batch-driver.scm:480: string-intersperse */
t2=*((C_word*)lf[225]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[226];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in ... */
static void C_ccall f_2702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,5))){C_save_and_reclaim((void *)f_2702,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:612: print-db */
t3=((C_word*)((C_word*)t0)[20])[1];
f_1872(t3,t2,lf[143],lf[144],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in ... */
static void C_ccall f_2708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_2708,2,av);}
a=C_alloc(22);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:619: debugging */
t3=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[36];
av2[3]=lf[110];
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[20],a[14]=((C_word*)t0)[6],a[15]=((C_word*)t0)[21],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[22])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2946,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:655: begin-time */
t4=((C_word*)((C_word*)t0)[11])[1];
f_2070(t4,t3);}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2825(2,av2);}}}}

/* k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in ... */
static void C_ccall f_2705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_2705,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_i_memq(lf[141],*((C_word*)lf[30]+1)))){
/* batch-driver.scm:615: print-program-statistics */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2708(2,av2);}}}

/* k4631 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in ... */
static void C_ccall f_4633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4633,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_2317(t3,t2);}

/* k4637 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in ... */
static void C_ccall f_4639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4639,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_2312(t3,t2);}

/* k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in ... */
static void C_fcall f_2262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2262,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[377],t3))){
t4=C_set_block_item(lf[378] /* ##compiler#emit-closure-info */,0,C_SCHEME_FALSE);
t5=t2;
f_2265(t5,t4);}
else{
t4=t2;
f_2265(t4,C_SCHEME_UNDEFINED);}}

/* k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in ... */
static void C_fcall f_2265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2265,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[375],t3))){
t4=C_set_block_item(lf[376] /* ##compiler#compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t5=t2;
f_2268(t5,t4);}
else{
t4=t2;
f_2268(t4,C_SCHEME_UNDEFINED);}}

/* k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in ... */
static void C_fcall f_2268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2268,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[374],t3))){
t4=C_set_block_item(lf[356] /* ##compiler#local-definitions */,0,C_SCHEME_TRUE);
t5=t2;
f_2271(t5,t4);}
else{
t4=t2;
f_2271(t4,C_SCHEME_UNDEFINED);}}

/* k3422 in k3419 in k3416 in for-each-loop925 in k3408 in a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in ... */
static void C_ccall f_3424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3424,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* batch-driver.scm:490: ##sys#print */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2893 in k2890 in k2887 in k2884 in k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in ... */
static void C_ccall f_2895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_2895,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5644,a[2]=t2,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t3;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[113];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}

/* k2890 in k2887 in k2884 in k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in ... */
static void C_ccall f_2892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2892,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:692: compiler-cleanup-hook */
t3=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3425 in k3422 in k3419 in k3416 in for-each-loop925 in k3408 in a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in ... */
static void C_ccall f_3427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3427,2,av);}
/* batch-driver.scm:490: ##sys#write-char-0 */
t2=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3419 in k3416 in for-each-loop925 in k3408 in a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in ... */
static void C_ccall f_3421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3421,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:490: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[218];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in ... */
static void C_ccall f_2717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_2717,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:621: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[13];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in ... */
static void C_ccall f_2714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_2714,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:620: begin-time */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2070(t3,t2);}

/* k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in ... */
static void C_ccall f_2346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(39,c,3))){C_save_and_reclaim((void *)f_2346,2,av);}
a=C_alloc(39);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4434,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4482,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:285: collect-options */
t5=((C_word*)((C_word*)t0)[22])[1];
f_2035(t5,t4,lf[246]);}

/* k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in ... */
static void C_ccall f_2343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,2))){C_save_and_reclaim((void *)f_2343,2,av);}
a=C_alloc(33);
t2=C_mutate2((C_word*)lf[66]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[14])){
if(C_truep(((C_word*)t0)[7])){
if(C_truep(C_i_string_equal_p(((C_word*)t0)[14],((C_word*)t0)[7]))){
/* batch-driver.scm:281: quit */
t4=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[333];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2346(2,av2);}}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2346(2,av2);}}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2346(2,av2);}}}

/* k2887 in k2884 in k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in ... */
static void C_ccall f_2889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2889,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_memq(lf[115],*((C_word*)lf[30]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2908,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:691: ##sys#stop-timer */
t4=*((C_word*)lf[117]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5247,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:692: compiler-cleanup-hook */
t4=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3452 in for-each-loop925 in k3408 in a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in ... */
static void C_ccall f_3454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3454,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3444(t3,((C_word*)t0)[4],t2);}

/* k2884 in k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in ... */
static void C_ccall f_2886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2886,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:689: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2080(t3,t2,lf[118]);}

/* k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in ... */
static void C_ccall f_2883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2883,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:688: close-output-port */
t3=*((C_word*)lf[119]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2886(2,av2);}}}

/* k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in ... */
static void C_ccall f_2247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,2))){C_save_and_reclaim((void *)f_2247,2,av);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[387],*((C_word*)lf[30]+1)))){
t3=C_set_block_item(((C_word*)t0)[36],0,C_SCHEME_TRUE);
t4=t2;
f_2250(t4,t3);}
else{
t3=t2;
f_2250(t3,C_SCHEME_UNDEFINED);}}

/* k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in ... */
static void C_fcall f_2244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(37,0,2))){
C_save_and_reclaim_args((void *)trf_2244,2,t0,t1);}
a=C_alloc(37);
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep(C_i_memq(lf[115],*((C_word*)lf[30]+1)))){
/* batch-driver.scm:200: ##sys#start-timer */
t3=*((C_word*)lf[388]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2247(2,av2);}}}

/* k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in ... */
static void C_ccall f_2880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,9))){C_save_and_reclaim((void *)f_2880,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:685: generate-code */
t3=*((C_word*)lf[120]+1);{
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=((C_word*)t0)[8];
av2[5]=((C_word*)t0)[5];
av2[6]=((C_word*)t0)[9];
av2[7]=((C_word*)t0)[10];
av2[8]=((C_word*)t0)[11];
av2[9]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t3+1)))(10,av2);}}

/* k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_1765,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[16]+1);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t5,a[10]=t7,a[11]=t6,tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4905,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:76: get-environment-variable */
t10=*((C_word*)lf[405]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[406];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* map-loop280 in k4790 in a4775 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 in ... */
static void C_fcall f_4797(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_4797,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* batch-driver.scm:182: string->symbol */
t6=*((C_word*)lf[303]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in ... */
static void C_ccall f_2337(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(45,c,2))){C_save_and_reclaim((void *)f_2337,2,av);}
a=C_alloc(45);
t2=C_mutate2((C_word*)lf[64]+1 /* (set! ##compiler#verbose-mode ...) */,((C_word*)t0)[2]);
t3=C_set_block_item(lf[65] /* ##sys#read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=*((C_word*)lf[16]+1);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4501,a[2]=t4,a[3]=((C_word*)t0)[34],a[4]=t7,a[5]=t9,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:277: collect-options */
t11=((C_word*)((C_word*)t0)[23])[1];
f_2035(t11,t10,lf[334]);}

/* k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in ... */
static void C_ccall f_2334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(41,c,4))){C_save_and_reclaim((void *)f_2334,2,av);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[335],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4546,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5792,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[340];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2337(2,av2);}}}

/* k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in ... */
static void C_ccall f_2331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(41,c,4))){C_save_and_reclaim((void *)f_2331,2,av);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[341],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5798,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[342];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2334(2,av2);}}}

/* k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 in ... */
static void C_ccall f_2228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(44,c,3))){C_save_and_reclaim((void *)f_2228,2,av);}
a=C_alloc(44);
t2=C_i_check_list_2(t1,lf[57]);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[37],a[3]=t5,a[4]=((C_word*)t0)[38],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4733(t7,t3,t1);}

/* k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in ... */
static void C_fcall f_2271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2271,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[373],t3))){
t4=C_set_block_item(lf[183] /* ##compiler#enable-inline-files */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[179] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t6=t2;
f_2274(t6,t5);}
else{
t4=t2;
f_2274(t4,C_SCHEME_UNDEFINED);}}

/* for-each-loop925 in k3408 in a3405 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in ... */
static void C_fcall f_3444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_3444,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3454,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=*((C_word*)lf[31]+1);
t8=*((C_word*)lf[31]+1);
t9=C_i_check_port_2(*((C_word*)lf[31]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3418,a[2]=t5,a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:490: ##sys#print */
t11=*((C_word*)lf[34]+1);{
C_word av2[5];
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[219];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[31]+1);
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2221 in k2217 in map-loop308 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in ... */
static void C_ccall f_2223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_2223,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in ... */
static void C_ccall f_2877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_2877,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=t3;
t5=C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5656,a[2]=t4,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[121];
av2[4]=t5;
C_apply(5,av2);}}

/* k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in ... */
static void C_fcall f_2274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2274,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_set_block_item(lf[372] /* ##sys#notices-enabled */,0,C_SCHEME_TRUE);
t4=t2;
f_2277(t4,t3);}
else{
t3=t2;
f_2277(t3,C_SCHEME_UNDEFINED);}}

/* k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in ... */
static void C_ccall f_2871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2871,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm:681: begin-time */
t3=((C_word*)((C_word*)t0)[12])[1];
f_2070(t3,t2);}

/* k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in ... */
static void C_fcall f_2277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2277,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[370],t3))){
t4=C_set_block_item(lf[371] /* ##compiler#strict-variable-types */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[54] /* ##compiler#enable-specialization */,0,C_SCHEME_TRUE);
t6=t2;
f_2280(t6,t5);}
else{
t4=t2;
f_2280(t4,C_SCHEME_UNDEFINED);}}

/* k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in ... */
static void C_ccall f_2874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2874,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:683: open-output-file */
t3=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=*((C_word*)lf[31]+1);
f_2877(2,av2);}}}

/* k4790 in a4775 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4792,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4797(t5,((C_word*)t0)[4],t1);}

/* k4200 in for-each-loop569 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in ... */
static void C_ccall f_4202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4202,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4192(t3,((C_word*)t0)[4],t2);}

/* k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_ccall f_3019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3019,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm:559: collect-options */
t3=((C_word*)((C_word*)t0)[12])[1];
f_2035(t3,t2,lf[175]);}

/* k4063 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in ... */
static void C_ccall f_4065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4065,2,av);}
a=C_alloc(5);
t2=C_set_block_item(lf[235] /* ##compiler#emit-profile */,0,C_SCHEME_TRUE);
t3=C_mutate2((C_word*)lf[280]+1 /* (set! ##compiler#profiled-procedures ...) */,lf[281]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm:367: append */
t5=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=*((C_word*)lf[285]+1);
av2[4]=lf[286];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
/* batch-driver.scm:367: append */
t5=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=*((C_word*)lf[285]+1);
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1697(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1697,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:37: make-parameter */
t4=*((C_word*)lf[415]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_1749,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_mutate2((C_word*)lf[9]+1 /* (set! ##compiler#explicit-use-flag ...) */,C_u_i_memq(lf[10],t2));
t4=((C_word*)t0)[2];
t5=C_mutate2((C_word*)lf[11]+1 /* (set! emit-debug-info ...) */,C_u_i_memq(lf[12],t4));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_truep(*((C_word*)lf[11]+1))?lf[411]:C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[9]+1))){
/* batch-driver.scm:57: append */
t8=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=*((C_word*)lf[412]+1);
av2[3]=t7;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t8=C_a_i_cons(&a,2,lf[246],*((C_word*)lf[413]+1));
t9=C_a_i_list(&a,1,t8);
/* batch-driver.scm:57: append */
t10=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t6;
av2[2]=*((C_word*)lf[412]+1);
av2[3]=t7;
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}

/* k1691 in k1688 in k1685 */
static void C_ccall f_1693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1693,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:36: make-parameter */
t3=*((C_word*)lf[415]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a4775 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_4776,3,av);}
a=C_alloc(10);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4792,a[2]=t5,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* string->list */
t8=*((C_word*)lf[395]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k1688 in k1685 */
static void C_ccall f_1690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1690,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k4069 in k4063 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in ... */
static void C_ccall f_4071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4071,2,av);}
a=C_alloc(6);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[4];
t4=C_a_i_list(&a,1,lf[282]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5746,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[283];
av2[4]=t4;
C_apply(5,av2);}}
else{
t3=((C_word*)t0)[4];
t4=C_a_i_list(&a,1,lf[284]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5752,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[283];
av2[4]=t4;
C_apply(5,av2);}}}

/* k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in ... */
static void C_ccall f_2253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,2))){C_save_and_reclaim((void *)f_2253,2,av);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[383],t3))){
/* batch-driver.scm:205: warning */
t4=*((C_word*)lf[381]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[384];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2256(2,av2);}}}

/* k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in ... */
static void C_fcall f_2250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2250,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[385],t3))){
/* batch-driver.scm:203: warning */
t4=*((C_word*)lf[381]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[386];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2253(2,av2);}}}

/* k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_2202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(44,c,2))){C_save_and_reclaim((void *)f_2202,2,av);}
a=C_alloc(44);
t2=C_i_memq(lf[56],*((C_word*)lf[30]+1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|38,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=t6,a[38]=t7,tmp=(C_word)a,a+=39,tmp);
/* batch-driver.scm:193: collect-options */
t9=((C_word*)((C_word*)t0)[24])[1];
f_2035(t9,t8,lf[393]);}

/* k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in ... */
static void C_ccall f_2256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,2))){C_save_and_reclaim((void *)f_2256,2,av);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[380],t3))){
/* batch-driver.scm:207: warning */
t4=*((C_word*)lf[381]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2259(2,av2);}}}

/* k4769 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4771,2,av);}
/* batch-driver.scm:187: exit */
t2=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in ... */
static void C_ccall f_2259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,2))){C_save_and_reclaim((void *)f_2259,2,av);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[379],t3))){
t4=C_set_block_item(lf[9] /* ##compiler#explicit-use-flag */,0,C_SCHEME_TRUE);
t5=C_set_block_item(((C_word*)t0)[25],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_END_OF_LIST);
t7=t2;
f_2262(t7,t6);}
else{
t4=t2;
f_2262(t4,C_SCHEME_UNDEFINED);}}

/* k1685 */
static void C_ccall f_1687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1687,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k4223 in for-each-loop543 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in ... */
static void C_ccall f_4225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4225,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4215(t3,((C_word*)t0)[4],t2);}

/* k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in ... */
static void C_fcall f_2237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(37,0,2))){
C_save_and_reclaim_args((void *)trf_2237,2,t0,t1);}
a=C_alloc(37);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[59],t2);
t4=C_i_not(t3);
t5=C_mutate2((C_word*)lf[60]+1 /* (set! ##compiler#enable-module-registration ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep(*((C_word*)lf[54]+1))){
t7=C_set_block_item(((C_word*)t0)[22],0,C_SCHEME_TRUE);
t8=t6;
f_2244(t8,t7);}
else{
t7=t6;
f_2244(t7,C_SCHEME_UNDEFINED);}}

/* k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in ... */
static void C_fcall f_2286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2286,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[159],t3))){
t4=C_set_block_item(lf[159] /* unsafe */,0,C_SCHEME_TRUE);
t5=t2;
f_2289(t5,t4);}
else{
t4=t2;
f_2289(t4,C_SCHEME_UNDEFINED);}}

/* k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in ... */
static void C_fcall f_2283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2283,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[101],t3))){
t4=C_set_block_item(lf[101] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t5=t2;
f_2286(t5,t4);}
else{
t4=t2;
f_2286(t4,C_SCHEME_UNDEFINED);}}

/* k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in ... */
static void C_ccall f_2234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(37,c,2))){C_save_and_reclaim((void *)f_2234,2,av);}
a=C_alloc(37);
t2=C_mutate2((C_word*)lf[58]+1 /* (set! ##compiler#import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[389],t4))){
if(C_truep(((C_word*)t0)[17])){
t5=t3;
f_2237(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_set_block_item(lf[390] /* ##compiler#all-import-libraries */,0,C_SCHEME_TRUE);
t6=t3;
f_2237(t6,t5);}}
else{
t5=t3;
f_2237(t5,C_SCHEME_UNDEFINED);}}

/* k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in ... */
static void C_fcall f_2280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(43,0,4))){
C_save_and_reclaim_args((void *)trf_2280,2,t0,t1);}
a=C_alloc(43);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[368],t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[22],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5816,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[369];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;
f_2283(t4,C_SCHEME_UNDEFINED);}}

/* k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in ... */
static void C_fcall f_2289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2289,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[366],t3))){
t4=C_set_block_item(lf[367] /* ##sys#setup-mode */,0,C_SCHEME_TRUE);
t5=t2;
f_2292(t5,t4);}
else{
t4=t2;
f_2292(t4,C_SCHEME_UNDEFINED);}}

/* k2217 in map-loop308 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in ... */
static void C_ccall f_2219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2219,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#string-append */
t4=*((C_word*)lf[391]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[392];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in ... */
static void C_ccall f_2828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,4))){C_save_and_reclaim((void *)f_2828,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[15])[1])?*((C_word*)lf[133]+1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[15])[1];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2940,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=t5;
t7=C_a_i_list(&a,1,t4);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5662,a[2]=t6,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t8;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[135];
av2[4]=t7;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2831(2,av2);}}}

/* k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in ... */
static void C_ccall f_2825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_2825,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:659: print-node */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1850(t3,t2,lf[136],lf[137],((C_word*)((C_word*)t0)[2])[1]);}

/* for-each-loop543 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in ... */
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4215,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4225,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:313: g544 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in ... */
static void C_fcall f_2295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2295,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[362],t3))){
t4=C_mutate2((C_word*)lf[363]+1 /* (set! number-type ...) */,lf[364]);
t5=t2;
f_2298(t5,t4);}
else{
t4=t2;
f_2298(t4,C_SCHEME_UNDEFINED);}}

/* k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in ... */
static void C_fcall f_2292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2292,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[365],t3))){
t4=C_set_block_item(lf[133] /* ##compiler#insert-timer-checks */,0,C_SCHEME_FALSE);
t5=t2;
f_2295(t5,t4);}
else{
t4=t2;
f_2295(t4,C_SCHEME_UNDEFINED);}}

/* k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in ... */
static void C_fcall f_2298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(36,0,2))){
C_save_and_reclaim_args((void *)trf_2298,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[360],t3))){
t4=C_set_block_item(lf[361] /* ##compiler#block-compilation */,0,C_SCHEME_TRUE);
t5=t2;
f_2301(t5,t4);}
else{
t4=t2;
f_2301(t4,C_SCHEME_UNDEFINED);}}

/* k3022 in for-each-loop1077 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in ... */
static void C_ccall f_3024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3024,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* batch-driver.scm:558: quit */
t2=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[174];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in ... */
static void C_ccall f_2867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_2867,7,av);}
a=C_alloc(13);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2871,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,a[7]=t5,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=t6,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:680: end-time */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2080(t8,t7,lf[123]);}

/* a2860 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in ... */
static void C_ccall f_2861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2861,2,av);}
/* batch-driver.scm:679: prepare-for-code-generation */
t2=*((C_word*)lf[111]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop569 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in ... */
static void C_fcall f_4192(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_4192,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4202,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:322: ##sys#resolve-include-filename */
t7=*((C_word*)lf[186]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in ... */
static void C_ccall f_2856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,7))){C_save_and_reclaim((void *)f_2856,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:678: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[9];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in ... */
static void C_ccall f_2850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2850,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
/* batch-driver.scm:675: exit */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2853(2,av2);}}}

/* k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in ... */
static void C_ccall f_2853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2853,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:676: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2070(t3,t2);}

/* k2974 in k2968 in k2965 in k2962 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in ... */
static void C_ccall f_2976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2976,2,av);}
/* batch-driver.scm:609: emit-type-file */
t2=*((C_word*)lf[146]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2968 in k2965 in k2962 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in ... */
static void C_ccall f_2970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_2970,2,av);}
a=C_alloc(11);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=t2;
t4=C_a_i_list(&a,1,((C_word*)((C_word*)t0)[2])[1]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5668,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[147];
av2[4]=t4;
C_apply(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_2698(2,av2);}}}

/* k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in ... */
static void C_ccall f_2847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_2847,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:674: print-node */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1850(t3,t2,lf[125],lf[126],((C_word*)((C_word*)t0)[2])[1]);}

/* k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in ... */
static void C_ccall f_2841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_2841,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:670: print-db */
t3=((C_word*)((C_word*)t0)[13])[1];
f_1872(t3,t2,lf[129],lf[130],((C_word*)t0)[3],((C_word*)t0)[14]);}

/* k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in ... */
static void C_ccall f_2844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_2844,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(*((C_word*)lf[127]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:105: current-milliseconds */
t4=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2847(2,av2);}}}

/* k4756 in map-loop308 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in ... */
static void C_ccall f_4758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4758,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4733(t6,((C_word*)t0)[5],t5);}

/* map-loop78 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_4869(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4869,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:74: g84 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2965 in k2962 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in ... */
static void C_ccall f_2967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2967,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(lf[148],*((C_word*)lf[30]+1)))){
/* batch-driver.scm:605: dump-global-refs */
t3=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2970(2,av2);}}}

/* k2962 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in ... */
static void C_ccall f_2964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2964,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(lf[150],*((C_word*)lf[30]+1)))){
/* batch-driver.scm:603: dump-defined-globals */
t3=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2967(2,av2);}}}

/* k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in ... */
static void C_ccall f_2838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_2838,2,av);}
a=C_alloc(15);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:669: end-time */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2080(t4,t3,lf[131]);}

/* k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f_2831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_2831,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:666: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2070(t3,t2);}

/* k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in ... */
static void C_ccall f_2834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_2834,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:668: perform-closure-conversion */
t3=*((C_word*)lf[132]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4181 in map-loop588 in k4148 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in ... */
static void C_ccall f_4183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4183,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4158(t6,((C_word*)t0)[5],t5);}

/* k3189 in for-each-loop1033 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in ... */
static void C_ccall f_3191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3191,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3200,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:537: file-exists? */
t4=*((C_word*)lf[185]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4154 in k4148 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in ... */
static void C_ccall f_4156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4156,2,av);}
/* batch-driver.scm:333: append */
t2=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4148 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in ... */
static void C_ccall f_4150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_4150,2,av);}
a=C_alloc(11);
t2=C_i_check_list_2(t1,lf[57]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4158(t7,t3,t1);}

/* map-loop308 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in ... */
static void C_fcall f_4733(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_4733,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2219,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:191: string->symbol */
t8=*((C_word*)lf[303]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4892 in map-loop78 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4894,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4869(t6,((C_word*)t0)[5],t5);}

/* map-loop588 in k4148 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in ... */
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_4158,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4147,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:335: string->symbol */
t7=*((C_word*)lf[303]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3173 in for-each-loop1054 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_ccall f_3175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3175,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3165(t3,((C_word*)t0)[4],t2);}

/* k4820 in map-loop280 in k4790 in a4775 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in ... */
static void C_ccall f_4822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4822,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4797(t6,((C_word*)t0)[5],t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_driver_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_driver_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(2251)){
C_save(t1);
C_rereclaim2(2251*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,416);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],23,"user-post-analysis-pass");
lf[5]=C_h_intern(&lf[5],19,"compile-source-file");
lf[6]=C_h_intern(&lf[6],13,"\010compilerquit");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[9]=C_h_intern(&lf[9],26,"\010compilerexplicit-use-flag");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],15,"emit-debug-info");
lf[12]=C_h_intern(&lf[12],10,"debug-info");
lf[13]=C_h_intern(&lf[13],12,"\004coredeclare");
lf[14]=C_h_intern(&lf[14],7,"verbose");
lf[15]=C_h_intern(&lf[15],11,"output-file");
lf[16]=C_h_intern(&lf[16],23,"\010compilerchop-separator");
lf[17]=C_h_intern(&lf[17],36,"\010compilerdefault-optimization-passes");
lf[18]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[19]=C_h_intern(&lf[19],7,"profile");
lf[20]=C_h_intern(&lf[20],12,"profile-name");
lf[21]=C_h_intern(&lf[21],9,"heap-size");
lf[22]=C_h_intern(&lf[22],13,"keyword-style");
lf[23]=C_h_intern(&lf[23],10,"clustering");
lf[24]=C_h_intern(&lf[24],4,"unit");
lf[25]=C_h_intern(&lf[25],12,"analyze-only");
lf[26]=C_h_intern(&lf[26],7,"dynamic");
lf[27]=C_h_intern(&lf[27],4,"lfa2");
lf[28]=C_h_intern(&lf[28],6,"module");
lf[29]=C_h_intern(&lf[29],7,"nursery");
lf[30]=C_h_intern(&lf[30],26,"\010compilerdebugging-chicken");
lf[31]=C_h_intern(&lf[31],19,"\003sysstandard-output");
lf[32]=C_h_intern(&lf[32],6,"printf");
lf[33]=C_h_intern(&lf[33],16,"\003syswrite-char-0");
lf[34]=C_h_intern(&lf[34],9,"\003sysprint");
lf[35]=C_h_intern(&lf[35],18,"\010compilerdebugging");
lf[36]=C_h_intern(&lf[36],1,"p");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\004pass");
lf[38]=C_h_intern(&lf[38],19,"\010compilerdump-nodes");
lf[39]=C_h_intern(&lf[39],12,"pretty-print");
lf[40]=C_h_intern(&lf[40],30,"\010compilerbuild-expression-tree");
lf[41]=C_h_intern(&lf[41],34,"\010compilerdisplay-analysis-database");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\013(iteration ");
lf[43]=C_h_intern(&lf[43],8,"for-each");
lf[44]=C_h_intern(&lf[44],7,"newline");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[46]=C_h_intern(&lf[46],9,"substring");
lf[47]=C_h_intern(&lf[47],20,"current-milliseconds");
lf[48]=C_h_intern(&lf[48],5,"round");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\003: \011");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\030milliseconds needed for ");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],30,"\010compilerenable-specialization");
lf[55]=C_h_intern(&lf[55],10,"specialize");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],3,"map");
lf[58]=C_h_intern(&lf[58],25,"\010compilerimport-libraries");
lf[59]=C_h_intern(&lf[59],22,"no-module-registration");
lf[60]=C_h_intern(&lf[60],35,"\010compilerenable-module-registration");
lf[61]=C_h_intern(&lf[61],16,"emit-inline-file");
lf[62]=C_h_intern(&lf[62],14,"emit-type-file");
lf[63]=C_h_intern(&lf[63],12,"inline-limit");
lf[64]=C_h_intern(&lf[64],21,"\010compilerverbose-mode");
lf[65]=C_h_intern(&lf[65],31,"\003sysread-error-with-line-number");
lf[66]=C_h_intern(&lf[66],21,"\003sysinclude-pathnames");
lf[67]=C_h_intern(&lf[67],17,"register-feature!");
lf[68]=C_h_intern(&lf[68],19,"unregister-feature!");
lf[69]=C_h_intern(&lf[69],19,"\000compiler-extension");
lf[70]=C_h_intern(&lf[70],12,"\003sysfeatures");
lf[71]=C_h_intern(&lf[71],10,"\000compiling");
lf[72]=C_h_intern(&lf[72],25,"\010compilertarget-heap-size");
lf[73]=C_h_intern(&lf[73],26,"\010compilertarget-stack-size");
lf[74]=C_h_intern(&lf[74],8,"no-trace");
lf[75]=C_h_intern(&lf[75],24,"\010compileremit-trace-info");
lf[76]=C_h_intern(&lf[76],40,"\010compilerdisable-stack-overflow-checking");
lf[77]=C_h_intern(&lf[77],29,"disable-stack-overflow-checks");
lf[78]=C_h_intern(&lf[78],23,"\010compilerbootstrap-mode");
lf[79]=C_h_intern(&lf[79],7,"version");
lf[80]=C_h_intern(&lf[80],22,"\010compilerprint-version");
lf[81]=C_h_intern(&lf[81],4,"help");
lf[82]=C_h_intern(&lf[82],20,"\010compilerprint-usage");
lf[83]=C_h_intern(&lf[83],7,"release");
lf[84]=C_h_intern(&lf[84],7,"display");
lf[85]=C_h_intern(&lf[85],15,"chicken-version");
lf[86]=C_h_intern(&lf[86],24,"\010compilersource-filename");
lf[87]=C_h_intern(&lf[87],24,"\003sysline-number-database");
lf[88]=C_h_intern(&lf[88],32,"\010compilercanonicalize-expression");
lf[89]=C_h_intern(&lf[89],28,"\010compilerprofile-lambda-list");
lf[90]=C_h_intern(&lf[90],31,"\010compilerline-number-database-2");
lf[91]=C_h_intern(&lf[91],4,"node");
lf[92]=C_h_intern(&lf[92],6,"lambda");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[94]=C_h_intern(&lf[94],23,"\010compilerconstant-table");
lf[95]=C_h_intern(&lf[95],21,"\010compilerinline-table");
lf[96]=C_h_intern(&lf[96],23,"\010compilerfirst-analysis");
lf[97]=C_h_intern(&lf[97],36,"\010compilerdetermine-loop-and-dispatch");
lf[98]=C_h_intern(&lf[98],41,"\010compilerperform-high-level-optimizations");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\022clustering enabled");
lf[100]=C_h_intern(&lf[100],37,"\010compilerinline-substitutions-enabled");
lf[101]=C_h_intern(&lf[101],22,"optimize-leaf-routines");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[103]=C_h_intern(&lf[103],34,"\010compilertransform-direct-lambdas!");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[105]=C_h_intern(&lf[105],4,"leaf");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\022rewritings enabled");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[108]=C_h_intern(&lf[108],1,"5");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[111]=C_h_intern(&lf[111],36,"\010compilerprepare-for-code-generation");
lf[112]=C_h_intern(&lf[112],7,"sprintf");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[114]=C_h_intern(&lf[114],30,"\010compilercompiler-cleanup-hook");
lf[115]=C_h_intern(&lf[115],1,"t");
lf[116]=C_h_intern(&lf[116],17,"\003sysdisplay-times");
lf[117]=C_h_intern(&lf[117],14,"\003sysstop-timer");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[119]=C_h_intern(&lf[119],17,"close-output-port");
lf[120]=C_h_intern(&lf[120],22,"\010compilergenerate-code");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[122]=C_h_intern(&lf[122],16,"open-output-file");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[124]=C_h_intern(&lf[124],4,"exit");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[126]=C_h_intern(&lf[126],1,"9");
lf[127]=C_h_intern(&lf[127],20,"\003syswarnings-enabled");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[130]=C_h_intern(&lf[130],1,"8");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[132]=C_h_intern(&lf[132],35,"\010compilerperform-closure-conversion");
lf[133]=C_h_intern(&lf[133],28,"\010compilerinsert-timer-checks");
lf[134]=C_h_intern(&lf[134],32,"\010compileremit-global-inline-file");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000&generating global inline file `~a\047 ...");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[137]=C_h_intern(&lf[137],1,"7");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\027secondary flow analysis");
lf[139]=C_h_intern(&lf[139],40,"\010compilerperform-secondary-flow-analysis");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\012doing lfa2");
lf[141]=C_h_intern(&lf[141],1,"s");
lf[142]=C_h_intern(&lf[142],33,"\010compilerprint-program-statistics");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[144]=C_h_intern(&lf[144],1,"4");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[146]=C_h_intern(&lf[146],23,"\010compileremit-type-file");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\035generating type file `~a\047 ...");
lf[148]=C_h_intern(&lf[148],1,"v");
lf[149]=C_h_intern(&lf[149],25,"\010compilerdump-global-refs");
lf[150]=C_h_intern(&lf[150],1,"d");
lf[151]=C_h_intern(&lf[151],29,"\010compilerdump-defined-globals");
lf[152]=C_h_intern(&lf[152],1,"u");
lf[153]=C_h_intern(&lf[153],31,"\010compilerdump-undefined-globals");
lf[154]=C_h_intern(&lf[154],3,"opt");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[156]=C_h_intern(&lf[156],1,"3");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[158]=C_h_intern(&lf[158],31,"\010compilerperform-cps-conversion");
lf[159]=C_h_intern(&lf[159],6,"unsafe");
lf[160]=C_h_intern(&lf[160],34,"\010compilerscan-toplevel-assignments");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\016specialization");
lf[162]=C_h_intern(&lf[162],1,"P");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\010scrutiny");
lf[164]=C_h_intern(&lf[164],19,"\010compilerscrutinize");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\023performing scrutiny");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\027pre-analysis (scrutiny)");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[168]=C_h_intern(&lf[168],1,"0");
lf[169]=C_h_intern(&lf[169],8,"scrutiny");
lf[170]=C_h_intern(&lf[170],27,"\010compilerload-type-database");
lf[171]=C_h_intern(&lf[171],13,"make-pathname");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\005types");
lf[173]=C_h_intern(&lf[173],14,"symbol->string");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\034type-database `~a\047 not found");
lf[175]=C_h_intern(&lf[175],5,"types");
lf[176]=C_h_intern(&lf[176],17,"ignore-repository");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\052default type-database `types.db\047 not found");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010types.db");
lf[179]=C_h_intern(&lf[179],23,"\010compilerinline-locally");
lf[180]=C_h_intern(&lf[180],25,"\010compilerload-inline-file");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[182]=C_h_intern(&lf[182],19,"consult-inline-file");
lf[183]=C_h_intern(&lf[183],28,"\010compilerenable-inline-files");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[185]=C_h_intern(&lf[185],12,"file-exists\077");
lf[186]=C_h_intern(&lf[186],28,"\003sysresolve-include-filename");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[188]=C_h_intern(&lf[188],2,"pp");
lf[189]=C_h_intern(&lf[189],1,"M");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[191]=C_h_intern(&lf[191],11,"concatenate");
lf[192]=C_h_intern(&lf[192],12,"vector->list");
lf[193]=C_h_intern(&lf[193],26,"\010compilerfile-requirements");
lf[194]=C_h_intern(&lf[194],37,"\010compilerinitialize-analysis-database");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\021initial node tree");
lf[196]=C_h_intern(&lf[196],1,"T");
lf[197]=C_h_intern(&lf[197],25,"\010compilerbuild-node-graph");
lf[198]=C_h_intern(&lf[198],32,"\010compilercanonicalize-begin-body");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[201]=C_h_intern(&lf[201],12,"check-syntax");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[203]=C_h_intern(&lf[203],1,"2");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[205]=C_h_intern(&lf[205],18,"\010compilerunit-name");
lf[206]=C_h_intern(&lf[206],10,"\003sysnotice");
lf[207]=C_h_intern(&lf[207],17,"get-output-string");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\032\047 compiled in dynamic mode");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\016library unit `");
lf[210]=C_h_intern(&lf[210],18,"open-output-string");
lf[211]=C_h_intern(&lf[211],37,"\010compilerdisplay-line-number-database");
lf[212]=C_h_intern(&lf[212],1,"n");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[214]=C_h_intern(&lf[214],32,"\010compilerdisplay-real-name-table");
lf[215]=C_h_intern(&lf[215],1,"N");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[217]=C_h_intern(&lf[217],35,"\010compilercompiler-syntax-statistics");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\002\011\011");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[220]=C_h_intern(&lf[220],5,"print");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\030applied compiler syntax:");
lf[222]=C_h_intern(&lf[222],30,"\010compilerwith-debugging-output");
lf[223]=C_h_intern(&lf[223],1,"S");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000;No module definition found for import libraries to emit: ~A");
lf[225]=C_h_intern(&lf[225],18,"string-intersperse");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[227]=C_h_intern(&lf[227],8,"->string");
lf[228]=C_h_intern(&lf[228],28,"\010compilerimmutable-constants");
lf[229]=C_h_intern(&lf[229],19,"\010compilerused-units");
lf[230]=C_h_intern(&lf[230],6,"append");
lf[231]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[232]=C_h_intern(&lf[232],5,"quote");
lf[233]=C_h_intern(&lf[233],28,"\003sysset-profile-info-vector!");
lf[234]=C_h_intern(&lf[234],33,"\010compilerprofile-info-vector-name");
lf[235]=C_h_intern(&lf[235],21,"\010compileremit-profile");
lf[236]=C_h_intern(&lf[236],25,"\003sysregister-profile-info");
lf[237]=C_h_intern(&lf[237],4,"set!");
lf[238]=C_h_intern(&lf[238],13,"\004corecallunit");
lf[239]=C_h_intern(&lf[239],6,"gensym");
lf[240]=C_h_intern(&lf[240],6,"import");
lf[241]=C_h_intern(&lf[241],6,"scheme");
lf[242]=C_h_intern(&lf[242],7,"chicken");
lf[243]=C_h_intern(&lf[243],4,"main");
lf[244]=C_h_intern(&lf[244],11,"\004coremodule");
lf[245]=C_h_intern(&lf[245],28,"\003sysexplicit-library-modules");
lf[246]=C_h_intern(&lf[246],4,"uses");
lf[247]=C_h_intern(&lf[247],7,"declare");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[249]=C_h_intern(&lf[249],1,"1");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[252]=C_h_intern(&lf[252],21,"\010compilerstring->expr");
lf[253]=C_h_intern(&lf[253],7,"reverse");
lf[254]=C_h_intern(&lf[254],27,"\003syscurrent-source-filename");
lf[255]=C_h_intern(&lf[255],33,"\010compilerclose-checked-input-file");
lf[256]=C_h_intern(&lf[256],25,"\010compilerread/source-info");
lf[257]=C_h_intern(&lf[257],16,"\003sysdynamic-wind");
lf[258]=C_h_intern(&lf[258],34,"\010compilercheck-and-open-input-file");
lf[259]=C_h_intern(&lf[259],8,"epilogue");
lf[260]=C_h_intern(&lf[260],8,"prologue");
lf[261]=C_h_intern(&lf[261],8,"postlude");
lf[262]=C_h_intern(&lf[262],7,"prelude");
lf[263]=C_h_intern(&lf[263],11,"make-vector");
lf[264]=C_h_intern(&lf[264],34,"\010compilerline-number-database-size");
lf[265]=C_h_intern(&lf[265],1,"r");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\0001\012Run `csi\047 to start the interactive interpreter.\012");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000.or try `csc\047 for a more convenient interface.\012");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000C\012Enter `chicken -help\047 for information on how to use the compiler,\012");
lf[274]=C_h_intern(&lf[274],5,"-help");
lf[275]=C_h_intern(&lf[275],1,"h");
lf[276]=C_h_intern(&lf[276],2,"-h");
lf[277]=C_h_intern(&lf[277],33,"\010compilerload-identifier-database");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[279]=C_h_intern(&lf[279],18,"accumulate-profile");
lf[280]=C_h_intern(&lf[280],28,"\010compilerprofiled-procedures");
lf[281]=C_h_intern(&lf[281],3,"all");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\015accumulative ");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\032generating ~aprofiled code");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[285]=C_h_intern(&lf[285],39,"\010compilerdefault-profiling-declarations");
lf[286]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000Eyou need to specify -profile-name if using accumulated profiling runs");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[291]=C_h_intern(&lf[291],21,"no-usual-integrations");
lf[292]=C_h_intern(&lf[292],17,"standard-bindings");
lf[293]=C_h_intern(&lf[293],34,"\010compilerdefault-standard-bindings");
lf[294]=C_h_intern(&lf[294],17,"extended-bindings");
lf[295]=C_h_intern(&lf[295],34,"\010compilerdefault-extended-bindings");
lf[296]=C_h_intern(&lf[296],1,"m");
lf[297]=C_h_intern(&lf[297],14,"set-gc-report!");
lf[298]=C_h_intern(&lf[298],8,"feature\077");
lf[299]=C_h_intern(&lf[299],18,"\000chicken-bootstrap");
lf[300]=C_h_intern(&lf[300],14,"compile-syntax");
lf[301]=C_h_intern(&lf[301],25,"\003sysenable-runtime-macros");
lf[302]=C_h_intern(&lf[302],22,"\004corerequire-extension");
lf[303]=C_h_intern(&lf[303],14,"string->symbol");
lf[304]=C_h_intern(&lf[304],17,"require-extension");
lf[305]=C_h_intern(&lf[305],28,"\010compilerpostponed-initforms");
lf[306]=C_h_intern(&lf[306],6,"delete");
lf[307]=C_h_intern(&lf[307],3,"eq\077");
lf[308]=C_h_intern(&lf[308],4,"load");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[310]=C_h_intern(&lf[310],6,"extend");
lf[311]=C_h_intern(&lf[311],12,"string-split");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[313]=C_h_intern(&lf[313],10,"append-map");
lf[314]=C_h_intern(&lf[314],10,"no-feature");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[316]=C_h_intern(&lf[316],7,"feature");
lf[317]=C_h_intern(&lf[317],12,"load-verbose");
lf[318]=C_h_intern(&lf[318],38,"no-procedure-checks-for-usual-bindings");
lf[319]=C_h_intern(&lf[319],8,"\003sysput!");
lf[320]=C_h_intern(&lf[320],21,"\010compileralways-bound");
lf[321]=C_h_intern(&lf[321],34,"\010compileralways-bound-to-procedure");
lf[322]=C_h_intern(&lf[322],41,"no-procedure-checks-for-toplevel-bindings");
lf[323]=C_h_intern(&lf[323],35,"\010compilerno-global-procedure-checks");
lf[324]=C_h_intern(&lf[324],19,"no-procedure-checks");
lf[325]=C_h_intern(&lf[325],28,"\010compilerno-procedure-checks");
lf[326]=C_h_intern(&lf[326],15,"no-bound-checks");
lf[327]=C_h_intern(&lf[327],24,"\010compilerno-bound-checks");
lf[328]=C_h_intern(&lf[328],14,"no-argc-checks");
lf[329]=C_h_intern(&lf[329],23,"\010compilerno-argc-checks");
lf[330]=C_h_intern(&lf[330],20,"keep-shadowed-macros");
lf[331]=C_h_intern(&lf[331],33,"\010compilerundefine-shadowed-macros");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[334]=C_h_intern(&lf[334],12,"include-path");
lf[335]=C_h_intern(&lf[335],11,"r5rs-syntax");
lf[336]=C_h_intern(&lf[336],13,"symbol-escape");
lf[337]=C_h_intern(&lf[337],20,"parentheses-synonyms");
lf[338]=C_h_intern(&lf[338],5,"\000none");
lf[339]=C_h_intern(&lf[339],14,"case-sensitive");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the CHICKEN extensions to R5RS syntax");
lf[341]=C_h_intern(&lf[341],16,"no-symbol-escape");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[343]=C_h_intern(&lf[343],23,"no-parenthesis-synonyms");
lf[344]=C_h_intern(&lf[344],20,"parenthesis-synonyms");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[347]=C_h_intern(&lf[347],7,"\000prefix");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[350]=C_h_intern(&lf[350],7,"\000suffix");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[352]=C_h_intern(&lf[352],16,"case-insensitive");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[354]=C_h_intern(&lf[354],24,"\010compilerinline-max-size");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[356]=C_h_intern(&lf[356],26,"\010compilerlocal-definitions");
lf[357]=C_h_intern(&lf[357],6,"inline");
lf[358]=C_h_intern(&lf[358],30,"emit-external-prototypes-first");
lf[359]=C_h_intern(&lf[359],30,"\010compilerexternal-protos-first");
lf[360]=C_h_intern(&lf[360],5,"block");
lf[361]=C_h_intern(&lf[361],26,"\010compilerblock-compilation");
lf[362]=C_h_intern(&lf[362],17,"fixnum-arithmetic");
lf[363]=C_h_intern(&lf[363],11,"number-type");
lf[364]=C_h_intern(&lf[364],6,"fixnum");
lf[365]=C_h_intern(&lf[365],18,"disable-interrupts");
lf[366]=C_h_intern(&lf[366],10,"setup-mode");
lf[367]=C_h_intern(&lf[367],14,"\003syssetup-mode");
lf[368]=C_h_intern(&lf[368],11,"no-warnings");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[370]=C_h_intern(&lf[370],12,"strict-types");
lf[371]=C_h_intern(&lf[371],30,"\010compilerstrict-variable-types");
lf[372]=C_h_intern(&lf[372],19,"\003sysnotices-enabled");
lf[373]=C_h_intern(&lf[373],13,"inline-global");
lf[374]=C_h_intern(&lf[374],5,"local");
lf[375]=C_h_intern(&lf[375],18,"no-compiler-syntax");
lf[376]=C_h_intern(&lf[376],32,"\010compilercompiler-syntax-enabled");
lf[377]=C_h_intern(&lf[377],14,"no-lambda-info");
lf[378]=C_h_intern(&lf[378],26,"\010compileremit-closure-info");
lf[379]=C_h_intern(&lf[379],3,"raw");
lf[380]=C_h_intern(&lf[380],8,"unboxing");
lf[381]=C_h_intern(&lf[381],7,"warning");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000#obsolete compiler option: -unboxing");
lf[383]=C_h_intern(&lf[383],11,"lambda-lift");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000&obsolete compiler option: -lambda-lift");
lf[385]=C_h_intern(&lf[385],12,"emit-exports");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\047obsolete compiler option: -emit-exports");
lf[387]=C_h_intern(&lf[387],1,"b");
lf[388]=C_h_intern(&lf[388],15,"\003sysstart-timer");
lf[389]=C_h_intern(&lf[389],25,"emit-all-import-libraries");
lf[390]=C_h_intern(&lf[390],29,"\010compilerall-import-libraries");
lf[391]=C_h_intern(&lf[391],17,"\003sysstring-append");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[393]=C_h_intern(&lf[393],19,"emit-import-library");
lf[394]=C_h_intern(&lf[394],28,"\010compilerprint-debug-options");
lf[395]=C_h_intern(&lf[395],16,"\003sysstring->list");
lf[396]=C_h_intern(&lf[396],5,"debug");
lf[397]=C_h_intern(&lf[397],18,"\003sysdload-disabled");
lf[398]=C_h_intern(&lf[398],15,"repository-path");
lf[399]=C_h_intern(&lf[399],30,"\010compilerstandalone-executable");
lf[400]=C_h_intern(&lf[400],29,"\010compilerstring->c-identifier");
lf[401]=C_h_intern(&lf[401],18,"\010compilerstringify");
lf[402]=C_h_intern(&lf[402],10,"stack-size");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[405]=C_h_intern(&lf[405],24,"get-environment-variable");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[407]=C_h_intern(&lf[407],9,"to-stdout");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[409]=C_h_intern(&lf[409],13,"pathname-file");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[411]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004uses\376\003\000\000\002\376\001\000\000\017debugger-client\376\377\016\376\377\016");
lf[412]=C_h_intern(&lf[412],29,"\010compilerdefault-declarations");
lf[413]=C_h_intern(&lf[413],30,"\010compilerunits-used-by-default");
lf[414]=C_h_intern(&lf[414],28,"\010compilerinitialize-compiler");
lf[415]=C_h_intern(&lf[415],14,"make-parameter");
C_register_lf2(lf,416,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* for-each-loop1054 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in ... */
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,4))){
C_save_and_reclaim_args((void *)trf_3165,3,t0,t1,t2);}
a=C_alloc(15);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3175,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3154,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t7;
t9=C_a_i_list(&a,1,t6);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5680,a[2]=t8,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t10;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[181];
av2[4]=t9;
C_apply(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4831 in k2190 in k2187 in k2184 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4833,2,av);}
/* batch-driver.scm:180: append-map */
t2=*((C_word*)lf[313]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3152 in for-each-loop1054 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_ccall f_3154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3154,2,av);}
/* batch-driver.scm:547: load-inline-file */
t2=*((C_word*)lf[180]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop800 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in ... */
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(18,0,2))){
C_save_and_reclaim_args((void *)trf_3713,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_u_i_car(t3);
t6=C_a_i_list(&a,2,lf[232],t5);
t7=C_a_i_list(&a,3,lf[237],t4,t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1992 in arg-val in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1994,2,av);}
a=C_alloc(8);
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
t3=C_a_i_times(&a,2,t2,C_fix(1048576));
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* batch-driver.scm:145: quit */
t4=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[45];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k2906 in k2887 in k2884 in k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in ... */
static void C_ccall f_2908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2908,2,av);}
/* batch-driver.scm:691: ##sys#display-times */
t2=*((C_word*)lf[116]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4845 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4847,2,av);}
t2=C_mutate2((C_word*)lf[205]+1 /* (set! ##compiler#unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_2186(t3,t2);}

/* k4849 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4851,2,av);}
/* batch-driver.scm:172: string->c-identifier */
t2=*((C_word*)lf[400]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4853 in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4855(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4855,2,av);}
/* batch-driver.scm:172: stringify */
t2=*((C_word*)lf[401]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f5816 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2248 in k2245 in k2242 in k2235 in k2232 in k2226 in k2200 in k2197 in k2190 in k2187 in k2184 in ... */
static void C_ccall f5816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5816,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f5810 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in ... */
static void C_ccall f5810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5810,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2950 in k2947 in k2944 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f_2952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2952,2,av);}
/* batch-driver.scm:658: end-time */
t2=((C_word*)((C_word*)t0)[2])[1];
f_2080(t2,((C_word*)t0)[3],lf[138]);}

/* f5804 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in k2293 in k2290 in k2287 in k2284 in k2281 in k2278 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 in ... */
static void C_ccall f5804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5804,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2944 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in ... */
static void C_ccall f_2946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2946,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:656: debugging */
t3=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[36];
av2[3]=lf[140];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2947 in k2944 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in ... */
static void C_ccall f_2949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2949,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:657: perform-secondary-flow-analysis */
t3=*((C_word*)lf[139]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2938 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f_2940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2940,2,av);}
/* batch-driver.scm:665: emit-global-inline-file */
t2=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a4031 in k3987 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f_4032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4032,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[254]+1));
t3=C_mutate2((C_word*)lf[254]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4037 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in ... */
static void C_ccall f_4039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4039,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:409: collect-options */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2035(t6,t5,lf[259]);}

/* arg-val in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1945(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_1945,2,t1,t2);}
a=C_alloc(8);
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
if(C_truep(C_fixnum_lessp(t3,C_fix(2)))){
t5=C_a_i_string_to_number(&a,2,t2,C_fix(10));
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* batch-driver.scm:145: quit */
t6=*((C_word*)lf[6]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[45];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}
else{
t5=C_i_string_ref(t2,t4);
t6=C_eqp(t5,C_make_character(109));
t7=(C_truep(t6)?t6:C_eqp(t5,C_make_character(77)));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1994,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:142: substring */
t9=*((C_word*)lf[46]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
av2[3]=C_fix(0);
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t8=C_eqp(t5,C_make_character(107));
t9=(C_truep(t8)?t8:C_eqp(t5,C_make_character(75)));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:143: substring */
t11=*((C_word*)lf[46]+1);{
C_word av2[5];
av2[0]=t11;
av2[1]=t10;
av2[2]=t2;
av2[3]=C_fix(0);
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t10=C_a_i_string_to_number(&a,2,t2,C_fix(10));
if(C_truep(t10)){
t11=t1;{
C_word av2[2];
av2[0]=t11;
av2[1]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
/* batch-driver.scm:145: quit */
t11=*((C_word*)lf[6]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=t1;
av2[2]=lf[45];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}}}}}

/* k2932 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in ... */
static void C_ccall f_2934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2934,2,av);}
a=C_alloc(4);
t2=C_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_i_greaterp(t2,C_fix(60000)))){
/* batch-driver.scm:673: display */
t3=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[128];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2847(2,av2);}}}

/* k4045 in k4037 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in ... */
static void C_ccall f_4047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4047,2,av);}
/* batch-driver.scm:406: append */
t2=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1930 in for-each-loop164 in k1904 in print-expr in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1932,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1922(t3,((C_word*)t0)[4],t2);}

/* k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_fcall f_2665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,2))){
C_save_and_reclaim_args((void *)trf_2665,2,t0,t1);}
a=C_alloc(18);
t2=C_set_block_item(lf[87] /* ##sys#line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[94] /* ##compiler#constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[95] /* ##compiler#inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(*((C_word*)lf[159]+1))){
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_2671(2,av2);}}
else{
t6=C_slot(((C_word*)t0)[17],C_fix(3));
t7=C_i_car(t6);
/* batch-driver.scm:582: scan-toplevel-assignments */
t8=*((C_word*)lf[160]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t5;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}

/* k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in ... */
static void C_ccall f_2662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(34,c,2))){C_save_and_reclaim((void *)f_2662,2,av);}
a=C_alloc(34);
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=((C_word*)((C_word*)t0)[18])[1];
t4=(C_truep(t3)?t3:*((C_word*)lf[54]+1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[19],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[18],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[21],tmp=(C_word)a,a+=13,tmp);
t6=((C_word*)t0)[22];
if(C_truep(C_u_i_memq(lf[176],t6))){
t7=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_3019(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:553: load-type-database */
t8=*((C_word*)lf[170]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[178];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}
else{
t5=t2;
f_2665(t5,C_SCHEME_UNDEFINED);}}

/* for-each-loop164 in k1904 in print-expr in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_1922,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1932,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:132: pretty-print */
t7=*((C_word*)lf[39]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in ... */
static void C_ccall f_2659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,3))){C_save_and_reclaim((void *)f_2659,2,av);}
a=C_alloc(28);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_i_nullp(t1))){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2662(2,av2);}}
else{
t3=C_set_block_item(lf[179] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t4=C_i_check_list_2(t1,lf[43]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3165,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3165(t8,t2,t1);}}

/* k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in ... */
static void C_ccall f_2656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_2656,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:541: collect-options */
t3=((C_word*)((C_word*)t0)[21])[1];
f_2035(t3,t2,lf[182]);}

/* k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in ... */
static void C_ccall f_2650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_2650,2,av);}
a=C_alloc(27);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=t2,a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3243,a[2]=t3,a[3]=((C_word*)t0)[22],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:529: debugging */
t5=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[189];
av2[3]=lf[190];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in ... */
static void C_ccall f_2653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,3))){C_save_and_reclaim((void *)f_2653,2,av);}
a=C_alloc(28);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(*((C_word*)lf[183]+1))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3219,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3219(t6,t2,((C_word*)t0)[20]);}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2656(2,av2);}}}

/* compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,3))){
C_save_and_reclaim((void*)f_1715,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1718,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1749,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:53: initialize-compiler */
t6=*((C_word*)lf[414]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,3))){C_save_and_reclaim((void *)f_1713,2,av);}
a=C_alloc(2);
t2=C_mutate2((C_word*)lf[4]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate2((C_word*)lf[5]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1715,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* option-arg in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1718(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_1718,2,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_car(t4);
/* batch-driver.scm:48: quit */
t6=*((C_word*)lf[6]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[7];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t4=C_i_cadr(t2);
if(C_truep(C_i_symbolp(t4))){
/* batch-driver.scm:51: quit */
t5=*((C_word*)lf[6]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[8];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}

/* for-each-loop1098 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in ... */
static void C_fcall f_3090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_3090,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3100,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3048,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:562: symbol->string */
t8=*((C_word*)lf[173]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in ... */
static void C_ccall f_2647(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(38,c,3))){C_save_and_reclaim((void *)f_2647,2,av);}
a=C_alloc(38);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=t2,tmp=(C_word)a,a+=23,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3255,a[2]=t6,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3255(t12,t8,t2);}

/* k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in ... */
static void C_ccall f_2641(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,2))){C_save_and_reclaim((void *)f_2641,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:524: initialize-analysis-database */
t3=*((C_word*)lf[194]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in ... */
static void C_ccall f_2644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,2))){C_save_and_reclaim((void *)f_2644,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:527: vector->list */
t4=*((C_word*)lf[192]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[193]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3599 in k3570 in k3566 in k3551 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in ... */
static void C_ccall f_3601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,8))){C_save_and_reclaim((void *)f_3601,2,av);}
t2=*((C_word*)lf[205]+1);
if(C_truep(*((C_word*)lf[205]+1))){
/* batch-driver.scm:455: append */
t3=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=t1;
av2[6]=((C_word*)t0)[6];
av2[7]=C_SCHEME_END_OF_LIST;
av2[8]=lf[231];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}
else{
if(C_truep(((C_word*)t0)[7])){
/* batch-driver.scm:455: append */
t3=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=t1;
av2[6]=((C_word*)t0)[6];
av2[7]=C_SCHEME_END_OF_LIST;
av2[8]=lf[231];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}
else{
t3=((C_word*)((C_word*)t0)[8])[1];
/* batch-driver.scm:455: append */
t4=*((C_word*)lf[230]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=t1;
av2[6]=((C_word*)t0)[6];
av2[7]=t3;
av2[8]=lf[231];
((C_proc)(void*)(*((C_word*)t4+1)))(9,av2);}}}}

/* k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in ... */
static void C_ccall f_2630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_2630,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3303,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:521: canonicalize-begin-body */
t4=*((C_word*)lf[198]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[20])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4935 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4937,2,av);}
/* batch-driver.scm:73: make-pathname */
t2=*((C_word*)lf[171]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=t1;
av2[4]=lf[408];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4270 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in ... */
static void C_ccall f_4271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4271,3,av);}
t3=*((C_word*)lf[311]+1);
/* batch-driver.scm:312: g534 */
t4=*((C_word*)lf[311]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[315];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4277 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in ... */
static void C_ccall f_4279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4279,2,av);}
/* batch-driver.scm:312: append-map */
t2=*((C_word*)lf[313]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4911 in g72 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4913,2,av);}
if(C_truep(C_i_symbolp(t1))){
/* batch-driver.scm:70: symbol->string */
t2=*((C_word*)lf[173]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1705,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:39: make-parameter */
t4=*((C_word*)lf[415]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1701,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:38: make-parameter */
t4=*((C_word*)lf[415]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1709(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1709,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:40: make-parameter */
t4=*((C_word*)lf[415]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in ... */
static void C_ccall f_2695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,2))){C_save_and_reclaim((void *)f_2695,2,av);}
a=C_alloc(28);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(*((C_word*)lf[96]+1))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[22],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(lf[152],*((C_word*)lf[30]+1)))){
/* batch-driver.scm:601: dump-undefined-globals */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_2964(2,av2);}}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2698(2,av2);}}}

/* k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_4948,2,av);}
a=C_alloc(19);
t2=C_a_i_cons(&a,2,lf[13],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_memq(lf[14],t6);
t8=((C_word*)t0)[2];
t9=C_u_i_memq(lf[15],t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t9)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:66: g72 */
t12=t11;
f_4909(t12,t10,t9);}
else{
t11=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[407],t11))){
t12=t10;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
f_1765(2,av2);}}
else{
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[5])){
/* batch-driver.scm:73: pathname-file */
t13=*((C_word*)lf[409]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}
else{
/* batch-driver.scm:73: make-pathname */
t13=*((C_word*)lf[171]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t13;
av2[1]=t10;
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[410];
av2[4]=lf[408];
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}}}}

/* k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in ... */
static void C_ccall f_2692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,4))){C_save_and_reclaim((void *)f_2692,2,av);}
a=C_alloc(29);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:598: analyze */
t3=((C_word*)((C_word*)t0)[11])[1];
f_2120(t3,t2,lf[154],((C_word*)((C_word*)t0)[4])[1],C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]));}

/* k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in ... */
static void C_ccall f_2698(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_2698,2,av);}
a=C_alloc(23);
t2=C_set_block_item(lf[96] /* ##compiler#first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:611: end-time */
t4=((C_word*)((C_word*)t0)[10])[1];
f_2080(t4,t3,lf[145]);}

/* k4244 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in ... */
static void C_ccall f_4246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4246,2,av);}
/* batch-driver.scm:315: append-map */
t2=*((C_word*)lf[313]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop518 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in ... */
static void C_fcall f_4248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4248,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4258,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:310: g519 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3050 in for-each-loop1098 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in ... */
static void C_ccall f_3052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3052,2,av);}
/* batch-driver.scm:562: make-pathname */
t2=*((C_word*)lf[171]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=t1;
av2[4]=lf[172];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in ... */
static void C_ccall f_3058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_3058,2,av);}
a=C_alloc(10);
t2=C_set_block_item(lf[96] /* ##compiler#first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:566: analyze */
t4=((C_word*)((C_word*)t0)[10])[1];
f_2120(t4,t3,lf[169],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* map-loop867 in k3570 in k3566 in k3551 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in ... */
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(27,0,2))){
C_save_and_reclaim_args((void *)trf_3616,3,t0,t1,t2);}
a=C_alloc(27);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_list(&a,2,lf[232],t4);
t6=C_u_i_cdr(t3);
t7=C_a_i_list(&a,2,lf[232],t6);
t8=C_a_i_list(&a,4,lf[233],*((C_word*)lf[234]+1),t5,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t14=t1;
t15=t12;
t1=t14;
t2=t15;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in ... */
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(25,0,2))){
C_save_and_reclaim_args((void *)trf_2688,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(25);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2692,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=t1,a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],a[21]=((C_word*)t0)[15],a[22]=((C_word*)t0)[16],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:596: begin-time */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2070(t9,t8);}

/* k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in ... */
static void C_ccall f_3055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_3055,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:564: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2070(t3,t2);}

/* k4404 in for-each-loop419 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in k2341 in k2335 in k2332 in k2329 in k2326 in k2323 in k2320 in k2315 in k2310 in k2305 in k2302 in k2299 in k2296 in ... */
static void C_ccall f_4406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4406,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4396(t3,((C_word*)t0)[4],t2);}

/* k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in ... */
static void C_ccall f_2680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,4))){C_save_and_reclaim((void *)f_2680,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:588: print-node */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1850(t3,t2,lf[155],lf[156],((C_word*)t0)[17]);}

/* k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in ... */
static void C_ccall f_2683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,7))){C_save_and_reclaim((void *)f_2683,2,av);}
a=C_alloc(19);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2688,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp));
t5=((C_word*)t3)[1];
f_2688(t5,((C_word*)t0)[16],C_fix(1),((C_word*)t0)[17],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k3079 in k3076 in k3073 in k3070 in k3067 in k3064 in k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in ... */
static void C_ccall f_3081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_3081,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[54]+1))){
/* batch-driver.scm:574: print-node */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1850(t3,t2,lf[161],lf[162],((C_word*)t0)[4]);}
else{
t3=C_set_block_item(lf[96] /* ##compiler#first-analysis */,0,C_SCHEME_TRUE);
t4=((C_word*)t0)[2];
f_2665(t4,t3);}}

/* k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in ... */
static void C_ccall f_2677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_2677,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:587: end-time */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2080(t4,t3,lf[157]);}

/* k3082 in k3079 in k3076 in k3073 in k3070 in k3067 in k3064 in k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in ... */
static void C_ccall f_3084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3084,2,av);}
t2=C_set_block_item(lf[96] /* ##compiler#first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2665(t3,t2);}

/* k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in ... */
static void C_ccall f_2671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_2671,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:584: begin-time */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2070(t3,t2);}

/* k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in ... */
static void C_ccall f_2674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_2674,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:586: perform-cps-conversion */
t3=*((C_word*)lf[158]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[17];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* f5247 in k2887 in k2884 in k2881 in k2878 in k2875 in k2872 in k2869 in a2866 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2832 in k2829 in k2826 in k2823 in k2706 in k2703 in ... */
static void C_ccall f5247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f5247,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5650,a[2]=t2,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t3;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[113];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}

/* k1877 in print-db in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1879,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=*((C_word*)lf[31]+1);
t3=*((C_word*)lf[31]+1);
t4=C_i_check_port_2(*((C_word*)lf[31]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:125: ##sys#print */
t6=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[42];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[31]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* print-db in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_1872,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(5);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1879,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:124: print-header */
f_1823(t6,t2,t3);}

/* k3070 in k3067 in k3064 in k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in ... */
static void C_ccall f_3072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_3072,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:570: debugging */
t3=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[36];
av2[3]=lf[165];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3073 in k3070 in k3067 in k3064 in k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in ... */
static void C_ccall f_3075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_3075,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:571: scrutinize */
t3=*((C_word*)lf[164]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)((C_word*)t0)[6])[1];
av2[4]=((C_word*)((C_word*)t0)[7])[1];
av2[5]=*((C_word*)lf[54]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3076 in k3073 in k3070 in k3067 in k3064 in k3061 in k3056 in k3053 in k3037 in k3031 in k3017 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in ... */
static void C_ccall f_3078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3078,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:572: end-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2080(t3,t2,lf[163]);}

/* k4903 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_4905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4905,2,av);}
if(C_truep(t1)){
t2=t1;
/* batch-driver.scm:75: string-split */
t3=*((C_word*)lf[311]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=lf[403];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* batch-driver.scm:75: string-split */
t2=*((C_word*)lf[311]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[404];
av2[3]=lf[403];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* g72 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_4909(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4909,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4913,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:68: option-arg */
f_1718(t3,t2);}

/* print-expr in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_1899,5,t0,t1,t2,t3,t4);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1906,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:129: print-header */
f_1823(t5,t2,t3);}

/* k1892 in k1889 in k1886 in k1883 in k1877 in print-db in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 in ... */
static void C_ccall f_1894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1894,2,av);}
/* batch-driver.scm:126: display-analysis-database */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1889 in k1886 in k1883 in k1877 in print-db in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1891,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:125: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4145 in map-loop588 in k4148 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in k2366 in k2363 in k2360 in k2357 in k2354 in k2351 in k2348 in k2344 in ... */
static void C_ccall f_4147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_4147,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[302],t2,C_SCHEME_TRUE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1886 in k1883 in k1877 in print-db in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1888,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:125: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(41);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1883 in k1877 in print-db in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1885,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:125: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3140 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k3297 in k2628 in k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in ... */
static void C_ccall f_3142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3142,2,av);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_3019(2,av2);}}
else{
/* batch-driver.scm:554: quit */
t2=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[177];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* f5726 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in ... */
static void C_ccall f5726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5726,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f5720 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in ... */
static void C_ccall f5720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5720,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1837 in k1825 in print-header in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1839,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:114: ##sys#print */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* print-node in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_1850,5,t0,t1,t2,t3,t4);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:118: print-header */
f_1823(t5,t2,t3);}

/* k2625 in k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in ... */
static void C_ccall f_2627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(31,c,4))){C_save_and_reclaim((void *)f_2627,2,av);}
a=C_alloc(31);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3306,a[2]=t2,a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5700,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[112]+1);
av2[3]=lf[200];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2630(2,av2);}}}

/* k2622 in k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in ... */
static void C_ccall f_2624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,2))){C_save_and_reclaim((void *)f_2624,2,av);}
a=C_alloc(21);
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm:510: user-pass */
t3=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2619 in k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in ... */
static void C_ccall f_2621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,2))){C_save_and_reclaim((void *)f_2621,2,av);}
a=C_alloc(21);
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=((C_word*)t0)[19];
if(C_truep(C_u_i_memq(lf[201],t3))){
/* batch-driver.scm:507: exit */
t4=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2624(2,av2);}}}

/* k3889 in doloop655 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in k2521 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in ... */
static void C_ccall f_3891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3891,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* print-header in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_fcall f_1823(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_1823,3,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1827,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:111: debugging */
t5=*((C_word*)lf[35]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[36];
av2[3]=lf[37];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k1825 in print-header in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1827,2,av);}
a=C_alloc(5);
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[30]+1)))){
t2=*((C_word*)lf[31]+1);
t3=*((C_word*)lf[31]+1);
t4=C_i_check_port_2(*((C_word*)lf[31]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:114: ##sys#write-char-0 */
t6=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[31]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k2616 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in ... */
static void C_ccall f_2618(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,4))){C_save_and_reclaim((void *)f_2618,2,av);}
a=C_alloc(21);
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm:505: print-expr */
t3=((C_word*)((C_word*)t0)[21])[1];
f_1899(t3,t2,lf[202],lf[203],((C_word*)((C_word*)t0)[20])[1]);}

/* k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in ... */
static void C_ccall f_2613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,2))){C_save_and_reclaim((void *)f_2613,2,av);}
a=C_alloc(22);
t2=C_mutate2((C_word*)lf[87]+1 /* (set! ##sys#line-number-database ...) */,*((C_word*)lf[90]+1));
t3=C_set_block_item(lf[90] /* ##compiler#line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:504: end-time */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2080(t5,t4,lf[204]);}

/* f5746 in k4069 in k4063 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in k2369 in ... */
static void C_ccall f5746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5746,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2608 in k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in ... */
static void C_ccall f_2610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,2))){C_save_and_reclaim((void *)f_2610,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(C_truep(*((C_word*)lf[205]+1))?((C_word*)t0)[9]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3371,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:499: open-output-string */
t5=*((C_word*)lf[210]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2613(2,av2);}}}

/* f5740 in k2482 in k2463 in k2460 in k2457 in k2454 in k2451 in k2448 in k2437 in k2433 in k2429 in k2426 in k2422 in k2418 in k2410 in k2406 in k2391 in k2388 in k2381 in k2378 in k2375 in k2372 in ... */
static void C_ccall f5740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f5740,2,av);}
/* batch-driver.scm:108: debugging */
t2=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1855 in print-node in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1857,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* batch-driver.scm:120: dump-nodes */
t2=*((C_word*)lf[38]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:121: build-expression-tree */
t3=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1868 in k1855 in print-node in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1870,2,av);}
/* batch-driver.scm:121: pretty-print */
t2=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_ccall f_2601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_2601,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[217]+1)))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3406,tmp=(C_word)a,a+=2,tmp);
/* batch-driver.scm:485: with-debugging-output */
t4=*((C_word*)lf[222]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[223];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_2604(2,av2);}}}

/* k2758 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in ... */
static void C_ccall f_2760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,6))){C_save_and_reclaim((void *)f_2760,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* batch-driver.scm:631: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2688(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in k2528 in ... */
static void C_ccall f_2604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_2604,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3395,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:492: debugging */
t4=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[215];
av2[3]=lf[216];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2605 in k2602 in k2599 in k2596 in k2590 in k2587 in k2581 in k2578 in k2572 in k2569 in k2566 in k2563 in k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in k2542 in k2538 in k2534 in k2531 in ... */
static void C_ccall f_2607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_2607,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3389,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:494: debugging */
t4=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[212];
av2[3]=lf[213];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1843 in k1840 in k1837 in k1825 in print-header in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_1845,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:114: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1840 in k1837 in k1825 in print-header in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 */
static void C_ccall f_1842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1842,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:114: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(93);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1846 in k1843 in k1840 in k1837 in k1825 in print-header in k1803 in k1777 in k1772 in k1769 in k1763 in k4946 in k1747 in compile-source-file in k1711 in k1707 in k1703 in k1699 in k1695 in k1691 in k1688 in k1685 in ... */
static void C_ccall f_1848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1848,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2797 in k2794 in k2791 in k2788 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in ... */
static void C_ccall f_2799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2799,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:642: transform-direct-lambdas! */
t3=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2794 in k2791 in k2788 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in ... */
static void C_ccall f_2796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2796,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:640: begin-time */
t3=((C_word*)((C_word*)t0)[9])[1];
f_2070(t3,t2);}

/* k2791 in k2788 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in ... */
static void C_ccall f_2793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2793,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:639: end-time */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2080(t4,t3,lf[104]);}

/* k2788 in k2739 in k2736 in a2733 in k2715 in k2712 in k2706 in k2703 in k2700 in k2696 in k2693 in k2690 in loop in k2681 in k2678 in k2675 in k2672 in k2669 in k2663 in k2660 in k2657 in k2654 in ... */
static void C_ccall f_2790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_2790,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:638: analyze */
t3=((C_word*)((C_word*)t0)[9])[1];
f_2120(t3,t2,lf[105],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[424] = {
{"f5700:batch_2ddriver_2escm",(void*)f5700},
{"f_3880:batch_2ddriver_2escm",(void*)f_3880},
{"f_3229:batch_2ddriver_2escm",(void*)f_3229},
{"f_4373:batch_2ddriver_2escm",(void*)f_4373},
{"f5774:batch_2ddriver_2escm",(void*)f5774},
{"f_4507:batch_2ddriver_2escm",(void*)f_4507},
{"f_4509:batch_2ddriver_2escm",(void*)f_4509},
{"f_3210:batch_2ddriver_2escm",(void*)f_3210},
{"f_3875:batch_2ddriver_2escm",(void*)f_3875},
{"f_3214:batch_2ddriver_2escm",(void*)f_3214},
{"f_3871:batch_2ddriver_2escm",(void*)f_3871},
{"f_3219:batch_2ddriver_2escm",(void*)f_3219},
{"f_2495:batch_2ddriver_2escm",(void*)f_2495},
{"f_4383:batch_2ddriver_2escm",(void*)f_4383},
{"f5792:batch_2ddriver_2escm",(void*)f5792},
{"f5798:batch_2ddriver_2escm",(void*)f5798},
{"f_2738:batch_2ddriver_2escm",(void*)f_2738},
{"f_2734:batch_2ddriver_2escm",(void*)f_2734},
{"f_3836:batch_2ddriver_2escm",(void*)f_3836},
{"f_3834:batch_2ddriver_2escm",(void*)f_3834},
{"f5644:batch_2ddriver_2escm",(void*)f5644},
{"f5764:batch_2ddriver_2escm",(void*)f5764},
{"f_3861:batch_2ddriver_2escm",(void*)f_3861},
{"f5752:batch_2ddriver_2escm",(void*)f5752},
{"f_2741:batch_2ddriver_2escm",(void*)f_2741},
{"f5758:batch_2ddriver_2escm",(void*)f5758},
{"f_4238:batch_2ddriver_2escm",(void*)f_4238},
{"f_3809:batch_2ddriver_2escm",(void*)f_3809},
{"f_2776:batch_2ddriver_2escm",(void*)f_2776},
{"f_2428:batch_2ddriver_2escm",(void*)f_2428},
{"f_2424:batch_2ddriver_2escm",(void*)f_2424},
{"f_2420:batch_2ddriver_2escm",(void*)f_2420},
{"f_2722:batch_2ddriver_2escm",(void*)f_2722},
{"f_4258:batch_2ddriver_2escm",(void*)f_4258},
{"f_2412:batch_2ddriver_2escm",(void*)f_2412},
{"f_3048:batch_2ddriver_2escm",(void*)f_3048},
{"f_3824:batch_2ddriver_2escm",(void*)f_3824},
{"f_3039:batch_2ddriver_2escm",(void*)f_3039},
{"f_2484:batch_2ddriver_2escm",(void*)f_2484},
{"f_3033:batch_2ddriver_2escm",(void*)f_3033},
{"f_3069:batch_2ddriver_2escm",(void*)f_3069},
{"f_2473:batch_2ddriver_2escm",(void*)f_2473},
{"f_3063:batch_2ddriver_2escm",(void*)f_3063},
{"f_3066:batch_2ddriver_2escm",(void*)f_3066},
{"f_2462:batch_2ddriver_2escm",(void*)f_2462},
{"f_2465:batch_2ddriver_2escm",(void*)f_2465},
{"f_4348:batch_2ddriver_2escm",(void*)f_4348},
{"f_2456:batch_2ddriver_2escm",(void*)f_2456},
{"f_2459:batch_2ddriver_2escm",(void*)f_2459},
{"f_2450:batch_2ddriver_2escm",(void*)f_2450},
{"f_2453:batch_2ddriver_2escm",(void*)f_2453},
{"f_4329:batch_2ddriver_2escm",(void*)f_4329},
{"f_1911:batch_2ddriver_2escm",(void*)f_1911},
{"f_4396:batch_2ddriver_2escm",(void*)f_4396},
{"f5662:batch_2ddriver_2escm",(void*)f5662},
{"f5668:batch_2ddriver_2escm",(void*)f5668},
{"f_4613:batch_2ddriver_2escm",(void*)f_4613},
{"f_4610:batch_2ddriver_2escm",(void*)f_4610},
{"f5656:batch_2ddriver_2escm",(void*)f5656},
{"f5650:batch_2ddriver_2escm",(void*)f5650},
{"f_3410:batch_2ddriver_2escm",(void*)f_3410},
{"f_3418:batch_2ddriver_2escm",(void*)f_3418},
{"f5680:batch_2ddriver_2escm",(void*)f5680},
{"f5688:batch_2ddriver_2escm",(void*)f5688},
{"f_3406:batch_2ddriver_2escm",(void*)f_3406},
{"f_3772:batch_2ddriver_2escm",(void*)f_3772},
{"f_2402:batch_2ddriver_2escm",(void*)f_2402},
{"f_2408:batch_2ddriver_2escm",(void*)f_2408},
{"f_3747:batch_2ddriver_2escm",(void*)f_3747},
{"f_2802:batch_2ddriver_2escm",(void*)f_2802},
{"f_2805:batch_2ddriver_2escm",(void*)f_2805},
{"f_3200:batch_2ddriver_2escm",(void*)f_3200},
{"f_3203:batch_2ddriver_2escm",(void*)f_3203},
{"f_2559:batch_2ddriver_2escm",(void*)f_2559},
{"f_2556:batch_2ddriver_2escm",(void*)f_2556},
{"f_2550:batch_2ddriver_2escm",(void*)f_2550},
{"f_2553:batch_2ddriver_2escm",(void*)f_2553},
{"f_2150:batch_2ddriver_2escm",(void*)f_2150},
{"f_2547:batch_2ddriver_2escm",(void*)f_2547},
{"f_2544:batch_2ddriver_2escm",(void*)f_2544},
{"f_2540:batch_2ddriver_2escm",(void*)f_2540},
{"f_2439:batch_2ddriver_2escm",(void*)f_2439},
{"f_2435:batch_2ddriver_2escm",(void*)f_2435},
{"f_2431:batch_2ddriver_2escm",(void*)f_2431},
{"f_2134:batch_2ddriver_2escm",(void*)f_2134},
{"f_2536:batch_2ddriver_2escm",(void*)f_2536},
{"f_2140:batch_2ddriver_2escm",(void*)f_2140},
{"f_1805:batch_2ddriver_2escm",(void*)f_1805},
{"f_2145:batch_2ddriver_2escm",(void*)f_2145},
{"f_2533:batch_2ddriver_2escm",(void*)f_2533},
{"f_2530:batch_2ddriver_2escm",(void*)f_2530},
{"f_2126:batch_2ddriver_2escm",(void*)f_2126},
{"f_2122:batch_2ddriver_2escm",(void*)f_2122},
{"f_2120:batch_2ddriver_2escm",(void*)f_2120},
{"f_3306:batch_2ddriver_2escm",(void*)f_3306},
{"f_3309:batch_2ddriver_2escm",(void*)f_3309},
{"f_3255:batch_2ddriver_2escm",(void*)f_3255},
{"f_3253:batch_2ddriver_2escm",(void*)f_3253},
{"f_2527:batch_2ddriver_2escm",(void*)f_2527},
{"f_2523:batch_2ddriver_2escm",(void*)f_2523},
{"f_2129:batch_2ddriver_2escm",(void*)f_2129},
{"f_3303:batch_2ddriver_2escm",(void*)f_3303},
{"f_2118:batch_2ddriver_2escm",(void*)f_2118},
{"f_2110:batch_2ddriver_2escm",(void*)f_2110},
{"f_2592:batch_2ddriver_2escm",(void*)f_2592},
{"f_3679:batch_2ddriver_2escm",(void*)f_3679},
{"f_2598:batch_2ddriver_2escm",(void*)f_2598},
{"f_2589:batch_2ddriver_2escm",(void*)f_2589},
{"f_2192:batch_2ddriver_2escm",(void*)f_2192},
{"f_2580:batch_2ddriver_2escm",(void*)f_2580},
{"f_2583:batch_2ddriver_2escm",(void*)f_2583},
{"f_2199:batch_2ddriver_2escm",(void*)f_2199},
{"f_4471:batch_2ddriver_2escm",(void*)f_4471},
{"f_3319:batch_2ddriver_2escm",(void*)f_3319},
{"f_2186:batch_2ddriver_2escm",(void*)f_2186},
{"f_2571:batch_2ddriver_2escm",(void*)f_2571},
{"f_2574:batch_2ddriver_2escm",(void*)f_2574},
{"f_2189:batch_2ddriver_2escm",(void*)f_2189},
{"f_4482:batch_2ddriver_2escm",(void*)f_4482},
{"f_3291:batch_2ddriver_2escm",(void*)f_3291},
{"f_3299:batch_2ddriver_2escm",(void*)f_3299},
{"f_2568:batch_2ddriver_2escm",(void*)f_2568},
{"f_2565:batch_2ddriver_2escm",(void*)f_2565},
{"f_2562:batch_2ddriver_2escm",(void*)f_2562},
{"f_3243:batch_2ddriver_2escm",(void*)f_3243},
{"f_3992:batch_2ddriver_2escm",(void*)f_3992},
{"f_3999:batch_2ddriver_2escm",(void*)f_3999},
{"f_3324:batch_2ddriver_2escm",(void*)f_3324},
{"f_4434:batch_2ddriver_2escm",(void*)f_4434},
{"f_4306:batch_2ddriver_2escm",(void*)f_4306},
{"f_3989:batch_2ddriver_2escm",(void*)f_3989},
{"f_4441:batch_2ddriver_2escm",(void*)f_4441},
{"f_4446:batch_2ddriver_2escm",(void*)f_4446},
{"f_3976:batch_2ddriver_2escm",(void*)f_3976},
{"f_2517:batch_2ddriver_2escm",(void*)f_2517},
{"f_2514:batch_2ddriver_2escm",(void*)f_2514},
{"f_2511:batch_2ddriver_2escm",(void*)f_2511},
{"f_2061:batch_2ddriver_2escm",(void*)f_2061},
{"f_2502:batch_2ddriver_2escm",(void*)f_2502},
{"f_2057:batch_2ddriver_2escm",(void*)f_2057},
{"f_3951:batch_2ddriver_2escm",(void*)f_3951},
{"f_2041:batch_2ddriver_2escm",(void*)f_2041},
{"f_3942:batch_2ddriver_2escm",(void*)f_3942},
{"f_2049:batch_2ddriver_2escm",(void*)f_2049},
{"f_2014:batch_2ddriver_2escm",(void*)f_2014},
{"f_4501:batch_2ddriver_2escm",(void*)f_4501},
{"f_2093:batch_2ddriver_2escm",(void*)f_2093},
{"f_3917:batch_2ddriver_2escm",(void*)f_3917},
{"f_2096:batch_2ddriver_2escm",(void*)f_2096},
{"f_3915:batch_2ddriver_2escm",(void*)f_3915},
{"f_2090:batch_2ddriver_2escm",(void*)f_2090},
{"f_2099:batch_2ddriver_2escm",(void*)f_2099},
{"f_2393:batch_2ddriver_2escm",(void*)f_2393},
{"f_2390:batch_2ddriver_2escm",(void*)f_2390},
{"f_3901:batch_2ddriver_2escm",(void*)f_3901},
{"f_3905:batch_2ddriver_2escm",(void*)f_3905},
{"f_2080:batch_2ddriver_2escm",(void*)f_2080},
{"f_4004:batch_2ddriver_2escm",(void*)f_4004},
{"f_2070:batch_2ddriver_2escm",(void*)f_2070},
{"f_4563:batch_2ddriver_2escm",(void*)f_4563},
{"f_2078:batch_2ddriver_2escm",(void*)f_2078},
{"f_4014:batch_2ddriver_2escm",(void*)f_4014},
{"f_4010:batch_2ddriver_2escm",(void*)f_4010},
{"f_4571:batch_2ddriver_2escm",(void*)f_4571},
{"f_4577:batch_2ddriver_2escm",(void*)f_4577},
{"f_3572:batch_2ddriver_2escm",(void*)f_3572},
{"f_2035:batch_2ddriver_2escm",(void*)f_2035},
{"f_4552:batch_2ddriver_2escm",(void*)f_4552},
{"f_4555:batch_2ddriver_2escm",(void*)f_4555},
{"f_4546:batch_2ddriver_2escm",(void*)f_4546},
{"f_4549:batch_2ddriver_2escm",(void*)f_4549},
{"f_3568:batch_2ddriver_2escm",(void*)f_3568},
{"f_4534:batch_2ddriver_2escm",(void*)f_4534},
{"f_2325:batch_2ddriver_2escm",(void*)f_2325},
{"f_2328:batch_2ddriver_2escm",(void*)f_2328},
{"f_2322:batch_2ddriver_2escm",(void*)f_2322},
{"f_2317:batch_2ddriver_2escm",(void*)f_2317},
{"f_2312:batch_2ddriver_2escm",(void*)f_2312},
{"f_4120:batch_2ddriver_2escm",(void*)f_4120},
{"f_3380:batch_2ddriver_2escm",(void*)f_3380},
{"f_3383:batch_2ddriver_2escm",(void*)f_3383},
{"f_3386:batch_2ddriver_2escm",(void*)f_3386},
{"f_3389:batch_2ddriver_2escm",(void*)f_3389},
{"f_2380:batch_2ddriver_2escm",(void*)f_2380},
{"f_2383:batch_2ddriver_2escm",(void*)f_2383},
{"f_3521:batch_2ddriver_2escm",(void*)f_3521},
{"f_3123:batch_2ddriver_2escm",(void*)f_3123},
{"f_2377:batch_2ddriver_2escm",(void*)f_2377},
{"f_2371:batch_2ddriver_2escm",(void*)f_2371},
{"f_2374:batch_2ddriver_2escm",(void*)f_2374},
{"f_4127:batch_2ddriver_2escm",(void*)f_4127},
{"f_3113:batch_2ddriver_2escm",(void*)f_3113},
{"f_2368:batch_2ddriver_2escm",(void*)f_2368},
{"f_2362:batch_2ddriver_2escm",(void*)f_2362},
{"f_2365:batch_2ddriver_2escm",(void*)f_2365},
{"f_3100:batch_2ddriver_2escm",(void*)f_3100},
{"f_2356:batch_2ddriver_2escm",(void*)f_2356},
{"f_3395:batch_2ddriver_2escm",(void*)f_3395},
{"f_2359:batch_2ddriver_2escm",(void*)f_2359},
{"f_2350:batch_2ddriver_2escm",(void*)f_2350},
{"f_2353:batch_2ddriver_2escm",(void*)f_2353},
{"f_1779:batch_2ddriver_2escm",(void*)f_1779},
{"f_1771:batch_2ddriver_2escm",(void*)f_1771},
{"f_1774:batch_2ddriver_2escm",(void*)f_1774},
{"f_3349:batch_2ddriver_2escm",(void*)f_3349},
{"f_4668:batch_2ddriver_2escm",(void*)f_4668},
{"f_1906:batch_2ddriver_2escm",(void*)f_1906},
{"f_3371:batch_2ddriver_2escm",(void*)f_3371},
{"f_3377:batch_2ddriver_2escm",(void*)f_3377},
{"f_3553:batch_2ddriver_2escm",(void*)f_3553},
{"f_3475:batch_2ddriver_2escm",(void*)f_3475},
{"f_4620:batch_2ddriver_2escm",(void*)f_4620},
{"f_2301:batch_2ddriver_2escm",(void*)f_2301},
{"f_2307:batch_2ddriver_2escm",(void*)f_2307},
{"f_2304:batch_2ddriver_2escm",(void*)f_2304},
{"f_4626:batch_2ddriver_2escm",(void*)f_4626},
{"f_3496:batch_2ddriver_2escm",(void*)f_3496},
{"f_3494:batch_2ddriver_2escm",(void*)f_3494},
{"f_2702:batch_2ddriver_2escm",(void*)f_2702},
{"f_2708:batch_2ddriver_2escm",(void*)f_2708},
{"f_2705:batch_2ddriver_2escm",(void*)f_2705},
{"f_4633:batch_2ddriver_2escm",(void*)f_4633},
{"f_4639:batch_2ddriver_2escm",(void*)f_4639},
{"f_2262:batch_2ddriver_2escm",(void*)f_2262},
{"f_2265:batch_2ddriver_2escm",(void*)f_2265},
{"f_2268:batch_2ddriver_2escm",(void*)f_2268},
{"f_3424:batch_2ddriver_2escm",(void*)f_3424},
{"f_2895:batch_2ddriver_2escm",(void*)f_2895},
{"f_2892:batch_2ddriver_2escm",(void*)f_2892},
{"f_3427:batch_2ddriver_2escm",(void*)f_3427},
{"f_3421:batch_2ddriver_2escm",(void*)f_3421},
{"f_2717:batch_2ddriver_2escm",(void*)f_2717},
{"f_2714:batch_2ddriver_2escm",(void*)f_2714},
{"f_2346:batch_2ddriver_2escm",(void*)f_2346},
{"f_2343:batch_2ddriver_2escm",(void*)f_2343},
{"f_2889:batch_2ddriver_2escm",(void*)f_2889},
{"f_3454:batch_2ddriver_2escm",(void*)f_3454},
{"f_2886:batch_2ddriver_2escm",(void*)f_2886},
{"f_2883:batch_2ddriver_2escm",(void*)f_2883},
{"f_2247:batch_2ddriver_2escm",(void*)f_2247},
{"f_2244:batch_2ddriver_2escm",(void*)f_2244},
{"f_2880:batch_2ddriver_2escm",(void*)f_2880},
{"f_1765:batch_2ddriver_2escm",(void*)f_1765},
{"f_4797:batch_2ddriver_2escm",(void*)f_4797},
{"f_2337:batch_2ddriver_2escm",(void*)f_2337},
{"f_2334:batch_2ddriver_2escm",(void*)f_2334},
{"f_2331:batch_2ddriver_2escm",(void*)f_2331},
{"f_2228:batch_2ddriver_2escm",(void*)f_2228},
{"f_2271:batch_2ddriver_2escm",(void*)f_2271},
{"f_3444:batch_2ddriver_2escm",(void*)f_3444},
{"f_2223:batch_2ddriver_2escm",(void*)f_2223},
{"f_2877:batch_2ddriver_2escm",(void*)f_2877},
{"f_2274:batch_2ddriver_2escm",(void*)f_2274},
{"f_2871:batch_2ddriver_2escm",(void*)f_2871},
{"f_2277:batch_2ddriver_2escm",(void*)f_2277},
{"f_2874:batch_2ddriver_2escm",(void*)f_2874},
{"f_4792:batch_2ddriver_2escm",(void*)f_4792},
{"f_4202:batch_2ddriver_2escm",(void*)f_4202},
{"f_3019:batch_2ddriver_2escm",(void*)f_3019},
{"f_4065:batch_2ddriver_2escm",(void*)f_4065},
{"f_1697:batch_2ddriver_2escm",(void*)f_1697},
{"f_1749:batch_2ddriver_2escm",(void*)f_1749},
{"f_1693:batch_2ddriver_2escm",(void*)f_1693},
{"f_4776:batch_2ddriver_2escm",(void*)f_4776},
{"f_1690:batch_2ddriver_2escm",(void*)f_1690},
{"f_4071:batch_2ddriver_2escm",(void*)f_4071},
{"f_2253:batch_2ddriver_2escm",(void*)f_2253},
{"f_2250:batch_2ddriver_2escm",(void*)f_2250},
{"f_2202:batch_2ddriver_2escm",(void*)f_2202},
{"f_2256:batch_2ddriver_2escm",(void*)f_2256},
{"f_4771:batch_2ddriver_2escm",(void*)f_4771},
{"f_2259:batch_2ddriver_2escm",(void*)f_2259},
{"f_1687:batch_2ddriver_2escm",(void*)f_1687},
{"f_4225:batch_2ddriver_2escm",(void*)f_4225},
{"f_2237:batch_2ddriver_2escm",(void*)f_2237},
{"f_2286:batch_2ddriver_2escm",(void*)f_2286},
{"f_2283:batch_2ddriver_2escm",(void*)f_2283},
{"f_2234:batch_2ddriver_2escm",(void*)f_2234},
{"f_2280:batch_2ddriver_2escm",(void*)f_2280},
{"f_2289:batch_2ddriver_2escm",(void*)f_2289},
{"f_2219:batch_2ddriver_2escm",(void*)f_2219},
{"f_2828:batch_2ddriver_2escm",(void*)f_2828},
{"f_2825:batch_2ddriver_2escm",(void*)f_2825},
{"f_4215:batch_2ddriver_2escm",(void*)f_4215},
{"f_2295:batch_2ddriver_2escm",(void*)f_2295},
{"f_2292:batch_2ddriver_2escm",(void*)f_2292},
{"f_2298:batch_2ddriver_2escm",(void*)f_2298},
{"f_3024:batch_2ddriver_2escm",(void*)f_3024},
{"f_2867:batch_2ddriver_2escm",(void*)f_2867},
{"f_2861:batch_2ddriver_2escm",(void*)f_2861},
{"f_4192:batch_2ddriver_2escm",(void*)f_4192},
{"f_2856:batch_2ddriver_2escm",(void*)f_2856},
{"f_2850:batch_2ddriver_2escm",(void*)f_2850},
{"f_2853:batch_2ddriver_2escm",(void*)f_2853},
{"f_2976:batch_2ddriver_2escm",(void*)f_2976},
{"f_2970:batch_2ddriver_2escm",(void*)f_2970},
{"f_2847:batch_2ddriver_2escm",(void*)f_2847},
{"f_2841:batch_2ddriver_2escm",(void*)f_2841},
{"f_2844:batch_2ddriver_2escm",(void*)f_2844},
{"f_4758:batch_2ddriver_2escm",(void*)f_4758},
{"f_4869:batch_2ddriver_2escm",(void*)f_4869},
{"f_2967:batch_2ddriver_2escm",(void*)f_2967},
{"f_2964:batch_2ddriver_2escm",(void*)f_2964},
{"f_2838:batch_2ddriver_2escm",(void*)f_2838},
{"f_2831:batch_2ddriver_2escm",(void*)f_2831},
{"f_2834:batch_2ddriver_2escm",(void*)f_2834},
{"f_4183:batch_2ddriver_2escm",(void*)f_4183},
{"f_3191:batch_2ddriver_2escm",(void*)f_3191},
{"f_4156:batch_2ddriver_2escm",(void*)f_4156},
{"f_4150:batch_2ddriver_2escm",(void*)f_4150},
{"f_4733:batch_2ddriver_2escm",(void*)f_4733},
{"f_4894:batch_2ddriver_2escm",(void*)f_4894},
{"f_4158:batch_2ddriver_2escm",(void*)f_4158},
{"f_3175:batch_2ddriver_2escm",(void*)f_3175},
{"f_4822:batch_2ddriver_2escm",(void*)f_4822},
{"toplevel:batch_2ddriver_2escm",(void*)C_driver_toplevel},
{"f_3165:batch_2ddriver_2escm",(void*)f_3165},
{"f_4833:batch_2ddriver_2escm",(void*)f_4833},
{"f_3154:batch_2ddriver_2escm",(void*)f_3154},
{"f_3713:batch_2ddriver_2escm",(void*)f_3713},
{"f_1994:batch_2ddriver_2escm",(void*)f_1994},
{"f_2908:batch_2ddriver_2escm",(void*)f_2908},
{"f_4847:batch_2ddriver_2escm",(void*)f_4847},
{"f_4851:batch_2ddriver_2escm",(void*)f_4851},
{"f_4855:batch_2ddriver_2escm",(void*)f_4855},
{"f5816:batch_2ddriver_2escm",(void*)f5816},
{"f5810:batch_2ddriver_2escm",(void*)f5810},
{"f_2952:batch_2ddriver_2escm",(void*)f_2952},
{"f5804:batch_2ddriver_2escm",(void*)f5804},
{"f_2946:batch_2ddriver_2escm",(void*)f_2946},
{"f_2949:batch_2ddriver_2escm",(void*)f_2949},
{"f_2940:batch_2ddriver_2escm",(void*)f_2940},
{"f_4032:batch_2ddriver_2escm",(void*)f_4032},
{"f_4039:batch_2ddriver_2escm",(void*)f_4039},
{"f_1945:batch_2ddriver_2escm",(void*)f_1945},
{"f_2934:batch_2ddriver_2escm",(void*)f_2934},
{"f_4047:batch_2ddriver_2escm",(void*)f_4047},
{"f_1932:batch_2ddriver_2escm",(void*)f_1932},
{"f_2665:batch_2ddriver_2escm",(void*)f_2665},
{"f_2662:batch_2ddriver_2escm",(void*)f_2662},
{"f_1922:batch_2ddriver_2escm",(void*)f_1922},
{"f_2659:batch_2ddriver_2escm",(void*)f_2659},
{"f_2656:batch_2ddriver_2escm",(void*)f_2656},
{"f_2650:batch_2ddriver_2escm",(void*)f_2650},
{"f_2653:batch_2ddriver_2escm",(void*)f_2653},
{"f_1715:batch_2ddriver_2escm",(void*)f_1715},
{"f_1713:batch_2ddriver_2escm",(void*)f_1713},
{"f_1718:batch_2ddriver_2escm",(void*)f_1718},
{"f_3090:batch_2ddriver_2escm",(void*)f_3090},
{"f_2647:batch_2ddriver_2escm",(void*)f_2647},
{"f_2641:batch_2ddriver_2escm",(void*)f_2641},
{"f_2644:batch_2ddriver_2escm",(void*)f_2644},
{"f_3601:batch_2ddriver_2escm",(void*)f_3601},
{"f_2630:batch_2ddriver_2escm",(void*)f_2630},
{"f_4937:batch_2ddriver_2escm",(void*)f_4937},
{"f_4271:batch_2ddriver_2escm",(void*)f_4271},
{"f_4279:batch_2ddriver_2escm",(void*)f_4279},
{"f_4913:batch_2ddriver_2escm",(void*)f_4913},
{"f_1705:batch_2ddriver_2escm",(void*)f_1705},
{"f_1701:batch_2ddriver_2escm",(void*)f_1701},
{"f_1709:batch_2ddriver_2escm",(void*)f_1709},
{"f_2695:batch_2ddriver_2escm",(void*)f_2695},
{"f_4948:batch_2ddriver_2escm",(void*)f_4948},
{"f_2692:batch_2ddriver_2escm",(void*)f_2692},
{"f_2698:batch_2ddriver_2escm",(void*)f_2698},
{"f_4246:batch_2ddriver_2escm",(void*)f_4246},
{"f_4248:batch_2ddriver_2escm",(void*)f_4248},
{"f_3052:batch_2ddriver_2escm",(void*)f_3052},
{"f_3058:batch_2ddriver_2escm",(void*)f_3058},
{"f_3616:batch_2ddriver_2escm",(void*)f_3616},
{"f_2688:batch_2ddriver_2escm",(void*)f_2688},
{"f_3055:batch_2ddriver_2escm",(void*)f_3055},
{"f_4406:batch_2ddriver_2escm",(void*)f_4406},
{"f_2680:batch_2ddriver_2escm",(void*)f_2680},
{"f_2683:batch_2ddriver_2escm",(void*)f_2683},
{"f_3081:batch_2ddriver_2escm",(void*)f_3081},
{"f_2677:batch_2ddriver_2escm",(void*)f_2677},
{"f_3084:batch_2ddriver_2escm",(void*)f_3084},
{"f_2671:batch_2ddriver_2escm",(void*)f_2671},
{"f_2674:batch_2ddriver_2escm",(void*)f_2674},
{"f5247:batch_2ddriver_2escm",(void*)f5247},
{"f_1879:batch_2ddriver_2escm",(void*)f_1879},
{"f_1872:batch_2ddriver_2escm",(void*)f_1872},
{"f_3072:batch_2ddriver_2escm",(void*)f_3072},
{"f_3075:batch_2ddriver_2escm",(void*)f_3075},
{"f_3078:batch_2ddriver_2escm",(void*)f_3078},
{"f_4905:batch_2ddriver_2escm",(void*)f_4905},
{"f_4909:batch_2ddriver_2escm",(void*)f_4909},
{"f_1899:batch_2ddriver_2escm",(void*)f_1899},
{"f_1894:batch_2ddriver_2escm",(void*)f_1894},
{"f_1891:batch_2ddriver_2escm",(void*)f_1891},
{"f_4147:batch_2ddriver_2escm",(void*)f_4147},
{"f_1888:batch_2ddriver_2escm",(void*)f_1888},
{"f_1885:batch_2ddriver_2escm",(void*)f_1885},
{"f_3142:batch_2ddriver_2escm",(void*)f_3142},
{"f5726:batch_2ddriver_2escm",(void*)f5726},
{"f5720:batch_2ddriver_2escm",(void*)f5720},
{"f_1839:batch_2ddriver_2escm",(void*)f_1839},
{"f_1850:batch_2ddriver_2escm",(void*)f_1850},
{"f_2627:batch_2ddriver_2escm",(void*)f_2627},
{"f_2624:batch_2ddriver_2escm",(void*)f_2624},
{"f_2621:batch_2ddriver_2escm",(void*)f_2621},
{"f_3891:batch_2ddriver_2escm",(void*)f_3891},
{"f_1823:batch_2ddriver_2escm",(void*)f_1823},
{"f_1827:batch_2ddriver_2escm",(void*)f_1827},
{"f_2618:batch_2ddriver_2escm",(void*)f_2618},
{"f_2613:batch_2ddriver_2escm",(void*)f_2613},
{"f5746:batch_2ddriver_2escm",(void*)f5746},
{"f_2610:batch_2ddriver_2escm",(void*)f_2610},
{"f5740:batch_2ddriver_2escm",(void*)f5740},
{"f_1857:batch_2ddriver_2escm",(void*)f_1857},
{"f_1870:batch_2ddriver_2escm",(void*)f_1870},
{"f_2601:batch_2ddriver_2escm",(void*)f_2601},
{"f_2760:batch_2ddriver_2escm",(void*)f_2760},
{"f_2604:batch_2ddriver_2escm",(void*)f_2604},
{"f_2607:batch_2ddriver_2escm",(void*)f_2607},
{"f_1845:batch_2ddriver_2escm",(void*)f_1845},
{"f_1842:batch_2ddriver_2escm",(void*)f_1842},
{"f_1848:batch_2ddriver_2escm",(void*)f_1848},
{"f_2799:batch_2ddriver_2escm",(void*)f_2799},
{"f_2796:batch_2ddriver_2escm",(void*)f_2796},
{"f_2793:batch_2ddriver_2escm",(void*)f_2793},
{"f_2790:batch_2ddriver_2escm",(void*)f_2790},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  sprintf		1
S|  for-each		11
S|  printf		4
S|  map		16
o|eliminated procedure checks: 131 
o|specializations:
o|  1 (current-output-port)
o|  2 (string=? string string)
o|  1 (string-append string string)
o|  5 (cdr pair)
o|  4 (eqv? (not float) *)
o|  1 (< fixnum fixnum)
o|  5 (##sys#check-output-port * * *)
o|  8 (##sys#check-list (or pair list) *)
o|  66 (memq * list)
o|  2 (car pair)
(o e)|safe calls: 353 
o|Removed `not' forms: 5 
o|inlining procedure: k1720 
o|inlining procedure: k1720 
o|substituted constant variable: a1751 
o|substituted constant variable: a1754 
o|substituted constant variable: a1759 
o|substituted constant variable: a1761 
o|substituted constant variable: a1775 
o|substituted constant variable: a1780 
o|substituted constant variable: a1785 
o|substituted constant variable: a1787 
o|substituted constant variable: a1789 
o|substituted constant variable: a1791 
o|substituted constant variable: a1793 
o|substituted constant variable: a1795 
o|substituted constant variable: a1797 
o|substituted constant variable: a1799 
o|substituted constant variable: a1801 
o|merged explicitly consed rest parameter: args127 
o|propagated global variable: out131135 ##sys#standard-output 
o|substituted constant variable: a1835 
o|substituted constant variable: a1836 
o|inlining procedure: k1828 
o|propagated global variable: out131135 ##sys#standard-output 
o|inlining procedure: k1828 
o|inlining procedure: k1852 
o|inlining procedure: k1852 
o|propagated global variable: out149153 ##sys#standard-output 
o|substituted constant variable: a1881 
o|substituted constant variable: a1882 
o|inlining procedure: k1874 
o|propagated global variable: out149153 ##sys#standard-output 
o|inlining procedure: k1874 
o|inlining procedure: k1901 
o|inlining procedure: k1924 
o|contracted procedure: "(batch-driver.scm:130) g165172" 
o|inlining procedure: k1924 
o|inlining procedure: k1901 
o|inlining procedure: k1956 
o|inlining procedure: k1956 
o|inlining procedure: k1971 
o|folded constant expression: (* (quote 1024) (quote 1024)) 
o|inlining procedure: k1971 
o|substituted constant variable: a2022 
o|substituted constant variable: a2024 
o|substituted constant variable: a2029 
o|substituted constant variable: a2031 
o|substituted constant variable: a2033 
o|inlining procedure: k2046 
o|inlining procedure: k2046 
o|inlining procedure: k2072 
o|inlining procedure: "(batch-driver.scm:153) cputime115" 
o|inlining procedure: k2072 
o|propagated global variable: out213217 ##sys#standard-output 
o|substituted constant variable: a2086 
o|substituted constant variable: a2087 
o|inlining procedure: k2082 
o|inlining procedure: "(batch-driver.scm:159) cputime115" 
o|propagated global variable: out213217 ##sys#standard-output 
o|inlining procedure: k2082 
o|merged explicitly consed rest parameter: args225 
o|inlining procedure: k2127 
o|propagated global variable: g249250 ##compiler#get 
o|propagated global variable: g263264 ##compiler#put! 
o|inlining procedure: k2127 
o|inlining procedure: k2155 
o|inlining procedure: k2155 
o|substituted constant variable: a2194 
o|substituted constant variable: a2308 
o|substituted constant variable: a2313 
o|substituted constant variable: a2318 
o|substituted constant variable: a2445 
o|substituted constant variable: a2469 
o|inlining procedure: k2466 
o|inlining procedure: k2466 
o|substituted constant variable: a2480 
o|substituted constant variable: a2491 
o|inlining procedure: k2488 
o|inlining procedure: k2488 
o|contracted procedure: k2506 
o|inlining procedure: k2709 
o|inlining procedure: k2724 
o|inlining procedure: k2724 
o|inlining procedure: k2742 
o|inlining procedure: k2742 
o|contracted procedure: k2771 
o|propagated global variable: r2772 ##compiler#inline-substitutions-enabled 
o|inlining procedure: k2768 
o|consed rest parameter at call site: "(batch-driver.scm:638) analyze125" 3 
o|inlining procedure: k2768 
o|contracted procedure: k2820 
o|inlining procedure: k2709 
o|consed rest parameter at call site: "(batch-driver.scm:693) dribble116" 2 
o|consed rest parameter at call site: "(batch-driver.scm:684) dribble116" 2 
o|inlining procedure: "(batch-driver.scm:672) cputime115" 
o|consed rest parameter at call site: "(batch-driver.scm:664) dribble116" 2 
o|inlining procedure: k2971 
o|consed rest parameter at call site: "(batch-driver.scm:608) dribble116" 2 
o|inlining procedure: k2971 
o|consed rest parameter at call site: "(batch-driver.scm:598) analyze125" 3 
o|contracted procedure: "(batch-driver.scm:582) g11301131" 
o|inlining procedure: k3082 
o|inlining procedure: k3082 
o|consed rest parameter at call site: "(batch-driver.scm:566) analyze125" 3 
o|inlining procedure: k3092 
o|contracted procedure: "(batch-driver.scm:560) g10991106" 
o|inlining procedure: k3092 
o|inlining procedure: k3115 
o|contracted procedure: "(batch-driver.scm:555) g10781085" 
o|inlining procedure: k3025 
o|inlining procedure: k3025 
o|inlining procedure: k3115 
o|substituted constant variable: a3135 
o|inlining procedure: k3137 
o|inlining procedure: k3137 
o|consed rest parameter at call site: "(batch-driver.scm:546) dribble116" 2 
o|inlining procedure: k3167 
o|inlining procedure: k3167 
o|inlining procedure: k3192 
o|consed rest parameter at call site: "(batch-driver.scm:538) dribble116" 2 
o|inlining procedure: k3192 
o|inlining procedure: k3221 
o|inlining procedure: k3221 
o|inlining procedure: k3257 
o|inlining procedure: k3257 
o|contracted procedure: "(batch-driver.scm:518) g998999" 
o|inlining procedure: k3326 
o|inlining procedure: k3326 
o|consed rest parameter at call site: "(batch-driver.scm:512) dribble116" 2 
o|substituted constant variable: a3357 
o|substituted constant variable: a3373 
o|substituted constant variable: a3374 
o|inlining procedure: k3446 
o|contracted procedure: "(batch-driver.scm:489) g926933" 
o|propagated global variable: out936940 ##sys#standard-output 
o|substituted constant variable: a3414 
o|substituted constant variable: a3415 
o|propagated global variable: out936940 ##sys#standard-output 
o|inlining procedure: k3446 
o|propagated global variable: g932934 ##compiler#compiler-syntax-statistics 
o|inlining procedure: k3498 
o|contracted procedure: "(batch-driver.scm:481) g904913" 
o|inlining procedure: k3498 
o|propagated global variable: g910914 ##compiler#import-libraries 
o|contracted procedure: k3609 
o|propagated global variable: r3610 ##compiler#unit-name 
o|inlining procedure: k3606 
o|inlining procedure: k3606 
o|inlining procedure: k3618 
o|contracted procedure: "(batch-driver.scm:465) g873882" 
o|inlining procedure: k3618 
o|propagated global variable: g879883 ##compiler#profile-lambda-list 
o|contracted procedure: k3672 
o|propagated global variable: r3673 ##compiler#unit-name 
o|inlining procedure: k3669 
o|inlining procedure: k3669 
o|inlining procedure: k3681 
o|contracted procedure: "(batch-driver.scm:457) g836845" 
o|inlining procedure: k3681 
o|propagated global variable: g842846 ##compiler#used-units 
o|inlining procedure: k3715 
o|contracted procedure: "(batch-driver.scm:456) g806815" 
o|inlining procedure: k3715 
o|propagated global variable: g812816 ##compiler#immutable-constants 
o|inlining procedure: k3749 
o|inlining procedure: k3749 
o|inlining procedure: k3838 
o|inlining procedure: k3838 
o|consed rest parameter at call site: "(batch-driver.scm:436) dribble116" 2 
o|consed rest parameter at call site: "(batch-driver.scm:413) dribble116" 2 
o|inlining procedure: k3882 
o|inlining procedure: k3919 
o|inlining procedure: k3919 
o|inlining procedure: k3953 
o|inlining procedure: k3953 
o|inlining procedure: k3882 
o|inlining procedure: k4015 
o|inlining procedure: k4015 
o|inlining procedure: "(batch-driver.scm:400) cputime115" 
o|consed rest parameter at call site: "(batch-driver.scm:394) dribble116" 2 
o|substituted constant variable: a4048 
o|inlining procedure: k4050 
o|substituted constant variable: a4053 
o|inlining procedure: k4050 
o|substituted constant variable: a4058 
o|consed rest parameter at call site: "(batch-driver.scm:373) dribble116" 2 
o|inlining procedure: k4076 
o|consed rest parameter at call site: "(batch-driver.scm:373) dribble116" 2 
o|inlining procedure: k4076 
o|consed rest parameter at call site: "(batch-driver.scm:373) dribble116" 2 
o|inlining procedure: k4080 
o|inlining procedure: k4080 
o|consed rest parameter at call site: "(batch-driver.scm:355) dribble116" 2 
o|inlining procedure: k4097 
o|consed rest parameter at call site: "(batch-driver.scm:355) dribble116" 2 
o|inlining procedure: k4097 
o|consed rest parameter at call site: "(batch-driver.scm:355) dribble116" 2 
o|substituted constant variable: a4100 
o|substituted constant variable: a4112 
o|substituted constant variable: a4128 
o|inlining procedure: k4160 
o|contracted procedure: "(batch-driver.scm:335) g594603" 
o|inlining procedure: k4160 
o|inlining procedure: k4194 
o|contracted procedure: "(batch-driver.scm:321) g570577" 
o|inlining procedure: k4194 
o|consed rest parameter at call site: "(batch-driver.scm:320) dribble116" 2 
o|inlining procedure: k4217 
o|inlining procedure: k4217 
o|propagated global variable: g559560 string-split 
o|inlining procedure: k4250 
o|inlining procedure: k4250 
o|propagated global variable: g534535 string-split 
o|substituted constant variable: a4286 
o|inlining procedure: k4375 
o|contracted procedure: "(batch-driver.scm:302) g469476" 
o|contracted procedure: "(batch-driver.scm:305) g494495" 
o|contracted procedure: "(batch-driver.scm:304) g479480" 
o|inlining procedure: k4375 
o|propagated global variable: g475477 ##compiler#default-extended-bindings 
o|inlining procedure: k4398 
o|contracted procedure: "(batch-driver.scm:297) g420427" 
o|contracted procedure: "(batch-driver.scm:300) g445446" 
o|contracted procedure: "(batch-driver.scm:299) g430431" 
o|inlining procedure: k4398 
o|propagated global variable: g426428 ##compiler#default-standard-bindings 
o|substituted constant variable: a4418 
o|substituted constant variable: a4421 
o|substituted constant variable: a4424 
o|substituted constant variable: a4427 
o|substituted constant variable: a4430 
o|inlining procedure: k4448 
o|inlining procedure: k4448 
o|inlining procedure: k4489 
o|inlining procedure: k4489 
o|inlining procedure: k4511 
o|inlining procedure: k4511 
o|substituted constant variable: a4542 
o|consed rest parameter at call site: "(batch-driver.scm:269) dribble116" 2 
o|substituted constant variable: a4559 
o|consed rest parameter at call site: "(batch-driver.scm:266) dribble116" 2 
o|substituted constant variable: a4567 
o|consed rest parameter at call site: "(batch-driver.scm:263) dribble116" 2 
o|inlining procedure: k4578 
o|inlining procedure: k4578 
o|substituted constant variable: a4590 
o|substituted constant variable: a4598 
o|inlining procedure: k4595 
o|inlining procedure: k4595 
o|substituted constant variable: a4606 
o|consed rest parameter at call site: "(batch-driver.scm:253) dribble116" 2 
o|inlining procedure: k4624 
o|inlining procedure: k4624 
o|substituted constant variable: a4640 
o|substituted constant variable: a4643 
o|substituted constant variable: a4646 
o|substituted constant variable: a4649 
o|substituted constant variable: a4652 
o|substituted constant variable: a4655 
o|substituted constant variable: a4658 
o|substituted constant variable: a4661 
o|substituted constant variable: a4664 
o|consed rest parameter at call site: "(batch-driver.scm:227) dribble116" 2 
o|substituted constant variable: a4671 
o|substituted constant variable: a4676 
o|substituted constant variable: a4680 
o|substituted constant variable: a4683 
o|substituted constant variable: a4686 
o|substituted constant variable: a4689 
o|substituted constant variable: a4694 
o|substituted constant variable: a4699 
o|substituted constant variable: a4704 
o|substituted constant variable: a4721 
o|substituted constant variable: a4727 
o|inlining procedure: k4723 
o|inlining procedure: k4723 
o|inlining procedure: k4735 
o|contracted procedure: "(batch-driver.scm:190) g314323" 
o|substituted constant variable: a2225 
o|inlining procedure: k4735 
o|inlining procedure: k4799 
o|contracted procedure: "(batch-driver.scm:181) g286295" 
o|inlining procedure: k4799 
o|substituted constant variable: a4834 
o|propagated global variable: tmp273275 ##compiler#unit-name 
o|inlining procedure: k4840 
o|propagated global variable: tmp273275 ##compiler#unit-name 
o|inlining procedure: k4840 
o|substituted constant variable: a4856 
o|substituted constant variable: a4861 
o|inlining procedure: k4863 
o|inlining procedure: k4863 
o|substituted constant variable: a4866 
o|inlining procedure: k4871 
o|inlining procedure: k4871 
o|inlining procedure: k4906 
o|inlining procedure: k4906 
o|inlining procedure: k4914 
o|inlining procedure: k4914 
o|substituted constant variable: a4929 
o|inlining procedure: k4926 
o|inlining procedure: k4926 
o|inlining procedure: k4935 
o|inlining procedure: k4935 
o|inlining procedure: k4954 
o|inlining procedure: k4954 
o|replaced variables: 410 
o|removed binding forms: 395 
o|Removed `not' forms: 2 
o|removed side-effect free assignment to unused variable: cputime115 
o|propagated global variable: out131135 ##sys#standard-output 
o|substituted constant variable: r18294966 
o|substituted constant variable: r18294967 
o|propagated global variable: out149153 ##sys#standard-output 
o|contracted procedure: k1988 
o|substituted constant variable: r20474981 
o|propagated global variable: out213217 ##sys#standard-output 
o|substituted constant variable: r31935035 
o|substituted constant variable: c1000 
o|substituted constant variable: p1001 
o|propagated global variable: out936940 ##sys#standard-output 
o|substituted constant variable: r36075046 
o|contracted procedure: k3606 
o|substituted constant variable: r36705050 
o|substituted constant variable: r36705050 
o|inlining procedure: k3669 
o|inlining procedure: k3669 
o|substituted constant variable: r40775076 
o|substituted constant variable: r40775076 
o|substituted constant variable: r40775078 
o|substituted constant variable: r40775078 
o|substituted constant variable: r40815080 
o|substituted constant variable: r40815080 
o|substituted constant variable: r40815082 
o|substituted constant variable: r40815082 
o|substituted constant variable: r40985084 
o|substituted constant variable: r40985084 
o|substituted constant variable: r40985086 
o|substituted constant variable: r40985086 
o|substituted constant variable: tmp500503 
o|substituted constant variable: mark502 
o|substituted constant variable: tmp485488 
o|substituted constant variable: mark487 
o|substituted constant variable: tmp451454 
o|substituted constant variable: mark453 
o|substituted constant variable: tmp436439 
o|substituted constant variable: mark438 
o|substituted constant variable: r44905103 
o|contracted procedure: k4723 
o|substituted constant variable: r47245116 
o|propagated global variable: r48415122 ##compiler#unit-name 
o|substituted constant variable: r49075132 
o|substituted constant variable: r49075132 
o|substituted constant variable: r49275136 
o|substituted constant variable: r49365140 
o|substituted constant variable: r49365140 
o|substituted constant variable: r49555142 
o|substituted constant variable: r49555142 
o|converted assignments to bindings: (option-arg30) 
o|simplifications: ((let . 1)) 
o|replaced variables: 16 
o|removed binding forms: 524 
o|removed conditional forms: 2 
o|substituted constant variable: r1989 
o|inlining procedure: k2890 
o|inlining procedure: k2918 
o|inlining procedure: k3603 
o|inlining procedure: k3603 
o|inlining procedure: k3603 
o|substituted constant variable: r36705186 
o|inlining procedure: k4083 
o|inlining procedure: k4351 
o|inlining procedure: k4334 
o|inlining procedure: k4309 
o|inlining procedure: k4292 
o|inlining procedure: k4483 
o|inlining procedure: k4483 
o|replaced variables: 15 
o|removed binding forms: 61 
o|Removed `not' forms: 1 
o|substituted constant variable: r29195249 
o|substituted constant variable: r36045268 
o|substituted constant variable: r36045269 
o|contracted procedure: k4083 
o|substituted constant variable: r40845289 
o|substituted constant variable: r43525298 
o|substituted constant variable: r43355299 
o|substituted constant variable: r43105302 
o|substituted constant variable: r42935303 
o|substituted constant variable: r44845308 
o|substituted constant variable: r44845309 
o|replaced variables: 4 
o|removed binding forms: 20 
o|removed conditional forms: 4 
o|replaced variables: 4 
o|removed binding forms: 14 
o|removed binding forms: 2 
o|simplifications: ((if . 10) (##core#call . 282)) 
o|  call simplifications:
o|    string->list
o|    string
o|    string=?	2
o|    not	2
o|    eof-object?
o|    ##sys#cons	7
o|    length
o|    ##sys#list	20
o|    list	2
o|    ##sys#make-structure
o|    ##sys#setslot	16
o|    first
o|    >
o|    ##sys#call-with-values	2
o|    add1	5
o|    car	11
o|    inexact->exact
o|    cddr
o|    cons	38
o|    string-length
o|    -	3
o|    fx<
o|    string-ref
o|    eq?	5
o|    *	2
o|    string->number	5
o|    ##sys#check-list	19
o|    pair?	28
o|    ##sys#slot	71
o|    memq	13
o|    apply
o|    cdr	3
o|    null?	11
o|    cadr	2
o|    symbol?	2
o|contracted procedure: k1744 
o|contracted procedure: k1723 
o|contracted procedure: k1731 
o|contracted procedure: k1737 
o|contracted procedure: k4942 
o|contracted procedure: k1756 
o|contracted procedure: k1766 
o|contracted procedure: k1782 
o|contracted procedure: k1831 
o|contracted procedure: k1915 
o|contracted procedure: k1927 
o|contracted procedure: k1937 
o|contracted procedure: k1941 
o|contracted procedure: k1947 
o|contracted procedure: k1950 
o|contracted procedure: k1962 
o|inlining procedure: k1953 
o|contracted procedure: k1968 
o|contracted procedure: k1974 
o|contracted procedure: k1977 
o|contracted procedure: k1984 
o|inlining procedure: k1953 
o|contracted procedure: k1998 
o|contracted procedure: k2001 
o|contracted procedure: k2008 
o|inlining procedure: k1953 
o|inlining procedure: k1953 
o|contracted procedure: k2043 
o|contracted procedure: k2063 
o|contracted procedure: k2104 
o|contracted procedure: k2112 
o|contracted procedure: k2158 
o|contracted procedure: k2164 
o|contracted procedure: k2171 
o|contracted procedure: k2177 
o|contracted procedure: k2204 
o|contracted procedure: k2208 
o|contracted procedure: k2229 
o|contracted procedure: k2239 
o|contracted procedure: k2385 
o|contracted procedure: k2403 
o|contracted procedure: k2414 
o|contracted procedure: k2441 
o|contracted procedure: k2575 
o|contracted procedure: k2584 
o|contracted procedure: k2593 
o|contracted procedure: k3293 
o|contracted procedure: k2636 
o|contracted procedure: k2749 
o|contracted procedure: k2755 
o|contracted procedure: k2765 
o|contracted procedure: k2810 
o|contracted procedure: k2817 
o|contracted procedure: k2782 
o|inlining procedure: "(batch-driver.scm:693) dribble116" 
o|contracted procedure: k2899 
o|inlining procedure: "(batch-driver.scm:693) dribble116" 
o|inlining procedure: "(batch-driver.scm:684) dribble116" 
o|contracted procedure: k2928 
o|contracted procedure: k2918 
o|contracted procedure: k2935 
o|inlining procedure: "(batch-driver.scm:664) dribble116" 
o|contracted procedure: k2956 
o|inlining procedure: "(batch-driver.scm:608) dribble116" 
o|contracted procedure: k2980 
o|contracted procedure: k2986 
o|contracted procedure: k2992 
o|contracted procedure: k3011 
o|contracted procedure: k3002 
o|contracted procedure: k3014 
o|contracted procedure: k3034 
o|contracted procedure: k3095 
o|contracted procedure: k3105 
o|contracted procedure: k3109 
o|contracted procedure: k3118 
o|contracted procedure: k3128 
o|contracted procedure: k3132 
o|contracted procedure: k3146 
o|inlining procedure: "(batch-driver.scm:546) dribble116" 
o|contracted procedure: k3158 
o|contracted procedure: k3170 
o|contracted procedure: k3180 
o|contracted procedure: k3184 
o|inlining procedure: "(batch-driver.scm:538) dribble116" 
o|contracted procedure: k3224 
o|contracted procedure: k3234 
o|contracted procedure: k3238 
o|contracted procedure: k3248 
o|contracted procedure: k3260 
o|contracted procedure: k3282 
o|contracted procedure: k3278 
o|contracted procedure: k3263 
o|contracted procedure: k3266 
o|contracted procedure: k3274 
o|contracted procedure: k3311 
o|contracted procedure: k3314 
o|contracted procedure: k3329 
o|contracted procedure: k3332 
o|contracted procedure: k3335 
o|contracted procedure: k3343 
o|contracted procedure: k3351 
o|inlining procedure: "(batch-driver.scm:512) dribble116" 
o|contracted procedure: k3362 
o|contracted procedure: k3399 
o|contracted procedure: k3437 
o|contracted procedure: k3449 
o|contracted procedure: k3459 
o|contracted procedure: k3463 
o|contracted procedure: k3434 
o|propagated global variable: g932934 ##compiler#compiler-syntax-statistics 
o|contracted procedure: k3466 
o|contracted procedure: k3477 
o|contracted procedure: k3489 
o|contracted procedure: k3501 
o|contracted procedure: k3504 
o|contracted procedure: k3507 
o|contracted procedure: k3515 
o|contracted procedure: k3523 
o|contracted procedure: k3486 
o|propagated global variable: g910914 ##compiler#import-libraries 
o|contracted procedure: k3530 
o|contracted procedure: k3548 
o|contracted procedure: k3555 
o|contracted procedure: k3563 
o|contracted procedure: k3574 
o|contracted procedure: k3596 
o|contracted procedure: k3621 
o|contracted procedure: k3624 
o|contracted procedure: k3627 
o|contracted procedure: k3635 
o|contracted procedure: k3643 
o|contracted procedure: k3593 
o|contracted procedure: k3583 
o|contracted procedure: k3587 
o|propagated global variable: g879883 ##compiler#profile-lambda-list 
o|contracted procedure: k3661 
o|contracted procedure: k3665 
o|contracted procedure: k3657 
o|contracted procedure: k3653 
o|contracted procedure: k3684 
o|contracted procedure: k3706 
o|contracted procedure: k3702 
o|contracted procedure: k3687 
o|contracted procedure: k3690 
o|contracted procedure: k3698 
o|propagated global variable: g842846 ##compiler#used-units 
o|contracted procedure: k3718 
o|contracted procedure: k3721 
o|contracted procedure: k3724 
o|contracted procedure: k3732 
o|contracted procedure: k3740 
o|contracted procedure: k3539 
o|contracted procedure: k3543 
o|propagated global variable: g812816 ##compiler#immutable-constants 
o|contracted procedure: k3752 
o|contracted procedure: k3755 
o|contracted procedure: k3758 
o|contracted procedure: k3766 
o|contracted procedure: k3774 
o|contracted procedure: k3800 
o|contracted procedure: k3796 
o|contracted procedure: k3792 
o|contracted procedure: k3788 
o|contracted procedure: k3784 
o|contracted procedure: k3803 
o|contracted procedure: k3819 
o|contracted procedure: k3815 
o|contracted procedure: k3811 
o|contracted procedure: k3826 
o|contracted procedure: k3829 
o|contracted procedure: k3841 
o|contracted procedure: k3844 
o|contracted procedure: k3847 
o|contracted procedure: k3855 
o|contracted procedure: k3863 
o|inlining procedure: "(batch-driver.scm:436) dribble116" 
o|inlining procedure: "(batch-driver.scm:413) dribble116" 
o|contracted procedure: k3885 
o|contracted procedure: k3893 
o|contracted procedure: k3896 
o|contracted procedure: k3907 
o|contracted procedure: k3910 
o|contracted procedure: k3922 
o|contracted procedure: k3925 
o|contracted procedure: k3928 
o|contracted procedure: k3936 
o|contracted procedure: k3944 
o|contracted procedure: k3956 
o|contracted procedure: k3959 
o|contracted procedure: k3962 
o|contracted procedure: k3970 
o|contracted procedure: k3978 
o|contracted procedure: k3984 
o|contracted procedure: k4018 
o|contracted procedure: k4025 
o|contracted procedure: k4041 
o|inlining procedure: "(batch-driver.scm:394) dribble116" 
o|contracted procedure: k4093 
o|contracted procedure: k4060 
o|inlining procedure: "(batch-driver.scm:373) dribble116" 
o|inlining procedure: "(batch-driver.scm:373) dribble116" 
o|inlining procedure: "(batch-driver.scm:355) dribble116" 
o|inlining procedure: "(batch-driver.scm:355) dribble116" 
o|contracted procedure: k4105 
o|contracted procedure: k4132 
o|contracted procedure: k4151 
o|contracted procedure: k4163 
o|contracted procedure: k4166 
o|contracted procedure: k4169 
o|contracted procedure: k4177 
o|contracted procedure: k4185 
o|contracted procedure: k4141 
o|contracted procedure: k4197 
o|contracted procedure: k4207 
o|contracted procedure: k4211 
o|inlining procedure: "(batch-driver.scm:320) dribble116" 
o|contracted procedure: k4220 
o|contracted procedure: k4230 
o|contracted procedure: k4234 
o|contracted procedure: k4253 
o|contracted procedure: k4263 
o|contracted procedure: k4267 
o|contracted procedure: k4280 
o|contracted procedure: k4324 
o|contracted procedure: k4366 
o|contracted procedure: k4378 
o|contracted procedure: k4388 
o|contracted procedure: k4392 
o|contracted procedure: k4357 
o|contracted procedure: k4351 
o|contracted procedure: k4340 
o|contracted procedure: k4334 
o|propagated global variable: g475477 ##compiler#default-extended-bindings 
o|contracted procedure: k4401 
o|contracted procedure: k4411 
o|contracted procedure: k4415 
o|contracted procedure: k4315 
o|contracted procedure: k4309 
o|contracted procedure: k4298 
o|contracted procedure: k4292 
o|propagated global variable: g426428 ##compiler#default-standard-bindings 
o|contracted procedure: k4436 
o|contracted procedure: k4451 
o|contracted procedure: k4454 
o|contracted procedure: k4457 
o|contracted procedure: k4465 
o|contracted procedure: k4473 
o|contracted procedure: k4483 
o|contracted procedure: k4496 
o|contracted procedure: k4502 
o|contracted procedure: k4514 
o|contracted procedure: k4517 
o|contracted procedure: k4520 
o|contracted procedure: k4528 
o|contracted procedure: k4536 
o|inlining procedure: "(batch-driver.scm:269) dribble116" 
o|inlining procedure: "(batch-driver.scm:266) dribble116" 
o|inlining procedure: "(batch-driver.scm:263) dribble116" 
o|contracted procedure: k4581 
o|inlining procedure: "(batch-driver.scm:253) dribble116" 
o|contracted procedure: k4621 
o|inlining procedure: "(batch-driver.scm:227) dribble116" 
o|contracted procedure: k4709 
o|contracted procedure: k4713 
o|contracted procedure: k4738 
o|contracted procedure: k4741 
o|contracted procedure: k4744 
o|contracted procedure: k4752 
o|contracted procedure: k4760 
o|contracted procedure: k4766 
o|contracted procedure: k4778 
o|contracted procedure: k4802 
o|contracted procedure: k4805 
o|contracted procedure: k4808 
o|contracted procedure: k4816 
o|contracted procedure: k4824 
o|contracted procedure: k4787 
o|contracted procedure: k4874 
o|contracted procedure: k4877 
o|contracted procedure: k4880 
o|contracted procedure: k4888 
o|contracted procedure: k4896 
o|contracted procedure: k4917 
o|contracted procedure: k4950 
o|contracted procedure: k4961 
o|contracted procedure: k4954 
o|simplifications: ((let . 57)) 
o|removed binding forms: 254 
o|removed side-effect free assignment to unused variable: dribble116 
o|substituted constant variable: fstr1265641 
o|substituted constant variable: args1275642 
o|substituted constant variable: fstr1265647 
o|substituted constant variable: args1275648 
o|substituted constant variable: fstr1265653 
o|substituted constant variable: fstr1265659 
o|substituted constant variable: fstr1265665 
o|contracted procedure: "(batch-driver.scm:544) g10551062" 
o|substituted constant variable: fstr1265677 
o|contracted procedure: "(batch-driver.scm:532) g10341041" 
o|substituted constant variable: fstr1265685 
o|substituted constant variable: fstr1265697 
o|substituted constant variable: args1275698 
o|substituted constant variable: fstr1265717 
o|substituted constant variable: args1275718 
o|substituted constant variable: fstr1265723 
o|substituted constant variable: args1275724 
o|substituted constant variable: fstr1265737 
o|substituted constant variable: fstr1265743 
o|substituted constant variable: fstr1265749 
o|substituted constant variable: fstr1265755 
o|substituted constant variable: fstr1265761 
o|substituted constant variable: fstr1265771 
o|substituted constant variable: args1275772 
o|substituted constant variable: fstr1265789 
o|substituted constant variable: args1275790 
o|substituted constant variable: fstr1265795 
o|substituted constant variable: args1275796 
o|substituted constant variable: fstr1265801 
o|substituted constant variable: args1275802 
o|substituted constant variable: fstr1265807 
o|substituted constant variable: args1275808 
o|substituted constant variable: fstr1265813 
o|substituted constant variable: args1275814 
o|replaced variables: 115 
o|removed binding forms: 3 
o|replaced variables: 1 
o|removed binding forms: 94 
o|contracted procedure: k3639 
o|contracted procedure: k3736 
o|removed binding forms: 3 
o|customizable procedures: (g7273 map-loop7898 k1777 k1803 k2184 k2187 map-loop280298 map-loop308326 k2235 k2242 k2248 k2260 k2263 k2266 k2269 k2272 k2275 k2278 k2281 k2284 k2287 k2290 k2293 k2296 k2299 k2302 k2305 k2310 k2315 k2320 map-loop364381 map-loop393410 k2351 k2354 k2357 k2360 k2363 for-each-loop419461 for-each-loop468510 for-each-loop518536 for-each-loop543561 for-each-loop569580 map-loop588609 k2429 arg-val121 k2454 k2482 loop720 doloop655656 map-loop660677 map-loop686703 map-loop735752 k2563 k2572 k2581 map-loop767788 map-loop800821 map-loop830851 k3570 map-loop867888 map-loop898916 for-each-loop925946 print-expr120 map-loop969986 map-loop10071024 for-each-loop10331046 for-each-loop10541066 collect-options122 for-each-loop10771091 for-each-loop10981109 k2663 print-db119 print-node118 analyze125 begin-time123 end-time124 loop1134 def-no230268 def-contf231266 body228236 g208209 option-arg30 loop200 for-each-loop164176 print-header117) 
o|calls to known targets: 277 
o|identified direct recursive calls: f_3255 1 
o|identified direct recursive calls: f_3616 1 
o|identified direct recursive calls: f_3679 1 
o|identified direct recursive calls: f_3713 1 
o|fast box initializations: 40 
o|dropping unused closure argument: f_1945 
o|dropping unused closure argument: f_1718 
o|dropping unused closure argument: f_1823 
*/
/* end of file */
