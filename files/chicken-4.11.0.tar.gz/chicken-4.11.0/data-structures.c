/* Generated from data-structures.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:48
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: data-structures.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file data-structures.c
   unit: data_2dstructures
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[121];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,105,100,101,110,116,105,116,121,32,120,54,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,54,57,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,12),40,102,95,49,52,48,56,32,120,54,55,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,19),40,99,111,110,106,111,105,110,32,46,32,112,114,101,100,115,54,54,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,56,49,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,12),40,102,95,49,52,52,49,32,120,55,57,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,19),40,100,105,115,106,111,105,110,32,46,32,112,114,101,100,115,55,56,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,14),40,102,95,49,52,56,55,32,46,32,95,57,50,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,102,95,49,52,56,57,32,46,32,95,57,51,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,99,111,110,115,116,97,110,116,108,121,32,46,32,120,115,57,48,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,102,95,49,52,57,57,32,120,57,54,32,121,57,55,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,13),40,102,108,105,112,32,112,114,111,99,57,53,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,102,95,49,53,48,55,32,46,32,97,114,103,115,49,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,99,111,109,112,108,101,109,101,110,116,32,112,57,57,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,53,51,51,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,102,95,49,53,50,56,32,46,32,97,114,103,115,49,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,20),40,114,101,99,32,102,48,49,48,52,32,46,32,102,110,115,49,48,53,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,99,111,109,112,111,115,101,32,46,32,102,110,115,49,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,102,95,49,53,55,57,32,120,49,49,52,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,49,49,49,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,12),40,111,32,46,32,102,110,115,49,48,57,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,50,50,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,15),40,102,95,49,53,57,52,32,108,115,116,49,50,48,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,18),40,108,105,115,116,45,111,102,63,32,112,114,101,100,49,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,15),40,102,95,49,54,52,48,32,46,32,95,49,51,52,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,112,114,111,99,115,49,51,55,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,18),40,102,95,49,54,53,52,32,46,32,97,114,103,115,49,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,17),40,101,97,99,104,32,46,32,112,114,111,99,115,49,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,11),40,97,110,121,63,32,120,49,52,51,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,12),40,97,116,111,109,63,32,120,49,52,53,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,17),40,116,97,105,108,63,32,120,49,52,55,32,121,49,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,110,115,49,54,52,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,105,110,116,101,114,115,112,101,114,115,101,32,108,115,116,49,54,49,32,120,49,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,55,48,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,98,117,116,108,97,115,116,32,108,115,116,49,54,56,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,105,115,116,115,49,55,56,32,114,101,115,116,49,55,57,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,21),40,102,108,97,116,116,101,110,32,46,32,108,105,115,116,115,48,49,55,54,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,28),40,100,111,108,111,111,112,49,57,56,32,104,100,50,48,48,32,116,108,50,48,49,32,99,50,48,50,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,115,116,49,57,50,32,105,49,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,99,104,111,112,32,108,115,116,49,56,56,32,110,49,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,115,50,49,50,41,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,23),40,106,111,105,110,32,108,115,116,115,50,48,56,32,46,32,108,115,116,50,48,57,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,98,108,115,116,50,50,54,32,108,115,116,50,50,55,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,25),40,99,111,109,112,114,101,115,115,32,98,108,115,116,50,50,50,32,108,115,116,50,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,50,53,55,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,102,95,50,48,56,57,32,120,50,53,52,32,108,115,116,50,53,53,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,44),40,97,108,105,115,116,45,117,112,100,97,116,101,33,32,120,50,52,48,32,121,50,52,49,32,108,115,116,50,52,50,32,46,32,116,109,112,50,51,57,50,52,51,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,50,56,48,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,43),40,97,108,105,115,116,45,117,112,100,97,116,101,32,107,50,55,48,32,118,50,55,49,32,108,115,116,50,55,50,32,46,32,116,109,112,50,54,57,50,55,51,41,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,51,49,56,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,20),40,102,95,50,50,56,49,32,120,51,49,53,32,108,115,116,51,49,54,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,35),40,97,108,105,115,116,45,114,101,102,32,120,50,57,55,32,108,115,116,50,57,56,32,46,32,116,109,112,50,57,54,50,57,57,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,51,51,51,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,29),40,114,97,115,115,111,99,32,120,51,50,56,32,108,115,116,51,50,57,32,46,32,116,115,116,51,51,48,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,107,51,52,57,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,29),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,51,52,50,32,105,51,52,51,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,28),40,114,101,118,101,114,115,101,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,51,52,48,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,45,62,115,116,114,105,110,103,32,120,51,53,52,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,54,53,32,103,51,55,55,51,56,51,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,16),40,99,111,110,99,32,46,32,97,114,103,115,51,54,50,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,105,115,116,97,114,116,52,48,49,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,52),40,116,114,97,118,101,114,115,101,32,119,104,105,99,104,51,57,48,32,119,104,101,114,101,51,57,49,32,115,116,97,114,116,51,57,50,32,116,101,115,116,51,57,51,32,108,111,99,51,57,52,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,97,50,54,52,52,32,105,52,49,52,32,108,52,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,52,49,49,32,119,104,101,114,101,52,49,50,32,115,116,97,114,116,52,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,17),40,97,50,54,53,51,32,105,52,49,57,32,108,52,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,53),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,52,49,54,32,119,104,101,114,101,52,49,55,32,115,116,97,114,116,52,49,56,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,47),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,52,50,57,32,119,104,101,114,101,52,51,48,32,46,32,116,109,112,52,50,56,52,51,49,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,50),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,52,52,51,32,119,104,101,114,101,52,52,52,32,46,32,116,109,112,52,52,50,52,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,32,115,49,52,53,50,32,115,50,52,53,51,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,45,99,105,32,115,49,52,54,49,32,115,50,52,54,50,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,61,63,32,115,49,52,55,48,32,115,50,52,55,49,32,115,116,97,114,116,49,52,55,50,32,115,116,97,114,116,50,52,55,51,32,110,52,55,52,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,37),40,115,117,98,115,116,114,105,110,103,61,63,32,115,49,52,56,57,32,115,50,52,57,48,32,46,32,116,109,112,52,56,56,52,57,49,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,59),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,53,48,53,32,115,50,53,48,54,32,115,116,97,114,116,49,53,48,55,32,115,116,97,114,116,50,53,48,56,32,110,53,48,57,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,40),40,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,53,50,52,32,115,50,53,50,53,32,46,32,116,109,112,53,50,51,53,50,54,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,27),40,97,100,100,32,102,114,111,109,53,52,56,32,116,111,53,52,57,32,108,97,115,116,53,53,48,41,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,53,55,48,41,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,105,53,53,52,32,108,97,115,116,53,53,53,32,102,114,111,109,53,53,54,41,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,42),40,115,116,114,105,110,103,45,115,112,108,105,116,32,115,116,114,53,52,48,32,46,32,100,101,108,115,116,114,45,97,110,100,45,102,108,97,103,53,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,50,32,110,50,54,48,56,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,49,32,115,115,53,57,57,32,110,54,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,40),40,115,116,114,105,110,103,45,105,110,116,101,114,115,112,101,114,115,101,32,115,116,114,115,53,57,48,32,46,32,116,109,112,53,56,57,53,57,49,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,13),40,102,95,51,49,56,55,32,99,54,50,57,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,15),40,105,110,115,116,114,105,110,103,32,115,54,50,55,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,105,54,53,55,32,106,54,53,56,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,13),40,102,95,51,51,53,57,32,99,54,52,50,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,32,115,116,114,54,50,51,32,102,114,111,109,54,50,52,32,46,32,116,111,54,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,109,97,112,54,56,49,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,37),40,99,111,108,108,101,99,116,32,105,54,55,54,32,102,114,111,109,54,55,55,32,116,111,116,97,108,54,55,56,32,102,115,54,55,57,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,34),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,42,32,115,116,114,54,55,50,32,115,109,97,112,54,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,116,111,116,97,108,54,57,56,32,112,111,115,54,57,57,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,27),40,115,116,114,105,110,103,45,99,104,111,112,32,115,116,114,54,57,52,32,108,101,110,54,57,53,41,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,33),40,115,116,114,105,110,103,45,99,104,111,109,112,32,115,116,114,55,49,51,32,46,32,116,109,112,55,49,50,55,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,51,52,32,105,55,51,54,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,108,97,115,116,55,52,50,32,110,101,120,116,55,52,51,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,25),40,115,111,114,116,101,100,63,32,115,101,113,55,50,55,32,108,101,115,115,63,55,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,120,55,53,56,32,97,55,53,57,32,121,55,54,48,32,98,55,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,26),40,109,101,114,103,101,32,97,55,53,48,32,98,55,53,49,32,108,101,115,115,63,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,114,55,55,50,32,97,55,55,51,32,98,55,55,52,41,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,27),40,109,101,114,103,101,33,32,97,55,54,52,32,98,55,54,53,32,108,101,115,115,63,55,54,54,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,11),40,115,116,101,112,32,110,55,56,52,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,56,48,53,32,112,56,48,55,32,105,56,48,56,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,23),40,115,111,114,116,33,32,115,101,113,55,56,49,32,108,101,115,115,63,55,56,50,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,22),40,115,111,114,116,32,115,101,113,56,49,52,32,108,101,115,115,63,56,49,53,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,24),40,119,97,108,107,32,101,100,103,101,115,56,51,53,32,115,116,97,116,101,56,51,54,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,48),40,118,105,115,105,116,32,100,97,103,56,50,48,32,110,111,100,101,56,50,49,32,101,100,103,101,115,56,50,50,32,112,97,116,104,56,50,51,32,115,116,97,116,101,56,50,52,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,100,97,103,56,52,51,32,115,116,97,116,101,56,52,52,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,33),40,116,111,112,111,108,111,103,105,99,97,108,45,115,111,114,116,32,100,97,103,56,49,55,32,112,114,101,100,56,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,115,56,53,51,32,112,101,56,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,30),40,98,105,110,97,114,121,45,115,101,97,114,99,104,32,118,101,99,56,52,56,32,112,114,111,99,56,52,57,41,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,12),40,109,97,107,101,45,113,117,101,117,101,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,13),40,113,117,101,117,101,63,32,120,56,54,56,41,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,108,101,110,103,116,104,32,113,56,55,48,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,101,109,112,116,121,63,32,113,56,55,51,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,102,105,114,115,116,32,113,56,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,17),40,113,117,101,117,101,45,108,97,115,116,32,113,56,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,26),40,113,117,101,117,101,45,97,100,100,33,32,113,56,56,54,32,100,97,116,117,109,56,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,20),40,113,117,101,117,101,45,114,101,109,111,118,101,33,32,113,56,57,56,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,108,115,116,57,48,57,32,108,115,116,50,57,49,48,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,62,108,105,115,116,32,113,57,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,57,49,53,32,108,115,116,57,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,21),40,108,105,115,116,45,62,113,117,101,117,101,32,108,115,116,48,57,49,52,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,31),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,33,32,113,57,50,53,32,105,116,101,109,57,50,54,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,57,51,57,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,40),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,45,108,105,115,116,33,32,113,57,51,50,32,105,116,101,109,108,105,115,116,57,51,51,41};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word *av) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word *av) C_noret;
C_noret_decl(f_4280)
static void C_fcall f_4280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word *av) C_noret;
C_noret_decl(f_2984)
static void C_fcall f_2984(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word *av) C_noret;
C_noret_decl(f_4294)
static void C_fcall f_4294(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word *av) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word *av) C_noret;
C_noret_decl(f_2759)
static void C_fcall f_2759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word *av) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word *av) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word *av) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word *av) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word *av) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word *av) C_noret;
C_noret_decl(f_2964)
static void C_fcall f_2964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word *av) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word *av) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word *av) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word *av) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word *av) C_noret;
C_noret_decl(f_1447)
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word *av) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word *av) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word *av) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word *av) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word *av) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word *av) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word *av) C_noret;
C_noret_decl(f_4166)
static void C_fcall f_4166(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word *av) C_noret;
C_noret_decl(f_4238)
static void C_fcall f_4238(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word *av) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word *av) C_noret;
C_noret_decl(f_2287)
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word *av) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word *av) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word *av) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word *av) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word *av) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word *av) C_noret;
C_noret_decl(f_4094)
static void C_fcall f_4094(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word *av) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word *av) C_noret;
C_noret_decl(f_2256)
static void C_fcall f_2256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word *av) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word *av) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word *av) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word *av) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word *av) C_noret;
C_noret_decl(f_3429)
static void C_fcall f_3429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word *av) C_noret;
C_noret_decl(f_1979)
static void C_fcall f_1979(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word *av) C_noret;
C_noret_decl(f_1864)
static void C_fcall f_1864(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word *av) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word *av) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word *av) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word *av) C_noret;
C_noret_decl(f_1917)
static void C_fcall f_1917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_fcall f_1843(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1925)
static void C_fcall f_1925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word *av) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word *av) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word *av) C_noret;
C_noret_decl(f_3642)
static void C_fcall f_3642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word *av) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word *av) C_noret;
C_noret_decl(f_2145)
static void C_fcall f_2145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word *av) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word *av) C_noret;
C_noret_decl(f_3751)
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word *av) C_noret;
C_noret_decl(f_3527)
static void C_fcall f_3527(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word *av) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word *av) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word *av) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word *av) C_noret;
C_noret_decl(f_4704)
static C_word C_fcall f_4704(C_word t0);
C_noret_decl(f_2403)
static void C_fcall f_2403(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word *av) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word *av) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word *av) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word *av) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word *av) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word *av) C_noret;
C_noret_decl(f_2426)
static C_word C_fcall f_2426(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word *av) C_noret;
C_noret_decl(f_4032)
static void C_fcall f_4032(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word *av) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word *av) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word *av) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word *av) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word *av) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word *av) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word *av) C_noret;
C_noret_decl(f_4609)
static void C_fcall f_4609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word *av) C_noret;
C_noret_decl(f_2364)
static void C_fcall f_2364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3691)
static void C_fcall f_3691(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word *av) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word *av) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word *av) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word *av) C_noret;
C_noret_decl(f_3095)
static void C_fcall f_3095(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word *av) C_noret;
C_noret_decl(f_3815)
static void C_fcall f_3815(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word *av) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word *av) C_noret;
C_noret_decl(f_3939)
static void C_fcall f_3939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word *av) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word *av) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word *av) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word *av) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word *av) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word *av) C_noret;
C_noret_decl(f_1660)
static void C_fcall f_1660(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word *av) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word *av) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word *av) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word *av) C_noret;
C_noret_decl(f_4676)
static void C_fcall f_4676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word *av) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word *av) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word *av) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word *av) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word *av) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word *av) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word *av) C_noret;
C_noret_decl(f_3182)
static void C_fcall f_3182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word *av) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word *av) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word *av) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word *av) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word *av) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word *av) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word *av) C_noret;
C_noret_decl(f_1600)
static void C_fcall f_1600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word *av) C_noret;
C_noret_decl(f_3193)
static C_word C_fcall f_3193(C_word t0,C_word t1);
C_noret_decl(f_4538)
static void C_fcall f_4538(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word *av) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word *av) C_noret;
C_noret_decl(f_2607)
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2565)
static void C_fcall f_2565(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1764)
static void C_fcall f_1764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2359)
static void C_fcall f_2359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word *av) C_noret;
C_noret_decl(f_1706)
static C_word C_fcall f_1706(C_word t0,C_word t1);
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word *av) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word *av) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word *av) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word *av) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word *av) C_noret;
C_noret_decl(f_4586)
static void C_fcall f_4586(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word *av) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word *av) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word *av) C_noret;
C_noret_decl(f_1728)
static void C_fcall f_1728(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word *av) C_noret;
C_noret_decl(f_2531)
static void C_fcall f_2531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word *av) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word *av) C_noret;
C_noret_decl(f_3110)
static C_word C_fcall f_3110(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2095)
static void C_fcall f_2095(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word *av) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word *av) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word *av) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word *av) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word *av) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word *av) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externexport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word *av) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word *av) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word *av) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word *av) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word *av) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word *av) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word *av) C_noret;
C_noret_decl(f_2057)
static void C_fcall f_2057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word *av) C_noret;
C_noret_decl(f_1793)
static void C_fcall f_1793(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word *av) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word *av) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word *av) C_noret;
C_noret_decl(f_3396)
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3011)
static void C_fcall f_3011(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2856)
static void C_fcall f_2856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word *av) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word *av) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word *av) C_noret;
C_noret_decl(f_1565)
static void C_fcall f_1565(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word *av) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word *av) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word *av) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word *av) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word *av) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word *av) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word *av) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word *av) C_noret;
C_noret_decl(f_4445)
static void C_fcall f_4445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word *av) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word *av) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word *av) C_noret;
C_noret_decl(f_3237)
static void C_fcall f_3237(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word *av) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word *av) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word *av) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word *av) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word *av) C_noret;
C_noret_decl(f_1414)
static void C_fcall f_1414(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3469)
static void C_fcall f_3469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word *av) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word *av) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word *av) C_noret;

C_noret_decl(trf_4280)
static void C_ccall trf_4280(C_word c,C_word *av) C_noret;
static void C_ccall trf_4280(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4280(t0,t1);}

C_noret_decl(trf_2984)
static void C_ccall trf_2984(C_word c,C_word *av) C_noret;
static void C_ccall trf_2984(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2984(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4294)
static void C_ccall trf_4294(C_word c,C_word *av) C_noret;
static void C_ccall trf_4294(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4294(t0,t1,t2,t3);}

C_noret_decl(trf_2759)
static void C_ccall trf_2759(C_word c,C_word *av) C_noret;
static void C_ccall trf_2759(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2759(t0,t1);}

C_noret_decl(trf_2964)
static void C_ccall trf_2964(C_word c,C_word *av) C_noret;
static void C_ccall trf_2964(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2964(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1447)
static void C_ccall trf_1447(C_word c,C_word *av) C_noret;
static void C_ccall trf_1447(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1447(t0,t1,t2);}

C_noret_decl(trf_4166)
static void C_ccall trf_4166(C_word c,C_word *av) C_noret;
static void C_ccall trf_4166(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4166(t0,t1,t2,t3);}

C_noret_decl(trf_4238)
static void C_ccall trf_4238(C_word c,C_word *av) C_noret;
static void C_ccall trf_4238(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4238(t0,t1,t2,t3);}

C_noret_decl(trf_2287)
static void C_ccall trf_2287(C_word c,C_word *av) C_noret;
static void C_ccall trf_2287(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2287(t0,t1,t2);}

C_noret_decl(trf_4094)
static void C_ccall trf_4094(C_word c,C_word *av) C_noret;
static void C_ccall trf_4094(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_4094(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2256)
static void C_ccall trf_2256(C_word c,C_word *av) C_noret;
static void C_ccall trf_2256(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2256(t0,t1);}

C_noret_decl(trf_3429)
static void C_ccall trf_3429(C_word c,C_word *av) C_noret;
static void C_ccall trf_3429(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3429(t0,t1,t2);}

C_noret_decl(trf_1979)
static void C_ccall trf_1979(C_word c,C_word *av) C_noret;
static void C_ccall trf_1979(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1979(t0,t1,t2,t3);}

C_noret_decl(trf_1864)
static void C_ccall trf_1864(C_word c,C_word *av) C_noret;
static void C_ccall trf_1864(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1864(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1917)
static void C_ccall trf_1917(C_word c,C_word *av) C_noret;
static void C_ccall trf_1917(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1917(t0,t1);}

C_noret_decl(trf_1843)
static void C_ccall trf_1843(C_word c,C_word *av) C_noret;
static void C_ccall trf_1843(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1843(t0,t1,t2,t3);}

C_noret_decl(trf_1925)
static void C_ccall trf_1925(C_word c,C_word *av) C_noret;
static void C_ccall trf_1925(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1925(t0,t1,t2);}

C_noret_decl(trf_3642)
static void C_ccall trf_3642(C_word c,C_word *av) C_noret;
static void C_ccall trf_3642(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3642(t0,t1,t2);}

C_noret_decl(trf_2145)
static void C_ccall trf_2145(C_word c,C_word *av) C_noret;
static void C_ccall trf_2145(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2145(t0,t1,t2);}

C_noret_decl(trf_3751)
static void C_ccall trf_3751(C_word c,C_word *av) C_noret;
static void C_ccall trf_3751(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_3751(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3527)
static void C_ccall trf_3527(C_word c,C_word *av) C_noret;
static void C_ccall trf_3527(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3527(t0,t1,t2,t3);}

C_noret_decl(trf_2403)
static void C_ccall trf_2403(C_word c,C_word *av) C_noret;
static void C_ccall trf_2403(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2403(t0,t1,t2,t3);}

C_noret_decl(trf_4032)
static void C_ccall trf_4032(C_word c,C_word *av) C_noret;
static void C_ccall trf_4032(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4032(t0,t1,t2,t3);}

C_noret_decl(trf_4609)
static void C_ccall trf_4609(C_word c,C_word *av) C_noret;
static void C_ccall trf_4609(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4609(t0,t1);}

C_noret_decl(trf_2364)
static void C_ccall trf_2364(C_word c,C_word *av) C_noret;
static void C_ccall trf_2364(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2364(t0,t1,t2);}

C_noret_decl(trf_3691)
static void C_ccall trf_3691(C_word c,C_word *av) C_noret;
static void C_ccall trf_3691(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3691(t0,t1,t2,t3);}

C_noret_decl(trf_3095)
static void C_ccall trf_3095(C_word c,C_word *av) C_noret;
static void C_ccall trf_3095(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3095(t0,t1,t2,t3);}

C_noret_decl(trf_3815)
static void C_ccall trf_3815(C_word c,C_word *av) C_noret;
static void C_ccall trf_3815(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_3815(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3939)
static void C_ccall trf_3939(C_word c,C_word *av) C_noret;
static void C_ccall trf_3939(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3939(t0,t1,t2);}

C_noret_decl(trf_1660)
static void C_ccall trf_1660(C_word c,C_word *av) C_noret;
static void C_ccall trf_1660(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1660(t0,t1,t2);}

C_noret_decl(trf_4676)
static void C_ccall trf_4676(C_word c,C_word *av) C_noret;
static void C_ccall trf_4676(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4676(t0,t1);}

C_noret_decl(trf_3182)
static void C_ccall trf_3182(C_word c,C_word *av) C_noret;
static void C_ccall trf_3182(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3182(t0,t1);}

C_noret_decl(trf_1600)
static void C_ccall trf_1600(C_word c,C_word *av) C_noret;
static void C_ccall trf_1600(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1600(t0,t1,t2);}

C_noret_decl(trf_4538)
static void C_ccall trf_4538(C_word c,C_word *av) C_noret;
static void C_ccall trf_4538(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4538(t0,t1,t2,t3);}

C_noret_decl(trf_2607)
static void C_ccall trf_2607(C_word c,C_word *av) C_noret;
static void C_ccall trf_2607(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2607(t0,t1,t2);}

C_noret_decl(trf_2565)
static void C_ccall trf_2565(C_word c,C_word *av) C_noret;
static void C_ccall trf_2565(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_2565(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1764)
static void C_ccall trf_1764(C_word c,C_word *av) C_noret;
static void C_ccall trf_1764(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1764(t0,t1,t2);}

C_noret_decl(trf_2359)
static void C_ccall trf_2359(C_word c,C_word *av) C_noret;
static void C_ccall trf_2359(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2359(t0,t1);}

C_noret_decl(trf_4586)
static void C_ccall trf_4586(C_word c,C_word *av) C_noret;
static void C_ccall trf_4586(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4586(t0,t1,t2);}

C_noret_decl(trf_1728)
static void C_ccall trf_1728(C_word c,C_word *av) C_noret;
static void C_ccall trf_1728(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1728(t0,t1,t2);}

C_noret_decl(trf_2531)
static void C_ccall trf_2531(C_word c,C_word *av) C_noret;
static void C_ccall trf_2531(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2531(t0,t1,t2);}

C_noret_decl(trf_2095)
static void C_ccall trf_2095(C_word c,C_word *av) C_noret;
static void C_ccall trf_2095(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2095(t0,t1,t2);}

C_noret_decl(trf_2057)
static void C_ccall trf_2057(C_word c,C_word *av) C_noret;
static void C_ccall trf_2057(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2057(t0,t1);}

C_noret_decl(trf_1793)
static void C_ccall trf_1793(C_word c,C_word *av) C_noret;
static void C_ccall trf_1793(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1793(t0,t1,t2,t3);}

C_noret_decl(trf_3396)
static void C_ccall trf_3396(C_word c,C_word *av) C_noret;
static void C_ccall trf_3396(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_3396(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3011)
static void C_ccall trf_3011(C_word c,C_word *av) C_noret;
static void C_ccall trf_3011(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3011(t0,t1,t2);}

C_noret_decl(trf_2856)
static void C_ccall trf_2856(C_word c,C_word *av) C_noret;
static void C_ccall trf_2856(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2856(t0,t1);}

C_noret_decl(trf_1565)
static void C_ccall trf_1565(C_word c,C_word *av) C_noret;
static void C_ccall trf_1565(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1565(t0,t1,t2);}

C_noret_decl(trf_4445)
static void C_ccall trf_4445(C_word c,C_word *av) C_noret;
static void C_ccall trf_4445(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4445(t0,t1);}

C_noret_decl(trf_3237)
static void C_ccall trf_3237(C_word c,C_word *av) C_noret;
static void C_ccall trf_3237(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3237(t0,t1,t2,t3);}

C_noret_decl(trf_1414)
static void C_ccall trf_1414(C_word c,C_word *av) C_noret;
static void C_ccall trf_1414(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1414(t0,t1,t2);}

C_noret_decl(trf_3469)
static void C_ccall trf_3469(C_word c,C_word *av) C_noret;
static void C_ccall trf_3469(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3469(t0,t1);}

/* k1513 */
static void C_ccall f_1515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1515,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* compose in k1399 */
static void C_ccall f_1517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,3))){
C_save_and_reclaim((void*)f_1517,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=t4,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));
if(C_truep(C_i_nullp(t2))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=*((C_word*)lf[7]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t4)[1];
av2[3]=t2;
C_apply(4,av2);}}}

/* k4278 in binary-search in k1399 */
static void C_fcall f_4280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_4280,2,t0,t1);}
a=C_alloc(8);
t2=C_block_size(((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4294,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4294(t6,((C_word*)t0)[4],C_fix(0),t2);}
else{
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4401 in queue-first in k1399 */
static void C_ccall f_4403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4403,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[3],C_fix(0));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in string-split in k1399 */
static void C_fcall f_2984(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,4))){
C_save_and_reclaim_args((void *)trf_2984,5,t0,t1,t2,t3,t4);}
a=C_alloc(15);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[4]);
if(C_truep(t7)){
/* data-structures.scm:422: add */
t8=((C_word*)t0)[5];
f_2964(t8,t5,t4,t2,t3);}
else{
t8=((C_word*)((C_word*)t0)[3])[1];
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=(C_truep(t8)?t8:C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t5=C_subchar(((C_word*)t0)[6],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t7,a[12]=((C_word)li76),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_3011(t9,t1,C_fix(0));}}

/* k3493 in loop in collect in string-translate* in k1399 */
static void C_ccall f_3495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_3495,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_3469(t4,t3);}

/* loop in k4278 in binary-search in k1399 */
static void C_fcall f_4294(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_4294,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=C_fixnum_difference(t3,t2);
t5=C_fixnum_shift_right(t4,C_fix(1));
t6=C_fixnum_plus(t2,t5);
t7=t6;
t8=C_slot(((C_word*)((C_word*)t0)[2])[1],t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4304,a[2]=t1,a[3]=t7,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:785: proc */
t10=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t8;
((C_proc)C_fast_retrieve_proc(t10))(3,av2);}}

/* queue-last in k1399 */
static void C_ccall f_4414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4414,3,av);}
a=C_alloc(4);
t3=C_i_check_structure_2(t2,lf[104],lf[110]);
t4=C_slot(t2,C_fix(2));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4424,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(C_SCHEME_END_OF_LIST,t5);
if(C_truep(t7)){
/* data-structures.scm:830: ##sys#error */
t8=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=lf[110];
av2[3]=lf[111];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_slot(t5,C_fix(0));
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2992 in loop in string-split in k1399 */
static void C_ccall f_2994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2994,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?t2:C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2757 in substring=? in k1399 */
static void C_fcall f_2759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_2759,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[61]);
t3=C_i_check_exact_2(((C_word*)t0)[3],lf[61]);
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_substring_compare(((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* substring-ci=? in k1399 */
static void C_ccall f_2883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,6))){
C_save_and_reclaim((void*)f_2883,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_fix(0):C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(0):C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
if(C_truep(C_i_nullp(t12))){
/* data-structures.scm:400: ##sys#substring-ci=? */
t15=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t15;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t6;
av2[5]=t10;
av2[6]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(7,av2);}}
else{
t15=C_i_cdr(t12);
/* data-structures.scm:400: ##sys#substring-ci=? */
t16=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t16;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t6;
av2[5]=t10;
av2[6]=t14;
((C_proc)(void*)(*((C_word*)t16+1)))(7,av2);}}}

/* complement in k1399 */
static void C_ccall f_1505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1505,3,av);}
a=C_alloc(4);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* f_1507 in complement in k1399 */
static void C_ccall f_1507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,3))){
C_save_and_reclaim((void*)f_1507,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1515,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
C_apply(4,av2);}}

/* string-split in k1399 */
static void C_ccall f_2943(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +20,c,5))){
C_save_and_reclaim((void*)f_2943,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+20);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
t4=C_i_check_string_2(t2,lf[64]);
t5=C_i_nullp(t3);
t6=(C_truep(t5)?lf[65]:C_i_car(t3));
t7=t6;
t8=t3;
t9=C_u_i_length(t8);
t10=C_eqp(t9,C_fix(2));
t11=(C_truep(t10)?C_i_cadr(t3):C_SCHEME_FALSE);
t12=t11;
t13=C_block_size(t2);
t14=t13;
t15=C_i_check_string_2(t7,lf[64]);
t16=C_block_size(t7);
t17=t16;
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2964,a[2]=t19,a[3]=t2,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2984,a[2]=t14,a[3]=t19,a[4]=t12,a[5]=t20,a[6]=t2,a[7]=t17,a[8]=t22,a[9]=t7,a[10]=((C_word)li77),tmp=(C_word)a,a+=11,tmp));
t24=((C_word*)t22)[1];
f_2984(t24,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* f_1579 in loop in o in k1399 */
static void C_ccall f_1579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1579,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:87: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1565(t4,t3,((C_word*)t0)[4]);}

/* string-compare3-ci in k1399 */
static void C_ccall f_2718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2718,4,av);}
t4=C_i_check_string_2(t2,lf[59]);
t5=C_i_check_string_2(t3,lf[59]);
t6=C_block_size(t2);
t7=C_block_size(t3);
t8=C_fixnum_difference(t6,t7);
t9=C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=C_string_compare_case_insensitive(t2,t3,t10);
t12=C_eqp(t11,C_fix(0));
t13=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=(C_truep(t12)?t8:t11);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}

/* add in string-split in k1399 */
static void C_fcall f_2964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_2964,5,t0,t1,t2,t3,t4);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:415: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[66]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[66]+1);
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=t3;
tp(5,av2);}}

/* k2977 in add in string-split in k1399 */
static void C_ccall f_2979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_2979,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* list-of? in k1399 */
static void C_ccall f_1592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1592,3,av);}
a=C_alloc(4);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1594,a[2]=t2,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* f_1594 in list-of? in k1399 */
static void C_ccall f_1594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1594,3,av);}
a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1600,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1600(t6,t1,t2);}

/* k1588 in k1585 */
static void C_ccall f_1590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1590,2,av);}
/* data-structures.scm:87: h */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k4200 in walk in k4158 in k4096 in visit in topological-sort in k1399 */
static void C_ccall f_4202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4202,2,av);}
/* data-structures.scm:754: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4166(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop */
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1447,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1460,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:48: g86 */
t5=t3;{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}}

/* f_2089 in alist-update! in k1399 */
static void C_ccall f_2089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2089,4,av);}
a=C_alloc(8);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2095,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2095(t7,t1,t3);}

/* f_1441 in disjoin in k1399 */
static void C_ccall f_1441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1441,3,av);}
a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1447,a[2]=t4,a[3]=t2,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1447(t6,t1,((C_word*)t0)[2]);}

/* substring=? in k1399 */
static void C_ccall f_2786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,6))){
C_save_and_reclaim((void*)f_2786,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_fix(0):C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(0):C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
if(C_truep(C_i_nullp(t12))){
/* data-structures.scm:386: ##sys#substring=? */
t15=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t15;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t6;
av2[5]=t10;
av2[6]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(7,av2);}}
else{
t15=C_i_cdr(t12);
/* data-structures.scm:386: ##sys#substring=? */
t16=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t16;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t6;
av2[5]=t10;
av2[6]=t14;
((C_proc)(void*)(*((C_word*)t16+1)))(7,av2);}}}

/* k2019 in loop in compress in k1399 */
static void C_ccall f_2021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_2021,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* make-queue in k1399 */
static void C_ccall f_4359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_4359,2,av);}
a=C_alloc(5);
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_record4(&a,4,lf[104],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_fix(0));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4352 in binary-search in k1399 */
static void C_ccall f_4354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4354,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_4280(t3,t2);}

/* k4158 in k4096 in visit in topological-sort in k1399 */
static void C_ccall f_4160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,4))){C_save_and_reclaim((void *)f_4160,2,av);}
a=C_alloc(20);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],lf[90]);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
t5=C_a_i_cons(&a,2,t2,t4);
t6=((C_word*)t0)[3];
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t5,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t10,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li105),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_4166(t12,((C_word*)t0)[8],t1,t8);}

/* walk in k4158 in k4096 in visit in topological-sort in k1399 */
static void C_fcall f_4166(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,6))){
C_save_and_reclaim_args((void *)trf_4166,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4180,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t3);
/* data-structures.scm:751: alist-update! */
t6=*((C_word*)lf[29]+1);{
C_word av2[6];
av2[0]=t6;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[101];
av2[4]=t5;
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}
else{
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
/* data-structures.scm:755: visit */
t9=((C_word*)((C_word*)t0)[6])[1];
f_4094(t9,t7,((C_word*)t0)[7],t4,C_SCHEME_FALSE,t8,t3);}}

/* k1585 */
static void C_ccall f_1587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1587,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:87: g115 */
t3=t1;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* loop in topological-sort in k1399 */
static void C_fcall f_4238(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,6))){
C_save_and_reclaim_args((void *)trf_4238,4,t0,t1,t2,t3);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_cdr(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_i_caar(t2);
t8=t2;
t9=C_u_i_car(t8);
t10=C_u_i_cdr(t9);
/* data-structures.scm:765: visit */
t11=((C_word*)((C_word*)t0)[3])[1];
f_4094(t11,t6,t2,t7,t10,C_SCHEME_END_OF_LIST,t3);}}

/* f_3359 in string-translate in k1399 */
static void C_ccall f_3359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3359,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_eqp(t2,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4178 in walk in k4158 in k4096 in visit in topological-sort in k1399 */
static void C_ccall f_4180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4180,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_cons(&a,2,t1,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop */
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_2287,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_i_check_pair_2(t4,lf[40]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2312,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t4,C_fix(0));
/* data-structures.scm:247: cmp */
t8=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t8;
av2[1]=t6;
av2[2]=((C_word*)t0)[4];
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t8))(4,av2);}}
else{
/* data-structures.scm:250: error */
t3=*((C_word*)lf[37]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[40];
av2[3]=lf[41];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}}

/* f_2281 in alist-ref in k1399 */
static void C_ccall f_2281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2281,4,av);}
a=C_alloc(8);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2287,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2287(t7,t1,t3);}

/* k4302 in loop in k4278 in binary-search in k1399 */
static void C_ccall f_4304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4304,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t3=C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* data-structures.scm:787: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4294(t4,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[3]);}}
else{
t3=C_eqp(((C_word*)t0)[6],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* data-structures.scm:788: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4294(t4,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}}}}

/* k4257 in loop in topological-sort in k1399 */
static void C_ccall f_4259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4259,2,av);}
/* data-structures.scm:764: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4238(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k4076 in sort in k1399 */
static void C_ccall f_4078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4078,2,av);}
/* data-structures.scm:723: list->vector */
t2=*((C_word*)lf[87]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* alist-ref in k1399 */
static void C_ccall f_2240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +10,c,4))){
C_save_and_reclaim((void*)f_2240,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+10);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?*((C_word*)lf[30]+1):C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2256,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t16=C_eqp(*((C_word*)lf[31]+1),t7);
if(C_truep(t16)){
t17=t15;
f_2256(t17,*((C_word*)lf[32]+1));}
else{
t17=C_eqp(*((C_word*)lf[30]+1),t7);
if(C_truep(t17)){
t18=t15;
f_2256(t18,*((C_word*)lf[33]+1));}
else{
t18=C_eqp(*((C_word*)lf[34]+1),t7);
t19=t15;
f_2256(t19,(C_truep(t18)?*((C_word*)lf[35]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=t7,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp)));}}}

/* topological-sort in k1399 */
static void C_ccall f_4091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,7))){C_save_and_reclaim((void *)f_4091,4,av);}
a=C_alloc(17);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4094,a[2]=t3,a[3]=t5,a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t7=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4238,a[2]=t9,a[3]=t5,a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4238(t11,t1,t2,t7);}

/* visit in topological-sort in k1399 */
static void C_fcall f_4094(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_4094,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(10);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4098,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t4,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t8=C_i_car(t6);
/* data-structures.scm:734: alist-ref */
t9=*((C_word*)lf[40]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t7;
av2[2]=t3;
av2[3]=t8;
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}

/* k4096 in visit in topological-sort in k1399 */
static void C_ccall f_4098(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,5))){C_save_and_reclaim((void *)f_4098,2,av);}
a=C_alloc(12);
t2=C_eqp(t1,lf[90]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,lf[91],lf[92]);
t4=t3;
t5=C_a_i_cons(&a,2,lf[91],lf[93]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t6,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:741: reverse */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=C_eqp(t1,lf[101]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=((C_word*)t0)[6];
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t4;
f_4160(2,av2);}}
else{
/* data-structures.scm:747: alist-ref */
t6=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[9];
av2[4]=((C_word*)t0)[7];
av2[5]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}}}}

/* k2257 in k2254 in alist-ref in k1399 */
static void C_ccall f_2259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2259,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(t1)?C_slot(t1,C_fix(1)):((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2254 in alist-ref in k1399 */
static void C_fcall f_2256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_2256,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:251: aq */
t3=t1;{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3560 in k3556 in loop in string-chop in k1399 */
static void C_ccall f_3562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_3562,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1958 in loop in k1915 in join in k1399 */
static void C_ccall f_1960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1960,2,av);}
/* data-structures.scm:181: ##sys#append */
t2=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3556 in loop in string-chop in k1399 */
static void C_ccall f_3558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_3558,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[4]);
t5=C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* data-structures.scm:558: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3527(t6,t3,t4,t5);}

/* k4133 in k4145 in k4096 in visit in topological-sort in k1399 */
static void C_ccall f_4135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(31,c,2))){C_save_and_reclaim((void *)f_4135,2,av);}
a=C_alloc(31);
t2=C_a_i_cons(&a,2,lf[91],lf[95]);
t3=C_a_i_list(&a,8,((C_word*)t0)[2],lf[96],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,t2,lf[89]);
t4=C_a_i_record3(&a,3,lf[97],lf[98],t3);
/* data-structures.scm:736: ##sys#abort */
t5=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[6];
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3650 in doloop734 in sorted? in k1399 */
static void C_ccall f_3652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3652,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_nequalp(((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[5])[1];
f_3642(t3,((C_word*)t0)[2],t2);}}

/* loop in collect in string-translate* in k1399 */
static void C_fcall f_3429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,5))){
C_save_and_reclaim_args((void *)trf_3429,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_nullp(t2))){
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm:531: collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3396(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=C_i_car(t2);
t4=C_i_car(t3);
t5=C_i_string_length(t4);
t6=C_u_i_cdr(t3);
t7=C_fixnum_plus(((C_word*)t0)[2],t5);
t8=C_fixnum_less_or_equal_p(t7,((C_word*)t0)[7]);
t9=(C_truep(t8)?C_substring_compare(((C_word*)t0)[8],t4,((C_word*)t0)[2],C_fix(0),t5):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=C_fixnum_plus(((C_word*)t0)[2],t5);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3469,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[2],((C_word*)t0)[5]))){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[6],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:540: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[66]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[66]+1);
av2[1]=t13;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[2];
tp(5,av2);}}
else{
t13=t12;
f_3469(t13,C_SCHEME_UNDEFINED);}}
else{
t10=t2;
t11=C_u_i_cdr(t10);
/* data-structures.scm:545: loop */
t15=t1;
t16=t11;
t1=t15;
t2=t16;
goto loop;}}}

/* compress in k1399 */
static void C_ccall f_1970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1970,4,av);}
a=C_alloc(7);
t4=lf[26];
t5=C_i_check_list_2(t3,lf[25]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1979,a[2]=t7,a[3]=t4,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1979(t9,t1,t2,t3);}

/* loop in compress in k1399 */
static void C_fcall f_1979(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,5))){
C_save_and_reclaim_args((void *)trf_1979,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_slot(t2,C_fix(0)))){
t4=C_slot(t3,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(t2,C_fix(1));
t8=C_slot(t3,C_fix(1));
/* data-structures.scm:194: loop */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t3,C_fix(1));
/* data-structures.scm:195: loop */
t10=t1;
t11=t4;
t12=t5;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}
else{
/* data-structures.scm:192: ##sys#signal-hook */
t4=*((C_word*)lf[27]+1);{
C_word av2[6];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[28];
av2[3]=lf[25];
av2[4]=((C_word*)t0)[3];
av2[5]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}}
else{
/* data-structures.scm:190: ##sys#signal-hook */
t4=*((C_word*)lf[27]+1);{
C_word av2[6];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[28];
av2[3]=lf[25];
av2[4]=((C_word*)t0)[3];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}}}

/* k3422 in collect in string-translate* in k1399 */
static void C_ccall f_3424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3424,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
/* data-structures.scm:525: ##sys#fast-reverse */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[77]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[77]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
tp(3,av2);}}

/* doloop198 in loop in k1833 in chop in k1399 */
static void C_fcall f_1864(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_1864,5,t0,t1,t2,t3,t4);}
a=C_alloc(7);
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1878,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:167: reverse */
t7=*((C_word*)lf[19]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=C_slot(t3,C_fix(0));
t7=C_a_i_cons(&a,2,t6,t2);
t8=C_slot(t3,C_fix(1));
t9=C_fixnum_difference(t4,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t14=t9;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k2206 in k2184 in loop in alist-update in k1399 */
static void C_ccall f_2208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_2208,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2184 in loop in alist-update in k1399 */
static void C_ccall f_2186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2186,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[6],C_fix(0));
t3=C_slot(((C_word*)t0)[6],C_fix(1));
t4=C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:233: loop */
t8=((C_word*)((C_word*)t0)[7])[1];
f_2145(t8,t6,t7);}}

/* k1833 in chop in k1399 */
static void C_ccall f_1835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1835,2,av);}
a=C_alloc(7);
t2=C_i_length(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1843(t6,((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* join in k1399 */
static void C_ccall f_1913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_1913,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1917,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t3;
t6=t4;
f_1917(t6,C_u_i_car(t5));}
else{
t5=t4;
f_1917(t5,C_SCHEME_END_OF_LIST);}}

/* k1915 in join in k1399 */
static void C_fcall f_1917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_1917,2,t0,t1);}
a=C_alloc(7);
t2=t1;
t3=C_i_check_list_2(t2,lf[22]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1925,a[2]=t2,a[3]=t5,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1925(t7,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* loop in k1833 in chop in k1399 */
static void C_fcall f_1843(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,5))){
C_save_and_reclaim_args((void *)trf_1843,4,t0,t1,t2,t3);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list1(&a,1,t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1864,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li38),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1864(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[2]);}}}

/* loop in k1915 in join in k1399 */
static void C_fcall f_1925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1925,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t2,C_fix(1));
if(C_truep(C_i_nullp(t5))){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1960,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:181: loop */
t8=t6;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}
else{
/* data-structures.scm:175: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[24]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[24]+1);
av2[1]=t1;
av2[2]=t2;
tp(3,av2);}}}}

/* k3545 in loop in string-chop in k1399 */
static void C_ccall f_3547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_3547,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list1(&a,1,t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1824 in loop in flatten in k1399 */
static void C_ccall f_1826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_1826,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4145 in k4096 in visit in topological-sort in k1399 */
static void C_ccall f_4147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_4147,2,av);}
a=C_alloc(16);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
t4=t3;
t5=C_a_i_cons(&a,2,lf[91],lf[94]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:742: ##sys#get-call-chain */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[100]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[100]+1);
av2[1]=t7;
tp(2,av2);}}

/* doloop734 in sorted? in k1399 */
static void C_fcall f_3642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_3642,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_nequalp(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3652,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;{
C_word av2[2];
av2[0]=t5;
av2[1]=t3;
f_3652(2,av2);}}
else{
t5=C_i_vector_ref(((C_word*)t0)[4],t2);
t6=C_a_i_minus(&a,2,t2,C_fix(1));
t7=C_i_vector_ref(((C_word*)t0)[4],t6);
/* data-structures.scm:604: less? */
t8=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t8;
av2[1]=t4;
av2[2]=t5;
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t8))(4,av2);}}}

/* chop in k1399 */
static void C_ccall f_1828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1828,4,av);}
a=C_alloc(5);
t4=C_i_check_exact_2(t3,lf[18]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1835,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* data-structures.scm:157: ##sys#error */
t6=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[18];
av2[3]=lf[21];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_1835(2,av2);}}}

/* k3408 in collect in string-translate* in k1399 */
static void C_ccall f_3410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3410,2,av);}
/* data-structures.scm:523: ##sys#fragments->string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[76]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[76]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* loop in alist-update in k1399 */
static void C_fcall f_2145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_2145,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list1(&a,1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=C_slot(t4,C_fix(0));
/* data-structures.scm:229: cmp */
t7=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}
else{
/* data-structures.scm:228: error */
t5=*((C_word*)lf[37]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[36];
av2[3]=lf[38];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}
else{
/* data-structures.scm:224: error */
t3=*((C_word*)lf[37]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[36];
av2[3]=lf[39];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}}

/* string-chomp in k1399 */
static void C_ccall f_3576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_3576,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?lf[80]:C_i_car(t3));
t6=C_i_check_string_2(t2,lf[79]);
t7=C_i_check_string_2(t5,lf[79]);
t8=C_block_size(t2);
t9=C_block_size(t5);
t10=C_fixnum_difference(t8,t9);
t11=C_fixnum_greater_or_equal_p(t8,t9);
t12=(C_truep(t11)?C_substring_compare(t2,t5,t10,C_fix(0),t9):C_SCHEME_FALSE);
if(C_truep(t12)){
/* data-structures.scm:571: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[66]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[66]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(0);
av2[4]=t10;
tp(5,av2);}}
else{
t13=t2;
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}

/* ->string in k1399 */
static void C_ccall f_2473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2473,3,av);}
a=C_alloc(4);
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
/* data-structures.scm:291: symbol->string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
if(C_truep(C_charp(t2))){
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_string(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_numberp(t2))){
/* data-structures.scm:293: ##sys#number->string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[47]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[47]+1);
av2[1]=t1;
av2[2]=t2;
tp(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:295: open-output-string */
t4=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}}

/* loop in merge in k1399 */
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_3751,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3758,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm:627: less? */
t7=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}

/* k3756 in loop in merge in k1399 */
static void C_ccall f_3758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_3758,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* data-structures.scm:630: loop */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3751(t6,t2,((C_word*)t0)[3],((C_word*)t0)[4],t3,t5);}}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* data-structures.scm:634: loop */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3751(t6,t2,t3,t5,((C_word*)t0)[6],((C_word*)t0)[2]);}}}

/* loop in string-chop in k1399 */
static void C_fcall f_3527(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_3527,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_fixnum_less_or_equal_p(t2,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3547,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_plus(t3,t2);
/* data-structures.scm:557: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[66]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[66]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=t3;
av2[4]=t5;
tp(5,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3558,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_fixnum_plus(t3,((C_word*)t0)[2]);
/* data-structures.scm:558: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[66]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[66]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=t3;
av2[4]=t5;
tp(5,av2);}}}}

/* k2109 in loop */
static void C_ccall f_2111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2111,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:211: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2095(t3,((C_word*)t0)[2],t2);}}

/* string-chop in k1399 */
static void C_ccall f_3512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_3512,4,av);}
a=C_alloc(8);
t4=C_i_check_string_2(t2,lf[78]);
t5=C_i_check_exact_2(t3,lf[78]);
t6=C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3527,a[2]=t3,a[3]=t2,a[4]=t8,a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3527(t10,t1,t6,C_fix(0));}

/* sorted? in k1399 */
static void C_ccall f_3615(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_3615,4,av);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_vectorp(t2))){
t4=t2;
t5=C_block_size(t4);
t6=t5;
if(C_truep(C_fixnum_less_or_equal_p(t6,C_fix(1)))){
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3642,a[2]=t6,a[3]=t8,a[4]=t2,a[5]=t3,a[6]=((C_word)li94),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_3642(t10,t1,C_fix(1));}}
else{
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3691,a[2]=t8,a[3]=t3,a[4]=((C_word)li95),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3691(t10,t1,t4,t6);}}}

/* k1817 in loop in flatten in k1399 */
static void C_ccall f_1819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1819,2,av);}
/* data-structures.scm:151: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1793(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* doloop939 in k4671 in queue-push-back-list! in k1399 */
static C_word C_fcall f_4704(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
t2=C_slot(t1,C_fix(1));
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
return(t4);}
else{
t4=C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* rev-string-append in reverse-string-append in k1399 */
static void C_fcall f_2403(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_2403,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_string_length(t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2417,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
t11=C_fixnum_plus(t3,t7);
/* data-structures.scm:276: rev-string-append */
t13=t8;
t14=t10;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
/* data-structures.scm:283: make-string */
t4=*((C_word*)lf[44]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* merge in k1399 */
static void C_ccall f_3721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,6))){C_save_and_reclaim((void *)f_3721,5,av);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
t5=t3;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(t3))){
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_i_car(t2);
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_i_car(t3);
t9=t3;
t10=C_u_i_cdr(t9);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3751,a[2]=t12,a[3]=t4,a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_3751(t14,t1,t5,t7,t8,t10);}}}

/* k2381 in loop in k2357 in rassoc in k1399 */
static void C_ccall f_2383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2383,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:265: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2364(t3,((C_word*)t0)[2],t2);}}

/* k1876 in doloop198 in loop in k1833 in chop in k1399 */
static void C_ccall f_1878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1878,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[4]);
/* data-structures.scm:167: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1843(t5,t3,((C_word*)t0)[6],t4);}

/* k2415 in rev-string-append in reverse-string-append in k1399 */
static void C_ccall f_2417(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2417,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_i_string_length(t2);
t4=C_fixnum_difference(t3,((C_word*)t0)[2]);
t5=C_fixnum_difference(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=f_2426(t6,C_fix(0),t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k3713 in loop in sorted? in k1399 */
static void C_ccall f_3715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3715,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* data-structures.scm:611: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3691(t6,((C_word*)t0)[2],t3,t5);}}

/* k1880 in k1876 in doloop198 in loop in k1833 in chop in k1399 */
static void C_ccall f_1882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_1882,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k2415 in rev-string-append in reverse-string-append in k1399 */
static C_word C_fcall f_2426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_lessp(t1,((C_word*)t0)[2]))){
t3=C_i_string_ref(((C_word*)t0)[3],t1);
t4=C_i_string_set(((C_word*)t0)[4],t2,t3);
t5=C_fixnum_plus(t1,C_fix(1));
t6=C_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(((C_word*)t0)[4]);}}

/* sort in k1399 */
static void C_ccall f_4064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4064,4,av);}
a=C_alloc(7);
if(C_truep(C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4078,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4082,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:723: vector->list */
t6=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4089,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:724: append */
t5=*((C_word*)lf[88]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* doloop805 in k4028 in k4021 in sort! in k1399 */
static void C_fcall f_4032(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_4032,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=C_i_vector_set(((C_word*)t0)[2],t3,t4);
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_a_i_plus(&a,2,t3,C_fix(1));
t10=t1;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k4028 in k4021 in sort! in k1399 */
static void C_ccall f_4030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4030,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4032(t5,((C_word*)t0)[3],t1,C_fix(0));}

/* k4080 in sort in k1399 */
static void C_ccall f_4082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4082,2,av);}
/* data-structures.scm:723: sort! */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* queue-push-back-list! in k1399 */
static void C_ccall f_4663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4663,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[104],lf[118]);
t5=C_i_check_list_2(t3,lf[118]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4673,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
/* data-structures.scm:898: append */
t8=*((C_word*)lf[88]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t3;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k4087 in sort in k1399 */
static void C_ccall f_4089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4089,2,av);}
/* data-structures.scm:724: sort! */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* each in k1399 */
static void C_ccall f_1632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_1632,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(1));
t4=C_i_nullp(t3);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=(C_truep(t4)?C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1654,a[2]=t2,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp));
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k4021 in sort! in k1399 */
static void C_ccall f_4023(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4023,2,av);}
a=C_alloc(4);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:707: step */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3939(t4,t3,((C_word*)t0)[6]);}

/* f_1640 in each in k1399 */
static void C_ccall f_1640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1640,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4607 in doloop915 in list->queue in k1399 */
static void C_fcall f_4609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_4609,2,t0,t1);}
if(C_truep(t1)){
/* data-structures.scm:872: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[24]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[24]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[116];
tp(4,av2);}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[5])[1];
f_4586(t3,((C_word*)t0)[6],t2);}}

/* reverse-string-append in k1399 */
static void C_ccall f_2400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2400,3,av);}
a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t4,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
/* data-structures.scm:284: rev-string-append */
t6=((C_word*)t4)[1];
f_2403(t6,t1,t2,C_fix(0));}

/* loop in k2357 in rassoc in k1399 */
static void C_fcall f_2364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_2364,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_i_check_pair_2(t4,lf[42]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2383,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t4,C_fix(1));
/* data-structures.scm:263: tst */
t8=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t8;
av2[1]=t6;
av2[2]=((C_word*)t0)[4];
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t8))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in sorted? in k1399 */
static void C_fcall f_3691(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_3691,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3715,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=C_i_car(t3);
/* data-structures.scm:610: less? */
t7=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k1617 in loop */
static void C_ccall f_1619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1619,2,av);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* data-structures.scm:94: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1600(t3,((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3909 in k3888 in merge! in k1399 */
static void C_ccall f_3911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3911,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3776 in k3756 in loop in merge in k1399 */
static void C_ccall f_3778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_3778,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* alist-update in k1399 */
static void C_ccall f_2136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +9,c,3))){
C_save_and_reclaim((void*)f_2136,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+9);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t6=C_i_nullp(t5);
t7=(C_truep(t6)?*((C_word*)lf[30]+1):C_i_car(t5));
t8=t7;
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2145,a[2]=t2,a[3]=t3,a[4]=t10,a[5]=t8,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2145(t12,t1,t4);}

/* loop1 in string-intersperse in k1399 */
static void C_fcall f_3095(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,5))){
C_save_and_reclaim_args((void *)trf_3095,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep(C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[69];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=C_fixnum_difference(t3,((C_word*)t0)[4]);
/* data-structures.scm:446: ##sys#allocate-vector */
t6=*((C_word*)lf[70]+1);{
C_word av2[6];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=C_SCHEME_TRUE;
av2[4]=C_make_character(32);
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}}
else{
t4=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_slot(t2,C_fix(0));
t6=C_i_check_string_2(t5,lf[67]);
t7=C_slot(t2,C_fix(1));
t8=C_block_size(t5);
t9=C_fixnum_plus(((C_word*)t0)[4],t3);
t10=C_fixnum_plus(t8,t9);
/* data-structures.scm:461: loop1 */
t12=t1;
t13=t7;
t14=t10;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
/* data-structures.scm:463: ##sys#error-not-a-proper-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[24]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[24]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}}

/* k3947 in step in sort! in k1399 */
static void C_ccall f_3949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3949,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:682: step */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3939(t4,t3,t2);}

/* loop in merge! in k1399 */
static void C_fcall f_3815(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_3815,5,t0,t1,t2,t3,t4);}
a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3822,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t4);
t7=C_i_car(t3);
/* data-structures.scm:644: less? */
t8=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t8;
av2[1]=t5;
av2[2]=t6;
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t8))(4,av2);}}

/* merge! in k1399 */
static void C_ccall f_3812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_3812,5,av);}
a=C_alloc(13);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3815,a[2]=t6,a[3]=t4,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
if(C_truep(C_i_nullp(t2))){
t8=t3;
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(t3))){
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3890,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t9=C_i_car(t3);
t10=C_i_car(t2);
/* data-structures.scm:659: less? */
t11=t4;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t11;
av2[1]=t8;
av2[2]=t9;
av2[3]=t10;
((C_proc)C_fast_retrieve_proc(t11))(4,av2);}}}}

/* sort! in k1399 */
static void C_ccall f_3936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_3936,4,av);}
a=C_alloc(17);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3939,a[2]=t3,a[3]=t6,a[4]=t4,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
if(C_truep(C_i_vectorp(((C_word*)t4)[1]))){
t8=C_i_vector_length(((C_word*)t4)[1]);
t9=t8;
t10=((C_word*)t4)[1];
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4023,a[2]=t4,a[3]=t10,a[4]=t1,a[5]=t6,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:706: vector->list */
t12=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=((C_word*)t4)[1];
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t8=C_i_length(((C_word*)t4)[1]);
/* data-structures.scm:712: step */
t9=((C_word*)t6)[1];
f_3939(t9,t1,t8);}}

/* step in sort! in k1399 */
static void C_fcall f_3939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3939,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3949,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);{
C_word av2[4];
av2[0]=0;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(2);
C_quotient(4,av2);}}
else{
if(C_truep(C_i_nequalp(t2,C_fix(2)))){
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=t3;
t5=C_i_cadr(((C_word*)((C_word*)t0)[4])[1]);
t6=t5;
t7=((C_word*)((C_word*)t0)[4])[1];
t8=((C_word*)((C_word*)t0)[4])[1];
t9=C_u_i_cdr(t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[4])+1,C_u_i_cdr(t9));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3987,a[2]=t7,a[3]=t6,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:691: less? */
t12=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t12;
av2[1]=t11;
av2[2]=t6;
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t12))(4,av2);}}
else{
if(C_truep(C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[4])[1];
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t4);
t6=C_i_set_cdr(t3,C_SCHEME_END_OF_LIST);
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}}

/* k2310 in loop */
static void C_ccall f_2312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2312,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:249: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2287(t3,((C_word*)t0)[2],t2);}}

/* ##sys#substring-index in k1399 */
static void C_ccall f_2639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_2639,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2645,a[2]=t2,a[3]=t3,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:330: traverse */
f_2565(t1,t2,t3,t4,t5,lf[55]);}

/* k3802 in k3756 in loop in merge in k1399 */
static void C_ccall f_3804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_3804,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f_1654 in each in k1399 */
static void C_ccall f_1654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +7,c,3))){
C_save_and_reclaim((void*)f_1654,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+7);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1660,a[2]=t2,a[3]=t4,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1660(t6,t1,((C_word*)t0)[2]);}

/* k3950 in k3947 in step in sort! in k1399 */
static void C_ccall f_3952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3952,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_a_i_minus(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:684: step */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3939(t5,t4,t3);}

/* k3956 in k3950 in k3947 in step in sort! in k1399 */
static void C_ccall f_3958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3958,2,av);}
/* data-structures.scm:685: merge! */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* loop */
static void C_fcall f_1660(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_1660,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
t5=t4;
if(C_truep(C_i_nullp(t5))){{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[2];
C_apply(4,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);{
C_word av2[4];
av2[0]=0;
av2[1]=t6;
av2[2]=t3;
av2[3]=((C_word*)t0)[2];
C_apply(4,av2);}}}

/* a2653 in substring-index-ci in k1399 */
static void C_ccall f_2654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2654,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_substring_compare_case_insensitive(((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* substring-index in k1399 */
static void C_ccall f_2657(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_2657,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* data-structures.scm:342: ##sys#substring-index */
t5=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=C_i_car(t4);
/* data-structures.scm:342: ##sys#substring-index */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* k3820 in loop in merge! in k1399 */
static void C_ccall f_3822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3822,2,av);}
if(C_truep(t1)){
t2=C_i_set_cdr(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[4];
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_i_setslot(t5,C_fix(1),t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
/* data-structures.scm:649: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3815(t7,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[4],t6);}}
else{
t2=C_i_set_cdr(((C_word*)t0)[2],((C_word*)t0)[4]);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_i_setslot(t5,C_fix(1),t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* data-structures.scm:655: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3815(t7,((C_word*)t0)[5],((C_word*)t0)[4],t6,((C_word*)t0)[3]);}}}

/* k3985 in step in sort! in k1399 */
static void C_ccall f_3987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3987,2,av);}
if(C_truep(t1)){
t2=C_i_setslot(((C_word*)t0)[2],C_fix(0),((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_i_set_car(t3,((C_word*)t0)[4]);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_i_set_cdr(t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4674 in k4671 in queue-push-back-list! in k1399 */
static void C_fcall f_4676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_4676,2,t0,t1);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]);
t3=C_i_setslot(((C_word*)t0)[2],C_fix(2),t1);
t4=C_slot(((C_word*)t0)[2],C_fix(3));
t5=C_i_length(((C_word*)t0)[4]);
t6=C_fixnum_plus(t4,t5);
t7=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t7;
av2[1]=C_i_set_i_slot(((C_word*)t0)[2],C_fix(3),t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k4671 in queue-push-back-list! in k1399 */
static void C_ccall f_4673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4673,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t3;
f_4676(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4704,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_4676(t6,f_4704(t2));}}

/* k2618 in loop in traverse in k1399 */
static void C_ccall f_2620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2620,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm:322: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2607(t3,((C_word*)t0)[2],t2);}}

/* list->queue in k1399 */
static void C_ccall f_4565(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_4565,3,av);}
a=C_alloc(11);
t3=C_i_check_list_2(t2,lf[116]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_length(t6);
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_record4(&a,4,lf[104],t2,C_SCHEME_END_OF_LIST,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4586,a[2]=t7,a[3]=t2,a[4]=((C_word)li121),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4586(t9,t4,t2);}}

/* a2644 in substring-index in k1399 */
static void C_ccall f_2645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2645,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_substring_compare(((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* atom? in k1399 */
static void C_ccall f_1691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1691,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_not_pair_p(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* tail? in k1399 */
static void C_ccall f_1694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1694,4,av);}
a=C_alloc(4);
t4=C_i_check_list_2(t3,lf[14]);
t5=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1706,a[2]=t2,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=f_1706(t6,t3);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* ##sys#substring-index-ci in k1399 */
static void C_ccall f_2648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_2648,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2654,a[2]=t2,a[3]=t3,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:336: traverse */
f_2565(t1,t2,t3,t4,t5,lf[57]);}

/* instring in string-translate in k1399 */
static void C_fcall f_3182(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_3182,2,t1,t2);}
a=C_alloc(5);
t3=C_block_size(t2);
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3187,a[2]=t4,a[3]=t2,a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* f_3187 in instring in string-translate in k1399 */
static void C_ccall f_3187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3187,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_3193(t3,C_fix(0));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* queue-push-back! in k1399 */
static void C_ccall f_4623(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_4623,4,av);}
a=C_alloc(3);
t4=C_i_check_structure_2(t2,lf[104],lf[117]);
t5=C_slot(t2,C_fix(1));
t6=C_a_i_cons(&a,2,t3,t5);
t7=C_i_setslot(t2,C_fix(1),t6);
t8=C_slot(t2,C_fix(2));
t9=C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=(C_truep(t9)?C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED);
t11=C_slot(t2,C_fix(3));
t12=C_fixnum_plus(t11,C_fix(1));
t13=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_i_set_i_slot(t2,C_fix(3),t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}

/* queue-remove! in k1399 */
static void C_ccall f_4478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4478,3,av);}
a=C_alloc(5);
t3=C_i_check_structure_2(t2,lf[104],lf[113]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4488,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_eqp(C_SCHEME_END_OF_LIST,t5);
if(C_truep(t7)){
/* data-structures.scm:847: ##sys#error */
t8=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=lf[113];
av2[3]=lf[114];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t8=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
f_4488(2,av2);}}}

/* string-translate in k1399 */
static void C_ccall f_3179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +12,c,3))){
C_save_and_reclaim((void*)f_3179,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+12);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3182,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3217,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_charp(t3))){
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=t3,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
f_3217(2,av2);}}
else{
if(C_truep(C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3376,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* list->string */
t8=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t7=C_i_check_string_2(t3,lf[71]);
/* data-structures.scm:484: instring */
f_3182(t6,t3);}}}

/* k3891 in k3888 in merge! in k1399 */
static void C_ccall f_3893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3893,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3888 in merge! in k1399 */
static void C_ccall f_3890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3890,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[4];
t7=C_i_setslot(t5,C_fix(1),t6);
t8=((C_word*)t0)[2];
t9=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* data-structures.scm:662: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3815(t7,t2,((C_word*)t0)[2],((C_word*)t0)[4],t6);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[2];
t7=C_i_setslot(t5,C_fix(1),t6);
t8=((C_word*)t0)[4];
t9=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* data-structures.scm:667: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3815(t7,t2,((C_word*)t0)[4],t6,((C_word*)t0)[2]);}}}

/* k4486 in queue-remove! in k1399 */
static void C_ccall f_4488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4488,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=C_slot(((C_word*)t0)[3],C_fix(3));
t7=C_fixnum_difference(t6,C_fix(1));
t8=C_i_set_i_slot(((C_word*)t0)[3],C_fix(3),t7);
t9=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_slot(((C_word*)t0)[2],C_fix(0));
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}

/* loop */
static void C_fcall f_1600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1600,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_not_pair_p(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1619,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* data-structures.scm:94: pred */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}}}

/* k2554 in map-loop365 in conc in k1399 */
static void C_ccall f_2556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2556,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2531(t6,((C_word*)t0)[5],t5);}

/* loop */
static C_word C_fcall f_3193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(C_SCHEME_FALSE);}
else{
t2=C_subchar(((C_word*)t0)[3],t1);
t3=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
return(t1);}
else{
t4=C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}}

/* loop in queue->list in k1399 */
static void C_fcall f_4538(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_4538,4,t0,t1,t2,t3);}
a=C_alloc(3);
if(C_truep(C_i_nullp(t2))){
/* data-structures.scm:859: ##sys#fast-reverse */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[77]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[77]+1);
av2[1]=t1;
av2[2]=t3;
tp(3,av2);}}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_a_i_cons(&a,2,t5,t3);
/* data-structures.scm:860: loop */
t8=t1;
t9=t4;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* k1751 in loop in intersperse in k1399 */
static void C_ccall f_1753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_1753,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* butlast in k1399 */
static void C_ccall f_1755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1755,3,av);}
a=C_alloc(6);
t3=C_i_check_pair_2(t2,lf[16]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1764,a[2]=t5,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1764(t7,t1,t2);}

/* loop in traverse in k1399 */
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_2607,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greaterp(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2620,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:321: test */
t4=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}}

/* traverse in k1399 */
static void C_fcall f_2565(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,5))){
C_save_and_reclaim_args((void *)trf_2565,6,t1,t2,t3,t4,t5,t6);}
a=C_alloc(9);
t7=C_i_check_string_2(t2,t6);
t8=C_i_check_string_2(t3,t6);
t9=C_block_size(t3);
t10=C_block_size(t2);
t11=t10;
t12=C_fixnum_difference(t9,t11);
t13=t12;
t14=C_i_check_exact_2(t4,t6);
t15=C_fixnum_greater_or_equal_p(t4,C_fix(0));
t16=(C_truep(t15)?C_fixnum_greater_or_equal_p(t9,t4):C_SCHEME_FALSE);
if(C_truep(t16)){
t17=C_eqp(t11,C_fix(0));
if(C_truep(t17)){
t18=t1;{
C_word av2[2];
av2[0]=t18;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t13,C_fix(0)))){
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2607,a[2]=t13,a[3]=t19,a[4]=t5,a[5]=t11,a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t21=((C_word*)t19)[1];
f_2607(t21,t1,t4);}
else{
t18=t1;{
C_word av2[2];
av2[0]=t18;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}}}
else{
t17=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* data-structures.scm:323: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[53]+1));
C_word av2[6];
av2[0]=*((C_word*)lf[53]+1);
av2[1]=t1;
av2[2]=t17;
av2[3]=t6;
av2[4]=t4;
av2[5]=t9;
tp(6,av2);}}}

/* loop in butlast in k1399 */
static void C_fcall f_1764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_1764,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_slot(t2,C_fix(1));
t4=(C_truep(C_blockp(t3))?C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_slot(t2,C_fix(0));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1785,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:141: loop */
t9=t7;
t10=t3;
t1=t9;
t2=t10;
goto loop;}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k2357 in rassoc in k1399 */
static void C_fcall f_2359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_2359,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2364,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2364(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* rassoc in k1399 */
static void C_ccall f_2352(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_2352,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+5);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t5=C_i_check_list_2(t3,lf[42]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2359,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t4))){
t7=t4;
t8=t6;
f_2359(t8,C_u_i_car(t7));}
else{
t7=t6;
f_2359(t7,*((C_word*)lf[30]+1));}}

/* loop in tail? in k1399 */
static C_word C_fcall f_1706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;
loop:{}
if(C_truep(C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep(C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* substring-index-ci in k1399 */
static void C_ccall f_2672(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_2672,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* data-structures.scm:345: ##sys#substring-index-ci */
t5=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=C_i_car(t4);
/* data-structures.scm:345: ##sys#substring-index-ci */
t6=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* conc in k1399 */
static void C_ccall f_2518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +17,c,3))){
C_save_and_reclaim((void*)f_2518,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+17);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[45]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2529,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2531,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t6,a[6]=((C_word)li59),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2531(t12,t8,t2);}

/* k4574 in list->queue in k1399 */
static void C_ccall f_4576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_4576,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_u_i_length(t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[104],((C_word*)t0)[2],t1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2511 in k2508 in ->string in k1399 */
static void C_ccall f_2513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2513,2,av);}
/* data-structures.scm:297: get-output-string */
t2=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2508 in ->string in k1399 */
static void C_ccall f_2510(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2510,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:296: display */
t4=*((C_word*)lf[49]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* doloop915 in list->queue in k1399 */
static void C_fcall f_4586(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_4586,3,t0,t1,t2);}
a=C_alloc(12);
t3=C_slot(t2,C_fix(1));
t4=C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t2;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4596,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_blockp(t2);
t7=C_i_not(t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4609,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_4609(t9,t7);}
else{
t9=C_pairp(t2);
t10=t8;
f_4609(t10,C_i_not(t9));}}}

/* k2527 in conc in k1399 */
static void C_ccall f_2529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2529,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[52]+1);
av2[3]=t1;
C_apply(4,av2);}}

/* k3103 in loop1 in string-intersperse in k1399 */
static void C_ccall f_3105(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3105,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3110,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_3110(t3,((C_word*)t0)[5],C_fix(0));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* intersperse in k1399 */
static void C_ccall f_1722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1722,4,av);}
a=C_alloc(7);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1728,a[2]=t3,a[3]=t5,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1728(t7,t1,t2);}

/* loop in intersperse in k1399 */
static void C_fcall f_1728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1728,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_cdr(t2);
if(C_truep(C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:134: loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}}}

/* k1677 in loop */
static void C_ccall f_1679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1679,2,av);}
/* data-structures.scm:109: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1660(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* map-loop365 in conc in k1399 */
static void C_fcall f_2531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2531,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* data-structures.scm:301: g371 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* queue->list in k1399 */
static void C_ccall f_4525(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4525,3,av);}
a=C_alloc(6);
t3=C_i_check_structure_2(t2,lf[104],lf[115]);
t4=C_slot(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=t6,a[3]=((C_word)li119),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4538(t8,t1,t4,C_SCHEME_END_OF_LIST);}

/* any? in k1399 */
static void C_ccall f_1688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1688,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop2 in k3103 in loop1 in string-intersperse in k1399 */
static C_word C_fcall f_3110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_stack_overflow_check;
loop:{}
t3=C_slot(t1,C_fix(0));
t4=C_slot(t1,C_fix(1));
t5=C_block_size(t3);
t6=C_substring_copy(t3,((C_word*)t0)[2],C_fix(0),t5,t2);
t7=C_fixnum_plus(t2,t5);
if(C_truep(C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[2]);}
else{
t8=C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4],t7);
t9=C_fixnum_plus(t7,((C_word*)t0)[4]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* loop */
static void C_fcall f_2095(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_2095,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2111,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t4))){
t6=C_slot(t4,C_fix(0));
/* data-structures.scm:209: cmp */
t7=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}
else{
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_2111(2,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* string-compare3 in k1399 */
static void C_ccall f_2687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2687,4,av);}
t4=C_i_check_string_2(t2,lf[58]);
t5=C_i_check_string_2(t3,lf[58]);
t6=C_block_size(t2);
t7=C_block_size(t3);
t8=C_fixnum_difference(t6,t7);
t9=C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=C_string_compare(t2,t3,t10);
t12=C_eqp(t11,C_fix(0));
t13=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=(C_truep(t12)?t8:t11);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}

/* queue? in k1399 */
static void C_ccall f_4365(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4365,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[104]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3048 in scan in loop in string-split in k1399 */
static void C_ccall f_3050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3050,2,av);}
/* data-structures.scm:431: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_2984(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[4]);}

/* queue-length in k1399 */
static void C_ccall f_4371(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4371,3,av);}
t3=C_i_check_structure_2(t2,lf[104],lf[106]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* alist-update! in k1399 */
static void C_ccall f_2050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +10,c,4))){
C_save_and_reclaim((void*)f_2050,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+10);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t6=C_i_nullp(t5);
t7=(C_truep(t6)?*((C_word*)lf[30]+1):C_i_car(t5));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2057,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_eqp(*((C_word*)lf[31]+1),t8);
if(C_truep(t10)){
t11=t9;
f_2057(t11,*((C_word*)lf[32]+1));}
else{
t11=C_eqp(*((C_word*)lf[30]+1),t8);
if(C_truep(t11)){
t12=t9;
f_2057(t12,*((C_word*)lf[33]+1));}
else{
t12=C_eqp(*((C_word*)lf[34]+1),t8);
t13=t9;
f_2057(t13,(C_truep(t12)?*((C_word*)lf[35]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=t8,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp)));}}}

/* queue-empty? in k1399 */
static void C_ccall f_4380(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4380,3,av);}
t3=C_i_check_structure_2(t2,lf[104],lf[107]);
t4=C_slot(t2,C_fix(1));
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_eqp(C_SCHEME_END_OF_LIST,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* string-intersperse in k1399 */
static void C_ccall f_3077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +9,c,4))){
C_save_and_reclaim((void*)f_3077,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+9);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?lf[68]:C_i_car(t3));
t6=t5;
t7=C_i_check_list_2(t2,lf[67]);
t8=C_i_check_string_2(t6,lf[67]);
t9=C_block_size(t6);
t10=t9;
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3095,a[2]=t2,a[3]=t6,a[4]=t10,a[5]=t12,a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_3095(t14,t1,t2,C_fix(0));}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("data_2dstructures_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_data_2dstructures_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(772)){
C_save(t1);
C_rereclaim2(772*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,121);
lf[0]=C_h_intern(&lf[0],8,"identity");
lf[1]=C_h_intern(&lf[1],7,"conjoin");
lf[2]=C_h_intern(&lf[2],7,"disjoin");
lf[3]=C_h_intern(&lf[3],10,"constantly");
lf[4]=C_h_intern(&lf[4],4,"flip");
lf[5]=C_h_intern(&lf[5],10,"complement");
lf[6]=C_h_intern(&lf[6],7,"compose");
lf[7]=C_h_intern(&lf[7],6,"values");
lf[8]=C_h_intern(&lf[8],1,"o");
lf[9]=C_h_intern(&lf[9],8,"list-of\077");
lf[10]=C_h_intern(&lf[10],4,"each");
lf[11]=C_h_intern(&lf[11],19,"\003sysundefined-value");
lf[12]=C_h_intern(&lf[12],4,"any\077");
lf[13]=C_h_intern(&lf[13],5,"atom\077");
lf[14]=C_h_intern(&lf[14],5,"tail\077");
lf[15]=C_h_intern(&lf[15],11,"intersperse");
lf[16]=C_h_intern(&lf[16],7,"butlast");
lf[17]=C_h_intern(&lf[17],7,"flatten");
lf[18]=C_h_intern(&lf[18],4,"chop");
lf[19]=C_h_intern(&lf[19],7,"reverse");
lf[20]=C_h_intern(&lf[20],9,"\003syserror");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid numeric argument");
lf[22]=C_h_intern(&lf[22],4,"join");
lf[23]=C_h_intern(&lf[23],10,"\003sysappend");
lf[24]=C_h_intern(&lf[24],27,"\003syserror-not-a-proper-list");
lf[25]=C_h_intern(&lf[25],8,"compress");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000%bad argument type - not a proper list");
lf[27]=C_h_intern(&lf[27],15,"\003syssignal-hook");
lf[28]=C_h_intern(&lf[28],11,"\000type-error");
lf[29]=C_h_intern(&lf[29],13,"alist-update!");
lf[30]=C_h_intern(&lf[30],4,"eqv\077");
lf[31]=C_h_intern(&lf[31],3,"eq\077");
lf[32]=C_h_intern(&lf[32],4,"assq");
lf[33]=C_h_intern(&lf[33],4,"assv");
lf[34]=C_h_intern(&lf[34],6,"equal\077");
lf[35]=C_h_intern(&lf[35],5,"assoc");
lf[36]=C_h_intern(&lf[36],12,"alist-update");
lf[37]=C_h_intern(&lf[37],5,"error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\021bad argument type");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\021bad argument type");
lf[40]=C_h_intern(&lf[40],9,"alist-ref");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\021bad argument type");
lf[42]=C_h_intern(&lf[42],6,"rassoc");
lf[43]=C_h_intern(&lf[43],21,"reverse-string-append");
lf[44]=C_h_intern(&lf[44],11,"make-string");
lf[45]=C_h_intern(&lf[45],8,"->string");
lf[46]=C_h_intern(&lf[46],14,"symbol->string");
lf[47]=C_h_intern(&lf[47],18,"\003sysnumber->string");
lf[48]=C_h_intern(&lf[48],17,"get-output-string");
lf[49]=C_h_intern(&lf[49],7,"display");
lf[50]=C_h_intern(&lf[50],18,"open-output-string");
lf[51]=C_h_intern(&lf[51],4,"conc");
lf[52]=C_h_intern(&lf[52],13,"string-append");
lf[53]=C_h_intern(&lf[53],14,"\003syserror-hook");
lf[54]=C_h_intern(&lf[54],19,"\003syssubstring-index");
lf[55]=C_h_intern(&lf[55],15,"substring-index");
lf[56]=C_h_intern(&lf[56],22,"\003syssubstring-index-ci");
lf[57]=C_h_intern(&lf[57],18,"substring-index-ci");
lf[58]=C_h_intern(&lf[58],15,"string-compare3");
lf[59]=C_h_intern(&lf[59],18,"string-compare3-ci");
lf[60]=C_h_intern(&lf[60],15,"\003syssubstring=\077");
lf[61]=C_h_intern(&lf[61],11,"substring=\077");
lf[62]=C_h_intern(&lf[62],18,"\003syssubstring-ci=\077");
lf[63]=C_h_intern(&lf[63],14,"substring-ci=\077");
lf[64]=C_h_intern(&lf[64],12,"string-split");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\003\011\012 ");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_h_intern(&lf[67],18,"string-intersperse");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[70]=C_h_intern(&lf[70],19,"\003sysallocate-vector");
lf[71]=C_h_intern(&lf[71],16,"string-translate");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid translation destination");
lf[73]=C_h_intern(&lf[73],15,"\003sysmake-string");
lf[74]=C_h_intern(&lf[74],16,"\003syslist->string");
lf[75]=C_h_intern(&lf[75],17,"string-translate\052");
lf[76]=C_h_intern(&lf[76],21,"\003sysfragments->string");
lf[77]=C_h_intern(&lf[77],16,"\003sysfast-reverse");
lf[78]=C_h_intern(&lf[78],11,"string-chop");
lf[79]=C_h_intern(&lf[79],12,"string-chomp");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[81]=C_h_intern(&lf[81],7,"sorted\077");
lf[82]=C_h_intern(&lf[82],5,"merge");
lf[83]=C_h_intern(&lf[83],6,"merge!");
lf[84]=C_h_intern(&lf[84],5,"sort!");
lf[85]=C_h_intern(&lf[85],12,"vector->list");
lf[86]=C_h_intern(&lf[86],4,"sort");
lf[87]=C_h_intern(&lf[87],12,"list->vector");
lf[88]=C_h_intern(&lf[88],6,"append");
lf[89]=C_h_intern(&lf[89],16,"topological-sort");
lf[90]=C_h_intern(&lf[90],4,"grey");
lf[91]=C_h_intern(&lf[91],3,"exn");
lf[92]=C_h_intern(&lf[92],7,"message");
lf[93]=C_h_intern(&lf[93],9,"arguments");
lf[94]=C_h_intern(&lf[94],10,"call-chain");
lf[95]=C_h_intern(&lf[95],8,"location");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\016cycle detected");
lf[97]=C_h_intern(&lf[97],9,"condition");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\003\000\000\002\376\001\000\000\007runtime\376\003\000\000\002\376\001\000\000\005cycle\376\377\016");
lf[99]=C_h_intern(&lf[99],9,"\003sysabort");
lf[100]=C_h_intern(&lf[100],18,"\003sysget-call-chain");
lf[101]=C_h_intern(&lf[101],5,"black");
lf[102]=C_h_intern(&lf[102],13,"binary-search");
lf[103]=C_h_intern(&lf[103],10,"make-queue");
lf[104]=C_h_intern(&lf[104],5,"queue");
lf[105]=C_h_intern(&lf[105],6,"queue\077");
lf[106]=C_h_intern(&lf[106],12,"queue-length");
lf[107]=C_h_intern(&lf[107],12,"queue-empty\077");
lf[108]=C_h_intern(&lf[108],11,"queue-first");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[110]=C_h_intern(&lf[110],10,"queue-last");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[112]=C_h_intern(&lf[112],10,"queue-add!");
lf[113]=C_h_intern(&lf[113],13,"queue-remove!");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[115]=C_h_intern(&lf[115],11,"queue->list");
lf[116]=C_h_intern(&lf[116],11,"list->queue");
lf[117]=C_h_intern(&lf[117],16,"queue-push-back!");
lf[118]=C_h_intern(&lf[118],21,"queue-push-back-list!");
lf[119]=C_h_intern(&lf[119],17,"register-feature!");
lf[120]=C_h_intern(&lf[120],15,"data-structures");
C_register_lf2(lf,121,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm:33: register-feature! */
t3=*((C_word*)lf[119]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[120];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* f_1487 in constantly in k1399 */
static void C_ccall f_1487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1487,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1783 in loop in butlast in k1399 */
static void C_ccall f_1785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_1785,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* flatten in k1399 */
static void C_ccall f_1787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,4))){
C_save_and_reclaim((void*)f_1787,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1793,a[2]=t4,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1793(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* f_1489 in constantly in k1399 */
static void C_ccall f_1489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1489,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k3374 in string-translate in k1399 */
static void C_ccall f_3376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3376,2,av);}
/* data-structures.scm:481: instring */
f_3182(((C_word*)t0)[3],t1);}

/* k2058 in k2055 in alist-update! in k1399 */
static void C_ccall f_2060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_2060,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_setslot(t1,C_fix(1),((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* queue-first in k1399 */
static void C_ccall f_4393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4393,3,av);}
a=C_alloc(4);
t3=C_i_check_structure_2(t2,lf[104],lf[108]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4403,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(C_SCHEME_END_OF_LIST,t5);
if(C_truep(t7)){
/* data-structures.scm:822: ##sys#error */
t8=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=lf[108];
av2[3]=lf[109];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_slot(t5,C_fix(0));
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2055 in alist-update! in k1399 */
static void C_fcall f_2057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_2057,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:212: aq */
t3=t1;{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* flip in k1399 */
static void C_ccall f_1497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1497,3,av);}
a=C_alloc(4);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1499,a[2]=t2,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop in flatten in k1399 */
static void C_fcall f_1793(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_1793,4,t0,t1,t2,t3);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=C_slot(t2,C_fix(1));
if(C_truep(C_i_listp(t5))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:151: loop */
t9=t7;
t10=t6;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1826,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:152: loop */
t9=t7;
t10=t6;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* f_1499 in flip in k1399 */
static void C_ccall f_1499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1499,4,av);}
/* data-structures.scm:61: proc */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}

/* ##sys#substring-ci=? in k1399 */
static void C_ccall f_2846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2846,7,av);}
a=C_alloc(7);
t7=C_i_check_string_2(t2,lf[63]);
t8=C_i_check_string_2(t3,lf[63]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2856,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2856(t10,t6);}
else{
t10=C_block_size(t2);
t11=C_fixnum_difference(t10,t4);
t12=C_block_size(t3);
t13=C_fixnum_difference(t12,t5);
t14=t9;
f_2856(t14,C_i_fixnum_min(t11,t13));}}

/* k1458 in loop */
static void C_ccall f_1460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1460,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm:53: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1447(t3,((C_word*)t0)[2],t2);}}

/* collect in string-translate* in k1399 */
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,4))){
C_save_and_reclaim_args((void *)trf_3396,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(15);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3410,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_greaterp(t2,t3))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3424,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:527: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[66]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[66]+1);
av2[1]=t8;
av2[2]=((C_word*)t0)[3];
av2[3]=t3;
av2[4]=t2;
tp(5,av2);}}
else{
t8=((C_word*)t6)[1];
/* data-structures.scm:525: ##sys#fast-reverse */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[77]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[77]+1);
av2[1]=t7;
av2[2]=t8;
tp(3,av2);}}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3429,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t6,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=t8,a[10]=((C_word)li88),tmp=(C_word)a,a+=11,tmp));
t10=((C_word*)t8)[1];
f_3429(t10,t1,((C_word*)t0)[5]);}}

/* scan in loop in string-split in k1399 */
static void C_fcall f_3011(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_3011,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm:427: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2984(t4,t1,t3,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t3=C_subchar(((C_word*)t0)[7],t2);
t4=C_eqp(((C_word*)t0)[8],t3);
if(C_truep(t4)){
t5=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t6=t5;
t7=C_fixnum_greaterp(((C_word*)t0)[3],((C_word*)t0)[6]);
t8=(C_truep(t7)?t7:((C_word*)t0)[9]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:431: add */
t10=((C_word*)t0)[10];
f_2964(t10,t9,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
/* data-structures.scm:432: loop */
t9=((C_word*)((C_word*)t0)[4])[1];
f_2984(t9,t1,t6,((C_word*)t0)[5],t6);}}
else{
t5=C_fixnum_plus(t2,C_fix(1));
/* data-structures.scm:433: scan */
t11=t1;
t12=t5;
t1=t11;
t2=t12;
goto loop;}}}

/* k2854 in substring-ci=? in k1399 */
static void C_fcall f_2856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_2856,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[63]);
t3=C_i_check_exact_2(((C_word*)t0)[3],lf[63]);
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_substring_compare_case_insensitive(((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4594 in doloop915 in list->queue in k1399 */
static void C_ccall f_4596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4596,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4586(t3,((C_word*)t0)[4],t2);}

/* constantly in k1399 */
static void C_ccall f_1476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_1476,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t3=t2;
t4=C_u_i_length(t3);
t5=C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=C_i_car(t2);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1487,a[2]=t7,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=t2,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* string-translate* in k1399 */
static void C_ccall f_3384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,6))){C_save_and_reclaim((void *)f_3384,4,av);}
a=C_alloc(9);
t4=C_i_check_string_2(t2,lf[75]);
t5=C_i_check_list_2(t3,lf[75]);
t6=C_block_size(t2);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3396,a[2]=t7,a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li89),tmp=(C_word)a,a+=7,tmp));
/* data-structures.scm:546: collect */
t11=((C_word*)t9)[1];
f_3396(t11,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in o in k1399 */
static void C_fcall f_1565(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1565,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t2,C_fix(1));
t6=t5;
if(C_truep(C_i_nullp(t6))){
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1579,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp);
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* a1533 */
static void C_ccall f_1534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1534,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1542,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
C_apply(4,av2);}}

/* k4422 in queue-last in k1399 */
static void C_ccall f_4424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4424,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[3],C_fix(0));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3215 in string-translate in k1399 */
static void C_ccall f_3217(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3217,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t4=C_slot(((C_word*)t0)[4],C_fix(0));
if(C_truep(C_charp(t4))){
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
f_3220(2,av2);}}
else{
if(C_truep(C_i_pairp(t4))){
/* list->string */
t5=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=C_i_check_string_2(t4,lf[71]);
t6=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t4;
f_3220(2,av2);}}}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_3220(2,av2);}}}

/* k3230 in k3218 in k3215 in string-translate in k1399 */
static void C_ccall f_3232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_3232,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li85),tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3237(t6,((C_word*)t0)[7],C_fix(0),C_fix(0));}

/* queue-add! in k1399 */
static void C_ccall f_4435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4435,4,av);}
a=C_alloc(8);
t4=C_i_check_structure_2(t2,lf[104],lf[112]);
t5=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4445,a[2]=t2,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=C_slot(t2,C_fix(1));
t9=C_eqp(C_SCHEME_END_OF_LIST,t8);
if(C_truep(t9)){
t10=t7;
f_4445(t10,C_i_setslot(t2,C_fix(1),t6));}
else{
t10=C_slot(t2,C_fix(2));
t11=t7;
f_4445(t11,C_i_setslot(t10,C_fix(1),t6));}}

/* disjoin in k1399 */
static void C_ccall f_1439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_1439,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1441,a[2]=t2,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* o in k1399 */
static void C_ccall f_1553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,3))){
C_save_and_reclaim((void*)f_1553,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=*((C_word*)lf[0]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1565,a[2]=t4,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1565(t6,t1,t2);}}

/* k1428 in loop */
static void C_ccall f_1430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1430,2,av);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* data-structures.scm:46: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1414(t3,((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4443 in queue-add! in k1399 */
static void C_fcall f_4445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_4445,2,t0,t1);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(2),((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=C_fixnum_plus(t3,C_fix(1));
t5=C_i_set_i_slot(((C_word*)t0)[2],C_fix(3),t4);
t6=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k3218 in k3215 in string-translate in k1399 */
static void C_ccall f_3220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_3220,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_i_stringp(t2);
t4=(C_truep(t3)?C_block_size(t2):C_SCHEME_FALSE);
t5=t4;
t6=C_i_check_string_2(((C_word*)t0)[2],lf[71]);
t7=C_block_size(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3232,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t5,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* ##sys#make-string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[73]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[73]+1);
av2[1]=t9;
av2[2]=t8;
av2[3]=C_make_character(32);
tp(4,av2);}}

/* f_1408 in conjoin in k1399 */
static void C_ccall f_1408(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1408,3,av);}
a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1414,a[2]=t4,a[3]=t2,a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1414(t6,t1,((C_word*)t0)[2]);}

/* conjoin in k1399 */
static void C_ccall f_1406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_1406,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1408,a[2]=t2,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop in k3230 in k3218 in k3215 in string-translate in k1399 */
static void C_fcall f_3237(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_3237,4,t0,t1,t2,t3);}
a=C_alloc(10);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
if(C_truep(C_fixnum_lessp(t3,t2))){
/* data-structures.scm:500: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[66]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[66]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=t3;
tp(5,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_subchar(((C_word*)t0)[4],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* data-structures.scm:503: from */
t6=((C_word*)t0)[8];{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k1399 */
static void C_ccall f_1401(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(188,c,7))){C_save_and_reclaim((void *)f_1401,2,av);}
a=C_alloc(188);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! identity ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[1]+1 /* (set! conjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[2]+1 /* (set! disjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[3]+1 /* (set! constantly ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[4]+1 /* (set! flip ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[5]+1 /* (set! complement ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[6]+1 /* (set! compose ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1517,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[8]+1 /* (set! o ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1553,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[9]+1 /* (set! list-of? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1592,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[10]+1 /* (set! each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1632,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[12]+1 /* (set! any? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[13]+1 /* (set! atom? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1691,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[14]+1 /* (set! tail? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[15]+1 /* (set! intersperse ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1722,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[16]+1 /* (set! butlast ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[17]+1 /* (set! flatten ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1787,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[18]+1 /* (set! chop ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1828,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[22]+1 /* (set! join ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[25]+1 /* (set! compress ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[29]+1 /* (set! alist-update! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2050,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate2((C_word*)lf[36]+1 /* (set! alist-update ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[40]+1 /* (set! alist-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2240,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2((C_word*)lf[42]+1 /* (set! rassoc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2352,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate2((C_word*)lf[43]+1 /* (set! reverse-string-append ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate2((C_word*)lf[45]+1 /* (set! ->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2473,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate2((C_word*)lf[51]+1 /* (set! conc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2518,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2565,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate2((C_word*)lf[54]+1 /* (set! ##sys#substring-index ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2639,a[2]=t28,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp));
t30=C_mutate2((C_word*)lf[56]+1 /* (set! ##sys#substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2648,a[2]=t28,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t31=C_mutate2((C_word*)lf[55]+1 /* (set! substring-index ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2657,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate2((C_word*)lf[57]+1 /* (set! substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[58]+1 /* (set! string-compare3 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2687,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[59]+1 /* (set! string-compare3-ci ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[60]+1 /* (set! ##sys#substring=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[61]+1 /* (set! substring=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2786,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[62]+1 /* (set! ##sys#substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[63]+1 /* (set! substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate2((C_word*)lf[64]+1 /* (set! string-split ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate2((C_word*)lf[67]+1 /* (set! string-intersperse ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate2((C_word*)lf[71]+1 /* (set! string-translate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3179,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate2((C_word*)lf[75]+1 /* (set! string-translate* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate2((C_word*)lf[78]+1 /* (set! string-chop ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3512,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate2((C_word*)lf[79]+1 /* (set! string-chomp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate2((C_word*)lf[81]+1 /* (set! sorted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate2((C_word*)lf[82]+1 /* (set! merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate2((C_word*)lf[83]+1 /* (set! merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3812,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate2((C_word*)lf[84]+1 /* (set! sort! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3936,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate2((C_word*)lf[86]+1 /* (set! sort ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate2((C_word*)lf[89]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4091,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate2((C_word*)lf[102]+1 /* (set! binary-search ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4276,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate2((C_word*)lf[103]+1 /* (set! make-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4359,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate2((C_word*)lf[105]+1 /* (set! queue? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4365,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate2((C_word*)lf[106]+1 /* (set! queue-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4371,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate2((C_word*)lf[107]+1 /* (set! queue-empty? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4380,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate2((C_word*)lf[108]+1 /* (set! queue-first ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4393,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate2((C_word*)lf[110]+1 /* (set! queue-last ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4414,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate2((C_word*)lf[112]+1 /* (set! queue-add! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4435,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate2((C_word*)lf[113]+1 /* (set! queue-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4478,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate2((C_word*)lf[115]+1 /* (set! queue->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4525,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate2((C_word*)lf[116]+1 /* (set! list->queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4565,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate2((C_word*)lf[117]+1 /* (set! queue-push-back! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4623,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate2((C_word*)lf[118]+1 /* (set! queue-push-back-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4663,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t64=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t64;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t64+1)))(2,av2);}}

/* rec in compose in k1399 */
static void C_ccall f_1520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_1520,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+6);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* identity in k1399 */
static void C_ccall f_1403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1403,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##sys#substring=? in k1399 */
static void C_ccall f_2749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2749,7,av);}
a=C_alloc(7);
t7=C_i_check_string_2(t2,lf[61]);
t8=C_i_check_string_2(t3,lf[61]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2759,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2759(t10,t6);}
else{
t10=C_block_size(t2);
t11=C_fixnum_difference(t10,t4);
t12=C_block_size(t3);
t13=C_fixnum_difference(t12,t5);
t14=t9;
f_2759(t14,C_i_fixnum_min(t11,t13));}}

/* f_1528 in rec in compose in k1399 */
static void C_ccall f_1528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,3))){
C_save_and_reclaim((void*)f_1528,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1534,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:72: call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[4];
C_call_with_values(4,av2);}}

/* loop */
static void C_fcall f_1414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1414,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1430,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:41: g74 */
t6=t4;{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}}

/* k3467 in loop in collect in string-translate* in k1399 */
static void C_fcall f_3469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,5))){
C_save_and_reclaim_args((void *)trf_3469,2,t0,t1);}
a=C_alloc(3);
t2=C_i_string_length(((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);
/* data-structures.scm:541: collect */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3396(t5,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[7],t3,t4);}

/* k3254 in loop in k3230 in k3218 in k3215 in string-translate in k1399 */
static void C_ccall f_3256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_3256,2,av);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_charp(((C_word*)t0)[2]))){
t2=C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:510: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3237(t5,((C_word*)t0)[7],t3,t4);}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[8]))){
/* data-structures.scm:512: ##sys#error */
t2=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[7];
av2[2]=lf[71];
av2[3]=lf[72];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
t2=C_subchar(((C_word*)t0)[2],t1);
t3=C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:515: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3237(t6,((C_word*)t0)[7],t4,t5);}}}
else{
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* data-structures.scm:507: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3237(t3,((C_word*)t0)[7],t2,((C_word*)t0)[4]);}}
else{
t2=C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[9]);
t3=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:506: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3237(t5,((C_word*)t0)[7],t3,t4);}}

/* k1540 in a1533 */
static void C_ccall f_1542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1542,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
C_apply(4,av2);}}

/* binary-search in k1399 */
static void C_ccall f_4276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_4276,4,av);}
a=C_alloc(11);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4280,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4354,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:777: list->vector */
t7=*((C_word*)lf[87]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t4)[1];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t5;
f_4280(t6,C_i_check_vector_2(((C_word*)t4)[1],lf[102]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[218] = {
{"f_1515:data_2dstructures_2escm",(void*)f_1515},
{"f_1517:data_2dstructures_2escm",(void*)f_1517},
{"f_4280:data_2dstructures_2escm",(void*)f_4280},
{"f_4403:data_2dstructures_2escm",(void*)f_4403},
{"f_2984:data_2dstructures_2escm",(void*)f_2984},
{"f_3495:data_2dstructures_2escm",(void*)f_3495},
{"f_4294:data_2dstructures_2escm",(void*)f_4294},
{"f_4414:data_2dstructures_2escm",(void*)f_4414},
{"f_2994:data_2dstructures_2escm",(void*)f_2994},
{"f_2759:data_2dstructures_2escm",(void*)f_2759},
{"f_2883:data_2dstructures_2escm",(void*)f_2883},
{"f_1505:data_2dstructures_2escm",(void*)f_1505},
{"f_1507:data_2dstructures_2escm",(void*)f_1507},
{"f_2943:data_2dstructures_2escm",(void*)f_2943},
{"f_1579:data_2dstructures_2escm",(void*)f_1579},
{"f_2718:data_2dstructures_2escm",(void*)f_2718},
{"f_2964:data_2dstructures_2escm",(void*)f_2964},
{"f_2979:data_2dstructures_2escm",(void*)f_2979},
{"f_1592:data_2dstructures_2escm",(void*)f_1592},
{"f_1594:data_2dstructures_2escm",(void*)f_1594},
{"f_1590:data_2dstructures_2escm",(void*)f_1590},
{"f_4202:data_2dstructures_2escm",(void*)f_4202},
{"f_1447:data_2dstructures_2escm",(void*)f_1447},
{"f_2089:data_2dstructures_2escm",(void*)f_2089},
{"f_1441:data_2dstructures_2escm",(void*)f_1441},
{"f_2786:data_2dstructures_2escm",(void*)f_2786},
{"f_2021:data_2dstructures_2escm",(void*)f_2021},
{"f_4359:data_2dstructures_2escm",(void*)f_4359},
{"f_4354:data_2dstructures_2escm",(void*)f_4354},
{"f_4160:data_2dstructures_2escm",(void*)f_4160},
{"f_4166:data_2dstructures_2escm",(void*)f_4166},
{"f_1587:data_2dstructures_2escm",(void*)f_1587},
{"f_4238:data_2dstructures_2escm",(void*)f_4238},
{"f_3359:data_2dstructures_2escm",(void*)f_3359},
{"f_4180:data_2dstructures_2escm",(void*)f_4180},
{"f_2287:data_2dstructures_2escm",(void*)f_2287},
{"f_2281:data_2dstructures_2escm",(void*)f_2281},
{"f_4304:data_2dstructures_2escm",(void*)f_4304},
{"f_4259:data_2dstructures_2escm",(void*)f_4259},
{"f_4078:data_2dstructures_2escm",(void*)f_4078},
{"f_2240:data_2dstructures_2escm",(void*)f_2240},
{"f_4091:data_2dstructures_2escm",(void*)f_4091},
{"f_4094:data_2dstructures_2escm",(void*)f_4094},
{"f_4098:data_2dstructures_2escm",(void*)f_4098},
{"f_2259:data_2dstructures_2escm",(void*)f_2259},
{"f_2256:data_2dstructures_2escm",(void*)f_2256},
{"f_3562:data_2dstructures_2escm",(void*)f_3562},
{"f_1960:data_2dstructures_2escm",(void*)f_1960},
{"f_3558:data_2dstructures_2escm",(void*)f_3558},
{"f_4135:data_2dstructures_2escm",(void*)f_4135},
{"f_3652:data_2dstructures_2escm",(void*)f_3652},
{"f_3429:data_2dstructures_2escm",(void*)f_3429},
{"f_1970:data_2dstructures_2escm",(void*)f_1970},
{"f_1979:data_2dstructures_2escm",(void*)f_1979},
{"f_3424:data_2dstructures_2escm",(void*)f_3424},
{"f_1864:data_2dstructures_2escm",(void*)f_1864},
{"f_2208:data_2dstructures_2escm",(void*)f_2208},
{"f_2186:data_2dstructures_2escm",(void*)f_2186},
{"f_1835:data_2dstructures_2escm",(void*)f_1835},
{"f_1913:data_2dstructures_2escm",(void*)f_1913},
{"f_1917:data_2dstructures_2escm",(void*)f_1917},
{"f_1843:data_2dstructures_2escm",(void*)f_1843},
{"f_1925:data_2dstructures_2escm",(void*)f_1925},
{"f_3547:data_2dstructures_2escm",(void*)f_3547},
{"f_1826:data_2dstructures_2escm",(void*)f_1826},
{"f_4147:data_2dstructures_2escm",(void*)f_4147},
{"f_3642:data_2dstructures_2escm",(void*)f_3642},
{"f_1828:data_2dstructures_2escm",(void*)f_1828},
{"f_3410:data_2dstructures_2escm",(void*)f_3410},
{"f_2145:data_2dstructures_2escm",(void*)f_2145},
{"f_3576:data_2dstructures_2escm",(void*)f_3576},
{"f_2473:data_2dstructures_2escm",(void*)f_2473},
{"f_3751:data_2dstructures_2escm",(void*)f_3751},
{"f_3758:data_2dstructures_2escm",(void*)f_3758},
{"f_3527:data_2dstructures_2escm",(void*)f_3527},
{"f_2111:data_2dstructures_2escm",(void*)f_2111},
{"f_3512:data_2dstructures_2escm",(void*)f_3512},
{"f_3615:data_2dstructures_2escm",(void*)f_3615},
{"f_1819:data_2dstructures_2escm",(void*)f_1819},
{"f_4704:data_2dstructures_2escm",(void*)f_4704},
{"f_2403:data_2dstructures_2escm",(void*)f_2403},
{"f_3721:data_2dstructures_2escm",(void*)f_3721},
{"f_2383:data_2dstructures_2escm",(void*)f_2383},
{"f_1878:data_2dstructures_2escm",(void*)f_1878},
{"f_2417:data_2dstructures_2escm",(void*)f_2417},
{"f_3715:data_2dstructures_2escm",(void*)f_3715},
{"f_1882:data_2dstructures_2escm",(void*)f_1882},
{"f_2426:data_2dstructures_2escm",(void*)f_2426},
{"f_4064:data_2dstructures_2escm",(void*)f_4064},
{"f_4032:data_2dstructures_2escm",(void*)f_4032},
{"f_4030:data_2dstructures_2escm",(void*)f_4030},
{"f_4082:data_2dstructures_2escm",(void*)f_4082},
{"f_4663:data_2dstructures_2escm",(void*)f_4663},
{"f_4089:data_2dstructures_2escm",(void*)f_4089},
{"f_1632:data_2dstructures_2escm",(void*)f_1632},
{"f_4023:data_2dstructures_2escm",(void*)f_4023},
{"f_1640:data_2dstructures_2escm",(void*)f_1640},
{"f_4609:data_2dstructures_2escm",(void*)f_4609},
{"f_2400:data_2dstructures_2escm",(void*)f_2400},
{"f_2364:data_2dstructures_2escm",(void*)f_2364},
{"f_3691:data_2dstructures_2escm",(void*)f_3691},
{"f_1619:data_2dstructures_2escm",(void*)f_1619},
{"f_3911:data_2dstructures_2escm",(void*)f_3911},
{"f_3778:data_2dstructures_2escm",(void*)f_3778},
{"f_2136:data_2dstructures_2escm",(void*)f_2136},
{"f_3095:data_2dstructures_2escm",(void*)f_3095},
{"f_3949:data_2dstructures_2escm",(void*)f_3949},
{"f_3815:data_2dstructures_2escm",(void*)f_3815},
{"f_3812:data_2dstructures_2escm",(void*)f_3812},
{"f_3936:data_2dstructures_2escm",(void*)f_3936},
{"f_3939:data_2dstructures_2escm",(void*)f_3939},
{"f_2312:data_2dstructures_2escm",(void*)f_2312},
{"f_2639:data_2dstructures_2escm",(void*)f_2639},
{"f_3804:data_2dstructures_2escm",(void*)f_3804},
{"f_1654:data_2dstructures_2escm",(void*)f_1654},
{"f_3952:data_2dstructures_2escm",(void*)f_3952},
{"f_3958:data_2dstructures_2escm",(void*)f_3958},
{"f_1660:data_2dstructures_2escm",(void*)f_1660},
{"f_2654:data_2dstructures_2escm",(void*)f_2654},
{"f_2657:data_2dstructures_2escm",(void*)f_2657},
{"f_3822:data_2dstructures_2escm",(void*)f_3822},
{"f_3987:data_2dstructures_2escm",(void*)f_3987},
{"f_4676:data_2dstructures_2escm",(void*)f_4676},
{"f_4673:data_2dstructures_2escm",(void*)f_4673},
{"f_2620:data_2dstructures_2escm",(void*)f_2620},
{"f_4565:data_2dstructures_2escm",(void*)f_4565},
{"f_2645:data_2dstructures_2escm",(void*)f_2645},
{"f_1691:data_2dstructures_2escm",(void*)f_1691},
{"f_1694:data_2dstructures_2escm",(void*)f_1694},
{"f_2648:data_2dstructures_2escm",(void*)f_2648},
{"f_3182:data_2dstructures_2escm",(void*)f_3182},
{"f_3187:data_2dstructures_2escm",(void*)f_3187},
{"f_4623:data_2dstructures_2escm",(void*)f_4623},
{"f_4478:data_2dstructures_2escm",(void*)f_4478},
{"f_3179:data_2dstructures_2escm",(void*)f_3179},
{"f_3893:data_2dstructures_2escm",(void*)f_3893},
{"f_3890:data_2dstructures_2escm",(void*)f_3890},
{"f_4488:data_2dstructures_2escm",(void*)f_4488},
{"f_1600:data_2dstructures_2escm",(void*)f_1600},
{"f_2556:data_2dstructures_2escm",(void*)f_2556},
{"f_3193:data_2dstructures_2escm",(void*)f_3193},
{"f_4538:data_2dstructures_2escm",(void*)f_4538},
{"f_1753:data_2dstructures_2escm",(void*)f_1753},
{"f_1755:data_2dstructures_2escm",(void*)f_1755},
{"f_2607:data_2dstructures_2escm",(void*)f_2607},
{"f_2565:data_2dstructures_2escm",(void*)f_2565},
{"f_1764:data_2dstructures_2escm",(void*)f_1764},
{"f_2359:data_2dstructures_2escm",(void*)f_2359},
{"f_2352:data_2dstructures_2escm",(void*)f_2352},
{"f_1706:data_2dstructures_2escm",(void*)f_1706},
{"f_2672:data_2dstructures_2escm",(void*)f_2672},
{"f_2518:data_2dstructures_2escm",(void*)f_2518},
{"f_4576:data_2dstructures_2escm",(void*)f_4576},
{"f_2513:data_2dstructures_2escm",(void*)f_2513},
{"f_2510:data_2dstructures_2escm",(void*)f_2510},
{"f_4586:data_2dstructures_2escm",(void*)f_4586},
{"f_2529:data_2dstructures_2escm",(void*)f_2529},
{"f_3105:data_2dstructures_2escm",(void*)f_3105},
{"f_1722:data_2dstructures_2escm",(void*)f_1722},
{"f_1728:data_2dstructures_2escm",(void*)f_1728},
{"f_1679:data_2dstructures_2escm",(void*)f_1679},
{"f_2531:data_2dstructures_2escm",(void*)f_2531},
{"f_4525:data_2dstructures_2escm",(void*)f_4525},
{"f_1688:data_2dstructures_2escm",(void*)f_1688},
{"f_3110:data_2dstructures_2escm",(void*)f_3110},
{"f_2095:data_2dstructures_2escm",(void*)f_2095},
{"f_2687:data_2dstructures_2escm",(void*)f_2687},
{"f_4365:data_2dstructures_2escm",(void*)f_4365},
{"f_3050:data_2dstructures_2escm",(void*)f_3050},
{"f_4371:data_2dstructures_2escm",(void*)f_4371},
{"f_2050:data_2dstructures_2escm",(void*)f_2050},
{"f_4380:data_2dstructures_2escm",(void*)f_4380},
{"f_3077:data_2dstructures_2escm",(void*)f_3077},
{"toplevel:data_2dstructures_2escm",(void*)C_data_2dstructures_toplevel},
{"f_1487:data_2dstructures_2escm",(void*)f_1487},
{"f_1785:data_2dstructures_2escm",(void*)f_1785},
{"f_1787:data_2dstructures_2escm",(void*)f_1787},
{"f_1489:data_2dstructures_2escm",(void*)f_1489},
{"f_3376:data_2dstructures_2escm",(void*)f_3376},
{"f_2060:data_2dstructures_2escm",(void*)f_2060},
{"f_4393:data_2dstructures_2escm",(void*)f_4393},
{"f_2057:data_2dstructures_2escm",(void*)f_2057},
{"f_1497:data_2dstructures_2escm",(void*)f_1497},
{"f_1793:data_2dstructures_2escm",(void*)f_1793},
{"f_1499:data_2dstructures_2escm",(void*)f_1499},
{"f_2846:data_2dstructures_2escm",(void*)f_2846},
{"f_1460:data_2dstructures_2escm",(void*)f_1460},
{"f_3396:data_2dstructures_2escm",(void*)f_3396},
{"f_3011:data_2dstructures_2escm",(void*)f_3011},
{"f_2856:data_2dstructures_2escm",(void*)f_2856},
{"f_4596:data_2dstructures_2escm",(void*)f_4596},
{"f_1476:data_2dstructures_2escm",(void*)f_1476},
{"f_3384:data_2dstructures_2escm",(void*)f_3384},
{"f_1565:data_2dstructures_2escm",(void*)f_1565},
{"f_1534:data_2dstructures_2escm",(void*)f_1534},
{"f_4424:data_2dstructures_2escm",(void*)f_4424},
{"f_3217:data_2dstructures_2escm",(void*)f_3217},
{"f_3232:data_2dstructures_2escm",(void*)f_3232},
{"f_4435:data_2dstructures_2escm",(void*)f_4435},
{"f_1439:data_2dstructures_2escm",(void*)f_1439},
{"f_1553:data_2dstructures_2escm",(void*)f_1553},
{"f_1430:data_2dstructures_2escm",(void*)f_1430},
{"f_4445:data_2dstructures_2escm",(void*)f_4445},
{"f_3220:data_2dstructures_2escm",(void*)f_3220},
{"f_1408:data_2dstructures_2escm",(void*)f_1408},
{"f_1406:data_2dstructures_2escm",(void*)f_1406},
{"f_3237:data_2dstructures_2escm",(void*)f_3237},
{"f_1401:data_2dstructures_2escm",(void*)f_1401},
{"f_1520:data_2dstructures_2escm",(void*)f_1520},
{"f_1403:data_2dstructures_2escm",(void*)f_1403},
{"f_2749:data_2dstructures_2escm",(void*)f_2749},
{"f_1528:data_2dstructures_2escm",(void*)f_1528},
{"f_1414:data_2dstructures_2escm",(void*)f_1414},
{"f_3469:data_2dstructures_2escm",(void*)f_3469},
{"f_3256:data_2dstructures_2escm",(void*)f_3256},
{"f_1542:data_2dstructures_2escm",(void*)f_1542},
{"f_4276:data_2dstructures_2escm",(void*)f_4276},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		1
o|eliminated procedure checks: 113 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (##sys#length list)
o|  1 (cdar (pair pair *))
o|  2 (eqv? * (not float))
o|  1 (set-car! pair *)
o|  1 (cddr (pair * pair))
o|  4 (set-cdr! pair *)
o|  1 (<= fixnum fixnum)
o|  1 (vector-length vector)
o|  1 (make-string fixnum)
o|  1 (##sys#check-list (or pair list) *)
o|  23 (cdr pair)
o|  5 (car pair)
o|  2 (length list)
(o e)|safe calls: 465 
o|Removed `not' forms: 11 
o|inlining procedure: k1419 
o|inlining procedure: k1419 
o|contracted procedure: k1452 
o|inlining procedure: k1449 
o|inlining procedure: k1449 
o|inlining procedure: k1478 
o|inlining procedure: k1478 
o|inlining procedure: k1522 
o|inlining procedure: k1522 
o|inlining procedure: k1543 
o|propagated global variable: r15444738 values 
o|inlining procedure: k1543 
o|inlining procedure: k1555 
o|propagated global variable: r15564740 identity 
o|inlining procedure: k1555 
o|inlining procedure: k1573 
o|inlining procedure: k1573 
o|inlining procedure: k1602 
o|inlining procedure: k1602 
o|inlining procedure: k1614 
o|inlining procedure: k1614 
o|inlining procedure: k1634 
o|inlining procedure: k1634 
o|inlining procedure: k1668 
o|inlining procedure: k1668 
o|inlining procedure: k1699 
o|inlining procedure: k1699 
o|inlining procedure: k1708 
o|inlining procedure: k1708 
o|inlining procedure: k1730 
o|inlining procedure: k1730 
o|inlining procedure: k1769 
o|inlining procedure: k1769 
o|inlining procedure: k1795 
o|inlining procedure: k1795 
o|inlining procedure: k1845 
o|inlining procedure: k1845 
o|inlining procedure: k1866 
o|inlining procedure: k1866 
o|inlining procedure: k1927 
o|inlining procedure: k1927 
o|contracted procedure: k1936 
o|inlining procedure: k1948 
o|inlining procedure: k1948 
o|inlining procedure: k1981 
o|inlining procedure: k1981 
o|contracted procedure: k1990 
o|contracted procedure: k1999 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k2061 
o|inlining procedure: k2061 
o|inlining procedure: k2077 
o|propagated global variable: r20784776 assv 
o|inlining procedure: k2077 
o|inlining procedure: k2097 
o|inlining procedure: k2097 
o|inlining procedure: k2147 
o|inlining procedure: k2147 
o|contracted procedure: k2163 
o|contracted procedure: k2175 
o|inlining procedure: k2172 
o|inlining procedure: k2172 
o|inlining procedure: k2260 
o|inlining procedure: k2260 
o|inlining procedure: k2269 
o|propagated global variable: r22704786 assv 
o|inlining procedure: k2269 
o|inlining procedure: k2289 
o|inlining procedure: k2289 
o|inlining procedure: k2307 
o|inlining procedure: k2307 
o|inlining procedure: k2366 
o|inlining procedure: k2366 
o|inlining procedure: k2405 
o|inlining procedure: k2428 
o|inlining procedure: k2428 
o|inlining procedure: k2405 
o|inlining procedure: k2475 
o|inlining procedure: k2475 
o|inlining procedure: k2490 
o|inlining procedure: k2490 
o|inlining procedure: k2533 
o|inlining procedure: k2533 
o|inlining procedure: k2585 
o|inlining procedure: k2597 
o|inlining procedure: k2609 
o|inlining procedure: k2609 
o|inlining procedure: k2597 
o|inlining procedure: k2585 
o|inlining procedure: k2708 
o|inlining procedure: k2708 
o|inlining procedure: k2739 
o|inlining procedure: k2739 
o|inlining procedure: k2969 
o|inlining procedure: k2969 
o|inlining procedure: k2986 
o|inlining procedure: k2986 
o|inlining procedure: k3013 
o|inlining procedure: k3013 
o|inlining procedure: k3035 
o|inlining procedure: k3035 
o|inlining procedure: k3097 
o|inlining procedure: k3124 
o|inlining procedure: k3124 
o|inlining procedure: k3097 
o|inlining procedure: k3195 
o|inlining procedure: k3195 
o|inlining procedure: k3239 
o|inlining procedure: k3239 
o|contracted procedure: k3260 
o|contracted procedure: k3277 
o|inlining procedure: k3274 
o|inlining procedure: k3304 
o|inlining procedure: k3304 
o|inlining procedure: k3274 
o|inlining procedure: k3338 
o|inlining procedure: k3338 
o|inlining procedure: k3364 
o|inlining procedure: k3364 
o|inlining procedure: k3398 
o|inlining procedure: k3412 
o|inlining procedure: k3412 
o|inlining procedure: k3398 
o|inlining procedure: k3431 
o|inlining procedure: k3431 
o|inlining procedure: k3529 
o|inlining procedure: k3529 
o|inlining procedure: k3596 
o|inlining procedure: k3596 
o|inlining procedure: k3617 
o|inlining procedure: k3617 
o|inlining procedure: k3632 
o|inlining procedure: k3632 
o|inlining procedure: k3644 
o|inlining procedure: k3644 
o|substituted constant variable: a3679 
o|inlining procedure: k3696 
o|inlining procedure: k3696 
o|contracted procedure: k3702 
o|inlining procedure: k3723 
o|inlining procedure: k3723 
o|inlining procedure: k3753 
o|inlining procedure: k3753 
o|inlining procedure: k3817 
o|inlining procedure: k3817 
o|inlining procedure: k3873 
o|inlining procedure: k3873 
o|inlining procedure: k3885 
o|inlining procedure: k3885 
o|inlining procedure: k3941 
o|inlining procedure: k3941 
o|inlining procedure: k3998 
o|inlining procedure: k3998 
o|inlining procedure: k4011 
o|inlining procedure: k4034 
o|inlining procedure: k4034 
o|inlining procedure: k4011 
o|inlining procedure: k4066 
o|inlining procedure: k4066 
o|inlining procedure: k4099 
o|inlining procedure: k4099 
o|inlining procedure: k4168 
o|inlining procedure: k4168 
o|substituted constant variable: a4223 
o|substituted constant variable: a4225 
o|inlining procedure: k4240 
o|inlining procedure: k4240 
o|inlining procedure: k4284 
o|inlining procedure: k4305 
o|inlining procedure: k4305 
o|contracted procedure: k4320 
o|inlining procedure: k4317 
o|inlining procedure: k4317 
o|contracted procedure: k4333 
o|inlining procedure: k4330 
o|inlining procedure: k4330 
o|inlining procedure: k4284 
o|inlining procedure: k4401 
o|inlining procedure: k4401 
o|inlining procedure: k4422 
o|inlining procedure: k4422 
o|inlining procedure: k4540 
o|inlining procedure: k4540 
o|inlining procedure: k4574 
o|inlining procedure: k4574 
o|inlining procedure: k4588 
o|inlining procedure: k4588 
o|contracted procedure: "(data-structures.scm:901) g936937" 
o|inlining procedure: k4706 
o|inlining procedure: k4706 
o|replaced variables: 522 
o|removed binding forms: 211 
o|substituted constant variable: r14504732 
o|substituted constant variable: r16034744 
o|substituted constant variable: r16154747 
o|substituted constant variable: r17094754 
o|substituted constant variable: r17704759 
o|substituted constant variable: r18464762 
o|substituted constant variable: r19284766 
o|substituted constant variable: r19824770 
o|substituted constant variable: r20984779 
o|substituted constant variable: r22904788 
o|substituted constant variable: r23674793 
o|substituted constant variable: r26104806 
o|substituted constant variable: r25984808 
o|converted assignments to bindings: (add547) 
o|substituted constant variable: r31964828 
o|converted assignments to bindings: (instring626) 
o|substituted constant variable: r35304848 
o|substituted constant variable: r36184852 
o|substituted constant variable: r36334854 
o|substituted constant variable: r39994873 
o|substituted constant variable: r43184889 
o|substituted constant variable: r43314891 
o|substituted constant variable: r42854893 
o|substituted constant variable: r45754916 
o|substituted constant variable: r45754916 
o|converted assignments to bindings: (traverse389) 
o|simplifications: ((let . 3)) 
o|replaced variables: 21 
o|removed binding forms: 526 
o|inlining procedure: k2659 
o|inlining procedure: k2674 
o|inlining procedure: k2803 
o|inlining procedure: k2900 
o|inlining procedure: k2992 
o|inlining procedure: k4594 
o|replaced variables: 10 
o|removed binding forms: 47 
o|substituted constant variable: r26605137 
o|substituted constant variable: r26755138 
o|removed binding forms: 14 
o|removed binding forms: 2 
o|simplifications: ((if . 40) (##core#call . 514)) 
o|  call simplifications:
o|    ##sys#setislot	4
o|    ##sys#check-structure	9
o|    ##sys#structure?
o|    ##sys#check-vector
o|    caar
o|    ##sys#cons	4
o|    ##sys#list
o|    ##sys#make-structure	4
o|    vector-length
o|    vector-set!
o|    >
o|    set-car!
o|    quotient
o|    set-cdr!	4
o|    vector?	3
o|    -	2
o|    vector-ref	2
o|    +	2
o|    =	4
o|    list->string	2
o|    cadr	2
o|    fxmin	2
o|    ##sys#check-string	21
o|    ##sys#size	24
o|    fx>=	10
o|    fx>	6
o|    string?	2
o|    symbol?
o|    char?	4
o|    number?
o|    string
o|    string-length	4
o|    string-ref
o|    string-set!
o|    fx+	31
o|    ##sys#setslot	17
o|    pair?	17
o|    ##sys#check-exact	7
o|    fx<=	5
o|    length	2
o|    fx<	6
o|    fx=	8
o|    fx-	16
o|    list	6
o|    list?
o|    ##sys#check-pair	3
o|    cdr	12
o|    cons	38
o|    ##sys#check-list	8
o|    void
o|    not-pair?
o|    call-with-values
o|    not	3
o|    eq?	23
o|    apply	8
o|    car	33
o|    null?	57
o|    ##sys#slot	81
o|contracted procedure: k1416 
o|contracted procedure: k1425 
o|contracted procedure: k1435 
o|contracted procedure: k1472 
o|contracted procedure: k1455 
o|contracted procedure: k1468 
o|contracted procedure: k1481 
o|contracted procedure: k1484 
o|contracted procedure: k1525 
o|contracted procedure: k1546 
o|contracted procedure: k1558 
o|contracted procedure: k1567 
o|contracted procedure: k1570 
o|contracted procedure: k1576 
o|contracted procedure: k1605 
o|contracted procedure: k1611 
o|contracted procedure: k1624 
o|contracted procedure: k1628 
o|contracted procedure: k1637 
o|contracted procedure: k1684 
o|contracted procedure: k1648 
o|contracted procedure: k1662 
o|contracted procedure: k1665 
o|contracted procedure: k1671 
o|contracted procedure: k1696 
o|contracted procedure: k1718 
o|contracted procedure: k1733 
o|contracted procedure: k1743 
o|contracted procedure: k1747 
o|contracted procedure: k1757 
o|contracted procedure: k1766 
o|contracted procedure: k1772 
o|contracted procedure: k1779 
o|contracted procedure: k1798 
o|contracted procedure: k1801 
o|contracted procedure: k1804 
o|contracted procedure: k1810 
o|contracted procedure: k1830 
o|contracted procedure: k1836 
o|contracted procedure: k1848 
o|contracted procedure: k1854 
o|contracted procedure: k1869 
o|contracted procedure: k1884 
o|contracted procedure: k1903 
o|contracted procedure: k1891 
o|contracted procedure: k1895 
o|contracted procedure: k1899 
o|contracted procedure: k1906 
o|contracted procedure: k1918 
o|contracted procedure: k1930 
o|contracted procedure: k1962 
o|contracted procedure: k1942 
o|contracted procedure: k1945 
o|contracted procedure: k1951 
o|contracted procedure: k1965 
o|contracted procedure: k1972 
o|contracted procedure: k1984 
o|contracted procedure: k2046 
o|contracted procedure: k2042 
o|contracted procedure: k2008 
o|contracted procedure: k2015 
o|contracted procedure: k2023 
o|contracted procedure: k2027 
o|contracted procedure: k2034 
o|contracted procedure: k2038 
o|contracted procedure: k2129 
o|contracted procedure: k2052 
o|contracted procedure: k2064 
o|contracted procedure: k2071 
o|contracted procedure: k2074 
o|contracted procedure: k2080 
o|contracted procedure: k2086 
o|contracted procedure: k2100 
o|contracted procedure: k2103 
o|contracted procedure: k2116 
o|contracted procedure: k2119 
o|contracted procedure: k2126 
o|contracted procedure: k2233 
o|contracted procedure: k2138 
o|contracted procedure: k2150 
o|contracted procedure: k2157 
o|contracted procedure: k2230 
o|contracted procedure: k2169 
o|contracted procedure: k2226 
o|contracted procedure: k2191 
o|contracted procedure: k2195 
o|contracted procedure: k2214 
o|contracted procedure: k2218 
o|contracted procedure: k2202 
o|contracted procedure: k2210 
o|contracted procedure: k2222 
o|contracted procedure: k2345 
o|contracted procedure: k2242 
o|contracted procedure: k2339 
o|contracted procedure: k2245 
o|contracted procedure: k2333 
o|contracted procedure: k2248 
o|contracted procedure: k2327 
o|contracted procedure: k2251 
o|contracted procedure: k2266 
o|contracted procedure: k2272 
o|contracted procedure: k2278 
o|contracted procedure: k2292 
o|contracted procedure: k2298 
o|contracted procedure: k2301 
o|contracted procedure: k2304 
o|contracted procedure: k2317 
o|contracted procedure: k2321 
o|contracted procedure: k2354 
o|contracted procedure: k2369 
o|contracted procedure: k2372 
o|contracted procedure: k2375 
o|contracted procedure: k2388 
o|contracted procedure: k2392 
o|contracted procedure: k2395 
o|contracted procedure: k2408 
o|contracted procedure: k2412 
o|contracted procedure: k2457 
o|contracted procedure: k2453 
o|contracted procedure: k2422 
o|contracted procedure: k2431 
o|contracted procedure: k2449 
o|contracted procedure: k2434 
o|contracted procedure: k2441 
o|contracted procedure: k2445 
o|contracted procedure: k2463 
o|contracted procedure: k2478 
o|contracted procedure: k2484 
o|contracted procedure: k2493 
o|contracted procedure: k2502 
o|contracted procedure: k2524 
o|contracted procedure: k2536 
o|contracted procedure: k2539 
o|contracted procedure: k2542 
o|contracted procedure: k2550 
o|contracted procedure: k2558 
o|contracted procedure: k2567 
o|contracted procedure: k2570 
o|contracted procedure: k2573 
o|contracted procedure: k2576 
o|contracted procedure: k2579 
o|contracted procedure: k2582 
o|contracted procedure: k2632 
o|contracted procedure: k2588 
o|contracted procedure: k2594 
o|contracted procedure: k2600 
o|contracted procedure: k2612 
o|contracted procedure: k2625 
o|contracted procedure: k2665 
o|contracted procedure: k2659 
o|contracted procedure: k2680 
o|contracted procedure: k2674 
o|contracted procedure: k2689 
o|contracted procedure: k2692 
o|contracted procedure: k2695 
o|contracted procedure: k2698 
o|contracted procedure: k2701 
o|contracted procedure: k2714 
o|contracted procedure: k2705 
o|contracted procedure: k2711 
o|contracted procedure: k2720 
o|contracted procedure: k2723 
o|contracted procedure: k2726 
o|contracted procedure: k2729 
o|contracted procedure: k2732 
o|contracted procedure: k2745 
o|contracted procedure: k2736 
o|contracted procedure: k2742 
o|contracted procedure: k2751 
o|contracted procedure: k2754 
o|contracted procedure: k2760 
o|contracted procedure: k2763 
o|contracted procedure: k2782 
o|contracted procedure: k2770 
o|contracted procedure: k2778 
o|contracted procedure: k2774 
o|contracted procedure: k2839 
o|contracted procedure: k2788 
o|contracted procedure: k2833 
o|contracted procedure: k2791 
o|contracted procedure: k2827 
o|contracted procedure: k2794 
o|contracted procedure: k2821 
o|contracted procedure: k2797 
o|contracted procedure: k2815 
o|contracted procedure: k2800 
o|contracted procedure: k2809 
o|contracted procedure: k2803 
o|contracted procedure: k2848 
o|contracted procedure: k2851 
o|contracted procedure: k2857 
o|contracted procedure: k2860 
o|contracted procedure: k2879 
o|contracted procedure: k2867 
o|contracted procedure: k2875 
o|contracted procedure: k2871 
o|contracted procedure: k2936 
o|contracted procedure: k2885 
o|contracted procedure: k2930 
o|contracted procedure: k2888 
o|contracted procedure: k2924 
o|contracted procedure: k2891 
o|contracted procedure: k2918 
o|contracted procedure: k2894 
o|contracted procedure: k2912 
o|contracted procedure: k2897 
o|contracted procedure: k2906 
o|contracted procedure: k2900 
o|contracted procedure: k2945 
o|contracted procedure: k3070 
o|contracted procedure: k2948 
o|contracted procedure: k3062 
o|contracted procedure: k2951 
o|contracted procedure: k2954 
o|contracted procedure: k2957 
o|contracted procedure: k2960 
o|contracted procedure: k2966 
o|contracted procedure: k2969 
o|contracted procedure: k2989 
o|contracted procedure: k2998 
o|contracted procedure: k3001 
o|contracted procedure: k3016 
o|contracted procedure: k3023 
o|contracted procedure: k3029 
o|contracted procedure: k3032 
o|contracted procedure: k3038 
o|contracted procedure: k3041 
o|contracted procedure: k3058 
o|contracted procedure: k3172 
o|contracted procedure: k3079 
o|contracted procedure: k3082 
o|contracted procedure: k3085 
o|contracted procedure: k3088 
o|contracted procedure: k3112 
o|contracted procedure: k3115 
o|contracted procedure: k3118 
o|contracted procedure: k3121 
o|contracted procedure: k3131 
o|contracted procedure: k3135 
o|contracted procedure: k3141 
o|contracted procedure: k3144 
o|contracted procedure: k3147 
o|contracted procedure: k3154 
o|contracted procedure: k3162 
o|contracted procedure: k3166 
o|contracted procedure: k3158 
o|contracted procedure: k3184 
o|contracted procedure: k3198 
o|contracted procedure: k3204 
o|contracted procedure: k3211 
o|contracted procedure: k3326 
o|contracted procedure: k3221 
o|contracted procedure: k3224 
o|contracted procedure: k3227 
o|contracted procedure: k3242 
o|contracted procedure: k3248 
o|contracted procedure: k3290 
o|contracted procedure: k3297 
o|contracted procedure: k3301 
o|contracted procedure: k3307 
o|contracted procedure: k3318 
o|contracted procedure: k3322 
o|contracted procedure: k3284 
o|contracted procedure: k3267 
o|contracted procedure: k3271 
o|contracted procedure: k3332 
o|contracted procedure: k3335 
o|contracted procedure: k3341 
o|contracted procedure: k3347 
o|contracted procedure: k3353 
o|contracted procedure: k3356 
o|contracted procedure: k3367 
o|contracted procedure: k3377 
o|contracted procedure: k3386 
o|contracted procedure: k3389 
o|contracted procedure: k3392 
o|contracted procedure: k3401 
o|contracted procedure: k3415 
o|contracted procedure: k3412 
o|contracted procedure: k3434 
o|contracted procedure: k3441 
o|contracted procedure: k3445 
o|contracted procedure: k3448 
o|contracted procedure: k3451 
o|contracted procedure: k3454 
o|contracted procedure: k3505 
o|contracted procedure: k3501 
o|contracted procedure: k3461 
o|contracted procedure: k3464 
o|contracted procedure: k3482 
o|contracted procedure: k3474 
o|contracted procedure: k3478 
o|contracted procedure: k3485 
o|contracted procedure: k3489 
o|contracted procedure: k3514 
o|contracted procedure: k3517 
o|contracted procedure: k3520 
o|contracted procedure: k3532 
o|contracted procedure: k3538 
o|contracted procedure: k3549 
o|contracted procedure: k3564 
o|contracted procedure: k3568 
o|contracted procedure: k3572 
o|contracted procedure: k3608 
o|contracted procedure: k3578 
o|contracted procedure: k3581 
o|contracted procedure: k3584 
o|contracted procedure: k3587 
o|contracted procedure: k3590 
o|contracted procedure: k3593 
o|contracted procedure: k3605 
o|contracted procedure: k3599 
o|contracted procedure: k3620 
o|contracted procedure: k3626 
o|contracted procedure: k3629 
o|contracted procedure: k3635 
o|contracted procedure: k3647 
o|contracted procedure: k3660 
o|contracted procedure: k3667 
o|contracted procedure: k3675 
o|contracted procedure: k3671 
o|contracted procedure: k3685 
o|contracted procedure: k3693 
o|contracted procedure: k3717 
o|contracted procedure: k3726 
o|contracted procedure: k3732 
o|contracted procedure: k3739 
o|contracted procedure: k3745 
o|contracted procedure: k3762 
o|contracted procedure: k3769 
o|contracted procedure: k3780 
o|contracted procedure: k3788 
o|contracted procedure: k3795 
o|contracted procedure: k3806 
o|contracted procedure: k3823 
o|contracted procedure: k3829 
o|contracted procedure: k3844 
o|contracted procedure: k3850 
o|contracted procedure: k3866 
o|contracted procedure: k3870 
o|contracted procedure: k3876 
o|contracted procedure: k3882 
o|contracted procedure: k3894 
o|inlining procedure: k3891 
o|contracted procedure: k3912 
o|inlining procedure: k3909 
o|contracted procedure: k3928 
o|contracted procedure: k3932 
o|contracted procedure: k3944 
o|contracted procedure: k3953 
o|contracted procedure: k3965 
o|contracted procedure: k3968 
o|contracted procedure: k3971 
o|contracted procedure: k3980 
o|contracted procedure: k3988 
o|contracted procedure: k4001 
o|contracted procedure: k4005 
o|contracted procedure: k4008 
o|contracted procedure: k4014 
o|contracted procedure: k4017 
o|contracted procedure: k4037 
o|contracted procedure: k4053 
o|contracted procedure: k4040 
o|contracted procedure: k4049 
o|contracted procedure: k4060 
o|contracted procedure: k4069 
o|contracted procedure: k4102 
o|contracted procedure: k4117 
o|contracted procedure: k4121 
o|contracted procedure: k4141 
o|contracted procedure: k4125 
o|contracted procedure: k4129 
o|contracted procedure: k4137 
o|contracted procedure: k4113 
o|contracted procedure: k4109 
o|contracted procedure: k4151 
o|contracted procedure: k4214 
o|contracted procedure: k4208 
o|contracted procedure: k4162 
o|contracted procedure: k4171 
o|contracted procedure: k4182 
o|contracted procedure: k4188 
o|contracted procedure: k4191 
o|contracted procedure: k4204 
o|contracted procedure: k4227 
o|contracted procedure: k4268 
o|contracted procedure: k4272 
o|contracted procedure: k4234 
o|contracted procedure: k4243 
o|contracted procedure: k4253 
o|contracted procedure: k4261 
o|contracted procedure: k4281 
o|contracted procedure: k4287 
o|contracted procedure: k4345 
o|contracted procedure: k4296 
o|contracted procedure: k4299 
o|contracted procedure: k4308 
o|contracted procedure: k4314 
o|contracted procedure: k4327 
o|contracted procedure: k4340 
o|contracted procedure: k4348 
o|contracted procedure: k4373 
o|contracted procedure: k4382 
o|contracted procedure: k4389 
o|contracted procedure: k4395 
o|contracted procedure: k4398 
o|contracted procedure: k4407 
o|contracted procedure: k4416 
o|contracted procedure: k4419 
o|contracted procedure: k4428 
o|contracted procedure: k4437 
o|contracted procedure: k4440 
o|contracted procedure: k4446 
o|contracted procedure: k4457 
o|contracted procedure: k4453 
o|contracted procedure: k4449 
o|contracted procedure: k4474 
o|contracted procedure: k4460 
o|contracted procedure: k4470 
o|contracted procedure: k4480 
o|contracted procedure: k4483 
o|contracted procedure: k4489 
o|contracted procedure: k4492 
o|contracted procedure: k4512 
o|contracted procedure: k4495 
o|contracted procedure: k4509 
o|contracted procedure: k4505 
o|contracted procedure: k4498 
o|contracted procedure: k4518 
o|contracted procedure: k4527 
o|contracted procedure: k4534 
o|contracted procedure: k4543 
o|contracted procedure: k4553 
o|contracted procedure: k4561 
o|contracted procedure: k4557 
o|contracted procedure: k4567 
o|contracted procedure: k4579 
o|contracted procedure: k4619 
o|contracted procedure: k4591 
o|contracted procedure: k4601 
o|contracted procedure: k4604 
o|contracted procedure: k46015186 
o|contracted procedure: k4625 
o|contracted procedure: k4659 
o|contracted procedure: k4628 
o|contracted procedure: k4631 
o|contracted procedure: k4655 
o|contracted procedure: k4648 
o|contracted procedure: k4634 
o|contracted procedure: k4645 
o|contracted procedure: k4641 
o|contracted procedure: k4665 
o|contracted procedure: k4668 
o|contracted procedure: k4677 
o|contracted procedure: k4680 
o|contracted procedure: k4691 
o|contracted procedure: k4687 
o|contracted procedure: k4695 
o|contracted procedure: k4720 
o|contracted procedure: k4709 
o|contracted procedure: k4716 
o|contracted procedure: k4727 
o|simplifications: ((let . 87)) 
o|removed binding forms: 460 
o|inlining procedure: k3977 
o|inlining procedure: k3977 
o|substituted constant variable: r4269 
o|substituted constant variable: r4269 
o|substituted constant variable: r4273 
o|replaced variables: 167 
o|removed binding forms: 90 
o|direct leaf routine/allocation: loop152 0 
o|direct leaf routine/allocation: loop347 0 
o|direct leaf routine/allocation: loop2606 0 
o|direct leaf routine/allocation: loop630 0 
o|direct leaf routine/allocation: doloop939940 0 
o|converted assignments to bindings: (loop152) 
o|converted assignments to bindings: (loop347) 
o|converted assignments to bindings: (loop2606) 
o|converted assignments to bindings: (loop630) 
o|converted assignments to bindings: (doloop939940) 
o|simplifications: ((let . 5)) 
o|customizable procedures: (k4674 k4607 doloop915916 loop908 k4443 k4278 loop852 loop842 visit819 walk834 doloop805806 step783 loop771 loop757 loop741 doloop734735 loop697 loop680 k3467 collect675 instring626 loop656 loop1598 scan569 loop553 add547 k2854 k2757 traverse389 loop400 map-loop365382 rev-string-append341 k2357 loop332 loop317 k2254 loop279 loop256 k2055 loop225 k1915 loop211 doloop198199 loop191 loop177 loop169 loop163 loop136 loop121 loop110 loop80 loop68) 
o|calls to known targets: 131 
o|unused rest argument: _92 f_1487 
o|unused rest argument: _93 f_1489 
o|unused rest argument: _134 f_1640 
o|identified direct recursive calls: f_1706 1 
o|identified direct recursive calls: f_1728 1 
o|identified direct recursive calls: f_1764 1 
o|identified direct recursive calls: f_1793 2 
o|identified direct recursive calls: f_1864 1 
o|identified direct recursive calls: f_1925 1 
o|identified direct recursive calls: f_1979 2 
o|identified direct recursive calls: f_2426 1 
o|identified direct recursive calls: f_2403 1 
o|identified direct recursive calls: f_3011 1 
o|identified direct recursive calls: f_3110 1 
o|identified direct recursive calls: f_3095 1 
o|identified direct recursive calls: f_3193 1 
o|identified direct recursive calls: f_3429 1 
o|identified direct recursive calls: f_4032 1 
o|identified direct recursive calls: f_4538 1 
o|identified direct recursive calls: f_4704 1 
o|fast box initializations: 39 
o|dropping unused closure argument: f_4704 
o|dropping unused closure argument: f_3182 
o|dropping unused closure argument: f_2565 
*/
/* end of file */
