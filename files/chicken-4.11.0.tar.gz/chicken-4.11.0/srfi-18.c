/* Generated from srfi-18.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:48
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: srfi-18.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file srfi-18.c
   unit: srfi_2d18
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[113];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,31),40,99,111,109,112,117,116,101,45,116,105,109,101,45,108,105,109,105,116,32,116,109,57,49,32,108,111,99,57,50,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,99,117,114,114,101,110,116,45,116,105,109,101,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,20),40,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,57,57,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,20),40,115,101,99,111,110,100,115,45,62,116,105,109,101,32,110,49,48,50,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,116,105,109,101,63,32,120,49,48,53,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,30),40,106,111,105,110,45,116,105,109,101,111,117,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,48,56,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,33),40,97,98,97,110,100,111,110,101,100,45,109,117,116,101,120,45,101,120,99,101,112,116,105,111,110,63,32,120,49,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,116,101,114,109,105,110,97,116,101,100,45,116,104,114,101,97,100,45,101,120,99,101,112,116,105,111,110,63,32,120,49,49,52,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,117,110,99,97,117,103,104,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,97,56,54,50,32,46,32,114,101,115,117,108,116,115,49,50,52,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,6),40,97,56,53,54,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,116,104,114,101,97,100,32,116,104,117,110,107,49,50,49,32,46,32,110,97,109,101,49,50,50,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,14),40,116,104,114,101,97,100,63,32,120,49,50,57,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,99,117,114,114,101,110,116,45,116,104,114,101,97,100,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,24),40,116,104,114,101,97,100,45,115,116,97,116,101,32,116,104,114,101,97,100,49,51,50,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,116,104,114,101,97,100,49,51,53,32,120,49,51,54,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,32,116,104,114,101,97,100,49,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,36),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,45,115,101,116,33,32,116,104,114,101,97,100,49,52,53,32,113,49,52,54,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,18),40,116,104,114,101,97,100,45,110,97,109,101,32,120,49,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,116,104,114,101,97,100,45,115,116,97,114,116,33,32,116,104,114,101,97,100,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,49,48,50,56,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,17),40,97,49,48,49,51,32,114,101,116,117,114,110,49,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,106,111,105,110,33,32,116,104,114,101,97,100,49,54,48,32,46,32,116,105,109,101,111,117,116,49,54,49,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,29),40,116,104,114,101,97,100,45,116,101,114,109,105,110,97,116,101,33,32,116,104,114,101,97,100,49,57,48,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,49,50,51,50,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,17),40,97,49,50,50,51,32,114,101,116,117,114,110,50,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,27),40,116,104,114,101,97,100,45,115,117,115,112,101,110,100,33,32,116,104,114,101,97,100,49,57,57,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,114,101,115,117,109,101,33,32,116,104,114,101,97,100,50,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,7),40,97,49,50,56,49,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,17),40,97,49,50,54,57,32,114,101,116,117,114,110,50,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,21),40,116,104,114,101,97,100,45,115,108,101,101,112,33,32,116,109,50,48,57,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,109,117,116,101,120,63,32,120,50,49,57,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,109,97,107,101,45,109,117,116,101,120,32,46,32,116,109,112,50,50,53,50,50,54,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,17),40,109,117,116,101,120,45,110,97,109,101,32,120,50,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,25),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,32,109,117,116,101,120,50,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,35),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,109,117,116,101,120,50,51,57,32,120,50,52,48,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,22),40,109,117,116,101,120,45,115,116,97,116,101,32,109,117,116,101,120,50,52,51,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,8),40,115,119,105,116,99,104,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,99,104,101,99,107,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,8),40,97,115,115,105,103,110,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,49,53,53,50,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,17),40,97,49,51,57,57,32,114,101,116,117,114,110,50,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,36),40,109,117,116,101,120,45,108,111,99,107,33,32,109,117,116,101,120,50,53,51,32,46,32,109,115,45,97,110,100,45,116,50,53,52,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,49,55,51,50,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,49,55,55,48,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,17),40,97,49,54,51,48,32,114,101,116,117,114,110,51,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,41),40,109,117,116,101,120,45,117,110,108,111,99,107,33,32,109,117,116,101,120,51,48,52,32,46,32,99,118,97,114,45,97,110,100,45,116,111,51,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,32,46,32,110,97,109,101,51,52,57,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,63,32,120,51,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,31),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,110,97,109,101,32,99,118,51,53,51,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,32,99,118,51,53,54,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,45),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,99,118,51,53,57,32,120,51,54,48,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,36),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,105,103,110,97,108,33,32,99,118,97,114,51,54,51,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,55,54,32,103,51,56,51,51,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,39),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,98,114,111,97,100,99,97,115,116,33,32,99,118,97,114,51,55,51,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,7),40,97,50,48,48,55,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,116,104,114,101,97,100,45,115,105,103,110,97,108,33,32,116,104,114,101,97,100,51,57,57,32,101,120,110,52,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,114,101,97,100,45,112,114,111,109,112,116,45,104,111,111,107,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,40),40,116,104,114,101,97,100,45,119,97,105,116,45,102,111,114,45,105,47,111,33,32,102,100,52,50,52,32,46,32,116,109,112,52,50,51,52,50,53,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,17),40,97,50,49,48,57,32,116,104,114,101,97,100,49,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word *av) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word *av) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word *av) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word *av) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word *av) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word *av) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word *av) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word *av) C_noret;
C_noret_decl(f_1427)
static void C_fcall f_1427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_ccall f_898(C_word c,C_word *av) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word *av) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word *av) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word *av) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word *av) C_noret;
C_noret_decl(f_1403)
static void C_fcall f_1403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word *av) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word *av) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word *av) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word *av) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word *av) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word *av) C_noret;
C_noret_decl(f_695)
static void C_fcall f_695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word *av) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word *av) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word *av) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word *av) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word *av) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word *av) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word *av) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word *av) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word *av) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word *av) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d18_toplevel)
C_externexport void C_ccall C_srfi_2d18_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word *av) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word *av) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word *av) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word *av) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word *av) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word *av) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word *av) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word *av) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word *av) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word *av) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word *av) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word *av) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word *av) C_noret;
C_noret_decl(f_1952)
static void C_fcall f_1952(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word *av) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word *av) C_noret;
C_noret_decl(f_910)
static void C_ccall f_910(C_word c,C_word *av) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word *av) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word *av) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word *av) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word *av) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word *av) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word *av) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word *av) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word *av) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word *av) C_noret;
C_noret_decl(f_1650)
static void C_fcall f_1650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word *av) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word *av) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word *av) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word *av) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word *av) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word *av) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word *av) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word *av) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word *av) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word *av) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word *av) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word *av) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word *av) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word *av) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word *av) C_noret;
C_noret_decl(f_1620)
static void C_fcall f_1620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word *av) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word *av) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word *av) C_noret;
C_noret_decl(f_961)
static void C_fcall f_961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796(C_word c,C_word *av) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word *av) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word *av) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word *av) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word *av) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word *av) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word *av) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word *av) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word *av) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word *av) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word *av) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word *av) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word *av) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word *av) C_noret;
C_noret_decl(f_1089)
static void C_fcall f_1089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word *av) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word *av) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word *av) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word *av) C_noret;
C_noret_decl(f_1997)
static void C_fcall f_1997(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word *av) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word *av) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word *av) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word *av) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word *av) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word *av) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word *av) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word *av) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word *av) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word *av) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word *av) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word *av) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word *av) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word *av) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word *av) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word *av) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word *av) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word *av) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word *av) C_noret;

C_noret_decl(trf_1427)
static void C_ccall trf_1427(C_word c,C_word *av) C_noret;
static void C_ccall trf_1427(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1427(t0,t1);}

C_noret_decl(trf_1403)
static void C_ccall trf_1403(C_word c,C_word *av) C_noret;
static void C_ccall trf_1403(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1403(t0,t1);}

C_noret_decl(trf_695)
static void C_ccall trf_695(C_word c,C_word *av) C_noret;
static void C_ccall trf_695(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_695(t0,t1,t2);}

C_noret_decl(trf_1952)
static void C_ccall trf_1952(C_word c,C_word *av) C_noret;
static void C_ccall trf_1952(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1952(t0,t1,t2);}

C_noret_decl(trf_1650)
static void C_ccall trf_1650(C_word c,C_word *av) C_noret;
static void C_ccall trf_1650(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1650(t0,t1);}

C_noret_decl(trf_1620)
static void C_ccall trf_1620(C_word c,C_word *av) C_noret;
static void C_ccall trf_1620(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1620(t0,t1);}

C_noret_decl(trf_961)
static void C_ccall trf_961(C_word c,C_word *av) C_noret;
static void C_ccall trf_961(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_961(t0,t1);}

C_noret_decl(trf_1089)
static void C_ccall trf_1089(C_word c,C_word *av) C_noret;
static void C_ccall trf_1089(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1089(t0,t1);}

C_noret_decl(trf_1997)
static void C_ccall trf_1997(C_word c,C_word *av) C_noret;
static void C_ccall trf_1997(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1997(t0,t1);}

/* mutex? in k919 in k844 in k691 in k688 */
static void C_ccall f_1301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1301,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[71]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a1028 in k1016 in a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_1029,2,av);}
a=C_alloc(14);
t2=C_slot(((C_word*)t0)[2],C_fix(3));
t3=C_eqp(t2,lf[29]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_slot(((C_word*)t0)[4],C_fix(13)))){
t5=C_slot(((C_word*)t0)[2],C_fix(2));{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=t5;
C_apply(4,av2);}}
else{
/* srfi-18.scm:178: ##sys#remove-from-timeout-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[51]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[51]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}
else{
t4=C_eqp(t2,lf[52]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_slot(((C_word*)t0)[2],C_fix(7));
t7=C_a_i_list2(&a,2,lf[53],t6);
t8=C_a_i_record3(&a,3,lf[17],lf[54],t7);
/* srfi-18.scm:182: ##sys#signal */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[15]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t5;
av2[2]=t8;
tp(3,av2);}}
else{
t5=C_eqp(t2,lf[55]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_1089(t7,t5);}
else{
t7=C_eqp(t2,lf[44]);
t8=t6;
f_1089(t8,(C_truep(t7)?t7:C_eqp(t2,lf[59])));}}}}

/* k1578 in a1552 in k1540 in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1580,2,av);}
/* srfi-18.scm:316: assign */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
f_1455(2,av2);}}

/* make-mutex in k919 in k844 in k691 in k688 */
static void C_ccall f_1307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,3))){
C_save_and_reclaim((void*)f_1307,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
/* srfi-18.scm:241: gensym */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[71];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=C_i_car(t2);
/* srfi-18.scm:242: ##sys#make-mutex */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[73]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[73]+1);
av2[1]=t1;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
tp(4,av2);}}}

/* k1022 in k1016 in a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1024,2,av);}
/* srfi-18.scm:199: ##sys#schedule */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[2];
tp(2,av2);}}

/* k1571 in a1552 in k1540 in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1573,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(3),t1);
t3=C_i_set_i_slot(((C_word*)t0)[3],C_fix(11),C_SCHEME_FALSE);
/* srfi-18.scm:313: return */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[5];
av2[2]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* mutex-specific in k919 in k844 in k691 in k688 */
static void C_ccall f_1334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1334,3,av);}
t3=C_i_check_structure_2(t2,lf[71],lf[75]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(6));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* thread? in k844 in k691 in k688 */
static void C_ccall f_892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_892,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[34]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* check in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_fcall f_1427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_1427,2,t0,t1);}
a=C_alloc(11);
if(C_truep(C_slot(((C_word*)t0)[2],C_fix(4)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1441,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_a_i_list1(&a,1,t3);
t5=C_a_i_record3(&a,3,lf[17],lf[83],t4);
/* srfi-18.scm:280: ##sys#signal */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[15]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t2;
av2[2]=t5;
tp(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* current-thread in k844 in k691 in k688 */
static void C_ccall f_898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_898,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[30]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* assign in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_1455,2,av);}
a=C_alloc(9);
t2=C_i_set_i_slot(((C_word*)t0)[2],C_fix(11),C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* srfi-18.scm:283: check */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1427(t4,t3);}

/* k868 in a862 in a856 in k850 in make-thread in k844 in k691 in k688 */
static void C_ccall f_870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_870,2,av);}
/* srfi-18.scm:113: ##sys#schedule */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[2];
tp(2,av2);}}

/* a1281 in a1269 in k1294 in k1287 in thread-sleep! in k919 in k844 in k691 in k688 */
static void C_ccall f_1282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1282,2,av);}
/* srfi-18.scm:230: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=C_SCHEME_UNDEFINED;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k1309 in make-mutex in k919 in k844 in k691 in k688 */
static void C_ccall f_1311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1311,2,av);}
/* srfi-18.scm:242: ##sys#make-mutex */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[73]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[73]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
tp(4,av2);}}

/* switch in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_fcall f_1403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_1403,2,t0,t1);}
a=C_alloc(7);
t2=C_i_setslot(((C_word*)t0)[2],C_fix(11),((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[3],C_fix(3));
t5=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* srfi-18.scm:276: ##sys#append */
t6=*((C_word*)lf[82]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(34,c,2))){C_save_and_reclaim((void *)f_1400,3,av);}
a=C_alloc(34);
t3=*((C_word*)lf[30]+1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1403,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1455,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t7,a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp));
if(C_truep(C_slot(((C_word*)t0)[2],C_fix(5)))){
if(C_truep(((C_word*)t0)[5])){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1542,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t9,a[6]=t5,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* srfi-18.scm:305: check */
t14=((C_word*)t7)[1];
f_1427(t14,t13);}
else{
t13=C_i_setslot(t3,C_fix(3),lf[59]);
t14=C_i_setslot(t3,C_fix(1),((C_word*)t9)[1]);
/* srfi-18.scm:322: switch */
t15=((C_word*)t5)[1];
f_1403(t15,t1);}}
else{
/* srfi-18.scm:303: assign */
t13=((C_word*)t9)[1];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=t1;
f_1455(2,av2);}}}

/* k1294 in k1287 in thread-sleep! in k919 in k844 in k691 in k688 */
static void C_ccall f_1296(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1296,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];
t3=t1;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1270,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:227: ##sys#call-with-current-continuation */{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t2;
av2[2]=t4;
C_call_cc(3,av2);}}

/* mutex-specific-set! in k919 in k844 in k691 in k688 */
static void C_ccall f_1343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1343,4,av);}
t4=C_i_check_structure_2(t2,lf[71],lf[76]);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(6),t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k875 in make-thread in k844 in k691 in k688 */
static void C_ccall f_877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_877,2,av);}
t2=C_slot(*((C_word*)lf[30]+1),C_fix(9));
/* srfi-18.scm:100: ##sys#make-thread */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[31]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[31]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[32];
av2[4]=t1;
av2[5]=t2;
tp(6,av2);}}

/* k850 in make-thread in k844 in k691 in k688 */
static void C_ccall f_852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_852,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_857,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
t4=C_i_setslot(t2,C_fix(1),t3);
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1287 in thread-sleep! in k919 in k844 in k691 in k688 */
static void C_ccall f_1289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_1289,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:234: compute-time-limit */
f_695(t2,((C_word*)t0)[3],lf[68]);}

/* compute-time-limit in k691 in k688 */
static void C_fcall f_695(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,5))){
C_save_and_reclaim_args((void *)trf_695,3,t1,t2,t3);}
a=C_alloc(4);
t4=t2;
if(C_truep(t4)){
if(C_truep(C_i_structurep(t2,lf[1]))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_i_numberp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_724,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:51: current-milliseconds */
t6=*((C_word*)lf[2]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* srfi-18.scm:52: ##sys#signal-hook */
t5=*((C_word*)lf[3]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[4];
av2[3]=t3;
av2[4]=lf[5];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,3))){
C_save_and_reclaim((void*)f_1376,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_check_structure_2(t2,lf[71],lf[81]);
t5=C_i_pairp(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1386,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_car(t3);
/* srfi-18.scm:266: compute-time-limit */
f_695(t6,t7,lf[81]);}
else{
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
f_1386(2,av2);}}}

/* a862 in a856 in k850 in make-thread in k844 in k691 in k688 */
static void C_ccall f_863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,3))){
C_save_and_reclaim((void*)f_863,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
t3=C_i_setslot(((C_word*)t0)[2],C_fix(2),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:112: ##sys#thread-kill! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[29];
tp(4,av2);}}

/* k1415 in switch in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1417(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1417,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(3),t1);
/* srfi-18.scm:277: ##sys#schedule */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[3];
tp(2,av2);}}

/* k691 in k688 */
static void C_ccall f_693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,4))){C_save_and_reclaim((void *)f_693,2,av);}
a=C_alloc(30);
t2=C_mutate2(&lf[0] /* (set! compute-time-limit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_695,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[6]+1 /* (set! current-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_733,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[7]+1 /* (set! time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_743,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[10]+1 /* (set! seconds->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_756,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[13]+1 /* (set! time? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_773,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[14]+1 /* (set! raise ...) */,*((C_word*)lf[15]+1));
t8=C_mutate2((C_word*)lf[16]+1 /* (set! join-timeout-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[19]+1 /* (set! abandoned-mutex-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_796,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[21]+1 /* (set! terminated-thread-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_812,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[23]+1 /* (set! uncaught-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_828,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:92: condition-property-accessor */
t13=*((C_word*)lf[109]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=lf[24];
av2[3]=lf[110];
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}

/* k688 */
static void C_ccall f_690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_690,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:36: register-feature! */
t3=*((C_word*)lf[111]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[112];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a856 in k850 in make-thread in k844 in k691 in k688 */
static void C_ccall f_857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_857,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[2],a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:108: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
C_call_with_values(4,av2);}}

/* a2109 in k844 in k691 in k688 */
static void C_ccall f_2110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2110,3,av);}
t3=C_i_check_structure_2(t2,lf[34],lf[39]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(10));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* condition-variable-signal! in k919 in k844 in k691 in k688 */
static void C_ccall f_1871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1871,3,av);}
t3=C_i_check_structure_2(t2,lf[86],lf[95]);
t4=C_slot(t2,C_fix(2));
if(C_truep(C_i_nullp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_slot(t4,C_fix(0));
t6=C_slot(t5,C_fix(3));
t7=C_slot(t4,C_fix(1));
t8=C_i_setslot(t2,C_fix(2),t7);
t9=C_eqp(t6,lf[55]);
if(C_truep(t9)){
if(C_truep(t9)){
/* srfi-18.scm:414: ##sys#thread-basic-unblock! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[96]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[96]+1);
av2[1]=t1;
av2[2]=t5;
tp(3,av2);}}
else{
t10=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t10=C_eqp(t6,lf[59]);
if(C_truep(t10)){
/* srfi-18.scm:414: ##sys#thread-basic-unblock! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[96]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[96]+1);
av2[1]=t1;
av2[2]=t5;
tp(3,av2);}}
else{
t11=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}

/* mutex-state in k919 in k844 in k691 in k688 */
static void C_ccall f_1352(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1352,3,av);}
t3=C_i_check_structure_2(t2,lf[71],lf[77]);
if(C_truep(C_slot(t2,C_fix(5)))){
t4=C_slot(t2,C_fix(2));
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=(C_truep(t4)?t4:lf[78]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_slot(t2,C_fix(4));
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=(C_truep(t4)?lf[79]:lf[80]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* condition-variable-specific-set! in k919 in k844 in k691 in k688 */
static void C_ccall f_1862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1862,4,av);}
t4=C_i_check_structure_2(t2,lf[86],lf[94]);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(3),t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1386,2,av);}
a=C_alloc(7);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_length(t3);
t5=C_fixnum_greaterp(t4,C_fix(1));
t6=t5;
t7=(C_truep(t6)?C_i_cadr(((C_word*)t0)[2]):C_SCHEME_FALSE);
t8=t7;
t9=(C_truep(t8)?C_i_check_structure_2(t8,lf[34],lf[81]):C_SCHEME_UNDEFINED);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=((C_word)li41),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm:270: ##sys#call-with-current-continuation */{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t10;
C_call_cc(3,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_srfi_2d18_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("srfi_2d18_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_srfi_2d18_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(768)){
C_save(t1);
C_rereclaim2(768*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,113);
lf[1]=C_h_intern(&lf[1],4,"time");
lf[2]=C_h_intern(&lf[2],20,"current-milliseconds");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[6]=C_h_intern(&lf[6],12,"current-time");
lf[7]=C_h_intern(&lf[7],13,"time->seconds");
lf[8]=C_h_intern(&lf[8],3,"fp/");
lf[9]=C_decode_literal(C_heaptop,"\376U1000.0\000");
lf[10]=C_h_intern(&lf[10],13,"seconds->time");
lf[11]=C_h_intern(&lf[11],3,"fp\052");
lf[12]=C_h_intern(&lf[12],18,"\003sysexact->inexact");
lf[13]=C_h_intern(&lf[13],5,"time\077");
lf[14]=C_h_intern(&lf[14],5,"raise");
lf[15]=C_h_intern(&lf[15],10,"\003syssignal");
lf[16]=C_h_intern(&lf[16],23,"join-timeout-exception\077");
lf[17]=C_h_intern(&lf[17],9,"condition");
lf[18]=C_h_intern(&lf[18],22,"join-timeout-exception");
lf[19]=C_h_intern(&lf[19],26,"abandoned-mutex-exception\077");
lf[20]=C_h_intern(&lf[20],25,"abandoned-mutex-exception");
lf[21]=C_h_intern(&lf[21],28,"terminated-thread-exception\077");
lf[22]=C_h_intern(&lf[22],27,"terminated-thread-exception");
lf[23]=C_h_intern(&lf[23],19,"uncaught-exception\077");
lf[24]=C_h_intern(&lf[24],18,"uncaught-exception");
lf[25]=C_h_intern(&lf[25],25,"uncaught-exception-reason");
lf[26]=C_h_intern(&lf[26],11,"make-thread");
lf[27]=C_h_intern(&lf[27],12,"\003sysschedule");
lf[28]=C_h_intern(&lf[28],16,"\003systhread-kill!");
lf[29]=C_h_intern(&lf[29],4,"dead");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_h_intern(&lf[31],15,"\003sysmake-thread");
lf[32]=C_h_intern(&lf[32],7,"created");
lf[33]=C_h_intern(&lf[33],6,"gensym");
lf[34]=C_h_intern(&lf[34],6,"thread");
lf[35]=C_h_intern(&lf[35],7,"thread\077");
lf[36]=C_h_intern(&lf[36],14,"current-thread");
lf[37]=C_h_intern(&lf[37],12,"thread-state");
lf[38]=C_h_intern(&lf[38],20,"thread-specific-set!");
lf[39]=C_h_intern(&lf[39],15,"thread-specific");
lf[40]=C_h_intern(&lf[40],14,"thread-quantum");
lf[41]=C_h_intern(&lf[41],19,"thread-quantum-set!");
lf[42]=C_h_intern(&lf[42],11,"thread-name");
lf[43]=C_h_intern(&lf[43],13,"thread-start!");
lf[44]=C_h_intern(&lf[44],5,"ready");
lf[45]=C_h_intern(&lf[45],22,"\003sysadd-to-ready-queue");
lf[46]=C_h_intern(&lf[46],9,"\003syserror");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000&thread cannot be started a second time");
lf[48]=C_h_intern(&lf[48],13,"thread-yield!");
lf[49]=C_h_intern(&lf[49],17,"\003systhread-yield!");
lf[50]=C_h_intern(&lf[50],12,"thread-join!");
lf[51]=C_h_intern(&lf[51],28,"\003sysremove-from-timeout-list");
lf[52]=C_h_intern(&lf[52],10,"terminated");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\001\000\000\006reason");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\377\016");
lf[55]=C_h_intern(&lf[55],7,"blocked");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\026join-timeout-exception\376\377\016");
lf[57]=C_h_intern(&lf[57],33,"\003systhread-block-for-termination!");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\0000Internal scheduler error: unknown thread state: ");
lf[59]=C_h_intern(&lf[59],8,"sleeping");
lf[60]=C_h_intern(&lf[60],29,"\003systhread-block-for-timeout!");
lf[61]=C_h_intern(&lf[61],17,"thread-terminate!");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\033terminated-thread-exception\376\377\016");
lf[63]=C_h_intern(&lf[63],21,"\003sysprimordial-thread");
lf[64]=C_h_intern(&lf[64],16,"\003sysexit-handler");
lf[65]=C_h_intern(&lf[65],15,"thread-suspend!");
lf[66]=C_h_intern(&lf[66],9,"suspended");
lf[67]=C_h_intern(&lf[67],14,"thread-resume!");
lf[68]=C_h_intern(&lf[68],13,"thread-sleep!");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[70]=C_h_intern(&lf[70],6,"mutex\077");
lf[71]=C_h_intern(&lf[71],5,"mutex");
lf[72]=C_h_intern(&lf[72],10,"make-mutex");
lf[73]=C_h_intern(&lf[73],14,"\003sysmake-mutex");
lf[74]=C_h_intern(&lf[74],10,"mutex-name");
lf[75]=C_h_intern(&lf[75],14,"mutex-specific");
lf[76]=C_h_intern(&lf[76],19,"mutex-specific-set!");
lf[77]=C_h_intern(&lf[77],11,"mutex-state");
lf[78]=C_h_intern(&lf[78],9,"not-owned");
lf[79]=C_h_intern(&lf[79],9,"abandoned");
lf[80]=C_h_intern(&lf[80],13,"not-abandoned");
lf[81]=C_h_intern(&lf[81],11,"mutex-lock!");
lf[82]=C_h_intern(&lf[82],10,"\003sysappend");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\031abandoned-mutex-exception\376\377\016");
lf[84]=C_h_intern(&lf[84],8,"\003sysdelq");
lf[85]=C_h_intern(&lf[85],13,"mutex-unlock!");
lf[86]=C_h_intern(&lf[86],18,"condition-variable");
lf[87]=C_h_intern(&lf[87],7,"running");
lf[88]=C_h_intern(&lf[88],12,"mutex-unlock");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\0000Internal scheduler error: unknown thread state: ");
lf[90]=C_h_intern(&lf[90],23,"make-condition-variable");
lf[91]=C_h_intern(&lf[91],19,"condition-variable\077");
lf[92]=C_h_intern(&lf[92],23,"condition-variable-name");
lf[93]=C_h_intern(&lf[93],27,"condition-variable-specific");
lf[94]=C_h_intern(&lf[94],32,"condition-variable-specific-set!");
lf[95]=C_h_intern(&lf[95],26,"condition-variable-signal!");
lf[96]=C_h_intern(&lf[96],25,"\003systhread-basic-unblock!");
lf[97]=C_h_intern(&lf[97],29,"condition-variable-broadcast!");
lf[98]=C_h_intern(&lf[98],8,"for-each");
lf[99]=C_h_intern(&lf[99],14,"thread-signal!");
lf[100]=C_h_intern(&lf[100],19,"\003systhread-unblock!");
lf[101]=C_h_intern(&lf[101],20,"\003sysread-prompt-hook");
lf[102]=C_h_intern(&lf[102],25,"\003systhread-block-for-i/o!");
lf[103]=C_h_intern(&lf[103],6,"\000input");
lf[104]=C_h_intern(&lf[104],13,"\003systty-port\077");
lf[105]=C_h_intern(&lf[105],18,"\003sysstandard-input");
lf[106]=C_h_intern(&lf[106],20,"thread-wait-for-i/o!");
lf[107]=C_h_intern(&lf[107],4,"\000all");
lf[108]=C_h_intern(&lf[108],18,"getter-with-setter");
lf[109]=C_h_intern(&lf[109],27,"condition-property-accessor");
lf[110]=C_h_intern(&lf[110],6,"reason");
lf[111]=C_h_intern(&lf[111],17,"register-feature!");
lf[112]=C_h_intern(&lf[112],7,"srfi-18");
C_register_lf2(lf,113,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_scheduler_toplevel(2,av2);}}

/* terminated-thread-exception? in k691 in k688 */
static void C_ccall f_812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_812,3,av);}
if(C_truep(C_i_structurep(t2,lf[17]))){
t3=C_slot(t2,C_fix(1));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_memq(lf[22],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* make-thread in k844 in k691 in k688 */
static void C_ccall f_848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +7,c,5))){
C_save_and_reclaim((void*)f_848,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+7);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_852,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_877,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(t3))){
t6=C_slot(t3,C_fix(0));
t7=C_slot(*((C_word*)lf[30]+1),C_fix(9));
/* srfi-18.scm:100: ##sys#make-thread */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[31]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[31]+1);
av2[1]=t4;
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[32];
av2[4]=t6;
av2[5]=t7;
tp(6,av2);}}
else{
/* srfi-18.scm:103: gensym */
t6=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[34];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k844 in k691 in k688 */
static void C_ccall f_846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,4))){C_save_and_reclaim((void *)f_846,2,av);}
a=C_alloc(21);
t2=C_mutate2((C_word*)lf[25]+1 /* (set! uncaught-exception-reason ...) */,t1);
t3=C_mutate2((C_word*)lf[26]+1 /* (set! make-thread ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[35]+1 /* (set! thread? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[36]+1 /* (set! current-thread ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_898,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[37]+1 /* (set! thread-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[38]+1 /* (set! thread-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_910,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2110,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:128: getter-with-setter */
t10=*((C_word*)lf[108]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
av2[3]=*((C_word*)lf[38]+1);
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* a2007 in k1995 in thread-signal! in k919 in k844 in k691 in k688 */
static void C_ccall f_2008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2008,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:447: ##sys#signal */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[15]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* uncaught-exception? in k691 in k688 */
static void C_ccall f_828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_828,3,av);}
if(C_truep(C_i_structurep(t2,lf[17]))){
t3=C_slot(t2,C_fix(1));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_memq(lf[24],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2010 in a2007 in k1995 in thread-signal! in k919 in k844 in k691 in k688 */
static void C_ccall f_2012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2012,2,av);}
/* srfi-18.scm:448: old */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k1795 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1797,2,av);}
t2=((C_word*)t0)[2];
f_1650(t2,C_i_setslot(((C_word*)t0)[3],C_fix(8),t1));}

/* mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_1613,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+6);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_check_structure_2(t2,lf[71],lf[85]);
t5=*((C_word*)lf[30]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1620,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t3))){
t7=t3;
t8=t6;
f_1620(t8,C_u_i_car(t7));}
else{
t7=t6;
f_1620(t7,C_SCHEME_FALSE);}}

/* k1777 in k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1779,2,av);}
a=C_alloc(6);
t2=C_i_setslot(((C_word*)t0)[2],C_fix(2),t1);
t3=C_i_setslot(((C_word*)t0)[3],C_fix(11),((C_word*)t0)[2]);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp);
t5=C_i_setslot(((C_word*)t0)[3],C_fix(1),t4);
/* srfi-18.scm:358: ##sys#thread-block-for-timeout! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[60]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[60]+1);
av2[1]=((C_word*)t0)[6];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[5],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t5=C_i_setslot(((C_word*)t0)[3],C_fix(1),t4);
t6=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[59]);
f_1653(2,av2);}}}

/* a1770 in k1777 in k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1771,2,av);}
/* srfi-18.scm:360: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* current-time in k691 in k688 */
static void C_ccall f_733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_733,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_741,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:58: current-milliseconds */
t3=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* thread-state in k844 in k691 in k688 */
static void C_ccall f_901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_901,3,av);}
t3=C_i_check_structure_2(t2,lf[34],lf[37]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1016 in a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_1018,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li20),tmp=(C_word)a,a+=9,tmp);
t3=C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:198: ##sys#thread-block-for-termination! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[2];
tp(4,av2);}}

/* for-each-loop376 in condition-variable-broadcast! in k919 in k844 in k691 in k688 */
static void C_fcall f_1952(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1952,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1962,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_slot(t4,C_fix(3));
t6=C_eqp(t5,lf[55]);
if(C_truep(t6)){
if(C_truep(t6)){
/* srfi-18.scm:423: ##sys#thread-basic-unblock! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[96]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[96]+1);
av2[1]=t3;
av2[2]=t4;
tp(3,av2);}}
else{
t7=C_slot(t2,C_fix(1));
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t7=C_eqp(t5,lf[59]);
if(C_truep(t7)){
/* srfi-18.scm:423: ##sys#thread-basic-unblock! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[96]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[96]+1);
av2[1]=t3;
av2[2]=t4;
tp(3,av2);}}
else{
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* time->seconds in k691 in k688 */
static void C_ccall f_743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_743,3,av);}
t3=C_i_check_structure_2(t2,lf[1],lf[7]);
t4=C_slot(t2,C_fix(1));
/* srfi-18.scm:62: fp/ */
t5=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t4;
av2[3]=lf[9];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_1014,3,av);}
a=C_alloc(9);
t3=*((C_word*)lf[30]+1);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
/* srfi-18.scm:171: ##sys#thread-block-for-timeout! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[60]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[60]+1);
av2[1]=t4;
av2[2]=*((C_word*)lf[30]+1);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_1018(2,av2);}}}

/* thread-specific-set! in k844 in k691 in k688 */
static void C_ccall f_910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_910,4,av);}
t4=C_i_check_structure_2(t2,lf[34],lf[38]);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(10),t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k2079 in k2076 in k2073 in read-prompt-hook in k919 in k844 in k691 in k688 */
static void C_ccall f_2081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2081,2,av);}
/* srfi-18.scm:461: thread-yield! */
t2=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* thread-wait-for-i/o! in k919 in k844 in k691 in k688 */
static void C_ccall f_2089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +3,c,4))){
C_save_and_reclaim((void*)f_2089,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+3);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?lf[107]:C_i_car(t3));
t6=C_i_check_exact_2(t2,lf[106]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2099,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:468: ##sys#thread-block-for-i/o! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[102]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[102]+1);
av2[1]=t7;
av2[2]=*((C_word*)lf[30]+1);
av2[3]=t2;
av2[4]=t5;
tp(5,av2);}}

/* k739 in current-time in k691 in k688 */
static void C_ccall f_741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_741,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_record2(&a,2,lf[1],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1945 in condition-variable-broadcast! in k919 in k844 in k691 in k688 */
static void C_ccall f_1947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1947,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* seconds->time in k691 in k688 */
static void C_ccall f_756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_756,3,av);}
a=C_alloc(6);
t3=C_i_check_number_2(t2,lf[10]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_767,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:66: ##sys#exact->inexact */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[12]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[12]+1);
av2[1]=t5;
av2[2]=t2;
tp(3,av2);}}

/* k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1000,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t5=(C_truep(t4)?C_i_pairp(t4):C_SCHEME_FALSE);
t6=t5;
t7=(C_truep(t6)?C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t6,a[5]=t8,a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm:168: ##sys#call-with-current-continuation */{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t9;
C_call_cc(3,av2);}}

/* k1176 in k1167 in thread-terminate! in k919 in k844 in k691 in k688 */
static void C_ccall f_1178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1178,2,av);}
t2=C_eqp(((C_word*)t0)[2],*((C_word*)lf[30]+1));
if(C_truep(t2)){
/* srfi-18.scm:208: ##sys#schedule */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[3];
tp(2,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##sys#read-prompt-hook in k919 in k844 in k691 in k688 */
static void C_ccall f_2065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2065,2,av);}
a=C_alloc(4);
t2=C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2075,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
f_2075(2,av2);}}
else{
/* srfi-18.scm:458: ##sys#tty-port? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[104]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[104]+1);
av2[1]=t3;
av2[2]=*((C_word*)lf[105]+1);
tp(3,av2);}}}

/* k2097 in thread-wait-for-i/o! in k919 in k844 in k691 in k688 */
static void C_ccall f_2099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2099,2,av);}
/* srfi-18.scm:469: thread-yield! */
t2=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_fcall f_1650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(17,0,3))){
C_save_and_reclaim_args((void *)trf_1650,2,t0,t1);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_slot(((C_word*)t0)[7],C_fix(2));
t5=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* srfi-18.scm:344: ##sys#append */
t6=*((C_word*)lf[82]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_1653(2,av2);}}}

/* k1651 in k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,5))){C_save_and_reclaim((void *)f_1653,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[5]))){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_1656(2,av2);}}
else{
t3=C_slot(((C_word*)t0)[5],C_fix(0));
t4=C_slot(t3,C_fix(3));
t5=C_slot(((C_word*)t0)[5],C_fix(1));
t6=C_i_setslot(((C_word*)t0)[6],C_fix(3),t5);
t7=C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t8=C_eqp(t4,lf[55]);
t9=(C_truep(t8)?t8:C_eqp(t4,lf[59]));
if(C_truep(t9)){
t10=C_i_set_i_slot(t3,C_fix(11),C_SCHEME_FALSE);
/* srfi-18.scm:370: ##sys#add-to-ready-queue */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[45]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[45]+1);
av2[1]=t2;
av2[2]=t3;
tp(3,av2);}}
else{
/* srfi-18.scm:372: ##sys#error */
t10=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t10;
av2[1]=t2;
av2[2]=lf[88];
av2[3]=lf[89];
av2[4]=t3;
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t10+1)))(6,av2);}}}}

/* a1552 in k1540 in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1553,2,av);}
a=C_alloc(6);
if(C_truep(C_slot(((C_word*)t0)[2],C_fix(13)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(3));
/* srfi-18.scm:311: ##sys#delq */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[84]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[84]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
tp(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:315: ##sys#remove-from-timeout-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[51]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[51]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}

/* thread-terminate! in k919 in k844 in k691 in k688 */
static void C_ccall f_1162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1162,3,av);}
a=C_alloc(7);
t3=C_i_check_structure_2(t2,lf[34],lf[61]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1169,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_eqp(t2,*((C_word*)lf[63]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1201,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:204: ##sys#exit-handler */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[64]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[64]+1);
av2[1]=t6;
tp(2,av2);}}
else{
t6=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_1169(2,av2);}}}

/* k765 in seconds->time in k691 in k688 */
static void C_ccall f_767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_767,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_record2(&a,2,lf[1],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1167 in thread-terminate! in k919 in k844 in k691 in k688 */
static void C_ccall f_1169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1169,2,av);}
a=C_alloc(11);
t2=C_a_i_list1(&a,1,C_SCHEME_UNDEFINED);
t3=C_i_setslot(((C_word*)t0)[2],C_fix(2),t2);
t4=C_a_i_record3(&a,3,lf[17],lf[62],C_SCHEME_END_OF_LIST);
t5=C_i_setslot(((C_word*)t0)[2],C_fix(7),t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:207: ##sys#thread-kill! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t6;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[52];
tp(4,av2);}}

/* k2076 in k2073 in read-prompt-hook in k919 in k844 in k691 in k688 */
static void C_ccall f_2078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_2078,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:460: ##sys#thread-block-for-i/o! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[102]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[102]+1);
av2[1]=t2;
av2[2]=*((C_word*)lf[30]+1);
av2[3]=C_fix(0);
av2[4]=lf[103];
tp(5,av2);}}

/* k2073 in read-prompt-hook in k919 in k844 in k691 in k688 */
static void C_ccall f_2075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2075,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:459: old */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1540 in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1542,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp);
t3=C_i_setslot(((C_word*)t0)[2],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:317: ##sys#thread-block-for-timeout! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[60]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[60]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[8];
tp(4,av2);}}

/* k1546 in k1540 in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1548,2,av);}
/* srfi-18.scm:318: switch */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1403(t2,((C_word*)t0)[3]);}

/* k1654 in k1651 in k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1656,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(3));
t3=C_eqp(t2,lf[87]);
if(C_truep(t3)){
/* srfi-18.scm:375: return */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
/* srfi-18.scm:376: ##sys#schedule */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[4];
tp(2,av2);}}}

/* k769 in seconds->time in k691 in k688 */
static void C_ccall f_771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_771,2,av);}
/* srfi-18.scm:66: fp* */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[9];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* time? in k691 in k688 */
static void C_ccall f_773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_773,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[1]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1631,3,av);}
a=C_alloc(8);
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* srfi-18.scm:336: compute-time-limit */
f_695(t5,((C_word*)t0)[5],lf[85]);}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_1638(2,av2);}}}

/* condition-variable-broadcast! in k919 in k844 in k691 in k688 */
static void C_ccall f_1914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_1914,3,av);}
a=C_alloc(10);
t3=C_i_check_structure_2(t2,lf[86],lf[97]);
t4=C_slot(t2,C_fix(2));
t5=C_i_check_list_2(t4,lf[98]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1947,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1952,a[2]=t8,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_1952(t10,t6,t4);}

/* join-timeout-exception? in k691 in k688 */
static void C_ccall f_780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_780,3,av);}
if(C_truep(C_i_structurep(t2,lf[17]))){
t3=C_slot(t2,C_fix(1));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_memq(lf[18],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_fcall f_1620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_1620,2,t0,t1);}
a=C_alloc(7);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_length(t3);
t5=C_fixnum_greaterp(t4,C_fix(1));
t6=(C_truep(t5)?C_i_cadr(((C_word*)t0)[2]):C_SCHEME_FALSE);
t7=t6;
t8=(C_truep(t2)?C_i_check_structure_2(t2,lf[86],lf[85]):C_SCHEME_UNDEFINED);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t7,a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm:333: ##sys#call-with-current-continuation */{
C_word av2[3];
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=t9;
C_call_cc(3,av2);}}

/* k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1638(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_1638,2,av);}
a=C_alloc(13);
t2=t1;
t3=C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),C_SCHEME_FALSE);
t4=C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_SCHEME_FALSE);
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1797,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t10=C_slot(t6,C_fix(8));
/* srfi-18.scm:342: ##sys#delq */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[84]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[84]+1);
av2[1]=t9;
av2[2]=((C_word*)t0)[2];
av2[3]=t10;
tp(4,av2);}}
else{
t8=t7;
f_1650(t8,C_SCHEME_UNDEFINED);}}

/* k962 in k959 in thread-start! in k919 in k844 in k691 in k688 */
static void C_ccall f_964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_964,2,av);}
a=C_alloc(4);
t2=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(3),lf[44]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:155: ##sys#add-to-ready-queue */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[45]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[45]+1);
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
tp(3,av2);}}

/* k2023 in thread-signal! in k919 in k844 in k691 in k688 */
static void C_ccall f_2025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2025,2,av);}
t2=((C_word*)t0)[2];
f_1997(t2,C_i_setslot(((C_word*)t0)[3],C_fix(2),t1));}

/* k959 in thread-start! in k919 in k844 in k691 in k688 */
static void C_fcall f_961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_961,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(3));
t4=C_eqp(lf[32],t3);
if(C_truep(t4)){
t5=t2;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_964(2,av2);}}
else{
/* srfi-18.scm:153: ##sys#error */
t5=*((C_word*)lf[46]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[43];
av2[3]=lf[47];
av2[4]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* abandoned-mutex-exception? in k691 in k688 */
static void C_ccall f_796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_796,3,av);}
if(C_truep(C_i_structurep(t2,lf[17]))){
t3=C_slot(t2,C_fix(1));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_memq(lf[20],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k968 in k962 in k959 in thread-start! in k919 in k844 in k691 in k688 */
static void C_ccall f_970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_970,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k985 in thread-start! in k919 in k844 in k691 in k688 */
static void C_ccall f_987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_987,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_961(t3,t2);}

/* k2040 in thread-signal! in k919 in k844 in k691 in k688 */
static void C_ccall f_2042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2042,2,av);}
t2=((C_word*)t0)[2];
f_1997(t2,C_i_setslot(((C_word*)t0)[3],C_fix(3),t1));}

/* a1232 in a1223 in thread-suspend! in k919 in k844 in k691 in k688 */
static void C_ccall f_1233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1233,2,av);}
/* srfi-18.scm:216: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=C_SCHEME_UNDEFINED;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k1758 in a1732 in k1777 in k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1760,2,av);}
/* srfi-18.scm:357: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,3))){
C_save_and_reclaim((void*)f_993,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=C_i_check_structure_2(t2,lf[34],lf[50]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1000,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t3))){
t6=C_slot(t3,C_fix(0));
/* srfi-18.scm:164: compute-time-limit */
f_695(t5,t6,lf[50]);}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_1000(2,av2);}}}

/* k2057 in thread-signal! in k919 in k844 in k691 in k688 */
static void C_ccall f_2059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2059,2,av);}
t2=((C_word*)t0)[2];
f_1997(t2,C_i_setslot(((C_word*)t0)[3],C_fix(12),t1));}

/* a1223 in thread-suspend! in k919 in k844 in k691 in k688 */
static void C_ccall f_1224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1224,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t2,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t4=C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
/* srfi-18.scm:217: ##sys#schedule */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t1;
tp(2,av2);}}

/* k1751 in a1732 in k1777 in k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1753,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(2),t1);
/* srfi-18.scm:354: return */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* k1097 in k1087 in a1028 in k1016 in a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1099,2,av);}
/* srfi-18.scm:188: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* thread-resume! in k919 in k844 in k691 in k688 */
static void C_ccall f_1239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1239,3,av);}
t3=C_i_check_structure_2(t2,lf[34],lf[67]);
t4=C_slot(t2,C_fix(3));
t5=C_eqp(t4,lf[66]);
if(C_truep(t5)){
t6=C_i_setslot(t2,C_fix(3),lf[44]);
/* srfi-18.scm:223: ##sys#add-to-ready-queue */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[45]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[45]+1);
av2[1]=t1;
av2[2]=t2;
tp(3,av2);}}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k919 in k844 in k691 in k688 */
static void C_ccall f_921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
if(!C_demand(C_calculate_demand(82,c,4))){C_save_and_reclaim((void *)f_921,2,av);}
a=C_alloc(82);
t2=C_mutate2((C_word*)lf[39]+1 /* (set! thread-specific ...) */,t1);
t3=C_mutate2((C_word*)lf[40]+1 /* (set! thread-quantum ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[41]+1 /* (set! thread-quantum-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[42]+1 /* (set! thread-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[43]+1 /* (set! thread-start! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_957,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[48]+1 /* (set! thread-yield! ...) */,*((C_word*)lf[49]+1));
t8=C_mutate2((C_word*)lf[50]+1 /* (set! thread-join! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[61]+1 /* (set! thread-terminate! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1162,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[65]+1 /* (set! thread-suspend! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[67]+1 /* (set! thread-resume! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1239,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[68]+1 /* (set! thread-sleep! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1261,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[70]+1 /* (set! mutex? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[72]+1 /* (set! make-mutex ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[74]+1 /* (set! mutex-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[75]+1 /* (set! mutex-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[76]+1 /* (set! mutex-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[77]+1 /* (set! mutex-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[81]+1 /* (set! mutex-lock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[85]+1 /* (set! mutex-unlock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1613,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[90]+1 /* (set! make-condition-variable ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate2((C_word*)lf[91]+1 /* (set! condition-variable? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1838,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[92]+1 /* (set! condition-variable-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2((C_word*)lf[93]+1 /* (set! condition-variable-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1853,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate2((C_word*)lf[94]+1 /* (set! condition-variable-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate2((C_word*)lf[95]+1 /* (set! condition-variable-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1871,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate2((C_word*)lf[97]+1 /* (set! condition-variable-broadcast! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate2((C_word*)lf[99]+1 /* (set! thread-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1975,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t29=*((C_word*)lf[101]+1);
t30=C_mutate2((C_word*)lf[101]+1 /* (set! ##sys#read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2065,a[2]=t29,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t31=C_mutate2((C_word*)lf[106]+1 /* (set! thread-wait-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2089,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t32=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t32;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t32+1)))(2,av2);}}

/* thread-quantum in k919 in k844 in k691 in k688 */
static void C_ccall f_923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_923,3,av);}
t3=C_i_check_structure_2(t2,lf[34],lf[40]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(9));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1087 in a1028 in k1016 in a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_fcall f_1089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,5))){
C_save_and_reclaim_args((void *)trf_1089,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* srfi-18.scm:188: return */
t3=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}
else{
t3=C_a_i_record3(&a,3,lf[17],lf[56],C_SCHEME_END_OF_LIST);
/* srfi-18.scm:191: ##sys#signal */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[15]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t2;
av2[2]=t3;
tp(3,av2);}}}
else{
/* srfi-18.scm:193: ##sys#thread-block-for-termination! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[57]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[57]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[8];
tp(4,av2);}}}
else{
t2=C_slot(((C_word*)t0)[8],C_fix(3));
/* srfi-18.scm:195: ##sys#error */
t3=*((C_word*)lf[46]+1);{
C_word av2[6];
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[50];
av2[3]=lf[58];
av2[4]=((C_word*)t0)[7];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}}

/* condition-variable-specific in k919 in k844 in k691 in k688 */
static void C_ccall f_1853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1853,3,av);}
t3=C_i_check_structure_2(t2,lf[86],lf[93]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1199 in thread-terminate! in k919 in k844 in k691 in k688 */
static void C_ccall f_1201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1201,2,av);}
/* srfi-18.scm:203: g191 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* thread-quantum-set! in k919 in k844 in k691 in k688 */
static void C_ccall f_932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_932,4,av);}
t4=C_i_check_structure_2(t2,lf[34],lf[41]);
t5=C_i_check_exact_2(t3,lf[41]);
t6=C_i_fixnum_max(t3,C_fix(10));
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_i_set_i_slot(t2,C_fix(9),t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* a1732 in k1777 in k1648 in k1636 in a1630 in k1618 in mutex-unlock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1733,2,av);}
a=C_alloc(5);
t2=C_i_set_i_slot(((C_word*)t0)[2],C_fix(11),C_SCHEME_FALSE);
if(C_truep(C_slot(((C_word*)t0)[2],C_fix(13)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],C_fix(2));
/* srfi-18.scm:353: ##sys#delq */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[84]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[84]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=t4;
tp(4,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:356: ##sys#remove-from-timeout-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[51]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[51]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}

/* k1995 in thread-signal! in k919 in k844 in k691 in k688 */
static void C_fcall f_1997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1997,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
t3=C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[55]);
/* srfi-18.scm:450: ##sys#thread-unblock! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[100]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[100]+1);
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* condition-variable-name in k919 in k844 in k691 in k688 */
static void C_ccall f_1844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1844,3,av);}
t3=C_i_check_structure_2(t2,lf[86],lf[92]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* thread-name in k919 in k844 in k691 in k688 */
static void C_ccall f_948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_948,3,av);}
t3=C_i_check_structure_2(t2,lf[34],lf[42]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(6));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* condition-variable? in k919 in k844 in k691 in k688 */
static void C_ccall f_1838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1838,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[86]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1066 in a1028 in k1016 in a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1068,2,av);}
/* srfi-18.scm:181: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* thread-start! in k919 in k844 in k691 in k688 */
static void C_ccall f_957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_957,3,av);}
a=C_alloc(10);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_961,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_987,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:150: make-thread */
t6=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t3)[1];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t4;
f_961(t5,C_i_check_structure_2(((C_word*)t3)[1],lf[34],lf[43]));}}

/* k1827 in make-condition-variable in k919 in k844 in k691 in k688 */
static void C_ccall f_1829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_1829,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_record4(&a,4,lf[86],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a1269 in k1294 in k1287 in thread-sleep! in k919 in k844 in k691 in k688 */
static void C_ccall f_1270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1270,3,av);}
a=C_alloc(7);
t3=*((C_word*)lf[30]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1282,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t5=C_i_setslot(*((C_word*)lf[30]+1),C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:231: ##sys#thread-block-for-timeout! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[60]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[60]+1);
av2[1]=t6;
av2[2]=*((C_word*)lf[30]+1);
av2[3]=((C_word*)t0)[2];
tp(4,av2);}}

/* thread-signal! in k919 in k844 in k691 in k688 */
static void C_ccall f_1975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_1975,4,av);}
a=C_alloc(10);
t4=C_i_check_structure_2(t2,lf[34],lf[99]);
t5=C_eqp(t2,*((C_word*)lf[30]+1));
if(C_truep(t5)){
/* srfi-18.scm:434: ##sys#signal */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[15]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t1;
av2[2]=t3;
tp(3,av2);}}
else{
t6=C_slot(t2,C_fix(1));
t7=t6;
t8=C_slot(t2,C_fix(11));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1997,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_structurep(t9,lf[86]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2025,a[2]=t10,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t12=C_slot(t9,C_fix(2));
/* srfi-18.scm:439: ##sys#delq */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[84]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[84]+1);
av2[1]=t11;
av2[2]=t2;
av2[3]=t12;
tp(4,av2);}}
else{
if(C_truep(C_i_structurep(t9,lf[71]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=t10,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t12=C_slot(t9,C_fix(3));
/* srfi-18.scm:441: ##sys#delq */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[84]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[84]+1);
av2[1]=t11;
av2[2]=t2;
av2[3]=t12;
tp(4,av2);}}
else{
if(C_truep(C_i_structurep(t9,lf[34]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2059,a[2]=t10,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t12=C_slot(t9,C_fix(12));
/* srfi-18.scm:443: ##sys#delq */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[84]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[84]+1);
av2[1]=t11;
av2[2]=t2;
av2[3]=t12;
tp(4,av2);}}
else{
t11=t10;
f_1997(t11,C_SCHEME_UNDEFINED);}}}}}

/* thread-suspend! in k919 in k844 in k691 in k688 */
static void C_ccall f_1206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1206,3,av);}
a=C_alloc(4);
t3=C_i_check_structure_2(t2,lf[34],lf[65]);
t4=C_i_setslot(t2,C_fix(3),lf[66]);
t5=C_eqp(t2,*((C_word*)lf[30]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1224,a[2]=t2,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:214: ##sys#call-with-current-continuation */{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t6;
C_call_cc(3,av2);}}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k1463 in k1460 in assign in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1465,2,av);}
/* srfi-18.scm:300: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k1460 in assign in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1462,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[4])?C_i_not(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
/* srfi-18.scm:300: return */
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}
else{
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[7]);
t5=C_slot(t4,C_fix(3));
t6=C_eqp(lf[52],t5);
t7=(C_truep(t6)?t6:C_eqp(lf[29],t5));
if(C_truep(t7)){
t8=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t9=C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_FALSE);
t10=C_i_set_i_slot(((C_word*)t0)[6],C_fix(4),C_SCHEME_TRUE);
/* srfi-18.scm:295: check */
t11=((C_word*)((C_word*)t0)[8])[1];
f_1427(t11,t2);}
else{
t8=C_i_setslot(((C_word*)t0)[6],C_fix(2),t4);
t9=C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t10=C_slot(t4,C_fix(8));
t11=C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=C_i_setslot(t4,C_fix(8),t11);
/* srfi-18.scm:300: return */
t13=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t13))(3,av2);}}}}

/* make-condition-variable in k919 in k844 in k691 in k688 */
static void C_ccall f_1821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +8,c,2))){
C_save_and_reclaim((void*)f_1821,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+8);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[86],t5,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* srfi-18.scm:386: gensym */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[86];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* thread-sleep! in k919 in k844 in k691 in k688 */
static void C_ccall f_1261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_1261,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1289,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_1289(2,av2);}}
else{
/* srfi-18.scm:233: ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[4];
av2[3]=lf[68];
av2[4]=lf[69];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}}

/* mutex-name in k919 in k844 in k691 in k688 */
static void C_ccall f_1325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1325,3,av);}
t3=C_i_check_structure_2(t2,lf[71],lf[74]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1960 in for-each-loop376 in condition-variable-broadcast! in k919 in k844 in k691 in k688 */
static void C_ccall f_1962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1962,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1952(t3,((C_word*)t0)[4],t2);}

/* k1275 in a1269 in k1294 in k1287 in thread-sleep! in k919 in k844 in k691 in k688 */
static void C_ccall f_1277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1277,2,av);}
/* srfi-18.scm:232: ##sys#schedule */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[2];
tp(2,av2);}}

/* k1040 in a1028 in k1016 in a1013 in k998 in thread-join! in k919 in k844 in k691 in k688 */
static void C_ccall f_1042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1042,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(2));{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
C_apply(4,av2);}}

/* k722 in compute-time-limit in k691 in k688 */
static void C_ccall f_724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_724,2,av);}
a=C_alloc(8);
t2=C_a_i_times(&a,2,((C_word*)t0)[2],C_fix(1000));
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_plus(&a,2,t1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1439 in check in a1399 in k1384 in mutex-lock! in k919 in k844 in k691 in k688 */
static void C_ccall f_1441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1441,2,av);}
/* srfi-18.scm:280: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[121] = {
{"f_1301:srfi_2d18_2escm",(void*)f_1301},
{"f_1029:srfi_2d18_2escm",(void*)f_1029},
{"f_1580:srfi_2d18_2escm",(void*)f_1580},
{"f_1307:srfi_2d18_2escm",(void*)f_1307},
{"f_1024:srfi_2d18_2escm",(void*)f_1024},
{"f_1573:srfi_2d18_2escm",(void*)f_1573},
{"f_1334:srfi_2d18_2escm",(void*)f_1334},
{"f_892:srfi_2d18_2escm",(void*)f_892},
{"f_1427:srfi_2d18_2escm",(void*)f_1427},
{"f_898:srfi_2d18_2escm",(void*)f_898},
{"f_1455:srfi_2d18_2escm",(void*)f_1455},
{"f_870:srfi_2d18_2escm",(void*)f_870},
{"f_1282:srfi_2d18_2escm",(void*)f_1282},
{"f_1311:srfi_2d18_2escm",(void*)f_1311},
{"f_1403:srfi_2d18_2escm",(void*)f_1403},
{"f_1400:srfi_2d18_2escm",(void*)f_1400},
{"f_1296:srfi_2d18_2escm",(void*)f_1296},
{"f_1343:srfi_2d18_2escm",(void*)f_1343},
{"f_877:srfi_2d18_2escm",(void*)f_877},
{"f_852:srfi_2d18_2escm",(void*)f_852},
{"f_1289:srfi_2d18_2escm",(void*)f_1289},
{"f_695:srfi_2d18_2escm",(void*)f_695},
{"f_1376:srfi_2d18_2escm",(void*)f_1376},
{"f_863:srfi_2d18_2escm",(void*)f_863},
{"f_1417:srfi_2d18_2escm",(void*)f_1417},
{"f_693:srfi_2d18_2escm",(void*)f_693},
{"f_690:srfi_2d18_2escm",(void*)f_690},
{"f_857:srfi_2d18_2escm",(void*)f_857},
{"f_2110:srfi_2d18_2escm",(void*)f_2110},
{"f_1871:srfi_2d18_2escm",(void*)f_1871},
{"f_1352:srfi_2d18_2escm",(void*)f_1352},
{"f_1862:srfi_2d18_2escm",(void*)f_1862},
{"f_1386:srfi_2d18_2escm",(void*)f_1386},
{"toplevel:srfi_2d18_2escm",(void*)C_srfi_2d18_toplevel},
{"f_812:srfi_2d18_2escm",(void*)f_812},
{"f_848:srfi_2d18_2escm",(void*)f_848},
{"f_846:srfi_2d18_2escm",(void*)f_846},
{"f_2008:srfi_2d18_2escm",(void*)f_2008},
{"f_828:srfi_2d18_2escm",(void*)f_828},
{"f_2012:srfi_2d18_2escm",(void*)f_2012},
{"f_1797:srfi_2d18_2escm",(void*)f_1797},
{"f_1613:srfi_2d18_2escm",(void*)f_1613},
{"f_1779:srfi_2d18_2escm",(void*)f_1779},
{"f_1771:srfi_2d18_2escm",(void*)f_1771},
{"f_733:srfi_2d18_2escm",(void*)f_733},
{"f_901:srfi_2d18_2escm",(void*)f_901},
{"f_1018:srfi_2d18_2escm",(void*)f_1018},
{"f_1952:srfi_2d18_2escm",(void*)f_1952},
{"f_743:srfi_2d18_2escm",(void*)f_743},
{"f_1014:srfi_2d18_2escm",(void*)f_1014},
{"f_910:srfi_2d18_2escm",(void*)f_910},
{"f_2081:srfi_2d18_2escm",(void*)f_2081},
{"f_2089:srfi_2d18_2escm",(void*)f_2089},
{"f_741:srfi_2d18_2escm",(void*)f_741},
{"f_1947:srfi_2d18_2escm",(void*)f_1947},
{"f_756:srfi_2d18_2escm",(void*)f_756},
{"f_1000:srfi_2d18_2escm",(void*)f_1000},
{"f_1178:srfi_2d18_2escm",(void*)f_1178},
{"f_2065:srfi_2d18_2escm",(void*)f_2065},
{"f_2099:srfi_2d18_2escm",(void*)f_2099},
{"f_1650:srfi_2d18_2escm",(void*)f_1650},
{"f_1653:srfi_2d18_2escm",(void*)f_1653},
{"f_1553:srfi_2d18_2escm",(void*)f_1553},
{"f_1162:srfi_2d18_2escm",(void*)f_1162},
{"f_767:srfi_2d18_2escm",(void*)f_767},
{"f_1169:srfi_2d18_2escm",(void*)f_1169},
{"f_2078:srfi_2d18_2escm",(void*)f_2078},
{"f_2075:srfi_2d18_2escm",(void*)f_2075},
{"f_1542:srfi_2d18_2escm",(void*)f_1542},
{"f_1548:srfi_2d18_2escm",(void*)f_1548},
{"f_1656:srfi_2d18_2escm",(void*)f_1656},
{"f_771:srfi_2d18_2escm",(void*)f_771},
{"f_773:srfi_2d18_2escm",(void*)f_773},
{"f_1631:srfi_2d18_2escm",(void*)f_1631},
{"f_1914:srfi_2d18_2escm",(void*)f_1914},
{"f_780:srfi_2d18_2escm",(void*)f_780},
{"f_1620:srfi_2d18_2escm",(void*)f_1620},
{"f_1638:srfi_2d18_2escm",(void*)f_1638},
{"f_964:srfi_2d18_2escm",(void*)f_964},
{"f_2025:srfi_2d18_2escm",(void*)f_2025},
{"f_961:srfi_2d18_2escm",(void*)f_961},
{"f_796:srfi_2d18_2escm",(void*)f_796},
{"f_970:srfi_2d18_2escm",(void*)f_970},
{"f_987:srfi_2d18_2escm",(void*)f_987},
{"f_2042:srfi_2d18_2escm",(void*)f_2042},
{"f_1233:srfi_2d18_2escm",(void*)f_1233},
{"f_1760:srfi_2d18_2escm",(void*)f_1760},
{"f_993:srfi_2d18_2escm",(void*)f_993},
{"f_2059:srfi_2d18_2escm",(void*)f_2059},
{"f_1224:srfi_2d18_2escm",(void*)f_1224},
{"f_1753:srfi_2d18_2escm",(void*)f_1753},
{"f_1099:srfi_2d18_2escm",(void*)f_1099},
{"f_1239:srfi_2d18_2escm",(void*)f_1239},
{"f_921:srfi_2d18_2escm",(void*)f_921},
{"f_923:srfi_2d18_2escm",(void*)f_923},
{"f_1089:srfi_2d18_2escm",(void*)f_1089},
{"f_1853:srfi_2d18_2escm",(void*)f_1853},
{"f_1201:srfi_2d18_2escm",(void*)f_1201},
{"f_932:srfi_2d18_2escm",(void*)f_932},
{"f_1733:srfi_2d18_2escm",(void*)f_1733},
{"f_1997:srfi_2d18_2escm",(void*)f_1997},
{"f_1844:srfi_2d18_2escm",(void*)f_1844},
{"f_948:srfi_2d18_2escm",(void*)f_948},
{"f_1838:srfi_2d18_2escm",(void*)f_1838},
{"f_1068:srfi_2d18_2escm",(void*)f_1068},
{"f_957:srfi_2d18_2escm",(void*)f_957},
{"f_1829:srfi_2d18_2escm",(void*)f_1829},
{"f_1270:srfi_2d18_2escm",(void*)f_1270},
{"f_1975:srfi_2d18_2escm",(void*)f_1975},
{"f_1206:srfi_2d18_2escm",(void*)f_1206},
{"f_1465:srfi_2d18_2escm",(void*)f_1465},
{"f_1462:srfi_2d18_2escm",(void*)f_1462},
{"f_1821:srfi_2d18_2escm",(void*)f_1821},
{"f_1261:srfi_2d18_2escm",(void*)f_1261},
{"f_1325:srfi_2d18_2escm",(void*)f_1325},
{"f_1962:srfi_2d18_2escm",(void*)f_1962},
{"f_1277:srfi_2d18_2escm",(void*)f_1277},
{"f_1042:srfi_2d18_2escm",(void*)f_1042},
{"f_724:srfi_2d18_2escm",(void*)f_724},
{"f_1441:srfi_2d18_2escm",(void*)f_1441},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  ##sys#for-each		1
o|eliminated procedure checks: 127 
o|specializations:
o|  2 (car pair)
o|  2 (length list)
o|  7 (eqv? * (not float))
(o e)|safe calls: 127 
o|Removed `not' forms: 2 
o|contracted procedure: k700 
o|inlining procedure: k697 
o|inlining procedure: k712 
o|inlining procedure: k712 
o|inlining procedure: k697 
o|inlining procedure: k782 
o|inlining procedure: k782 
o|inlining procedure: k798 
o|inlining procedure: k798 
o|inlining procedure: k814 
o|inlining procedure: k814 
o|inlining procedure: k830 
o|inlining procedure: k830 
o|inlining procedure: k1034 
o|inlining procedure: k1034 
o|inlining procedure: k1081 
o|inlining procedure: k1097 
o|inlining procedure: k1097 
o|inlining procedure: k1081 
o|inlining procedure: k1120 
o|inlining procedure: k1120 
o|substituted constant variable: a1127 
o|substituted constant variable: a1129 
o|substituted constant variable: a1131 
o|substituted constant variable: a1133 
o|substituted constant variable: a1135 
o|propagated global variable: ct171 ##sys#current-thread 
o|inlining procedure: k1179 
o|inlining procedure: k1179 
o|inlining procedure: k1214 
o|inlining procedure: k1214 
o|inlining procedure: k1244 
o|inlining procedure: k1244 
o|contracted procedure: "(srfi-18.scm:234) sleep210" 
o|propagated global variable: ct213 ##sys#current-thread 
o|inlining procedure: k1309 
o|inlining procedure: k1309 
o|inlining procedure: k1357 
o|inlining procedure: k1357 
o|inlining procedure: k1429 
o|inlining procedure: k1429 
o|inlining procedure: k1463 
o|inlining procedure: k1463 
o|contracted procedure: k1531 
o|inlining procedure: k1528 
o|inlining procedure: k1555 
o|inlining procedure: k1555 
o|inlining procedure: k1528 
o|inlining procedure: k1657 
o|inlining procedure: k1657 
o|inlining procedure: k1688 
o|inlining procedure: k1688 
o|substituted constant variable: a1710 
o|substituted constant variable: a1712 
o|inlining procedure: k1723 
o|inlining procedure: k1738 
o|inlining procedure: k1738 
o|inlining procedure: k1723 
o|inlining procedure: k1827 
o|inlining procedure: k1827 
o|inlining procedure: k1879 
o|inlining procedure: k1879 
o|inlining procedure: k1954 
o|contracted procedure: "(srfi-18.scm:419) g377384" 
o|inlining procedure: k1924 
o|inlining procedure: k1924 
o|inlining procedure: k1954 
o|inlining procedure: k1980 
o|inlining procedure: k1980 
o|inlining procedure: k2030 
o|inlining procedure: k2030 
o|inlining procedure: k2067 
o|inlining procedure: k2067 
o|replaced variables: 220 
o|removed binding forms: 151 
o|substituted constant variable: r6982121 
o|substituted constant variable: r7832123 
o|substituted constant variable: r7992125 
o|substituted constant variable: r8152127 
o|substituted constant variable: r8312129 
o|replaced variables: 3 
o|removed binding forms: 228 
o|inlining procedure: k1900 
o|inlining procedure: k1930 
o|replaced variables: 1 
o|removed binding forms: 8 
o|removed binding forms: 1 
o|simplifications: ((if . 14) (##core#call . 224)) 
o|  call simplifications:
o|    ##sys#fudge
o|    ##sys#check-list
o|    ##sys#list
o|    fx>	2
o|    cadr	2
o|    not
o|    cons
o|    null?	4
o|    car	3
o|    ##sys#call-with-current-continuation	5
o|    list	4
o|    apply
o|    procedure?
o|    eq?	20
o|    ##sys#check-exact	2
o|    fxmax
o|    ##sys#setislot	15
o|    pair?	8
o|    ##sys#call-with-values
o|    ##sys#setslot	36
o|    memq	4
o|    ##sys#check-number
o|    ##sys#check-structure	26
o|    ##sys#make-structure	8
o|    ##sys#structure?	12
o|    number?
o|    *
o|    +
o|    ##sys#slot	60
o|contracted procedure: k706 
o|contracted procedure: k715 
o|contracted procedure: k726 
o|contracted procedure: k745 
o|contracted procedure: k752 
o|contracted procedure: k758 
o|contracted procedure: k785 
o|contracted procedure: k792 
o|contracted procedure: k801 
o|contracted procedure: k808 
o|contracted procedure: k817 
o|contracted procedure: k824 
o|contracted procedure: k833 
o|contracted procedure: k840 
o|contracted procedure: k865 
o|contracted procedure: k853 
o|contracted procedure: k879 
o|contracted procedure: k882 
o|contracted procedure: k903 
o|contracted procedure: k912 
o|contracted procedure: k925 
o|contracted procedure: k934 
o|contracted procedure: k937 
o|contracted procedure: k944 
o|contracted procedure: k950 
o|contracted procedure: k965 
o|contracted procedure: k978 
o|contracted procedure: k971 
o|contracted procedure: k981 
o|contracted procedure: k995 
o|contracted procedure: k1145 
o|contracted procedure: k1001 
o|contracted procedure: k1004 
o|contracted procedure: k1007 
o|contracted procedure: k1031 
o|contracted procedure: k1037 
o|contracted procedure: k1047 
o|contracted procedure: k1050 
o|contracted procedure: k1059 
o|contracted procedure: k1078 
o|contracted procedure: k1074 
o|contracted procedure: k1070 
o|contracted procedure: k1084 
o|contracted procedure: k1104 
o|contracted procedure: k1114 
o|contracted procedure: k1117 
o|contracted procedure: k1019 
o|contracted procedure: k1151 
o|contracted procedure: k1158 
o|contracted procedure: k1164 
o|contracted procedure: k1193 
o|contracted procedure: k1170 
o|contracted procedure: k1189 
o|contracted procedure: k1173 
o|contracted procedure: k1182 
o|contracted procedure: k1196 
o|contracted procedure: k1208 
o|contracted procedure: k1211 
o|contracted procedure: k1217 
o|contracted procedure: k1226 
o|contracted procedure: k1241 
o|contracted procedure: k1257 
o|contracted procedure: k1247 
o|contracted procedure: k1250 
o|contracted procedure: k1272 
o|propagated global variable: ct213 ##sys#current-thread 
o|contracted procedure: k1315 
o|inlining procedure: k1309 
o|contracted procedure: k1327 
o|contracted procedure: k1336 
o|contracted procedure: k1345 
o|contracted procedure: k1354 
o|contracted procedure: k1360 
o|contracted procedure: k1363 
o|contracted procedure: k1372 
o|contracted procedure: k1378 
o|contracted procedure: k1381 
o|contracted procedure: k1387 
o|contracted procedure: k1390 
o|contracted procedure: k1393 
o|contracted procedure: k1405 
o|contracted procedure: k1408 
o|contracted procedure: k1419 
o|contracted procedure: k1423 
o|contracted procedure: k1432 
o|contracted procedure: k1451 
o|contracted procedure: k1447 
o|contracted procedure: k1443 
o|contracted procedure: k1457 
o|contracted procedure: k1469 
o|contracted procedure: k1472 
o|inlining procedure: k1463 
o|contracted procedure: k1478 
o|contracted procedure: k1481 
o|contracted procedure: k1487 
o|contracted procedure: k1490 
o|contracted procedure: k1493 
o|contracted procedure: k1496 
o|contracted procedure: k1499 
o|contracted procedure: k1505 
o|contracted procedure: k1508 
o|contracted procedure: k1519 
o|contracted procedure: k1515 
o|inlining procedure: k1463 
o|contracted procedure: k1594 
o|contracted procedure: k1558 
o|contracted procedure: k1561 
o|contracted procedure: k1564 
o|contracted procedure: k1575 
o|contracted procedure: k1543 
o|contracted procedure: k1584 
o|contracted procedure: k1587 
o|contracted procedure: k1609 
o|contracted procedure: k1615 
o|contracted procedure: k1808 
o|contracted procedure: k1621 
o|contracted procedure: k1624 
o|contracted procedure: k1633 
o|contracted procedure: k1639 
o|contracted procedure: k1642 
o|contracted procedure: k1645 
o|contracted procedure: k1670 
o|contracted procedure: k1660 
o|contracted procedure: k1673 
o|contracted procedure: k1676 
o|contracted procedure: k1679 
o|contracted procedure: k1714 
o|contracted procedure: k1682 
o|contracted procedure: k1685 
o|contracted procedure: k1691 
o|contracted procedure: k1694 
o|contracted procedure: k1697 
o|contracted procedure: k1717 
o|contracted procedure: k1720 
o|contracted procedure: k1735 
o|contracted procedure: k1741 
o|contracted procedure: k1744 
o|contracted procedure: k1755 
o|contracted procedure: k1726 
o|contracted procedure: k1764 
o|contracted procedure: k1781 
o|contracted procedure: k1785 
o|contracted procedure: k1788 
o|contracted procedure: k1799 
o|contracted procedure: k1816 
o|contracted procedure: k1830 
o|contracted procedure: k1846 
o|contracted procedure: k1855 
o|contracted procedure: k1864 
o|contracted procedure: k1873 
o|contracted procedure: k1876 
o|contracted procedure: k1882 
o|contracted procedure: k1885 
o|contracted procedure: k1888 
o|contracted procedure: k1910 
o|contracted procedure: k1891 
o|contracted procedure: k1897 
o|contracted procedure: k1900 
o|contracted procedure: k1916 
o|contracted procedure: k1939 
o|contracted procedure: k1942 
o|contracted procedure: k1957 
o|contracted procedure: k1967 
o|contracted procedure: k1971 
o|contracted procedure: k1921 
o|contracted procedure: k1927 
o|contracted procedure: k1930 
o|contracted procedure: k1977 
o|contracted procedure: k1983 
o|contracted procedure: k1989 
o|contracted procedure: k1992 
o|contracted procedure: k1998 
o|contracted procedure: k2001 
o|contracted procedure: k2016 
o|contracted procedure: k2027 
o|contracted procedure: k2033 
o|contracted procedure: k2044 
o|contracted procedure: k2050 
o|contracted procedure: k2061 
o|contracted procedure: k2070 
o|contracted procedure: k2103 
o|contracted procedure: k2091 
o|contracted procedure: k2094 
o|contracted procedure: k2112 
o|simplifications: ((let . 24)) 
o|removed binding forms: 180 
o|inlining procedure: k875 
o|inlining procedure: k1040 
o|replaced variables: 53 
o|inlining procedure: k1960 
o|inlining procedure: k1960 
o|simplifications: ((if . 1)) 
o|replaced variables: 1 
o|removed binding forms: 25 
o|removed binding forms: 3 
o|removed binding forms: 2 
o|customizable procedures: (k1995 for-each-loop376391 k1618 k1648 switch263 check264 compute-time-limit k1087 k959) 
o|calls to known targets: 38 
o|identified direct recursive calls: f_1952 2 
o|fast box initializations: 4 
o|fast global references: 4 
o|fast global assignments: 1 
o|dropping unused closure argument: f_695 
*/
/* end of file */
