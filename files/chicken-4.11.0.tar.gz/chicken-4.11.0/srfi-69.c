/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:48
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: srfi-69.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file srfi-69.c
   unit: srfi_2d69
*/

#include "chicken.h"

#define C_rnd_fix() (C_fix(rand()))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[124];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,56,54,32,114,110,100,56,55,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,29),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,57,52,32,46,32,116,109,112,57,51,57,53,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,49,55,56,32,46,32,116,109,112,49,55,55,49,55,57,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,50,48,57,32,46,32,116,109,112,50,48,56,50,49,48,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,50,52,48,32,46,32,121,50,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,33),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,50,52,57,32,46,32,116,109,112,50,52,56,50,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,101,113,63,45,104,97,115,104,32,111,98,106,51,48,55,32,46,32,116,109,112,51,48,54,51,48,56,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,101,113,118,63,45,104,97,115,104,32,111,98,106,52,48,53,32,46,32,116,109,112,52,48,52,52,48,54,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,104,115,104,52,52,56,32,105,52,52,57,32,108,101,110,52,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,53),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,52,52,49,32,115,101,101,100,52,52,50,32,100,101,112,116,104,52,52,51,32,115,116,97,114,116,52,52,52,32,114,110,100,52,52,53,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,20),40,103,53,50,53,32,111,98,106,53,50,55,32,114,110,100,53,50,56,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,20),40,103,53,51,57,32,111,98,106,53,52,49,32,114,110,100,53,52,50,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,103,53,52,51,32,111,98,106,53,52,53,32,114,110,100,53,52,54,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,39),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,52,53,50,32,100,101,112,116,104,52,53,51,32,114,110,100,52,53,52,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,28),40,42,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,52,51,55,32,114,110,100,52,51,56,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,32),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,53,53,53,32,46,32,116,109,112,53,53,52,53,53,54,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,53,56,51,32,46,32,116,109,112,53,56,50,53,56,52,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,54,50,54,32,46,32,116,109,112,54,50,53,54,50,55,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,54,55,57,32,114,101,113,54,56,48,41,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,27),40,102,95,51,53,56,49,32,111,98,106,101,99,116,55,48,50,32,98,111,117,110,100,55,48,51,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,27),40,102,95,51,53,56,54,32,111,98,106,101,99,116,55,48,52,32,98,111,117,110,100,55,48,53,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,27),40,102,95,51,53,57,49,32,111,98,106,101,99,116,55,48,54,32,98,111,117,110,100,55,48,55,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,38),40,42,109,97,107,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,117,115,101,114,45,102,117,110,99,116,105,111,110,55,48,48,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,86),40,42,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,55,49,56,32,104,97,115,104,55,49,57,32,108,101,110,55,50,48,32,109,105,110,45,108,111,97,100,55,50,49,32,109,97,120,45,108,111,97,100,55,50,50,32,105,110,105,116,105,97,108,55,50,53,32,116,109,112,55,49,55,55,50,54,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,19),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,55,57,53,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,8),40,102,95,51,56,51,57,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,55,57,50,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,55,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,20),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,56,50,56,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,56,51,48,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,56,51,51,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,56,51,54,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,56,51,57,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,56,52,50,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,56,52,53,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,56,52,56,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,56,53,49,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,56,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,54,56,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,54,52,32,105,56,54,54,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,114,101,115,105,122,101,33,32,104,116,56,55,55,32,118,101,99,56,55,56,32,108,101,110,56,55,57,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,21),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,56,57,53,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,57,49,32,105,56,57,51,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,24),40,42,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,56,56,54,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,57,48,51,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,53,49,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,54,48,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,8),40,102,95,52,54,48,49,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,53),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,57,49,50,32,107,101,121,57,49,51,32,102,117,110,99,57,49,52,32,46,32,116,109,112,57,49,49,57,49,53,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,57),40,42,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,57,55,52,32,107,101,121,57,55,53,32,102,117,110,99,57,55,54,32,100,101,102,57,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,60),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,48,50,51,32,107,101,121,49,48,50,52,32,102,117,110,99,49,48,50,53,32,100,101,102,49,48,50,54,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,49,48,51,49,32,107,101,121,49,48,51,50,32,118,97,108,49,48,51,51,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,47),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,49,49,48,51,32,107,101,121,49,49,48,52,32,100,101,102,49,49,48,53,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,49,49,50,49,32,107,101,121,49,49,50,50,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,49,54,53,32,98,117,99,107,101,116,49,49,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,49,49,52,54,32,107,101,121,49,49,52,55,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,49,56,52,32,98,117,99,107,101,116,49,49,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,56,48,32,105,49,49,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,36),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,49,49,55,53,32,102,117,110,99,49,49,55,54,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,49,49,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,13),40,97,53,53,56,53,32,120,49,50,49,50,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,50,48,56,32,108,115,116,49,50,49,48,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,48,53,32,105,49,50,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,36),40,42,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,50,48,49,32,104,116,50,49,50,48,50,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,50,49,56,32,104,116,50,49,50,49,57,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,49,50,50,51,32,104,116,50,49,50,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,50,51,53,32,108,115,116,49,50,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,51,50,32,108,115,116,49,50,51,51,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,49,50,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,97,53,55,49,52,32,120,49,50,53,56,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,13),40,103,49,50,52,56,32,120,49,50,53,55,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,50,52,55,32,103,49,50,53,52,49,50,54,49,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,40),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,49,50,52,50,32,46,32,114,101,115,116,49,50,52,51,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,50,55,53,32,108,115,116,49,50,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,55,50,32,108,115,116,49,50,55,51,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,49,50,54,56,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,50,56,57,32,108,115,116,49,50,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,56,54,32,108,115,116,49,50,56,55,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,49,50,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,103,49,51,48,54,32,98,117,99,107,101,116,49,51,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,51,48,53,32,103,49,51,49,50,49,51,49,55,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,51,48,48,32,105,49,51,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,38),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,50,57,54,32,112,114,111,99,49,50,57,55,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,26),40,102,111,108,100,50,32,98,117,99,107,101,116,49,51,51,51,32,97,99,99,49,51,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,51,51,48,32,97,99,99,49,51,51,49,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,43),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,51,50,52,32,102,117,110,99,49,51,50,53,32,105,110,105,116,49,51,50,54,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,42),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,51,51,57,32,102,117,110,99,49,51,52,48,32,105,110,105,116,49,51,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,51,52,53,32,112,114,111,99,49,51,52,54,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,49,51,53,48,32,112,114,111,99,49,51,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,25),40,97,54,48,54,52,32,107,49,51,53,55,32,118,49,51,53,56,32,97,49,51,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,49,51,53,53,32,102,117,110,99,49,51,53,54,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,23),40,97,54,48,55,55,32,104,116,49,51,54,50,32,112,111,114,116,49,51,54,51,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,8),40,102,95,54,50,49,52,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,36),40,97,54,48,57,51,32,104,116,49,48,55,57,32,107,101,121,49,48,56,48,32,46,32,116,109,112,49,48,55,56,49,48,56,49,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,12),40,97,54,50,50,50,32,120,52,51,51,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,12),40,97,54,50,51,54,32,120,52,50,56,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word *av) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word *av) C_noret;
C_noret_decl(f_5979)
static void C_fcall f_5979(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5365)
static void C_fcall f_5365(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word *av) C_noret;
C_noret_decl(f_5963)
static void C_fcall f_5963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5828)
static void C_fcall f_5828(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4719)
static void C_fcall f_4719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word *av) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word *av) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word *av) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word *av) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word *av) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word *av) C_noret;
C_noret_decl(f_5844)
static void C_fcall f_5844(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word *av) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word *av) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word *av) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word *av) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word *av) C_noret;
C_noret_decl(f_5014)
static void C_fcall f_5014(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word *av) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word *av) C_noret;
C_noret_decl(f_4140)
static void C_fcall f_4140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word *av) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word *av) C_noret;
C_noret_decl(f_5460)
static void C_fcall f_5460(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word *av) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word *av) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word *av) C_noret;
C_noret_decl(f_5434)
static void C_fcall f_5434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word *av) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word *av) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word *av) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word *av) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word *av) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word *av) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word *av) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word *av) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word *av) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word *av) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word *av) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word *av) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word *av) C_noret;
C_noret_decl(f_3770)
static void C_fcall f_3770(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word *av) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word *av) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word *av) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word *av) C_noret;
C_noret_decl(f_4656)
static void C_fcall f_4656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_fcall f_4650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word *av) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word *av) C_noret;
C_noret_decl(f_5099)
static C_word C_fcall f_5099(C_word t0,C_word t1);
C_noret_decl(f_3759)
static void C_fcall f_3759(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word *av) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word *av) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word *av) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word *av) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word *av) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word *av) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word *av) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word *av) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word *av) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word *av) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word *av) C_noret;
C_noret_decl(f_5735)
static void C_ccall f_5735(C_word c,C_word *av) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word *av) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word *av) C_noret;
C_noret_decl(f_5725)
static void C_fcall f_5725(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word *av) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word *av) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word *av) C_noret;
C_noret_decl(f_6223)
static void C_ccall f_6223(C_word c,C_word *av) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word *av) C_noret;
C_noret_decl(f_3071)
static void C_fcall f_3071(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5898)
static void C_fcall f_5898(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word *av) C_noret;
C_noret_decl(f_5890)
static void C_fcall f_5890(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word *av) C_noret;
C_noret_decl(f_5702)
static void C_fcall f_5702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word *av) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word *av) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word *av) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word *av) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word *av) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word *av) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word *av) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word *av) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word *av) C_noret;
C_noret_decl(f_5525)
static void C_fcall f_5525(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word *av) C_noret;
C_noret_decl(f_4403)
static void C_fcall f_4403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_fcall f_4778(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word *av) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word *av) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word *av) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word *av) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word *av) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word *av) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word *av) C_noret;
C_noret_decl(f_6244)
static void C_fcall f_6244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_fcall f_2742(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word *av) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word *av) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word *av) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word *av) C_noret;
C_noret_decl(f_2739)
static void C_fcall f_2739(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4466)
static void C_fcall f_4466(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d69_toplevel)
C_externexport void C_ccall C_srfi_2d69_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_3162)
static void C_fcall f_3162(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4882)
static void C_fcall f_4882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_fcall f_6230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word *av) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word *av) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word *av) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word *av) C_noret;
C_noret_decl(f_4893)
static void C_fcall f_4893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_fcall f_4899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word *av) C_noret;
C_noret_decl(f_5560)
static void C_fcall f_5560(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word *av) C_noret;
C_noret_decl(f_5205)
static C_word C_fcall f_5205(C_word t0,C_word t1);
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word *av) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word *av) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word *av) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word *av) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word *av) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word *av) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word *av) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word *av) C_noret;
C_noret_decl(f_5779)
static void C_fcall f_5779(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word *av) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word *av) C_noret;
C_noret_decl(f_5763)
static void C_fcall f_5763(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word *av) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word *av) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word *av) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word *av) C_noret;
C_noret_decl(f_4529)
static void C_fcall f_4529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word *av) C_noret;
C_noret_decl(f_3721)
static void C_fcall f_3721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word *av) C_noret;
C_noret_decl(f_3724)
static void C_fcall f_3724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word *av) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word *av) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word *av) C_noret;
C_noret_decl(f_3718)
static void C_fcall f_3718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_fcall f_5138(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word *av) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word *av) C_noret;
C_noret_decl(f_4965)
static void C_fcall f_4965(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word *av) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word *av) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word *av) C_noret;
C_noret_decl(f_5878)
static void C_fcall f_5878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4349)
static void C_fcall f_4349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_fcall f_5537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word *av) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word *av) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word *av) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word *av) C_noret;
C_noret_decl(f_2759)
static void C_fcall f_2759(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word *av) C_noret;
C_noret_decl(f_5951)
static void C_fcall f_5951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word *av) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word *av) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word *av) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word *av) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word *av) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word *av) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word *av) C_noret;
C_noret_decl(f_5928)
static void C_fcall f_5928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word *av) C_noret;
C_noret_decl(f_5245)
static void C_fcall f_5245(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word *av) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word *av) C_noret;
C_noret_decl(f_4397)
static void C_fcall f_4397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6173)
static void C_fcall f_6173(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4386)
static void C_fcall f_4386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word *av) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word *av) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word *av) C_noret;
C_noret_decl(f_6131)
static void C_fcall f_6131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4210)
static void C_fcall f_4210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word *av) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word *av) C_noret;
C_noret_decl(f_5318)
static C_word C_fcall f_5318(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4239)
static void C_fcall f_4239(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word *av) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word *av) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word *av) C_noret;
C_noret_decl(f_2815)
static void C_fcall f_2815(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word *av) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word *av) C_noret;
C_noret_decl(f_4610)
static void C_fcall f_4610(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3533)
static void C_fcall f_3533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3539)
static C_word C_fcall f_3539(C_word t0,C_word t1);
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word *av) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word *av) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word *av) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word *av) C_noret;
C_noret_decl(f_4639)
static void C_fcall f_4639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word *av) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word *av) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word *av) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word *av) C_noret;
C_noret_decl(f_3642)
static C_word C_fcall f_3642(C_word t0);
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word *av) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word *av) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word *av) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word *av) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word *av) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word *av) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word *av) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word *av) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word *av) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word *av) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word *av) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word *av) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word *av) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word *av) C_noret;
C_noret_decl(f_5636)
static void C_fcall f_5636(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word *av) C_noret;
C_noret_decl(f_6029)
static void C_ccall f_6029(C_word c,C_word *av) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word *av) C_noret;
C_noret_decl(f_5652)
static void C_fcall f_5652(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word *av) C_noret;
C_noret_decl(f_4117)
static void C_fcall f_4117(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word *av) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word *av) C_noret;
C_noret_decl(f_3615)
static void C_fcall f_3615(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word *av) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word *av) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word *av) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word *av) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word *av) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word *av) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word *av) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word *av) C_noret;

C_noret_decl(trf_5979)
static void C_ccall trf_5979(C_word c,C_word *av) C_noret;
static void C_ccall trf_5979(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5979(t0,t1,t2,t3);}

C_noret_decl(trf_5365)
static void C_ccall trf_5365(C_word c,C_word *av) C_noret;
static void C_ccall trf_5365(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5365(t0,t1,t2,t3);}

C_noret_decl(trf_5963)
static void C_ccall trf_5963(C_word c,C_word *av) C_noret;
static void C_ccall trf_5963(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5963(t0,t1,t2,t3);}

C_noret_decl(trf_5828)
static void C_ccall trf_5828(C_word c,C_word *av) C_noret;
static void C_ccall trf_5828(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5828(t0,t1,t2,t3);}

C_noret_decl(trf_4719)
static void C_ccall trf_4719(C_word c,C_word *av) C_noret;
static void C_ccall trf_4719(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4719(t0,t1,t2);}

C_noret_decl(trf_5844)
static void C_ccall trf_5844(C_word c,C_word *av) C_noret;
static void C_ccall trf_5844(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5844(t0,t1,t2,t3);}

C_noret_decl(trf_5014)
static void C_ccall trf_5014(C_word c,C_word *av) C_noret;
static void C_ccall trf_5014(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5014(t0,t1,t2);}

C_noret_decl(trf_4140)
static void C_ccall trf_4140(C_word c,C_word *av) C_noret;
static void C_ccall trf_4140(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4140(t0,t1,t2);}

C_noret_decl(trf_5460)
static void C_ccall trf_5460(C_word c,C_word *av) C_noret;
static void C_ccall trf_5460(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5460(t0,t1,t2,t3);}

C_noret_decl(trf_5434)
static void C_ccall trf_5434(C_word c,C_word *av) C_noret;
static void C_ccall trf_5434(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5434(t0,t1,t2);}

C_noret_decl(trf_3770)
static void C_ccall trf_3770(C_word c,C_word *av) C_noret;
static void C_ccall trf_3770(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3770(t0,t1,t2);}

C_noret_decl(trf_4656)
static void C_ccall trf_4656(C_word c,C_word *av) C_noret;
static void C_ccall trf_4656(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4656(t0,t1);}

C_noret_decl(trf_4650)
static void C_ccall trf_4650(C_word c,C_word *av) C_noret;
static void C_ccall trf_4650(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4650(t0,t1);}

C_noret_decl(trf_3759)
static void C_ccall trf_3759(C_word c,C_word *av) C_noret;
static void C_ccall trf_3759(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3759(t0,t1,t2);}

C_noret_decl(trf_5725)
static void C_ccall trf_5725(C_word c,C_word *av) C_noret;
static void C_ccall trf_5725(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5725(t0,t1,t2);}

C_noret_decl(trf_3071)
static void C_ccall trf_3071(C_word c,C_word *av) C_noret;
static void C_ccall trf_3071(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3071(t0,t1,t2,t3);}

C_noret_decl(trf_5898)
static void C_ccall trf_5898(C_word c,C_word *av) C_noret;
static void C_ccall trf_5898(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5898(t0,t1,t2);}

C_noret_decl(trf_5890)
static void C_ccall trf_5890(C_word c,C_word *av) C_noret;
static void C_ccall trf_5890(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5890(t0,t1,t2);}

C_noret_decl(trf_5702)
static void C_ccall trf_5702(C_word c,C_word *av) C_noret;
static void C_ccall trf_5702(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5702(t0,t1,t2);}

C_noret_decl(trf_5525)
static void C_ccall trf_5525(C_word c,C_word *av) C_noret;
static void C_ccall trf_5525(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5525(t0,t1,t2);}

C_noret_decl(trf_4403)
static void C_ccall trf_4403(C_word c,C_word *av) C_noret;
static void C_ccall trf_4403(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4403(t0,t1);}

C_noret_decl(trf_4778)
static void C_ccall trf_4778(C_word c,C_word *av) C_noret;
static void C_ccall trf_4778(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4778(t0,t1,t2);}

C_noret_decl(trf_6244)
static void C_ccall trf_6244(C_word c,C_word *av) C_noret;
static void C_ccall trf_6244(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6244(t0,t1);}

C_noret_decl(trf_2742)
static void C_ccall trf_2742(C_word c,C_word *av) C_noret;
static void C_ccall trf_2742(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_2742(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2739)
static void C_ccall trf_2739(C_word c,C_word *av) C_noret;
static void C_ccall trf_2739(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2739(t0,t1,t2);}

C_noret_decl(trf_4466)
static void C_ccall trf_4466(C_word c,C_word *av) C_noret;
static void C_ccall trf_4466(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4466(t0,t1,t2);}

C_noret_decl(trf_3162)
static void C_ccall trf_3162(C_word c,C_word *av) C_noret;
static void C_ccall trf_3162(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3162(t0,t1,t2,t3);}

C_noret_decl(trf_4882)
static void C_ccall trf_4882(C_word c,C_word *av) C_noret;
static void C_ccall trf_4882(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4882(t0,t1);}

C_noret_decl(trf_6230)
static void C_ccall trf_6230(C_word c,C_word *av) C_noret;
static void C_ccall trf_6230(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6230(t0,t1);}

C_noret_decl(trf_4893)
static void C_ccall trf_4893(C_word c,C_word *av) C_noret;
static void C_ccall trf_4893(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4893(t0,t1);}

C_noret_decl(trf_4899)
static void C_ccall trf_4899(C_word c,C_word *av) C_noret;
static void C_ccall trf_4899(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4899(t0,t1);}

C_noret_decl(trf_5560)
static void C_ccall trf_5560(C_word c,C_word *av) C_noret;
static void C_ccall trf_5560(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5560(t0,t1,t2);}

C_noret_decl(trf_3150)
static void C_ccall trf_3150(C_word c,C_word *av) C_noret;
static void C_ccall trf_3150(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3150(t0,t1,t2,t3);}

C_noret_decl(trf_5779)
static void C_ccall trf_5779(C_word c,C_word *av) C_noret;
static void C_ccall trf_5779(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5779(t0,t1,t2,t3);}

C_noret_decl(trf_5763)
static void C_ccall trf_5763(C_word c,C_word *av) C_noret;
static void C_ccall trf_5763(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5763(t0,t1,t2,t3);}

C_noret_decl(trf_4529)
static void C_ccall trf_4529(C_word c,C_word *av) C_noret;
static void C_ccall trf_4529(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4529(t0,t1,t2);}

C_noret_decl(trf_3721)
static void C_ccall trf_3721(C_word c,C_word *av) C_noret;
static void C_ccall trf_3721(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3721(t0,t1);}

C_noret_decl(trf_3724)
static void C_ccall trf_3724(C_word c,C_word *av) C_noret;
static void C_ccall trf_3724(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3724(t0,t1);}

C_noret_decl(trf_3718)
static void C_ccall trf_3718(C_word c,C_word *av) C_noret;
static void C_ccall trf_3718(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3718(t0,t1);}

C_noret_decl(trf_5138)
static void C_ccall trf_5138(C_word c,C_word *av) C_noret;
static void C_ccall trf_5138(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5138(t0,t1,t2);}

C_noret_decl(trf_4965)
static void C_ccall trf_4965(C_word c,C_word *av) C_noret;
static void C_ccall trf_4965(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4965(t0,t1,t2);}

C_noret_decl(trf_5878)
static void C_ccall trf_5878(C_word c,C_word *av) C_noret;
static void C_ccall trf_5878(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5878(t0,t1,t2);}

C_noret_decl(trf_4349)
static void C_ccall trf_4349(C_word c,C_word *av) C_noret;
static void C_ccall trf_4349(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4349(t0,t1);}

C_noret_decl(trf_5537)
static void C_ccall trf_5537(C_word c,C_word *av) C_noret;
static void C_ccall trf_5537(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5537(t0,t1,t2);}

C_noret_decl(trf_2759)
static void C_ccall trf_2759(C_word c,C_word *av) C_noret;
static void C_ccall trf_2759(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2759(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4301)
static void C_ccall trf_4301(C_word c,C_word *av) C_noret;
static void C_ccall trf_4301(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4301(t0,t1,t2);}

C_noret_decl(trf_5951)
static void C_ccall trf_5951(C_word c,C_word *av) C_noret;
static void C_ccall trf_5951(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5951(t0,t1,t2,t3);}

C_noret_decl(trf_5928)
static void C_ccall trf_5928(C_word c,C_word *av) C_noret;
static void C_ccall trf_5928(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5928(t0,t1,t2);}

C_noret_decl(trf_5245)
static void C_ccall trf_5245(C_word c,C_word *av) C_noret;
static void C_ccall trf_5245(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5245(t0,t1,t2);}

C_noret_decl(trf_4397)
static void C_ccall trf_4397(C_word c,C_word *av) C_noret;
static void C_ccall trf_4397(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4397(t0,t1);}

C_noret_decl(trf_6173)
static void C_ccall trf_6173(C_word c,C_word *av) C_noret;
static void C_ccall trf_6173(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6173(t0,t1,t2);}

C_noret_decl(trf_4386)
static void C_ccall trf_4386(C_word c,C_word *av) C_noret;
static void C_ccall trf_4386(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4386(t0,t1);}

C_noret_decl(trf_6131)
static void C_ccall trf_6131(C_word c,C_word *av) C_noret;
static void C_ccall trf_6131(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6131(t0,t1,t2);}

C_noret_decl(trf_4210)
static void C_ccall trf_4210(C_word c,C_word *av) C_noret;
static void C_ccall trf_4210(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4210(t0,t1);}

C_noret_decl(trf_4239)
static void C_ccall trf_4239(C_word c,C_word *av) C_noret;
static void C_ccall trf_4239(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4239(t0,t1,t2);}

C_noret_decl(trf_2815)
static void C_ccall trf_2815(C_word c,C_word *av) C_noret;
static void C_ccall trf_2815(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2815(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4610)
static void C_ccall trf_4610(C_word c,C_word *av) C_noret;
static void C_ccall trf_4610(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_4610(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3533)
static void C_ccall trf_3533(C_word c,C_word *av) C_noret;
static void C_ccall trf_3533(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3533(t0,t1,t2);}

C_noret_decl(trf_4639)
static void C_ccall trf_4639(C_word c,C_word *av) C_noret;
static void C_ccall trf_4639(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4639(t0,t1);}

C_noret_decl(trf_5636)
static void C_ccall trf_5636(C_word c,C_word *av) C_noret;
static void C_ccall trf_5636(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5636(t0,t1,t2,t3);}

C_noret_decl(trf_5652)
static void C_ccall trf_5652(C_word c,C_word *av) C_noret;
static void C_ccall trf_5652(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5652(t0,t1,t2,t3);}

C_noret_decl(trf_4117)
static void C_ccall trf_4117(C_word c,C_word *av) C_noret;
static void C_ccall trf_4117(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4117(t0,t1,t2);}

C_noret_decl(trf_3615)
static void C_ccall trf_3615(C_word c,C_word *av) C_noret;
static void C_ccall trf_3615(C_word c,C_word *av){
C_word t0=av[7];
C_word t1=av[6];
C_word t2=av[5];
C_word t3=av[4];
C_word t4=av[3];
C_word t5=av[2];
C_word t6=av[1];
C_word t7=av[0];
f_3615(t0,t1,t2,t3,t4,t5,t6,t7);}

/* hash-table-equivalence-function in k2735 in k2730 in k1726 */
static void C_ccall f_4024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4024,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[74]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* hash-table->alist in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_5621,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[37],lf[103]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5636,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5636(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* fold2 in loop in *hash-table-fold in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5979(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_5979,4,t0,t1,t2,t3);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1099: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5963(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_slot(t4,C_fix(0));
t9=C_slot(t4,C_fix(1));
/* srfi-69.scm:1102: func */
t10=((C_word*)t0)[5];{
C_word av2[5];
av2[0]=t10;
av2[1]=t7;
av2[2]=t8;
av2[3]=t9;
av2[4]=t3;
((C_proc)C_fast_retrieve_proc(t10))(5,av2);}}}

/* loop in k5296 in hash-table-delete! in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5365(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,0,3))){
C_save_and_reclaim_args((void *)trf_5365,4,t0,t1,t2,t3);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5384,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t8=C_slot(t4,C_fix(0));
/* srfi-69.scm:953: test */
t9=((C_word*)t0)[7];{
C_word av2[4];
av2[0]=t9;
av2[1]=t7;
av2[2]=((C_word*)t0)[8];
av2[3]=t8;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}}

/* hash-table-size in k2735 in k2730 in k1726 */
static void C_ccall f_4015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4015,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[73]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(2));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* loop in *hash-table-fold in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_5963,4,t0,t1,t2,t3);}
a=C_alloc(9);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5979,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word)li93),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5979(t8,t1,t4,t3);}}

/* loop in hash-table-values in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5828(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_5828,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5844,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5844(t8,t1,t4,t3);}}

/* loop in k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_fcall f_4719(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_4719,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm:774: func */
t4=((C_word*)t0)[8];{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[9];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t4,C_fix(0));
t6=C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm:780: func */
t9=((C_word*)t0)[8];{
C_word av2[3];
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)C_fast_retrieve_proc(t9))(3,av2);}}
else{
t7=C_slot(t2,C_fix(1));
/* srfi-69.scm:783: loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}}

/* number-hash in k1726 */
static void C_ccall f_1737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +6,c,5))){
C_save_and_reclaim((void*)f_1737,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+6);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1753,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_numberp(t2))){
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_SCHEME_UNDEFINED;
f_1753(2,av2);}}
else{
/* srfi-69.scm:157: ##sys#signal-hook */
t15=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=lf[5];
av2[3]=lf[3];
av2[4]=lf[6];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t15+1)))(6,av2);}}}

/* ##sys#number-hash-hook in k1726 */
static void C_ccall f_1731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1731,4,av);}
/* srfi-69.scm:144: *equal?-hash */
f_2739(t1,t2,t3);}

/* k4727 in loop in k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4729,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k4195 in k4192 in k4189 in hash-table-resize! in k2735 in k2730 in k1726 */
static void C_ccall f_4197(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4197,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4189 in hash-table-resize! in k2735 in k2730 in k1726 */
static void C_ccall f_4191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4191,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:653: make-vector */
t3=*((C_word*)lf[38]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4192 in k4189 in hash-table-resize! in k2735 in k2730 in k1726 */
static void C_ccall f_4194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_4194,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],C_fix(10));
t5=((C_word*)t0)[4];
t6=t2;
t7=t4;
t8=C_block_size(t5);
t9=t8;
t10=C_block_size(t6);
t11=t10;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4117,a[2]=t9,a[3]=t13,a[4]=t5,a[5]=t6,a[6]=t7,a[7]=t11,a[8]=((C_word)li40),tmp=(C_word)a,a+=9,tmp));
t15=((C_word*)t13)[1];
f_4117(t15,t3,C_fix(0));}

/* loop2 in loop in hash-table-values in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5844(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_5844,4,t0,t1,t2,t3);}
a=C_alloc(3);
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1069: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5828(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(1));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm:1070: loop2 */
t9=t1;
t10=t4;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* eq?-hash in k1726 */
static void C_ccall f_2343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_2343,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[14]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2391,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(t2,t10);
f_2391(2,av2);}}
else{
if(C_truep(C_charp(t2))){
t15=C_fix(C_character_code(t2));
t16=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_fixnum_xor(t15,t10);
f_2391(2,av2);}}
else{
switch(t2){
case C_SCHEME_TRUE:
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(256),t10);
f_2391(2,av2);}
case C_SCHEME_FALSE:
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(257),t10);
f_2391(2,av2);}
default:
if(C_truep(C_i_nullp(t2))){
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(258),t10);
f_2391(2,av2);}}
else{
if(C_truep(C_eofp(t2))){
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(259),t10);
f_2391(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t15=C_slot(t2,C_fix(1));
t16=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_u_i_string_hash(t15,t10);
f_2391(2,av2);}}
else{
if(C_truep(C_blockp(t2))){
/* srfi-69.scm:168: *equal?-hash */
f_2739(t14,t2,t10);}
else{
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(262),t10);
f_2391(2,av2);}}}}}}}}}

/* k1751 in number-hash in k1726 */
static void C_ccall f_1753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1753,2,av);}
a=C_alloc(7);
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
if(C_truep(C_fixnump(t4))){
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_fixnum_xor(t4,((C_word*)t0)[5]);
f_1926(2,av2);}}
else{
t5=t3;
if(C_truep(C_i_flonump(t4))){
t6=C_subbyte(t4,C_fix(7));
t7=C_subbyte(t4,C_fix(6));
t8=C_subbyte(t4,C_fix(5));
t9=C_subbyte(t4,C_fix(4));
t10=C_subbyte(t4,C_fix(3));
t11=C_subbyte(t4,C_fix(2));
t12=C_subbyte(t4,C_fix(1));
t13=C_subbyte(t4,C_fix(0));
t14=C_fixnum_shift_left(t13,C_fix(1));
t15=C_fixnum_plus(t12,t14);
t16=C_fixnum_shift_left(t15,C_fix(1));
t17=C_fixnum_plus(t11,t16);
t18=C_fixnum_shift_left(t17,C_fix(1));
t19=C_fixnum_plus(t10,t18);
t20=C_fixnum_shift_left(t19,C_fix(1));
t21=C_fixnum_plus(t9,t20);
t22=C_fixnum_shift_left(t21,C_fix(1));
t23=C_fixnum_plus(t8,t22);
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t7,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t6,t26);
t28=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t28;
av2[1]=C_fixnum_times(C_fix(331804471),t27);
((C_proc)(void*)(*((C_word*)t28+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1920,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:148: ##sys#number-hash-hook */
t7=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}}

/* hash-table-resize! in k2735 in k2730 in k1726 */
static void C_ccall f_4184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4184,5,av);}
a=C_alloc(5);
t5=C_fixnum_times(t4,C_fix(2));
t6=C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4191,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:652: hash-table-canonical-length */
f_3533(t7,lf[29],t6);}

/* hash-table-values in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_5813,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[37],lf[106]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5828,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word)li87),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5828(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_4705,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_slot(((C_word*)t0)[2],t2);
t4=t3;
t5=C_eqp(((C_word*)t0)[3],((C_word*)t0)[4]);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word)li50),tmp=(C_word)a,a+=12,tmp));
t9=((C_word*)t7)[1];
f_4719(t9,((C_word*)t0)[10],t4);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word*)t0)[4],a[12]=((C_word)li51),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_4778(t9,((C_word*)t0)[10],t4);}}

/* loop in k4946 in k4931 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_fcall f_5014(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_5014,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[6],t4);
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_i_set_i_slot(((C_word*)t0)[7],C_fix(2),((C_word*)t0)[8]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5044,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:833: test */
t7=((C_word*)t0)[10];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k4154 in loop in doloop864 in k4192 in k4189 in hash-table-resize! in k2735 in k2730 in k1726 */
static void C_ccall f_4156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4156,2,av);}
a=C_alloc(6);
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_slot(((C_word*)t0)[4],t1);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_i_setslot(((C_word*)t0)[4],t1,t5);
t7=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:646: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_4140(t8,((C_word*)t0)[7],t7);}

/* k3806 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3808,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3759(t4,((C_word*)t0)[6],t3);}

/* loop in doloop864 in k4192 in k4189 in hash-table-resize! in k2735 in k2730 in k1726 */
static void C_fcall f_4140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_4140,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t4,C_fix(0));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4156,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:643: hash */
t8=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
av2[3]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t8))(4,av2);}}}

/* k4428 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4430,2,av);}
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4386(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4386(t3,t2);}}

/* k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_4437,2,av);}
a=C_alloc(11);
t2=C_slot(((C_word*)t0)[2],C_fix(10));
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4452,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:729: hash */
t9=t2;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[4];
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}

/* loop in doloop1180 in k5418 in hash-table-remove! in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5460(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_5460,4,t0,t1,t2,t3);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5479,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
t8=C_slot(t4,C_fix(0));
t9=C_slot(t4,C_fix(1));
/* srfi-69.scm:976: func */
t10=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t10;
av2[1]=t7;
av2[2]=t8;
av2[3]=t9;
((C_proc)C_fast_retrieve_proc(t10))(4,av2);}}}

/* k5382 in loop in k5296 in hash-table-delete! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5384,2,av);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[2])?C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]):C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]));
t3=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* srfi-69.scm:960: loop */
t2=((C_word*)((C_word*)t0)[9])[1];
f_5365(t2,((C_word*)t0)[8],((C_word*)t0)[10],((C_word*)t0)[3]);}}

/* k1726 */
static void C_ccall f_1728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(30,c,4))){C_save_and_reclaim((void *)f_1728,2,av);}
a=C_alloc(30);
t2=C_mutate2(&lf[0] /* (set! hash-default-randomization ...) */,C_rnd_fix());
t3=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[3]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[7]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1958,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[8]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2037,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[9]+1 /* (set! ##sys#check-keyword ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[13]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2151,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[14]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2343,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[15]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[14]+1));
t11=C_mutate2((C_word*)lf[16]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(lf[17] /* *recursive-hash-max-depth* */,0,C_fix(4));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6237,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:270: make-parameter */
t15=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t13;
av2[2]=C_fix(4);
av2[3]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}

/* k3819 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3821,2,av);}
t2=C_i_fixnum_min(C_fix(1073741823),((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3759(t5,((C_word*)t0)[6],t4);}

/* doloop1180 in k5418 in hash-table-remove! in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,4))){
C_save_and_reclaim_args((void *)trf_5434,3,t0,t1,t2);}
a=C_alloc(15);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)((C_word*)t0)[4])[1]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5447,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[6],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5460,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[7],a[7]=((C_word)li66),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5460(t8,t3,C_SCHEME_FALSE,t4);}}

/* k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3784(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_3784,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(((C_word*)t0)[5],lf[53]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:541: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=lf[45];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t5=C_eqp(((C_word*)t0)[5],lf[55]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:544: ##sys#check-closure */
t7=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=lf[45];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t6=C_eqp(((C_word*)t0)[5],lf[56]);
if(C_truep(t6)){
t7=C_i_check_exact_2(t2,lf[45]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3821,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),t2))){
t9=t8;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_SCHEME_UNDEFINED;
f_3821(2,av2);}}
else{
/* srfi-69.scm:549: error */
t9=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[45];
av2[3]=lf[57];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}
else{
t7=C_eqp(((C_word*)t0)[5],lf[58]);
if(C_truep(t7)){
t8=C_mutate2(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3839,a[2]=t2,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp));
t9=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t10=((C_word*)((C_word*)t0)[3])[1];
f_3759(t10,((C_word*)t0)[4],t9);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[59]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:554: ##sys#check-inexact */
t10=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t2;
av2[3]=lf[45];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t9=C_eqp(((C_word*)t0)[5],lf[64]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[11],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:559: ##sys#check-inexact */
t11=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=t2;
av2[3]=lf[45];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t10=C_eqp(((C_word*)t0)[5],lf[66]);
if(C_truep(t10)){
if(C_truep(t2)){
t11=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t12=((C_word*)((C_word*)t0)[3])[1];
f_3759(t12,((C_word*)t0)[4],t11);}
else{
t11=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t12=((C_word*)((C_word*)t0)[3])[1];
f_3759(t12,((C_word*)t0)[4],t11);}}
else{
t11=C_eqp(((C_word*)t0)[5],lf[67]);
if(C_truep(t11)){
if(C_truep(t2)){
t12=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t13=((C_word*)((C_word*)t0)[3])[1];
f_3759(t13,((C_word*)t0)[4],t12);}
else{
t12=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t13=((C_word*)((C_word*)t0)[3])[1];
f_3759(t13,((C_word*)t0)[4],t12);}}
else{
/* srfi-69.scm:568: invarg-err */
t12=((C_word*)t0)[12];
f_3770(t12,t3,lf[68]);}}}}}}}}}

/* k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_3780,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3784,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_u_i_car(t3);
f_3784(2,av2);}}
else{
/* srfi-69.scm:538: invarg-err */
t5=((C_word*)t0)[12];
f_3770(t5,t4,lf[69]);}}
else{
/* srfi-69.scm:570: invarg-err */
t2=((C_word*)t0)[12];
f_3770(t2,((C_word*)t0)[4],lf[70]);}}

/* k3785 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3787,2,av);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3759(t3,((C_word*)t0)[4],t2);}

/* k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_4690,2,av);}
a=C_alloc(11);
t2=C_slot(((C_word*)t0)[2],C_fix(10));
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4705,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:768: hash */
t9=t2;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[4];
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}

/* k4125 in doloop864 in k4192 in k4189 in hash-table-resize! in k2735 in k2730 in k1726 */
static void C_ccall f_4127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4127,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4117(t3,((C_word*)t0)[4],t2);}

/* k4809 in loop in k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4811,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:793: func */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t2=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:796: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4778(t3,((C_word*)t0)[3],t2);}}

/* k4812 in k4809 in loop in k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4814,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3796 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3798,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3759(t4,((C_word*)t0)[6],t3);}

/* k2389 in eq?-hash in k1726 */
static void C_ccall f_2391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2391,2,av);}
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_fixnum_modulo(t6,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k3031 in recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3033,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3847 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3849,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(C_flonum_lessp(lf[60],((C_word*)t0)[3]))?C_flonum_lessp(((C_word*)t0)[3],lf[61]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3759(t6,((C_word*)t0)[6],t5);}
else{
/* srfi-69.scm:556: error */
t4=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[45];
av2[3]=lf[62];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k3422 in string-ci-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3424,2,av);}
t2=C_u_i_string_ci_hash(t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t5=C_fixnum_lessp(t2,C_fix(0));
t6=(C_truep(t5)?C_fixnum_negate(t2):t2);
t7=C_fixnum_and(t4,t6);
t8=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_fixnum_modulo(t7,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* f_3839 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3839,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* invarg-err in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_fcall f_3770(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,5))){
C_save_and_reclaim_args((void *)trf_3770,3,t0,t1,t2);}
/* srfi-69.scm:533: error */
t3=*((C_word*)lf[50]+1);{
C_word av2[6];
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[45];
av2[3]=t2;
av2[4]=((C_word*)t0)[2];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4838,6,av);}
a=C_alloc(7);
t6=C_i_check_structure_2(t2,lf[37],lf[90]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4845,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:800: ##sys#check-closure */
t8=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
av2[3]=lf[90];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k4681 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4683,2,av);}
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4639(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4639(t3,t2);}}

/* k4843 in hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4845,2,av);}
/* srfi-69.scm:801: *hash-table-update!/default */
t2=lf[89];
f_4610(t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k5082 in hash-table-ref/default in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_5084,2,av);}
a=C_alloc(9);
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=f_5099(t4,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5138(t7,((C_word*)t0)[7],t3);}}

/* k4654 in k4648 in k4637 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_fcall f_4656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_4656,2,t0,t1);}
if(C_truep(t1)){
/* srfi-69.scm:668: hash-table-resize! */
t2=*((C_word*)lf[82]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4648 in k4637 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_fcall f_4650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4650,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[7]);
t4=t2;
f_4656(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[7],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4656(t3,C_SCHEME_FALSE);}}

/* k3752 in k3725 in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3754(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_3754,2,av);}
if(C_truep(t1)){
/* srfi-69.scm:573: error */
t2=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[45];
av2[3]=lf[51];
av2[4]=((C_word*)((C_word*)t0)[3])[1];
av2[5]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_3730(2,av2);}}}

/* k3748 in k3732 in k3728 in k3725 in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,8))){C_save_and_reclaim((void *)f_3750,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
/* srfi-69.scm:585: *make-hash-table */
f_3615(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);}

/* loop in k5082 in hash-table-ref/default in k5064 in k2735 in k2730 in k1726 */
static C_word C_fcall f_5099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
return(t2);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
return(C_slot(t2,C_fix(1)));}
else{
t5=C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_fcall f_3759(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,0,3))){
C_save_and_reclaim_args((void *)trf_3759,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3770,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3780,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t5,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm:534: keyword? */
t7=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* hash-table-ref/default in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5068,5,av);}
a=C_alloc(8);
t5=C_i_check_structure_2(t2,lf[37],lf[94]);
t6=C_slot(t2,C_fix(1));
t7=t6;
t8=C_slot(t2,C_fix(3));
t9=t8;
t10=C_slot(t2,C_fix(10));
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t7,a[5]=t4,a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t12=C_block_size(t7);
/* srfi-69.scm:880: hash */
t13=t10;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t13;
av2[1]=t11;
av2[2]=t3;
av2[3]=t12;
((C_proc)C_fast_retrieve_proc(t13))(4,av2);}}

/* k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(63,c,5))){C_save_and_reclaim((void *)f_5066,2,av);}
a=C_alloc(63);
t2=C_mutate2((C_word*)lf[93]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[39]+1);
t4=C_mutate2((C_word*)lf[94]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5068,a[2]=t3,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[39]+1);
t6=C_mutate2((C_word*)lf[95]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5174,a[2]=t5,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[39]+1);
t8=C_mutate2((C_word*)lf[96]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5282,a[2]=t7,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate2((C_word*)lf[97]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5413,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[98]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2(&lf[100] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5525,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[101]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5593,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[102]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5605,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[103]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5621,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[104]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5694,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[105]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5748,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[106]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5813,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2(&lf[107] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5878,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2(&lf[109] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5951,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[110]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6017,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[111]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6029,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate2((C_word*)lf[112]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6041,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[113]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6053,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6078,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:1127: ##sys#register-record-printer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[117]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[117]+1);
av2[1]=t24;
av2[2]=lf[37];
av2[3]=t25;
tp(4,av2);}}

/* k4673 in k4637 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4675,2,av);}
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4650(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4650(t3,t2);}}

/* hash-table-min-load in k2735 in k2730 in k1726 */
static void C_ccall f_4042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4042,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[76]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(5));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* f_6214 in a6093 in k2735 in k2730 in k1726 */
static void C_ccall f_6214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_6214,2,av);}
/* srfi-69.scm:844: ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[87];
av2[3]=lf[93];
av2[4]=lf[118];
av2[5]=((C_word*)t0)[2];
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* hash-table-hash-function in k2735 in k2730 in k1726 */
static void C_ccall f_4033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4033,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[75]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(4));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* hash-table-keys in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_5748,3,av);}
a=C_alloc(8);
t3=C_i_check_structure_2(t2,lf[37],lf[105]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5763,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5763(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* k5042 in loop in k4946 in k4931 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_ccall f_5044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5044,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:835: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5014(t3,((C_word*)t0)[2],t2);}}

/* hash-table-weak-values in k2735 in k2730 in k1726 */
static void C_ccall f_4069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4069,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[79]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(8));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* hash-table-weak-keys in k2735 in k2730 in k1726 */
static void C_ccall f_4060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4060,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[78]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(7));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* symbol-hash in k1726 */
static void C_ccall f_2037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,1))){
C_save_and_reclaim((void*)f_2037,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?lf[0]:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_check_symbol_2(t2,lf[8]);
t13=C_i_check_exact_2(t5,lf[8]);
t14=t2;
t15=C_slot(t14,C_fix(1));
t16=C_u_i_string_hash(t15,t9);
t17=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t18=C_fixnum_lessp(t16,C_fix(0));
t19=(C_truep(t18)?C_fixnum_negate(t16):t16);
t20=C_fixnum_and(t17,t19);
t21=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t21;
av2[1]=C_fixnum_modulo(t20,t5);
((C_proc)(void*)(*((C_word*)t21+1)))(2,av2);}}

/* k5733 in for-each-loop1247 in k5699 in alist->hash-table in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5735(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5735,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5725(t3,((C_word*)t0)[4],t2);}

/* k5445 in doloop1180 in k5418 in hash-table-remove! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5447,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5434(t3,((C_word*)t0)[4],t2);}

/* hash-table-max-load in k2735 in k2730 in k1726 */
static void C_ccall f_4051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4051,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[77]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(6));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* for-each-loop1247 in k5699 in alist->hash-table in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5725(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5725,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5735,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* srfi-69.scm:1034: g1248 */
t5=((C_word*)t0)[3];
f_5702(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5721 in k5699 in alist->hash-table in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5723,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a5714 in g1248 in k5699 in alist->hash-table in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5715,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* hash-table-has-initial? in k2735 in k2730 in k1726 */
static void C_ccall f_4078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4078,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[80]);
t4=C_slot(t2,C_fix(9));
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* a6222 in k2730 in k1726 */
static void C_ccall f_6223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6223,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6230,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=t2;
t5=t3;
f_6230(t5,C_fixnum_greaterp(t4,C_fix(0)));}
else{
t4=t3;
f_6230(t4,C_SCHEME_FALSE);}}

/* k3093 in g525 in recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3095,2,av);}
a=C_alloc(4);
t2=C_fixnum_shift_left(t1,C_fix(16));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:291: recursive-hash */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2815(t7,t4,t5,t6,((C_word*)t0)[6]);}

/* g525 in recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_fcall f_3071(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_3071,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3095,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
t6=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:290: recursive-hash */
t7=((C_word*)((C_word*)t0)[3])[1];
f_2815(t7,t4,t5,t6,t3);}

/* g1306 in doloop1300 in *hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_5898,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* srfi-69.scm:1087: proc */
t5=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}

/* k5477 in loop in doloop1180 in k5418 in hash-table-remove! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5479,2,av);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[2])?C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]):C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]));
t3=C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t3);
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
/* srfi-69.scm:983: loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5460(t2,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[3]);}}

/* doloop1300 in *hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,0,3))){
C_save_and_reclaim_args((void *)trf_5890,3,t0,t1,t2);}
a=C_alloc(16);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5898,a[2]=((C_word*)t0)[3],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_i_check_list_2(t4,lf[108]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5919,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5928,a[2]=t8,a[3]=t3,a[4]=((C_word)li90),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_5928(t10,t6,t4);}}

/* k5699 in alist->hash-table in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_5701,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5702,a[2]=t2,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5723,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5725,a[2]=t7,a[3]=t3,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5725(t9,t5,t4);}

/* g1248 in k5699 in alist->hash-table in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,5))){
C_save_and_reclaim_args((void *)trf_5702,3,t0,t1,t2);}
a=C_alloc(3);
t3=C_i_check_pair_2(t2,lf[104]);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5715,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp);
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:1038: *hash-table-update!/default */
t7=lf[89];
f_4610(t7,t1,((C_word*)t0)[2],t4,t5,t6);}

/* k2625 in eqv?-hash in k1726 */
static void C_ccall f_2627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2627,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4492 in loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4494,2,av);}
/* srfi-69.scm:735: func */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* hash-table-initial in k2735 in k2730 in k1726 */
static void C_ccall f_4090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4090,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[81]);
t4=C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm:630: thunk */
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t5))(2,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k3462 in string-ci-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_3464,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* srfi-69.scm:373: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(0);
av2[4]=t3;
av2[5]=lf[24];
tp(6,av2);}}

/* k3465 in k3462 in string-ci-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3467(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3467,2,av);}
/* srfi-69.scm:374: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[25]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[25]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
tp(5,av2);}}

/* k3081 in k3093 in g525 in recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3083,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fixnum_plus(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* hash-table-clear! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5509,3,av);}
a=C_alloc(4);
t3=C_i_check_structure_2(t2,lf[37],lf[98]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(1));
/* srfi-69.scm:989: vector-fill! */
t6=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5514 in hash-table-clear! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5516,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_fix(0));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4946 in k4931 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_ccall f_4948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_4948,2,av);}
a=C_alloc(17);
t2=t1;
t3=C_slot(((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t8,a[10]=((C_word)li54),tmp=(C_word)a,a+=11,tmp));
t10=((C_word*)t8)[1];
f_4965(t10,t5,t4);}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=((C_word)li55),tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_5014(t10,t5,t4);}}

/* *hash-table-merge! in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5525(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_5525,3,t1,t2,t3);}
a=C_alloc(9);
t4=C_slot(t3,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5537,a[2]=t7,a[3]=t2,a[4]=t9,a[5]=t5,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5537(t11,t1,C_fix(0));}

/* k4952 in k4946 in k4931 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_ccall f_4954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4954,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[92]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4401 in k4395 in k4384 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_fcall f_4403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_4403,2,t0,t1);}
if(C_truep(t1)){
/* srfi-69.scm:668: hash-table-resize! */
t2=*((C_word*)lf[82]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_fcall f_4778(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_4778,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm:787: func */
t4=((C_word*)t0)[8];{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[9];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4811,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:792: test */
t7=((C_word*)t0)[11];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k4924 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_ccall f_4926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4926,2,av);}
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4882(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4882(t3,t2);}}

/* k4474 in loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4476,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* object-uid-hash in k1726 */
static void C_ccall f_1958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_1958,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[7]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2011,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:168: *equal?-hash */
f_2739(t14,t2,t10);}

/* k4786 in loop in k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4788,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k4931 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_ccall f_4933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4933,2,av);}
a=C_alloc(10);
t2=C_slot(((C_word*)t0)[2],C_fix(10));
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4948,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm:813: hash */
t9=t2;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[5];
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}

/* k4420 in k4384 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4422,2,av);}
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4397(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4397(t3,t2);}}

/* k4753 in loop in k4703 in k4688 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_ccall f_4755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4755,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6242 in a6236 in k1726 */
static void C_fcall f_6244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_6244,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate2((C_word*)lf[17]+1 /* (set! *recursive-hash-max-depth* ...) */,((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=*((C_word*)lf[17]+1);
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=*((C_word*)lf[17]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* vector-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_fcall f_2742(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,5))){
C_save_and_reclaim_args((void *)trf_2742,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(10);
t7=C_block_size(t2);
t8=C_fixnum_xor(t3,t6);
t9=C_fixnum_plus(t7,t8);
t10=C_i_fixnum_min(*((C_word*)lf[19]+1),t7);
t11=C_i_fixnum_max(t5,t10);
t12=C_fixnum_difference(t11,t5);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2759,a[2]=t14,a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t6,a[7]=((C_word)li8),tmp=(C_word)a,a+=8,tmp));
t16=((C_word*)t14)[1];
f_2759(t16,t1,t9,t5,t12);}

/* k4916 in k4880 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_ccall f_4918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4918,2,av);}
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4893(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4893(t3,t2);}}

/* *make-hash-function in k2735 in k2730 in k1726 */
static void C_ccall f_3563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(41,c,4))){C_save_and_reclaim((void *)f_3563,3,av);}
a=C_alloc(41);
t3=t2;
t4=C_a_i_list(&a,10,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[11]);
if(C_truep(C_u_i_memq(t3,t4))){
t5=C_rnd_fix();
t6=t2;
t7=C_a_i_list2(&a,2,((C_word*)t0)[6],((C_word*)t0)[7]);
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=(C_truep(C_u_i_memq(t6,t7))?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=t2,a[3]=t5,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3586,a[2]=t2,a[3]=t5,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3591,a[2]=t2,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k2730 in k1726 */
static void C_ccall f_2732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2732,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[18]+1 /* (set! recursive-hash-max-depth ...) */,t1);
t3=C_set_block_item(lf[19] /* *recursive-hash-max-length* */,0,C_fix(4));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6223,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:279: make-parameter */
t6=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=C_fix(4);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k2735 in k2730 in k1726 */
static void C_ccall f_2737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(107,c,9))){C_save_and_reclaim((void *)f_2737,2,av);}
a=C_alloc(107);
t2=C_mutate2((C_word*)lf[20]+1 /* (set! recursive-hash-max-length ...) */,t1);
t3=C_mutate2(&lf[2] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2739,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[22]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3174,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[23]+1 /* (set! hash ...) */,*((C_word*)lf[22]+1));
t6=C_mutate2((C_word*)lf[24]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[27]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3390,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[28]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[27]+1));
t9=C_mutate2(&lf[29] /* (set! constant676 ...) */,lf[30]);
t10=C_mutate2(&lf[31] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3533,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[14]+1);
t12=*((C_word*)lf[16]+1);
t13=*((C_word*)lf[22]+1);
t14=*((C_word*)lf[23]+1);
t15=*((C_word*)lf[24]+1);
t16=*((C_word*)lf[28]+1);
t17=*((C_word*)lf[3]+1);
t18=*((C_word*)lf[7]+1);
t19=*((C_word*)lf[8]+1);
t20=*((C_word*)lf[13]+1);
t21=C_mutate2((C_word*)lf[32]+1 /* (set! *make-hash-function ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3563,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=t15,a[7]=t16,a[8]=t17,a[9]=t18,a[10]=t19,a[11]=t20,a[12]=((C_word)li23),tmp=(C_word)a,a+=13,tmp));
t22=C_mutate2(&lf[36] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t23=*((C_word*)lf[39]+1);
t24=*((C_word*)lf[40]+1);
t25=*((C_word*)lf[41]+1);
t26=*((C_word*)lf[42]+1);
t27=*((C_word*)lf[43]+1);
t28=*((C_word*)lf[44]+1);
t29=*((C_word*)lf[14]+1);
t30=*((C_word*)lf[16]+1);
t31=*((C_word*)lf[22]+1);
t32=*((C_word*)lf[23]+1);
t33=*((C_word*)lf[24]+1);
t34=*((C_word*)lf[28]+1);
t35=*((C_word*)lf[3]+1);
t36=C_mutate2((C_word*)lf[45]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3640,a[2]=t23,a[3]=t29,a[4]=t24,a[5]=t30,a[6]=t25,a[7]=t31,a[8]=t26,a[9]=t33,a[10]=t27,a[11]=t34,a[12]=t28,a[13]=t35,a[14]=((C_word)li28),tmp=(C_word)a,a+=15,tmp));
t37=C_mutate2((C_word*)lf[72]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[73]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4015,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate2((C_word*)lf[74]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate2((C_word*)lf[75]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4033,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate2((C_word*)lf[76]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4042,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate2((C_word*)lf[77]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4051,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate2((C_word*)lf[78]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4060,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate2((C_word*)lf[79]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4069,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate2((C_word*)lf[80]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4078,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate2((C_word*)lf[81]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate2((C_word*)lf[82]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate2(&lf[83] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4210,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate2((C_word*)lf[84]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t50=*((C_word*)lf[39]+1);
t51=C_mutate2((C_word*)lf[85]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4345,a[2]=t50,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t52=*((C_word*)lf[39]+1);
t53=C_mutate2(&lf[89] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=t52,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate2((C_word*)lf[90]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4838,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t55=*((C_word*)lf[39]+1);
t56=C_mutate2((C_word*)lf[91]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4850,a[2]=t55,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=*((C_word*)lf[39]+1);
t59=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6094,a[2]=t58,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:841: getter-with-setter */
t60=*((C_word*)lf[119]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t60;
av2[1]=t57;
av2[2]=t59;
av2[3]=*((C_word*)lf[91]+1);
av2[4]=lf[120];
((C_proc)(void*)(*((C_word*)t60+1)))(5,av2);}}

/* *equal?-hash in k2735 in k2730 in k1726 */
static void C_fcall f_2739(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,7))){
C_save_and_reclaim_args((void *)trf_2739,3,t1,t2,t3);}
a=C_alloc(13);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2742,a[2]=t7,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2815,a[2]=t7,a[3]=t5,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm:343: recursive-hash */
t10=((C_word*)t7)[1];
f_2815(t10,t1,t2,C_fix(0),t3);}

/* loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_fcall f_4466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_4466,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:735: thunk */
t5=((C_word*)t0)[9];{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)C_fast_retrieve_proc(t5))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t4,C_fix(0));
t6=C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4506,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm:741: func */
t9=((C_word*)t0)[8];{
C_word av2[3];
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)C_fast_retrieve_proc(t9))(3,av2);}}
else{
t7=C_slot(t2,C_fix(1));
/* srfi-69.scm:744: loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}}

/* a6236 in k1726 */
static void C_ccall f_6237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6237,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6244,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=t2;
t5=t3;
f_6244(t5,C_fixnum_greaterp(t4,C_fix(0)));}
else{
t4=t3;
f_6244(t4,C_SCHEME_FALSE);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_srfi_2d69_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("srfi_2d69_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_srfi_2d69_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(729)){
C_save(t1);
C_rereclaim2(729*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,124);
lf[1]=C_h_intern(&lf[1],20,"\003sysnumber-hash-hook");
lf[3]=C_h_intern(&lf[3],11,"number-hash");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_h_intern(&lf[5],5,"\000type");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[7]=C_h_intern(&lf[7],15,"object-uid-hash");
lf[8]=C_h_intern(&lf[8],11,"symbol-hash");
lf[9]=C_h_intern(&lf[9],17,"\003syscheck-keyword");
lf[10]=C_h_intern(&lf[10],11,"\000type-error");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[12]=C_h_intern(&lf[12],8,"keyword\077");
lf[13]=C_h_intern(&lf[13],12,"keyword-hash");
lf[14]=C_h_intern(&lf[14],8,"eq\077-hash");
lf[15]=C_h_intern(&lf[15],16,"hash-by-identity");
lf[16]=C_h_intern(&lf[16],9,"eqv\077-hash");
lf[17]=C_h_intern(&lf[17],26,"\052recursive-hash-max-depth\052");
lf[18]=C_h_intern(&lf[18],24,"recursive-hash-max-depth");
lf[19]=C_h_intern(&lf[19],27,"\052recursive-hash-max-length\052");
lf[20]=C_h_intern(&lf[20],25,"recursive-hash-max-length");
lf[21]=C_h_intern(&lf[21],11,"input-port\077");
lf[22]=C_h_intern(&lf[22],11,"equal\077-hash");
lf[23]=C_h_intern(&lf[23],4,"hash");
lf[24]=C_h_intern(&lf[24],11,"string-hash");
lf[25]=C_h_intern(&lf[25],13,"\003syssubstring");
lf[26]=C_h_intern(&lf[26],15,"\003syscheck-range");
lf[27]=C_h_intern(&lf[27],14,"string-ci-hash");
lf[28]=C_h_intern(&lf[28],14,"string-hash-ci");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[32]=C_h_intern(&lf[32],19,"\052make-hash-function");
lf[33]=C_h_intern(&lf[33],13,"\000bounds-error");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\030Hash value out of bounds");
lf[35]=C_h_intern(&lf[35],15,"\003syscheck-exact");
lf[37]=C_h_intern(&lf[37],10,"hash-table");
lf[38]=C_h_intern(&lf[38],11,"make-vector");
lf[39]=C_h_intern(&lf[39],3,"eq\077");
lf[40]=C_h_intern(&lf[40],4,"eqv\077");
lf[41]=C_h_intern(&lf[41],6,"equal\077");
lf[42]=C_h_intern(&lf[42],8,"string=\077");
lf[43]=C_h_intern(&lf[43],11,"string-ci=\077");
lf[44]=C_h_intern(&lf[44],1,"=");
lf[45]=C_h_intern(&lf[45],15,"make-hash-table");
lf[46]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[47]=C_decode_literal(C_heaptop,"\376U0.8000000000000000444089209850062616169452667236328125\000");
lf[48]=C_h_intern(&lf[48],7,"warning");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[50]=C_h_intern(&lf[50],5,"error");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[52]=C_h_intern(&lf[52],3,"fp<");
lf[53]=C_h_intern(&lf[53],5,"\000test");
lf[54]=C_h_intern(&lf[54],17,"\003syscheck-closure");
lf[55]=C_h_intern(&lf[55],5,"\000hash");
lf[56]=C_h_intern(&lf[56],5,"\000size");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[58]=C_h_intern(&lf[58],8,"\000initial");
lf[59]=C_h_intern(&lf[59],9,"\000min-load");
lf[60]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[61]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[63]=C_h_intern(&lf[63],17,"\003syscheck-inexact");
lf[64]=C_h_intern(&lf[64],9,"\000max-load");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[66]=C_h_intern(&lf[66],10,"\000weak-keys");
lf[67]=C_h_intern(&lf[67],12,"\000weak-values");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[72]=C_h_intern(&lf[72],11,"hash-table\077");
lf[73]=C_h_intern(&lf[73],15,"hash-table-size");
lf[74]=C_h_intern(&lf[74],31,"hash-table-equivalence-function");
lf[75]=C_h_intern(&lf[75],24,"hash-table-hash-function");
lf[76]=C_h_intern(&lf[76],19,"hash-table-min-load");
lf[77]=C_h_intern(&lf[77],19,"hash-table-max-load");
lf[78]=C_h_intern(&lf[78],20,"hash-table-weak-keys");
lf[79]=C_h_intern(&lf[79],22,"hash-table-weak-values");
lf[80]=C_h_intern(&lf[80],23,"hash-table-has-initial\077");
lf[81]=C_h_intern(&lf[81],18,"hash-table-initial");
lf[82]=C_h_intern(&lf[82],18,"hash-table-resize!");
lf[84]=C_h_intern(&lf[84],15,"hash-table-copy");
lf[85]=C_h_intern(&lf[85],18,"hash-table-update!");
lf[86]=C_h_intern(&lf[86],5,"floor");
lf[87]=C_h_intern(&lf[87],13,"\000access-error");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[90]=C_h_intern(&lf[90],26,"hash-table-update!/default");
lf[91]=C_h_intern(&lf[91],15,"hash-table-set!");
lf[92]=C_h_intern(&lf[92],19,"\003sysundefined-value");
lf[93]=C_h_intern(&lf[93],14,"hash-table-ref");
lf[94]=C_h_intern(&lf[94],22,"hash-table-ref/default");
lf[95]=C_h_intern(&lf[95],18,"hash-table-exists\077");
lf[96]=C_h_intern(&lf[96],18,"hash-table-delete!");
lf[97]=C_h_intern(&lf[97],18,"hash-table-remove!");
lf[98]=C_h_intern(&lf[98],17,"hash-table-clear!");
lf[99]=C_h_intern(&lf[99],12,"vector-fill!");
lf[101]=C_h_intern(&lf[101],17,"hash-table-merge!");
lf[102]=C_h_intern(&lf[102],16,"hash-table-merge");
lf[103]=C_h_intern(&lf[103],17,"hash-table->alist");
lf[104]=C_h_intern(&lf[104],17,"alist->hash-table");
lf[105]=C_h_intern(&lf[105],15,"hash-table-keys");
lf[106]=C_h_intern(&lf[106],17,"hash-table-values");
lf[108]=C_h_intern(&lf[108],8,"for-each");
lf[110]=C_h_intern(&lf[110],15,"hash-table-fold");
lf[111]=C_h_intern(&lf[111],19,"hash-table-for-each");
lf[112]=C_h_intern(&lf[112],15,"hash-table-walk");
lf[113]=C_h_intern(&lf[113],14,"hash-table-map");
lf[114]=C_h_intern(&lf[114],9,"\003sysprint");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002)>");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\016#<hash-table (");
lf[117]=C_h_intern(&lf[117],27,"\003sysregister-record-printer");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[119]=C_h_intern(&lf[119],18,"getter-with-setter");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\035(hash-table-ref ht key . def)");
lf[121]=C_h_intern(&lf[121],14,"make-parameter");
lf[122]=C_h_intern(&lf[122],17,"register-feature!");
lf[123]=C_h_intern(&lf[123],7,"srfi-69");
C_register_lf2(lf,124,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:40: register-feature! */
t3=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[123];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* g543 in recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_fcall f_3162(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,6))){
C_save_and_reclaim_args((void *)trf_3162,4,t0,t1,t2,t3);}
/* srfi-69.scm:303: vector-hash */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2742(t4,t1,t2,C_fix(0),((C_word*)t0)[3],C_fix(0),t3);}

/* k4880 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_fcall f_4882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_4882,2,t0,t1);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[7]);
/* srfi-69.scm:665: floor */
t6=*((C_word*)lf[86]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k6228 in a6222 in k2730 in k1726 */
static void C_fcall f_6230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_6230,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate2((C_word*)lf[19]+1 /* (set! *recursive-hash-max-length* ...) */,((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=*((C_word*)lf[19]+1);
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=*((C_word*)lf[19]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_4452,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_slot(((C_word*)t0)[2],t2);
t4=t3;
t5=C_eqp(((C_word*)t0)[3],((C_word*)t0)[4]);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word)li46),tmp=(C_word)a,a+=12,tmp));
t9=((C_word*)t7)[1];
f_4466(t9,((C_word*)t0)[10],t4);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word*)t0)[4],a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_4529(t9,((C_word*)t0)[10],t4);}}

/* f_3591 in *make-hash-function in k2735 in k2730 in k1726 */
static void C_ccall f_3591(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3591,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3595,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:438: user-function */
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}

/* k3593 */
static void C_ccall f_3595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3595,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3598,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:439: ##sys#check-exact */
t4=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[23];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* equal?-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_3174,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[23]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3222,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:348: *equal?-hash */
f_2739(t14,t2,t10);}

/* k4891 in k4880 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_fcall f_4893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4893,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[7]);
t4=t2;
f_4899(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[7],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4899(t3,C_SCHEME_FALSE);}}

/* k4897 in k4891 in k4880 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_fcall f_4899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_4899,2,t0,t1);}
if(C_truep(t1)){
/* srfi-69.scm:668: hash-table-resize! */
t2=*((C_word*)lf[82]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3596 in k3593 */
static void C_ccall f_3598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_3598,2,av);}
t2=C_fixnum_lessp(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(C_truep(t2)?C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* srfi-69.scm:442: ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[33];
av2[3]=lf[23];
av2[4]=lf[34];
av2[5]=((C_word*)t0)[3];
av2[6]=((C_word*)t0)[2];
av2[7]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(8,av2);}}}

/* doloop1208 in doloop1205 in *hash-table-merge! in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5560(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,5))){
C_save_and_reclaim_args((void *)trf_5560,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5573,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5586,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm:1002: *hash-table-update!/default */
t8=lf[89];
f_4610(t8,t4,((C_word*)t0)[3],t5,t6,t7);}}

/* k3128 in recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3130,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(t1)?C_fixnum_plus(((C_word*)t0)[3],C_fix(260)):C_fixnum_plus(((C_word*)t0)[3],C_fix(261)));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k5188 in hash-table-exists? in k5064 in k2735 in k2730 in k1726 */
static C_word C_fcall f_5205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* g539 in recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_fcall f_3150(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,6))){
C_save_and_reclaim_args((void *)trf_3150,4,t0,t1,t2,t3);}
t4=C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm:300: vector-hash */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2742(t5,t1,t2,t4,((C_word*)t0)[3],C_fix(1),t3);}

/* k1924 in k1751 in number-hash in k1726 */
static void C_ccall f_1926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1926,2,av);}
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_fixnum_modulo(t6,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k3980 in k3977 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3982,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)t0)[5];
f_3721(t5,t4);}

/* k1918 in k1751 in number-hash in k1726 */
static void C_ccall f_1920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1920,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3997 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3999,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3718(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:510: ##sys#check-closure */
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[45];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k2701 in eqv?-hash in k1726 */
static void C_ccall f_2703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2703,2,av);}
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_fixnum_modulo(t6,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* hash-table-copy in k2735 in k2730 in k1726 */
static void C_ccall f_4336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4336,3,av);}
t3=C_i_check_structure_2(t2,lf[37],lf[84]);
/* srfi-69.scm:701: *hash-table-copy */
f_4210(t1,t2);}

/* hash-table-exists? in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5174,4,av);}
a=C_alloc(7);
t4=C_i_check_structure_2(t2,lf[37],lf[95]);
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=C_slot(t2,C_fix(3));
t8=t7;
t9=C_slot(t2,C_fix(10));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t6,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t11=C_block_size(t6);
/* srfi-69.scm:906: hash */
t12=t9;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t12;
av2[1]=t10;
av2[2]=t3;
av2[3]=t11;
((C_proc)C_fast_retrieve_proc(t12))(4,av2);}}

/* k4320 in copy-loop in doloop891 in k4218 in *hash-table-copy in k2735 in k2730 in k1726 */
static void C_ccall f_4322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_4322,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop2 in loop in hash-table-keys in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5779(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_5779,4,t0,t1,t2,t3);}
a=C_alloc(3);
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1054: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5763(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm:1055: loop2 */
t9=t1;
t10=t4;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* f_3581 in *make-hash-function in k2735 in k2730 in k1726 */
static void C_ccall f_3581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3581,4,av);}
/* srfi-69.scm:434: user-function */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t4))(7,av2);}}

/* f_3586 in *make-hash-function in k2735 in k2730 in k1726 */
static void C_ccall f_3586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3586,4,av);}
/* srfi-69.scm:436: user-function */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}

/* loop in hash-table-keys in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5763(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_5763,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5779,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5779(t8,t1,t4,t3);}}

/* k3728 in k3725 in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_3730,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:575: hash-table-canonical-length */
f_3533(t2,lf[29],((C_word*)((C_word*)t0)[2])[1]);}

/* k3732 in k3728 in k3725 in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,8))){C_save_and_reclaim((void *)f_3734,2,av);}
a=C_alloc(10);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* srfi-69.scm:585: *make-hash-table */
f_3615(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t3=f_3642(((C_word*)t0)[9]);
if(C_truep(t3)){
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
/* srfi-69.scm:585: *make-hash-table */
f_3615(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm:582: warning */
t5=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[45];
av2[3]=lf[49];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}

/* k5188 in hash-table-exists? in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5190,2,av);}
a=C_alloc(8);
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[5],a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=f_5205(t4,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5245,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5245(t7,((C_word*)t0)[6],t3);}}

/* hash-table-set! in k2735 in k2730 in k1726 */
static void C_ccall f_4850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_4850,5,av);}
a=C_alloc(23);
t5=C_i_check_structure_2(t2,lf[37],lf[91]);
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4933,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t4,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=t9;
t11=t2;
t12=t8;
t13=C_slot(t11,C_fix(1));
t14=t13;
t15=C_slot(t11,C_fix(5));
t16=C_slot(t11,C_fix(6));
t17=t16;
t18=C_block_size(t14);
t19=t18;
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4882,a[2]=t10,a[3]=t11,a[4]=t14,a[5]=t19,a[6]=t12,a[7]=t17,tmp=(C_word)a,a+=8,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4926,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=C_a_i_times(&a,2,t19,t15);
/* srfi-69.scm:664: floor */
t23=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t23;
av2[1]=t21;
av2[2]=t22;
((C_proc)(void*)(*((C_word*)t23+1)))(3,av2);}}

/* loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_fcall f_4529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_4529,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:748: thunk */
t5=((C_word*)t0)[9];{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)C_fast_retrieve_proc(t5))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4566,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:753: test */
t7=((C_word*)t0)[11];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k5571 in doloop1208 in doloop1205 in *hash-table-merge! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5573,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5560(t3,((C_word*)t0)[4],t2);}

/* k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_fcall f_3721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(19,0,2))){
C_save_and_reclaim_args((void *)trf_3721,2,t0,t1);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t3=t2;
f_3724(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[12])[1]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3947,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:521: keyword? */
t6=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k3725 in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_3727,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3754,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:572: fp< */
t4=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[7])[1];
av2[3]=((C_word*)((C_word*)t0)[6])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_fcall f_3724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,0,3))){
C_save_and_reclaim_args((void *)trf_3724,2,t0,t1);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[11],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word)li27),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_3759(t6,t2,((C_word*)((C_word*)t0)[12])[1]);}

/* k4537 in loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4539,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k2130 in check-keyword in k1726 */
static void C_ccall f_2132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_2132,2,av);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* srfi-69.scm:194: ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[10];
av2[3]=C_SCHEME_FALSE;
av2[4]=lf[11];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
t2=C_i_car(((C_word*)t0)[3]);
/* srfi-69.scm:194: ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[10];
av2[3]=t2;
av2[4]=lf[11];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}}}

/* a5585 in doloop1208 in doloop1205 in *hash-table-merge! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5586,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_fcall f_3718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(19,0,2))){
C_save_and_reclaim_args((void *)trf_3718,2,t0,t1);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t3=t2;
f_3721(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[12])[1]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3979,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:515: keyword? */
t6=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* loop in k5082 in hash-table-ref/default in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5138(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5138,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[2];
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5154,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:895: test */
t7=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* ##sys#check-keyword in k1726 */
static void C_ccall f_2125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_2125,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2132,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:193: keyword? */
t5=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* hash-table-merge! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5593,4,av);}
t4=C_i_check_structure_2(t2,lf[37],lf[101]);
t5=C_i_check_structure_2(t3,lf[37],lf[101]);
/* srfi-69.scm:1007: *hash-table-merge! */
f_5525(t1,t2,t3);}

/* loop in k4946 in k4931 in hash-table-set! in k2735 in k2730 in k1726 */
static void C_fcall f_4965(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4965,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[6],t4);
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_i_set_i_slot(((C_word*)t0)[7],C_fix(2),((C_word*)t0)[8]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_i_setslot(t3,C_fix(1),((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:825: loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4358(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_4358,2,av);}
a=C_alloc(24);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_fixnum_plus(t2,C_fix(1));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=t5;
t7=((C_word*)t0)[2];
t8=t4;
t9=C_slot(t7,C_fix(1));
t10=t9;
t11=C_slot(t7,C_fix(5));
t12=C_slot(t7,C_fix(6));
t13=t12;
t14=C_block_size(t10);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4386,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t15,a[6]=t8,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4430,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=C_a_i_times(&a,2,t15,t11);
/* srfi-69.scm:664: floor */
t19=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t19;
av2[1]=t17;
av2[2]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}

/* k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4355,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:722: ##sys#check-closure */
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[85];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5152 in loop in k5082 in hash-table-ref/default in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5154,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[3],C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:897: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5138(t3,((C_word*)t0)[2],t2);}}

/* *hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5878(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_5878,3,t1,t2,t3);}
a=C_alloc(9);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5890,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t9,a[6]=((C_word)li91),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5890(t11,t1,C_fix(0));}

/* k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_fcall f_4349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_4349,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=C_i_check_structure_2(((C_word*)t0)[2],lf[37],lf[85]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:721: ##sys#check-closure */
t5=*((C_word*)lf[54]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=lf[85];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* doloop1205 in *hash-table-merge! in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_5537,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5547,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5560,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5560(t8,t3,t4);}}

/* hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4345(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +12,c,2))){
C_save_and_reclaim((void*)f_4345,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+12);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4349,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nullp(t5))){
t7=C_slot(t2,C_fix(9));
if(C_truep(t7)){
t8=t6;
f_4349(t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=t3,a[3]=t2,a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
t9=t6;
f_4349(t9,t8);}}
else{
t7=t6;
f_4349(t7,C_i_car(t5));}}

/* k5545 in doloop1205 in *hash-table-merge! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5547,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5537(t3,((C_word*)t0)[4],t2);}

/* eqv?-hash in k1726 */
static void C_ccall f_2655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +7,c,3))){
C_save_and_reclaim((void*)f_2655,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+7);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[16]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2703,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(t2,t10);
f_2703(2,av2);}}
else{
if(C_truep(C_charp(t2))){
t15=C_fix(C_character_code(t2));
t16=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_fixnum_xor(t15,t10);
f_2703(2,av2);}}
else{
switch(t2){
case C_SCHEME_TRUE:
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(256),t10);
f_2703(2,av2);}
case C_SCHEME_FALSE:
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(257),t10);
f_2703(2,av2);}
default:
if(C_truep(C_i_nullp(t2))){
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(258),t10);
f_2703(2,av2);}}
else{
if(C_truep(C_eofp(t2))){
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(259),t10);
f_2703(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t15=C_slot(t2,C_fix(1));
t16=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_u_i_string_hash(t15,t10);
f_2703(2,av2);}}
else{
if(C_truep(C_i_numberp(t2))){
t15=t14;
if(C_truep(C_i_flonump(t2))){
t16=C_subbyte(t2,C_fix(7));
t17=C_subbyte(t2,C_fix(6));
t18=C_subbyte(t2,C_fix(5));
t19=C_subbyte(t2,C_fix(4));
t20=C_subbyte(t2,C_fix(3));
t21=C_subbyte(t2,C_fix(2));
t22=C_subbyte(t2,C_fix(1));
t23=C_subbyte(t2,C_fix(0));
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t22,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t21,t26);
t28=C_fixnum_shift_left(t27,C_fix(1));
t29=C_fixnum_plus(t20,t28);
t30=C_fixnum_shift_left(t29,C_fix(1));
t31=C_fixnum_plus(t19,t30);
t32=C_fixnum_shift_left(t31,C_fix(1));
t33=C_fixnum_plus(t18,t32);
t34=C_fixnum_shift_left(t33,C_fix(1));
t35=C_fixnum_plus(t17,t34);
t36=C_fixnum_shift_left(t35,C_fix(1));
t37=C_fixnum_plus(t16,t36);
t38=t15;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t38;
av2[1]=C_fixnum_times(C_fix(331804471),t37);
((C_proc)(void*)(*((C_word*)t38+1)))(2,av2);}}
else{
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2627,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:148: ##sys#number-hash-hook */
t17=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t17;
av2[1]=t16;
av2[2]=t2;
av2[3]=t10;
((C_proc)(void*)(*((C_word*)t17+1)))(4,av2);}}}
else{
if(C_truep(C_blockp(t2))){
/* srfi-69.scm:168: *equal?-hash */
f_2739(t14,t2,t10);}
else{
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_fixnum_xor(C_fix(262),t10);
f_2703(2,av2);}}}}}}}}}}

/* k2165 in keyword-hash in k1726 */
static void C_ccall f_2167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2167,2,av);}
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[13]);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(1));
t5=C_u_i_string_hash(t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[5];
t7=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t8=C_fixnum_lessp(t5,C_fix(0));
t9=(C_truep(t8)?C_fixnum_negate(t5):t5);
t10=C_fixnum_and(t7,t9);
t11=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_fixnum_modulo(t10,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}

/* loop in vector-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_fcall f_2759(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_2759,5,t0,t1,t2,t3,t4);}
a=C_alloc(8);
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_fixnum_shift_left(t2,C_fix(4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2793,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t9=C_slot(((C_word*)t0)[3],t3);
t10=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:317: recursive-hash */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2815(t11,t8,t9,t10,((C_word*)t0)[6]);}}

/* copy-loop in doloop891 in k4218 in *hash-table-copy in k2735 in k2730 in k1726 */
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_4301,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=C_a_i_cons(&a,2,t4,t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4322,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_slot(t2,C_fix(1));
/* srfi-69.scm:692: copy-loop */
t11=t8;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k6102 in a6093 in k2735 in k2730 in k1726 */
static void C_ccall f_6104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6104,2,av);}
a=C_alloc(8);
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=C_slot(((C_word*)t0)[2],C_fix(3));
t5=t4;
t6=C_slot(((C_word*)t0)[2],C_fix(10));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_block_size(t3);
/* srfi-69.scm:852: hash */
t9=t6;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=((C_word*)t0)[5];
av2[3]=t8;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}

/* *hash-table-fold in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5951(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_5951,4,t1,t2,t3,t4);}
a=C_alloc(9);
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=t7;
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5963,a[2]=t8,a[3]=t6,a[4]=t10,a[5]=t3,a[6]=((C_word)li94),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_5963(t12,t1,C_fix(0),t4);}

/* k4504 in loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4506,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6114 in k6102 in a6093 in k2735 in k2730 in k1726 */
static void C_ccall f_6116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_6116,2,av);}
a=C_alloc(9);
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6131(t7,((C_word*)t0)[7],t3);}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6173,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word)li104),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_6173(t7,((C_word*)t0)[7],t3);}}

/* k3281 in string-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3283(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3283,2,av);}
t2=C_u_i_string_hash(t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t5=C_fixnum_lessp(t2,C_fix(0));
t6=(C_truep(t5)?C_fixnum_negate(t2):t2);
t7=C_fixnum_and(t4,t6);
t8=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_fixnum_modulo(t7,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k5256 in loop in k5188 in hash-table-exists? in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5258,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:919: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5245(t3,((C_word*)t0)[2],t2);}}

/* k2791 in loop in vector-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_ccall f_2793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2793,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],t2);
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:315: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2759(t6,((C_word*)t0)[7],t3,t4,t5);}

/* k5936 in for-each-loop1305 in doloop1300 in *hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5938,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5928(t3,((C_word*)t0)[4],t2);}

/* keyword-hash in k1726 */
static void C_ccall f_2151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +6,c,3))){
C_save_and_reclaim((void*)f_2151,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+6);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2167,a[2]=t6,a[3]=t2,a[4]=t11,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:207: ##sys#check-keyword */
t15=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=t2;
av2[3]=lf[13];
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}

/* for-each-loop1305 in doloop1300 in *hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5928,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5938,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* srfi-69.scm:1081: g1306 */
t5=((C_word*)t0)[3];
f_5898(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5917 in doloop1300 in *hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5919,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5890(t3,((C_word*)t0)[4],t2);}

/* loop in k5188 in hash-table-exists? in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5245(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_5245,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5258,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:918: test */
t6=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t6;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}}

/* string-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +11,c,5))){
C_save_and_reclaim((void*)f_3249,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+11);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_FALSE:C_i_car(t13));
t16=C_i_nullp(t13);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t18=C_i_nullp(t17);
t19=(C_truep(t18)?lf[0]:C_i_car(t17));
t20=t19;
t21=C_i_nullp(t17);
t22=(C_truep(t21)?C_SCHEME_END_OF_LIST:C_i_cdr(t17));
t23=C_i_check_string_2(t2,lf[24]);
t24=C_i_check_exact_2(t6,lf[24]);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3283,a[2]=t20,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t11)){
t26=(C_truep(t15)?t15:C_block_size(t2));
t27=t26;
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3323,a[2]=t25,a[3]=t2,a[4]=t11,a[5]=t27,tmp=(C_word)a,a+=6,tmp);
t29=C_block_size(t2);
/* srfi-69.scm:360: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t28;
av2[2]=t11;
av2[3]=C_fix(0);
av2[4]=t29;
av2[5]=lf[24];
tp(6,av2);}}
else{
t26=t25;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t26;
av2[1]=t2;
f_3283(2,av2);}}}

/* k5296 in hash-table-delete! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_5298,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=C_fixnum_difference(t5,C_fix(1));
t7=t6;
t8=C_slot(((C_word*)t0)[3],t2);
t9=C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5318,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t7,a[7]=((C_word)li63),tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=f_5318(t10,C_SCHEME_FALSE,t8);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t11,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=((C_word)li64),tmp=(C_word)a,a+=10,tmp));
t13=((C_word*)t11)[1];
f_5365(t13,((C_word*)t0)[6],C_SCHEME_FALSE,t8);}}

/* k4395 in k4384 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_fcall f_4397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4397,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[7]);
t4=t2;
f_4403(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[7],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4403(t3,C_SCHEME_FALSE);}}

/* loop in k6114 in k6102 in a6093 in k2735 in k2730 in k1726 */
static void C_fcall f_6173(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_6173,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm:865: def */
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6192,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:867: test */
t7=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k4384 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_fcall f_4386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_4386,2,t0,t1);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4422,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[7]);
/* srfi-69.scm:665: floor */
t6=*((C_word*)lf[86]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3220 in equal?-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3222,2,av);}
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_fixnum_modulo(t6,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* hash-table-delete! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5282,4,av);}
a=C_alloc(7);
t4=C_i_check_structure_2(t2,lf[37],lf[96]);
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=C_slot(t2,C_fix(10));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5298,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:930: hash */
t10=t8;{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t3;
av2[3]=t7;
((C_proc)C_fast_retrieve_proc(t10))(4,av2);}}

/* k6190 in loop in k6114 in k6102 in a6093 in k2735 in k2730 in k1726 */
static void C_ccall f_6192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6192,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[3],C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:869: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6173(t3,((C_word*)t0)[2],t2);}}

/* loop in k6114 in k6102 in a6093 in k2735 in k2730 in k1726 */
static void C_fcall f_6131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_6131,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm:857: def */
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(t3,C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:861: loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* *hash-table-copy in k2735 in k2730 in k1726 */
static void C_fcall f_4210(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4210,2,t1,t2);}
a=C_alloc(6);
t3=C_slot(t2,C_fix(1));
t4=t3;
t5=C_block_size(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4220,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:677: make-vector */
t8=*((C_word*)lf[38]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* string-ci-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +11,c,5))){
C_save_and_reclaim((void*)f_3390,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+11);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_FALSE:C_i_car(t13));
t16=C_i_nullp(t13);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t18=C_i_nullp(t17);
t19=(C_truep(t18)?lf[0]:C_i_car(t17));
t20=t19;
t21=C_i_nullp(t17);
t22=(C_truep(t21)?C_SCHEME_END_OF_LIST:C_i_cdr(t17));
t23=C_i_check_string_2(t2,lf[27]);
t24=C_i_check_exact_2(t6,lf[27]);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3424,a[2]=t20,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t11)){
t26=(C_truep(t15)?t15:C_block_size(t2));
t27=t26;
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3464,a[2]=t25,a[3]=t2,a[4]=t11,a[5]=t27,tmp=(C_word)a,a+=6,tmp);
t29=C_block_size(t2);
/* srfi-69.scm:372: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t28;
av2[2]=t11;
av2[3]=C_fix(0);
av2[4]=t29;
av2[5]=lf[24];
tp(6,av2);}}
else{
t26=t25;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t26;
av2[1]=t2;
f_3424(2,av2);}}}

/* k3945 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3947,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3724(t3,t2);}
else{
t2=C_i_check_exact_2(((C_word*)t0)[3],lf[45]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),((C_word*)t0)[3]))){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_3953(2,av2);}}
else{
/* srfi-69.scm:524: error */
t4=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[45];
av2[3]=lf[71];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}}

/* loop in k5296 in hash-table-delete! in k5064 in k2735 in k2730 in k1726 */
static C_word C_fcall f_5318(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
t5=C_slot(t3,C_fix(0));
t6=C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?C_i_setslot(t1,C_fix(1),t4):C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[4],t4));
t8=C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[6]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* doloop891 in k4218 in *hash-table-copy in k2735 in k2730 in k1726 */
static void C_fcall f_4239(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,8))){
C_save_and_reclaim_args((void *)trf_4239,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_slot(((C_word*)t0)[3],C_fix(3));
t4=C_slot(((C_word*)t0)[3],C_fix(4));
t5=C_slot(((C_word*)t0)[3],C_fix(2));
t6=C_slot(((C_word*)t0)[3],C_fix(5));
t7=C_slot(((C_word*)t0)[3],C_fix(6));
t8=C_slot(((C_word*)t0)[3],C_fix(9));
/* srfi-69.scm:680: *make-hash-table */
f_3615(t1,t3,t4,t5,t6,t7,t8,C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[6],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4301,a[2]=t6,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4301(t8,t3,t4);}}

/* k3951 in k3945 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3953,2,av);}
t2=C_i_fixnum_min(C_fix(1073741823),((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t4);
t6=((C_word*)t0)[5];
f_3724(t6,t5);}

/* k6005 in fold2 in loop in *hash-table-fold in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6007,2,av);}
/* srfi-69.scm:1101: fold2 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5979(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k6022 in hash-table-fold in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6024,2,av);}
/* srfi-69.scm:1107: *hash-table-fold */
f_5951(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* recursive-hash in *equal?-hash in k2735 in k2730 in k1726 */
static void C_fcall f_2815(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_2815,5,t0,t1,t2,t3,t4);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t3,*((C_word*)lf[17]+1)))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_fixnum_xor(C_fix(99),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_fixnump(t2))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_fixnum_xor(t2,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_charp(t2))){
t5=C_fix(C_character_code(t2));
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_fixnum_xor(t5,t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
switch(t2){
case C_SCHEME_TRUE:
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_fixnum_xor(C_fix(256),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}
case C_SCHEME_FALSE:
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_fixnum_xor(C_fix(257),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}
default:
if(C_truep(C_i_nullp(t2))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_fixnum_xor(C_fix(258),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_eofp(t2))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_fixnum_xor(C_fix(259),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t5=t1;
t6=t2;
t7=t4;
t8=C_slot(t6,C_fix(1));
t9=t5;{
C_word av2[2];
av2[0]=t9;
av2[1]=C_u_i_string_hash(t8,t7);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
if(C_truep(C_i_numberp(t2))){
t5=t1;
t6=t2;
t7=t4;
if(C_truep(C_i_flonump(t6))){
t8=C_subbyte(t6,C_fix(7));
t9=C_subbyte(t6,C_fix(6));
t10=C_subbyte(t6,C_fix(5));
t11=C_subbyte(t6,C_fix(4));
t12=C_subbyte(t6,C_fix(3));
t13=C_subbyte(t6,C_fix(2));
t14=C_subbyte(t6,C_fix(1));
t15=C_subbyte(t6,C_fix(0));
t16=C_fixnum_shift_left(t15,C_fix(1));
t17=C_fixnum_plus(t14,t16);
t18=C_fixnum_shift_left(t17,C_fix(1));
t19=C_fixnum_plus(t13,t18);
t20=C_fixnum_shift_left(t19,C_fix(1));
t21=C_fixnum_plus(t12,t20);
t22=C_fixnum_shift_left(t21,C_fix(1));
t23=C_fixnum_plus(t11,t22);
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t10,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t9,t26);
t28=C_fixnum_shift_left(t27,C_fix(1));
t29=C_fixnum_plus(t8,t28);
t30=t5;{
C_word av2[2];
av2[0]=t30;
av2[1]=C_fixnum_times(C_fix(331804471),t29);
((C_proc)(void*)(*((C_word*)t30+1)))(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:148: ##sys#number-hash-hook */
t9=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t9;
av2[1]=t8;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}
else{
t5=t2;
if(C_truep(C_blockp(t5))){
t6=t2;
if(C_truep(C_byteblockp(t6))){
t7=t1;
t8=t2;
t9=t4;
t10=t7;{
C_word av2[2];
av2[0]=t10;
av2[1]=C_u_i_string_hash(t8,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3071,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:337: g525 */
t8=t7;
f_3071(t8,t1,t2,t4);}
else{
t7=t2;
if(C_truep(C_portp(t7))){
t8=t1;
t9=t2;
t10=t4;
t11=C_peek_fixnum(t9,C_fix(0));
t12=C_fixnum_shift_left(t11,C_fix(4));
t13=C_fixnum_xor(t12,t10);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3130,a[2]=t8,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:295: input-port? */
t16=*((C_word*)lf[21]+1);{
C_word av2[3];
av2[0]=t16;
av2[1]=t15;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}
else{
t8=t2;
if(C_truep(C_specialp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:339: g539 */
t10=t9;
f_3150(t10,t1,t2,t4);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:340: g543 */
t10=t9;
f_3162(t10,t1,t2,t4);}}}}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_fixnum_xor(C_fix(262),t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}}}}}}

/* hash-table-fold in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6017(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6017,5,av);}
a=C_alloc(6);
t5=C_i_check_structure_2(t2,lf[37],lf[110]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6024,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:1106: ##sys#check-closure */
t7=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t3;
av2[3]=lf[110];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k3870 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3872,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(C_flonum_lessp(lf[60],((C_word*)t0)[3]))?C_flonum_lessp(((C_word*)t0)[3],lf[61]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3759(t6,((C_word*)t0)[6],t5);}
else{
/* srfi-69.scm:561: error */
t4=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[45];
av2[3]=lf[65];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_fcall f_4610(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,0,2))){
C_save_and_reclaim_args((void *)trf_4610,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(24);
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4690,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t10=t9;
t11=t2;
t12=t8;
t13=C_slot(t11,C_fix(1));
t14=t13;
t15=C_slot(t11,C_fix(5));
t16=C_slot(t11,C_fix(6));
t17=t16;
t18=C_block_size(t14);
t19=t18;
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4639,a[2]=t10,a[3]=t11,a[4]=t14,a[5]=t19,a[6]=t12,a[7]=t17,tmp=(C_word)a,a+=8,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4683,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=C_a_i_times(&a,2,t19,t15);
/* srfi-69.scm:664: floor */
t23=*((C_word*)lf[86]+1);{
C_word av2[3];
av2[0]=t23;
av2[1]=t21;
av2[2]=t22;
((C_proc)(void*)(*((C_word*)t23+1)))(3,av2);}}

/* hash-table-canonical-length in k2735 in k2730 in k1726 */
static void C_fcall f_3533(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_3533,3,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3539,a[2]=t3,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=f_3539(t4,t2);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in hash-table-canonical-length in k2735 in k2730 in k1726 */
static C_word C_fcall f_3539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
t2=C_slot(t1,C_fix(0));
t3=C_slot(t1,C_fix(1));
t4=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
if(C_truep(t4)){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}
else{
if(C_truep(C_i_nullp(t3))){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}}

/* k4564 in loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4566,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:754: func */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t2=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:757: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4529(t3,((C_word*)t0)[3],t2);}}

/* k3873 in k3870 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3875,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3759(t4,((C_word*)t0)[6],t3);}

/* k3850 in k3847 in k3782 in k3778 in loop in k3722 in k3719 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3852,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3759(t4,((C_word*)t0)[6],t3);}

/* hash-table-merge in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5605,4,av);}
a=C_alloc(4);
t4=C_i_check_structure_2(t2,lf[37],lf[102]);
t5=C_i_check_structure_2(t3,lf[37],lf[102]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5619,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1012: *hash-table-copy */
f_4210(t6,t2);}

/* k4637 in *hash-table-update!/default in k2735 in k2730 in k1726 */
static void C_fcall f_4639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_4639,2,t0,t1);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4675,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[7]);
/* srfi-69.scm:665: floor */
t6=*((C_word*)lf[86]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k4567 in k4564 in loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4569,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4293 in doloop891 in k4218 in *hash-table-copy in k2735 in k2730 in k1726 */
static void C_ccall f_4295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4295,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4239(t4,((C_word*)t0)[5],t3);}

/* f_4601 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_4601,2,av);}
/* srfi-69.scm:716: ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[87];
av2[3]=lf[85];
av2[4]=lf[88];
av2[5]=((C_word*)t0)[2];
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k3977 in k3716 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3979,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3721(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:516: ##sys#check-closure */
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[45];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* hash-for-test in make-hash-table in k2735 in k2730 in k1726 */
static C_word C_fcall f_3642(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_overflow_check;{}
t1=C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t2=(C_truep(t1)?t1:C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t2)){
return(((C_word*)t0)[4]);}
else{
t3=C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
t4=(C_truep(t3)?t3:C_eqp(*((C_word*)lf[40]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t4)){
return(((C_word*)t0)[6]);}
else{
t5=C_eqp(((C_word*)t0)[7],((C_word*)((C_word*)t0)[3])[1]);
t6=(C_truep(t5)?t5:C_eqp(*((C_word*)lf[41]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t6)){
return(((C_word*)t0)[8]);}
else{
t7=C_eqp(((C_word*)t0)[9],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_truep(t7)?t7:C_eqp(*((C_word*)lf[42]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t8)){
return(((C_word*)t0)[10]);}
else{
t9=C_eqp(((C_word*)t0)[11],((C_word*)((C_word*)t0)[3])[1]);
t10=(C_truep(t9)?t9:C_eqp(*((C_word*)lf[43]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t10)){
return(((C_word*)t0)[12]);}
else{
t11=C_eqp(((C_word*)t0)[13],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t11)){
return((C_truep(t11)?((C_word*)t0)[14]:C_SCHEME_FALSE));}
else{
t12=C_eqp(*((C_word*)lf[44]+1),((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t12)?((C_word*)t0)[14]:C_SCHEME_FALSE));}}}}}}}

/* make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +48,c,2))){
C_save_and_reclaim((void*)f_3640,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+48);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[41]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[46];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[47];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3642,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3718,a[2]=t10,a[3]=t8,a[4]=t1,a[5]=t6,a[6]=t14,a[7]=t16,a[8]=t12,a[9]=t17,a[10]=((C_word*)t0)[7],a[11]=t2,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3718(t19,C_SCHEME_UNDEFINED);}
else{
t19=C_i_car(((C_word*)t4)[1]);
t20=t19;
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3999,a[2]=t18,a[3]=t6,a[4]=t20,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:509: keyword? */
t22=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t22;
av2[1]=t21;
av2[2]=t20;
((C_proc)(void*)(*((C_word*)t22+1)))(3,av2);}}}

/* k3321 in string-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_3323,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* srfi-69.scm:361: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(0);
av2[4]=t3;
av2[5]=lf[24];
tp(6,av2);}}

/* k3324 in k3321 in string-hash in k2735 in k2730 in k1726 */
static void C_ccall f_3326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3326,2,av);}
/* srfi-69.scm:362: ##sys#substring */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[25]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[25]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
tp(5,av2);}}

/* k4555 in loop in k4450 in k4435 in k4356 in k4353 in k4347 in hash-table-update! in k2735 in k2730 in k1726 */
static void C_ccall f_4557(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4557,2,av);}
/* srfi-69.scm:748: func */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k6071 in a6064 in k6058 in hash-table-map in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_6073,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5617 in hash-table-merge in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5619,2,av);}
/* srfi-69.scm:1012: *hash-table-merge! */
f_5525(((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4221 in k4218 in *hash-table-copy in k2735 in k2730 in k1726 */
static void C_ccall f_4223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4223,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_setslot(t1,C_fix(2),t2);
t4=C_slot(((C_word*)t0)[2],C_fix(10));
t5=C_i_setslot(t1,C_fix(10),t4);
t6=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k4218 in *hash-table-copy in k2735 in k2730 in k1726 */
static void C_ccall f_4220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_4220,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4239,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word)li43),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_4239(t7,t3,C_fix(0));}

/* k6080 in a6077 in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_6082,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(2));
/* srfi-69.scm:1131: ##sys#print */
t4=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* alist->hash-table in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_5694,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=C_i_check_list_2(t2,lf[104]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5701,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[45]+1);
av2[3]=t3;
C_apply(4,av2);}}

/* a6077 in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6078,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6082,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1130: ##sys#print */
t5=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[116];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k6074 in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6076,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a6093 in k2735 in k2730 in k1726 */
static void C_ccall f_6094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +12,c,3))){
C_save_and_reclaim((void*)f_6094,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+12);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6214,a[2]=t3,a[3]=t2,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp):C_i_car(t4));
t7=t6;
t8=C_i_check_structure_2(t2,lf[37],lf[93]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6104,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:848: ##sys#check-closure */
t10=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t7;
av2[3]=lf[93];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* k6083 in k6080 in a6077 in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6085,2,av);}
/* srfi-69.scm:1132: ##sys#print */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[115];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* loop in hash-table->alist in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5636(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_5636,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5652,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5652(t8,t1,t4,t3);}}

/* k6034 in hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6036(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6036,2,av);}
/* srfi-69.scm:1112: *hash-table-for-each */
f_5878(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* hash-table-for-each in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6029,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[37],lf[111]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6036,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1111: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=lf[111];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k3627 in k3617 in *make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3629(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3629,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(10),t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop2 in loop in hash-table->alist in k5064 in k2735 in k2730 in k1726 */
static void C_fcall f_5652(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5652,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1026: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5636(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_slot(t5,C_fix(1));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm:1027: loop2 */
t11=t1;
t12=t4;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* hash-table-walk in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6041,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[37],lf[112]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6048,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1116: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=lf[112];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* doloop864 in k4192 in k4189 in hash-table-resize! in k2735 in k2730 in k1726 */
static void C_fcall f_4117(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,0,3))){
C_save_and_reclaim_args((void *)trf_4117,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4127,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4140,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4140(t8,t3,t4);}}

/* hash-table-remove! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5413,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[37],lf[97]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5420,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:966: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=lf[97];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k4000 in k3997 in make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_4002(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4002,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)t0)[5];
f_3718(t5,t4);}

/* *make-hash-table in k2735 in k2730 in k1726 */
static void C_fcall f_3615(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_3615,8,t1,t2,t3,t4,t5,t6,t7,t8);}
a=C_alloc(8);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3619,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t8))){
/* srfi-69.scm:451: make-vector */
t10=*((C_word*)lf[38]+1);{
C_word av2[4];
av2[0]=t10;
av2[1]=t9;
av2[2]=t4;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t10=t9;{
C_word av2[2];
av2[0]=t10;
av2[1]=C_i_car(t8);
f_3619(2,av2);}}}

/* k3617 in *make-hash-table in k2735 in k2730 in k1726 */
static void C_ccall f_3619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_3619,2,av);}
a=C_alloc(16);
t2=C_a_i_record(&a,11,lf[37],t1,C_fix(0),((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[6],C_SCHEME_FALSE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3629,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:454: *make-hash-function */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* hash-table? in k2735 in k2730 in k1726 */
static void C_ccall f_4009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4009,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[37]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* hash-table-map in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6053,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[37],lf[113]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6060,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1121: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=lf[113];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5418 in hash-table-remove! in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_5420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_5420,2,av);}
a=C_alloc(13);
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=C_block_size(t3);
t5=t4;
t6=C_slot(((C_word*)t0)[2],C_fix(2));
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5434,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=t10,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_5434(t12,((C_word*)t0)[4],C_fix(0));}

/* k6046 in hash-table-walk in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6048,2,av);}
/* srfi-69.scm:1117: *hash-table-for-each */
f_5878(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2009 in object-uid-hash in k1726 */
static void C_ccall f_2011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2011,2,av);}
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_fixnum_modulo(t6,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k6058 in hash-table-map in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_6060,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[2],a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1122: *hash-table-fold */
f_5951(((C_word*)t0)[3],((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST);}

/* a6064 in k6058 in hash-table-map in k5064 in k2735 in k2730 in k1726 */
static void C_ccall f_6065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6065,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6073,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1122: func */
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[244] = {
{"f_4024:srfi_2d69_2escm",(void*)f_4024},
{"f_5621:srfi_2d69_2escm",(void*)f_5621},
{"f_5979:srfi_2d69_2escm",(void*)f_5979},
{"f_5365:srfi_2d69_2escm",(void*)f_5365},
{"f_4015:srfi_2d69_2escm",(void*)f_4015},
{"f_5963:srfi_2d69_2escm",(void*)f_5963},
{"f_5828:srfi_2d69_2escm",(void*)f_5828},
{"f_4719:srfi_2d69_2escm",(void*)f_4719},
{"f_1737:srfi_2d69_2escm",(void*)f_1737},
{"f_1731:srfi_2d69_2escm",(void*)f_1731},
{"f_4729:srfi_2d69_2escm",(void*)f_4729},
{"f_4197:srfi_2d69_2escm",(void*)f_4197},
{"f_4191:srfi_2d69_2escm",(void*)f_4191},
{"f_4194:srfi_2d69_2escm",(void*)f_4194},
{"f_5844:srfi_2d69_2escm",(void*)f_5844},
{"f_2343:srfi_2d69_2escm",(void*)f_2343},
{"f_1753:srfi_2d69_2escm",(void*)f_1753},
{"f_4184:srfi_2d69_2escm",(void*)f_4184},
{"f_5813:srfi_2d69_2escm",(void*)f_5813},
{"f_4705:srfi_2d69_2escm",(void*)f_4705},
{"f_5014:srfi_2d69_2escm",(void*)f_5014},
{"f_4156:srfi_2d69_2escm",(void*)f_4156},
{"f_3808:srfi_2d69_2escm",(void*)f_3808},
{"f_4140:srfi_2d69_2escm",(void*)f_4140},
{"f_4430:srfi_2d69_2escm",(void*)f_4430},
{"f_4437:srfi_2d69_2escm",(void*)f_4437},
{"f_5460:srfi_2d69_2escm",(void*)f_5460},
{"f_5384:srfi_2d69_2escm",(void*)f_5384},
{"f_1728:srfi_2d69_2escm",(void*)f_1728},
{"f_3821:srfi_2d69_2escm",(void*)f_3821},
{"f_5434:srfi_2d69_2escm",(void*)f_5434},
{"f_3784:srfi_2d69_2escm",(void*)f_3784},
{"f_3780:srfi_2d69_2escm",(void*)f_3780},
{"f_3787:srfi_2d69_2escm",(void*)f_3787},
{"f_4690:srfi_2d69_2escm",(void*)f_4690},
{"f_4127:srfi_2d69_2escm",(void*)f_4127},
{"f_4811:srfi_2d69_2escm",(void*)f_4811},
{"f_4814:srfi_2d69_2escm",(void*)f_4814},
{"f_3798:srfi_2d69_2escm",(void*)f_3798},
{"f_2391:srfi_2d69_2escm",(void*)f_2391},
{"f_3033:srfi_2d69_2escm",(void*)f_3033},
{"f_3849:srfi_2d69_2escm",(void*)f_3849},
{"f_3424:srfi_2d69_2escm",(void*)f_3424},
{"f_3839:srfi_2d69_2escm",(void*)f_3839},
{"f_3770:srfi_2d69_2escm",(void*)f_3770},
{"f_4838:srfi_2d69_2escm",(void*)f_4838},
{"f_4683:srfi_2d69_2escm",(void*)f_4683},
{"f_4845:srfi_2d69_2escm",(void*)f_4845},
{"f_5084:srfi_2d69_2escm",(void*)f_5084},
{"f_4656:srfi_2d69_2escm",(void*)f_4656},
{"f_4650:srfi_2d69_2escm",(void*)f_4650},
{"f_3754:srfi_2d69_2escm",(void*)f_3754},
{"f_3750:srfi_2d69_2escm",(void*)f_3750},
{"f_5099:srfi_2d69_2escm",(void*)f_5099},
{"f_3759:srfi_2d69_2escm",(void*)f_3759},
{"f_5068:srfi_2d69_2escm",(void*)f_5068},
{"f_5066:srfi_2d69_2escm",(void*)f_5066},
{"f_4675:srfi_2d69_2escm",(void*)f_4675},
{"f_4042:srfi_2d69_2escm",(void*)f_4042},
{"f_6214:srfi_2d69_2escm",(void*)f_6214},
{"f_4033:srfi_2d69_2escm",(void*)f_4033},
{"f_5748:srfi_2d69_2escm",(void*)f_5748},
{"f_5044:srfi_2d69_2escm",(void*)f_5044},
{"f_4069:srfi_2d69_2escm",(void*)f_4069},
{"f_4060:srfi_2d69_2escm",(void*)f_4060},
{"f_2037:srfi_2d69_2escm",(void*)f_2037},
{"f_5735:srfi_2d69_2escm",(void*)f_5735},
{"f_5447:srfi_2d69_2escm",(void*)f_5447},
{"f_4051:srfi_2d69_2escm",(void*)f_4051},
{"f_5725:srfi_2d69_2escm",(void*)f_5725},
{"f_5723:srfi_2d69_2escm",(void*)f_5723},
{"f_5715:srfi_2d69_2escm",(void*)f_5715},
{"f_4078:srfi_2d69_2escm",(void*)f_4078},
{"f_6223:srfi_2d69_2escm",(void*)f_6223},
{"f_3095:srfi_2d69_2escm",(void*)f_3095},
{"f_3071:srfi_2d69_2escm",(void*)f_3071},
{"f_5898:srfi_2d69_2escm",(void*)f_5898},
{"f_5479:srfi_2d69_2escm",(void*)f_5479},
{"f_5890:srfi_2d69_2escm",(void*)f_5890},
{"f_5701:srfi_2d69_2escm",(void*)f_5701},
{"f_5702:srfi_2d69_2escm",(void*)f_5702},
{"f_2627:srfi_2d69_2escm",(void*)f_2627},
{"f_4494:srfi_2d69_2escm",(void*)f_4494},
{"f_4090:srfi_2d69_2escm",(void*)f_4090},
{"f_3464:srfi_2d69_2escm",(void*)f_3464},
{"f_3467:srfi_2d69_2escm",(void*)f_3467},
{"f_3083:srfi_2d69_2escm",(void*)f_3083},
{"f_5509:srfi_2d69_2escm",(void*)f_5509},
{"f_5516:srfi_2d69_2escm",(void*)f_5516},
{"f_4948:srfi_2d69_2escm",(void*)f_4948},
{"f_5525:srfi_2d69_2escm",(void*)f_5525},
{"f_4954:srfi_2d69_2escm",(void*)f_4954},
{"f_4403:srfi_2d69_2escm",(void*)f_4403},
{"f_4778:srfi_2d69_2escm",(void*)f_4778},
{"f_4926:srfi_2d69_2escm",(void*)f_4926},
{"f_4476:srfi_2d69_2escm",(void*)f_4476},
{"f_1958:srfi_2d69_2escm",(void*)f_1958},
{"f_4788:srfi_2d69_2escm",(void*)f_4788},
{"f_4933:srfi_2d69_2escm",(void*)f_4933},
{"f_4422:srfi_2d69_2escm",(void*)f_4422},
{"f_4755:srfi_2d69_2escm",(void*)f_4755},
{"f_6244:srfi_2d69_2escm",(void*)f_6244},
{"f_2742:srfi_2d69_2escm",(void*)f_2742},
{"f_4918:srfi_2d69_2escm",(void*)f_4918},
{"f_3563:srfi_2d69_2escm",(void*)f_3563},
{"f_2732:srfi_2d69_2escm",(void*)f_2732},
{"f_2737:srfi_2d69_2escm",(void*)f_2737},
{"f_2739:srfi_2d69_2escm",(void*)f_2739},
{"f_4466:srfi_2d69_2escm",(void*)f_4466},
{"f_6237:srfi_2d69_2escm",(void*)f_6237},
{"toplevel:srfi_2d69_2escm",(void*)C_srfi_2d69_toplevel},
{"f_3162:srfi_2d69_2escm",(void*)f_3162},
{"f_4882:srfi_2d69_2escm",(void*)f_4882},
{"f_6230:srfi_2d69_2escm",(void*)f_6230},
{"f_4452:srfi_2d69_2escm",(void*)f_4452},
{"f_3591:srfi_2d69_2escm",(void*)f_3591},
{"f_3595:srfi_2d69_2escm",(void*)f_3595},
{"f_3174:srfi_2d69_2escm",(void*)f_3174},
{"f_4893:srfi_2d69_2escm",(void*)f_4893},
{"f_4899:srfi_2d69_2escm",(void*)f_4899},
{"f_3598:srfi_2d69_2escm",(void*)f_3598},
{"f_5560:srfi_2d69_2escm",(void*)f_5560},
{"f_3130:srfi_2d69_2escm",(void*)f_3130},
{"f_5205:srfi_2d69_2escm",(void*)f_5205},
{"f_3150:srfi_2d69_2escm",(void*)f_3150},
{"f_1926:srfi_2d69_2escm",(void*)f_1926},
{"f_3982:srfi_2d69_2escm",(void*)f_3982},
{"f_1920:srfi_2d69_2escm",(void*)f_1920},
{"f_3999:srfi_2d69_2escm",(void*)f_3999},
{"f_2703:srfi_2d69_2escm",(void*)f_2703},
{"f_4336:srfi_2d69_2escm",(void*)f_4336},
{"f_5174:srfi_2d69_2escm",(void*)f_5174},
{"f_4322:srfi_2d69_2escm",(void*)f_4322},
{"f_5779:srfi_2d69_2escm",(void*)f_5779},
{"f_3581:srfi_2d69_2escm",(void*)f_3581},
{"f_3586:srfi_2d69_2escm",(void*)f_3586},
{"f_5763:srfi_2d69_2escm",(void*)f_5763},
{"f_3730:srfi_2d69_2escm",(void*)f_3730},
{"f_3734:srfi_2d69_2escm",(void*)f_3734},
{"f_5190:srfi_2d69_2escm",(void*)f_5190},
{"f_4850:srfi_2d69_2escm",(void*)f_4850},
{"f_4529:srfi_2d69_2escm",(void*)f_4529},
{"f_5573:srfi_2d69_2escm",(void*)f_5573},
{"f_3721:srfi_2d69_2escm",(void*)f_3721},
{"f_3727:srfi_2d69_2escm",(void*)f_3727},
{"f_3724:srfi_2d69_2escm",(void*)f_3724},
{"f_4539:srfi_2d69_2escm",(void*)f_4539},
{"f_2132:srfi_2d69_2escm",(void*)f_2132},
{"f_5586:srfi_2d69_2escm",(void*)f_5586},
{"f_3718:srfi_2d69_2escm",(void*)f_3718},
{"f_5138:srfi_2d69_2escm",(void*)f_5138},
{"f_2125:srfi_2d69_2escm",(void*)f_2125},
{"f_5593:srfi_2d69_2escm",(void*)f_5593},
{"f_4965:srfi_2d69_2escm",(void*)f_4965},
{"f_4358:srfi_2d69_2escm",(void*)f_4358},
{"f_4355:srfi_2d69_2escm",(void*)f_4355},
{"f_5154:srfi_2d69_2escm",(void*)f_5154},
{"f_5878:srfi_2d69_2escm",(void*)f_5878},
{"f_4349:srfi_2d69_2escm",(void*)f_4349},
{"f_5537:srfi_2d69_2escm",(void*)f_5537},
{"f_4345:srfi_2d69_2escm",(void*)f_4345},
{"f_5547:srfi_2d69_2escm",(void*)f_5547},
{"f_2655:srfi_2d69_2escm",(void*)f_2655},
{"f_2167:srfi_2d69_2escm",(void*)f_2167},
{"f_2759:srfi_2d69_2escm",(void*)f_2759},
{"f_4301:srfi_2d69_2escm",(void*)f_4301},
{"f_6104:srfi_2d69_2escm",(void*)f_6104},
{"f_5951:srfi_2d69_2escm",(void*)f_5951},
{"f_4506:srfi_2d69_2escm",(void*)f_4506},
{"f_6116:srfi_2d69_2escm",(void*)f_6116},
{"f_3283:srfi_2d69_2escm",(void*)f_3283},
{"f_5258:srfi_2d69_2escm",(void*)f_5258},
{"f_2793:srfi_2d69_2escm",(void*)f_2793},
{"f_5938:srfi_2d69_2escm",(void*)f_5938},
{"f_2151:srfi_2d69_2escm",(void*)f_2151},
{"f_5928:srfi_2d69_2escm",(void*)f_5928},
{"f_5919:srfi_2d69_2escm",(void*)f_5919},
{"f_5245:srfi_2d69_2escm",(void*)f_5245},
{"f_3249:srfi_2d69_2escm",(void*)f_3249},
{"f_5298:srfi_2d69_2escm",(void*)f_5298},
{"f_4397:srfi_2d69_2escm",(void*)f_4397},
{"f_6173:srfi_2d69_2escm",(void*)f_6173},
{"f_4386:srfi_2d69_2escm",(void*)f_4386},
{"f_3222:srfi_2d69_2escm",(void*)f_3222},
{"f_5282:srfi_2d69_2escm",(void*)f_5282},
{"f_6192:srfi_2d69_2escm",(void*)f_6192},
{"f_6131:srfi_2d69_2escm",(void*)f_6131},
{"f_4210:srfi_2d69_2escm",(void*)f_4210},
{"f_3390:srfi_2d69_2escm",(void*)f_3390},
{"f_3947:srfi_2d69_2escm",(void*)f_3947},
{"f_5318:srfi_2d69_2escm",(void*)f_5318},
{"f_4239:srfi_2d69_2escm",(void*)f_4239},
{"f_3953:srfi_2d69_2escm",(void*)f_3953},
{"f_6007:srfi_2d69_2escm",(void*)f_6007},
{"f_6024:srfi_2d69_2escm",(void*)f_6024},
{"f_2815:srfi_2d69_2escm",(void*)f_2815},
{"f_6017:srfi_2d69_2escm",(void*)f_6017},
{"f_3872:srfi_2d69_2escm",(void*)f_3872},
{"f_4610:srfi_2d69_2escm",(void*)f_4610},
{"f_3533:srfi_2d69_2escm",(void*)f_3533},
{"f_3539:srfi_2d69_2escm",(void*)f_3539},
{"f_4566:srfi_2d69_2escm",(void*)f_4566},
{"f_3875:srfi_2d69_2escm",(void*)f_3875},
{"f_3852:srfi_2d69_2escm",(void*)f_3852},
{"f_5605:srfi_2d69_2escm",(void*)f_5605},
{"f_4639:srfi_2d69_2escm",(void*)f_4639},
{"f_4569:srfi_2d69_2escm",(void*)f_4569},
{"f_4295:srfi_2d69_2escm",(void*)f_4295},
{"f_4601:srfi_2d69_2escm",(void*)f_4601},
{"f_3979:srfi_2d69_2escm",(void*)f_3979},
{"f_3642:srfi_2d69_2escm",(void*)f_3642},
{"f_3640:srfi_2d69_2escm",(void*)f_3640},
{"f_3323:srfi_2d69_2escm",(void*)f_3323},
{"f_3326:srfi_2d69_2escm",(void*)f_3326},
{"f_4557:srfi_2d69_2escm",(void*)f_4557},
{"f_6073:srfi_2d69_2escm",(void*)f_6073},
{"f_5619:srfi_2d69_2escm",(void*)f_5619},
{"f_4223:srfi_2d69_2escm",(void*)f_4223},
{"f_4220:srfi_2d69_2escm",(void*)f_4220},
{"f_6082:srfi_2d69_2escm",(void*)f_6082},
{"f_5694:srfi_2d69_2escm",(void*)f_5694},
{"f_6078:srfi_2d69_2escm",(void*)f_6078},
{"f_6076:srfi_2d69_2escm",(void*)f_6076},
{"f_6094:srfi_2d69_2escm",(void*)f_6094},
{"f_6085:srfi_2d69_2escm",(void*)f_6085},
{"f_5636:srfi_2d69_2escm",(void*)f_5636},
{"f_6036:srfi_2d69_2escm",(void*)f_6036},
{"f_6029:srfi_2d69_2escm",(void*)f_6029},
{"f_3629:srfi_2d69_2escm",(void*)f_3629},
{"f_5652:srfi_2d69_2escm",(void*)f_5652},
{"f_6041:srfi_2d69_2escm",(void*)f_6041},
{"f_4117:srfi_2d69_2escm",(void*)f_4117},
{"f_5413:srfi_2d69_2escm",(void*)f_5413},
{"f_4002:srfi_2d69_2escm",(void*)f_4002},
{"f_3615:srfi_2d69_2escm",(void*)f_3615},
{"f_3619:srfi_2d69_2escm",(void*)f_3619},
{"f_4009:srfi_2d69_2escm",(void*)f_4009},
{"f_6053:srfi_2d69_2escm",(void*)f_6053},
{"f_5420:srfi_2d69_2escm",(void*)f_5420},
{"f_6048:srfi_2d69_2escm",(void*)f_6048},
{"f_2011:srfi_2d69_2escm",(void*)f_2011},
{"f_6060:srfi_2d69_2escm",(void*)f_6060},
{"f_6065:srfi_2d69_2escm",(void*)f_6065},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  ##sys#for-each		1
S|  for-each		1
o|eliminated procedure checks: 243 
o|specializations:
o|  1 (##sys#check-list (or pair list) *)
o|  4 (fp< float float)
o|  8 (eqv? * (not float))
o|  1 (car pair)
o|  2 (cdr pair)
o|  2 (memq * list)
o|  2 (positive? fixnum)
(o e)|safe calls: 632 
o|Removed `not' forms: 6 
o|contracted procedure: "(srfi-69.scm:159) g106107" 
o|contracted procedure: "(srfi-69.scm:120) g111112" 
o|inlining procedure: k1770 
o|inlining procedure: k1770 
o|contracted procedure: "(srfi-69.scm:159) g114115" 
o|inlining procedure: k1788 
o|inlining procedure: k1788 
o|contracted procedure: "(srfi-69.scm:152) g122123" 
o|inlining procedure: k1799 
o|contracted procedure: "(srfi-69.scm:147) g163164" 
o|contracted procedure: "(srfi-69.scm:147) g159160" 
o|contracted procedure: "(srfi-69.scm:147) g155156" 
o|contracted procedure: "(srfi-69.scm:147) g151152" 
o|contracted procedure: "(srfi-69.scm:147) g147148" 
o|contracted procedure: "(srfi-69.scm:147) g143144" 
o|contracted procedure: "(srfi-69.scm:147) g139140" 
o|contracted procedure: "(srfi-69.scm:147) g135136" 
o|inlining procedure: k1799 
o|contracted procedure: "(srfi-69.scm:148) g167168" 
o|contracted procedure: "(srfi-69.scm:173) g190191" 
o|contracted procedure: "(srfi-69.scm:120) g195196" 
o|inlining procedure: k1988 
o|inlining procedure: k1988 
o|contracted procedure: "(srfi-69.scm:173) g198199" 
o|contracted procedure: "(srfi-69.scm:188) g221222" 
o|contracted procedure: "(srfi-69.scm:120) g226227" 
o|inlining procedure: k2070 
o|inlining procedure: k2070 
o|contracted procedure: "(srfi-69.scm:188) g229230" 
o|contracted procedure: "(srfi-69.scm:182) g233234" 
o|inlining procedure: k2127 
o|inlining procedure: k2127 
o|contracted procedure: k2140 
o|inlining procedure: k2137 
o|inlining procedure: k2137 
o|contracted procedure: "(srfi-69.scm:209) g261262" 
o|contracted procedure: "(srfi-69.scm:120) g266267" 
o|inlining procedure: k2184 
o|inlining procedure: k2184 
o|contracted procedure: "(srfi-69.scm:209) g269270" 
o|contracted procedure: "(srfi-69.scm:203) g273274" 
o|contracted procedure: "(srfi-69.scm:235) g319320" 
o|contracted procedure: "(srfi-69.scm:120) g324325" 
o|inlining procedure: k2373 
o|inlining procedure: k2373 
o|contracted procedure: "(srfi-69.scm:235) *eq?-hash" 
o|inlining procedure: k2241 
o|inlining procedure: k2241 
o|inlining procedure: k2263 
o|inlining procedure: k2263 
o|inlining procedure: k2281 
o|inlining procedure: k2281 
o|inlining procedure: k2299 
o|contracted procedure: "(srfi-69.scm:226) g286287" 
o|contracted procedure: "(srfi-69.scm:182) g290291" 
o|inlining procedure: k2299 
o|contracted procedure: "(srfi-69.scm:230) g297298" 
o|contracted procedure: "(srfi-69.scm:229) g294295" 
o|contracted procedure: "(srfi-69.scm:262) g417418" 
o|contracted procedure: "(srfi-69.scm:120) g422423" 
o|inlining procedure: k2685 
o|inlining procedure: k2685 
o|contracted procedure: "(srfi-69.scm:262) *eqv?-hash" 
o|inlining procedure: k2420 
o|inlining procedure: k2420 
o|inlining procedure: k2442 
o|inlining procedure: k2442 
o|inlining procedure: k2460 
o|inlining procedure: k2460 
o|inlining procedure: k2478 
o|contracted procedure: "(srfi-69.scm:252) g336337" 
o|contracted procedure: "(srfi-69.scm:182) g340341" 
o|inlining procedure: k2478 
o|contracted procedure: "(srfi-69.scm:255) g344345" 
o|inlining procedure: k2506 
o|contracted procedure: "(srfi-69.scm:147) g385386" 
o|contracted procedure: "(srfi-69.scm:147) g381382" 
o|contracted procedure: "(srfi-69.scm:147) g377378" 
o|contracted procedure: "(srfi-69.scm:147) g373374" 
o|contracted procedure: "(srfi-69.scm:147) g369370" 
o|contracted procedure: "(srfi-69.scm:147) g365366" 
o|contracted procedure: "(srfi-69.scm:147) g361362" 
o|contracted procedure: "(srfi-69.scm:147) g357358" 
o|inlining procedure: k2506 
o|contracted procedure: "(srfi-69.scm:148) g389390" 
o|inlining procedure: k2631 
o|inlining procedure: k2631 
o|contracted procedure: "(srfi-69.scm:257) g395396" 
o|contracted procedure: "(srfi-69.scm:256) g392393" 
o|inlining procedure: k2761 
o|inlining procedure: k2761 
o|inlining procedure: k2817 
o|inlining procedure: k2817 
o|inlining procedure: k2835 
o|inlining procedure: k2835 
o|inlining procedure: k2857 
o|inlining procedure: k2857 
o|inlining procedure: k2875 
o|inlining procedure: k2875 
o|contracted procedure: "(srfi-69.scm:331) g459460" 
o|contracted procedure: "(srfi-69.scm:182) g463464" 
o|inlining procedure: k2904 
o|contracted procedure: "(srfi-69.scm:334) g467468" 
o|inlining procedure: k2912 
o|contracted procedure: "(srfi-69.scm:147) g508509" 
o|contracted procedure: "(srfi-69.scm:147) g504505" 
o|contracted procedure: "(srfi-69.scm:147) g500501" 
o|contracted procedure: "(srfi-69.scm:147) g496497" 
o|contracted procedure: "(srfi-69.scm:147) g492493" 
o|contracted procedure: "(srfi-69.scm:147) g488489" 
o|contracted procedure: "(srfi-69.scm:147) g484485" 
o|contracted procedure: "(srfi-69.scm:147) g480481" 
o|inlining procedure: k2912 
o|contracted procedure: "(srfi-69.scm:148) g512513" 
o|inlining procedure: k2904 
o|inlining procedure: k3052 
o|contracted procedure: "(srfi-69.scm:336) g521522" 
o|inlining procedure: k3052 
o|inlining procedure: k3107 
o|contracted procedure: "(srfi-69.scm:338) g532533" 
o|inlining procedure: k3125 
o|inlining procedure: k3125 
o|inlining procedure: k3107 
o|contracted procedure: "(srfi-69.scm:339) g536537" 
o|contracted procedure: "(srfi-69.scm:338) g529530" 
o|contracted procedure: "(srfi-69.scm:336) g518519" 
o|contracted procedure: "(srfi-69.scm:335) g515516" 
o|contracted procedure: "(srfi-69.scm:348) g567568" 
o|contracted procedure: "(srfi-69.scm:120) g572573" 
o|inlining procedure: k3204 
o|inlining procedure: k3204 
o|contracted procedure: "(srfi-69.scm:364) g606607" 
o|contracted procedure: "(srfi-69.scm:120) g611612" 
o|inlining procedure: k3297 
o|inlining procedure: k3297 
o|contracted procedure: "(srfi-69.scm:364) g614615" 
o|contracted procedure: "(srfi-69.scm:376) g649650" 
o|contracted procedure: "(srfi-69.scm:120) g654655" 
o|inlining procedure: k3438 
o|inlining procedure: k3438 
o|contracted procedure: "(srfi-69.scm:376) g657658" 
o|inlining procedure: k3547 
o|inlining procedure: k3547 
o|inlining procedure: k3565 
o|inlining procedure: k3565 
o|inlining procedure: k3599 
o|inlining procedure: k3599 
o|merged explicitly consed rest parameter: tmp717726 
o|inlining procedure: k3644 
o|inlining procedure: k3644 
o|inlining procedure: k3662 
o|inlining procedure: k3662 
o|inlining procedure: k3680 
o|inlining procedure: k3680 
o|inlining procedure: k3695 
o|inlining procedure: k3695 
o|consed rest parameter at call site: "(srfi-69.scm:585) *make-hash-table" 9 
o|inlining procedure: k3744 
o|inlining procedure: k3744 
o|inlining procedure: k3761 
o|inlining procedure: k3761 
o|inlining procedure: k3800 
o|inlining procedure: k3800 
o|inlining procedure: k3832 
o|inlining procedure: k3832 
o|inlining procedure: k3850 
o|inlining procedure: k3850 
o|substituted constant variable: a3860 
o|substituted constant variable: a3863 
o|inlining procedure: k3864 
o|substituted constant variable: a3883 
o|substituted constant variable: a3886 
o|inlining procedure: k3864 
o|inlining procedure: k3894 
o|inlining procedure: k3894 
o|inlining procedure: k3897 
o|inlining procedure: k3897 
o|substituted constant variable: a3911 
o|substituted constant variable: a3913 
o|substituted constant variable: a3915 
o|substituted constant variable: a3917 
o|substituted constant variable: a3919 
o|substituted constant variable: a3921 
o|substituted constant variable: a3923 
o|substituted constant variable: a3925 
o|inlining procedure: k3942 
o|inlining procedure: k3942 
o|inlining procedure: k3974 
o|inlining procedure: k3974 
o|inlining procedure: k3994 
o|inlining procedure: k3994 
o|inlining procedure: k4083 
o|inlining procedure: k4083 
o|inlining procedure: k4098 
o|inlining procedure: k4098 
o|contracted procedure: "(srfi-69.scm:654) hash-table-rehash!" 
o|inlining procedure: k4119 
o|inlining procedure: k4119 
o|inlining procedure: k4142 
o|inlining procedure: k4142 
o|inlining procedure: k4241 
o|consed rest parameter at call site: "(srfi-69.scm:680) *make-hash-table" 9 
o|inlining procedure: k4241 
o|inlining procedure: k4303 
o|inlining procedure: k4303 
o|inlining procedure: k4456 
o|inlining procedure: k4468 
o|inlining procedure: k4468 
o|inlining procedure: k4456 
o|inlining procedure: k4531 
o|inlining procedure: k4531 
o|contracted procedure: "(srfi-69.scm:724) g926927" 
o|inlining procedure: k4398 
o|inlining procedure: k4398 
o|inlining procedure: k4410 
o|inlining procedure: k4410 
o|contracted procedure: "(srfi-69.scm:665) g939940" 
o|inlining procedure: k4389 
o|inlining procedure: k4389 
o|contracted procedure: "(srfi-69.scm:664) g936937" 
o|inlining procedure: k4378 
o|inlining procedure: k4378 
o|inlining procedure: k4598 
o|inlining procedure: k4598 
o|inlining procedure: k4709 
o|inlining procedure: k4721 
o|inlining procedure: k4721 
o|inlining procedure: k4709 
o|inlining procedure: k4780 
o|inlining procedure: k4780 
o|contracted procedure: "(srfi-69.scm:763) g979980" 
o|inlining procedure: k4651 
o|inlining procedure: k4651 
o|inlining procedure: k4663 
o|inlining procedure: k4663 
o|contracted procedure: "(srfi-69.scm:665) g992993" 
o|inlining procedure: k4642 
o|inlining procedure: k4642 
o|contracted procedure: "(srfi-69.scm:664) g989990" 
o|inlining procedure: k4631 
o|inlining procedure: k4631 
o|inlining procedure: k4952 
o|inlining procedure: k4967 
o|inlining procedure: k4967 
o|inlining procedure: k4952 
o|inlining procedure: k5016 
o|inlining procedure: k5016 
o|contracted procedure: "(srfi-69.scm:808) g10351036" 
o|inlining procedure: k4894 
o|inlining procedure: k4894 
o|inlining procedure: k4906 
o|inlining procedure: k4906 
o|contracted procedure: "(srfi-69.scm:665) g10481049" 
o|inlining procedure: k4885 
o|inlining procedure: k4885 
o|contracted procedure: "(srfi-69.scm:664) g10451046" 
o|inlining procedure: k4874 
o|inlining procedure: k4874 
o|inlining procedure: k5085 
o|inlining procedure: k5101 
o|inlining procedure: k5101 
o|inlining procedure: k5085 
o|inlining procedure: k5140 
o|inlining procedure: k5140 
o|inlining procedure: k5191 
o|contracted procedure: k5210 
o|inlining procedure: k5207 
o|inlining procedure: k5207 
o|inlining procedure: k5191 
o|contracted procedure: k5250 
o|inlining procedure: k5247 
o|inlining procedure: k5247 
o|inlining procedure: k5308 
o|contracted procedure: k5323 
o|inlining procedure: k5320 
o|inlining procedure: k5320 
o|inlining procedure: k5308 
o|contracted procedure: k5370 
o|inlining procedure: k5367 
o|inlining procedure: k5367 
o|inlining procedure: k5436 
o|inlining procedure: k5436 
o|contracted procedure: k5465 
o|inlining procedure: k5462 
o|inlining procedure: k5462 
o|inlining procedure: k5539 
o|inlining procedure: k5539 
o|inlining procedure: k5562 
o|inlining procedure: k5562 
o|inlining procedure: k5638 
o|inlining procedure: k5638 
o|inlining procedure: k5654 
o|inlining procedure: k5654 
o|inlining procedure: k5727 
o|inlining procedure: k5727 
o|inlining procedure: k5765 
o|inlining procedure: k5765 
o|inlining procedure: k5781 
o|inlining procedure: k5781 
o|inlining procedure: k5830 
o|inlining procedure: k5830 
o|inlining procedure: k5846 
o|inlining procedure: k5846 
o|inlining procedure: k5892 
o|inlining procedure: k5892 
o|inlining procedure: k5930 
o|inlining procedure: k5930 
o|inlining procedure: k5965 
o|inlining procedure: k5965 
o|inlining procedure: k5981 
o|inlining procedure: k5981 
o|inlining procedure: k6117 
o|inlining procedure: k6133 
o|inlining procedure: k6133 
o|inlining procedure: k6117 
o|inlining procedure: k6175 
o|inlining procedure: k6175 
o|inlining procedure: k6225 
o|inlining procedure: k6225 
o|propagated global variable: r62266481 *recursive-hash-max-length* 
o|inlining procedure: k6239 
o|inlining procedure: k6239 
o|propagated global variable: r62406483 *recursive-hash-max-depth* 
o|replaced variables: 690 
o|removed binding forms: 330 
o|substituted constant variable: i166 
o|substituted constant variable: i162 
o|substituted constant variable: i158 
o|substituted constant variable: i154 
o|substituted constant variable: i150 
o|substituted constant variable: i146 
o|substituted constant variable: i142 
o|substituted constant variable: i138 
o|substituted constant variable: r21386262 
o|substituted constant variable: r21386262 
o|substituted constant variable: i388 
o|substituted constant variable: i384 
o|substituted constant variable: i380 
o|substituted constant variable: i376 
o|substituted constant variable: i372 
o|substituted constant variable: i368 
o|substituted constant variable: i364 
o|substituted constant variable: i360 
o|substituted constant variable: i511 
o|substituted constant variable: i507 
o|substituted constant variable: i503 
o|substituted constant variable: i499 
o|substituted constant variable: i495 
o|substituted constant variable: i491 
o|substituted constant variable: i487 
o|substituted constant variable: i483 
o|substituted constant variable: r31266309 
o|substituted constant variable: r31266309 
o|substituted constant variable: r31266311 
o|substituted constant variable: r31266311 
o|removed unused formal parameters: (weak-keys723 weak-values724) 
o|removed unused parameter to known procedure: weak-keys723 "(srfi-69.scm:585) *make-hash-table" 
o|removed unused parameter to known procedure: weak-values724 "(srfi-69.scm:585) *make-hash-table" 
o|inlining procedure: k3873 
o|substituted constant variable: r38956350 
o|substituted constant variable: r38956352 
o|inlining procedure: k3904 
o|inlining procedure: k3904 
o|substituted constant variable: r40846362 
o|substituted constant variable: r40846363 
o|substituted constant variable: r40996365 
o|removed unused parameter to known procedure: weak-keys723 "(srfi-69.scm:680) *make-hash-table" 
o|removed unused parameter to known procedure: weak-values724 "(srfi-69.scm:680) *make-hash-table" 
o|substituted constant variable: r43046372 
o|substituted constant variable: r44116383 
o|substituted constant variable: r46646399 
o|substituted constant variable: r49076421 
o|substituted constant variable: r52086433 
o|substituted constant variable: r52486436 
o|substituted constant variable: r53216439 
o|substituted constant variable: r53686442 
o|substituted constant variable: r54636446 
o|replaced variables: 110 
o|removed binding forms: 711 
o|inlining procedure: k1909 
o|inlining procedure: k2616 
o|inlining procedure: k3022 
o|inlining procedure: k3553 
o|inlining procedure: k3735 
o|inlining procedure: k3735 
o|inlining procedure: k3735 
o|inlining procedure: k3785 
o|inlining procedure: k3785 
o|inlining procedure: k3785 
o|inlining procedure: k3785 
o|inlining procedure: k3785 
o|inlining procedure: k3785 
o|inlining procedure: k3785 
o|inlining procedure: k3785 
o|removed side-effect free assignment to unused variable: weak-keys756 
o|inlining procedure: k3785 
o|removed side-effect free assignment to unused variable: weak-keys756 
o|inlining procedure: k3785 
o|removed side-effect free assignment to unused variable: weak-values757 
o|inlining procedure: k3785 
o|removed side-effect free assignment to unused variable: weak-values757 
o|inlining procedure: k3785 
o|replaced variables: 34 
o|removed binding forms: 158 
o|contracted procedure: k1815 
o|contracted procedure: k1829 
o|contracted procedure: k1843 
o|contracted procedure: k1857 
o|contracted procedure: k1871 
o|contracted procedure: k1885 
o|contracted procedure: k1899 
o|contracted procedure: k2522 
o|contracted procedure: k2536 
o|contracted procedure: k2550 
o|contracted procedure: k2564 
o|contracted procedure: k2578 
o|contracted procedure: k2592 
o|contracted procedure: k2606 
o|contracted procedure: k2928 
o|contracted procedure: k2942 
o|contracted procedure: k2956 
o|contracted procedure: k2970 
o|contracted procedure: k2984 
o|contracted procedure: k2998 
o|contracted procedure: k3012 
o|contracted procedure: k3057 
o|contracted procedure: k3112 
o|contracted procedure: k3147 
o|contracted procedure: k3315 
o|contracted procedure: k3456 
o|removed call to pure procedure with unused result: "(srfi-69.scm:684) slot" 
o|removed call to pure procedure with unused result: "(srfi-69.scm:684) slot" 
o|simplifications: ((let . 3)) 
o|removed binding forms: 84 
o|Removed `not' forms: 3 
o|contracted procedure: k2328 
o|contracted procedure: k2640 
o|contracted procedure: k3046 
o|contracted procedure: k4271 
o|contracted procedure: k4275 
o|removed binding forms: 9 
o|replaced variables: 3 
o|removed binding forms: 2 
o|removed binding forms: 3 
o|simplifications: ((let . 3)) 
o|simplifications: ((if . 75) (##core#call . 698)) 
o|  call simplifications:
o|    ##sys#check-list	2
o|    apply
o|    ##sys#check-pair
o|    void
o|    *	6
o|    ##sys#immediate?	6
o|    fx<=	6
o|    ##sys#setislot	10
o|    cons	21
o|    ##sys#check-structure	30
o|    ##sys#structure?
o|    ##sys#make-structure
o|    ##sys#setslot	24
o|    list	2
o|    ##sys#check-string	2
o|    fx>=	12
o|    pair?	4
o|    ##sys#peek-fixnum	2
o|    ##sys#size	27
o|    fxmin	4
o|    fxmax
o|    fx=
o|    fx-	4
o|    char?	3
o|    eq?	40
o|    eof-object?	3
o|    symbol?	3
o|    char->integer	3
o|    ##sys#check-symbol
o|    ##sys#slot	182
o|    car	30
o|    null?	78
o|    cdr	25
o|    number?	3
o|    ##sys#check-exact	11
o|    fixnum?	6
o|    flonum?	3
o|    fxshl	24
o|    fx+	43
o|    fx*	4
o|    fxxor	25
o|    fx<	15
o|    fxneg	9
o|    fxand	9
o|    fxmod	9
o|contracted procedure: k1951 
o|contracted procedure: k1739 
o|contracted procedure: k1945 
o|contracted procedure: k1742 
o|contracted procedure: k1939 
o|contracted procedure: k1745 
o|contracted procedure: k1933 
o|contracted procedure: k1748 
o|contracted procedure: k1754 
o|contracted procedure: k1763 
o|contracted procedure: k1773 
o|contracted procedure: k1791 
o|contracted procedure: k1802 
o|contracted procedure: k1903 
o|contracted procedure: k1893 
o|contracted procedure: k1889 
o|contracted procedure: k1879 
o|contracted procedure: k1875 
o|contracted procedure: k1865 
o|contracted procedure: k1861 
o|contracted procedure: k1851 
o|contracted procedure: k1847 
o|contracted procedure: k1837 
o|contracted procedure: k1833 
o|contracted procedure: k1823 
o|contracted procedure: k1819 
o|contracted procedure: k1809 
o|contracted procedure: k1927 
o|contracted procedure: k2030 
o|contracted procedure: k1960 
o|contracted procedure: k2024 
o|contracted procedure: k1963 
o|contracted procedure: k2018 
o|contracted procedure: k1966 
o|contracted procedure: k2012 
o|contracted procedure: k1969 
o|contracted procedure: k1972 
o|contracted procedure: k1981 
o|contracted procedure: k1991 
o|contracted procedure: k2118 
o|contracted procedure: k2039 
o|contracted procedure: k2112 
o|contracted procedure: k2042 
o|contracted procedure: k2106 
o|contracted procedure: k2045 
o|contracted procedure: k2100 
o|contracted procedure: k2048 
o|contracted procedure: k2051 
o|contracted procedure: k2054 
o|contracted procedure: k2063 
o|contracted procedure: k2073 
o|contracted procedure: k2094 
o|contracted procedure: k2147 
o|contracted procedure: k2137 
o|contracted procedure: k2232 
o|contracted procedure: k2153 
o|contracted procedure: k2226 
o|contracted procedure: k2156 
o|contracted procedure: k2220 
o|contracted procedure: k2159 
o|contracted procedure: k2214 
o|contracted procedure: k2162 
o|contracted procedure: k2168 
o|contracted procedure: k2177 
o|contracted procedure: k2187 
o|contracted procedure: k2208 
o|contracted procedure: k2410 
o|contracted procedure: k2345 
o|contracted procedure: k2404 
o|contracted procedure: k2348 
o|contracted procedure: k2398 
o|contracted procedure: k2351 
o|contracted procedure: k2392 
o|contracted procedure: k2354 
o|contracted procedure: k2357 
o|contracted procedure: k2366 
o|contracted procedure: k2376 
o|contracted procedure: k2244 
o|contracted procedure: k2253 
o|contracted procedure: k2260 
o|contracted procedure: k2266 
o|contracted procedure: k2275 
o|contracted procedure: k2284 
o|contracted procedure: k2293 
o|contracted procedure: k2302 
o|contracted procedure: k2313 
o|contracted procedure: k2722 
o|contracted procedure: k2657 
o|contracted procedure: k2716 
o|contracted procedure: k2660 
o|contracted procedure: k2710 
o|contracted procedure: k2663 
o|contracted procedure: k2704 
o|contracted procedure: k2666 
o|contracted procedure: k2669 
o|contracted procedure: k2678 
o|contracted procedure: k2688 
o|contracted procedure: k2423 
o|contracted procedure: k2432 
o|contracted procedure: k2439 
o|contracted procedure: k2445 
o|contracted procedure: k2454 
o|contracted procedure: k2463 
o|contracted procedure: k2472 
o|contracted procedure: k2481 
o|contracted procedure: k2492 
o|contracted procedure: k2501 
o|contracted procedure: k2509 
o|contracted procedure: k2610 
o|contracted procedure: k2600 
o|contracted procedure: k2596 
o|contracted procedure: k2586 
o|contracted procedure: k2582 
o|contracted procedure: k2572 
o|contracted procedure: k2568 
o|contracted procedure: k2558 
o|contracted procedure: k2554 
o|contracted procedure: k2544 
o|contracted procedure: k2540 
o|contracted procedure: k2530 
o|contracted procedure: k2526 
o|contracted procedure: k2516 
o|contracted procedure: k2744 
o|contracted procedure: k2811 
o|contracted procedure: k2751 
o|contracted procedure: k2807 
o|contracted procedure: k2803 
o|contracted procedure: k2755 
o|contracted procedure: k2764 
o|contracted procedure: k2787 
o|contracted procedure: k2783 
o|contracted procedure: k2771 
o|contracted procedure: k2775 
o|contracted procedure: k2779 
o|contracted procedure: k2795 
o|contracted procedure: k2799 
o|contracted procedure: k2820 
o|contracted procedure: k2829 
o|contracted procedure: k2838 
o|contracted procedure: k2845 
o|contracted procedure: k2851 
o|contracted procedure: k2860 
o|contracted procedure: k2869 
o|contracted procedure: k2878 
o|contracted procedure: k2887 
o|contracted procedure: k2898 
o|contracted procedure: k2907 
o|contracted procedure: k2915 
o|contracted procedure: k3016 
o|contracted procedure: k3006 
o|contracted procedure: k3002 
o|contracted procedure: k2992 
o|contracted procedure: k2988 
o|contracted procedure: k2978 
o|contracted procedure: k2974 
o|contracted procedure: k2964 
o|contracted procedure: k2960 
o|contracted procedure: k2950 
o|contracted procedure: k2946 
o|contracted procedure: k2936 
o|contracted procedure: k2932 
o|contracted procedure: k2922 
o|contracted procedure: k3068 
o|contracted procedure: k3077 
o|contracted procedure: k3085 
o|contracted procedure: k3089 
o|contracted procedure: k3097 
o|contracted procedure: k3101 
o|contracted procedure: k3136 
o|contracted procedure: k3132 
o|contracted procedure: k3121 
o|contracted procedure: k3156 
o|contracted procedure: k3241 
o|contracted procedure: k3176 
o|contracted procedure: k3235 
o|contracted procedure: k3179 
o|contracted procedure: k3229 
o|contracted procedure: k3182 
o|contracted procedure: k3223 
o|contracted procedure: k3185 
o|contracted procedure: k3188 
o|contracted procedure: k3197 
o|contracted procedure: k3207 
o|contracted procedure: k3383 
o|contracted procedure: k3251 
o|contracted procedure: k3377 
o|contracted procedure: k3254 
o|contracted procedure: k3371 
o|contracted procedure: k3257 
o|contracted procedure: k3365 
o|contracted procedure: k3260 
o|contracted procedure: k3359 
o|contracted procedure: k3263 
o|contracted procedure: k3353 
o|contracted procedure: k3266 
o|contracted procedure: k3347 
o|contracted procedure: k3269 
o|contracted procedure: k3341 
o|contracted procedure: k3272 
o|contracted procedure: k3275 
o|contracted procedure: k3278 
o|contracted procedure: k3290 
o|contracted procedure: k3300 
o|contracted procedure: k3318 
o|contracted procedure: k3331 
o|contracted procedure: k3335 
o|contracted procedure: k3524 
o|contracted procedure: k3392 
o|contracted procedure: k3518 
o|contracted procedure: k3395 
o|contracted procedure: k3512 
o|contracted procedure: k3398 
o|contracted procedure: k3506 
o|contracted procedure: k3401 
o|contracted procedure: k3500 
o|contracted procedure: k3404 
o|contracted procedure: k3494 
o|contracted procedure: k3407 
o|contracted procedure: k3488 
o|contracted procedure: k3410 
o|contracted procedure: k3482 
o|contracted procedure: k3413 
o|contracted procedure: k3416 
o|contracted procedure: k3419 
o|contracted procedure: k3431 
o|contracted procedure: k3441 
o|contracted procedure: k3459 
o|contracted procedure: k3472 
o|contracted procedure: k3476 
o|contracted procedure: k3541 
o|contracted procedure: k3544 
o|contracted procedure: k3550 
o|contracted procedure: k3553 
o|contracted procedure: k3570 
o|contracted procedure: k3578 
o|contracted procedure: k3608 
o|contracted procedure: k3602 
o|contracted procedure: k3620 
o|contracted procedure: k3623 
o|contracted procedure: k3630 
o|contracted procedure: k3647 
o|contracted procedure: k3650 
o|contracted procedure: k3656 
o|contracted procedure: k3659 
o|contracted procedure: k3665 
o|contracted procedure: k3668 
o|contracted procedure: k3674 
o|contracted procedure: k3677 
o|contracted procedure: k3683 
o|contracted procedure: k3686 
o|contracted procedure: k3692 
o|contracted procedure: k3695 
o|contracted procedure: k3764 
o|contracted procedure: k3767 
o|contracted procedure: k3793 
o|contracted procedure: k3803 
o|contracted procedure: k3813 
o|contracted procedure: k3816 
o|contracted procedure: k3823 
o|contracted procedure: k3826 
o|contracted procedure: k3835 
o|contracted procedure: k3844 
o|contracted procedure: k3854 
o|contracted procedure: k3867 
o|contracted procedure: k3877 
o|contracted procedure: k3890 
o|contracted procedure: k3900 
o|contracted procedure: k3926 
o|contracted procedure: k3936 
o|contracted procedure: k3939 
o|contracted procedure: k3948 
o|contracted procedure: k3955 
o|contracted procedure: k3959 
o|contracted procedure: k3962 
o|contracted procedure: k3968 
o|contracted procedure: k3971 
o|contracted procedure: k3985 
o|contracted procedure: k3988 
o|contracted procedure: k3991 
o|contracted procedure: k4005 
o|contracted procedure: k4017 
o|contracted procedure: k4026 
o|contracted procedure: k4035 
o|contracted procedure: k4044 
o|contracted procedure: k4053 
o|contracted procedure: k4062 
o|contracted procedure: k4071 
o|contracted procedure: k4080 
o|contracted procedure: k4086 
o|contracted procedure: k4092 
o|contracted procedure: k4095 
o|contracted procedure: k4206 
o|contracted procedure: k4186 
o|contracted procedure: k4202 
o|contracted procedure: k4107 
o|contracted procedure: k4110 
o|contracted procedure: k4122 
o|contracted procedure: k4132 
o|contracted procedure: k4136 
o|contracted procedure: k4145 
o|contracted procedure: k4148 
o|contracted procedure: k4151 
o|contracted procedure: k4180 
o|contracted procedure: k4172 
o|contracted procedure: k4176 
o|contracted procedure: k4168 
o|contracted procedure: k4157 
o|contracted procedure: k4164 
o|contracted procedure: k4212 
o|contracted procedure: k4215 
o|contracted procedure: k4235 
o|contracted procedure: k4224 
o|contracted procedure: k4231 
o|contracted procedure: k4227 
o|contracted procedure: k4244 
o|contracted procedure: k4251 
o|contracted procedure: k4255 
o|contracted procedure: k4259 
o|contracted procedure: k4263 
o|contracted procedure: k4267 
o|contracted procedure: k4279 
o|contracted procedure: k4282 
o|contracted procedure: k4289 
o|contracted procedure: k4297 
o|contracted procedure: k4306 
o|contracted procedure: k4309 
o|contracted procedure: k4328 
o|contracted procedure: k4332 
o|contracted procedure: k4316 
o|contracted procedure: k4324 
o|contracted procedure: k4338 
o|contracted procedure: k4350 
o|contracted procedure: k4589 
o|contracted procedure: k4359 
o|contracted procedure: k4438 
o|contracted procedure: k4441 
o|contracted procedure: k4444 
o|contracted procedure: k4447 
o|contracted procedure: k4453 
o|contracted procedure: k4459 
o|contracted procedure: k4471 
o|contracted procedure: k4488 
o|contracted procedure: k4484 
o|contracted procedure: k4477 
o|contracted procedure: k4480 
o|contracted procedure: k4495 
o|contracted procedure: k4522 
o|contracted procedure: k4501 
o|contracted procedure: k4507 
o|contracted procedure: k4511 
o|contracted procedure: k4518 
o|contracted procedure: k4534 
o|contracted procedure: k4551 
o|contracted procedure: k4547 
o|contracted procedure: k4540 
o|contracted procedure: k4543 
o|contracted procedure: k4558 
o|contracted procedure: k4570 
o|contracted procedure: k4574 
o|contracted procedure: k4581 
o|contracted procedure: k4585 
o|contracted procedure: k4364 
o|contracted procedure: k4367 
o|contracted procedure: k4370 
o|contracted procedure: k4373 
o|contracted procedure: k4407 
o|contracted procedure: k4413 
o|contracted procedure: k4392 
o|contracted procedure: k4424 
o|contracted procedure: k4381 
o|contracted procedure: k4432 
o|contracted procedure: k4592 
o|contracted procedure: k4595 
o|contracted procedure: k4834 
o|contracted procedure: k4612 
o|contracted procedure: k4691 
o|contracted procedure: k4694 
o|contracted procedure: k4697 
o|contracted procedure: k4700 
o|contracted procedure: k4706 
o|contracted procedure: k4712 
o|contracted procedure: k4724 
o|contracted procedure: k4741 
o|contracted procedure: k4737 
o|contracted procedure: k4730 
o|contracted procedure: k4733 
o|contracted procedure: k4744 
o|contracted procedure: k4771 
o|contracted procedure: k4750 
o|contracted procedure: k4756 
o|contracted procedure: k4760 
o|contracted procedure: k4767 
o|contracted procedure: k4783 
o|contracted procedure: k4800 
o|contracted procedure: k4796 
o|contracted procedure: k4789 
o|contracted procedure: k4792 
o|contracted procedure: k4803 
o|contracted procedure: k4815 
o|contracted procedure: k4819 
o|contracted procedure: k4826 
o|contracted procedure: k4830 
o|contracted procedure: k4617 
o|contracted procedure: k4620 
o|contracted procedure: k4623 
o|contracted procedure: k4626 
o|contracted procedure: k4660 
o|contracted procedure: k4666 
o|contracted procedure: k4645 
o|contracted procedure: k4677 
o|contracted procedure: k4634 
o|contracted procedure: k4685 
o|contracted procedure: k4840 
o|contracted procedure: k4852 
o|contracted procedure: k5060 
o|contracted procedure: k4855 
o|contracted procedure: k4934 
o|contracted procedure: k4937 
o|contracted procedure: k4940 
o|contracted procedure: k4943 
o|contracted procedure: k4949 
o|contracted procedure: k4958 
o|contracted procedure: k4970 
o|contracted procedure: k4984 
o|contracted procedure: k4980 
o|contracted procedure: k4973 
o|contracted procedure: k4987 
o|contracted procedure: k5007 
o|contracted procedure: k4993 
o|contracted procedure: k5003 
o|contracted procedure: k5019 
o|contracted procedure: k5033 
o|contracted procedure: k5029 
o|contracted procedure: k5022 
o|contracted procedure: k5036 
o|contracted procedure: k5052 
o|contracted procedure: k5056 
o|contracted procedure: k4860 
o|contracted procedure: k4863 
o|contracted procedure: k4866 
o|contracted procedure: k4869 
o|contracted procedure: k4903 
o|contracted procedure: k4909 
o|contracted procedure: k4888 
o|contracted procedure: k4920 
o|contracted procedure: k4877 
o|contracted procedure: k4928 
o|contracted procedure: k5070 
o|contracted procedure: k5073 
o|contracted procedure: k5076 
o|contracted procedure: k5079 
o|contracted procedure: k5088 
o|contracted procedure: k5095 
o|contracted procedure: k5104 
o|contracted procedure: k5107 
o|contracted procedure: k5127 
o|contracted procedure: k5113 
o|contracted procedure: k5123 
o|contracted procedure: k5134 
o|contracted procedure: k5143 
o|contracted procedure: k5146 
o|contracted procedure: k5162 
o|contracted procedure: k5166 
o|contracted procedure: k5170 
o|contracted procedure: k5176 
o|contracted procedure: k5179 
o|contracted procedure: k5182 
o|contracted procedure: k5185 
o|contracted procedure: k5194 
o|contracted procedure: k5201 
o|contracted procedure: k5234 
o|contracted procedure: k5213 
o|contracted procedure: k5230 
o|contracted procedure: k5216 
o|contracted procedure: k5226 
o|contracted procedure: k5241 
o|contracted procedure: k5274 
o|contracted procedure: k5253 
o|contracted procedure: k5266 
o|contracted procedure: k5270 
o|contracted procedure: k5278 
o|contracted procedure: k5284 
o|contracted procedure: k5287 
o|contracted procedure: k5290 
o|contracted procedure: k5293 
o|contracted procedure: k5299 
o|contracted procedure: k5409 
o|contracted procedure: k5302 
o|contracted procedure: k5305 
o|contracted procedure: k5311 
o|contracted procedure: k5358 
o|contracted procedure: k5326 
o|contracted procedure: k5329 
o|contracted procedure: k5354 
o|contracted procedure: k5335 
o|contracted procedure: k5338 
o|contracted procedure: k5341 
o|contracted procedure: k5405 
o|contracted procedure: k5373 
o|contracted procedure: k5376 
o|contracted procedure: k5385 
o|contracted procedure: k5388 
o|contracted procedure: k5401 
o|contracted procedure: k5415 
o|contracted procedure: k5421 
o|contracted procedure: k5424 
o|contracted procedure: k5427 
o|contracted procedure: k5439 
o|contracted procedure: k5452 
o|contracted procedure: k5456 
o|contracted procedure: k5505 
o|contracted procedure: k5468 
o|contracted procedure: k5471 
o|contracted procedure: k5480 
o|contracted procedure: k5484 
o|contracted procedure: k5497 
o|contracted procedure: k5501 
o|contracted procedure: k5511 
o|contracted procedure: k5521 
o|contracted procedure: k5527 
o|contracted procedure: k5530 
o|contracted procedure: k5542 
o|contracted procedure: k5552 
o|contracted procedure: k5556 
o|contracted procedure: k5565 
o|contracted procedure: k5568 
o|contracted procedure: k5578 
o|contracted procedure: k5582 
o|contracted procedure: k5589 
o|contracted procedure: k5595 
o|contracted procedure: k5598 
o|contracted procedure: k5607 
o|contracted procedure: k5610 
o|contracted procedure: k5623 
o|contracted procedure: k5626 
o|contracted procedure: k5629 
o|contracted procedure: k5641 
o|contracted procedure: k5648 
o|contracted procedure: k5657 
o|contracted procedure: k5664 
o|contracted procedure: k5671 
o|contracted procedure: k5675 
o|contracted procedure: k5686 
o|contracted procedure: k5690 
o|contracted procedure: k5682 
o|contracted procedure: k5678 
o|contracted procedure: k5696 
o|contracted procedure: k5704 
o|contracted procedure: k5711 
o|contracted procedure: k5718 
o|contracted procedure: k5730 
o|contracted procedure: k5740 
o|contracted procedure: k5744 
o|contracted procedure: k5750 
o|contracted procedure: k5753 
o|contracted procedure: k5756 
o|contracted procedure: k5768 
o|contracted procedure: k5775 
o|contracted procedure: k5784 
o|contracted procedure: k5791 
o|contracted procedure: k5798 
o|contracted procedure: k5802 
o|contracted procedure: k5809 
o|contracted procedure: k5805 
o|contracted procedure: k5815 
o|contracted procedure: k5818 
o|contracted procedure: k5821 
o|contracted procedure: k5833 
o|contracted procedure: k5840 
o|contracted procedure: k5849 
o|contracted procedure: k5856 
o|contracted procedure: k5863 
o|contracted procedure: k5867 
o|contracted procedure: k5874 
o|contracted procedure: k5870 
o|contracted procedure: k5880 
o|contracted procedure: k5883 
o|contracted procedure: k5895 
o|contracted procedure: k5904 
o|contracted procedure: k5908 
o|contracted procedure: k5911 
o|contracted procedure: k5914 
o|contracted procedure: k5924 
o|contracted procedure: k5933 
o|contracted procedure: k5943 
o|contracted procedure: k5947 
o|contracted procedure: k5953 
o|contracted procedure: k5956 
o|contracted procedure: k5968 
o|contracted procedure: k5975 
o|contracted procedure: k5984 
o|contracted procedure: k5991 
o|contracted procedure: k5994 
o|contracted procedure: k6001 
o|contracted procedure: k6009 
o|contracted procedure: k6013 
o|contracted procedure: k6019 
o|contracted procedure: k6031 
o|contracted procedure: k6043 
o|contracted procedure: k6055 
o|contracted procedure: k6090 
o|contracted procedure: k6211 
o|contracted procedure: k6096 
o|contracted procedure: k6099 
o|contracted procedure: k6105 
o|contracted procedure: k6108 
o|contracted procedure: k6111 
o|contracted procedure: k6120 
o|contracted procedure: k6127 
o|contracted procedure: k6136 
o|contracted procedure: k6142 
o|contracted procedure: k6162 
o|contracted procedure: k6148 
o|contracted procedure: k6158 
o|contracted procedure: k6169 
o|contracted procedure: k6178 
o|contracted procedure: k6184 
o|contracted procedure: k6200 
o|contracted procedure: k6204 
o|contracted procedure: k6208 
o|contracted procedure: k6232 
o|contracted procedure: k6246 
o|simplifications: ((let . 82)) 
o|removed binding forms: 622 
o|replaced variables: 394 
o|inlining procedure: k1779 
o|inlining procedure: k1997 
o|inlining procedure: k2079 
o|inlining procedure: k2193 
o|inlining procedure: k2382 
o|inlining procedure: k2694 
o|inlining procedure: k3213 
o|inlining procedure: k3306 
o|inlining procedure: k3447 
o|removed binding forms: 173 
o|contracted procedure: k2097 
o|contracted procedure: k2211 
o|removed binding forms: 11 
o|replaced variables: 12 
o|removed binding forms: 11 
o|direct leaf routine/allocation: loop681 0 
o|direct leaf routine/allocation: hash-for-test758 0 
o|direct leaf routine/allocation: loop1110 0 
o|direct leaf routine/allocation: loop1127 0 
o|direct leaf routine/allocation: loop1155 0 
o|converted assignments to bindings: (loop681) 
o|contracted procedure: "(srfi-69.scm:578) k3741" 
o|converted assignments to bindings: (loop1110) 
o|converted assignments to bindings: (loop1127) 
o|converted assignments to bindings: (loop1155) 
o|simplifications: ((let . 4)) 
o|removed binding forms: 1 
o|customizable procedures: (k6242 k6228 loop1095 loop1091 *hash-table-for-each *hash-table-fold fold21332 loop1329 g13061313 for-each-loop13051316 doloop13001301 loop21288 loop1285 loop21274 loop1271 g12481255 for-each-loop12471260 loop21234 loop1231 *hash-table-merge! doloop12081209 doloop12051206 loop1183 doloop11801181 loop1164 loop1135 loop1114 k4880 k4891 k4897 loop1064 loop1059 *hash-table-update!/default k4637 k4648 k4654 loop1012 loop1003 k4347 k4384 k4395 k4401 loop959 loop950 *hash-table-copy copy-loop894 doloop891892 loop867 doloop864865 k3716 k3719 k3722 invarg-err794 loop791 hash-table-canonical-length *make-hash-table g543544 g539540 vector-hash439 g525526 recursive-hash440 loop447 *equal?-hash) 
o|calls to known targets: 171 
o|identified direct recursive calls: f_3539 2 
o|identified direct recursive calls: f_4301 1 
o|identified direct recursive calls: f_4466 1 
o|identified direct recursive calls: f_4719 1 
o|identified direct recursive calls: f_4965 1 
o|identified direct recursive calls: f_5099 1 
o|identified direct recursive calls: f_5205 1 
o|identified direct recursive calls: f_5318 1 
o|identified direct recursive calls: f_5652 1 
o|identified direct recursive calls: f_5779 1 
o|identified direct recursive calls: f_5844 1 
o|identified direct recursive calls: f_6131 1 
o|fast box initializations: 34 
o|fast global references: 33 
o|fast global assignments: 10 
o|dropping unused closure argument: f_5525 
o|dropping unused closure argument: f_2739 
o|dropping unused closure argument: f_5878 
o|dropping unused closure argument: f_5951 
o|dropping unused closure argument: f_4210 
o|dropping unused closure argument: f_3533 
o|dropping unused closure argument: f_3615 
*/
/* end of file */
