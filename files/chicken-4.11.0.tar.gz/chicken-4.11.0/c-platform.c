/* Generated from c-platform.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: c-platform.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file c-platform.c
   unit: platform
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[933];
static double C_possibly_force_alignment;


C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word *av) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word *av) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word *av) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word *av) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word *av) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word *av) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word *av) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word *av) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word *av) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word *av) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word *av) C_noret;
C_noret_decl(f_4489)
static void C_fcall f_4489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word *av) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word *av) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word *av) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word *av) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word *av) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word *av) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word *av) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word *av) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word *av) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word *av) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word *av) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word *av) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word *av) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word *av) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word *av) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word *av) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word *av) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word *av) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word *av) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word *av) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word *av) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word *av) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word *av) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word *av) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word *av) C_noret;
C_noret_decl(f_5044)
static void C_fcall f_5044(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word *av) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word *av) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word *av) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word *av) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word *av) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word *av) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word *av) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word *av) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word *av) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word *av) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word *av) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word *av) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word *av) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word *av) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word *av) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word *av) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word *av) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word *av) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word *av) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word *av) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word *av) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word *av) C_noret;
C_noret_decl(f_1783)
static void C_fcall f_1783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word *av) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word *av) C_noret;
C_noret_decl(f_1774)
static void C_fcall f_1774(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word *av) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word *av) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word *av) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word *av) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word *av) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word *av) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word *av) C_noret;
C_noret_decl(C_platform_toplevel)
C_externexport void C_ccall C_platform_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word *av) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word *av) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word *av) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word *av) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word *av) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word *av) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word *av) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word *av) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word *av) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word *av) C_noret;
C_noret_decl(f_2071)
static void C_fcall f_2071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word *av) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word *av) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word *av) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word *av) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word *av) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word *av) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word *av) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word *av) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word *av) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word *av) C_noret;
C_noret_decl(f_5181)
static void C_fcall f_5181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word *av) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word *av) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word *av) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word *av) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word *av) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word *av) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word *av) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word *av) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word *av) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word *av) C_noret;
C_noret_decl(f_4539)
static void C_fcall f_4539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word *av) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word *av) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word *av) C_noret;
C_noret_decl(f_4785)
static void C_fcall f_4785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word *av) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word *av) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word *av) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word *av) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word *av) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word *av) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word *av) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word *av) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word *av) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word *av) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word *av) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word *av) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word *av) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word *av) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word *av) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word *av) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word *av) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word *av) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word *av) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word *av) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word *av) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word *av) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word *av) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word *av) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word *av) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word *av) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word *av) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word *av) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word *av) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word *av) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word *av) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word *av) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word *av) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word *av) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word *av) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word *av) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word *av) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word *av) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word *av) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word *av) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word *av) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word *av) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word *av) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word *av) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word *av) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word *av) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word *av) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word *av) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word *av) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word *av) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word *av) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word *av) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word *av) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word *av) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word *av) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word *av) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word *av) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word *av) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word *av) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word *av) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word *av) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word *av) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word *av) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word *av) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word *av) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word *av) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word *av) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word *av) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word *av) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word *av) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word *av) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word *av) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word *av) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word *av) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word *av) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word *av) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word *av) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word *av) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word *av) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word *av) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word *av) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word *av) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word *av) C_noret;
C_noret_decl(f_5633)
static void C_fcall f_5633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word *av) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word *av) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word *av) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word *av) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word *av) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word *av) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word *av) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word *av) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word *av) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word *av) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word *av) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word *av) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word *av) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word *av) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word *av) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word *av) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word *av) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word *av) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word *av) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word *av) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word *av) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word *av) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word *av) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word *av) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word *av) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word *av) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word *av) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word *av) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word *av) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word *av) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word *av) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word *av) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word *av) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word *av) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word *av) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word *av) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word *av) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word *av) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word *av) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word *av) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word *av) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word *av) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word *av) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word *av) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word *av) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word *av) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word *av) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word *av) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word *av) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word *av) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word *av) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word *av) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word *av) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word *av) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word *av) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word *av) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word *av) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word *av) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word *av) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word *av) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word *av) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word *av) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word *av) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word *av) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word *av) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word *av) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word *av) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word *av) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word *av) C_noret;
C_noret_decl(f_4825)
static void C_fcall f_4825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_fcall f_4822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word *av) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word *av) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word *av) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word *av) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word *av) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word *av) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word *av) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word *av) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word *av) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word *av) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word *av) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word *av) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word *av) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word *av) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word *av) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word *av) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word *av) C_noret;
C_noret_decl(f_1673)
static void C_fcall f_1673(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word *av) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word *av) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word *av) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word *av) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word *av) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word *av) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word *av) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word *av) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word *av) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word *av) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word *av) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word *av) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word *av) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word *av) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word *av) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word *av) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word *av) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word *av) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word *av) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word *av) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word *av) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word *av) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word *av) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word *av) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word *av) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word *av) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word *av) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word *av) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word *av) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word *av) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word *av) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word *av) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word *av) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word *av) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word *av) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word *av) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word *av) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word *av) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word *av) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word *av) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word *av) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word *av) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word *av) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word *av) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word *av) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word *av) C_noret;
C_noret_decl(f_4791)
static void C_fcall f_4791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word *av) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word *av) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word *av) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word *av) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word *av) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word *av) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word *av) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word *av) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word *av) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word *av) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word *av) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word *av) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word *av) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word *av) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word *av) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word *av) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word *av) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word *av) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word *av) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word *av) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word *av) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word *av) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word *av) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word *av) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word *av) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word *av) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word *av) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word *av) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word *av) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word *av) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word *av) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word *av) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word *av) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word *av) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word *av) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word *av) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word *av) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word *av) C_noret;
C_noret_decl(f_2196)
static void C_fcall f_2196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word *av) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word *av) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word *av) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word *av) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word *av) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word *av) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word *av) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word *av) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word *av) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word *av) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word *av) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word *av) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word *av) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word *av) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word *av) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word *av) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word *av) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word *av) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word *av) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word *av) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word *av) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word *av) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word *av) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word *av) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word *av) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word *av) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word *av) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word *av) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word *av) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word *av) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word *av) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word *av) C_noret;
C_noret_decl(f_4320)
static void C_fcall f_4320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word *av) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word *av) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word *av) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word *av) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word *av) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word *av) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word *av) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word *av) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word *av) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word *av) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word *av) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word *av) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word *av) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word *av) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word *av) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word *av) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word *av) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word *av) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word *av) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word *av) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word *av) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word *av) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word *av) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word *av) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word *av) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word *av) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word *av) C_noret;
C_noret_decl(f_4696)
static C_word C_fcall f_4696(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word *av) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word *av) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word *av) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word *av) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word *av) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word *av) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word *av) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word *av) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word *av) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word *av) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word *av) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word *av) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word *av) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word *av) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word *av) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word *av) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word *av) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word *av) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word *av) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word *av) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word *av) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word *av) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word *av) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word *av) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word *av) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word *av) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word *av) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word *av) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word *av) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word *av) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word *av) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word *av) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word *av) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word *av) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word *av) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word *av) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word *av) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word *av) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word *av) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word *av) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word *av) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word *av) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word *av) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word *av) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word *av) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word *av) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word *av) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word *av) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word *av) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word *av) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word *av) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word *av) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word *av) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word *av) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word *av) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word *av) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word *av) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word *av) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word *av) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word *av) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word *av) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word *av) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word *av) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word *av) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word *av) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word *av) C_noret;
C_noret_decl(f_5537)
static void C_fcall f_5537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word *av) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word *av) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word *av) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word *av) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word *av) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word *av) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word *av) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word *av) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word *av) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word *av) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word *av) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word *av) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word *av) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word *av) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word *av) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word *av) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word *av) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word *av) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word *av) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word *av) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word *av) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word *av) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word *av) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word *av) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word *av) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word *av) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word *av) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word *av) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word *av) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word *av) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word *av) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word *av) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word *av) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word *av) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word *av) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word *av) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word *av) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word *av) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word *av) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word *av) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word *av) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word *av) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word *av) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word *av) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word *av) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word *av) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word *av) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word *av) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word *av) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word *av) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word *av) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word *av) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word *av) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word *av) C_noret;

C_noret_decl(trf_4489)
static void C_ccall trf_4489(C_word c,C_word *av) C_noret;
static void C_ccall trf_4489(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4489(t0,t1);}

C_noret_decl(trf_5044)
static void C_ccall trf_5044(C_word c,C_word *av) C_noret;
static void C_ccall trf_5044(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5044(t0,t1);}

C_noret_decl(trf_1786)
static void C_ccall trf_1786(C_word c,C_word *av) C_noret;
static void C_ccall trf_1786(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1786(t0,t1);}

C_noret_decl(trf_1783)
static void C_ccall trf_1783(C_word c,C_word *av) C_noret;
static void C_ccall trf_1783(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1783(t0,t1);}

C_noret_decl(trf_1774)
static void C_ccall trf_1774(C_word c,C_word *av) C_noret;
static void C_ccall trf_1774(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1774(t0,t1);}

C_noret_decl(trf_2071)
static void C_ccall trf_2071(C_word c,C_word *av) C_noret;
static void C_ccall trf_2071(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2071(t0,t1);}

C_noret_decl(trf_5181)
static void C_ccall trf_5181(C_word c,C_word *av) C_noret;
static void C_ccall trf_5181(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5181(t0,t1);}

C_noret_decl(trf_4539)
static void C_ccall trf_4539(C_word c,C_word *av) C_noret;
static void C_ccall trf_4539(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4539(t0,t1);}

C_noret_decl(trf_4785)
static void C_ccall trf_4785(C_word c,C_word *av) C_noret;
static void C_ccall trf_4785(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4785(t0,t1);}

C_noret_decl(trf_5633)
static void C_ccall trf_5633(C_word c,C_word *av) C_noret;
static void C_ccall trf_5633(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5633(t0,t1,t2);}

C_noret_decl(trf_4825)
static void C_ccall trf_4825(C_word c,C_word *av) C_noret;
static void C_ccall trf_4825(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4825(t0,t1);}

C_noret_decl(trf_4822)
static void C_ccall trf_4822(C_word c,C_word *av) C_noret;
static void C_ccall trf_4822(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4822(t0,t1);}

C_noret_decl(trf_1673)
static void C_ccall trf_1673(C_word c,C_word *av) C_noret;
static void C_ccall trf_1673(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1673(t0,t1,t2,t3);}

C_noret_decl(trf_4791)
static void C_ccall trf_4791(C_word c,C_word *av) C_noret;
static void C_ccall trf_4791(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4791(t0,t1);}

C_noret_decl(trf_2196)
static void C_ccall trf_2196(C_word c,C_word *av) C_noret;
static void C_ccall trf_2196(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2196(t0,t1,t2,t3);}

C_noret_decl(trf_4320)
static void C_ccall trf_4320(C_word c,C_word *av) C_noret;
static void C_ccall trf_4320(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4320(t0,t1);}

C_noret_decl(trf_5537)
static void C_ccall trf_5537(C_word c,C_word *av) C_noret;
static void C_ccall trf_5537(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5537(t0,t1);}

C_noret_decl(trf_2023)
static void C_ccall trf_2023(C_word c,C_word *av) C_noret;
static void C_ccall trf_2023(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2023(t0,t1,t2);}

/* k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in ... */
static void C_ccall f_3418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3418,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:846: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[353];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[354];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in ... */
static void C_ccall f_4065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_4065,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1158: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[92];
av2[3]=C_fix(23);
av2[4]=C_fix(1);
av2[5]=lf[93];
av2[6]=lf[94];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1996 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_1998,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in ... */
static void C_ccall f_3415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3415,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:845: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[355];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[356];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in ... */
static void C_ccall f_4068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_4068,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1159: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[90];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[91];
av2[6]=C_fix(0);
av2[7]=C_fix(0);
av2[8]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2282,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:481: rewrite-c..r */
f_2196(t2,lf[890],lf[891],lf[892]);}

/* k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in ... */
static void C_ccall f_4062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_4062,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1157: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[95];
av2[3]=C_fix(23);
av2[4]=C_fix(1);
av2[5]=lf[96];
av2[6]=lf[97];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in ... */
static void C_ccall f_3412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3412,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:844: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[353];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[357];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2285(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2285,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:482: rewrite-c..r */
f_2196(t2,lf[887],lf[888],lf[889]);}

/* k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2288,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:483: rewrite-c..r */
f_2196(t2,lf[850],lf[885],lf[886]);}

/* k5551 in k5535 in a5529 in k5450 in a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5553,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[36],lf[924],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4487 in a4458 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in ... */
static void C_fcall f_4489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,1))){
C_save_and_reclaim_args((void *)trf_4489,2,t0,t1);}
a=C_alloc(22);
if(C_truep(t1)){
t2=t1;
t3=C_a_i_list2(&a,2,((C_word*)t0)[2],t2);
t4=((C_word*)t0)[3];
t5=t4;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t2=C_eqp(*((C_word*)lf[33]+1),lf[32]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
t4=C_a_i_record4(&a,4,lf[35],lf[36],lf[257],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=C_a_i_list2(&a,2,lf[258],*((C_word*)lf[9]+1));
t4=((C_word*)t0)[5];
t5=C_a_i_record4(&a,4,lf[35],lf[38],t3,t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[3];
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t6);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}

/* k4589 in a4458 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in ... */
static void C_ccall f_4591(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4591,2,av);}
t2=((C_word*)t0)[2];
f_4539(t2,C_i_not(t1));}

/* k5060 in k5042 in a5004 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_5062,2,av);}
a=C_alloc(22);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[35],lf[36],lf[912],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in ... */
static void C_ccall f_3406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3406,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:842: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[360];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[361];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in ... */
static void C_ccall f_3409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3409,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:843: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[358];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[359];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in ... */
static void C_ccall f_3400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3400,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:840: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[364];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[365];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 in ... */
static void C_ccall f_2291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2291,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:484: rewrite-c..r */
f_2196(t2,lf[829],lf[883],lf[884]);}

/* k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in ... */
static void C_ccall f_3403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3403,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:841: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[362];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[363];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in ... */
static void C_ccall f_2294(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2294,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:485: rewrite-c..r */
f_2196(t2,lf[880],lf[881],lf[882]);}

/* k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in ... */
static void C_ccall f_2297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2297,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:486: rewrite-c..r */
f_2196(t2,lf[877],lf[878],lf[879]);}

/* k5112 in a5004 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_5114,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in ... */
static void C_ccall f_3517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3517,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:917: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[281];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[282];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in ... */
static void C_ccall f_3514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3514,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:916: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[283];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[284];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in ... */
static void C_ccall f_3511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3511,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:915: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[285];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[286];
av2[6]=lf[287];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in ... */
static void C_ccall f_3508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3508,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:914: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[288];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[289];
av2[6]=lf[290];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in ... */
static void C_ccall f_3505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_3505,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4616,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:896: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[294];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in ... */
static void C_ccall f_3502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3502,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:894: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[295];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[296];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2236 in a2213 in a2201 in rewrite-c..r in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_2238,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4428 in k4402 in a4373 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in ... */
static void C_ccall f_4430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_4430,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in ... */
static void C_ccall f_3535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3535,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:923: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[263];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[264];
av2[6]=lf[265];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in ... */
static void C_ccall f_3538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_3538,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4459,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:925: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[262];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in ... */
static void C_ccall f_3532(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3532,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:922: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[266];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[267];
av2[6]=lf[268];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_1957,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:400: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[793];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in ... */
static void C_ccall f_4028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_4028,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1079: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[117];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in ... */
static void C_ccall f_3457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3457,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:878: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[325];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[326];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in ... */
static void C_ccall f_3454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3454,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:876: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[327];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[328];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5042 in a5004 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_5044(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,2))){
C_save_and_reclaim_args((void *)trf_5044,2,t0,t1);}
a=C_alloc(16);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5062,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:354: qnode */
t5=*((C_word*)lf[39]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[35],lf[36],lf[913],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in ... */
static void C_ccall f_3451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3451,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:875: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[329];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[330];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_1963,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1965,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:457: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[900];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1965,6,av);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1975,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:435: last */
t7=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_1960,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4769,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:402: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[903];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in ... */
static void C_ccall f_3469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3469,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:882: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[317];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[318];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in ... */
static void C_ccall f_3466(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3466,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:881: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[319];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[320];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in ... */
static void C_ccall f_3463(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3463,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:880: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[321];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[322];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in ... */
static void C_ccall f_3460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3460,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:879: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[323];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[324];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1911 in eqv?-id in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_1913,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_1774(t3,C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2));}

/* a5598 in a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5599,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[41],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_eqp(C_fix(1),t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k2002 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2004,2,av);}
/* c-platform.scm:440: cons* */
t2=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_1975,2,av);}
a=C_alloc(16);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_slot(t2,C_fix(1));
t6=C_eqp(lf[41],t5);
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[3],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=t9,a[3]=t11,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:442: butlast */
t14=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t14;
av2[1]=t13;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=C_slot(t4,C_fix(1));
t9=C_eqp(lf[42],t8);
if(C_truep(t9)){
t10=C_i_length(((C_word*)t0)[2]);
t11=C_eqp(C_fix(2),t10);
if(C_truep(t11)){
t12=C_slot(t4,C_fix(2));
t13=C_i_car(t12);
if(C_truep((C_truep(C_eqp(t13,lf[49]))?C_SCHEME_TRUE:(C_truep(C_eqp(t13,lf[50]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* tweaks.scm:51: ##sys#get */
t15=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=t13;
av2[3]=lf[53];
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t14=t7;
f_2071(t14,C_SCHEME_FALSE);}}
else{
t12=t7;
f_2071(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_2071(t10,C_SCHEME_FALSE);}}}

/* k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in ... */
static void C_ccall f_2905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2905,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:649: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[664];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[665];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in ... */
static void C_ccall f_2908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2908,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:650: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[662];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[663];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in ... */
static void C_ccall f_2902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2902,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:648: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[666];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[667];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in ... */
static void C_ccall f_2938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2938,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:660: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[642];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[643];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in ... */
static void C_ccall f_2935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2935,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:659: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[644];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[645];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in ... */
static void C_ccall f_2932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2932,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:658: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[646];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[647];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in ... */
static void C_ccall f_2947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2947,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:663: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[636];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[637];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* a5129 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5130,6,av);}
a=C_alloc(7);
t6=C_i_length(t5);
if(C_truep(C_fixnum_greater_or_equal_p(t6,C_fix(2)))){
t7=C_i_car(t5);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5250,a[2]=t8,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5252,tmp=(C_word)a,a+=2,tmp);
t11=t5;
t12=C_u_i_cdr(t11);
/* c-platform.scm:320: remove */
t13=*((C_word*)lf[919]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t13;
av2[1]=t9;
av2[2]=t10;
av2[3]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}
else{
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k1784 in k1781 in k1772 in eqv?-id in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_1786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,1))){
C_save_and_reclaim_args((void *)trf_1786,2,t0,t1);}
a=C_alloc(19);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[35],lf[36],lf[40],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t2,t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in ... */
static void C_ccall f_2944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2944,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:662: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[638];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[639];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in ... */
static void C_ccall f_2941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2941,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:661: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[640];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[641];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1781 in k1772 in eqv?-id in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_1783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1783,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1786(t3,t1);}
else{
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_eqp(lf[41],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[5],C_fix(2));
t6=C_i_car(t5);
t7=C_i_flonump(t6);
t8=t2;
f_1786(t8,C_i_not(t7));}
else{
t5=t2;
f_1786(t5,C_SCHEME_FALSE);}}}

/* k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in ... */
static void C_ccall f_2917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2917,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:653: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[656];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[657];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in ... */
static void C_ccall f_2911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2911,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:651: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[660];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[661];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1772 in eqv?-id in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_1774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1774,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
t4=C_eqp(lf[41],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[6],C_fix(2));
t6=C_i_car(t5);
t7=C_i_flonump(t6);
t8=t2;
f_1783(t8,C_i_not(t7));}
else{
t5=t2;
f_1783(t5,C_SCHEME_FALSE);}}}

/* k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in ... */
static void C_ccall f_2914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2914,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:652: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[658];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[659];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in ... */
static void C_ccall f_3646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3646,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:992: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[182];
av2[3]=C_fix(22);
av2[4]=C_fix(2);
av2[5]=lf[183];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
av2[8]=lf[184];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_3649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3649,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:993: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[179];
av2[3]=C_fix(22);
av2[4]=C_fix(2);
av2[5]=lf[180];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
av2[8]=lf[181];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in ... */
static void C_ccall f_2929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2929,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:657: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[648];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[649];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in ... */
static void C_ccall f_2926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2926,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:656: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[650];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[651];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in ... */
static void C_ccall f_3643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3643,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:990: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[185];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[186];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in ... */
static void C_ccall f_3640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3640,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:989: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[187];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[188];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_platform_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("platform_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_platform_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(10845)){
C_save(t1);
C_rereclaim2(10845*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,933);
lf[0]=C_h_intern(&lf[0],36,"\010compilerdefault-optimization-passes");
lf[1]=C_h_intern(&lf[1],29,"\010compilerdefault-declarations");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014always-bound\376\003\000\000\002\376\001\000\000\022\003sysstandard-input\376\003\000\000\002\376\001\000\000\023\003sysstandard-ou"
"tput\376\003\000\000\002\376\001\000\000\022\003sysstandard-error\376\003\000\000\002\376\001\000\000\023\003sysundefined-value\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022b"
"ound-to-procedure\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\007\003sysmap\376\003\000\000\002\376\001\000\000\011\003sysprint\376\003\000\000\002"
"\376\001\000\000\012\003syssetter\376\003\000\000\002\376\001\000\000\013\003syssetslot\376\003\000\000\002\376\001\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\024\003syscall"
"-with-values\376\003\000\000\002\376\001\000\000\017\003sysstart-timer\376\003\000\000\002\376\001\000\000\016\003sysstop-timer\376\003\000\000\002\376\001\000\000\007\003sysgcd\376\003"
"\000\000\002\376\001\000\000\007\003syslcm\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\003\000\000\002\376\001\000\000\016\003sysstructure\077\376\003\000\000\002\376\001\000\000\010\003syss"
"lot\376\003\000\000\002\376\001\000\000\023\003sysallocate-vector\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\015\003sysblock-re"
"f\376\003\000\000\002\376\001\000\000\016\003sysblock-set!\376\003\000\000\002\376\001\000\000\010\003syslist\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\012\003sysappen"
"d\376\003\000\000\002\376\001\000\000\012\003sysvector\376\003\000\000\002\376\001\000\000\031\003sysforeign-char-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-fi"
"xnum-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-flonum-argument\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\001\000\000\021\003"
"syspeek-c-string\376\003\000\000\002\376\001\000\000\031\003syspeek-nonnull-c-string\376\003\000\000\002\376\001\000\000\032\003syspeek-and-free-c"
"-string\376\003\000\000\002\376\001\000\000\042\003syspeek-and-free-nonnull-c-string\376\003\000\000\002\376\001\000\000\032\003sysforeign-block-a"
"rgument\376\003\000\000\002\376\001\000\000\033\003sysforeign-string-argument\376\003\000\000\002\376\001\000\000\034\003sysforeign-pointer-argume"
"nt\376\003\000\000\002\376\001\000\000\034\003sysforeign-integer-argument\376\003\000\000\002\376\001\000\000\042\003syscall-with-current-continua"
"tion\376\377\016\376\377\016");
lf[3]=C_h_intern(&lf[3],39,"\010compilerdefault-debugging-declarations");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\004coredeclare\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004uses\376\003\000\000\002\376\001\000\000\010debu"
"gger\376\377\016\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022bound-to-procedure\376\003\000\000\002\376\001\000\000\024\003syspus"
"h-debug-frame\376\003\000\000\002\376\001\000\000\023\003syspop-debug-frame\376\003\000\000\002\376\001\000\000\025\003syscheck-debug-entry\376\003\000\000\002\376\001"
"\000\000\032\003syscheck-debug-assignment\376\003\000\000\002\376\001\000\000\032\003sysregister-debug-lambdas\376\003\000\000\002\376\001\000\000\034\003sysr"
"egister-debug-variables\376\003\000\000\002\376\001\000\000\016\003sysdebug-call\376\377\016\376\377\016\376\377\016\376\377\016");
lf[5]=C_h_intern(&lf[5],39,"\010compilerdefault-profiling-declarations");
lf[6]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\004coredeclare\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004uses\376\003\000\000\002\376\001\000\000\010profiler\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000"
"\000\022bound-to-procedure\376\003\000\000\002\376\001\000\000\021\003sysprofile-entry\376\003\000\000\002\376\001\000\000\020\003sysprofile-exit\376\377\016\376\377\016\376"
"\377\016");
lf[7]=C_h_intern(&lf[7],30,"\010compilerunits-used-by-default");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007library\376\003\000\000\002\376\001\000\000\004eval\376\003\000\000\002\376\001\000\000\016chicken-syntax\376\377\016");
lf[9]=C_h_intern(&lf[9],25,"\010compilerwords-per-flonum");
lf[10]=C_h_intern(&lf[10],27,"\010compilerunlikely-variables");
lf[11]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\020unquote-splicing\376\377\016");
lf[12]=C_h_intern(&lf[12],27,"\010compilereq-inline-operator");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[14]=C_h_intern(&lf[14],34,"\010compilermembership-test-operators");
lf[15]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_i_memq\376B\000\000\005C_eqp\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_u_i_memq\376B\000\000\005C_eqp\376\003\000\000\002\376\003\000\000\002\376B"
"\000\000\012C_i_member\376B\000\000\012C_i_equalp\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_i_memv\376B\000\000\010C_i_eqvp\376\377\016");
lf[16]=C_h_intern(&lf[16],32,"\010compilermembership-unfold-limit");
lf[17]=C_h_intern(&lf[17],28,"\010compilertarget-include-file");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\011chicken.h");
lf[19]=C_h_intern(&lf[19],31,"\010compilervalid-compiler-options");
lf[20]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005-help\376\003\000\000\002\376\001\000\000\001h\376\003\000\000\002\376\001\000\000\004help\376\003\000\000\002\376\001\000\000\007version\376\003\000\000\002\376\001\000\000\007verbose\376\003\000\000\002\376"
"\001\000\000\014explicit-use\376\003\000\000\002\376\001\000\000\010no-trace\376\003\000\000\002\376\001\000\000\013no-warnings\376\003\000\000\002\376\001\000\000\006unsafe\376\003\000\000\002\376\001\000\000"
"\005block\376\003\000\000\002\376\001\000\000\014check-syntax\376\003\000\000\002\376\001\000\000\011to-stdout\376\003\000\000\002\376\001\000\000\025no-usual-integrations\376\003"
"\000\000\002\376\001\000\000\020case-insensitive\376\003\000\000\002\376\001\000\000\016no-lambda-info\376\003\000\000\002\376\001\000\000\007profile\376\003\000\000\002\376\001\000\000\006inlin"
"e\376\003\000\000\002\376\001\000\000\024keep-shadowed-macros\376\003\000\000\002\376\001\000\000\021ignore-repository\376\003\000\000\002\376\001\000\000\021fixnum-arith"
"metic\376\003\000\000\002\376\001\000\000\022disable-interrupts\376\003\000\000\002\376\001\000\000\026optimize-leaf-routines\376\003\000\000\002\376\001\000\000\016compi"
"le-syntax\376\003\000\000\002\376\001\000\000\014tag-pointers\376\003\000\000\002\376\001\000\000\022accumulate-profile\376\003\000\000\002\376\001\000\000\035disable-sta"
"ck-overflow-checks\376\003\000\000\002\376\001\000\000\003raw\376\003\000\000\002\376\001\000\000\012specialize\376\003\000\000\002\376\001\000\000\036emit-external-proto"
"types-first\376\003\000\000\002\376\001\000\000\007release\376\003\000\000\002\376\001\000\000\005local\376\003\000\000\002\376\001\000\000\015inline-global\376\003\000\000\002\376\001\000\000\014anal"
"yze-only\376\003\000\000\002\376\001\000\000\007dynamic\376\003\000\000\002\376\001\000\000\012scrutinize\376\003\000\000\002\376\001\000\000\016no-argc-checks\376\003\000\000\002\376\001\000\000\023n"
"o-procedure-checks\376\003\000\000\002\376\001\000\000)no-procedure-checks-for-toplevel-bindings\376\003\000\000\002\376\001\000\000\006m"
"odule\376\003\000\000\002\376\001\000\000\017no-bound-checks\376\003\000\000\002\376\001\000\000&no-procedure-checks-for-usual-bindings\376\003"
"\000\000\002\376\001\000\000\022no-compiler-syntax\376\003\000\000\002\376\001\000\000\027no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\020no-symbol-e"
"scape\376\003\000\000\002\376\001\000\000\013r5rs-syntax\376\003\000\000\002\376\001\000\000\031emit-all-import-libraries\376\003\000\000\002\376\001\000\000\014strict-ty"
"pes\376\003\000\000\002\376\001\000\000\012clustering\376\003\000\000\002\376\001\000\000\004lfa2\376\003\000\000\002\376\001\000\000\012debug-info\376\003\000\000\002\376\001\000\000\012setup-mode\376\003\000"
"\000\002\376\001\000\000\026no-module-registration\376\377\016");
lf[21]=C_h_intern(&lf[21],45,"\010compilervalid-compiler-options-with-argument");
lf[22]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005debug\376\003\000\000\002\376\001\000\000\013output-file\376\003\000\000\002\376\001\000\000\014include-path\376\003\000\000\002\376\001\000\000\011heap-size\376\003\000"
"\000\002\376\001\000\000\012stack-size\376\003\000\000\002\376\001\000\000\004unit\376\003\000\000\002\376\001\000\000\004uses\376\003\000\000\002\376\001\000\000\015keyword-style\376\003\000\000\002\376\001\000\000\021re"
"quire-extension\376\003\000\000\002\376\001\000\000\014inline-limit\376\003\000\000\002\376\001\000\000\014profile-name\376\003\000\000\002\376\001\000\000\024parenthesis"
"-synonyms\376\003\000\000\002\376\001\000\000\007prelude\376\003\000\000\002\376\001\000\000\010postlude\376\003\000\000\002\376\001\000\000\010prologue\376\003\000\000\002\376\001\000\000\010epilogue"
"\376\003\000\000\002\376\001\000\000\007nursery\376\003\000\000\002\376\001\000\000\006extend\376\003\000\000\002\376\001\000\000\007feature\376\003\000\000\002\376\001\000\000\012no-feature\376\003\000\000\002\376\001\000\000\005"
"types\376\003\000\000\002\376\001\000\000\023emit-import-library\376\003\000\000\002\376\001\000\000\020emit-inline-file\376\003\000\000\002\376\001\000\000\020static-ext"
"ension\376\003\000\000\002\376\001\000\000\023consult-inline-file\376\003\000\000\002\376\001\000\000\016emit-type-file\376\003\000\000\002\376\001\000\000\012ffi-define\376"
"\003\000\000\002\376\001\000\000\020ffi-include-path\376\377\016");
lf[23]=C_h_intern(&lf[23],34,"\010compilerdefault-standard-bindings");
lf[24]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\036call-with-current-contin"
"uation\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003"
"\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr"
"\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002"
"\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaar\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000"
"\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadadr\376\003\000\000\002\376\001\000\000\006caddar\376\003\000\000\002\376\001\000"
"\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdaddr\376\003\000\000\002\376\001\000"
"\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-car!\376\003\000\000\002\376"
"\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\006length\376\003\000\000\002\376\001\000"
"\000\005zero\077\376\003\000\000\002\376\001\000\000\001\052\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001"
"\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\022cu"
"rrent-input-port\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007di"
"splay\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\003map\376\003\000\000"
"\002\376\001\000\000\005char\077\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000\000\013eof-object\077\376\003"
"\000\000\002\376\001\000\000\015vector-length\376\003\000\000\002\376\001\000\000\015string-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string"
"-set!\376\003\000\000\002\376\001\000\000\012vector-ref\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003"
"\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376"
"\001\000\000\007reverse\376\003\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077\376\003\000\000\002\376\001\000\000\010c"
"omplex\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001"
"\000\000\005even\077\376\003\000\000\002\376\001\000\000\011positive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\010inexact\077"
"\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376"
"\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016exact-"
">inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000"
"\004expt\376\003\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376\003\000\000\002\376\001"
"\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376"
"\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000"
"\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015char-numeric\077\376\003\000\000\002\376\001\000\000\020cha"
"r-lower-case\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\013char-upcase\376\003\000\000\002\376\001\000\000\015char-downc"
"ase\376\003\000\000\002\376\001\000\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376"
"\001\000\000\011string>=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376"
"\001\000\000\013string-ci>\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\015string-appe"
"nd\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\014vector-"
">list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\004read\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000"
"\002\376\001\000\000\011substring\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\013make-string"
"\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002\376\001\000"
"\000\024call-with-input-file\376\003\000\000\002\376\001\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\020close-input-port\376"
"\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\006ve"
"ctor\376\003\000\000\002\376\001\000\000\012procedure\077\376\003\000\000\002\376\001\000\000\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004as"
"sq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\003ab"
"s\376\003\000\000\002\376\001\000\000\013char-ready\077\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\014string-"
">list\376\003\000\000\002\376\001\000\000\022current-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\377\016");
lf[25]=C_h_intern(&lf[25],34,"\010compilerdefault-extended-bindings");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013bitwise-and\376\003\000\000\002\376\001\000\000\012alist-cons\376\003\000\000\002\376\001\000\000\005xcons\376\003\000\000\002\376\001\000\000\013bitwise-ior\376\003\000"
"\000\002\376\001\000\000\013bitwise-xor\376\003\000\000\002\376\001\000\000\013bitwise-not\376\003\000\000\002\376\001\000\000\004add1\376\003\000\000\002\376\001\000\000\004sub1\376\003\000\000\002\376\001\000\000\003fx+"
"\376\003\000\000\002\376\001\000\000\003fx-\376\003\000\000\002\376\001\000\000\003fx\052\376\003\000\000\002\376\001\000\000\003fx/\376\003\000\000\002\376\001\000\000\004fx+\077\376\003\000\000\002\376\001\000\000\004fx-\077\376\003\000\000\002\376\001\000\000\004fx\052"
"\077\376\003\000\000\002\376\001\000\000\004fx/\077\376\003\000\000\002\376\001\000\000\005fxmod\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\004fp/\077\376\003\000\000\002\376\001\000\000\003fx=\376\003\000\000\002\376\001\000\000\003fx"
">\376\003\000\000\002\376\001\000\000\003fx<\376\003\000\000\002\376\001\000\000\004fx>=\376\003\000\000\002\376\001\000\000\004fx<=\376\003\000\000\002\376\001\000\000\007fixnum\077\376\003\000\000\002\376\001\000\000\005fxneg\376\003\000\000\002\376"
"\001\000\000\005fxmax\376\003\000\000\002\376\001\000\000\005fxmin\376\003\000\000\002\376\001\000\000\010identity\376\003\000\000\002\376\001\000\000\003fp+\376\003\000\000\002\376\001\000\000\003fp-\376\003\000\000\002\376\001\000\000\003fp"
"\052\376\003\000\000\002\376\001\000\000\003fp/\376\003\000\000\002\376\001\000\000\005fpmin\376\003\000\000\002\376\001\000\000\005fpmax\376\003\000\000\002\376\001\000\000\005fpneg\376\003\000\000\002\376\001\000\000\003fp>\376\003\000\000\002\376\001\000"
"\000\003fp<\376\003\000\000\002\376\001\000\000\003fp=\376\003\000\000\002\376\001\000\000\004fp>=\376\003\000\000\002\376\001\000\000\004fp<=\376\003\000\000\002\376\001\000\000\005fxand\376\003\000\000\002\376\001\000\000\005fxnot\376\003\000\000"
"\002\376\001\000\000\005fxior\376\003\000\000\002\376\001\000\000\005fxxor\376\003\000\000\002\376\001\000\000\005fxshr\376\003\000\000\002\376\001\000\000\005fxshl\376\003\000\000\002\376\001\000\000\010bit-set\077\376\003\000\000\002\376"
"\001\000\000\006fxodd\077\376\003\000\000\002\376\001\000\000\007fxeven\077\376\003\000\000\002\376\001\000\000\007fpfloor\376\003\000\000\002\376\001\000\000\011fpceiling\376\003\000\000\002\376\001\000\000\012fptrunc"
"ate\376\003\000\000\002\376\001\000\000\007fpround\376\003\000\000\002\376\001\000\000\005fpsin\376\003\000\000\002\376\001\000\000\005fpcos\376\003\000\000\002\376\001\000\000\005fptan\376\003\000\000\002\376\001\000\000\006fpasi"
"n\376\003\000\000\002\376\001\000\000\006fpacos\376\003\000\000\002\376\001\000\000\006fpatan\376\003\000\000\002\376\001\000\000\007fpatan2\376\003\000\000\002\376\001\000\000\005fpexp\376\003\000\000\002\376\001\000\000\006fpexp"
"t\376\003\000\000\002\376\001\000\000\005fplog\376\003\000\000\002\376\001\000\000\006fpsqrt\376\003\000\000\002\376\001\000\000\005fpabs\376\003\000\000\002\376\001\000\000\012fpinteger\077\376\003\000\000\002\376\001\000\000\020ari"
"thmetic-shift\376\003\000\000\002\376\001\000\000\004void\376\003\000\000\002\376\001\000\000\014flush-output\376\003\000\000\002\376\001\000\000\017thread-specific\376\003\000\000\002\376"
"\001\000\000\024thread-specific-set!\376\003\000\000\002\376\001\000\000\011not-pair\077\376\003\000\000\002\376\001\000\000\005atom\077\376\003\000\000\002\376\001\000\000\012null-list\077\376\003"
"\000\000\002\376\001\000\000\005print\376\003\000\000\002\376\001\000\000\006print\052\376\003\000\000\002\376\001\000\000\005error\376\003\000\000\002\376\001\000\000\014proper-list\077\376\003\000\000\002\376\001\000\000\007call"
"/cc\376\003\000\000\002\376\001\000\000\011blob-size\376\003\000\000\002\376\001\000\000\025u8vector->blob/shared\376\003\000\000\002\376\001\000\000\025s8vector->blob/sh"
"ared\376\003\000\000\002\376\001\000\000\026u16vector->blob/shared\376\003\000\000\002\376\001\000\000\026s16vector->blob/shared\376\003\000\000\002\376\001\000\000\026u3"
"2vector->blob/shared\376\003\000\000\002\376\001\000\000\026s32vector->blob/shared\376\003\000\000\002\376\001\000\000\026f32vector->blob/sh"
"ared\376\003\000\000\002\376\001\000\000\026f64vector->blob/shared\376\003\000\000\002\376\001\000\000\025blob->u8vector/shared\376\003\000\000\002\376\001\000\000\025blo"
"b->s8vector/shared\376\003\000\000\002\376\001\000\000\026blob->u16vector/shared\376\003\000\000\002\376\001\000\000\026blob->s16vector/shar"
"ed\376\003\000\000\002\376\001\000\000\026blob->u32vector/shared\376\003\000\000\002\376\001\000\000\026blob->s32vector/shared\376\003\000\000\002\376\001\000\000\026blob"
"->f32vector/shared\376\003\000\000\002\376\001\000\000\026blob->f64vector/shared\376\003\000\000\002\376\001\000\000\011block-ref\376\003\000\000\002\376\001\000\000\012b"
"lock-set!\376\003\000\000\002\376\001\000\000\017number-of-slots\376\003\000\000\002\376\001\000\000\017substring-index\376\003\000\000\002\376\001\000\000\022substring-i"
"ndex-ci\376\003\000\000\002\376\001\000\000\016hash-table-ref\376\003\000\000\002\376\001\000\000\004any\077\376\003\000\000\002\376\001\000\000\013read-string\376\003\000\000\002\376\001\000\000\013subs"
"tring=\077\376\003\000\000\002\376\001\000\000\016substring-ci=\077\376\003\000\000\002\376\001\000\000\005first\376\003\000\000\002\376\001\000\000\006second\376\003\000\000\002\376\001\000\000\005third\376\003\000"
"\000\002\376\001\000\000\006fourth\376\003\000\000\002\376\001\000\000\024make-record-instance\376\003\000\000\002\376\001\000\000\005foldl\376\003\000\000\002\376\001\000\000\005foldr\376\003\000\000\002\376\001"
"\000\000\017u8vector-length\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\020s"
"16vector-length\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\020s32vector-length\376\003\000\000\002\376\001\000\000\020f32"
"vector-length\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\006setter\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\003\000"
"\000\002\376\001\000\000\014s8vector-ref\376\003\000\000\002\376\001\000\000\015u16vector-ref\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\003\000\000\002\376\001\000\000\015u32ve"
"ctor-ref\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\003\000\000\002\376\001\000\000\015f64vector-ref\376\003\000"
"\000\002\376\001\000\000\016f32vector-set!\376\003\000\000\002\376\001\000\000\016f64vector-set!\376\003\000\000\002\376\001\000\000\015u8vector-set!\376\003\000\000\002\376\001\000\000\015s8"
"vector-set!\376\003\000\000\002\376\001\000\000\016u16vector-set!\376\003\000\000\002\376\001\000\000\016s16vector-set!\376\003\000\000\002\376\001\000\000\016u32vector-s"
"et!\376\003\000\000\002\376\001\000\000\016s32vector-set!\376\003\000\000\002\376\001\000\000\014locative-ref\376\003\000\000\002\376\001\000\000\015locative-set!\376\003\000\000\002\376\001\000"
"\000\020locative->object\376\003\000\000\002\376\001\000\000\011locative\077\376\003\000\000\002\376\001\000\000\017pointer->object\376\003\000\000\002\376\001\000\000\007flonum\077\376"
"\003\000\000\002\376\001\000\000\007finite\077\376\003\000\000\002\376\001\000\000\020address->pointer\376\003\000\000\002\376\001\000\000\020pointer->address\376\003\000\000\002\376\001\000\000\010po"
"inter+\376\003\000\000\002\376\001\000\000\011pointer=\077\376\003\000\000\002\376\001\000\000\016pointer-u8-ref\376\003\000\000\002\376\001\000\000\016pointer-s8-ref\376\003\000\000\002\376\001"
"\000\000\017pointer-u16-ref\376\003\000\000\002\376\001\000\000\017pointer-s16-ref\376\003\000\000\002\376\001\000\000\017pointer-u32-ref\376\003\000\000\002\376\001\000\000\017po"
"inter-s32-ref\376\003\000\000\002\376\001\000\000\017pointer-f32-ref\376\003\000\000\002\376\001\000\000\017pointer-f64-ref\376\003\000\000\002\376\001\000\000\017pointer"
"-u8-set!\376\003\000\000\002\376\001\000\000\017pointer-s8-set!\376\003\000\000\002\376\001\000\000\020pointer-u16-set!\376\003\000\000\002\376\001\000\000\020pointer-s16"
"-set!\376\003\000\000\002\376\001\000\000\020pointer-u32-set!\376\003\000\000\002\376\001\000\000\020pointer-s32-set!\376\003\000\000\002\376\001\000\000\020pointer-f32-s"
"et!\376\003\000\000\002\376\001\000\000\020pointer-f64-set!\376\003\000\000\002\376\001\000\000\022current-error-port\376\003\000\000\002\376\001\000\000\016current-threa"
"d\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\013get"
"-keyword\376\377\016");
lf[27]=C_h_intern(&lf[27],26,"\010compilerinternal-bindings");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysslot\376\003\000\000\002\376\001\000\000\013\003syssetslot\376\003\000\000\002\376\001\000\000\015\003sysblock-ref\376\003\000\000\002\376\001\000\000\016\003sysbloc"
"k-set!\376\003\000\000\002\376\001\000\000\042\003syscall-with-current-continuation\376\003\000\000\002\376\001\000\000\010\003syssize\376\003\000\000\002\376\001\000\000\010\003s"
"ysbyte\376\003\000\000\002\376\001\000\000\013\003syssetbyte\376\003\000\000\002\376\001\000\000\014\003syspointer\077\376\003\000\000\002\376\001\000\000\026\003sysgeneric-structure"
"\077\376\003\000\000\002\376\001\000\000\016\003sysstructure\077\376\003\000\000\002\376\001\000\000\023\003syscheck-structure\376\003\000\000\002\376\001\000\000\017\003syscheck-exact\376"
"\003\000\000\002\376\001\000\000\020\003syscheck-number\376\003\000\000\002\376\001\000\000\016\003syscheck-list\376\003\000\000\002\376\001\000\000\016\003syscheck-pair\376\003\000\000\002\376\001"
"\000\000\020\003syscheck-string\376\003\000\000\002\376\001\000\000\020\003syscheck-symbol\376\003\000\000\002\376\001\000\000\021\003syscheck-boolean\376\003\000\000\002\376\001\000"
"\000\022\003syscheck-locative\376\003\000\000\002\376\001\000\000\016\003syscheck-port\376\003\000\000\002\376\001\000\000\024\003syscheck-input-port\376\003\000\000\002\376"
"\001\000\000\025\003syscheck-output-port\376\003\000\000\002\376\001\000\000\023\003syscheck-open-port\376\003\000\000\002\376\001\000\000\016\003syscheck-char\376\003"
"\000\000\002\376\001\000\000\020\003syscheck-vector\376\003\000\000\002\376\001\000\000\025\003syscheck-byte-vector\376\003\000\000\002\376\001\000\000\010\003syslist\376\003\000\000\002\376\001"
"\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\020\003sysfits-in-int\077\376\003\000\000\002\376\001\000\000\031\003sy"
"sfits-in-unsigned-int\077\376\003\000\000\002\376\001\000\000\033\003sysflonum-in-fixnum-range\077\376\003\000\000\002\376\001\000\000\011\003sysfudge\376\003"
"\000\000\002\376\001\000\000\016\003sysimmediate\077\376\003\000\000\002\376\001\000\000\022\003syscontext-switch\376\003\000\000\002\376\001\000\000\022\003sysmake-structure\376\003"
"\000\000\002\376\001\000\000\011\003sysapply\376\003\000\000\002\376\001\000\000\020\003sysapply-values\376\003\000\000\002\376\001\000\000\026\003syscontinuation-graft\376\003\000\000\002"
"\376\001\000\000\017\003sysbytevector\077\376\003\000\000\002\376\001\000\000\017\003sysmake-vector\376\003\000\000\002\376\001\000\000\012\003syssetter\376\003\000\000\002\376\001\000\000\007\003sysc"
"ar\376\003\000\000\002\376\001\000\000\007\003syscdr\376\003\000\000\002\376\001\000\000\011\003syspair\077\376\003\000\000\002\376\001\000\000\007\003syseq\077\376\003\000\000\002\376\001\000\000\011\003syslist\077\376\003\000\000\002\376"
"\001\000\000\013\003sysvector\077\376\003\000\000\002\376\001\000\000\010\003syseqv\077\376\003\000\000\002\376\001\000\000\017\003sysget-keyword\376\003\000\000\002\376\001\000\000\031\003sysforeign-"
"char-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-fixnum-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-flonum-a"
"rgument\376\003\000\000\002\376\001\000\000\032\003sysforeign-block-argument\376\003\000\000\002\376\001\000\000#\003sysforeign-struct-wrapper-"
"argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-string-argument\376\003\000\000\002\376\001\000\000\034\003sysforeign-pointer-argum"
"ent\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\034\003sysforeign-integer-argument\376\003\000\000\002\376\001\000\000%\003sysforeign"
"-unsigned-integer-argument\376\003\000\000\002\376\001\000\000\017\003syspeek-fixnum\376\003\000\000\002\376\001\000\000\014\003syssetislot\376\003\000\000\002\376\001"
"\000\000\020\003syspoke-integer\376\003\000\000\002\376\001\000\000\016\003syspermanent\077\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001\000\000\017\003syspok"
"e-double\376\003\000\000\002\376\001\000\000\021\003sysintern-symbol\376\003\000\000\002\376\001\000\000\017\003sysmake-symbol\376\003\000\000\002\376\001\000\000\021\003sysnull-p"
"ointer\077\376\003\000\000\002\376\001\000\000\015\003syspeek-byte\376\003\000\000\002\376\001\000\000\020\003sysfile-exists\077\376\377\016");
lf[29]=C_h_intern(&lf[29],30,"\010compilernon-foldable-bindings");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\013make-vecto"
"r\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\022current-"
"input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\012write-char\376\003"
"\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\036call-wit"
"h-current-continuation\376\003\000\000\002\376\001\000\000\010set-car!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\012write-char\376\003"
"\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007display\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\013char"
"-ready\077\376\003\000\000\002\376\001\000\000\004read\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000"
"\013string-set!\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000"
"\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002\376\001\000\000\020close-input-port\376\003\000\000\002\376"
"\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-port\376\003\000\000\002\376\001\000\000\025call-with-output-po"
"rt\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003\000\000\002\376\001\000\000\010\003sysslot\376\003\000\000\002\376\001\000\000\013\003syssetslo"
"t\376\003\000\000\002\376\001\000\000\042\003syscall-with-current-continuation\376\003\000\000\002\376\001\000\000\011\003sysfudge\376\003\000\000\002\376\001\000\000\014flush-"
"output\376\003\000\000\002\376\001\000\000\005print\376\003\000\000\002\376\001\000\000\004void\376\003\000\000\002\376\001\000\000\025u8vector->blob/shared\376\003\000\000\002\376\001\000\000\025s8ve"
"ctor->blob/shared\376\003\000\000\002\376\001\000\000\026u16vector->blob/shared\376\003\000\000\002\376\001\000\000\026s16vector->blob/share"
"d\376\003\000\000\002\376\001\000\000\026u32vector->blob/shared\376\003\000\000\002\376\001\000\000\026f32vector->blob/shared\376\003\000\000\002\376\001\000\000\026f64ve"
"ctor->blob/shared\376\003\000\000\002\376\001\000\000\026s32vector->blob/shared\376\003\000\000\002\376\001\000\000\013read-string\376\003\000\000\002\376\001\000\000\014"
"read-string!\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\020address->pointer\376\003\000\000\002\376\001\000\000\020pointer->address\376\003\000\000\002"
"\376\001\000\000\022\003sysmake-structure\376\003\000\000\002\376\001\000\000\006print\052\376\003\000\000\002\376\001\000\000\017\003sysmake-vector\376\003\000\000\002\376\001\000\000\011\003sysap"
"ply\376\003\000\000\002\376\001\000\000\014\003syssetislot\376\003\000\000\002\376\001\000\000\015\003sysblock-ref\376\003\000\000\002\376\001\000\000\010\003sysbyte\376\003\000\000\002\376\001\000\000\013\003sys"
"setbyte\376\003\000\000\002\376\001\000\000\017\003sysget-keyword\376\003\000\000\002\376\001\000\000\013get-keyword\376\003\000\000\002\376\001\000\000\017u8vector-length\376\003"
"\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\020s16vector-length\376\003\000\000\002"
"\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\020s32vector-length\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001"
"\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\020\003sysapply-values\376\003\000\000\002\376\001\000\000\012\003syssetter\376\003\000\000\002\376\001\000\000\006sette"
"r\376\003\000\000\002\376\001\000\000\016f32vector-set!\376\003\000\000\002\376\001\000\000\016f64vector-set!\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\003\000\000\002\376\001\000\000"
"\014s8vector-ref\376\003\000\000\002\376\001\000\000\015u16vector-ref\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\003\000\000\002\376\001\000\000\015u32vector-r"
"ef\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\003\000\000\002\376\001\000\000\015u8vector-set!\376\003\000\000\002\376\001\000\000\015s8vector-set!\376\003\000\000\002\376\001\000\000"
"\016u16vector-set!\376\003\000\000\002\376\001\000\000\016s16vector-set!\376\003\000\000\002\376\001\000\000\016u32vector-set!\376\003\000\000\002\376\001\000\000\016s32vect"
"or-set!\376\003\000\000\002\376\001\000\000\021\003sysintern-symbol\376\003\000\000\002\376\001\000\000\017\003sysmake-symbol\376\003\000\000\002\376\001\000\000\024make-record"
"-instance\376\003\000\000\002\376\001\000\000\005error\376\003\000\000\002\376\001\000\000\016\003sysblock-set!\376\003\000\000\002\376\001\000\000\022current-error-port\376\003\000\000"
"\002\376\001\000\000\016current-thread\376\003\000\000\002\376\001\000\000\016pointer-u8-ref\376\003\000\000\002\376\001\000\000\017pointer-u8-set!\376\003\000\000\002\376\001\000\000\016p"
"ointer-s8-ref\376\003\000\000\002\376\001\000\000\017pointer-s8-set!\376\003\000\000\002\376\001\000\000\017pointer-u16-ref\376\003\000\000\002\376\001\000\000\020pointer"
"-u16-set!\376\003\000\000\002\376\001\000\000\017pointer-s16-ref\376\003\000\000\002\376\001\000\000\020pointer-s16-set!\376\003\000\000\002\376\001\000\000\017pointer-u3"
"2-ref\376\003\000\000\002\376\001\000\000\020pointer-u32-set!\376\003\000\000\002\376\001\000\000\017pointer-s32-ref\376\003\000\000\002\376\001\000\000\020pointer-s32-se"
"t!\376\003\000\000\002\376\001\000\000\017pointer-f32-ref\376\003\000\000\002\376\001\000\000\020pointer-f32-set!\376\003\000\000\002\376\001\000\000\017pointer-f64-ref\376\003"
"\000\000\002\376\001\000\000\020pointer-f64-set!\376\377\016");
lf[31]=C_h_intern(&lf[31],26,"\010compilerfoldable-bindings");
lf[32]=C_h_intern(&lf[32],6,"fixnum");
lf[33]=C_h_intern(&lf[33],11,"number-type");
lf[34]=C_h_intern(&lf[34],6,"unsafe");
lf[35]=C_h_intern(&lf[35],4,"node");
lf[36]=C_h_intern(&lf[36],11,"\004coreinline");
lf[37]=C_h_intern(&lf[37],9,"\004corecall");
lf[38]=C_h_intern(&lf[38],20,"\004coreinline_allocate");
lf[39]=C_h_intern(&lf[39],14,"\010compilerqnode");
lf[40]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_eqp\376\377\016");
lf[41]=C_h_intern(&lf[41],5,"quote");
lf[42]=C_h_intern(&lf[42],13,"\004corevariable");
lf[43]=C_h_intern(&lf[43],5,"cons\052");
lf[44]=C_h_intern(&lf[44],3,"map");
lf[45]=C_h_intern(&lf[45],6,"append");
lf[46]=C_h_intern(&lf[46],7,"butlast");
lf[47]=C_h_intern(&lf[47],9,"\004coreproc");
lf[48]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\007C_apply\376\003\000\000\002\376\377\006\001\376\377\016");
lf[49]=C_h_intern(&lf[49],6,"values");
lf[50]=C_h_intern(&lf[50],10,"\003sysvalues");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016C_apply_values\376\003\000\000\002\376\377\006\001\376\377\016");
lf[52]=C_h_intern(&lf[52],7,"\003sysget");
lf[53]=C_h_intern(&lf[53],18,"\010compilerintrinsic");
lf[54]=C_h_intern(&lf[54],4,"last");
lf[55]=C_h_intern(&lf[55],30,"call-with-current-continuation");
lf[56]=C_h_intern(&lf[56],16,"\010compilerrewrite");
lf[57]=C_h_intern(&lf[57],11,"\004corelambda");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],16,"\010compilervarnode");
lf[60]=C_h_intern(&lf[60],6,"gensym");
lf[61]=C_h_intern(&lf[61],2,"f_");
lf[62]=C_h_intern(&lf[62],18,"\010compilerdebugging");
lf[63]=C_h_intern(&lf[63],1,"o");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000)removing single-valued `call-with-values\047");
lf[65]=C_h_intern(&lf[65],1,"r");
lf[66]=C_h_intern(&lf[66],12,"\010compilerget");
lf[67]=C_h_intern(&lf[67],5,"value");
lf[68]=C_h_intern(&lf[68],14,"\004coreundefined");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_vector");
lf[70]=C_h_intern(&lf[70],13,"list-tabulate");
lf[71]=C_h_intern(&lf[71],16,"inline-transient");
lf[72]=C_h_intern(&lf[72],8,"assigned");
lf[73]=C_h_intern(&lf[73],10,"references");
lf[74]=C_h_intern(&lf[74],30,"\010compilerdecompose-lambda-list");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[76]=C_h_intern(&lf[76],5,"xcons");
lf[77]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[79]=C_h_intern(&lf[79],10,"alist-cons");
lf[80]=C_h_intern(&lf[80],15,"\003sysget-keyword");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_get_keyword");
lf[82]=C_h_intern(&lf[82],11,"get-keyword");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_get_keyword");
lf[84]=C_h_intern(&lf[84],18,"substring-index-ci");
lf[85]=C_h_intern(&lf[85],22,"\003syssubstring-index-ci");
lf[86]=C_h_intern(&lf[86],15,"substring-index");
lf[87]=C_h_intern(&lf[87],19,"\003syssubstring-index");
lf[88]=C_h_intern(&lf[88],14,"substring-ci=\077");
lf[89]=C_h_intern(&lf[89],18,"\003syssubstring-ci=\077");
lf[90]=C_h_intern(&lf[90],11,"substring=\077");
lf[91]=C_h_intern(&lf[91],15,"\003syssubstring=\077");
lf[92]=C_h_intern(&lf[92],11,"read-string");
lf[93]=C_h_intern(&lf[93],20,"\003sysread-string/port");
lf[94]=C_h_intern(&lf[94],18,"\003sysstandard-input");
lf[95]=C_h_intern(&lf[95],10,"write-char");
lf[96]=C_h_intern(&lf[96],19,"\003syswrite-char/port");
lf[97]=C_h_intern(&lf[97],19,"\003sysstandard-output");
lf[98]=C_h_intern(&lf[98],9,"read-char");
lf[99]=C_h_intern(&lf[99],18,"\003sysread-char/port");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_i_bit_setp");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_bit_setp");
lf[102]=C_h_intern(&lf[102],8,"bit-set\077");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006C_anyp\376\377\016");
lf[104]=C_h_intern(&lf[104],6,"global");
lf[105]=C_h_intern(&lf[105],4,"any\077");
lf[106]=C_h_intern(&lf[106],18,"current-error-port");
lf[107]=C_h_intern(&lf[107],18,"\003sysstandard-error");
lf[108]=C_h_intern(&lf[108],19,"current-output-port");
lf[109]=C_h_intern(&lf[109],18,"current-input-port");
lf[110]=C_h_intern(&lf[110],14,"current-thread");
lf[111]=C_h_intern(&lf[111],18,"\003syscurrent-thread");
lf[112]=C_h_intern(&lf[112],8,"\003sysvoid");
lf[113]=C_h_intern(&lf[113],19,"\003sysundefined-value");
lf[114]=C_h_intern(&lf[114],4,"void");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003car\376\001\000\000\010set-car!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003cdr\376\001\000\000\010set-cdr!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016has"
"h-table-ref\376\001\000\000\017hash-table-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011block-ref\376\001\000\000\012block-set!\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\014locative-ref\376\001\000\000\015locative-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\001\000\000\015u8vector-set!"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\001\000\000\015s8vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015u16vector-ref\376\001\000\000\016u1"
"6vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\001\000\000\016s16vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015u32vec"
"tor-ref\376\001\000\000\016u32vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\001\000\000\016s32vector-set!\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\015f32vector-ref\376\001\000\000\016f32vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015f64vector-ref\376\001\000\000\016f64vect"
"or-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016pointer-u8-ref\376\001\000\000\017pointer-u8-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016pointer-s"
"8-ref\376\001\000\000\017pointer-s8-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-u16-ref\376\001\000\000\020pointer-u16-set!\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\017pointer-s16-ref\376\001\000\000\020pointer-s16-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-u32-ref\376\001\000"
"\000\020pointer-u32-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-s32-ref\376\001\000\000\020pointer-s32-set!\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\017pointer-f32-ref\376\001\000\000\020pointer-f32-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-f64-ref\376\001\000\000\020point"
"er-f64-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012string-ref\376\001\000\000\013string-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012vector-ref\376\001\000"
"\000\013vector-set!\376\377\016");
lf[116]=C_h_intern(&lf[116],10,"\003syssetter");
lf[117]=C_h_intern(&lf[117],7,"call/cc");
lf[118]=C_h_intern(&lf[118],20,"thread-specific-set!");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_setslot");
lf[120]=C_h_intern(&lf[120],15,"thread-specific");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[122]=C_h_intern(&lf[122],15,"\003sysmake-vector");
lf[123]=C_h_intern(&lf[123],11,"make-vector");
lf[124]=C_h_intern(&lf[124],22,"f64vector->blob/shared");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[126]=C_h_intern(&lf[126],22,"f32vector->blob/shared");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[128]=C_h_intern(&lf[128],22,"s32vector->blob/shared");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[130]=C_h_intern(&lf[130],22,"u32vector->blob/shared");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[132]=C_h_intern(&lf[132],22,"s16vector->blob/shared");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[134]=C_h_intern(&lf[134],22,"u16vector->blob/shared");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[136]=C_h_intern(&lf[136],21,"s8vector->blob/shared");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[138]=C_h_intern(&lf[138],21,"u8vector->blob/shared");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[140]=C_h_intern(&lf[140],10,"null-list\077");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_null_list_p");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_nullp");
lf[143]=C_h_intern(&lf[143],5,"atom\077");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_not_pair_p");
lf[145]=C_h_intern(&lf[145],9,"not-pair\077");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_not_pair_p");
lf[147]=C_h_intern(&lf[147],16,"f64vector-length");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_64vector_length");
lf[149]=C_h_intern(&lf[149],16,"f32vector-length");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_32vector_length");
lf[151]=C_h_intern(&lf[151],16,"s32vector-length");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_32vector_length");
lf[153]=C_h_intern(&lf[153],16,"u32vector-length");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_32vector_length");
lf[155]=C_h_intern(&lf[155],16,"s16vector-length");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_16vector_length");
lf[157]=C_h_intern(&lf[157],16,"u16vector-length");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_16vector_length");
lf[159]=C_h_intern(&lf[159],15,"s8vector-length");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_8vector_length");
lf[161]=C_h_intern(&lf[161],15,"u8vector-length");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_8vector_length");
lf[163]=C_h_intern(&lf[163],14,"f64vector-set!");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_f64vector_set");
lf[165]=C_h_intern(&lf[165],14,"f32vector-set!");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_f32vector_set");
lf[167]=C_h_intern(&lf[167],14,"s32vector-set!");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s32vector_set");
lf[169]=C_h_intern(&lf[169],14,"u32vector-set!");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u32vector_set");
lf[171]=C_h_intern(&lf[171],14,"s16vector-set!");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s16vector_set");
lf[173]=C_h_intern(&lf[173],14,"u16vector-set!");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u16vector_set");
lf[175]=C_h_intern(&lf[175],13,"s8vector-set!");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_s8vector_set");
lf[177]=C_h_intern(&lf[177],13,"u8vector-set!");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_u8vector_set");
lf[179]=C_h_intern(&lf[179],13,"s32vector-ref");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_s32vector_ref");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s32vector_ref");
lf[182]=C_h_intern(&lf[182],13,"u32vector-ref");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_u32vector_ref");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u32vector_ref");
lf[185]=C_h_intern(&lf[185],13,"f64vector-ref");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_f64vector_ref");
lf[187]=C_h_intern(&lf[187],13,"f32vector-ref");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_f32vector_ref");
lf[189]=C_h_intern(&lf[189],13,"s16vector-ref");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s16vector_ref");
lf[191]=C_h_intern(&lf[191],13,"u16vector-ref");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u16vector_ref");
lf[193]=C_h_intern(&lf[193],12,"s8vector-ref");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_s8vector_ref");
lf[195]=C_h_intern(&lf[195],12,"u8vector-ref");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_u8vector_ref");
lf[197]=C_h_intern(&lf[197],9,"blob-size");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\014C_block_size");
lf[199]=C_h_intern(&lf[199],37,"\003sysforeign-unsigned-integer-argument");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000&C_i_foreign_unsigned_integer_argumentp");
lf[201]=C_h_intern(&lf[201],28,"\003sysforeign-integer-argument");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\035C_i_foreign_integer_argumentp");
lf[203]=C_h_intern(&lf[203],28,"\003sysforeign-pointer-argument");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\035C_i_foreign_pointer_argumentp");
lf[205]=C_h_intern(&lf[205],27,"\003sysforeign-string-argument");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\034C_i_foreign_string_argumentp");
lf[207]=C_h_intern(&lf[207],35,"\003sysforeign-struct-wrapper-argument");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000$C_i_foreign_struct_wrapper_argumentp");
lf[209]=C_h_intern(&lf[209],26,"\003sysforeign-block-argument");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\033C_i_foreign_block_argumentp");
lf[211]=C_h_intern(&lf[211],27,"\003sysforeign-flonum-argument");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\034C_i_foreign_flonum_argumentp");
lf[213]=C_h_intern(&lf[213],25,"\003sysforeign-char-argument");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\032C_i_foreign_char_argumentp");
lf[215]=C_h_intern(&lf[215],27,"\003sysforeign-fixnum-argument");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\034C_i_foreign_fixnum_argumentp");
lf[217]=C_h_intern(&lf[217],13,"locative-set!");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_locative_set");
lf[219]=C_h_intern(&lf[219],16,"locative->object");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\026C_i_locative_to_object");
lf[221]=C_h_intern(&lf[221],14,"\003sysimmediate\077");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\006C_immp");
lf[223]=C_h_intern(&lf[223],17,"\003sysnull-pointer\077");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\017C_null_pointerp");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\017C_null_pointerp");
lf[226]=C_h_intern(&lf[226],14,"\003syspermanent\077");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\014C_permanentp");
lf[228]=C_h_intern(&lf[228],27,"\003sysflonum-in-fixnum-range\077");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\032C_flonum_in_fixnum_range_p");
lf[230]=C_h_intern(&lf[230],25,"\003sysfits-in-unsigned-int\077");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\030C_fits_in_unsigned_int_p");
lf[232]=C_h_intern(&lf[232],16,"\003sysfits-in-int\077");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fits_in_int_p");
lf[234]=C_h_intern(&lf[234],9,"\003sysfudge");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\007C_fudge");
lf[236]=C_h_intern(&lf[236],11,"string-ci=\077");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_string_ci_equal_p");
lf[238]=C_h_intern(&lf[238],8,"string=\077");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_string_equal_p");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_string_equal_p");
lf[241]=C_h_intern(&lf[241],15,"\003syspoke-double");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\015C_poke_double");
lf[243]=C_h_intern(&lf[243],16,"\003syspoke-integer");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\016C_poke_integer");
lf[245]=C_h_intern(&lf[245],12,"\003syssetislot");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_set_i_slot");
lf[247]=C_h_intern(&lf[247],15,"pointer->object");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\023C_pointer_to_object");
lf[249]=C_h_intern(&lf[249],13,"\003syspeek-byte");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\013C_peek_byte");
lf[251]=C_h_intern(&lf[251],15,"\003syspeek-fixnum");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\015C_peek_fixnum");
lf[253]=C_h_intern(&lf[253],11,"\003syssetbyte");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\011C_setbyte");
lf[255]=C_h_intern(&lf[255],8,"\003sysbyte");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\011C_subbyte");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\033C_i_fixnum_arithmetic_shift\376\377\016");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_i_arithmetic_shift");
lf[259]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016");
lf[260]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\023C_fixnum_shift_left\376\377\016");
lf[261]=C_h_intern(&lf[261],20,"\010compilerbig-fixnum\077");
lf[262]=C_h_intern(&lf[262],16,"arithmetic-shift");
lf[263]=C_h_intern(&lf[263],5,"fxmod");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_modulo");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_fixnum_modulo");
lf[266]=C_h_intern(&lf[266],3,"fx/");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_divide");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_fixnum_divide");
lf[269]=C_h_intern(&lf[269],5,"fxior");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\013C_fixnum_or");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_fixnum_or");
lf[272]=C_h_intern(&lf[272],5,"fxand");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_and");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_fixnum_and");
lf[275]=C_h_intern(&lf[275],5,"fxxor");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[278]=C_h_intern(&lf[278],5,"fxneg");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_negate");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_fixnum_negate");
lf[281]=C_h_intern(&lf[281],5,"fxshr");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\024C_fixnum_shift_right");
lf[283]=C_h_intern(&lf[283],5,"fxshl");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fixnum_shift_left");
lf[285]=C_h_intern(&lf[285],3,"fx-");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fixnum_difference");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_fixnum_difference");
lf[288]=C_h_intern(&lf[288],3,"fx+");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fixnum_plus");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_fixnum_plus");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016C_i_set_i_slot\376\377\016");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\013C_i_setslot\376\377\016");
lf[293]=C_h_intern(&lf[293],19,"\010compilerimmediate\077");
lf[294]=C_h_intern(&lf[294],11,"\003syssetslot");
lf[295]=C_h_intern(&lf[295],15,"pointer-f64-ref");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_f64_ref");
lf[297]=C_h_intern(&lf[297],15,"pointer-f32-ref");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_f32_ref");
lf[299]=C_h_intern(&lf[299],15,"pointer-s32-ref");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_s32_ref");
lf[301]=C_h_intern(&lf[301],15,"pointer-u32-ref");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_u32_ref");
lf[303]=C_h_intern(&lf[303],16,"pointer-f64-set!");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_f64_set");
lf[305]=C_h_intern(&lf[305],16,"pointer-f32-set!");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_f32_set");
lf[307]=C_h_intern(&lf[307],16,"pointer-s32-set!");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_s32_set");
lf[309]=C_h_intern(&lf[309],16,"pointer-u32-set!");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_u32_set");
lf[311]=C_h_intern(&lf[311],16,"pointer-s16-set!");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_s16_set");
lf[313]=C_h_intern(&lf[313],16,"pointer-u16-set!");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_u16_set");
lf[315]=C_h_intern(&lf[315],15,"pointer-s8-set!");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_s8_set");
lf[317]=C_h_intern(&lf[317],15,"pointer-u8-set!");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_u8_set");
lf[319]=C_h_intern(&lf[319],15,"pointer-s16-ref");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_s16_ref");
lf[321]=C_h_intern(&lf[321],15,"pointer-u16-ref");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_u16_ref");
lf[323]=C_h_intern(&lf[323],14,"pointer-s8-ref");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_s8_ref");
lf[325]=C_h_intern(&lf[325],14,"pointer-u8-ref");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_u8_ref");
lf[327]=C_h_intern(&lf[327],8,"pointer+");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_u_i_pointer_inc");
lf[329]=C_h_intern(&lf[329],16,"pointer->address");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\030C_a_i_pointer_to_address");
lf[331]=C_h_intern(&lf[331],16,"address->pointer");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\030C_a_i_address_to_pointer");
lf[333]=C_h_intern(&lf[333],6,"string");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_string");
lf[335]=C_h_intern(&lf[335],18,"\003sysmake-structure");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_record");
lf[337]=C_h_intern(&lf[337],10,"\003sysvector");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_vector");
lf[339]=C_h_intern(&lf[339],6,"vector");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_vector");
lf[341]=C_h_intern(&lf[341],8,"\003syslist");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[343]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[344]=C_h_intern(&lf[344],4,"list");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[347]=C_h_intern(&lf[347],8,"\003syscons");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_cons");
lf[349]=C_h_intern(&lf[349],4,"cons");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_cons");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\026C_a_i_string_to_number\376\003\000\000\002\376\377\001\000\000\000\004\376\377\016");
lf[352]=C_h_intern(&lf[352],14,"string->number");
lf[353]=C_h_intern(&lf[353],7,"fpround");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_floor");
lf[355]=C_h_intern(&lf[355],9,"fpceiling");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\024C_a_i_flonum_ceiling");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_round");
lf[358]=C_h_intern(&lf[358],10,"fptruncate");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_i_flonum_truncate");
lf[360]=C_h_intern(&lf[360],5,"fpabs");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_abs");
lf[362]=C_h_intern(&lf[362],6,"fpsqrt");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_sqrt");
lf[364]=C_h_intern(&lf[364],5,"fplog");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_log");
lf[366]=C_h_intern(&lf[366],6,"fpexpt");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_expt");
lf[368]=C_h_intern(&lf[368],5,"fpexp");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_exp");
lf[370]=C_h_intern(&lf[370],7,"fpatan2");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_atan2");
lf[372]=C_h_intern(&lf[372],6,"fpatan");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_atan");
lf[374]=C_h_intern(&lf[374],6,"fpacos");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_acos");
lf[376]=C_h_intern(&lf[376],6,"fpasin");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_asin");
lf[378]=C_h_intern(&lf[378],5,"fptan");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_tan");
lf[380]=C_h_intern(&lf[380],5,"fpcos");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_cos");
lf[382]=C_h_intern(&lf[382],5,"fpsin");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_sin");
lf[384]=C_h_intern(&lf[384],8,"truncate");
lf[385]=C_h_intern(&lf[385],6,"flonum");
lf[386]=C_h_intern(&lf[386],7,"ceiling");
lf[387]=C_h_intern(&lf[387],5,"floor");
lf[388]=C_h_intern(&lf[388],7,"fpfloor");
lf[389]=C_h_intern(&lf[389],7,"fxeven\077");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_fixnumevenp");
lf[391]=C_h_intern(&lf[391],6,"fxodd\077");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnumoddp");
lf[393]=C_h_intern(&lf[393],4,"odd\077");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_oddp");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_oddp");
lf[396]=C_h_intern(&lf[396],5,"even\077");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_evenp");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_evenp");
lf[399]=C_h_intern(&lf[399],9,"remainder");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_modulo");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_modulo");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnumoddp");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnumoddp");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_fixnumevenp");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_fixnumevenp");
lf[406]=C_h_intern(&lf[406],15,"\003sysmake-symbol");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\015C_make_symbol");
lf[408]=C_h_intern(&lf[408],17,"\003sysintern-symbol");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\022C_string_to_symbol");
lf[410]=C_h_intern(&lf[410],18,"\003syscontext-switch");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\020C_context_switch");
lf[412]=C_h_intern(&lf[412],14,"return-to-host");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\020C_return_to_host");
lf[414]=C_h_intern(&lf[414],23,"\003sysensure-heap-reserve");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\025C_ensure_heap_reserve");
lf[416]=C_h_intern(&lf[416],19,"\003sysallocate-vector");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\021C_allocate_vector");
lf[418]=C_h_intern(&lf[418],34,"\003syscall-with-current-continuation");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\011C_call_cc");
lf[420]=C_h_intern(&lf[420],14,"number->string");
lf[421]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\001\376\377\001\000\000\000\002");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\022C_number_to_string");
lf[423]=C_h_intern(&lf[423],1,"-");
lf[424]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\001\376\377\006\000");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\007C_minus");
lf[426]=C_h_intern(&lf[426],1,"/");
lf[427]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\001\376\377\006\000");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\010C_divide");
lf[429]=C_h_intern(&lf[429],1,"+");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\006C_plus");
lf[431]=C_h_intern(&lf[431],1,"\052");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\007C_times");
lf[433]=C_h_intern(&lf[433],2,"<=");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\021C_less_or_equal_p");
lf[435]=C_h_intern(&lf[435],2,">=");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\024C_greater_or_equal_p");
lf[437]=C_h_intern(&lf[437],1,"<");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\007C_lessp");
lf[439]=C_h_intern(&lf[439],1,">");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\012C_greaterp");
lf[441]=C_h_intern(&lf[441],1,"=");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\011C_nequalp");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_less_or_equalp");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_greater_or_equalp");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_lessp");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_greaterp");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_nequalp");
lf[448]=C_h_intern(&lf[448],14,"exact->inexact");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_i_exact_to_inexact");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_divide");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_minus");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_plus");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_times");
lf[454]=C_h_intern(&lf[454],3,"lcm");
lf[455]=C_h_intern(&lf[455],3,"gcd");
lf[456]=C_h_intern(&lf[456],8,"identity");
lf[457]=C_h_intern(&lf[457],7,"\003syslcm");
lf[458]=C_h_intern(&lf[458],7,"\003sysgcd");
lf[459]=C_h_intern(&lf[459],11,"vector-set!");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_vector_set");
lf[461]=C_h_intern(&lf[461],12,"list->string");
lf[462]=C_h_intern(&lf[462],16,"\003syslist->string");
lf[463]=C_h_intern(&lf[463],12,"string->list");
lf[464]=C_h_intern(&lf[464],16,"\003sysstring->list");
lf[465]=C_h_intern(&lf[465],13,"string-append");
lf[466]=C_h_intern(&lf[466],17,"\003sysstring-append");
lf[467]=C_h_intern(&lf[467],9,"substring");
lf[468]=C_h_intern(&lf[468],13,"\003syssubstring");
lf[469]=C_h_intern(&lf[469],20,"make-record-instance");
lf[470]=C_h_intern(&lf[470],14,"\003sysblock-set!");
lf[471]=C_h_intern(&lf[471],10,"block-set!");
lf[472]=C_h_intern(&lf[472],7,"\003sysmap");
lf[473]=C_h_intern(&lf[473],8,"for-each");
lf[474]=C_h_intern(&lf[474],12,"\003sysfor-each");
lf[475]=C_h_intern(&lf[475],6,"setter");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\030C_fixnum_less_or_equal_p");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\030C_flonum_less_or_equal_p");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\033C_fixnum_greater_or_equal_p");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\033C_flonum_greater_or_equal_p");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_lessp");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000\016C_flonum_lessp");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_greaterp");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\021C_flonum_greaterp");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_equalp");
lf[486]=C_h_intern(&lf[486],14,"\003syscheck-char");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_char_2");
lf[488]=C_h_intern(&lf[488],19,"\003syscheck-structure");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_check_structure_2");
lf[490]=C_h_intern(&lf[490],16,"\003syscheck-vector");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_vector_2");
lf[492]=C_h_intern(&lf[492],21,"\003syscheck-byte-vector");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\026C_i_check_bytevector_2");
lf[494]=C_h_intern(&lf[494],16,"\003syscheck-string");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_string_2");
lf[496]=C_h_intern(&lf[496],16,"\003syscheck-symbol");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_symbol_2");
lf[498]=C_h_intern(&lf[498],18,"\003syscheck-locative");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\024C_i_check_locative_2");
lf[500]=C_h_intern(&lf[500],17,"\003syscheck-boolean");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\023C_i_check_boolean_2");
lf[502]=C_h_intern(&lf[502],14,"\003syscheck-pair");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_pair_2");
lf[504]=C_h_intern(&lf[504],14,"\003syscheck-list");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_list_2");
lf[506]=C_h_intern(&lf[506],16,"\003syscheck-number");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_number_2");
lf[508]=C_h_intern(&lf[508],15,"\003syscheck-exact");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_check_exact_2");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_check_char");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\023C_i_check_structure");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_vector");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\024C_i_check_bytevector");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_string");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_symbol");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_locative");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_check_boolean");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_check_pair");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_check_list");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_number");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_check_exact");
lf[522]=C_h_intern(&lf[522],14,"inexact->exact");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\024C_i_inexact_to_exact");
lf[524]=C_h_intern(&lf[524],13,"string-length");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_string_length");
lf[526]=C_h_intern(&lf[526],17,"\003sysvector-length");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_vector_length");
lf[528]=C_h_intern(&lf[528],13,"vector-length");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_vector_length");
lf[530]=C_h_intern(&lf[530],13,"integer->char");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\020C_make_character");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\007C_unfix");
lf[533]=C_h_intern(&lf[533],13,"char->integer");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\005C_fix");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\020C_character_code");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\005C_fix");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\015C_header_size");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\005C_fix");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\015C_header_size");
lf[540]=C_h_intern(&lf[540],9,"negative\077");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_i_negativep");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_negativep");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\016C_flonum_lessp");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_lessp");
lf[545]=C_h_intern(&lf[545],9,"positive\077");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_i_positivep");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_positivep");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\021C_flonum_greaterp");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_greaterp");
lf[550]=C_h_intern(&lf[550],5,"zero\077");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_zerop");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_zerop");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[554]=C_h_intern(&lf[554],4,"atan");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_atan2");
lf[556]=C_h_intern(&lf[556],4,"sqrt");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_sqrt");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_atan");
lf[559]=C_h_intern(&lf[559],4,"acos");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_acos");
lf[561]=C_h_intern(&lf[561],4,"asin");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_asin");
lf[563]=C_h_intern(&lf[563],3,"log");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_log");
lf[565]=C_h_intern(&lf[565],3,"tan");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_tan");
lf[567]=C_h_intern(&lf[567],3,"cos");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_cos");
lf[569]=C_h_intern(&lf[569],3,"sin");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_sin");
lf[571]=C_h_intern(&lf[571],3,"exp");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_exp");
lf[573]=C_h_intern(&lf[573],5,"fpneg");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_i_flonum_negate");
lf[575]=C_h_intern(&lf[575],4,"fp/\077");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\035C_a_i_flonum_quotient_checked");
lf[577]=C_h_intern(&lf[577],3,"fp/");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_i_flonum_quotient");
lf[579]=C_h_intern(&lf[579],3,"fp\052");
lf[580]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_times");
lf[581]=C_h_intern(&lf[581],3,"fp-");
lf[582]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_i_flonum_difference");
lf[583]=C_h_intern(&lf[583],3,"fp+");
lf[584]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_plus");
lf[585]=C_h_intern(&lf[585],11,"bitwise-not");
lf[586]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_not");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_not");
lf[588]=C_h_intern(&lf[588],11,"bitwise-ior");
lf[589]=C_decode_literal(C_heaptop,"\376B\000\000\013C_fixnum_or");
lf[590]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_fixnum_or");
lf[591]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_ior");
lf[592]=C_h_intern(&lf[592],11,"bitwise-and");
lf[593]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_and");
lf[594]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_fixnum_and");
lf[595]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_and");
lf[596]=C_h_intern(&lf[596],11,"bitwise-xor");
lf[597]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[598]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[599]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_xor");
lf[600]=C_h_intern(&lf[600],3,"abs");
lf[601]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_abs");
lf[602]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_abs");
lf[603]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_abs");
lf[604]=C_h_intern(&lf[604],8,"set-cdr!");
lf[605]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_set_cdr");
lf[606]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_i_set_cdr");
lf[607]=C_h_intern(&lf[607],8,"set-car!");
lf[608]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_set_car");
lf[609]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_i_set_car");
lf[610]=C_h_intern(&lf[610],6,"member");
lf[611]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_member");
lf[612]=C_h_intern(&lf[612],5,"assoc");
lf[613]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_assoc");
lf[614]=C_h_intern(&lf[614],4,"memq");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_memq");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_memq");
lf[617]=C_h_intern(&lf[617],4,"assq");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_assq");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_assq");
lf[620]=C_h_intern(&lf[620],4,"memv");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_memv");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_memq");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_memq");
lf[624]=C_h_intern(&lf[624],4,"assv");
lf[625]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_assv");
lf[626]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_assq");
lf[627]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_assq");
lf[628]=C_h_intern(&lf[628],15,"number-of-slots");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\014C_block_size");
lf[630]=C_h_intern(&lf[630],9,"block-ref");
lf[631]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[632]=C_h_intern(&lf[632],15,"\003sysbytevector\077");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\015C_bytevectorp");
lf[634]=C_h_intern(&lf[634],14,"\003sysstructure\077");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_structurep");
lf[636]=C_h_intern(&lf[636],9,"list-tail");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_list_tail");
lf[638]=C_h_intern(&lf[638],13,"char-downcase");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_char_downcase");
lf[640]=C_h_intern(&lf[640],11,"char-upcase");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_i_char_upcase");
lf[642]=C_h_intern(&lf[642],16,"char-lower-case\077");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_lower_casep");
lf[644]=C_h_intern(&lf[644],16,"char-upper-case\077");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_upper_casep");
lf[646]=C_h_intern(&lf[646],16,"char-whitespace\077");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_whitespacep");
lf[648]=C_h_intern(&lf[648],16,"char-alphabetic\077");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_alphabeticp");
lf[650]=C_h_intern(&lf[650],13,"char-numeric\077");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_char_numericp");
lf[652]=C_h_intern(&lf[652],5,"fpmin");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_flonum_min");
lf[654]=C_h_intern(&lf[654],5,"fpmax");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_flonum_max");
lf[656]=C_h_intern(&lf[656],5,"fxmin");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnum_min");
lf[658]=C_h_intern(&lf[658],5,"fxmax");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnum_max");
lf[660]=C_h_intern(&lf[660],4,"fp<=");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\030C_flonum_less_or_equal_p");
lf[662]=C_h_intern(&lf[662],4,"fp>=");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\033C_flonum_greater_or_equal_p");
lf[664]=C_h_intern(&lf[664],3,"fp<");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\016C_flonum_lessp");
lf[666]=C_h_intern(&lf[666],3,"fp>");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\021C_flonum_greaterp");
lf[668]=C_h_intern(&lf[668],3,"fp=");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\017C_flonum_equalp");
lf[670]=C_h_intern(&lf[670],4,"fx<=");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\030C_fixnum_less_or_equal_p");
lf[672]=C_h_intern(&lf[672],4,"fx>=");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\033C_fixnum_greater_or_equal_p");
lf[674]=C_h_intern(&lf[674],3,"fx<");
lf[675]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_lessp");
lf[676]=C_h_intern(&lf[676],3,"fx>");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_greaterp");
lf[678]=C_h_intern(&lf[678],3,"fx=");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[680]=C_h_intern(&lf[680],4,"fx/\077");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_o_fixnum_quotient");
lf[682]=C_h_intern(&lf[682],4,"fx\052\077");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_o_fixnum_times");
lf[684]=C_h_intern(&lf[684],4,"fx-\077");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\027C_i_o_fixnum_difference");
lf[686]=C_h_intern(&lf[686],4,"fx+\077");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_o_fixnum_plus");
lf[688]=C_h_intern(&lf[688],3,"fx\052");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_times");
lf[690]=C_h_intern(&lf[690],5,"fxnot");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_not");
lf[692]=C_h_intern(&lf[692],8,"\003syssize");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\014C_block_size");
lf[694]=C_h_intern(&lf[694],13,"\003sysblock-ref");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_block_ref");
lf[696]=C_h_intern(&lf[696],8,"\003sysslot");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[698]=C_h_intern(&lf[698],7,"char<=\077");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\030C_i_char_less_or_equal_p");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\032C_u_i_char_less_or_equal_p");
lf[701]=C_h_intern(&lf[701],7,"char>=\077");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\033C_i_char_greater_or_equal_p");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\035C_u_i_char_greater_or_equal_p");
lf[704]=C_h_intern(&lf[704],6,"char<\077");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_char_lessp");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\020C_u_i_char_lessp");
lf[707]=C_h_intern(&lf[707],6,"char>\077");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_char_greaterp");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_char_greaterp");
lf[710]=C_h_intern(&lf[710],6,"char=\077");
lf[711]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_char_equalp");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_i_char_equalp");
lf[713]=C_h_intern(&lf[713],10,"vector-ref");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_vector_ref");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[716]=C_h_intern(&lf[716],11,"string-set!");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_string_set");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\014C_setsubchar");
lf[719]=C_h_intern(&lf[719],10,"string-ref");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_string_ref");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\011C_subchar");
lf[722]=C_h_intern(&lf[722],11,"eof-object\077");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\006C_eofp");
lf[724]=C_h_intern(&lf[724],12,"proper-list\077");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_listp");
lf[726]=C_h_intern(&lf[726],5,"list\077");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_listp");
lf[728]=C_h_intern(&lf[728],8,"inexact\077");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_i_inexactp");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_inexactp");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\012C_nfixnump");
lf[732]=C_h_intern(&lf[732],6,"exact\077");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_exactp");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_exactp");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\011C_fixnump");
lf[736]=C_h_intern(&lf[736],22,"\003sysgeneric-structure\077");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\014C_structurep");
lf[738]=C_h_intern(&lf[738],8,"pointer\077");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_safe_pointerp");
lf[740]=C_h_intern(&lf[740],12,"\003syspointer\077");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\015C_anypointerp");
lf[742]=C_h_intern(&lf[742],10,"fpinteger\077");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\020C_u_i_fpintegerp");
lf[744]=C_h_intern(&lf[744],7,"finite\077");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_finitep");
lf[746]=C_h_intern(&lf[746],7,"fixnum\077");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\011C_fixnump");
lf[748]=C_h_intern(&lf[748],7,"flonum\077");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_flonump");
lf[750]=C_h_intern(&lf[750],8,"integer\077");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_integerp");
lf[752]=C_h_intern(&lf[752],5,"real\077");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_numberp");
lf[754]=C_h_intern(&lf[754],9,"rational\077");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_rationalp");
lf[756]=C_h_intern(&lf[756],8,"complex\077");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_numberp");
lf[758]=C_h_intern(&lf[758],7,"number\077");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_numberp");
lf[760]=C_h_intern(&lf[760],8,"boolean\077");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\012C_booleanp");
lf[762]=C_h_intern(&lf[762],5,"port\077");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_portp");
lf[764]=C_h_intern(&lf[764],10,"procedure\077");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_closurep");
lf[766]=C_h_intern(&lf[766],9,"\003syspair\077");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_pairp");
lf[768]=C_h_intern(&lf[768],5,"pair\077");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_pairp");
lf[770]=C_h_intern(&lf[770],11,"\003sysvector\077");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_vectorp");
lf[772]=C_h_intern(&lf[772],7,"vector\077");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_vectorp");
lf[774]=C_h_intern(&lf[774],7,"symbol\077");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_symbolp");
lf[776]=C_h_intern(&lf[776],9,"locative\077");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_locativep");
lf[778]=C_h_intern(&lf[778],7,"string\077");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_stringp");
lf[780]=C_h_intern(&lf[780],5,"char\077");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\007C_charp");
lf[782]=C_h_intern(&lf[782],3,"not");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_not");
lf[784]=C_h_intern(&lf[784],6,"length");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_length");
lf[786]=C_h_intern(&lf[786],9,"\003sysnull\077");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_nullp");
lf[788]=C_h_intern(&lf[788],5,"null\077");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_nullp");
lf[790]=C_h_intern(&lf[790],8,"list-ref");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_list_ref");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_i_list_ref");
lf[793]=C_h_intern(&lf[793],8,"\003syseqv\077");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_eqvp");
lf[795]=C_h_intern(&lf[795],4,"eqv\077");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_eqvp");
lf[797]=C_h_intern(&lf[797],7,"\003syseq\077");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[799]=C_h_intern(&lf[799],3,"eq\077");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[801]=C_h_intern(&lf[801],3,"cdr");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_cdr");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[804]=C_h_intern(&lf[804],6,"cddddr");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_cddddr");
lf[806]=C_h_intern(&lf[806],5,"cdddr");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_cdddr");
lf[808]=C_h_intern(&lf[808],4,"cddr");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cddr");
lf[810]=C_h_intern(&lf[810],4,"cdar");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cdar");
lf[812]=C_h_intern(&lf[812],4,"caar");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_caar");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cddddr");
lf[815]=C_h_intern(&lf[815],6,"cdddar");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdddar");
lf[817]=C_h_intern(&lf[817],6,"cddadr");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cddadr");
lf[819]=C_h_intern(&lf[819],6,"cddaar");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cddaar");
lf[821]=C_h_intern(&lf[821],6,"cdaddr");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdaddr");
lf[823]=C_h_intern(&lf[823],6,"cdadar");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdadar");
lf[825]=C_h_intern(&lf[825],6,"cdaadr");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdaadr");
lf[827]=C_h_intern(&lf[827],6,"cdaaar");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdaaar");
lf[829]=C_h_intern(&lf[829],6,"cadddr");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadddr");
lf[831]=C_h_intern(&lf[831],6,"caddar");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caddar");
lf[833]=C_h_intern(&lf[833],6,"cadadr");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadadr");
lf[835]=C_h_intern(&lf[835],6,"cadaar");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadaar");
lf[837]=C_h_intern(&lf[837],6,"caaddr");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caaddr");
lf[839]=C_h_intern(&lf[839],6,"caadar");
lf[840]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caadar");
lf[841]=C_h_intern(&lf[841],6,"caaaar");
lf[842]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caaaar");
lf[843]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cdddr");
lf[844]=C_h_intern(&lf[844],5,"cddar");
lf[845]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cddar");
lf[846]=C_h_intern(&lf[846],5,"cdadr");
lf[847]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cdadr");
lf[848]=C_h_intern(&lf[848],5,"cdaar");
lf[849]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cdaar");
lf[850]=C_h_intern(&lf[850],5,"caddr");
lf[851]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caddr");
lf[852]=C_h_intern(&lf[852],5,"cadar");
lf[853]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cadar");
lf[854]=C_h_intern(&lf[854],5,"caaar");
lf[855]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caaar");
lf[856]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cddr");
lf[857]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cdar");
lf[858]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_caar");
lf[859]=C_h_intern(&lf[859],22,"\003syscontinuation-graft");
lf[860]=C_decode_literal(C_heaptop,"\376B\000\000\024C_continuation_graft");
lf[861]=C_h_intern(&lf[861],12,"locative-ref");
lf[862]=C_decode_literal(C_heaptop,"\376B\000\000\016C_locative_ref");
lf[863]=C_h_intern(&lf[863],20,"\003syscall-with-values");
lf[864]=C_decode_literal(C_heaptop,"\376B\000\000\022C_call_with_values");
lf[865]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_call_with_values");
lf[866]=C_h_intern(&lf[866],16,"call-with-values");
lf[867]=C_decode_literal(C_heaptop,"\376B\000\000\022C_call_with_values");
lf[868]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_call_with_values");
lf[869]=C_decode_literal(C_heaptop,"\376B\000\000\010C_values");
lf[870]=C_decode_literal(C_heaptop,"\376B\000\000\010C_values");
lf[871]=C_h_intern(&lf[871],6,"fourth");
lf[872]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_cadddr");
lf[873]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadddr");
lf[874]=C_h_intern(&lf[874],5,"third");
lf[875]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_caddr");
lf[876]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caddr");
lf[877]=C_h_intern(&lf[877],6,"second");
lf[878]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cadr");
lf[879]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cadr");
lf[880]=C_h_intern(&lf[880],5,"first");
lf[881]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_car");
lf[882]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_car");
lf[883]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_cadddr");
lf[884]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadddr");
lf[885]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_caddr");
lf[886]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caddr");
lf[887]=C_h_intern(&lf[887],4,"cadr");
lf[888]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cadr");
lf[889]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cadr");
lf[890]=C_h_intern(&lf[890],7,"\003syscdr");
lf[891]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_cdr");
lf[892]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_cdr");
lf[893]=C_h_intern(&lf[893],7,"\003syscar");
lf[894]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_car");
lf[895]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_car");
lf[896]=C_h_intern(&lf[896],3,"car");
lf[897]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_car");
lf[898]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_car");
lf[899]=C_h_intern(&lf[899],9,"\003sysapply");
lf[900]=C_h_intern(&lf[900],5,"apply");
lf[901]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_i_equalp\376\377\016");
lf[902]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_eqp\376\377\016");
lf[903]=C_h_intern(&lf[903],6,"equal\077");
lf[904]=C_h_intern(&lf[904],4,"sub1");
lf[905]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_decrease");
lf[906]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_fixnum_decrease");
lf[907]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_minus");
lf[908]=C_h_intern(&lf[908],4,"add1");
lf[909]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_increase");
lf[910]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_fixnum_increase");
lf[911]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_plus");
lf[912]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016");
lf[913]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\017C_fixnum_divide\376\377\016");
lf[914]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_quotient\376\003\000\000\002\376\377\006\001\376\377\016");
lf[915]=C_h_intern(&lf[915],8,"quotient");
lf[916]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016");
lf[917]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\017C_fixnum_divide\376\377\016");
lf[918]=C_h_intern(&lf[918],19,"\010compilerfold-inner");
lf[919]=C_h_intern(&lf[919],6,"remove");
lf[920]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021C_u_fixnum_negate\376\377\016");
lf[921]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\017C_fixnum_negate\376\377\016");
lf[922]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\025C_u_fixnum_difference\376\377\016");
lf[923]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\023C_fixnum_difference\376\377\016");
lf[924]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\023C_fixnum_shift_left\376\377\016");
lf[925]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016C_fixnum_times\376\377\016");
lf[926]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fixnum_plus");
lf[927]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_fixnum_plus");
lf[928]=C_h_intern(&lf[928],8,"\003sysput!");
lf[929]=C_h_intern(&lf[929],13,"\010compilerpure");
lf[930]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysslot\376\003\000\000\002\376\001\000\000\015\003sysblock-ref\376\003\000\000\002\376\001\000\000\010\003syssize\376\003\000\000\002\376\001\000\000\010\003sysbyte\376\003\000"
"\000\002\376\001\000\000\014\003syspointer\077\376\003\000\000\002\376\001\000\000\026\003sysgeneric-structure\077\376\003\000\000\002\376\001\000\000\020\003sysfits-in-int\077\376\003\000"
"\000\002\376\001\000\000\031\003sysfits-in-unsigned-int\077\376\003\000\000\002\376\001\000\000\033\003sysflonum-in-fixnum-range\077\376\003\000\000\002\376\001\000\000\011\003"
"sysfudge\376\003\000\000\002\376\001\000\000\016\003sysimmediate\077\376\003\000\000\002\376\001\000\000\017\003sysbytevector\077\376\003\000\000\002\376\001\000\000\011\003syspair\077\376\003\000\000"
"\002\376\001\000\000\007\003syseq\077\376\003\000\000\002\376\001\000\000\011\003syslist\077\376\003\000\000\002\376\001\000\000\013\003sysvector\077\376\003\000\000\002\376\001\000\000\010\003syseqv\077\376\003\000\000\002\376\001\000\000"
"\017\003sysget-keyword\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\016\003syspermanent\077\376\377\016");
lf[931]=C_h_intern(&lf[931],15,"lset-difference");
lf[932]=C_h_intern(&lf[932],10,"lset-union");
C_register_lf2(lf,933,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1607,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in ... */
static void C_ccall f_2923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2923,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:655: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[652];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[653];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in ... */
static void C_ccall f_2920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2920,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:654: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[654];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[655];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_3655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3655,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:996: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[175];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[176];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_3658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3658,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:997: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[173];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[174];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in ... */
static void C_ccall f_2977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2977,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:674: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[614];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[615];
av2[6]=lf[616];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_3652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3652,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:995: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[177];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[178];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in ... */
static void C_ccall f_2971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2971,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:672: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[620];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[621];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in ... */
static void C_ccall f_2974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2974,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:673: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[617];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[618];
av2[6]=lf[619];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in ... */
static void C_ccall f_2989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_2989,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:679: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[604];
av2[3]=C_fix(4);
av2[4]=lf[294];
av2[5]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in ... */
static void C_ccall f_2986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_2986,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:678: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[607];
av2[3]=C_fix(4);
av2[4]=lf[294];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k2069 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_2071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_2071,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_record4(&a,4,lf[35],lf[47],lf[48],C_SCHEME_END_OF_LIST);
/* c-platform.scm:455: cons* */
t6=*((C_word*)lf[43]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* k5170 in k5248 in a5129 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5172,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1743 */
static void C_ccall f_1745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_1745,2,av);}
a=C_alloc(22);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[35],lf[38],((C_word*)t0)[3],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[6],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* a5173 in k5248 in a5129 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5174,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5181,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t3;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(lf[41],t6);
if(C_truep(t7)){
t8=t3;
t9=C_slot(t8,C_fix(2));
t10=C_i_car(t9);
t11=t4;
f_5181(t11,C_eqp(C_fix(2),t10));}
else{
t8=t4;
f_5181(t8,C_SCHEME_FALSE);}}

/* k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in ... */
static void C_ccall f_2980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2980,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:675: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[612];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[613];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in ... */
static void C_ccall f_2983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2983,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:676: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[610];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[611];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in ... */
static void C_ccall f_2956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2956,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:666: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[630];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[631];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in ... */
static void C_ccall f_2959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2959,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:667: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[628];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[629];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* a4236 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in ... */
static void C_ccall f_4237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_4237,6,av);}
a=C_alloc(22);
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=C_eqp(*((C_word*)lf[33]+1),lf[32]);
t10=(C_truep(t9)?C_a_i_list1(&a,1,lf[100]):C_a_i_list1(&a,1,lf[101]));
t11=t5;
t12=C_a_i_record4(&a,4,lf[35],lf[36],t10,t11);
t13=C_a_i_list2(&a,2,t4,t12);
t14=t1;
t15=t14;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t8,t13);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2046 in map-loop433 in k2066 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2048,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2023(t6,((C_word*)t0)[5],t5);}

/* k4656 in a4615 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in ... */
static void C_ccall f_4658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,1))){C_save_and_reclaim((void *)f_4658,2,av);}
a=C_alloc(16);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[35],lf[36],lf[291],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[35],lf[36],lf[292],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k5179 in a5173 in k5248 in a5129 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_5181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_5181,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:334: qnode */
t3=*((C_word*)lf[39]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[36],lf[917],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3768 in k3753 in rewrite-make-vector in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in ... */
static void C_ccall f_3770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,3))){C_save_and_reclaim((void *)f_3770,2,av);}
a=C_alloc(32);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_pairp(t3);
t5=(C_truep(t4)?C_i_cadr(((C_word*)t0)[2]):C_a_i_record4(&a,4,lf[35],lf[68],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));
t6=t5;
t7=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t8=t7;
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t10=t9;
t11=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t12=C_a_i_list2(&a,2,lf[69],t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3823,a[2]=t13,a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1051: list-tabulate */
t16=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t16;
av2[1]=t14;
av2[2]=((C_word*)t0)[4];
av2[3]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t2=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in ... */
static void C_ccall f_2950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2950,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:664: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[634];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[635];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in ... */
static void C_ccall f_2953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2953,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:665: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[632];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[633];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in ... */
static void C_ccall f_2968(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_2968,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:671: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[620];
av2[3]=C_fix(14);
av2[4]=lf[32];
av2[5]=C_fix(2);
av2[6]=lf[622];
av2[7]=lf[623];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2088 in k2069 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_2090,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5195 in k5179 in a5173 in k5248 in a5129 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5197(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5197,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[36],lf[916],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in ... */
static void C_ccall f_2962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_2962,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:669: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[624];
av2[3]=C_fix(14);
av2[4]=lf[32];
av2[5]=C_fix(2);
av2[6]=lf[626];
av2[7]=lf[627];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in ... */
static void C_ccall f_2965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2965,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:670: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[624];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[625];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3753 in rewrite-make-vector in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in ... */
static void C_ccall f_3755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3755,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_slot(((C_word*)t0)[2],C_fix(2));
t4=C_i_car(t3);
t5=t4;
if(C_truep(C_fixnump(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1037: <= */{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=C_fix(0);
av2[3]=t5;
av2[4]=C_fix(32);
C_less_or_equal_p(5,av2);}}
else{
t6=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k2066 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_2068,2,av);}
a=C_alloc(17);
t2=C_i_cdr(t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[39]+1);
t9=C_slot(((C_word*)t0)[2],C_fix(2));
t10=C_i_car(t9);
t11=C_i_check_list_2(t10,lf[44]);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2023,a[2]=t6,a[3]=t14,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_2023(t16,t12,t10);}

/* k4537 in a4458 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in ... */
static void C_fcall f_4539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_4539,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
if(C_truep(C_i_negativep(((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4563,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4567,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:944: - */{
C_word av2[3];
av2[0]=0;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
C_minus(3,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,t3,((C_word*)t0)[5]);
t5=((C_word*)t0)[4];
f_4489(t5,C_a_i_record4(&a,4,lf[35],lf[36],lf[260],t4));}}
else{
t2=((C_word*)t0)[4];
f_4489(t2,C_SCHEME_FALSE);}}

/* k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_3664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3664,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:999: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[169];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[170];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_3667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3667,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1000: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[167];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[168];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_3661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3661,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:998: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[171];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[172];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4783 in a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_4785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_4785,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[6],C_fix(1));
t5=C_eqp(lf[41],t4);
if(C_truep(t5)){
t6=C_slot(((C_word*)t0)[6],C_fix(2));
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4895,a[2]=t3,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:417: immediate? */
t10=*((C_word*)lf[293]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t6=t3;
f_4822(t6,C_SCHEME_FALSE);}}}

/* k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_3676(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3676,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1004: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[161];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[162];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in ... */
static void C_ccall f_2998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_2998,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:683: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[600];
av2[3]=C_fix(14);
av2[4]=lf[32];
av2[5]=C_fix(1);
av2[6]=lf[602];
av2[7]=lf[603];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_3679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3679,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1005: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[159];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[160];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_3670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3670,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1001: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[165];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[166];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_3673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3673,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1002: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[163];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[164];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in ... */
static void C_ccall f_2995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2995,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:681: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[604];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[605];
av2[6]=lf[606];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in ... */
static void C_ccall f_2992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2992,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:680: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[607];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[608];
av2[6]=lf[609];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5001 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5003,2,av);}
/* c-platform.scm:378: rewrite */
t2=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[908];
av2[3]=C_fix(8);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a5004 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_5005,6,av);}
a=C_alloc(12);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=C_eqp(lf[32],*((C_word*)lf[33]+1));
if(C_truep(t8)){
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t10=t9;
t11=C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5044,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t13=C_slot(t11,C_fix(1));
t14=C_eqp(lf[41],t13);
if(C_truep(t14)){
t15=C_slot(t11,C_fix(2));
t16=C_i_car(t15);
t17=t12;
f_5044(t17,C_eqp(C_fix(2),t16));}
else{
t15=t12;
f_5044(t15,C_SCHEME_FALSE);}}
else{
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5114,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=C_a_i_record4(&a,4,lf[35],lf[47],lf[914],C_SCHEME_END_OF_LIST);
/* c-platform.scm:358: cons* */
t13=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t13;
av2[1]=t11;
av2[2]=t12;
av2[3]=t4;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f_2710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2710,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:584: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[782];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[783];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in ... */
static void C_ccall f_2707(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2707,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:583: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[784];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[785];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in ... */
static void C_ccall f_2704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2704,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:582: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[786];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[787];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1753,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:379: op1 */
f_1673(t3,lf[905],lf[906],lf[907]);}

/* k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_1756,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1758,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:399: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[795];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* eqv?-id in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_1758,6,av);}
a=C_alloc(15);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_i_cadr(t5);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1774,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t11,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t13=C_slot(t9,C_fix(1));
t14=C_eqp(lf[42],t13);
if(C_truep(t14)){
t15=C_slot(t11,C_fix(1));
t16=C_eqp(lf[42],t15);
if(C_truep(t16)){
t17=C_slot(t9,C_fix(2));
t18=C_slot(t11,C_fix(2));
if(C_truep(C_i_equalp(t17,t18))){
t19=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t20=t19;
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1913,a[2]=t4,a[3]=t12,a[4]=t20,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:391: qnode */
t22=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t22;
av2[1]=t21;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t22+1)))(3,av2);}}
else{
t19=t12;
f_1774(t19,C_SCHEME_FALSE);}}
else{
t17=t12;
f_1774(t17,C_SCHEME_FALSE);}}
else{
t15=t12;
f_1774(t15,C_SCHEME_FALSE);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in ... */
static void C_ccall f_2719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2719,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:587: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[776];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[777];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in ... */
static void C_ccall f_2713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2713,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:585: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[780];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[781];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in ... */
static void C_ccall f_2716(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2716,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:586: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[778];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[779];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in ... */
static void C_ccall f_3592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3592,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:970: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[219];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[220];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in ... */
static void C_ccall f_3709(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3709,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1017: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[138];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[139];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in ... */
static void C_ccall f_3706(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3706,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1015: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[140];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[141];
av2[6]=lf[142];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in ... */
static void C_ccall f_3703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3703,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1014: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[143];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[144];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in ... */
static void C_ccall f_3700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3700,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1013: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[145];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[146];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in ... */
static void C_ccall f_3589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3589,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:969: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[221];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[222];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in ... */
static void C_ccall f_3586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3586,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:968: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[223];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[224];
av2[6]=lf[225];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in ... */
static void C_ccall f_3583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3583,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:967: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[226];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[227];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in ... */
static void C_ccall f_3286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3286,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:794: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[435];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[444];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in ... */
static void C_ccall f_3289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3289,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:795: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[433];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[443];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in ... */
static void C_ccall f_3598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3598,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:972: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[215];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[216];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in ... */
static void C_ccall f_3595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3595,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:971: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[217];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[218];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3898 in rewrite-call/cc in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in ... */
static void C_ccall f_3900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_3900,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_slot(t1,C_fix(1));
t3=C_eqp(lf[57],t2);
if(C_truep(t3)){
t4=C_slot(t1,C_fix(2));
t5=C_i_caddr(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3917,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1067: decompose-lambda-list */
t8=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=((C_word*)t0)[5];
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in ... */
static void C_ccall f_3283(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3283,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:793: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[437];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[445];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in ... */
static void C_ccall f_3280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3280,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:792: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[439];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[446];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in ... */
static void C_ccall f_3727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3727,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1023: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[126];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[127];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in ... */
static void C_ccall f_3724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3724,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1022: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[128];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[129];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in ... */
static void C_ccall f_3721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3721,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1021: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[130];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[131];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in ... */
static void C_ccall f_3295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3295,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:798: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[439];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[440];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in ... */
static void C_ccall f_3298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3298,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:799: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[437];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[438];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in ... */
static void C_ccall f_3292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3292,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:797: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[441];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[442];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in ... */
static void C_ccall f_3715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3715,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1019: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[134];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[135];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in ... */
static void C_ccall f_3718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3718,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1020: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[132];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[133];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in ... */
static void C_ccall f_3712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3712,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1018: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[136];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[137];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in ... */
static void C_ccall f_3268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3268,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:787: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[423];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[451];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(4);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in ... */
static void C_ccall f_3265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3265,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:786: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[452];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(4);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in ... */
static void C_ccall f_3262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3262,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:785: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[431];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[453];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(4);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2125 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_2127,2,av);}
a=C_alloc(22);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_a_i_record4(&a,4,lf[35],lf[47],lf[51],C_SCHEME_END_OF_LIST);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list3(&a,3,t3,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
f_2071(t6,C_a_i_record4(&a,4,lf[35],lf[37],t2,t5));}
else{
t2=((C_word*)t0)[4];
f_2071(t2,C_SCHEME_FALSE);}}

/* k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in ... */
static void C_ccall f_2701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2701,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:581: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[788];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[789];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in ... */
static void C_ccall f_3277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3277,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:791: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[441];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[447];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in ... */
static void C_ccall f_3274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3274,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:789: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[448];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[449];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(4);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in ... */
static void C_ccall f_3271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3271,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:788: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[426];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[450];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(4);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* a3916 in k3898 in rewrite-call/cc in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in ... */
static void C_ccall f_3917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3917,5,av);}
a=C_alloc(7);
if(C_truep(C_i_nequalp(t3,C_fix(2)))){
t5=(C_truep(t4)?t4:C_i_cadr(((C_word*)t0)[2]));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3977,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1072: get */
t8=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[5];
av2[3]=t6;
av2[4]=lf[73];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* rewrite-make-vector in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in ... */
static void C_ccall f_3735(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3735,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
if(C_truep(C_i_pairp(t5))){
t7=t5;
t8=C_u_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[41],t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3755,a[2]=t8,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1034: gensym */
t12=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t11=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in ... */
static void C_ccall f_3733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_3733,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3735,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1052: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[123];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in ... */
static void C_ccall f_3730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3730,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1024: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[124];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[125];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in ... */
static void C_ccall f_3247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3247,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:778: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[454];
av2[3]=C_fix(12);
av2[4]=lf[457];
av2[5]=C_SCHEME_TRUE;
av2[6]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in ... */
static void C_ccall f_2791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2791,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:611: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[728];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[731];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in ... */
static void C_ccall f_2794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2794,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:612: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[728];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[730];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in ... */
static void C_ccall f_3244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3244,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:777: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[455];
av2[3]=C_fix(12);
av2[4]=lf[458];
av2[5]=C_SCHEME_TRUE;
av2[6]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in ... */
static void C_ccall f_3241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3241,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:775: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[459];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[460];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in ... */
static void C_ccall f_2785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2785,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:609: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[732];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[734];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in ... */
static void C_ccall f_2788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2788,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:610: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[732];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[733];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* a5371 in k5398 in a5292 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5372(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5372,4,av);}
a=C_alloc(11);
t4=(C_truep(*((C_word*)lf[34]+1))?lf[922]:lf[923]);
t5=C_a_i_list2(&a,2,t2,t3);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[36],t4,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k5368 in k5398 in a5292 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5370,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in ... */
static void C_ccall f_3259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_3259,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:783: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[344];
av2[3]=C_fix(18);
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in ... */
static void C_ccall f_2764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2764,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:602: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[746];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[747];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in ... */
static void C_ccall f_3253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_3253,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:781: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[455];
av2[3]=C_fix(18);
av2[4]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in ... */
static void C_ccall f_2761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2761,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:601: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[748];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[749];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in ... */
static void C_ccall f_3256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_3256,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:782: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[454];
av2[3]=C_fix(18);
av2[4]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in ... */
static void C_ccall f_3250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3250,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:779: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[456];
av2[3]=C_fix(12);
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_TRUE;
av2[6]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in ... */
static void C_ccall f_2797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2797,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:613: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[728];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[729];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in ... */
static void C_ccall f_2773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2773,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:605: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[740];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[741];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in ... */
static void C_ccall f_2770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2770,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:604: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[742];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[743];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in ... */
static void C_ccall f_3148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3148,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:741: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[490];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[512];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in ... */
static void C_ccall f_3145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3145,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:740: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[492];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[513];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in ... */
static void C_ccall f_3439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3439,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:871: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[337];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[338];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in ... */
static void C_ccall f_3433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3433,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:869: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[341];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[342];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[343];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in ... */
static void C_ccall f_3436(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3436,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:870: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[339];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[340];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
av2[8]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in ... */
static void C_ccall f_2767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2767,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:603: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[744];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[745];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in ... */
static void C_ccall f_3430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3430,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:868: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[344];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[345];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[346];
av2[8]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in ... */
static void C_ccall f_3448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3448,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:874: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[331];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[332];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in ... */
static void C_ccall f_3445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3445,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:873: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[333];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[334];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in ... */
static void C_ccall f_2779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2779,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:607: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[736];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[737];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in ... */
static void C_ccall f_2776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2776,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:606: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[738];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[739];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* for-each-loop42 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_5633(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_5633,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5643,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[928]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[929];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t6=C_i_car(t5);
/* tweaks.scm:54: ##sys#put! */
t7=*((C_word*)lf[928]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[929];
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in ... */
static void C_ccall f_3442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3442,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:872: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[335];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[336];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
av2[8]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k5398 in a5292 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_5400,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_eqp(*((C_word*)lf[33]+1),lf[32]);
if(C_truep(t3)){
t4=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5372,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:304: fold-inner */
t9=*((C_word*)lf[918]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in ... */
static void C_ccall f_2752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2752,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:598: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[754];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[755];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in ... */
static void C_ccall f_2755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2755,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:599: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[752];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[753];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* a5401 in a5292 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5402,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[41],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_i_zerop(t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in ... */
static void C_ccall f_3496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3496,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:892: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[299];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[300];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in ... */
static void C_ccall f_2746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2746,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:596: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[758];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[759];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in ... */
static void C_ccall f_3499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3499,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:893: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[297];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[298];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in ... */
static void C_ccall f_2749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2749,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2752,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:597: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[756];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[757];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in ... */
static void C_ccall f_3493(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3493,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:891: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[301];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[302];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in ... */
static void C_ccall f_3490(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3490,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:889: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[303];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[304];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in ... */
static void C_ccall f_2725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2725,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:589: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[772];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[773];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in ... */
static void C_ccall f_2722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2722,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:588: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[774];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[775];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in ... */
static void C_ccall f_2758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2758,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:600: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[750];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[751];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in ... */
static void C_ccall f_2731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2731,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:591: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[768];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[769];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in ... */
static void C_ccall f_2734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2734,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:592: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[766];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[767];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in ... */
static void C_ccall f_3475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3475,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:884: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[313];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[314];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in ... */
static void C_ccall f_3478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3478,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:885: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[311];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[312];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in ... */
static void C_ccall f_2728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2728,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:590: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[770];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[771];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in ... */
static void C_ccall f_3328(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3328,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:811: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[414];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[415];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in ... */
static void C_ccall f_3325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3325,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:810: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[416];
av2[3]=C_fix(13);
av2[4]=C_fix(4);
av2[5]=lf[417];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in ... */
static void C_ccall f_3322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3322,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:809: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[418];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[419];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in ... */
static void C_ccall f_3472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3472,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:883: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[315];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[316];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in ... */
static void C_ccall f_2782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2782,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:608: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[732];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[735];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3971 in k3975 in a3916 in k3898 in rewrite-call/cc in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in ... */
static void C_ccall f_3973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3973,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1074: get */
t3=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=lf[71];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in ... */
static void C_ccall f_3484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3484,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:887: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[307];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[308];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in ... */
static void C_ccall f_3487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3487,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:888: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[305];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[306];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in ... */
static void C_ccall f_2737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2737,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:593: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[764];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[765];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in ... */
static void C_ccall f_3319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3319,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:808: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[420];
av2[3]=C_fix(13);
av2[4]=lf[421];
av2[5]=lf[422];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in ... */
static void C_ccall f_3316(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3316,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:806: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[423];
av2[3]=C_fix(13);
av2[4]=lf[424];
av2[5]=lf[425];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in ... */
static void C_ccall f_3310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3310,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:804: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[430];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in ... */
static void C_ccall f_3313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3313,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:805: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[426];
av2[3]=C_fix(13);
av2[4]=lf[427];
av2[5]=lf[428];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in ... */
static void C_ccall f_3481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3481,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:886: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[309];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[310];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3975 in a3916 in k3898 in rewrite-call/cc in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in ... */
static void C_ccall f_3977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3977,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1073: get */
t3=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=lf[72];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* a3824 in k3768 in k3753 in rewrite-make-vector in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in ... */
static void C_ccall f_3825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3825,3,av);}
/* c-platform.scm:1051: varnode */
t3=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3821 in k3768 in k3753 in rewrite-make-vector in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in ... */
static void C_ccall f_3823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,1))){C_save_and_reclaim((void *)f_3823,2,av);}
a=C_alloc(27);
t2=C_a_i_record4(&a,4,lf[35],lf[38],((C_word*)t0)[2],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[5],t4);
t6=((C_word*)t0)[6];
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[58],((C_word*)t0)[7],t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in ... */
static void C_ccall f_2740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2740,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:594: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[762];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[763];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in ... */
static void C_ccall f_2743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2743,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:595: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[760];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[761];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4160 in k4102 in a4093 in k4087 in k4084 in k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in ... */
static void C_ccall f_4162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,1))){C_save_and_reclaim((void *)f_4162,2,av);}
a=C_alloc(33);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[35],lf[38],lf[75],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[5],t5);
t7=((C_word*)t0)[6];
t8=t7;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[58],((C_word*)t0)[7],t6);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* a4168 in k4084 in k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in ... */
static void C_ccall f_4169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,1))){C_save_and_reclaim((void *)f_4169,6,av);}
a=C_alloc(36);
t6=C_i_length(t5);
t7=C_eqp(C_fix(3),t6);
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=C_i_car(t5);
t10=C_i_cadr(t5);
t11=C_a_i_list2(&a,2,t9,t10);
t12=C_a_i_record4(&a,4,lf[35],lf[38],lf[77],t11);
t13=C_i_caddr(t5);
t14=C_a_i_list2(&a,2,t12,t13);
t15=C_a_i_record4(&a,4,lf[35],lf[38],lf[78],t14);
t16=C_a_i_list2(&a,2,t4,t15);
t17=t1;
t18=t17;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t8,t16);
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k4561 in k4537 in a4458 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in ... */
static void C_ccall f_4563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_4563,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_4489(t3,C_a_i_record4(&a,4,lf[35],lf[36],lf[259],t2));}

/* k4565 in k4537 in a4458 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in ... */
static void C_ccall f_4567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4567,2,av);}
/* c-platform.scm:944: qnode */
t2=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3967 in k3971 in k3975 in a3916 in k3898 in rewrite-call/cc in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in ... */
static void C_ccall f_3969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3969,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1077: qnode */
t5=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k3963 in k3967 in k3971 in k3975 in a3916 in k3898 in rewrite-call/cc in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in ... */
static void C_ccall f_3965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_3965,2,av);}
a=C_alloc(14);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in ... */
static void C_ccall f_3307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3307,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:803: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[431];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[432];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in ... */
static void C_ccall f_3301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3301,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:800: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[435];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[436];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in ... */
static void C_ccall f_3304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3304,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:801: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[433];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[434];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in ... */
static void C_ccall f_3238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3238,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:774: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[459];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[294];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in ... */
static void C_ccall f_3235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3235,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:772: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[461];
av2[3]=C_fix(11);
av2[4]=C_fix(1);
av2[5]=lf[462];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in ... */
static void C_ccall f_3232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3232,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:771: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[463];
av2[3]=C_fix(11);
av2[4]=C_fix(1);
av2[5]=lf[464];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in ... */
static void C_ccall f_3358(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3358,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:824: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[391];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[392];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in ... */
static void C_ccall f_3355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3355,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:822: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[393];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[394];
av2[6]=lf[395];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in ... */
static void C_ccall f_3352(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3352,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:821: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[396];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[397];
av2[6]=lf[398];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in ... */
static void C_ccall f_3367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3367,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:828: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[386];
av2[3]=C_fix(15);
av2[4]=lf[385];
av2[5]=lf[32];
av2[6]=lf[355];
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in ... */
static void C_ccall f_3364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3364,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:827: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[387];
av2[3]=C_fix(15);
av2[4]=lf[385];
av2[5]=lf[32];
av2[6]=lf[388];
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in ... */
static void C_ccall f_3361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3361,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:825: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[389];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[390];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_2608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2608,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:546: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[846];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[847];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_2605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2605,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:545: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[848];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[849];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_2602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2602,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2605,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:544: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[850];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[851];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in ... */
static void C_ccall f_2617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2617,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:549: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[841];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[842];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in ... */
static void C_ccall f_2614(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2614,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:548: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[806];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[843];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1611 in k1608 in k1605 */
static void C_ccall f_1613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1613,2,av);}
a=C_alloc(6);
t2=C_set_block_item(lf[0] /* ##compiler#default-optimization-passes */,0,C_fix(3));
t3=C_mutate2((C_word*)lf[1]+1 /* (set! ##compiler#default-declarations ...) */,lf[2]);
t4=C_mutate2((C_word*)lf[3]+1 /* (set! ##compiler#default-debugging-declarations ...) */,lf[4]);
t5=C_mutate2((C_word*)lf[5]+1 /* (set! ##compiler#default-profiling-declarations ...) */,lf[6]);
t6=C_mutate2((C_word*)lf[7]+1 /* (set! ##compiler#units-used-by-default ...) */,lf[8]);
t7=C_set_block_item(lf[9] /* ##compiler#words-per-flonum */,0,C_fix(4));
t8=C_mutate2((C_word*)lf[10]+1 /* (set! ##compiler#unlikely-variables ...) */,lf[11]);
t9=C_mutate2((C_word*)lf[12]+1 /* (set! ##compiler#eq-inline-operator ...) */,lf[13]);
t10=C_mutate2((C_word*)lf[14]+1 /* (set! ##compiler#membership-test-operators ...) */,lf[15]);
t11=C_set_block_item(lf[16] /* ##compiler#membership-unfold-limit */,0,C_fix(20));
t12=C_mutate2((C_word*)lf[17]+1 /* (set! ##compiler#target-include-file ...) */,lf[18]);
t13=C_mutate2((C_word*)lf[19]+1 /* (set! ##compiler#valid-compiler-options ...) */,lf[20]);
t14=C_mutate2((C_word*)lf[21]+1 /* (set! ##compiler#valid-compiler-options-with-argument ...) */,lf[22]);
t15=C_mutate2((C_word*)lf[23]+1 /* (set! ##compiler#default-standard-bindings ...) */,lf[24]);
t16=C_mutate2((C_word*)lf[25]+1 /* (set! ##compiler#default-extended-bindings ...) */,lf[26]);
t17=C_mutate2((C_word*)lf[27]+1 /* (set! ##compiler#internal-bindings ...) */,lf[28]);
t18=C_mutate2((C_word*)lf[29]+1 /* (set! ##compiler#non-foldable-bindings ...) */,lf[30]);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5658,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:224: lset-union */
t21=*((C_word*)lf[932]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t21;
av2[1]=t20;
av2[2]=*((C_word*)lf[799]+1);
av2[3]=*((C_word*)lf[23]+1);
av2[4]=*((C_word*)lf[25]+1);
((C_proc)(void*)(*((C_word*)t21+1)))(5,av2);}}

/* k1608 in k1605 */
static void C_ccall f_1610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1610,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in ... */
static void C_ccall f_2611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2611,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:547: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[844];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[845];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1605 */
static void C_ccall f_1607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1607,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in ... */
static void C_ccall f_2569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2569,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:532: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[866];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[868];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in ... */
static void C_ccall f_2566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2566,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:531: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[50];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[869];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in ... */
static void C_ccall f_2563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2563,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:530: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[49];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[870];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in ... */
static void C_ccall f_2560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_2560,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:528: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[863];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4823 in k4820 in k4783 in a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_4825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,1))){
C_save_and_reclaim_args((void *)trf_4825,2,t0,t1);}
a=C_alloc(19);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[35],lf[36],lf[902],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
f_4791(t6,C_a_i_record4(&a,4,lf[35],lf[37],t2,t5));}
else{
t2=((C_word*)t0)[4];
f_4791(t2,C_SCHEME_FALSE);}}

/* k4820 in k4783 in a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_4822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_4822,2,t0,t1);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4825(t3,t1);}
else{
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_eqp(lf[41],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[5],C_fix(2));
t6=C_i_car(t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4862,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:420: immediate? */
t9=*((C_word*)lf[293]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t5=t2;
f_4825(t5,C_SCHEME_FALSE);}}}

/* a4286 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in ... */
static void C_ccall f_4287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,4))){C_save_and_reclaim((void *)f_4287,6,av);}
a=C_alloc(18);
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4317,a[2]=t4,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4320,a[2]=t12,a[3]=t9,a[4]=t4,a[5]=t1,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t14=C_slot(t9,C_fix(1));
t15=C_eqp(lf[42],t14);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4345,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t17=C_slot(t9,C_fix(2));
t18=C_i_car(t17);
/* c-platform.scm:1138: get */
t19=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t19;
av2[1]=t16;
av2[2]=t2;
av2[3]=t18;
av2[4]=lf[104];
((C_proc)(void*)(*((C_word*)t19+1)))(5,av2);}}
else{
t16=t13;
f_4320(t16,C_SCHEME_FALSE);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_2599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2599,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:543: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[852];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[853];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_ccall f_2596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2596,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:542: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[854];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[855];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in ... */
static void C_ccall f_2662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2662,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:565: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[812];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[813];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in ... */
static void C_ccall f_2593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2593,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:541: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[808];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[856];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in ... */
static void C_ccall f_2590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2590,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:540: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[810];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[857];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in ... */
static void C_ccall f_2668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2668,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:567: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[808];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[809];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in ... */
static void C_ccall f_2665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2665,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:566: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[810];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[811];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5641 in for-each-loop42 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5643,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5633(t3,((C_word*)t0)[4],t2);}

/* k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in ... */
static void C_ccall f_2300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2300,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:487: rewrite-c..r */
f_2196(t2,lf[874],lf[875],lf[876]);}

/* k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in ... */
static void C_ccall f_2674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2674,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:569: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[804];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[805];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in ... */
static void C_ccall f_2671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2671,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:568: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[806];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[807];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4102 in a4093 in k4087 in k4084 in k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in ... */
static void C_ccall f_4104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_4104,2,av);}
a=C_alloc(14);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=C_i_car(((C_word*)t0)[2]);
t5=t4;
t6=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t7=t6;
t8=C_i_cadr(((C_word*)t0)[2]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4162,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* c-platform.scm:1198: varnode */
t11=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}

/* k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in ... */
static void C_ccall f_2677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_2677,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:571: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[801];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[803];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in ... */
static void C_ccall f_2575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2575,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:534: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[863];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[865];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in ... */
static void C_ccall f_2578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2578,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:535: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[863];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[864];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* f_1675 in op1 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,2))){C_save_and_reclaim((void *)f_1675,6,av);}
a=C_alloc(22);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=C_eqp(lf[32],*((C_word*)lf[33]+1));
if(C_truep(t10)){
if(C_truep(*((C_word*)lf[34]+1))){
t11=((C_word*)t0)[2];
t12=C_a_i_list1(&a,1,t11);
t13=t5;
t14=C_a_i_record4(&a,4,lf[35],lf[36],t12,t13);
t15=C_a_i_list2(&a,2,t4,t14);
t16=t1;
t17=t16;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t17;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t9,t15);
((C_proc)(void*)(*((C_word*)t17+1)))(2,av2);}}
else{
t11=((C_word*)t0)[3];
t12=C_a_i_list1(&a,1,t11);
t13=t5;
t14=C_a_i_record4(&a,4,lf[35],lf[36],t12,t13);
t15=C_a_i_list2(&a,2,t4,t14);
t16=t1;
t17=t16;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t17;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t9,t15);
((C_proc)(void*)(*((C_word*)t17+1)))(2,av2);}}}
else{
t11=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(4));
t12=t11;
t13=C_i_car(t5);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1745,a[2]=t14,a[3]=t12,a[4]=t4,a[5]=t1,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:377: qnode */
t16=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=t15;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* op1 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_1673(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,6))){
C_save_and_reclaim_args((void *)trf_1673,4,t1,t2,t3,t4);}
a=C_alloc(5);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1675,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in ... */
static void C_ccall f_2683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_2683,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:574: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[799];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[800];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_1671,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1673,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5003,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:378: op1 */
f_1673(t4,lf[909],lf[910],lf[911]);}

/* k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in ... */
static void C_ccall f_2680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2680,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:572: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[801];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[802];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in ... */
static void C_ccall f_2572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2572,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:533: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[866];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[867];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in ... */
static void C_ccall f_2303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_2303,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:488: rewrite-c..r */
f_2196(t2,lf[871],lf[872],lf[873]);}

/* k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in ... */
static void C_ccall f_2689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_2689,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:576: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[795];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[796];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* rvalues in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in ... */
static void C_ccall f_2307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_2307,6,av);}
a=C_alloc(11);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=C_a_i_cons(&a,2,t4,t5);
t10=t1;
t11=t10;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t8,t9);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in ... */
static void C_ccall f_2306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_2306,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2307,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:495: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[49];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in ... */
static void C_ccall f_2686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_2686,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:575: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[797];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[798];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in ... */
static void C_ccall f_3553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3553,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:957: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[247];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[248];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in ... */
static void C_ccall f_2587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2587,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:539: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[812];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[858];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in ... */
static void C_ccall f_3550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3550,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:956: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[249];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[250];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_1668,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5005,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:338: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[915];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_1665,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5130,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:311: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[426];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in ... */
static void C_ccall f_2692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_2692,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:577: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[793];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[794];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_1662,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5293,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:273: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[423];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in ... */
static void C_ccall f_3547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3547,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3550,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:955: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[251];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[252];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in ... */
static void C_ccall f_3544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3544,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3547,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:954: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[253];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[254];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in ... */
static void C_ccall f_2584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2584,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:537: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[859];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[860];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in ... */
static void C_ccall f_2581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2581,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:536: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[861];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[862];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in ... */
static void C_ccall f_2695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2695,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:579: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[790];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[792];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in ... */
static void C_ccall f_2698(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2698,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:580: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[790];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[791];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in ... */
static void C_ccall f_3016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3016,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:692: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[583];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[584];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in ... */
static void C_ccall f_3013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3013,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:690: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[585];
av2[3]=C_fix(22);
av2[4]=C_fix(1);
av2[5]=lf[586];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
av2[8]=lf[587];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in k2339 in ... */
static void C_ccall f_2620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2620,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:550: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[839];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[840];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in ... */
static void C_ccall f_3010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3010,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:688: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[588];
av2[3]=C_fix(21);
av2[4]=C_fix(0);
av2[5]=lf[589];
av2[6]=lf[590];
av2[7]=lf[591];
av2[8]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in k2558 in ... */
static void C_ccall f_2623(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2623,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:551: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[837];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[838];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in ... */
static void C_ccall f_3019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3019,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:693: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[581];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[582];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in ... */
static void C_ccall f_3556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3556,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:958: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[245];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[246];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in ... */
static void C_ccall f_2629(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2629,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:553: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[833];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[834];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in ... */
static void C_ccall f_3559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3559,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:959: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[243];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[244];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in k2564 in k2561 in ... */
static void C_ccall f_2626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2626,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:552: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[835];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[836];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5656 in k1611 in k1608 in k1605 */
static void C_ccall f_5658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5658,2,av);}
/* c-platform.scm:222: lset-difference */
t2=*((C_word*)lf[931]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[799]+1);
av2[3]=t1;
av2[4]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in ... */
static void C_ccall f_3109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3109,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:727: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[528];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[529];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in ... */
static void C_ccall f_3106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3106,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:725: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[530];
av2[3]=C_fix(6);
av2[4]=lf[531];
av2[5]=lf[532];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in ... */
static void C_ccall f_3100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3100,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:723: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[524];
av2[3]=C_fix(6);
av2[4]=lf[536];
av2[5]=lf[537];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in ... */
static void C_ccall f_3103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3103,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:724: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[533];
av2[3]=C_fix(6);
av2[4]=lf[534];
av2[5]=lf[535];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in ... */
static void C_ccall f_2635(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2635,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:555: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[829];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[830];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in k2570 in k2567 in ... */
static void C_ccall f_2632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2632,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:554: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[831];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[832];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4893 in k4783 in a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_4895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4895,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_4822(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4822(t2,C_i_symbolp(((C_word*)t0)[3]));}}

/* k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in k2573 in ... */
static void C_ccall f_2638(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2638,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:556: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[827];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[828];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in ... */
static void C_ccall f_3580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3580,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:966: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[228];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[229];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1634,2,av);}
a=C_alloc(8);
t2=C_mutate2((C_word*)lf[31]+1 /* (set! ##compiler#foldable-bindings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5633,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5633(t7,t3,lf[930]);}

/* k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in k2576 in ... */
static void C_ccall f_2641(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2641,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:557: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[825];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[826];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in k2579 in ... */
static void C_ccall f_2644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2644,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:558: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[823];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[824];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in k2582 in ... */
static void C_ccall f_2647(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2647,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:559: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[821];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[822];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4789 in k4783 in a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_4791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,1))){
C_save_and_reclaim_args((void *)trf_4791,2,t0,t1);}
a=C_alloc(19);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
t4=C_a_i_record4(&a,4,lf[35],lf[36],lf[901],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[2];
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t2,t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in ... */
static void C_ccall f_3127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3127,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:734: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[504];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[519];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in ... */
static void C_ccall f_3121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3121,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:732: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[508];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[521];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in ... */
static void C_ccall f_3124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3124,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:733: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[506];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[520];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in k2585 in ... */
static void C_ccall f_2650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2650,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:560: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[819];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[820];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in k2588 in ... */
static void C_ccall f_2653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2653,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:561: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[817];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[818];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* a4458 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in ... */
static void C_ccall f_4459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_4459,6,av);}
a=C_alloc(18);
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_i_cadr(t5);
t9=t8;
t10=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4489,a[2]=t4,a[3]=t1,a[4]=t11,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t13=C_slot(t9,C_fix(1));
t14=C_eqp(lf[41],t13);
if(C_truep(t14)){
t15=C_eqp(*((C_word*)lf[33]+1),lf[32]);
if(C_truep(t15)){
t16=C_slot(t9,C_fix(2));
t17=C_i_car(t16);
t18=t17;
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4539,a[2]=t18,a[3]=t5,a[4]=t12,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t18))){
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4591,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:940: big-fixnum? */
t21=*((C_word*)lf[261]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t21;
av2[1]=t20;
av2[2]=t18;
((C_proc)(void*)(*((C_word*)t21+1)))(3,av2);}}
else{
t20=t19;
f_4539(t20,C_SCHEME_FALSE);}}
else{
t19=t12;
f_4489(t19,C_SCHEME_FALSE);}}
else{
t16=t12;
f_4489(t16,C_SCHEME_FALSE);}}
else{
t15=t12;
f_4489(t15,C_SCHEME_FALSE);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in k2591 in ... */
static void C_ccall f_2656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2656,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:562: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[815];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[816];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2594 in ... */
static void C_ccall f_2659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2659,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:563: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[804];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[814];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in ... */
static void C_ccall f_3562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3562,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:960: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[241];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[242];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_4769(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_4769,6,av);}
a=C_alloc(15);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_i_cadr(t5);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4785,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t11,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t13=C_slot(t9,C_fix(1));
t14=C_eqp(lf[42],t13);
if(C_truep(t14)){
t15=C_slot(t11,C_fix(1));
t16=C_eqp(lf[42],t15);
if(C_truep(t16)){
t17=C_slot(t9,C_fix(2));
t18=C_slot(t11,C_fix(2));
if(C_truep(C_i_equalp(t17,t18))){
t19=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t20=t19;
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4954,a[2]=t4,a[3]=t12,a[4]=t20,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:414: qnode */
t22=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t22;
av2[1]=t21;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t22+1)))(3,av2);}}
else{
t19=t12;
f_4785(t19,C_SCHEME_FALSE);}}
else{
t17=t12;
f_4785(t17,C_SCHEME_FALSE);}}
else{
t15=t12;
f_4785(t15,C_SCHEME_FALSE);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in ... */
static void C_ccall f_3118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3118,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:730: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[522];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[523];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in ... */
static void C_ccall f_3112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3112,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:728: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[526];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[527];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in ... */
static void C_ccall f_3115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3115,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:729: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[524];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[525];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_1656,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:241: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=C_fix(19);
av2[4]=C_fix(0);
av2[5]=lf[926];
av2[6]=lf[927];
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_1659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_1659,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5448,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:243: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[431];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in ... */
static void C_ccall f_3571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3571,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:963: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[234];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[235];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in ... */
static void C_ccall f_3004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3004,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:686: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[596];
av2[3]=C_fix(21);
av2[4]=C_fix(0);
av2[5]=lf[597];
av2[6]=lf[598];
av2[7]=lf[599];
av2[8]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in ... */
static void C_ccall f_3001(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3001,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:684: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[600];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[601];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in ... */
static void C_ccall f_3007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_3007,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:687: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[592];
av2[3]=C_fix(21);
av2[4]=C_fix(-1);
av2[5]=lf[593];
av2[6]=lf[594];
av2[7]=lf[595];
av2[8]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in ... */
static void C_ccall f_3565(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3565,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:961: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[238];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[239];
av2[6]=lf[240];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in ... */
static void C_ccall f_3568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3568,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:962: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[236];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[237];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4343 in a4286 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in ... */
static void C_ccall f_4345(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4345,2,av);}
t2=((C_word*)t0)[2];
f_4320(t2,C_i_not(t1));}

/* k4744 in a4692 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in ... */
static void C_ccall f_4746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,1))){C_save_and_reclaim((void *)f_4746,2,av);}
a=C_alloc(25);
/* c-platform.scm:862: build */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=f_4696(C_a_i(&a,25),((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in ... */
static void C_ccall f_3541(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3541,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:953: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[255];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[256];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in ... */
static void C_ccall f_3574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3574,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:964: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[232];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[233];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in ... */
static void C_ccall f_3577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3577,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:965: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[230];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[231];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in ... */
static void C_ccall f_3055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3055,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:706: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[554];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[558];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in ... */
static void C_ccall f_3052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3052,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:705: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[559];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[560];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in ... */
static void C_ccall f_3058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3058,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:707: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[556];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[557];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in ... */
static void C_ccall f_3022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3022,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:694: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[579];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[580];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in ... */
static void C_ccall f_3025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3025,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:695: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[577];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[578];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in ... */
static void C_ccall f_3028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3028,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:696: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[575];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[576];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in ... */
static void C_ccall f_3034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3034,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:699: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[571];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[572];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in ... */
static void C_ccall f_3037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3037,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:700: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[569];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[570];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in ... */
static void C_ccall f_3031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3031,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:697: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[573];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[574];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in ... */
static void C_ccall f_3190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3190,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:755: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[486];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[487];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in ... */
static void C_ccall f_3193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3193,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:757: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[441];
av2[3]=C_fix(9);
av2[4]=lf[484];
av2[5]=lf[485];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_2191,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:458: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[899];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* rewrite-c..r in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_2196(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,6))){
C_save_and_reclaim_args((void *)trf_2196,4,t1,t2,t3,t4);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2202,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:462: rewrite */
t6=*((C_word*)lf[56]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(8);
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_2194,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2196,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:479: rewrite-c..r */
f_2196(t3,lf[896],lf[897],lf[898]);}

/* k2405 in k2402 in k2375 in rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in ... */
static void C_ccall f_2407(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_2407,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_slot(((C_word*)t0)[7],C_fix(2));
/* c-platform.scm:515: debugging */
t5=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[63];
av2[3]=lf[64];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2402 in k2375 in rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in ... */
static void C_ccall f_2404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2404,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2407,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-platform.scm:514: gensym */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[65];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in ... */
static void C_ccall f_3097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3097,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:722: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[528];
av2[3]=C_fix(6);
av2[4]=lf[538];
av2[5]=lf[539];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in ... */
static void C_ccall f_3094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3094,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:720: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[540];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[541];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in ... */
static void C_ccall f_3091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3091,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:719: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[540];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[542];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in ... */
static void C_ccall f_3196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3196,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:758: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[439];
av2[3]=C_fix(9);
av2[4]=lf[482];
av2[5]=lf[483];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in ... */
static void C_ccall f_3199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3199,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:759: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[437];
av2[3]=C_fix(9);
av2[4]=lf[480];
av2[5]=lf[481];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in ... */
static void C_ccall f_3067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3067,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:711: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[550];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[552];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in ... */
static void C_ccall f_3061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3061,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:708: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[554];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[555];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in ... */
static void C_ccall f_3172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3172,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:749: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[498];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[499];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in ... */
static void C_ccall f_3064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3064,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:710: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[550];
av2[3]=C_fix(5);
av2[4]=lf[553];
av2[5]=C_fix(0);
av2[6]=lf[32];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2408 in k2405 in k2402 in k2375 in rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in ... */
static void C_ccall f_2410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2410,2,av);}
a=C_alloc(12);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* c-platform.scm:520: gensym */
t5=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[61];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in ... */
static void C_ccall f_3079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3079,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:715: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[545];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[547];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in ... */
static void C_ccall f_3076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3076,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:714: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[545];
av2[3]=C_fix(5);
av2[4]=lf[548];
av2[5]=C_fix(0);
av2[6]=lf[385];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in ... */
static void C_ccall f_3073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3073,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:713: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[545];
av2[3]=C_fix(5);
av2[4]=lf[549];
av2[5]=C_fix(0);
av2[6]=lf[32];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in ... */
static void C_ccall f_3181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3181,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:752: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[492];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[493];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in ... */
static void C_ccall f_3070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3070,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:712: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[550];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[551];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in ... */
static void C_ccall f_3175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3175,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:750: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[496];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[497];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in ... */
static void C_ccall f_3178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3178,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:751: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[494];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[495];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in ... */
static void C_ccall f_3043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3043,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:702: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[565];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[566];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in ... */
static void C_ccall f_3151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3151,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:742: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[488];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[511];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in ... */
static void C_ccall f_3049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3049,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:704: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[561];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[562];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in ... */
static void C_ccall f_3046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3046,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:703: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[563];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[564];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in ... */
static void C_ccall f_3040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3040,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:701: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[567];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[568];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in ... */
static void C_ccall f_3187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3187,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:754: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[488];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[489];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in ... */
static void C_ccall f_3184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3184,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:753: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[490];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[491];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in ... */
static void C_ccall f_3160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3160,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:745: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[506];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[507];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4315 in a4286 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in ... */
static void C_ccall f_4317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_4317,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in ... */
static void C_ccall f_3157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3157,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:744: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[508];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[509];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in ... */
static void C_ccall f_3154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3154,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:743: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[486];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[510];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in ... */
static void C_ccall f_3130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3130,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:735: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[502];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[518];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4318 in a4286 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in ... */
static void C_fcall f_4320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,2))){
C_save_and_reclaim_args((void *)trf_4320,2,t0,t1);}
a=C_alloc(19);
if(C_truep(t1)){
/* c-platform.scm:1139: qnode */
t2=*((C_word*)lf[39]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t3=C_a_i_record4(&a,4,lf[35],lf[36],lf[103],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[6],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* a5292 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_5293,6,av);}
a=C_alloc(19);
if(C_truep(C_i_nullp(t5))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_cdr(t5);
t7=C_i_nullp(t6);
t8=(C_truep(t7)?C_eqp(*((C_word*)lf[33]+1),lf[32]):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
if(C_truep(*((C_word*)lf[34]+1))){
t10=t5;
t11=C_a_i_record4(&a,4,lf[35],lf[36],lf[920],t10);
t12=C_a_i_list2(&a,2,t4,t11);
t13=t1;
t14=t13;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t9,t12);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t10=t5;
t11=C_a_i_record4(&a,4,lf[35],lf[36],lf[921],t10);
t12=C_a_i_list2(&a,2,t4,t11);
t13=t1;
t14=t13;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t9,t12);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t9=t5;
t10=C_u_i_car(t9);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5400,a[2]=t10,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5402,tmp=(C_word)a,a+=2,tmp);
t13=t5;
t14=C_u_i_cdr(t13);
/* c-platform.scm:293: remove */
t15=*((C_word*)lf[919]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t11;
av2[2]=t12;
av2[3]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}}}

/* k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in ... */
static void C_ccall f_3169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3169,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:748: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[500];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[501];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in ... */
static void C_ccall f_3163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3163,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:746: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[504];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[505];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in ... */
static void C_ccall f_3166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3166,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:747: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[502];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[503];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in ... */
static void C_ccall f_3142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3142,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:739: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[494];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[514];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in ... */
static void C_ccall f_3139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3139,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:738: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[496];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[515];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in ... */
static void C_ccall f_3136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3136,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:737: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[498];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[516];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in ... */
static void C_ccall f_3133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3133,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:736: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[500];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[517];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in ... */
static void C_ccall f_3088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3088,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:718: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[540];
av2[3]=C_fix(5);
av2[4]=lf[543];
av2[5]=C_fix(0);
av2[6]=lf[385];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in ... */
static void C_ccall f_3085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3085,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:717: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[540];
av2[3]=C_fix(5);
av2[4]=lf[544];
av2[5]=C_fix(0);
av2[6]=lf[32];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in ... */
static void C_ccall f_3082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3082,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:716: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[545];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[546];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in ... */
static void C_ccall f_3337(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3337,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:814: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[408];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[409];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in ... */
static void C_ccall f_3334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3334,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:813: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[410];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[411];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2487 in k2408 in k2405 in k2402 in k2375 in rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in ... */
static void C_ccall f_2489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,2))){C_save_and_reclaim((void *)f_2489,2,av);}
a=C_alloc(28);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=t3;
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-platform.scm:523: varnode */
t8=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k2483 in k2487 in k2408 in k2405 in k2402 in k2375 in rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in ... */
static void C_ccall f_2485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,2))){C_save_and_reclaim((void *)f_2485,2,av);}
a=C_alloc(32);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
t4=C_a_i_list1(&a,1,t3);
t5=C_a_i_record4(&a,4,lf[35],lf[57],((C_word*)t0)[5],t4);
t6=t5;
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2456,a[2]=((C_word*)t0)[6],a[3]=t8,a[4]=t6,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:526: varnode */
t10=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in ... */
static void C_ccall f_3331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3331,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:812: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[412];
av2[3]=C_fix(13);
av2[4]=C_fix(0);
av2[5]=lf[413];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in ... */
static void C_ccall f_3349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3349,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:819: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[399];
av2[3]=C_fix(14);
av2[4]=lf[32];
av2[5]=C_fix(2);
av2[6]=lf[400];
av2[7]=lf[401];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in ... */
static void C_ccall f_3343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3343,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:817: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[396];
av2[3]=C_fix(14);
av2[4]=lf[32];
av2[5]=C_fix(1);
av2[6]=lf[404];
av2[7]=lf[405];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in ... */
static void C_ccall f_3346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3346,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:818: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[393];
av2[3]=C_fix(14);
av2[4]=lf[32];
av2[5]=C_fix(1);
av2[6]=lf[402];
av2[7]=lf[403];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2375 in rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in ... */
static void C_ccall f_2377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2377,2,av);}
a=C_alloc(7);
t2=t1;
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[57],t3);
if(C_truep(t4)){
t5=C_slot(t2,C_fix(2));
t6=C_i_caddr(t5);
if(C_truep(C_i_listp(t6))){
t7=C_i_length(t6);
t8=C_eqp(C_fix(2),t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:513: gensym */
t10=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t9=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in ... */
static void C_ccall f_3340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3340,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:815: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[406];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[407];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in ... */
static void C_ccall f_3397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3397,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:839: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[366];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[367];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in ... */
static void C_ccall f_3394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3394,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:838: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[368];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[369];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in ... */
static void C_ccall f_3391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3391,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:837: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[370];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[371];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4402 in a4373 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in ... */
static void C_ccall f_4404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4404,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],lf[115]);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(t2);
/* c-platform.scm:1120: varnode */
t7=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a2201 in rewrite-c..r in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2202,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2214,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:468: call-with-current-continuation */
t9=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t1;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k4860 in k4820 in k4783 in a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_4862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4862,2,av);}
t2=((C_word*)t0)[2];
f_4825(t2,(C_truep(t1)?t1:C_i_symbolp(((C_word*)t0)[3])));}

/* build in a4692 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in ... */
static C_word C_fcall f_4696(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;{}
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_a_i_list2(&a,2,t1,t2);
t5=C_a_i_record4(&a,4,lf[35],lf[38],lf[351],t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[2],t5);
return(C_a_i_record4(&a,4,lf[35],lf[37],t3,t6));}

/* a4692 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in ... */
static void C_ccall f_4693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,3))){C_save_and_reclaim((void *)f_4693,6,av);}
a=C_alloc(28);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4696,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=C_i_length(t5);
switch(t7){
case C_fix(1):
t8=C_i_car(t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4746,a[2]=t1,a[3]=t6,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:862: qnode */
t11=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=C_fix(10);
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}
case C_fix(2):
t8=C_i_car(t5);
t9=C_i_cadr(t5);
/* c-platform.scm:863: build */
t10=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=f_4696(C_a_i(&a,25),t6,t8,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}
default:
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in ... */
static void C_ccall f_3376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3376,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:832: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[380];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[381];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in ... */
static void C_ccall f_3379(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3379,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:833: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[378];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[379];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* a2213 in a2201 in rewrite-c..r in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,2))){C_save_and_reclaim((void *)f_2214,3,av);}
a=C_alloc(27);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(*((C_word*)lf[34]+1))?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,((C_word*)t0)[4]);
t9=((C_word*)t0)[2];
t10=C_a_i_record4(&a,4,lf[35],lf[36],t8,t9);
t11=C_a_i_list2(&a,2,((C_word*)t0)[3],t10);
t12=t1;
t13=t12;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t5,t11);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
if(C_truep(((C_word*)t0)[5])){
t8=C_a_i_list1(&a,1,((C_word*)t0)[5]);
t9=((C_word*)t0)[2];
t10=C_a_i_record4(&a,4,lf[35],lf[36],t8,t9);
t11=C_a_i_list2(&a,2,((C_word*)t0)[3],t10);
t12=t1;
t13=t12;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t5,t11);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
/* c-platform.scm:477: return */
t8=t2;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}}

/* k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in ... */
static void C_ccall f_3370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3370,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:829: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[384];
av2[3]=C_fix(15);
av2[4]=lf[385];
av2[5]=lf[32];
av2[6]=lf[358];
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in ... */
static void C_ccall f_3373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3373,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:831: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[382];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[383];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in ... */
static void C_ccall f_3385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3385,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:835: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[374];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[375];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in ... */
static void C_ccall f_3388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3388,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:836: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[372];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[373];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2454 in k2483 in k2487 in k2408 in k2405 in k2402 in k2375 in rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in ... */
static void C_ccall f_2456(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_2456,2,av);}
a=C_alloc(22);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[3],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[58],((C_word*)t0)[6],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* a5251 in a5129 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5252(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5252,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[41],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_eqp(C_fix(1),t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k5248 in a5129 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_5250,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_eqp(*((C_word*)lf[33]+1),lf[32]);
if(C_truep(t3)){
t4=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5174,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:331: fold-inner */
t9=*((C_word*)lf[918]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in ... */
static void C_ccall f_2893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2893,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:645: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[672];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[673];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in ... */
static void C_ccall f_3876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3876,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1056: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[118];
av2[3]=C_fix(20);
av2[4]=C_fix(2);
av2[5]=lf[119];
av2[6]=C_fix(10);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in ... */
static void C_ccall f_2896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2896,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:646: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[670];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[671];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in ... */
static void C_ccall f_2890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2890,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:644: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[674];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[675];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in ... */
static void C_ccall f_3879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_3879,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3881,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1078: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[55];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in ... */
static void C_ccall f_2899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2899,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:647: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[668];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[669];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in ... */
static void C_ccall f_3382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3382,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:834: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[376];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[377];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in ... */
static void C_ccall f_3873(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3873,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1055: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[120];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[121];
av2[6]=C_fix(10);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in ... */
static void C_ccall f_3870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_3870,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1053: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[122];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in ... */
static void C_ccall f_3637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3637,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:987: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[189];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[190];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in ... */
static void C_ccall f_3631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3631,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:985: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[193];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[194];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in ... */
static void C_ccall f_3634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3634,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:986: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[191];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[192];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in ... */
static void C_ccall f_2860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2860,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:634: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[694];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[695];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in ... */
static void C_ccall f_2863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2863,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:635: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[692];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[693];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* rewrite-c-w-v in k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in ... */
static void C_ccall f_2343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2343,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_i_cadr(t5);
t11=t10;
t12=C_slot(t9,C_fix(1));
t13=C_eqp(lf[42],t12);
if(C_truep(t13)){
t14=C_slot(t11,C_fix(1));
t15=C_eqp(lf[42],t14);
if(C_truep(t15)){
t16=C_slot(t11,C_fix(2));
t17=C_i_car(t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2377,a[2]=t11,a[3]=t4,a[4]=t9,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:508: get */
t19=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t19;
av2[1]=t18;
av2[2]=t2;
av2[3]=t17;
av2[4]=lf[67];
((C_proc)(void*)(*((C_word*)t19+1)))(5,av2);}}
else{
t18=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}}
else{
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2339 in k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in ... */
static void C_ccall f_2341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_2341,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2343,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2560,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:527: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[866];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2336 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in ... */
static void C_ccall f_2338(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_2338,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:496: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[50];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in ... */
static void C_ccall f_2866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2866,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:636: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[690];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[691];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in ... */
static void C_ccall f_2869(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2869,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:637: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[688];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[689];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in ... */
static void C_ccall f_3625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3625,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:982: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[197];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[198];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in ... */
static void C_ccall f_3628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3628,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:984: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[195];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[196];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in ... */
static void C_ccall f_3622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3622,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:980: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[199];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[200];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in ... */
static void C_ccall f_3619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3619,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:979: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[201];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[202];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in ... */
static void C_ccall f_3616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3616,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:978: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[203];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[204];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in ... */
static void C_ccall f_3613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3613,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:977: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[205];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[206];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in ... */
static void C_ccall f_3610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3610,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:976: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[207];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[208];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in ... */
static void C_ccall f_2881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2881,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:641: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[680];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[681];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in ... */
static void C_ccall f_2884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2884,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:642: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[678];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[679];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in ... */
static void C_ccall f_2887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2887,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:643: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[676];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[677];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in ... */
static void C_ccall f_2851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2851,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:631: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[698];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[700];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in ... */
static void C_ccall f_2854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2854,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:632: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[698];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[699];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in ... */
static void C_ccall f_2857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2857,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:633: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[696];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[697];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in ... */
static void C_ccall f_2821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2821,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:621: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[713];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[715];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in ... */
static void C_ccall f_2824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2824,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:622: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[713];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[714];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in ... */
static void C_ccall f_2827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2827,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:623: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[710];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[712];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* rewrite-call/cc in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in ... */
static void C_ccall f_3881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3881,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[42],t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3900,a[2]=t9,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=C_slot(t9,C_fix(2));
t14=C_i_car(t13);
/* c-platform.scm:1064: get */
t15=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t15;
av2[1]=t12;
av2[2]=t2;
av2[3]=t14;
av2[4]=lf[67];
((C_proc)(void*)(*((C_word*)t15+1)))(5,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in ... */
static void C_ccall f_2875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2875,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:639: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[684];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[685];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in ... */
static void C_ccall f_2872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2872,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:638: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[686];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[687];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in ... */
static void C_ccall f_2878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2878,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:640: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[682];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[683];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* a4615 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in ... */
static void C_ccall f_4616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,2))){C_save_and_reclaim((void *)f_4616,6,av);}
a=C_alloc(25);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(3));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=C_i_caddr(t5);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4658,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t12=C_slot(t10,C_fix(1));
t13=C_eqp(lf[41],t12);
if(C_truep(t13)){
t14=C_slot(t10,C_fix(2));
t15=C_i_car(t14);
/* c-platform.scm:909: immediate? */
t16=*((C_word*)lf[293]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=t11;
av2[2]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}
else{
t14=t5;
t15=C_a_i_record4(&a,4,lf[35],lf[36],lf[292],t14);
t16=C_a_i_list2(&a,2,t4,t15);
t17=t1;
t18=t17;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t9,t16);
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in ... */
static void C_ccall f_2842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2842,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:628: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[704];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[705];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_ccall f_3688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3688,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1008: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[153];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[154];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_3685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3685,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1007: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[155];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[156];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4952 in a4768 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_4954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_4954,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_4785(t3,C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2));}

/* k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in ... */
static void C_ccall f_2848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2848,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:630: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[701];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[702];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in ... */
static void C_ccall f_2845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2845,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:629: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[701];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[703];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_3682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3682,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1006: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[157];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[158];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* a5529 in k5450 in a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5530,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5537,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t3;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(lf[41],t6);
if(C_truep(t7)){
t8=t3;
t9=C_slot(t8,C_fix(2));
t10=C_i_car(t9);
t11=t4;
f_5537(t11,C_eqp(C_fix(2),t10));}
else{
t8=t4;
f_5537(t8,C_SCHEME_FALSE);}}

/* k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in ... */
static void C_ccall f_2812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2812,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:618: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[719];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[720];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in ... */
static void C_ccall f_3697(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3697,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1011: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[147];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[148];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in ... */
static void C_ccall f_3694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3694,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1010: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[149];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[150];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5526 in k5450 in a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5528,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in ... */
static void C_ccall f_2815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2815,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:619: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[716];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[718];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in ... */
static void C_ccall f_2818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2818,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:620: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[716];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[717];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_3691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3691,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1009: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[151];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[152];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5535 in a5529 in k5450 in a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_5537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_5537,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:268: qnode */
t3=*((C_word*)lf[39]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[36],lf[925],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in ... */
static void C_ccall f_2833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2833,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:625: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[707];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[709];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in ... */
static void C_ccall f_2830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2830,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:624: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[710];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[711];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in ... */
static void C_ccall f_2839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2839,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:627: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[704];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[706];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in ... */
static void C_ccall f_2836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2836,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:626: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[707];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[708];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in ... */
static void C_ccall f_3226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3226,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:769: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[467];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[468];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in ... */
static void C_ccall f_3229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3229,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:770: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[465];
av2[3]=C_fix(11);
av2[4]=C_fix(2);
av2[5]=lf[466];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in ... */
static void C_ccall f_3220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3220,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:767: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[470];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[294];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in ... */
static void C_ccall f_3223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3223,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:768: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[469];
av2[3]=C_fix(11);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[335];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in ... */
static void C_ccall f_2806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2806,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:616: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[722];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[723];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in ... */
static void C_ccall f_2809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2809,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:617: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[719];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[721];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4997 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_4999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4999,2,av);}
/* c-platform.scm:379: rewrite */
t2=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[904];
av2[3]=C_fix(8);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in ... */
static void C_ccall f_2803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2803,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:615: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[724];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[725];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in ... */
static void C_ccall f_2800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_2800,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:614: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[726];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[727];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in ... */
static void C_ccall f_3217(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3217,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:766: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[471];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[294];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in ... */
static void C_ccall f_3607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3607,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:975: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[209];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[210];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in ... */
static void C_ccall f_3604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3604,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:974: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[211];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[212];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in ... */
static void C_ccall f_3211(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3211,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:764: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[473];
av2[3]=C_fix(11);
av2[4]=C_fix(2);
av2[5]=lf[474];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in ... */
static void C_ccall f_3601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3601,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:973: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[213];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[214];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in ... */
static void C_ccall f_3214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3214,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:765: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[44];
av2[3]=C_fix(11);
av2[4]=C_fix(2);
av2[5]=lf[472];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in ... */
static void C_ccall f_3208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3208,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:763: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[475];
av2[3]=C_fix(11);
av2[4]=C_fix(1);
av2[5]=lf[116];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in ... */
static void C_ccall f_3205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3205,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:761: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[433];
av2[3]=C_fix(9);
av2[4]=lf[476];
av2[5]=lf[477];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in ... */
static void C_ccall f_3202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3202,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3205,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:760: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[435];
av2[3]=C_fix(9);
av2[4]=lf[478];
av2[5]=lf[479];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in ... */
static void C_ccall f_4077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_4077,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1162: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[84];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[85];
av2[6]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in ... */
static void C_ccall f_4071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_4071,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1160: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[88];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[89];
av2[6]=C_fix(0);
av2[7]=C_fix(0);
av2[8]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in ... */
static void C_ccall f_4074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_4074,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1161: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[86];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[87];
av2[6]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4087 in k4084 in k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in ... */
static void C_ccall f_4089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_4089,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4094,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1183: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[76];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4084 in k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in ... */
static void C_ccall f_4086(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_4086,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4169,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1167: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[79];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in ... */
static void C_ccall f_4083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_4083,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1165: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[80];
av2[3]=C_fix(7);
av2[4]=C_fix(2);
av2[5]=lf[81];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in ... */
static void C_ccall f_4080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_4080,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1164: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[82];
av2[3]=C_fix(7);
av2[4]=C_fix(2);
av2[5]=lf[83];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* map-loop433 in k2066 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2023,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* c-platform.scm:442: g439 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a4373 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in ... */
static void C_ccall f_4374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4374,6,av);}
a=C_alloc(5);
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[42],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4404,a[2]=t13,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tweaks.scm:51: ##sys#get */
t15=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=t13;
av2[3]=lf[53];
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t11=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k2019 in k2066 in k1973 in rewrite-apply in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2021,2,av);}
/* c-platform.scm:442: append */
t2=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5448,6,av);}
a=C_alloc(6);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5452,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5599,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:252: remove */
t8=*((C_word*)lf[919]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* a4093 in k4087 in k4084 in k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in ... */
static void C_ccall f_4094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4094,6,av);}
a=C_alloc(5);
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4104,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1187: gensym */
t9=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k4090 in k4087 in k4084 in k4081 in k4078 in k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in ... */
static void C_ccall f_4092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4092,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5450 in a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_5452,2,av);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:257: qnode */
t5=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_u_i_car(t1);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],t3,t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=C_eqp(*((C_word*)lf[33]+1),lf[32]);
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5530,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:265: fold-inner */
t8=*((C_word*)lf[918]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in ... */
static void C_ccall f_3529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3529,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:921: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[269];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[270];
av2[6]=lf[271];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in ... */
static void C_ccall f_3526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3526,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:920: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[272];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[273];
av2[6]=lf[274];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in ... */
static void C_ccall f_3523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3523,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:919: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[275];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[276];
av2[6]=lf[277];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in ... */
static void C_ccall f_3520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_3520,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:918: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[278];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[279];
av2[6]=lf[280];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in ... */
static void C_ccall f_4038(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_4038,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1123: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[112];
av2[3]=C_fix(3);
av2[4]=lf[113];
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in ... */
static void C_ccall f_4031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_4031,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4374,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1108: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[116];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in ... */
static void C_ccall f_4035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_4035,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1122: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[114];
av2[3]=C_fix(3);
av2[4]=lf[113];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in ... */
static void C_ccall f_4047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_4047,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1126: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[108];
av2[3]=C_fix(3);
av2[4]=lf[97];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5476 in k5450 in a5447 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_5478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5478,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[35],lf[37],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in ... */
static void C_ccall f_4041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_4041,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1124: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[110];
av2[3]=C_fix(3);
av2[4]=lf[111];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in ... */
static void C_ccall f_4044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_4044,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1125: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[109];
av2[3]=C_fix(3);
av2[4]=lf[94];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in ... */
static void C_ccall f_3427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3427,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:867: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[347];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[348];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(3);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in ... */
static void C_ccall f_4059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_4059,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1156: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[98];
av2[3]=C_fix(23);
av2[4]=C_fix(0);
av2[5]=lf[99];
av2[6]=lf[94];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in ... */
static void C_ccall f_4056(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_4056,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4237,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1144: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[102];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in ... */
static void C_ccall f_3421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_3421,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4693,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:848: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[352];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in ... */
static void C_ccall f_3424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3424,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:866: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[349];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[350];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(3);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in ... */
static void C_ccall f_4050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_4050,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1127: rewrite */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[106];
av2[3]=C_fix(3);
av2[4]=lf[107];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4029 in k4026 in k3877 in k3874 in k3871 in k3868 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in ... */
static void C_ccall f_4053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_4053,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4287,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1129: rewrite */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[105];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2277 in k2192 in k2189 in k1961 in k1958 in k1955 in k1754 in k1751 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1632 in k1611 in k1608 in k1605 */
static void C_ccall f_2279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2279,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:480: rewrite-c..r */
f_2196(t2,lf[893],lf[894],lf[895]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[553] = {
{"f_3418:c_2dplatform_2escm",(void*)f_3418},
{"f_4065:c_2dplatform_2escm",(void*)f_4065},
{"f_1998:c_2dplatform_2escm",(void*)f_1998},
{"f_3415:c_2dplatform_2escm",(void*)f_3415},
{"f_4068:c_2dplatform_2escm",(void*)f_4068},
{"f_2282:c_2dplatform_2escm",(void*)f_2282},
{"f_4062:c_2dplatform_2escm",(void*)f_4062},
{"f_3412:c_2dplatform_2escm",(void*)f_3412},
{"f_2285:c_2dplatform_2escm",(void*)f_2285},
{"f_2288:c_2dplatform_2escm",(void*)f_2288},
{"f_5553:c_2dplatform_2escm",(void*)f_5553},
{"f_4489:c_2dplatform_2escm",(void*)f_4489},
{"f_4591:c_2dplatform_2escm",(void*)f_4591},
{"f_5062:c_2dplatform_2escm",(void*)f_5062},
{"f_3406:c_2dplatform_2escm",(void*)f_3406},
{"f_3409:c_2dplatform_2escm",(void*)f_3409},
{"f_3400:c_2dplatform_2escm",(void*)f_3400},
{"f_2291:c_2dplatform_2escm",(void*)f_2291},
{"f_3403:c_2dplatform_2escm",(void*)f_3403},
{"f_2294:c_2dplatform_2escm",(void*)f_2294},
{"f_2297:c_2dplatform_2escm",(void*)f_2297},
{"f_5114:c_2dplatform_2escm",(void*)f_5114},
{"f_3517:c_2dplatform_2escm",(void*)f_3517},
{"f_3514:c_2dplatform_2escm",(void*)f_3514},
{"f_3511:c_2dplatform_2escm",(void*)f_3511},
{"f_3508:c_2dplatform_2escm",(void*)f_3508},
{"f_3505:c_2dplatform_2escm",(void*)f_3505},
{"f_3502:c_2dplatform_2escm",(void*)f_3502},
{"f_2238:c_2dplatform_2escm",(void*)f_2238},
{"f_4430:c_2dplatform_2escm",(void*)f_4430},
{"f_3535:c_2dplatform_2escm",(void*)f_3535},
{"f_3538:c_2dplatform_2escm",(void*)f_3538},
{"f_3532:c_2dplatform_2escm",(void*)f_3532},
{"f_1957:c_2dplatform_2escm",(void*)f_1957},
{"f_4028:c_2dplatform_2escm",(void*)f_4028},
{"f_3457:c_2dplatform_2escm",(void*)f_3457},
{"f_3454:c_2dplatform_2escm",(void*)f_3454},
{"f_5044:c_2dplatform_2escm",(void*)f_5044},
{"f_3451:c_2dplatform_2escm",(void*)f_3451},
{"f_1963:c_2dplatform_2escm",(void*)f_1963},
{"f_1965:c_2dplatform_2escm",(void*)f_1965},
{"f_1960:c_2dplatform_2escm",(void*)f_1960},
{"f_3469:c_2dplatform_2escm",(void*)f_3469},
{"f_3466:c_2dplatform_2escm",(void*)f_3466},
{"f_3463:c_2dplatform_2escm",(void*)f_3463},
{"f_3460:c_2dplatform_2escm",(void*)f_3460},
{"f_1913:c_2dplatform_2escm",(void*)f_1913},
{"f_5599:c_2dplatform_2escm",(void*)f_5599},
{"f_2004:c_2dplatform_2escm",(void*)f_2004},
{"f_1975:c_2dplatform_2escm",(void*)f_1975},
{"f_2905:c_2dplatform_2escm",(void*)f_2905},
{"f_2908:c_2dplatform_2escm",(void*)f_2908},
{"f_2902:c_2dplatform_2escm",(void*)f_2902},
{"f_2938:c_2dplatform_2escm",(void*)f_2938},
{"f_2935:c_2dplatform_2escm",(void*)f_2935},
{"f_2932:c_2dplatform_2escm",(void*)f_2932},
{"f_2947:c_2dplatform_2escm",(void*)f_2947},
{"f_5130:c_2dplatform_2escm",(void*)f_5130},
{"f_1786:c_2dplatform_2escm",(void*)f_1786},
{"f_2944:c_2dplatform_2escm",(void*)f_2944},
{"f_2941:c_2dplatform_2escm",(void*)f_2941},
{"f_1783:c_2dplatform_2escm",(void*)f_1783},
{"f_2917:c_2dplatform_2escm",(void*)f_2917},
{"f_2911:c_2dplatform_2escm",(void*)f_2911},
{"f_1774:c_2dplatform_2escm",(void*)f_1774},
{"f_2914:c_2dplatform_2escm",(void*)f_2914},
{"f_3646:c_2dplatform_2escm",(void*)f_3646},
{"f_3649:c_2dplatform_2escm",(void*)f_3649},
{"f_2929:c_2dplatform_2escm",(void*)f_2929},
{"f_2926:c_2dplatform_2escm",(void*)f_2926},
{"f_3643:c_2dplatform_2escm",(void*)f_3643},
{"f_3640:c_2dplatform_2escm",(void*)f_3640},
{"toplevel:c_2dplatform_2escm",(void*)C_platform_toplevel},
{"f_2923:c_2dplatform_2escm",(void*)f_2923},
{"f_2920:c_2dplatform_2escm",(void*)f_2920},
{"f_3655:c_2dplatform_2escm",(void*)f_3655},
{"f_3658:c_2dplatform_2escm",(void*)f_3658},
{"f_2977:c_2dplatform_2escm",(void*)f_2977},
{"f_3652:c_2dplatform_2escm",(void*)f_3652},
{"f_2971:c_2dplatform_2escm",(void*)f_2971},
{"f_2974:c_2dplatform_2escm",(void*)f_2974},
{"f_2989:c_2dplatform_2escm",(void*)f_2989},
{"f_2986:c_2dplatform_2escm",(void*)f_2986},
{"f_2071:c_2dplatform_2escm",(void*)f_2071},
{"f_5172:c_2dplatform_2escm",(void*)f_5172},
{"f_1745:c_2dplatform_2escm",(void*)f_1745},
{"f_5174:c_2dplatform_2escm",(void*)f_5174},
{"f_2980:c_2dplatform_2escm",(void*)f_2980},
{"f_2983:c_2dplatform_2escm",(void*)f_2983},
{"f_2956:c_2dplatform_2escm",(void*)f_2956},
{"f_2959:c_2dplatform_2escm",(void*)f_2959},
{"f_4237:c_2dplatform_2escm",(void*)f_4237},
{"f_2048:c_2dplatform_2escm",(void*)f_2048},
{"f_4658:c_2dplatform_2escm",(void*)f_4658},
{"f_5181:c_2dplatform_2escm",(void*)f_5181},
{"f_3770:c_2dplatform_2escm",(void*)f_3770},
{"f_2950:c_2dplatform_2escm",(void*)f_2950},
{"f_2953:c_2dplatform_2escm",(void*)f_2953},
{"f_2968:c_2dplatform_2escm",(void*)f_2968},
{"f_2090:c_2dplatform_2escm",(void*)f_2090},
{"f_5197:c_2dplatform_2escm",(void*)f_5197},
{"f_2962:c_2dplatform_2escm",(void*)f_2962},
{"f_2965:c_2dplatform_2escm",(void*)f_2965},
{"f_3755:c_2dplatform_2escm",(void*)f_3755},
{"f_2068:c_2dplatform_2escm",(void*)f_2068},
{"f_4539:c_2dplatform_2escm",(void*)f_4539},
{"f_3664:c_2dplatform_2escm",(void*)f_3664},
{"f_3667:c_2dplatform_2escm",(void*)f_3667},
{"f_3661:c_2dplatform_2escm",(void*)f_3661},
{"f_4785:c_2dplatform_2escm",(void*)f_4785},
{"f_3676:c_2dplatform_2escm",(void*)f_3676},
{"f_2998:c_2dplatform_2escm",(void*)f_2998},
{"f_3679:c_2dplatform_2escm",(void*)f_3679},
{"f_3670:c_2dplatform_2escm",(void*)f_3670},
{"f_3673:c_2dplatform_2escm",(void*)f_3673},
{"f_2995:c_2dplatform_2escm",(void*)f_2995},
{"f_2992:c_2dplatform_2escm",(void*)f_2992},
{"f_5003:c_2dplatform_2escm",(void*)f_5003},
{"f_5005:c_2dplatform_2escm",(void*)f_5005},
{"f_2710:c_2dplatform_2escm",(void*)f_2710},
{"f_2707:c_2dplatform_2escm",(void*)f_2707},
{"f_2704:c_2dplatform_2escm",(void*)f_2704},
{"f_1753:c_2dplatform_2escm",(void*)f_1753},
{"f_1756:c_2dplatform_2escm",(void*)f_1756},
{"f_1758:c_2dplatform_2escm",(void*)f_1758},
{"f_2719:c_2dplatform_2escm",(void*)f_2719},
{"f_2713:c_2dplatform_2escm",(void*)f_2713},
{"f_2716:c_2dplatform_2escm",(void*)f_2716},
{"f_3592:c_2dplatform_2escm",(void*)f_3592},
{"f_3709:c_2dplatform_2escm",(void*)f_3709},
{"f_3706:c_2dplatform_2escm",(void*)f_3706},
{"f_3703:c_2dplatform_2escm",(void*)f_3703},
{"f_3700:c_2dplatform_2escm",(void*)f_3700},
{"f_3589:c_2dplatform_2escm",(void*)f_3589},
{"f_3586:c_2dplatform_2escm",(void*)f_3586},
{"f_3583:c_2dplatform_2escm",(void*)f_3583},
{"f_3286:c_2dplatform_2escm",(void*)f_3286},
{"f_3289:c_2dplatform_2escm",(void*)f_3289},
{"f_3598:c_2dplatform_2escm",(void*)f_3598},
{"f_3595:c_2dplatform_2escm",(void*)f_3595},
{"f_3900:c_2dplatform_2escm",(void*)f_3900},
{"f_3283:c_2dplatform_2escm",(void*)f_3283},
{"f_3280:c_2dplatform_2escm",(void*)f_3280},
{"f_3727:c_2dplatform_2escm",(void*)f_3727},
{"f_3724:c_2dplatform_2escm",(void*)f_3724},
{"f_3721:c_2dplatform_2escm",(void*)f_3721},
{"f_3295:c_2dplatform_2escm",(void*)f_3295},
{"f_3298:c_2dplatform_2escm",(void*)f_3298},
{"f_3292:c_2dplatform_2escm",(void*)f_3292},
{"f_3715:c_2dplatform_2escm",(void*)f_3715},
{"f_3718:c_2dplatform_2escm",(void*)f_3718},
{"f_3712:c_2dplatform_2escm",(void*)f_3712},
{"f_3268:c_2dplatform_2escm",(void*)f_3268},
{"f_3265:c_2dplatform_2escm",(void*)f_3265},
{"f_3262:c_2dplatform_2escm",(void*)f_3262},
{"f_2127:c_2dplatform_2escm",(void*)f_2127},
{"f_2701:c_2dplatform_2escm",(void*)f_2701},
{"f_3277:c_2dplatform_2escm",(void*)f_3277},
{"f_3274:c_2dplatform_2escm",(void*)f_3274},
{"f_3271:c_2dplatform_2escm",(void*)f_3271},
{"f_3917:c_2dplatform_2escm",(void*)f_3917},
{"f_3735:c_2dplatform_2escm",(void*)f_3735},
{"f_3733:c_2dplatform_2escm",(void*)f_3733},
{"f_3730:c_2dplatform_2escm",(void*)f_3730},
{"f_3247:c_2dplatform_2escm",(void*)f_3247},
{"f_2791:c_2dplatform_2escm",(void*)f_2791},
{"f_2794:c_2dplatform_2escm",(void*)f_2794},
{"f_3244:c_2dplatform_2escm",(void*)f_3244},
{"f_3241:c_2dplatform_2escm",(void*)f_3241},
{"f_2785:c_2dplatform_2escm",(void*)f_2785},
{"f_2788:c_2dplatform_2escm",(void*)f_2788},
{"f_5372:c_2dplatform_2escm",(void*)f_5372},
{"f_5370:c_2dplatform_2escm",(void*)f_5370},
{"f_3259:c_2dplatform_2escm",(void*)f_3259},
{"f_2764:c_2dplatform_2escm",(void*)f_2764},
{"f_3253:c_2dplatform_2escm",(void*)f_3253},
{"f_2761:c_2dplatform_2escm",(void*)f_2761},
{"f_3256:c_2dplatform_2escm",(void*)f_3256},
{"f_3250:c_2dplatform_2escm",(void*)f_3250},
{"f_2797:c_2dplatform_2escm",(void*)f_2797},
{"f_2773:c_2dplatform_2escm",(void*)f_2773},
{"f_2770:c_2dplatform_2escm",(void*)f_2770},
{"f_3148:c_2dplatform_2escm",(void*)f_3148},
{"f_3145:c_2dplatform_2escm",(void*)f_3145},
{"f_3439:c_2dplatform_2escm",(void*)f_3439},
{"f_3433:c_2dplatform_2escm",(void*)f_3433},
{"f_3436:c_2dplatform_2escm",(void*)f_3436},
{"f_2767:c_2dplatform_2escm",(void*)f_2767},
{"f_3430:c_2dplatform_2escm",(void*)f_3430},
{"f_3448:c_2dplatform_2escm",(void*)f_3448},
{"f_3445:c_2dplatform_2escm",(void*)f_3445},
{"f_2779:c_2dplatform_2escm",(void*)f_2779},
{"f_2776:c_2dplatform_2escm",(void*)f_2776},
{"f_5633:c_2dplatform_2escm",(void*)f_5633},
{"f_3442:c_2dplatform_2escm",(void*)f_3442},
{"f_5400:c_2dplatform_2escm",(void*)f_5400},
{"f_2752:c_2dplatform_2escm",(void*)f_2752},
{"f_2755:c_2dplatform_2escm",(void*)f_2755},
{"f_5402:c_2dplatform_2escm",(void*)f_5402},
{"f_3496:c_2dplatform_2escm",(void*)f_3496},
{"f_2746:c_2dplatform_2escm",(void*)f_2746},
{"f_3499:c_2dplatform_2escm",(void*)f_3499},
{"f_2749:c_2dplatform_2escm",(void*)f_2749},
{"f_3493:c_2dplatform_2escm",(void*)f_3493},
{"f_3490:c_2dplatform_2escm",(void*)f_3490},
{"f_2725:c_2dplatform_2escm",(void*)f_2725},
{"f_2722:c_2dplatform_2escm",(void*)f_2722},
{"f_2758:c_2dplatform_2escm",(void*)f_2758},
{"f_2731:c_2dplatform_2escm",(void*)f_2731},
{"f_2734:c_2dplatform_2escm",(void*)f_2734},
{"f_3475:c_2dplatform_2escm",(void*)f_3475},
{"f_3478:c_2dplatform_2escm",(void*)f_3478},
{"f_2728:c_2dplatform_2escm",(void*)f_2728},
{"f_3328:c_2dplatform_2escm",(void*)f_3328},
{"f_3325:c_2dplatform_2escm",(void*)f_3325},
{"f_3322:c_2dplatform_2escm",(void*)f_3322},
{"f_3472:c_2dplatform_2escm",(void*)f_3472},
{"f_2782:c_2dplatform_2escm",(void*)f_2782},
{"f_3973:c_2dplatform_2escm",(void*)f_3973},
{"f_3484:c_2dplatform_2escm",(void*)f_3484},
{"f_3487:c_2dplatform_2escm",(void*)f_3487},
{"f_2737:c_2dplatform_2escm",(void*)f_2737},
{"f_3319:c_2dplatform_2escm",(void*)f_3319},
{"f_3316:c_2dplatform_2escm",(void*)f_3316},
{"f_3310:c_2dplatform_2escm",(void*)f_3310},
{"f_3313:c_2dplatform_2escm",(void*)f_3313},
{"f_3481:c_2dplatform_2escm",(void*)f_3481},
{"f_3977:c_2dplatform_2escm",(void*)f_3977},
{"f_3825:c_2dplatform_2escm",(void*)f_3825},
{"f_3823:c_2dplatform_2escm",(void*)f_3823},
{"f_2740:c_2dplatform_2escm",(void*)f_2740},
{"f_2743:c_2dplatform_2escm",(void*)f_2743},
{"f_4162:c_2dplatform_2escm",(void*)f_4162},
{"f_4169:c_2dplatform_2escm",(void*)f_4169},
{"f_4563:c_2dplatform_2escm",(void*)f_4563},
{"f_4567:c_2dplatform_2escm",(void*)f_4567},
{"f_3969:c_2dplatform_2escm",(void*)f_3969},
{"f_3965:c_2dplatform_2escm",(void*)f_3965},
{"f_3307:c_2dplatform_2escm",(void*)f_3307},
{"f_3301:c_2dplatform_2escm",(void*)f_3301},
{"f_3304:c_2dplatform_2escm",(void*)f_3304},
{"f_3238:c_2dplatform_2escm",(void*)f_3238},
{"f_3235:c_2dplatform_2escm",(void*)f_3235},
{"f_3232:c_2dplatform_2escm",(void*)f_3232},
{"f_3358:c_2dplatform_2escm",(void*)f_3358},
{"f_3355:c_2dplatform_2escm",(void*)f_3355},
{"f_3352:c_2dplatform_2escm",(void*)f_3352},
{"f_3367:c_2dplatform_2escm",(void*)f_3367},
{"f_3364:c_2dplatform_2escm",(void*)f_3364},
{"f_3361:c_2dplatform_2escm",(void*)f_3361},
{"f_2608:c_2dplatform_2escm",(void*)f_2608},
{"f_2605:c_2dplatform_2escm",(void*)f_2605},
{"f_2602:c_2dplatform_2escm",(void*)f_2602},
{"f_2617:c_2dplatform_2escm",(void*)f_2617},
{"f_2614:c_2dplatform_2escm",(void*)f_2614},
{"f_1613:c_2dplatform_2escm",(void*)f_1613},
{"f_1610:c_2dplatform_2escm",(void*)f_1610},
{"f_2611:c_2dplatform_2escm",(void*)f_2611},
{"f_1607:c_2dplatform_2escm",(void*)f_1607},
{"f_2569:c_2dplatform_2escm",(void*)f_2569},
{"f_2566:c_2dplatform_2escm",(void*)f_2566},
{"f_2563:c_2dplatform_2escm",(void*)f_2563},
{"f_2560:c_2dplatform_2escm",(void*)f_2560},
{"f_4825:c_2dplatform_2escm",(void*)f_4825},
{"f_4822:c_2dplatform_2escm",(void*)f_4822},
{"f_4287:c_2dplatform_2escm",(void*)f_4287},
{"f_2599:c_2dplatform_2escm",(void*)f_2599},
{"f_2596:c_2dplatform_2escm",(void*)f_2596},
{"f_2662:c_2dplatform_2escm",(void*)f_2662},
{"f_2593:c_2dplatform_2escm",(void*)f_2593},
{"f_2590:c_2dplatform_2escm",(void*)f_2590},
{"f_2668:c_2dplatform_2escm",(void*)f_2668},
{"f_2665:c_2dplatform_2escm",(void*)f_2665},
{"f_5643:c_2dplatform_2escm",(void*)f_5643},
{"f_2300:c_2dplatform_2escm",(void*)f_2300},
{"f_2674:c_2dplatform_2escm",(void*)f_2674},
{"f_2671:c_2dplatform_2escm",(void*)f_2671},
{"f_4104:c_2dplatform_2escm",(void*)f_4104},
{"f_2677:c_2dplatform_2escm",(void*)f_2677},
{"f_2575:c_2dplatform_2escm",(void*)f_2575},
{"f_2578:c_2dplatform_2escm",(void*)f_2578},
{"f_1675:c_2dplatform_2escm",(void*)f_1675},
{"f_1673:c_2dplatform_2escm",(void*)f_1673},
{"f_2683:c_2dplatform_2escm",(void*)f_2683},
{"f_1671:c_2dplatform_2escm",(void*)f_1671},
{"f_2680:c_2dplatform_2escm",(void*)f_2680},
{"f_2572:c_2dplatform_2escm",(void*)f_2572},
{"f_2303:c_2dplatform_2escm",(void*)f_2303},
{"f_2689:c_2dplatform_2escm",(void*)f_2689},
{"f_2307:c_2dplatform_2escm",(void*)f_2307},
{"f_2306:c_2dplatform_2escm",(void*)f_2306},
{"f_2686:c_2dplatform_2escm",(void*)f_2686},
{"f_3553:c_2dplatform_2escm",(void*)f_3553},
{"f_2587:c_2dplatform_2escm",(void*)f_2587},
{"f_3550:c_2dplatform_2escm",(void*)f_3550},
{"f_1668:c_2dplatform_2escm",(void*)f_1668},
{"f_1665:c_2dplatform_2escm",(void*)f_1665},
{"f_2692:c_2dplatform_2escm",(void*)f_2692},
{"f_1662:c_2dplatform_2escm",(void*)f_1662},
{"f_3547:c_2dplatform_2escm",(void*)f_3547},
{"f_3544:c_2dplatform_2escm",(void*)f_3544},
{"f_2584:c_2dplatform_2escm",(void*)f_2584},
{"f_2581:c_2dplatform_2escm",(void*)f_2581},
{"f_2695:c_2dplatform_2escm",(void*)f_2695},
{"f_2698:c_2dplatform_2escm",(void*)f_2698},
{"f_3016:c_2dplatform_2escm",(void*)f_3016},
{"f_3013:c_2dplatform_2escm",(void*)f_3013},
{"f_2620:c_2dplatform_2escm",(void*)f_2620},
{"f_3010:c_2dplatform_2escm",(void*)f_3010},
{"f_2623:c_2dplatform_2escm",(void*)f_2623},
{"f_3019:c_2dplatform_2escm",(void*)f_3019},
{"f_3556:c_2dplatform_2escm",(void*)f_3556},
{"f_2629:c_2dplatform_2escm",(void*)f_2629},
{"f_3559:c_2dplatform_2escm",(void*)f_3559},
{"f_2626:c_2dplatform_2escm",(void*)f_2626},
{"f_5658:c_2dplatform_2escm",(void*)f_5658},
{"f_3109:c_2dplatform_2escm",(void*)f_3109},
{"f_3106:c_2dplatform_2escm",(void*)f_3106},
{"f_3100:c_2dplatform_2escm",(void*)f_3100},
{"f_3103:c_2dplatform_2escm",(void*)f_3103},
{"f_2635:c_2dplatform_2escm",(void*)f_2635},
{"f_2632:c_2dplatform_2escm",(void*)f_2632},
{"f_4895:c_2dplatform_2escm",(void*)f_4895},
{"f_2638:c_2dplatform_2escm",(void*)f_2638},
{"f_3580:c_2dplatform_2escm",(void*)f_3580},
{"f_1634:c_2dplatform_2escm",(void*)f_1634},
{"f_2641:c_2dplatform_2escm",(void*)f_2641},
{"f_2644:c_2dplatform_2escm",(void*)f_2644},
{"f_2647:c_2dplatform_2escm",(void*)f_2647},
{"f_4791:c_2dplatform_2escm",(void*)f_4791},
{"f_3127:c_2dplatform_2escm",(void*)f_3127},
{"f_3121:c_2dplatform_2escm",(void*)f_3121},
{"f_3124:c_2dplatform_2escm",(void*)f_3124},
{"f_2650:c_2dplatform_2escm",(void*)f_2650},
{"f_2653:c_2dplatform_2escm",(void*)f_2653},
{"f_4459:c_2dplatform_2escm",(void*)f_4459},
{"f_2656:c_2dplatform_2escm",(void*)f_2656},
{"f_2659:c_2dplatform_2escm",(void*)f_2659},
{"f_3562:c_2dplatform_2escm",(void*)f_3562},
{"f_4769:c_2dplatform_2escm",(void*)f_4769},
{"f_3118:c_2dplatform_2escm",(void*)f_3118},
{"f_3112:c_2dplatform_2escm",(void*)f_3112},
{"f_3115:c_2dplatform_2escm",(void*)f_3115},
{"f_1656:c_2dplatform_2escm",(void*)f_1656},
{"f_1659:c_2dplatform_2escm",(void*)f_1659},
{"f_3571:c_2dplatform_2escm",(void*)f_3571},
{"f_3004:c_2dplatform_2escm",(void*)f_3004},
{"f_3001:c_2dplatform_2escm",(void*)f_3001},
{"f_3007:c_2dplatform_2escm",(void*)f_3007},
{"f_3565:c_2dplatform_2escm",(void*)f_3565},
{"f_3568:c_2dplatform_2escm",(void*)f_3568},
{"f_4345:c_2dplatform_2escm",(void*)f_4345},
{"f_4746:c_2dplatform_2escm",(void*)f_4746},
{"f_3541:c_2dplatform_2escm",(void*)f_3541},
{"f_3574:c_2dplatform_2escm",(void*)f_3574},
{"f_3577:c_2dplatform_2escm",(void*)f_3577},
{"f_3055:c_2dplatform_2escm",(void*)f_3055},
{"f_3052:c_2dplatform_2escm",(void*)f_3052},
{"f_3058:c_2dplatform_2escm",(void*)f_3058},
{"f_3022:c_2dplatform_2escm",(void*)f_3022},
{"f_3025:c_2dplatform_2escm",(void*)f_3025},
{"f_3028:c_2dplatform_2escm",(void*)f_3028},
{"f_3034:c_2dplatform_2escm",(void*)f_3034},
{"f_3037:c_2dplatform_2escm",(void*)f_3037},
{"f_3031:c_2dplatform_2escm",(void*)f_3031},
{"f_3190:c_2dplatform_2escm",(void*)f_3190},
{"f_3193:c_2dplatform_2escm",(void*)f_3193},
{"f_2191:c_2dplatform_2escm",(void*)f_2191},
{"f_2196:c_2dplatform_2escm",(void*)f_2196},
{"f_2194:c_2dplatform_2escm",(void*)f_2194},
{"f_2407:c_2dplatform_2escm",(void*)f_2407},
{"f_2404:c_2dplatform_2escm",(void*)f_2404},
{"f_3097:c_2dplatform_2escm",(void*)f_3097},
{"f_3094:c_2dplatform_2escm",(void*)f_3094},
{"f_3091:c_2dplatform_2escm",(void*)f_3091},
{"f_3196:c_2dplatform_2escm",(void*)f_3196},
{"f_3199:c_2dplatform_2escm",(void*)f_3199},
{"f_3067:c_2dplatform_2escm",(void*)f_3067},
{"f_3061:c_2dplatform_2escm",(void*)f_3061},
{"f_3172:c_2dplatform_2escm",(void*)f_3172},
{"f_3064:c_2dplatform_2escm",(void*)f_3064},
{"f_2410:c_2dplatform_2escm",(void*)f_2410},
{"f_3079:c_2dplatform_2escm",(void*)f_3079},
{"f_3076:c_2dplatform_2escm",(void*)f_3076},
{"f_3073:c_2dplatform_2escm",(void*)f_3073},
{"f_3181:c_2dplatform_2escm",(void*)f_3181},
{"f_3070:c_2dplatform_2escm",(void*)f_3070},
{"f_3175:c_2dplatform_2escm",(void*)f_3175},
{"f_3178:c_2dplatform_2escm",(void*)f_3178},
{"f_3043:c_2dplatform_2escm",(void*)f_3043},
{"f_3151:c_2dplatform_2escm",(void*)f_3151},
{"f_3049:c_2dplatform_2escm",(void*)f_3049},
{"f_3046:c_2dplatform_2escm",(void*)f_3046},
{"f_3040:c_2dplatform_2escm",(void*)f_3040},
{"f_3187:c_2dplatform_2escm",(void*)f_3187},
{"f_3184:c_2dplatform_2escm",(void*)f_3184},
{"f_3160:c_2dplatform_2escm",(void*)f_3160},
{"f_4317:c_2dplatform_2escm",(void*)f_4317},
{"f_3157:c_2dplatform_2escm",(void*)f_3157},
{"f_3154:c_2dplatform_2escm",(void*)f_3154},
{"f_3130:c_2dplatform_2escm",(void*)f_3130},
{"f_4320:c_2dplatform_2escm",(void*)f_4320},
{"f_5293:c_2dplatform_2escm",(void*)f_5293},
{"f_3169:c_2dplatform_2escm",(void*)f_3169},
{"f_3163:c_2dplatform_2escm",(void*)f_3163},
{"f_3166:c_2dplatform_2escm",(void*)f_3166},
{"f_3142:c_2dplatform_2escm",(void*)f_3142},
{"f_3139:c_2dplatform_2escm",(void*)f_3139},
{"f_3136:c_2dplatform_2escm",(void*)f_3136},
{"f_3133:c_2dplatform_2escm",(void*)f_3133},
{"f_3088:c_2dplatform_2escm",(void*)f_3088},
{"f_3085:c_2dplatform_2escm",(void*)f_3085},
{"f_3082:c_2dplatform_2escm",(void*)f_3082},
{"f_3337:c_2dplatform_2escm",(void*)f_3337},
{"f_3334:c_2dplatform_2escm",(void*)f_3334},
{"f_2489:c_2dplatform_2escm",(void*)f_2489},
{"f_2485:c_2dplatform_2escm",(void*)f_2485},
{"f_3331:c_2dplatform_2escm",(void*)f_3331},
{"f_3349:c_2dplatform_2escm",(void*)f_3349},
{"f_3343:c_2dplatform_2escm",(void*)f_3343},
{"f_3346:c_2dplatform_2escm",(void*)f_3346},
{"f_2377:c_2dplatform_2escm",(void*)f_2377},
{"f_3340:c_2dplatform_2escm",(void*)f_3340},
{"f_3397:c_2dplatform_2escm",(void*)f_3397},
{"f_3394:c_2dplatform_2escm",(void*)f_3394},
{"f_3391:c_2dplatform_2escm",(void*)f_3391},
{"f_4404:c_2dplatform_2escm",(void*)f_4404},
{"f_2202:c_2dplatform_2escm",(void*)f_2202},
{"f_4862:c_2dplatform_2escm",(void*)f_4862},
{"f_4696:c_2dplatform_2escm",(void*)f_4696},
{"f_4693:c_2dplatform_2escm",(void*)f_4693},
{"f_3376:c_2dplatform_2escm",(void*)f_3376},
{"f_3379:c_2dplatform_2escm",(void*)f_3379},
{"f_2214:c_2dplatform_2escm",(void*)f_2214},
{"f_3370:c_2dplatform_2escm",(void*)f_3370},
{"f_3373:c_2dplatform_2escm",(void*)f_3373},
{"f_3385:c_2dplatform_2escm",(void*)f_3385},
{"f_3388:c_2dplatform_2escm",(void*)f_3388},
{"f_2456:c_2dplatform_2escm",(void*)f_2456},
{"f_5252:c_2dplatform_2escm",(void*)f_5252},
{"f_5250:c_2dplatform_2escm",(void*)f_5250},
{"f_2893:c_2dplatform_2escm",(void*)f_2893},
{"f_3876:c_2dplatform_2escm",(void*)f_3876},
{"f_2896:c_2dplatform_2escm",(void*)f_2896},
{"f_2890:c_2dplatform_2escm",(void*)f_2890},
{"f_3879:c_2dplatform_2escm",(void*)f_3879},
{"f_2899:c_2dplatform_2escm",(void*)f_2899},
{"f_3382:c_2dplatform_2escm",(void*)f_3382},
{"f_3873:c_2dplatform_2escm",(void*)f_3873},
{"f_3870:c_2dplatform_2escm",(void*)f_3870},
{"f_3637:c_2dplatform_2escm",(void*)f_3637},
{"f_3631:c_2dplatform_2escm",(void*)f_3631},
{"f_3634:c_2dplatform_2escm",(void*)f_3634},
{"f_2860:c_2dplatform_2escm",(void*)f_2860},
{"f_2863:c_2dplatform_2escm",(void*)f_2863},
{"f_2343:c_2dplatform_2escm",(void*)f_2343},
{"f_2341:c_2dplatform_2escm",(void*)f_2341},
{"f_2338:c_2dplatform_2escm",(void*)f_2338},
{"f_2866:c_2dplatform_2escm",(void*)f_2866},
{"f_2869:c_2dplatform_2escm",(void*)f_2869},
{"f_3625:c_2dplatform_2escm",(void*)f_3625},
{"f_3628:c_2dplatform_2escm",(void*)f_3628},
{"f_3622:c_2dplatform_2escm",(void*)f_3622},
{"f_3619:c_2dplatform_2escm",(void*)f_3619},
{"f_3616:c_2dplatform_2escm",(void*)f_3616},
{"f_3613:c_2dplatform_2escm",(void*)f_3613},
{"f_3610:c_2dplatform_2escm",(void*)f_3610},
{"f_2881:c_2dplatform_2escm",(void*)f_2881},
{"f_2884:c_2dplatform_2escm",(void*)f_2884},
{"f_2887:c_2dplatform_2escm",(void*)f_2887},
{"f_2851:c_2dplatform_2escm",(void*)f_2851},
{"f_2854:c_2dplatform_2escm",(void*)f_2854},
{"f_2857:c_2dplatform_2escm",(void*)f_2857},
{"f_2821:c_2dplatform_2escm",(void*)f_2821},
{"f_2824:c_2dplatform_2escm",(void*)f_2824},
{"f_2827:c_2dplatform_2escm",(void*)f_2827},
{"f_3881:c_2dplatform_2escm",(void*)f_3881},
{"f_2875:c_2dplatform_2escm",(void*)f_2875},
{"f_2872:c_2dplatform_2escm",(void*)f_2872},
{"f_2878:c_2dplatform_2escm",(void*)f_2878},
{"f_4616:c_2dplatform_2escm",(void*)f_4616},
{"f_2842:c_2dplatform_2escm",(void*)f_2842},
{"f_3688:c_2dplatform_2escm",(void*)f_3688},
{"f_3685:c_2dplatform_2escm",(void*)f_3685},
{"f_4954:c_2dplatform_2escm",(void*)f_4954},
{"f_2848:c_2dplatform_2escm",(void*)f_2848},
{"f_2845:c_2dplatform_2escm",(void*)f_2845},
{"f_3682:c_2dplatform_2escm",(void*)f_3682},
{"f_5530:c_2dplatform_2escm",(void*)f_5530},
{"f_2812:c_2dplatform_2escm",(void*)f_2812},
{"f_3697:c_2dplatform_2escm",(void*)f_3697},
{"f_3694:c_2dplatform_2escm",(void*)f_3694},
{"f_5528:c_2dplatform_2escm",(void*)f_5528},
{"f_2815:c_2dplatform_2escm",(void*)f_2815},
{"f_2818:c_2dplatform_2escm",(void*)f_2818},
{"f_3691:c_2dplatform_2escm",(void*)f_3691},
{"f_5537:c_2dplatform_2escm",(void*)f_5537},
{"f_2833:c_2dplatform_2escm",(void*)f_2833},
{"f_2830:c_2dplatform_2escm",(void*)f_2830},
{"f_2839:c_2dplatform_2escm",(void*)f_2839},
{"f_2836:c_2dplatform_2escm",(void*)f_2836},
{"f_3226:c_2dplatform_2escm",(void*)f_3226},
{"f_3229:c_2dplatform_2escm",(void*)f_3229},
{"f_3220:c_2dplatform_2escm",(void*)f_3220},
{"f_3223:c_2dplatform_2escm",(void*)f_3223},
{"f_2806:c_2dplatform_2escm",(void*)f_2806},
{"f_2809:c_2dplatform_2escm",(void*)f_2809},
{"f_4999:c_2dplatform_2escm",(void*)f_4999},
{"f_2803:c_2dplatform_2escm",(void*)f_2803},
{"f_2800:c_2dplatform_2escm",(void*)f_2800},
{"f_3217:c_2dplatform_2escm",(void*)f_3217},
{"f_3607:c_2dplatform_2escm",(void*)f_3607},
{"f_3604:c_2dplatform_2escm",(void*)f_3604},
{"f_3211:c_2dplatform_2escm",(void*)f_3211},
{"f_3601:c_2dplatform_2escm",(void*)f_3601},
{"f_3214:c_2dplatform_2escm",(void*)f_3214},
{"f_3208:c_2dplatform_2escm",(void*)f_3208},
{"f_3205:c_2dplatform_2escm",(void*)f_3205},
{"f_3202:c_2dplatform_2escm",(void*)f_3202},
{"f_4077:c_2dplatform_2escm",(void*)f_4077},
{"f_4071:c_2dplatform_2escm",(void*)f_4071},
{"f_4074:c_2dplatform_2escm",(void*)f_4074},
{"f_4089:c_2dplatform_2escm",(void*)f_4089},
{"f_4086:c_2dplatform_2escm",(void*)f_4086},
{"f_4083:c_2dplatform_2escm",(void*)f_4083},
{"f_4080:c_2dplatform_2escm",(void*)f_4080},
{"f_2023:c_2dplatform_2escm",(void*)f_2023},
{"f_4374:c_2dplatform_2escm",(void*)f_4374},
{"f_2021:c_2dplatform_2escm",(void*)f_2021},
{"f_5448:c_2dplatform_2escm",(void*)f_5448},
{"f_4094:c_2dplatform_2escm",(void*)f_4094},
{"f_4092:c_2dplatform_2escm",(void*)f_4092},
{"f_5452:c_2dplatform_2escm",(void*)f_5452},
{"f_3529:c_2dplatform_2escm",(void*)f_3529},
{"f_3526:c_2dplatform_2escm",(void*)f_3526},
{"f_3523:c_2dplatform_2escm",(void*)f_3523},
{"f_3520:c_2dplatform_2escm",(void*)f_3520},
{"f_4038:c_2dplatform_2escm",(void*)f_4038},
{"f_4031:c_2dplatform_2escm",(void*)f_4031},
{"f_4035:c_2dplatform_2escm",(void*)f_4035},
{"f_4047:c_2dplatform_2escm",(void*)f_4047},
{"f_5478:c_2dplatform_2escm",(void*)f_5478},
{"f_4041:c_2dplatform_2escm",(void*)f_4041},
{"f_4044:c_2dplatform_2escm",(void*)f_4044},
{"f_3427:c_2dplatform_2escm",(void*)f_3427},
{"f_4059:c_2dplatform_2escm",(void*)f_4059},
{"f_4056:c_2dplatform_2escm",(void*)f_4056},
{"f_3421:c_2dplatform_2escm",(void*)f_3421},
{"f_3424:c_2dplatform_2escm",(void*)f_3424},
{"f_4050:c_2dplatform_2escm",(void*)f_4050},
{"f_4053:c_2dplatform_2escm",(void*)f_4053},
{"f_2279:c_2dplatform_2escm",(void*)f_2279},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		1
S|  for-each		1
o|eliminated procedure checks: 58 
o|specializations:
o|  2 (eqv? (not float) *)
o|  1 (memq * list)
o|  17 (= fixnum fixnum)
o|  3 (>= fixnum fixnum)
o|  3 (cdr pair)
o|  2 (car pair)
o|  6 (first pair)
o|  1 (##sys#check-list (or pair list) *)
(o e)|safe calls: 418 
o|safe globals: (##compiler#non-foldable-bindings ##compiler#internal-bindings ##compiler#default-extended-bindings ##compiler#default-standard-bindings ##compiler#valid-compiler-options-with-argument ##compiler#valid-compiler-options ##compiler#target-include-file ##compiler#membership-unfold-limit ##compiler#membership-test-operators ##compiler#eq-inline-operator ##compiler#unlikely-variables ##compiler#words-per-flonum ##compiler#units-used-by-default ##compiler#default-profiling-declarations ##compiler#default-debugging-declarations ##compiler#default-declarations ##compiler#default-optimization-passes) 
o|Removed `not' forms: 3 
o|inlining procedure: k1677 
o|contracted procedure: "(c-platform.scm:369) g258259" 
o|inlining procedure: k1700 
o|contracted procedure: "(c-platform.scm:374) g263264" 
o|inlining procedure: k1719 
o|inlining procedure: k1719 
o|inlining procedure: k1700 
o|contracted procedure: "(c-platform.scm:375) g268269" 
o|inlining procedure: k1677 
o|substituted constant variable: a1750 
o|inlining procedure: k1760 
o|inlining procedure: k1778 
o|contracted procedure: "(c-platform.scm:396) g324325" 
o|contracted procedure: "(c-platform.scm:398) g329330" 
o|inlining procedure: k1778 
o|inlining procedure: k1812 
o|contracted procedure: "(c-platform.scm:395) g321322" 
o|inlining procedure: k1812 
o|contracted procedure: "(c-platform.scm:394) g318319" 
o|contracted procedure: "(c-platform.scm:393) g314315" 
o|contracted procedure: "(c-platform.scm:392) g311312" 
o|inlining procedure: k1882 
o|contracted procedure: "(c-platform.scm:391) g301302" 
o|contracted procedure: "(c-platform.scm:390) g298299" 
o|contracted procedure: "(c-platform.scm:390) g295296" 
o|inlining procedure: k1882 
o|contracted procedure: "(c-platform.scm:389) g291292" 
o|contracted procedure: "(c-platform.scm:388) g287288" 
o|inlining procedure: k1760 
o|substituted constant variable: a1954 
o|inlining procedure: k1967 
o|contracted procedure: "(c-platform.scm:438) g426427" 
o|inlining procedure: k2025 
o|inlining procedure: k2025 
o|contracted procedure: "(c-platform.scm:442) g450451" 
o|inlining procedure: k2072 
o|inlining procedure: k2072 
o|contracted procedure: "(c-platform.scm:453) g487488" 
o|contracted procedure: "(c-platform.scm:455) g492493" 
o|inlining procedure: k2103 
o|substituted constant variable: a2116 
o|inlining procedure: k2117 
o|contracted procedure: "(c-platform.scm:448) g477478" 
o|contracted procedure: "(c-platform.scm:450) g482483" 
o|inlining procedure: k2117 
o|contracted procedure: "(c-platform.scm:447) g474475" 
o|contracted procedure: "(c-platform.scm:445) g469470" 
o|inlining procedure: k2103 
o|substituted constant variable: a2166 
o|contracted procedure: "(c-platform.scm:443) g464465" 
o|contracted procedure: "(c-platform.scm:437) g423424" 
o|inlining procedure: k1967 
o|inlining procedure: k2204 
o|contracted procedure: "(c-platform.scm:471) g510511" 
o|inlining procedure: k2236 
o|contracted procedure: "(c-platform.scm:475) g520521" 
o|inlining procedure: k2236 
o|contracted procedure: "(c-platform.scm:476) g525526" 
o|inlining procedure: k2204 
o|substituted constant variable: a2276 
o|inlining procedure: k2309 
o|contracted procedure: "(c-platform.scm:494) g546547" 
o|inlining procedure: k2309 
o|substituted constant variable: a2335 
o|inlining procedure: k2345 
o|inlining procedure: k2363 
o|inlining procedure: k2378 
o|inlining procedure: k2390 
o|contracted procedure: "(c-platform.scm:516) g588589" 
o|contracted procedure: "(c-platform.scm:524) g603604" 
o|contracted procedure: "(c-platform.scm:518) g593594" 
o|contracted procedure: "(c-platform.scm:521) g598599" 
o|contracted procedure: "(c-platform.scm:515) g585586" 
o|substituted constant variable: a2503 
o|inlining procedure: k2390 
o|contracted procedure: "(c-platform.scm:510) g578579" 
o|contracted procedure: "(c-platform.scm:509) g574575" 
o|inlining procedure: k2378 
o|contracted procedure: "(c-platform.scm:507) g569570" 
o|inlining procedure: k2363 
o|contracted procedure: "(c-platform.scm:506) g565566" 
o|contracted procedure: "(c-platform.scm:505) g561562" 
o|inlining procedure: k2345 
o|substituted constant variable: a2553 
o|inlining procedure: k3740 
o|inlining procedure: k3759 
o|contracted procedure: "(c-platform.scm:1041) g725726" 
o|contracted procedure: "(c-platform.scm:1045) g730731" 
o|contracted procedure: "(c-platform.scm:1048) g735736" 
o|contracted procedure: "(c-platform.scm:1040) g720721" 
o|inlining procedure: k3759 
o|contracted procedure: "(c-platform.scm:1035) g714715" 
o|contracted procedure: "(c-platform.scm:1033) g709710" 
o|inlining procedure: k3740 
o|inlining procedure: k3883 
o|inlining procedure: k3901 
o|inlining procedure: k3919 
o|contracted procedure: k3931 
o|contracted procedure: k3937 
o|inlining procedure: k3934 
o|inlining procedure: k3934 
o|contracted procedure: k3943 
o|contracted procedure: "(c-platform.scm:1075) g776777" 
o|inlining procedure: k3919 
o|contracted procedure: "(c-platform.scm:1066) g762763" 
o|contracted procedure: "(c-platform.scm:1065) g758759" 
o|inlining procedure: k3901 
o|contracted procedure: "(c-platform.scm:1064) g755756" 
o|contracted procedure: "(c-platform.scm:1063) g751752" 
o|inlining procedure: k3883 
o|substituted constant variable: a4021 
o|inlining procedure: k4096 
o|contracted procedure: "(c-platform.scm:1188) g872873" 
o|contracted procedure: "(c-platform.scm:1192) g877878" 
o|contracted procedure: "(c-platform.scm:1195) g882883" 
o|inlining procedure: k4096 
o|substituted constant variable: a4163 
o|inlining procedure: k4171 
o|contracted procedure: "(c-platform.scm:1171) g851852" 
o|contracted procedure: "(c-platform.scm:1174) g856857" 
o|contracted procedure: "(c-platform.scm:1177) g861862" 
o|inlining procedure: k4171 
o|substituted constant variable: a4231 
o|inlining procedure: k4239 
o|contracted procedure: "(c-platform.scm:1148) g836837" 
o|contracted procedure: "(c-platform.scm:1151) g841842" 
o|inlining procedure: k4275 
o|inlining procedure: k4275 
o|inlining procedure: k4239 
o|substituted constant variable: a4281 
o|inlining procedure: k4289 
o|contracted procedure: "(c-platform.scm:1134) g814815" 
o|inlining procedure: k4315 
o|inlining procedure: k4315 
o|contracted procedure: "(c-platform.scm:1140) g826827" 
o|contracted procedure: "(c-platform.scm:1138) g823824" 
o|contracted procedure: "(c-platform.scm:1137) g820821" 
o|inlining procedure: k4289 
o|substituted constant variable: a4368 
o|inlining procedure: k4376 
o|inlining procedure: k4394 
o|contracted procedure: "(c-platform.scm:1118) g803804" 
o|substituted constant variable: setter-map 
o|inlining procedure: k4394 
o|contracted procedure: "(c-platform.scm:1116) g799800" 
o|contracted procedure: "(c-platform.scm:1115) g795796" 
o|contracted procedure: "(c-platform.scm:1114) g791792" 
o|inlining procedure: k4376 
o|substituted constant variable: a4453 
o|inlining procedure: k4461 
o|contracted procedure: "(c-platform.scm:934) g664665" 
o|inlining procedure: k4490 
o|inlining procedure: k4490 
o|contracted procedure: "(c-platform.scm:949) g690691" 
o|contracted procedure: "(c-platform.scm:950) g695696" 
o|inlining procedure: k4522 
o|inlining procedure: k4534 
o|contracted procedure: "(c-platform.scm:942) g680681" 
o|contracted procedure: "(c-platform.scm:945) g685686" 
o|inlining procedure: k4534 
o|contracted procedure: "(c-platform.scm:939) g676677" 
o|inlining procedure: k4522 
o|contracted procedure: "(c-platform.scm:937) g672673" 
o|inlining procedure: k4461 
o|substituted constant variable: a4610 
o|inlining procedure: k4618 
o|contracted procedure: "(c-platform.scm:902) g640641" 
o|contracted procedure: "(c-platform.scm:905) g645646" 
o|inlining procedure: k4656 
o|contracted procedure: "(c-platform.scm:909) g655656" 
o|inlining procedure: k4656 
o|contracted procedure: "(c-platform.scm:908) g652653" 
o|inlining procedure: k4618 
o|substituted constant variable: a4691 
o|contracted procedure: "(c-platform.scm:854) g623624" 
o|contracted procedure: "(c-platform.scm:857) g628629" 
o|inlining procedure: k4730 
o|inlining procedure: k4730 
o|substituted constant variable: a4765 
o|substituted constant variable: a4767 
o|inlining procedure: k4771 
o|inlining procedure: k4792 
o|inlining procedure: k4792 
o|contracted procedure: "(c-platform.scm:424) g405406" 
o|contracted procedure: "(c-platform.scm:426) g410411" 
o|contracted procedure: "(c-platform.scm:421) g395396" 
o|contracted procedure: "(c-platform.scm:423) g400401" 
o|inlining procedure: k4851 
o|contracted procedure: "(c-platform.scm:419) g389390" 
o|inlining procedure: k4851 
o|contracted procedure: "(c-platform.scm:418) g385386" 
o|inlining procedure: k4896 
o|inlining procedure: k4896 
o|contracted procedure: "(c-platform.scm:416) g378379" 
o|contracted procedure: "(c-platform.scm:415) g374375" 
o|inlining procedure: k4923 
o|contracted procedure: "(c-platform.scm:414) g361362" 
o|contracted procedure: "(c-platform.scm:413) g358359" 
o|contracted procedure: "(c-platform.scm:413) g355356" 
o|inlining procedure: k4923 
o|contracted procedure: "(c-platform.scm:412) g351352" 
o|contracted procedure: "(c-platform.scm:411) g347348" 
o|inlining procedure: k4771 
o|substituted constant variable: a4995 
o|inlining procedure: k5007 
o|contracted procedure: "(c-platform.scm:346) g216217" 
o|inlining procedure: k5039 
o|contracted procedure: "(c-platform.scm:352) g229230" 
o|inlining procedure: k5039 
o|contracted procedure: "(c-platform.scm:355) g234235" 
o|contracted procedure: "(c-platform.scm:351) g226227" 
o|contracted procedure: "(c-platform.scm:350) g223224" 
o|contracted procedure: "(c-platform.scm:356) g239240" 
o|contracted procedure: "(c-platform.scm:358) g244245" 
o|inlining procedure: k5007 
o|substituted constant variable: a5128 
o|inlining procedure: k5132 
o|inlining procedure: k5147 
o|contracted procedure: "(c-platform.scm:327) g187188" 
o|inlining procedure: k5176 
o|contracted procedure: "(c-platform.scm:334) g201202" 
o|inlining procedure: k5176 
o|contracted procedure: "(c-platform.scm:335) g206207" 
o|contracted procedure: "(c-platform.scm:333) g198199" 
o|contracted procedure: "(c-platform.scm:333) g195196" 
o|inlining procedure: k5147 
o|substituted constant variable: a5242 
o|inlining procedure: k5254 
o|contracted procedure: "(c-platform.scm:323) g182183" 
o|inlining procedure: k5254 
o|contracted procedure: "(c-platform.scm:322) g179180" 
o|inlining procedure: k5132 
o|substituted constant variable: a5291 
o|inlining procedure: k5295 
o|inlining procedure: k5295 
o|contracted procedure: "(c-platform.scm:284) g138139" 
o|contracted procedure: "(c-platform.scm:287) g143144" 
o|inlining procedure: k5339 
o|contracted procedure: "(c-platform.scm:300) g159160" 
o|contracted procedure: "(c-platform.scm:306) g166167" 
o|substituted constant variable: a5394 
o|inlining procedure: k5339 
o|inlining procedure: k5404 
o|contracted procedure: "(c-platform.scm:296) g154155" 
o|inlining procedure: k5404 
o|contracted procedure: "(c-platform.scm:295) g151152" 
o|inlining procedure: k5453 
o|contracted procedure: "(c-platform.scm:257) g9596" 
o|inlining procedure: k5453 
o|contracted procedure: "(c-platform.scm:259) g100101" 
o|inlining procedure: k5503 
o|contracted procedure: "(c-platform.scm:261) g105106" 
o|inlining procedure: k5532 
o|contracted procedure: "(c-platform.scm:268) g119120" 
o|inlining procedure: k5532 
o|contracted procedure: "(c-platform.scm:269) g124125" 
o|contracted procedure: "(c-platform.scm:267) g116117" 
o|contracted procedure: "(c-platform.scm:267) g113114" 
o|inlining procedure: k5503 
o|inlining procedure: k5601 
o|contracted procedure: "(c-platform.scm:255) g8889" 
o|inlining procedure: k5601 
o|contracted procedure: "(c-platform.scm:254) g8586" 
o|inlining procedure: k5635 
o|contracted procedure: "(c-platform.scm:227) g4350" 
o|contracted procedure: "(c-platform.scm:228) g5859" 
o|inlining procedure: k5635 
o|simplifications: ((if . 1)) 
o|replaced variables: 520 
o|removed binding forms: 609 
o|substituted constant variable: c260 
o|substituted constant variable: c265 
o|substituted constant variable: c270 
o|substituted constant variable: r16785668 
o|substituted constant variable: c326 
o|substituted constant variable: c331 
o|substituted constant variable: p332 
o|substituted constant variable: r17795671 
o|substituted constant variable: r18135673 
o|substituted constant variable: c303 
o|substituted constant variable: r18835675 
o|substituted constant variable: r17615676 
o|substituted constant variable: c428 
o|substituted constant variable: c489 
o|substituted constant variable: c494 
o|substituted constant variable: p495 
o|substituted constant variable: s496 
o|substituted constant variable: c479 
o|substituted constant variable: c484 
o|substituted constant variable: p485 
o|substituted constant variable: s486 
o|substituted constant variable: r21185684 
o|substituted constant variable: r21045686 
o|substituted constant variable: r19685687 
o|substituted constant variable: c512 
o|substituted constant variable: c522 
o|substituted constant variable: c527 
o|substituted constant variable: r22055693 
o|substituted constant variable: c548 
o|substituted constant variable: r23105695 
o|substituted constant variable: c590 
o|substituted constant variable: c605 
o|substituted constant variable: c595 
o|substituted constant variable: c600 
o|substituted constant variable: r23915700 
o|substituted constant variable: r23795701 
o|substituted constant variable: r23645702 
o|substituted constant variable: r23465703 
o|substituted constant variable: c727 
o|substituted constant variable: c732 
o|substituted constant variable: c737 
o|substituted constant variable: c722 
o|substituted constant variable: p723 
o|substituted constant variable: s724 
o|substituted constant variable: r37605706 
o|substituted constant variable: r37415707 
o|substituted constant variable: r39355711 
o|substituted constant variable: c778 
o|substituted constant variable: r39205713 
o|substituted constant variable: r39025714 
o|substituted constant variable: r38845715 
o|removed side-effect free assignment to unused variable: setter-map 
o|substituted constant variable: c874 
o|substituted constant variable: c879 
o|substituted constant variable: c884 
o|substituted constant variable: p885 
o|substituted constant variable: r40975717 
o|substituted constant variable: c853 
o|substituted constant variable: c858 
o|substituted constant variable: p859 
o|substituted constant variable: c863 
o|substituted constant variable: p864 
o|substituted constant variable: r41725719 
o|substituted constant variable: c838 
o|substituted constant variable: c843 
o|substituted constant variable: r42765721 
o|substituted constant variable: r42765721 
o|substituted constant variable: r42765723 
o|substituted constant variable: r42765723 
o|substituted constant variable: r42405725 
o|substituted constant variable: c816 
o|substituted constant variable: c828 
o|substituted constant variable: p829 
o|substituted constant variable: r42905731 
o|substituted constant variable: c805 
o|substituted constant variable: r43955734 
o|substituted constant variable: r43775735 
o|converted assignments to bindings: (rewrite-call/cc743) 
o|converted assignments to bindings: (rewrite-make-vector700) 
o|substituted constant variable: c666 
o|substituted constant variable: c692 
o|substituted constant variable: p693 
o|substituted constant variable: c697 
o|substituted constant variable: c682 
o|substituted constant variable: p683 
o|substituted constant variable: c687 
o|substituted constant variable: p688 
o|substituted constant variable: r45355743 
o|substituted constant variable: r45235744 
o|substituted constant variable: r44625745 
o|substituted constant variable: c642 
o|substituted constant variable: c647 
o|substituted constant variable: r46575748 
o|substituted constant variable: r46195749 
o|substituted constant variable: c625 
o|substituted constant variable: c630 
o|substituted constant variable: p631 
o|converted assignments to bindings: (build620) 
o|converted assignments to bindings: (rewrite-c-w-v552) 
o|converted assignments to bindings: (rewrite-c..r499) 
o|converted assignments to bindings: (rewrite-apply415) 
o|substituted constant variable: c407 
o|substituted constant variable: c412 
o|substituted constant variable: p413 
o|substituted constant variable: c397 
o|substituted constant variable: c402 
o|substituted constant variable: p403 
o|substituted constant variable: r48525756 
o|substituted constant variable: c363 
o|substituted constant variable: r49245760 
o|substituted constant variable: r47725761 
o|converted assignments to bindings: (eqv?-id275) 
o|converted assignments to bindings: (op1249) 
o|substituted constant variable: c218 
o|substituted constant variable: c231 
o|substituted constant variable: p232 
o|substituted constant variable: c236 
o|substituted constant variable: p237 
o|substituted constant variable: c241 
o|substituted constant variable: c246 
o|substituted constant variable: p247 
o|substituted constant variable: s248 
o|substituted constant variable: r50085767 
o|substituted constant variable: c189 
o|substituted constant variable: c203 
o|substituted constant variable: p204 
o|substituted constant variable: c208 
o|substituted constant variable: p209 
o|substituted constant variable: r51485772 
o|substituted constant variable: r52555774 
o|substituted constant variable: r51335775 
o|substituted constant variable: r52965776 
o|substituted constant variable: c140 
o|substituted constant variable: c145 
o|substituted constant variable: c161 
o|substituted constant variable: c168 
o|substituted constant variable: r53405779 
o|substituted constant variable: r54055781 
o|substituted constant variable: c97 
o|substituted constant variable: c102 
o|substituted constant variable: c107 
o|substituted constant variable: c121 
o|substituted constant variable: p122 
o|substituted constant variable: c126 
o|substituted constant variable: p127 
o|substituted constant variable: r55045787 
o|substituted constant variable: r56025789 
o|substituted constant variable: mark66 
o|substituted constant variable: g4951 
o|simplifications: ((let . 8)) 
o|replaced variables: 84 
o|removed binding forms: 524 
o|removed conditional forms: 1 
o|inlining procedure: k4653 
o|inlining procedure: k4653 
o|inlining procedure: k4653 
o|inlining procedure: k5333 
o|inlining procedure: k5333 
o|inlining procedure: k1639 
o|replaced variables: 151 
o|removed binding forms: 225 
o|substituted constant variable: r46545806 
o|substituted constant variable: r46545806 
o|substituted constant variable: r46545811 
o|substituted constant variable: r46545811 
o|substituted constant variable: r46545816 
o|substituted constant variable: r46545816 
o|substituted constant variable: r53345821 
o|substituted constant variable: r53345821 
o|substituted constant variable: r53345826 
o|substituted constant variable: r53345826 
o|substituted constant variable: r16405831 
o|replaced variables: 5 
o|removed binding forms: 154 
o|removed binding forms: 16 
o|simplifications: ((if . 7) (##core#call . 390)) 
o|  call simplifications:
o|    null?	5
o|    zero?
o|    fx>=	3
o|    symbol?	2
o|    negative?
o|    -
o|    assq
o|    =
o|    fixnum?	2
o|    <=
o|    add1
o|    third	4
o|    proper-list?
o|    cadr	2
o|    cdr	4
o|    ##sys#check-list
o|    pair?	5
o|    cons	5
o|    ##sys#setslot
o|    second	9
o|    equal?	2
o|    ##sys#slot	57
o|    first	23
o|    flonum?	2
o|    not	4
o|    length	22
o|    eq?	59
o|    car	10
o|    list	91
o|    ##sys#make-structure	69
o|contracted procedure: k1747 
o|contracted procedure: k1680 
o|contracted procedure: k1692 
o|contracted procedure: k1696 
o|contracted procedure: k1703 
o|inlining procedure: k1715 
o|inlining procedure: k1715 
o|contracted procedure: k1731 
o|contracted procedure: k1739 
o|contracted procedure: k1735 
o|contracted procedure: k1951 
o|contracted procedure: k1763 
o|contracted procedure: k1766 
o|contracted procedure: k1769 
o|contracted procedure: k1796 
o|contracted procedure: k1809 
o|contracted procedure: k1800 
o|contracted procedure: k1844 
o|contracted procedure: k1815 
o|contracted procedure: k1835 
o|contracted procedure: k1826 
o|contracted procedure: k1822 
o|contracted procedure: k1876 
o|contracted procedure: k1847 
o|contracted procedure: k1867 
o|contracted procedure: k1858 
o|contracted procedure: k1854 
o|contracted procedure: k1947 
o|contracted procedure: k1879 
o|contracted procedure: k1938 
o|contracted procedure: k1885 
o|contracted procedure: k1920 
o|contracted procedure: k1929 
o|contracted procedure: k1891 
o|contracted procedure: k1903 
o|contracted procedure: k1907 
o|contracted procedure: k1970 
o|contracted procedure: k2186 
o|contracted procedure: k1980 
o|contracted procedure: k1992 
o|contracted procedure: k2006 
o|contracted procedure: k2010 
o|contracted procedure: k2062 
o|contracted procedure: k2013 
o|contracted procedure: k2016 
o|contracted procedure: k2028 
o|contracted procedure: k2031 
o|contracted procedure: k2034 
o|contracted procedure: k2042 
o|contracted procedure: k2050 
o|contracted procedure: k2084 
o|contracted procedure: k2097 
o|contracted procedure: k2177 
o|contracted procedure: k2100 
o|contracted procedure: k2168 
o|contracted procedure: k2106 
o|contracted procedure: k2163 
o|contracted procedure: k2109 
o|contracted procedure: k2137 
o|contracted procedure: k2150 
o|contracted procedure: k2154 
o|contracted procedure: k2141 
o|contracted procedure: k2273 
o|contracted procedure: k2207 
o|contracted procedure: k2216 
o|contracted procedure: k2228 
o|contracted procedure: k2232 
o|contracted procedure: k2239 
o|contracted procedure: k2251 
o|contracted procedure: k2266 
o|contracted procedure: k2332 
o|contracted procedure: k2312 
o|contracted procedure: k2324 
o|contracted procedure: k2328 
o|contracted procedure: k2555 
o|contracted procedure: k2348 
o|contracted procedure: k2351 
o|contracted procedure: k2354 
o|contracted procedure: k2550 
o|contracted procedure: k2360 
o|contracted procedure: k2541 
o|contracted procedure: k2366 
o|contracted procedure: k2532 
o|contracted procedure: k2369 
o|contracted procedure: k2523 
o|contracted procedure: k2384 
o|contracted procedure: k2514 
o|contracted procedure: k2387 
o|contracted procedure: k2393 
o|contracted procedure: k2505 
o|contracted procedure: k2399 
o|contracted procedure: k2420 
o|contracted procedure: k2491 
o|contracted procedure: k2458 
o|contracted procedure: k2475 
o|contracted procedure: k2479 
o|contracted procedure: k2471 
o|contracted procedure: k2462 
o|contracted procedure: k2433 
o|contracted procedure: k2446 
o|contracted procedure: k2450 
o|contracted procedure: k2442 
o|contracted procedure: k2424 
o|contracted procedure: k2500 
o|contracted procedure: k3737 
o|contracted procedure: k3743 
o|contracted procedure: k3865 
o|contracted procedure: k3750 
o|contracted procedure: k3856 
o|contracted procedure: k3756 
o|contracted procedure: k3762 
o|contracted procedure: k3834 
o|contracted procedure: k3771 
o|contracted procedure: k3783 
o|contracted procedure: k3800 
o|contracted procedure: k3831 
o|contracted procedure: k3817 
o|contracted procedure: k3813 
o|contracted procedure: k3804 
o|contracted procedure: k3796 
o|contracted procedure: k3787 
o|contracted procedure: k4023 
o|contracted procedure: k3886 
o|contracted procedure: k3889 
o|contracted procedure: k4018 
o|contracted procedure: k3895 
o|contracted procedure: k3996 
o|contracted procedure: k3907 
o|contracted procedure: k3987 
o|contracted procedure: k3910 
o|contracted procedure: k3922 
o|contracted procedure: k3925 
o|contracted procedure: k3955 
o|contracted procedure: k3959 
o|contracted procedure: k4009 
o|contracted procedure: k4000 
o|contracted procedure: k4165 
o|contracted procedure: k4099 
o|contracted procedure: k4114 
o|contracted procedure: k4122 
o|contracted procedure: k4135 
o|contracted procedure: k4156 
o|contracted procedure: k4152 
o|contracted procedure: k4148 
o|contracted procedure: k4139 
o|contracted procedure: k4131 
o|contracted procedure: k4118 
o|contracted procedure: k4233 
o|contracted procedure: k4174 
o|contracted procedure: k4186 
o|contracted procedure: k4224 
o|contracted procedure: k4228 
o|contracted procedure: k4220 
o|contracted procedure: k4212 
o|contracted procedure: k4216 
o|contracted procedure: k4203 
o|contracted procedure: k4199 
o|contracted procedure: k4190 
o|contracted procedure: k4283 
o|contracted procedure: k4242 
o|contracted procedure: k4254 
o|contracted procedure: k4278 
o|contracted procedure: k4271 
o|contracted procedure: k4267 
o|contracted procedure: k4258 
o|contracted procedure: k4370 
o|contracted procedure: k4292 
o|contracted procedure: k4295 
o|contracted procedure: k4307 
o|contracted procedure: k4311 
o|contracted procedure: k4333 
o|contracted procedure: k4365 
o|contracted procedure: k4336 
o|contracted procedure: k4356 
o|contracted procedure: k4347 
o|contracted procedure: k4455 
o|contracted procedure: k4379 
o|contracted procedure: k4382 
o|contracted procedure: k4450 
o|contracted procedure: k4388 
o|contracted procedure: k4441 
o|contracted procedure: k4391 
o|contracted procedure: k4405 
o|contracted procedure: k4420 
o|contracted procedure: k4424 
o|contracted procedure: k4432 
o|contracted procedure: k4612 
o|contracted procedure: k4464 
o|contracted procedure: k4467 
o|contracted procedure: k4479 
o|inlining procedure: k4483 
o|inlining procedure: k4483 
o|contracted procedure: k4496 
o|contracted procedure: k4516 
o|contracted procedure: k4607 
o|contracted procedure: k4519 
o|contracted procedure: k4525 
o|contracted procedure: k4598 
o|contracted procedure: k4528 
o|contracted procedure: k4543 
o|contracted procedure: k4555 
o|contracted procedure: k4577 
o|contracted procedure: k4582 
o|contracted procedure: k4688 
o|contracted procedure: k4621 
o|contracted procedure: k4633 
o|contracted procedure: k4637 
o|contracted procedure: k4650 
o|contracted procedure: k4684 
o|contracted procedure: k4659 
o|contracted procedure: k4675 
o|contracted procedure: k4666 
o|contracted procedure: k4707 
o|contracted procedure: k4724 
o|contracted procedure: k4720 
o|contracted procedure: k4711 
o|contracted procedure: k4727 
o|contracted procedure: k4733 
o|contracted procedure: k4740 
o|contracted procedure: k4750 
o|contracted procedure: k4757 
o|contracted procedure: k4761 
o|contracted procedure: k4992 
o|contracted procedure: k4774 
o|contracted procedure: k4777 
o|contracted procedure: k4780 
o|contracted procedure: k4804 
o|contracted procedure: k4817 
o|contracted procedure: k4808 
o|contracted procedure: k4835 
o|contracted procedure: k4848 
o|contracted procedure: k4839 
o|contracted procedure: k4884 
o|contracted procedure: k4854 
o|contracted procedure: k4875 
o|contracted procedure: k4857 
o|contracted procedure: k4917 
o|contracted procedure: k4887 
o|contracted procedure: k4908 
o|contracted procedure: k4890 
o|contracted procedure: k4988 
o|contracted procedure: k4920 
o|contracted procedure: k4979 
o|contracted procedure: k4926 
o|contracted procedure: k4961 
o|contracted procedure: k4970 
o|contracted procedure: k4932 
o|contracted procedure: k4944 
o|contracted procedure: k4948 
o|contracted procedure: k5125 
o|contracted procedure: k5010 
o|contracted procedure: k5016 
o|contracted procedure: k5028 
o|contracted procedure: k5032 
o|contracted procedure: k5035 
o|contracted procedure: k5054 
o|contracted procedure: k5096 
o|contracted procedure: k5071 
o|contracted procedure: k5087 
o|contracted procedure: k5078 
o|contracted procedure: k5108 
o|contracted procedure: k5121 
o|contracted procedure: k5288 
o|contracted procedure: k5135 
o|contracted procedure: k5244 
o|contracted procedure: k5138 
o|contracted procedure: k5144 
o|contracted procedure: k5239 
o|contracted procedure: k5150 
o|contracted procedure: k5162 
o|contracted procedure: k5166 
o|contracted procedure: k5191 
o|contracted procedure: k5207 
o|contracted procedure: k5235 
o|contracted procedure: k5210 
o|contracted procedure: k5226 
o|contracted procedure: k5217 
o|contracted procedure: k5282 
o|contracted procedure: k5257 
o|contracted procedure: k5273 
o|contracted procedure: k5264 
o|contracted procedure: k5298 
o|contracted procedure: k5444 
o|contracted procedure: k5437 
o|contracted procedure: k5304 
o|contracted procedure: k5316 
o|contracted procedure: k5320 
o|contracted procedure: k5336 
o|contracted procedure: k5342 
o|contracted procedure: k5391 
o|contracted procedure: k5348 
o|contracted procedure: k5360 
o|contracted procedure: k5364 
o|contracted procedure: k5383 
o|contracted procedure: k5387 
o|contracted procedure: k5432 
o|contracted procedure: k5407 
o|contracted procedure: k5423 
o|contracted procedure: k5414 
o|contracted procedure: k5456 
o|contracted procedure: k5468 
o|contracted procedure: k5472 
o|contracted procedure: k5595 
o|contracted procedure: k5482 
o|contracted procedure: k5494 
o|contracted procedure: k5498 
o|contracted procedure: k5506 
o|contracted procedure: k5518 
o|contracted procedure: k5522 
o|contracted procedure: k5547 
o|contracted procedure: k5563 
o|contracted procedure: k5591 
o|contracted procedure: k5566 
o|contracted procedure: k5582 
o|contracted procedure: k5573 
o|contracted procedure: k5629 
o|contracted procedure: k5604 
o|contracted procedure: k5620 
o|contracted procedure: k5611 
o|contracted procedure: k5638 
o|contracted procedure: k5648 
o|contracted procedure: k5652 
o|contracted procedure: k1645 
o|contracted procedure: k1639 
o|simplifications: ((let . 19)) 
o|removed binding forms: 320 
o|inlining procedure: k1700 
o|inlining procedure: k1700 
o|inlining procedure: k1700 
o|inlining procedure: k2236 
o|inlining procedure: k2236 
o|inlining procedure: k4315 
o|inlining procedure: k4490 
o|inlining procedure: k4490 
o|inlining procedure: k4646 
o|inlining procedure: k4646 
o|inlining procedure: k4646 
o|inlining procedure: k5039 
o|inlining procedure: k5039 
o|inlining procedure: k5329 
o|inlining procedure: k5329 
o|replaced variables: 58 
o|removed binding forms: 2 
o|removed binding forms: 43 
o|replaced variables: 2 
o|removed binding forms: 1 
o|direct leaf routine/allocation: build620 25 
o|customizable procedures: (for-each-loop4273 k5535 k5179 k5042 op1249 k4783 k4820 k4823 k4789 rewrite-c..r499 k4537 k4487 k4318 k2069 map-loop433453 k1772 k1781 k1784) 
o|calls to known targets: 58 
o|fast box initializations: 2 
o|dropping unused closure argument: f_1673 
o|dropping unused closure argument: f_2196 
*/
/* end of file */
