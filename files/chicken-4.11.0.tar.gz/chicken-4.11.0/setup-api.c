/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: setup-api.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -feature chicken-compile-shared -dynamic -emit-import-library setup-api -output-file setup-api.c
   used units: library eval chicken_2dsyntax srfi_2d1 irregex utils posix srfi_2d13 extras ports data_2dstructures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[288];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,53,55,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,101,120,116,114,97,45,102,101,97,116,117,114,101,115,32,46,32,116,109,112,55,50,55,51,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,97,112,105,35,101,120,116,114,97,45,110,111,110,102,101,97,116,117,114,101,115,32,46,32,116,109,112,56,57,57,48,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,50,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,7),40,97,50,50,56,49,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,7),40,97,50,50,55,49,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,50,53,53,32,114,120,50,53,54,32,115,117,98,115,116,50,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,48),40,115,101,116,117,112,45,97,112,105,35,114,101,103,105,115,116,101,114,45,112,114,111,103,114,97,109,32,110,97,109,101,50,57,54,32,46,32,116,109,112,50,57,53,50,57,55,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,112,114,111,103,114,97,109,32,110,97,109,101,51,48,52,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,22),40,114,101,103,32,110,97,109,101,51,48,56,32,114,110,97,109,101,51,48,57,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,54,54,32,103,51,55,56,51,56,53,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,51,57,32,103,51,53,49,51,53,56,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,48,57,32,103,52,50,49,52,50,55,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,115,109,111,111,116,104,32,108,115,116,52,48,53,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,57,54,32,103,52,48,51,52,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,52,56,32,103,52,54,48,52,54,54,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,51,57,51,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,97,116,105,111,110,45,112,114,101,102,105,120,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,53,55,56,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,15),40,102,95,53,50,51,53,32,100,105,114,53,56,56,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,15),40,102,95,53,50,52,51,32,100,105,114,53,57,48,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,50,57,54,52,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,50,57,55,51,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,54,48,48,32,102,105,108,101,115,54,48,49,32,105,110,102,111,54,48,50,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,11),40,103,54,56,50,32,102,54,57,49,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,54,56,49,32,103,54,56,56,54,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,20),40,119,97,108,107,32,102,114,111,109,54,55,51,32,116,111,54,55,52,41,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,54,53,54,32,116,111,54,53,55,32,46,32,116,109,112,54,53,53,54,53,56,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,55,49,48,32,116,111,55,49,49,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,55,50,50,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,55,51,48,32,102,105,108,101,55,51,49,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,51,54,32,103,55,52,56,55,54,52,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,55,51,51,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,103,56,48,53,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,115,117,112,112,108,121,45,118,101,114,115,105,111,110,32,105,110,102,111,55,57,55,32,118,101,114,115,105,111,110,55,57,56,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,51,53,53,53,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,115,116,97,110,100,97,114,100,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,50,52,32,46,32,116,109,112,56,50,51,56,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,11),40,103,56,57,49,32,102,57,48,50,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,56,56,53,32,103,56,57,55,57,50,56,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,56),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,56,55,49,32,102,105,108,101,115,56,55,50,32,46,32,116,109,112,56,55,48,56,55,51,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,101,120,105,102,121,32,102,57,52,57,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,12),40,103,57,57,48,32,102,49,48,48,49,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,22),40,109,97,112,45,108,111,111,112,57,56,52,32,103,57,57,54,49,48,49,51,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,11),40,103,57,54,50,32,102,57,55,51,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,53,54,32,103,57,54,56,57,55,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,54),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,57,52,48,32,102,105,108,101,115,57,52,49,32,46,32,116,109,112,57,51,57,57,52,50,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,13),40,103,49,48,52,54,32,102,49,48,53,55,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,52,48,32,103,49,48,53,50,49,48,54,57,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,48,50,54,32,102,105,108,101,115,49,48,50,55,32,46,32,116,109,112,49,48,50,53,49,48,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,48,56,55,49,48,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,49,49,53,32,116,109,112,49,49,49,52,49,49,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,7),40,97,52,51,48,51,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,18),40,97,52,50,57,55,32,101,120,49,49,56,49,49,49,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,7),40,97,52,51,49,50,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,7),40,97,52,51,52,55,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,22),40,97,52,51,52,49,32,46,32,97,114,103,115,49,49,56,51,49,50,48,51,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,52,51,48,54,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,17),40,97,52,50,57,49,32,107,49,49,56,50,49,49,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,7),40,97,52,51,54,53,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,18),40,97,52,51,53,57,32,101,120,49,49,53,55,49,49,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,7),40,97,52,51,55,52,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,7),40,97,52,52,48,57,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,22),40,97,52,52,48,51,32,46,32,97,114,103,115,49,49,53,57,49,49,55,57,41,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,7),40,97,52,51,54,56,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,17),40,97,52,51,53,51,32,107,49,49,53,56,49,49,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,52,52,54,51,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,52,52,54,57,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,52,52,55,50,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,97,52,52,55,56,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,52,52,56,49,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,7),40,97,52,52,56,52,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,49,51,55,32,46,32,116,109,112,49,49,51,54,49,49,51,56,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,50,48,57,32,112,114,111,99,49,50,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,50,51,54,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,50,53,55,32,103,49,50,54,57,49,50,55,57,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,50,53,52,41,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,50,56,54,32,112,50,49,50,56,55,41,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,50,53,49,32,118,50,49,50,53,50,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,51,51,50,49,51,51,51,41,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,51,52,55,32,46,32,116,109,112,49,51,52,54,49,51,52,56,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,7),40,97,52,56,53,56,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,97,52,56,53,50,32,101,120,49,51,55,50,49,51,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,7),40,97,52,56,54,55,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,7),40,97,52,57,49,50,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,22),40,97,52,57,48,54,32,46,32,97,114,103,115,49,51,55,52,49,51,57,56,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,7),40,97,52,56,54,49,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,17),40,97,52,56,52,54,32,107,49,51,55,51,49,51,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,13),40,103,49,52,48,53,32,102,49,52,49,52,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,52,48,52,32,103,49,52,49,49,49,52,50,48,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,52,48,48,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,51,54,48,32,46,32,116,109,112,49,51,53,57,49,51,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,13),40,103,49,52,52,51,32,102,49,52,53,50,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,52,52,50,32,103,49,52,52,57,49,52,53,53,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,52,51,50,32,46,32,116,109,112,49,52,51,49,49,52,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,16),40,103,49,52,55,48,32,112,97,116,104,49,52,55,50,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,52,54,49,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,16),40,116,109,112,49,49,56,57,51,32,99,49,52,57,50,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,115,101,116,117,112,45,101,114,114,111,114,45,104,97,110,100,108,105,110,103,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,51,50,50,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,13),40,97,53,49,54,56,32,120,49,51,49,48,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,7),40,97,53,50,57,49,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_3187)
static void C_fcall f_3187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word *av) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word *av) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word *av) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word *av) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word *av) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word *av) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word *av) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word *av) C_noret;
C_noret_decl(f_2288)
static void C_fcall f_2288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word *av) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word *av) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word *av) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word *av) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word *av) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word *av) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word *av) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word *av) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word *av) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word *av) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word *av) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word *av) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word *av) C_noret;
C_noret_decl(f_5192)
static void C_fcall f_5192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word *av) C_noret;
C_noret_decl(f_2424)
static void C_fcall f_2424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word *av) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word *av) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word *av) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word *av) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word *av) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word *av) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word *av) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word *av) C_noret;
C_noret_decl(f_4183)
static void C_fcall f_4183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word *av) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word *av) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word *av) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word *av) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word *av) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word *av) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word *av) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word *av) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word *av) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word *av) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word *av) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word *av) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word *av) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word *av) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word *av) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word *av) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word *av) C_noret;
C_noret_decl(f_5131)
static void C_fcall f_5131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word *av) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word *av) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word *av) C_noret;
C_noret_decl(f_2202)
static void C_fcall f_2202(C_word t0) C_noret;
C_noret_decl(f_2587)
static void C_fcall f_2587(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word *av) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word *av) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word *av) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word *av) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word *av) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word *av) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word *av) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word *av) C_noret;
C_noret_decl(f_4121)
static void C_fcall f_4121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word *av) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word *av) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word *av) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word *av) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word *av) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word *av) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word *av) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word *av) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word *av) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word *av) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word *av) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word *av) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word *av) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word *av) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word *av) C_noret;
C_noret_decl(f_5073)
static void C_fcall f_5073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word *av) C_noret;
C_noret_decl(f_2489)
static void C_fcall f_2489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word *av) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word *av) C_noret;
C_noret_decl(f_2553)
static void C_fcall f_2553(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word *av) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word *av) C_noret;
C_noret_decl(f_4962)
static void C_fcall f_4962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word *av) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word *av) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word *av) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word *av) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word *av) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word *av) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word *av) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word *av) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word *av) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word *av) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word *av) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word *av) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word *av) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word *av) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word *av) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word *av) C_noret;
C_noret_decl(f_5013)
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word *av) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word *av) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word *av) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word *av) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word *av) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word *av) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word *av) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word *av) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word *av) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word *av) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word *av) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word *av) C_noret;
C_noret_decl(f_3067)
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word *av) C_noret;
C_noret_decl(f_2775)
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word *av) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word *av) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word *av) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word *av) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word *av) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word *av) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word *av) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word *av) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word *av) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word *av) C_noret;
C_noret_decl(f_3039)
static void C_fcall f_3039(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word *av) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word *av) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word *av) C_noret;
C_noret_decl(f_5037)
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3028)
static void C_fcall f_3028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word *av) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word *av) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word *av) C_noret;
C_noret_decl(f_2798)
static void C_fcall f_2798(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word *av) C_noret;
C_noret_decl(f_4651)
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word *av) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word *av) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word *av) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word *av) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word *av) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897(C_word c,C_word *av) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word *av) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word *av) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word *av) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word *av) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word *av) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word *av) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word *av) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word *av) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word *av) C_noret;
C_noret_decl(f_3047)
static void C_fcall f_3047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word *av) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word *av) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word *av) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word *av) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word *av) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word *av) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word *av) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word *av) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word *av) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word *av) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word *av) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word *av) C_noret;
C_noret_decl(f_4602)
static void C_fcall f_4602(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word *av) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word *av) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word *av) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word *av) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word *av) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word *av) C_noret;
C_noret_decl(f_3322)
static void C_fcall f_3322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word *av) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word *av) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word *av) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word *av) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word *av) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word *av) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word *av) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word *av) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word *av) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word *av) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word *av) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word *av) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word *av) C_noret;
C_noret_decl(f_2700)
static void C_fcall f_2700(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word *av) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word *av) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word *av) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word *av) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word *av) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word *av) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word *av) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word *av) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word *av) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word *av) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word *av) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word *av) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word *av) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word *av) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word *av) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word *av) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word *av) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word *av) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word *av) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word *av) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word *av) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word *av) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word *av) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word *av) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word *av) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word *av) C_noret;
C_noret_decl(f_3852)
static void C_fcall f_3852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word *av) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word *av) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word *av) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word *av) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word *av) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word *av) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word *av) C_noret;
C_noret_decl(f_4927)
static void C_fcall f_4927(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word *av) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word *av) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word *av) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word *av) C_noret;
C_noret_decl(f_4922)
static void C_fcall f_4922(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4957)
static void C_ccall f_4957(C_word c,C_word *av) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word *av) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word *av) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word *av) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word *av) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word *av) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word *av) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word *av) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word *av) C_noret;
C_noret_decl(f_3271)
static void C_fcall f_3271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word *av) C_noret;
C_noret_decl(f_4937)
static void C_fcall f_4937(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word *av) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word *av) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word *av) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word *av) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word *av) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word *av) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word *av) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word *av) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word *av) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word *av) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word *av) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word *av) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word *av) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word *av) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word *av) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word *av) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word *av) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word *av) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word *av) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word *av) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word *av) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word *av) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word *av) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word *av) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word *av) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word *av) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word *av) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word *av) C_noret;
C_noret_decl(f_3246)
static void C_fcall f_3246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word *av) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word *av) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word *av) C_noret;
C_noret_decl(f_3775)
static void C_fcall f_3775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word *av) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word *av) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word *av) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word *av) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word *av) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word *av) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word *av) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word *av) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word *av) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word *av) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word *av) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word *av) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word *av) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word *av) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word *av) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word *av) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word *av) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word *av) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word *av) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word *av) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word *av) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word *av) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word *av) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word *av) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word *av) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word *av) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word *av) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word *av) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word *av) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word *av) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word *av) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word *av) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word *av) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word *av) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word *av) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word *av) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word *av) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word *av) C_noret;
C_noret_decl(f_2901)
static void C_fcall f_2901(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word *av) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word *av) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word *av) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word *av) C_noret;
C_noret_decl(f_3925)
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3524)
static void C_fcall f_3524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word *av) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word *av) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word *av) C_noret;
C_noret_decl(f_3598)
static void C_fcall f_3598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_fcall f_3594(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word *av) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word *av) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word *av) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word *av) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word *av) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word *av) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word *av) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word *av) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word *av) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word *av) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word *av) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word *av) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word *av) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word *av) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word *av) C_noret;
C_noret_decl(f_5219)
static void C_ccall f_5219(C_word c,C_word *av) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word *av) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word *av) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word *av) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word *av) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word *av) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word *av) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word *av) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word *av) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word *av) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word *av) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word *av) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word *av) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word *av) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word *av) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word *av) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word *av) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word *av) C_noret;
C_noret_decl(f_3439)
static void C_fcall f_3439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word *av) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word *av) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word *av) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word *av) C_noret;
C_noret_decl(f_3431)
static void C_fcall f_3431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word *av) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word *av) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word *av) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word *av) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word *av) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word *av) C_noret;
C_noret_decl(f_3805)
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word *av) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word *av) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word *av) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word *av) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word *av) C_noret;
C_noret_decl(f_3809)
static void C_fcall f_3809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word *av) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word *av) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word *av) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word *av) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word *av) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word *av) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word *av) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word *av) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word *av) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word *av) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word *av) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word *av) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word *av) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word *av) C_noret;
C_noret_decl(f_4582)
static void C_fcall f_4582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word *av) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word *av) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word *av) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word *av) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word *av) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word *av) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word *av) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word *av) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word *av) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word *av) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word *av) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word *av) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word *av) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word *av) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word *av) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word *av) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word *av) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word *av) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word *av) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word *av) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word *av) C_noret;
C_noret_decl(f_4067)
static void C_fcall f_4067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word *av) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word *av) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word *av) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word *av) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word *av) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word *av) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word *av) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word *av) C_noret;
C_noret_decl(f_3719)
static void C_fcall f_3719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word *av) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word *av) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word *av) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word *av) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word *av) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word *av) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word *av) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word *av) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word *av) C_noret;
C_noret_decl(f_2874)
static void C_fcall f_2874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word *av) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word *av) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word *av) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word *av) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word *av) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word *av) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word *av) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word *av) C_noret;
C_noret_decl(f_3888)
static void C_fcall f_3888(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word *av) C_noret;
C_noret_decl(f_4006)
static void C_fcall f_4006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_fcall f_4002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word *av) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word *av) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word *av) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word *av) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word *av) C_noret;
C_noret_decl(f_5185)
static void C_fcall f_5185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word *av) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word *av) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word *av) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word *av) C_noret;
C_noret_decl(f_3646)
static void C_fcall f_3646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word *av) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word *av) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word *av) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word *av) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word *av) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word *av) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word *av) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word *av) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word *av) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word *av) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word *av) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word *av) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word *av) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word *av) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word *av) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word *av) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word *av) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word *av) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word *av) C_noret;

C_noret_decl(trf_3187)
static void C_ccall trf_3187(C_word c,C_word *av) C_noret;
static void C_ccall trf_3187(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3187(t0,t1);}

C_noret_decl(trf_2288)
static void C_ccall trf_2288(C_word c,C_word *av) C_noret;
static void C_ccall trf_2288(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2288(t0,t1);}

C_noret_decl(trf_5192)
static void C_ccall trf_5192(C_word c,C_word *av) C_noret;
static void C_ccall trf_5192(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5192(t0,t1);}

C_noret_decl(trf_2424)
static void C_ccall trf_2424(C_word c,C_word *av) C_noret;
static void C_ccall trf_2424(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2424(t0,t1,t2);}

C_noret_decl(trf_4183)
static void C_ccall trf_4183(C_word c,C_word *av) C_noret;
static void C_ccall trf_4183(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4183(t0,t1,t2);}

C_noret_decl(trf_5131)
static void C_ccall trf_5131(C_word c,C_word *av) C_noret;
static void C_ccall trf_5131(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5131(t0,t1,t2);}

C_noret_decl(trf_2202)
static void C_ccall trf_2202(C_word c,C_word *av) C_noret;
static void C_ccall trf_2202(C_word c,C_word *av){
C_word t0=av[0];
f_2202(t0);}

C_noret_decl(trf_2587)
static void C_ccall trf_2587(C_word c,C_word *av) C_noret;
static void C_ccall trf_2587(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2587(t0,t1,t2);}

C_noret_decl(trf_4121)
static void C_ccall trf_4121(C_word c,C_word *av) C_noret;
static void C_ccall trf_4121(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4121(t0,t1);}

C_noret_decl(trf_5073)
static void C_ccall trf_5073(C_word c,C_word *av) C_noret;
static void C_ccall trf_5073(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5073(t0,t1);}

C_noret_decl(trf_2489)
static void C_ccall trf_2489(C_word c,C_word *av) C_noret;
static void C_ccall trf_2489(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2489(t0,t1);}

C_noret_decl(trf_2553)
static void C_ccall trf_2553(C_word c,C_word *av) C_noret;
static void C_ccall trf_2553(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2553(t0,t1,t2);}

C_noret_decl(trf_4962)
static void C_ccall trf_4962(C_word c,C_word *av) C_noret;
static void C_ccall trf_4962(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4962(t0,t1,t2);}

C_noret_decl(trf_5013)
static void C_ccall trf_5013(C_word c,C_word *av) C_noret;
static void C_ccall trf_5013(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5013(t0,t1,t2);}

C_noret_decl(trf_3067)
static void C_ccall trf_3067(C_word c,C_word *av) C_noret;
static void C_ccall trf_3067(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3067(t0,t1,t2);}

C_noret_decl(trf_2775)
static void C_ccall trf_2775(C_word c,C_word *av) C_noret;
static void C_ccall trf_2775(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2775(t0,t1,t2);}

C_noret_decl(trf_3039)
static void C_ccall trf_3039(C_word c,C_word *av) C_noret;
static void C_ccall trf_3039(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3039(t0,t1,t2,t3);}

C_noret_decl(trf_5037)
static void C_ccall trf_5037(C_word c,C_word *av) C_noret;
static void C_ccall trf_5037(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5037(t0,t1,t2);}

C_noret_decl(trf_3028)
static void C_ccall trf_3028(C_word c,C_word *av) C_noret;
static void C_ccall trf_3028(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3028(t0,t1);}

C_noret_decl(trf_2798)
static void C_ccall trf_2798(C_word c,C_word *av) C_noret;
static void C_ccall trf_2798(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2798(t0,t1,t2);}

C_noret_decl(trf_4651)
static void C_ccall trf_4651(C_word c,C_word *av) C_noret;
static void C_ccall trf_4651(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4651(t0,t1,t2,t3);}

C_noret_decl(trf_3047)
static void C_ccall trf_3047(C_word c,C_word *av) C_noret;
static void C_ccall trf_3047(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3047(t0,t1,t2);}

C_noret_decl(trf_4602)
static void C_ccall trf_4602(C_word c,C_word *av) C_noret;
static void C_ccall trf_4602(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4602(t0,t1,t2);}

C_noret_decl(trf_3322)
static void C_ccall trf_3322(C_word c,C_word *av) C_noret;
static void C_ccall trf_3322(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3322(t0,t1,t2);}

C_noret_decl(trf_2700)
static void C_ccall trf_2700(C_word c,C_word *av) C_noret;
static void C_ccall trf_2700(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2700(t0,t1,t2);}

C_noret_decl(trf_3852)
static void C_ccall trf_3852(C_word c,C_word *av) C_noret;
static void C_ccall trf_3852(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3852(t0,t1,t2);}

C_noret_decl(trf_4927)
static void C_ccall trf_4927(C_word c,C_word *av) C_noret;
static void C_ccall trf_4927(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4927(t0,t1,t2);}

C_noret_decl(trf_4922)
static void C_ccall trf_4922(C_word c,C_word *av) C_noret;
static void C_ccall trf_4922(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4922(t0,t1,t2);}

C_noret_decl(trf_3271)
static void C_ccall trf_3271(C_word c,C_word *av) C_noret;
static void C_ccall trf_3271(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3271(t0,t1);}

C_noret_decl(trf_4937)
static void C_ccall trf_4937(C_word c,C_word *av) C_noret;
static void C_ccall trf_4937(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4937(t0,t1);}

C_noret_decl(trf_3246)
static void C_ccall trf_3246(C_word c,C_word *av) C_noret;
static void C_ccall trf_3246(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3246(t0,t1,t2);}

C_noret_decl(trf_3775)
static void C_ccall trf_3775(C_word c,C_word *av) C_noret;
static void C_ccall trf_3775(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3775(t0,t1);}

C_noret_decl(trf_2901)
static void C_ccall trf_2901(C_word c,C_word *av) C_noret;
static void C_ccall trf_2901(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2901(t0,t1,t2,t3);}

C_noret_decl(trf_3925)
static void C_ccall trf_3925(C_word c,C_word *av) C_noret;
static void C_ccall trf_3925(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3925(t0,t1,t2);}

C_noret_decl(trf_3524)
static void C_ccall trf_3524(C_word c,C_word *av) C_noret;
static void C_ccall trf_3524(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3524(t0,t1);}

C_noret_decl(trf_3598)
static void C_ccall trf_3598(C_word c,C_word *av) C_noret;
static void C_ccall trf_3598(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3598(t0,t1);}

C_noret_decl(trf_3594)
static void C_ccall trf_3594(C_word c,C_word *av) C_noret;
static void C_ccall trf_3594(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3594(t0,t1,t2);}

C_noret_decl(trf_3439)
static void C_ccall trf_3439(C_word c,C_word *av) C_noret;
static void C_ccall trf_3439(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3439(t0,t1);}

C_noret_decl(trf_3431)
static void C_ccall trf_3431(C_word c,C_word *av) C_noret;
static void C_ccall trf_3431(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3431(t0,t1,t2);}

C_noret_decl(trf_3805)
static void C_ccall trf_3805(C_word c,C_word *av) C_noret;
static void C_ccall trf_3805(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3805(t0,t1,t2);}

C_noret_decl(trf_3809)
static void C_ccall trf_3809(C_word c,C_word *av) C_noret;
static void C_ccall trf_3809(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3809(t0,t1);}

C_noret_decl(trf_4582)
static void C_ccall trf_4582(C_word c,C_word *av) C_noret;
static void C_ccall trf_4582(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4582(t0,t1);}

C_noret_decl(trf_4067)
static void C_ccall trf_4067(C_word c,C_word *av) C_noret;
static void C_ccall trf_4067(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4067(t0,t1,t2);}

C_noret_decl(trf_3719)
static void C_ccall trf_3719(C_word c,C_word *av) C_noret;
static void C_ccall trf_3719(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3719(t0,t1,t2);}

C_noret_decl(trf_2874)
static void C_ccall trf_2874(C_word c,C_word *av) C_noret;
static void C_ccall trf_2874(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2874(t0,t1);}

C_noret_decl(trf_3888)
static void C_ccall trf_3888(C_word c,C_word *av) C_noret;
static void C_ccall trf_3888(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3888(t0,t1,t2);}

C_noret_decl(trf_4006)
static void C_ccall trf_4006(C_word c,C_word *av) C_noret;
static void C_ccall trf_4006(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4006(t0,t1);}

C_noret_decl(trf_4002)
static void C_ccall trf_4002(C_word c,C_word *av) C_noret;
static void C_ccall trf_4002(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4002(t0,t1,t2);}

C_noret_decl(trf_5185)
static void C_ccall trf_5185(C_word c,C_word *av) C_noret;
static void C_ccall trf_5185(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5185(t0,t1);}

C_noret_decl(trf_3646)
static void C_ccall trf_3646(C_word c,C_word *av) C_noret;
static void C_ccall trf_3646(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3646(t0,t1);}

/* k3185 in setup-api#move-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_3187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_3187,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t4=C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm:355: make-pathname");
t5=C_fast_retrieve(lf[79]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
f_3190(2,av2);}}}

/* k3742 in map-loop885 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3744,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3719(t6,((C_word*)t0)[5],t5);}

/* k3617 in k3611 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_3619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3619,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:445: destination-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[112]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[112]+1);
av2[1]=t2;
tp(2,av2);}}}

/* k3611 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_3613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3613,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:444: deployment-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[21]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[21]+1);
av2[1]=t2;
tp(2,av2);}}

/* k4141 in k4135 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4143,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:507: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
C_trace("setup-api.scm:508: repository-path");
t3=C_fast_retrieve(lf[124]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3175 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3177,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:351: normalize-pathname");
t4=C_fast_retrieve(lf[16]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2195 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in ... */
static void C_ccall f_2197(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2197,2,av);}
if(C_truep(t1)){
t2=t1;
C_trace("setup-api.scm:158: qs");
t3=C_fast_retrieve(lf[15]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
C_trace("setup-api.scm:158: qs");
t2=C_fast_retrieve(lf[15]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[59];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k2191 in k2188 in k2185 in k2179 in k2175 in k2172 in k2169 in k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in ... */
static void C_ccall f_2193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2193,2,av);}
t2=C_mutate2(&lf[33] /* (set! setup-api#*mkdir-command* ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a2281 in a2271 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in ... */
static void C_ccall f_2282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2282,2,av);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2288,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2288(t5,t1);}

/* loop in a2281 in a2271 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in ... */
static void C_fcall f_2288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2288,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2292,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:198: read-line");
t3=C_fast_retrieve(lf[66]);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_3607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_3607,2,av);}
a=C_alloc(15);
t2=C_i_assq(lf[164],((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3646,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3685,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:440: software-version");
t7=C_fast_retrieve(lf[168]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_3613(2,av2);}}}

/* k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_3601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3601,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:436: copy-file");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[129]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[129]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
tp(4,av2);}}

/* k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_3604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_3604,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_3607(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3700,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:438: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}}

/* k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in ... */
static void C_ccall f_2441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2441,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CHICKEN_INSTALL_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in ... */
static void C_ccall f_2447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2447,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5270,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CHICKEN_STATUS_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in ... */
static void C_ccall f_2444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2444,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CHICKEN_UNINSTALL_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3675 in k3683 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_3677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3677,2,av);}
t2=((C_word*)t0)[2];
f_3646(t2,C_i_equalp(t1,lf[166]));}

/* setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_3769(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +10,c,3))){
C_save_and_reclaim((void*)f_3769,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+10);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3775,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3789,a[2]=t1,a[3]=t2,a[4]=t7,a[5]=t8,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:458: setup-install-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[20]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t9;
tp(2,av2);}}

/* k2735 in for-each-loop396 in k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2737,2,av);}
C_trace("setup-api.scm:270: $system");
f_5073(((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1941,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[3] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_CFLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in ... */
static void C_ccall f_2453(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2453,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[81]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2668,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:289: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in ... */
static void C_ccall f_2450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_2450,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5266,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2457 in k3638 in k3634 in k3617 in k3611 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in ... */
static void C_ccall f_2459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2459,2,av);}
if(C_truep(t1)){
C_trace("setup-api.scm:235: make-pathname");
t2=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ensure-string in k5183 in a5168 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_fcall f_5192(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_5192,2,t1,t2);}
t3=C_i_not(t2);
if(C_truep(t3)){
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[266];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
C_trace("setup-api.scm:587: ->string");
t4=C_fast_retrieve(lf[78]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[266];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
C_trace("setup-api.scm:587: ->string");
t4=C_fast_retrieve(lf[78]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}

/* k3659 in k3644 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_3661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3661,2,av);}
a=C_alloc(9);
t2=C_a_i_list(&a,2,C_retrieve2(lf[32],"setup-api#\052ranlib-command\052"),t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:443: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* reg in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_fcall f_2424(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_2424,3,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2432,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:224: make-pathname");
t5=C_fast_retrieve(lf[79]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_retrieve2(lf[12],"setup-api#\052chicken-bin-path\052");
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5100 in k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_5102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5102,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:650: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(58);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k5106 in k5103 in k5100 in k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_5108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5108,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:650: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k5103 in k5100 in k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_5105(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5105,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:650: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* a2271 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2272,2,av);}
a=C_alloc(5);
t2=C_i_car(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:195: with-input-from-file");
t4=C_fast_retrieve(lf[67]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1945,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[4] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_MORE_LIBS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1949,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[5] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1960,2,av);}
a=C_alloc(3);
t2=C_mutate2(&lf[10] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:89: register-feature!");
t4=C_fast_retrieve(lf[25]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[284];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2430 in reg in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2432,2,av);}
C_trace("setup-api.scm:224: register-program");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[77]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[77]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* setup-api#ensure-directory in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_fcall f_4183(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_4183,3,t1,t2,t3);}
a=C_alloc(4);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4190,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=t2;
f_4190(2,av2);}}
else{
C_trace("setup-api.scm:514: pathname-directory");
t7=C_fast_retrieve(lf[184]);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in ... */
static void C_ccall f_2097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2097,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:159: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_ccall f_2435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2435,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CSI_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2438(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2438,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CSC_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3108 in k3104 in k3089 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_3110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3110,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[28],"setup-api#\052copy-command\052"),((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:343: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
tp(3,av2);}}

/* k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1932,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[0] /* (set! setup-api#constant26 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_CC);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1937,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[2] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_CXX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3124 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3126,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
f_3034(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:331: absolute-pathname?");
t3=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in ... */
static void C_ccall f_2253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2253,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2257,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2357,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:191: setup-verbose-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[19]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[19]+1);
av2[1]=t6;
tp(2,av2);}}

/* k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in ... */
static void C_ccall f_2251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_2251,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[62]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate2((C_word*)lf[63]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:208: make-parameter");
t5=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_ccall f_2257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2257,2,av);}
a=C_alloc(6);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:193: with-output-to-file");
t4=C_fast_retrieve(lf[68]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:202: create-temporary-file");
t3=C_fast_retrieve(lf[71]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1963,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:91: make-parameter");
t3=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1967,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[11]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:94: get-environment-variable");
t4=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[283];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3117 in k3124 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3119(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3119,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
f_3034(2,av2);}}
else{
C_trace("setup-api.scm:333: make-pathname");
t2=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in ... */
static void C_ccall f_2228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_2228,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
if(C_truep(C_i_nullp(t2))){
t3=C_retrieve2(lf[7],"setup-api#\052sudo\052");
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_retrieve2(lf[7],"setup-api#\052sudo\052");
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_car(t2))){
t3=t1;
t4=lf[7] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t5=lf[7] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
C_trace("setup-api.scm:155: print");
t6=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:158: get-environment-variable");
t8=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[61];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}
else{
C_trace("setup-api.scm:181: user-install-setup");
f_2202(t1);}}}

/* k3104 in k3089 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_3106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3106,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3110,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:345: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k4319 in a4312 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in ... */
static void C_ccall f_4321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4321,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:545: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_retrieve2(lf[29],"setup-api#\052remove-command\052");
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4325 in k4319 in a4312 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in ... */
static void C_ccall f_4327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4327,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:545: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* g1470 in k5125 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_fcall f_5131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_5131,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5139,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:645: qs");
t4=C_fast_retrieve(lf[15]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5137 in g1470 in k5125 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_5139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_5139,2,av);}
C_trace("setup-api.scm:644: string-append");
t2=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[257];
av2[3]=t1;
av2[4]=lf[258];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k4778 in k4788 in setup-api#extension-version in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4780,2,av);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm:598: ->string");
t2=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a4312 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in ... */
static void C_ccall f_4313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4313,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4321,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:545: open-output-string");
t3=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* setup-api#user-install-setup in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in ... */
static void C_fcall f_2202(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_2202,1,t1);}
t2=lf[7] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t3=t1;
t4=C_mutate2(&lf[28] /* (set! setup-api#*copy-command* ...) */,lf[35]);
t5=C_mutate2(&lf[29] /* (set! setup-api#*remove-command* ...) */,lf[36]);
t6=C_mutate2(&lf[30] /* (set! setup-api#*move-command* ...) */,lf[37]);
t7=C_mutate2(&lf[31] /* (set! setup-api#*chmod-command* ...) */,lf[38]);
t8=C_mutate2(&lf[32] /* (set! setup-api#*ranlib-command* ...) */,lf[39]);
t9=t3;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t3=t1;
t4=C_mutate2(&lf[28] /* (set! setup-api#*copy-command* ...) */,lf[40]);
t5=C_mutate2(&lf[29] /* (set! setup-api#*remove-command* ...) */,lf[41]);
t6=C_mutate2(&lf[30] /* (set! setup-api#*move-command* ...) */,lf[42]);
t7=C_mutate2(&lf[31] /* (set! setup-api#*chmod-command* ...) */,lf[43]);
t8=C_mutate2(&lf[32] /* (set! setup-api#*ranlib-command* ...) */,lf[44]);
t9=C_mutate2(&lf[33] /* (set! setup-api#*mkdir-command* ...) */,lf[45]);
t10=t3;{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}

/* map-loop339 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_fcall f_2587(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_2587,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:252: symbol->string");
t7=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in ... */
static void C_ccall f_5120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5120,2,av);}
C_trace("setup-api.scm:649: error");
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5125 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_5127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5127,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5131,a[2]=((C_word*)t0)[2],a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:639: g1470");
t3=t2;
f_5131(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_5077(2,av2);}}}

/* setup-api#read-info in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_4798,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
C_trace("setup-api.scm:601: repository-path");
t5=C_fast_retrieve(lf[124]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_car(t3);
f_4802(2,av2);}}}

/* k4126 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4128,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4131,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:510: ensure-directory");
f_4183(t3,t2,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in ... */
static void C_ccall f_4307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4307,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[2],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[3],a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:545: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a4303 in a4297 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in ... */
static void C_ccall f_4304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4304,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5109 in k5106 in k5103 in k5100 in k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_5111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5111,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:650: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[252];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_5062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_5062,2,av);}
a=C_alloc(16);
t2=C_i_assq(lf[120],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[3],a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
t6=C_i_check_list_2(t5,lf[109]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5037,a[2]=t8,a[3]=t4,a[4]=((C_word)li95),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_5037(t10,t3,t5);}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_5005(2,av2);}}}

/* setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_fcall f_4121(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4121,2,t1,t2);}
a=C_alloc(6);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4128,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4137,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:501: deployment-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[21]);
C_word av2[2];
av2[0]=*((C_word*)lf[21]+1);
av2[1]=t6;
tp(2,av2);}}
else{
C_trace("setup-api.scm:509: repository-path");
t6=C_fast_retrieve(lf[124]);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_5117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5117,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:650: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_5114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5114,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:650: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4157 in k4151 in k4141 in k4135 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4159,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_fudge(C_fix(42));
C_trace("setup-api.scm:507: ##sys#print");
t4=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4151 in k4141 in k4135 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4153,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:507: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[181];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_5093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_5093,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:650: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[253];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5097 in k5091 in k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_5099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5099,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:650: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4101 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4103,2,av);}
a=C_alloc(3);
C_trace("setup-api.scm:483: ensure-directory");
f_4183(((C_word*)t0)[2],t1,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k5045 in for-each-loop1442 in k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_5047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5047,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5037(t3,((C_word*)t0)[4],t2);}

/* k4763 in setup-api#extension-name in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4765,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_car(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* setup-api#extension-version in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_4767,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4790,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:596: extension-name-and-version");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[147]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[147]+1);
av2[1]=t6;
tp(2,av2);}}

/* k4135 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4137,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
C_trace("setup-api.scm:502: installation-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[114]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[114]+1);
av2[1]=((C_word*)t0)[2];
tp(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4143,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:503: destination-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[112]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[112]+1);
av2[1]=t2;
tp(2,av2);}}}

/* k2540 in map-loop366 in k2543 in k2526 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_2542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2542,2,av);}
C_trace("##sys#string-append");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[97]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[97]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[98];
av2[3]=t1;
tp(4,av2);}}

/* k2543 in k2526 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_2545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_2545,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[82]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li12),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2553(t7,t3,t1);}

/* k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2485,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:243: deployment-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[21]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[21]+1);
av2[1]=t4;
tp(2,av2);}}

/* k2479 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2481,2,av);}
C_trace("setup-api.scm:239: string-intersperse");
t2=C_fast_retrieve(lf[83]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[86];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_5073(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_5073,2,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5077,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
C_trace("setup-api.scm:640: string-append");
t4=*((C_word*)lf[254]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[255];
av2[3]=t2;
av2[4]=lf[256];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5152,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:641: software-version");
t6=C_fast_retrieve(lf[168]);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k4129 in k4126 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4131(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4131,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_2489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2489,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:247: keep-intermediates");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[23]);
C_word av2[2];
av2[0]=*((C_word*)lf[23]+1);
av2[1]=t3;
tp(2,av2);}}

/* k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_5077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5077,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5080,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:647: system");
t4=C_fast_retrieve(lf[191]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2549 in k2543 in k2526 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_2551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2551,2,av);}
C_trace("setup-api.scm:250: append");
t2=*((C_word*)lf[96]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop366 in k2543 in k2526 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_fcall f_2553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_2553,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2542,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:255: symbol->string");
t7=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_2522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2522,2,av);}
a=C_alloc(11);
t2=C_i_check_list_2(t1,lf[82]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2587(t7,t3,t1);}

/* k2526 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_2528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2528,2,av);}
a=C_alloc(11);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:256: extra-nonfeatures");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[26]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t7;
tp(2,av2);}}

/* for-each-loop1404 in k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_4962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4962,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4972,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:617: g1405");
t5=((C_word*)t0)[3];
f_4927(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4788 in setup-api#extension-version in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4790,2,av);}
a=C_alloc(5);
t2=C_i_cadr(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:597: string-null?");
t5=C_fast_retrieve(lf[238]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5078 in k5075 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_5080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5080,2,av);}
a=C_alloc(5);
t2=t1;
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:650: open-output-string");
t5=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_4995,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4999,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
C_trace("setup-api.scm:629: repository-path");
t5=C_fast_retrieve(lf[124]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_car(t3);
f_4999(2,av2);}}}

/* k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4999,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:630: read-info");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[239]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[239]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
tp(4,av2);}}

/* k4390 in k4387 in k4381 in a4374 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in ... */
static void C_ccall f_4392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4392,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4402,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:544: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}

/* k4393 in k4390 in k4387 in k4381 in a4374 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in ... */
static void C_ccall f_4395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4395,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:544: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2503 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_2505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_2505,2,av);}
C_trace("setup-api.scm:240: cons*");
t2=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[94];
av2[4]=lf[95];
av2[5]=((C_word*)t0)[4];
av2[6]=((C_word*)t0)[5];
av2[7]=((C_word*)t0)[6];
av2[8]=((C_word*)t0)[7];
av2[9]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(10,av2);}}

/* k4381 in a4374 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in ... */
static void C_ccall f_4383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4383,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:544: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_retrieve2(lf[29],"setup-api#\052remove-command\052");
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2517 in map-loop339 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_2519(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2519,2,av);}
C_trace("##sys#string-append");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[97]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[97]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[100];
av2[3]=t1;
tp(4,av2);}}

/* k4396 in k4393 in k4390 in k4387 in k4381 in a4374 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in ... */
static void C_ccall f_4398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4398,2,av);}
C_trace("setup-api.scm:544: $system");
f_5073(((C_word*)t0)[2],t1);}

/* k4970 in for-each-loop1404 in k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4972,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4962(t3,((C_word*)t0)[4],t2);}

/* a4374 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in ... */
static void C_ccall f_4375(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4375,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4383,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:544: open-output-string");
t3=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3089 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_3091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3091,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:344: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* k4387 in k4381 in a4374 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in ... */
static void C_ccall f_4389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4389,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:544: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k5010 in k5003 in k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_5012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5012,2,av);}
C_trace("setup-api.scm:636: remove-file*");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[134]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[134]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k5015 in g1443 in k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_5017(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5017,2,av);}
C_trace("setup-api.scm:634: remove-file*");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[134]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[134]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* g1443 in k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_5013,3,t0,t1,t2);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5017,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5023,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:633: absolute-pathname?");
t5=C_fast_retrieve(lf[132]);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* a4359 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in ... */
static void C_ccall f_4360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4360,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4366,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:544: k1158");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k2576 in map-loop366 in k2543 in k2526 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_2578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2578,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2553(t6,((C_word*)t0)[5],t5);}

/* k2957 in k2942 in k2939 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_2959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2959,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2963,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:322: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_4354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4354,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=t2,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:544: with-exception-handler");
t5=C_fast_retrieve(lf[187]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k3075 in for-each-loop681 in k3060 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_3077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3077,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3067(t3,((C_word*)t0)[4],t2);}

/* a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in ... */
static void C_ccall f_4369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4369,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[2],a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[3],a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:544: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a4365 in a4359 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in ... */
static void C_ccall f_4366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4366,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2407 in setup-api#find-program in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2409,2,av);}
t2=C_i_assoc(t1,C_retrieve2(lf[9],"setup-api#\052registered-programs\052"));
if(C_truep(t2)){
t3=C_i_cdr(t2);
C_trace("setup-api.scm:219: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* setup-api#find-program in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_ccall f_2405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2405,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:216: ->string");
t4=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2398 in setup-api#register-program in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2400,2,av);}
C_trace("setup-api.scm:211: make-pathname");
t2=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[12],"setup-api#\052chicken-bin-path\052");
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a4341 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in ... */
static void C_ccall f_4342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_4342,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4348,a[2]=t2,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:545: k1182");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4338 in k4328 in k4325 in k4319 in a4312 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in ... */
static void C_ccall f_4340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4340,2,av);}
C_trace("setup-api.scm:545: ##sys#print");
t2=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* for-each-loop681 in k3060 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3067,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:337: g682");
t5=((C_word*)t0)[3];
f_3047(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3060 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_3062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3062,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3067,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3067(t5,((C_word*)t0)[3],t1);}

/* for-each-loop396 in k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in ... */
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,0,2))){
C_save_and_reclaim_args((void *)trf_2775,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2785,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2737,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2743,a[2]=t7,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:269: run-verbose");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[76]);
C_word av2[2];
av2[0]=*((C_word*)lf[76]+1);
av2[1]=t8;
tp(2,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5021 in g1443 in k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_5023(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5023,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
C_trace("setup-api.scm:634: remove-file*");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[134]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[134]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
tp(3,av2);}}
else{
C_trace("setup-api.scm:633: make-pathname");
t2=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k4331 in k4328 in k4325 in k4319 in a4312 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in ... */
static void C_ccall f_4333(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4333,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:545: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4328 in k4325 in k4319 in a4312 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in ... */
static void C_ccall f_4330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4330,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4340,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:545: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}

/* k3053 in g682 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_3055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3055,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:339: make-pathname");
t4=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3057 in k3053 in g682 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_3059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3059,2,av);}
C_trace("setup-api.scm:339: walk");
t2=((C_word*)((C_word*)t0)[2])[1];
f_3039(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a4347 in a4341 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in ... */
static void C_ccall f_4348(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4348,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k4800 in setup-api#read-info in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_4802,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:603: make-pathname");
t3=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
av2[4]=lf[0];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4807 in k4800 in setup-api#read-info in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4809,2,av);}
C_trace("setup-api.scm:602: with-input-from-file");
t2=C_fast_retrieve(lf[67]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[240]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4334 in k4331 in k4328 in k4325 in k4319 in a4312 in a4306 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in ... */
static void C_ccall f_4336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4336,2,av);}
C_trace("setup-api.scm:545: $system");
f_5073(((C_word*)t0)[2],t1);}

/* k5003 in k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_5005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_5005,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:636: make-pathname");
t3=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[0];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_3039(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3039,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:336: directory?");
t5=C_fast_retrieve(lf[131]);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3035 in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3037,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_3034,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3039,a[2]=t5,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3039(t7,t3,((C_word*)t0)[3],t2);}

/* k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_3031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_3031,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3126,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=t4;
t6=t2;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3177,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:350: normalize-pathname");
t8=C_fast_retrieve(lf[16]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* for-each-loop1442 in k5060 in k4997 in setup-api#remove-extension in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5037,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5047,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:631: g1443");
t5=((C_word*)t0)[3];
f_5013(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_fcall f_3028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_3028,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t4=C_i_cadr(((C_word*)t0)[4]);
C_trace("setup-api.scm:329: make-pathname");
t5=C_fast_retrieve(lf[79]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[5];
f_3031(2,av2);}}}

/* k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3022,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t6=((C_word*)t0)[4];
t7=t5;
f_3028(t7,C_u_i_car(t6));}
else{
t6=t5;
f_3028(t6,((C_word*)t0)[4]);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(964)){
C_save(t1);
C_rereclaim2(964*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,288);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[11]=C_h_intern(&lf[11],24,"setup-api#host-extension");
lf[13]=C_h_intern(&lf[13],24,"setup-api#chicken-prefix");
lf[14]=C_h_intern(&lf[14],19,"setup-api#shellpath");
lf[15]=C_h_intern(&lf[15],2,"qs");
lf[16]=C_h_intern(&lf[16],18,"normalize-pathname");
lf[18]=C_h_intern(&lf[18],30,"setup-api#setup-root-directory");
lf[19]=C_h_intern(&lf[19],28,"setup-api#setup-verbose-mode");
lf[20]=C_h_intern(&lf[20],28,"setup-api#setup-install-mode");
lf[21]=C_h_intern(&lf[21],25,"setup-api#deployment-mode");
lf[22]=C_h_intern(&lf[22],22,"setup-api#program-path");
lf[23]=C_h_intern(&lf[23],28,"setup-api#keep-intermediates");
lf[24]=C_h_intern(&lf[24],24,"setup-api#extra-features");
lf[25]=C_h_intern(&lf[25],17,"register-feature!");
lf[26]=C_h_intern(&lf[26],27,"setup-api#extra-nonfeatures");
lf[27]=C_h_intern(&lf[27],19,"unregister-feature!");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\005mkdir");
lf[46]=C_h_intern(&lf[46],22,"setup-api#sudo-install");
lf[47]=C_h_intern(&lf[47],5,"print");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[49]=C_h_intern(&lf[49],7,"sprintf");
lf[50]=C_h_intern(&lf[50],17,"get-output-string");
lf[51]=C_h_intern(&lf[51],9,"\003sysprint");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\006 mkdir");
lf[53]=C_h_intern(&lf[53],18,"open-output-string");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\007 ranlib");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\006 chmod");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\003 mv");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\007 rm -rf");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\006 cp -r");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\004sudo");
lf[60]=C_h_intern(&lf[60],24,"get-environment-variable");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\004SUDO");
lf[62]=C_h_intern(&lf[62],21,"setup-api#abort-setup");
lf[63]=C_h_intern(&lf[63],15,"setup-api#patch");
lf[64]=C_h_intern(&lf[64],10,"write-line");
lf[65]=C_h_intern(&lf[65],19,"irregex-replace/all");
lf[66]=C_h_intern(&lf[66],9,"read-line");
lf[67]=C_h_intern(&lf[67],20,"with-input-from-file");
lf[68]=C_h_intern(&lf[68],19,"with-output-to-file");
lf[70]=C_h_intern(&lf[70],16,"\003syswrite-char-0");
lf[71]=C_h_intern(&lf[71],21,"create-temporary-file");
lf[72]=C_h_intern(&lf[72],19,"\003sysstandard-output");
lf[73]=C_h_intern(&lf[73],6,"printf");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\011patching ");
lf[76]=C_h_intern(&lf[76],21,"setup-api#run-verbose");
lf[77]=C_h_intern(&lf[77],26,"setup-api#register-program");
lf[78]=C_h_intern(&lf[78],8,"->string");
lf[79]=C_h_intern(&lf[79],13,"make-pathname");
lf[80]=C_h_intern(&lf[80],22,"setup-api#find-program");
lf[81]=C_h_intern(&lf[81],17,"setup-api#execute");
lf[82]=C_h_intern(&lf[82],3,"map");
lf[83]=C_h_intern(&lf[83],18,"string-intersperse");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\011-deployed");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[93]=C_h_intern(&lf[93],5,"cons\052");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[96]=C_h_intern(&lf[96],6,"append");
lf[97]=C_h_intern(&lf[97],17,"\003sysstring-append");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-feature ");
lf[99]=C_h_intern(&lf[99],14,"symbol->string");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\011-feature ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_h_intern(&lf[103],8,"feature\077");
lf[104]=C_h_intern(&lf[104],14,"\000cross-chicken");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[106]=C_h_intern(&lf[106],9,"substring");
lf[107]=C_h_intern(&lf[107],14,"string-prefix\077");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[109]=C_h_intern(&lf[109],8,"for-each");
lf[110]=C_h_intern(&lf[110],16,"\003sysflush-output");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[112]=C_h_intern(&lf[112],28,"setup-api#destination-prefix");
lf[113]=C_h_intern(&lf[113],24,"setup-api#runtime-prefix");
lf[114]=C_h_intern(&lf[114],29,"setup-api#installation-prefix");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\010  mkdir ");
lf[116]=C_h_intern(&lf[116],16,"create-directory");
lf[117]=C_h_intern(&lf[117],2,"-p");
lf[118]=C_h_intern(&lf[118],34,"setup-api#create-directory/parents");
lf[120]=C_h_intern(&lf[120],5,"files");
lf[121]=C_h_intern(&lf[121],3,"a+r");
lf[122]=C_h_intern(&lf[122],2,"pp");
lf[124]=C_h_intern(&lf[124],15,"repository-path");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\015writing info ");
lf[129]=C_h_intern(&lf[129],19,"setup-api#copy-file");
lf[130]=C_h_intern(&lf[130],9,"directory");
lf[131]=C_h_intern(&lf[131],10,"directory\077");
lf[132]=C_h_intern(&lf[132],18,"absolute-pathname\077");
lf[133]=C_h_intern(&lf[133],19,"setup-api#move-file");
lf[134]=C_h_intern(&lf[134],22,"setup-api#remove-file\052");
lf[137]=C_h_intern(&lf[137],5,"error");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[139]=C_h_intern(&lf[139],5,"every");
lf[140]=C_h_intern(&lf[140],7,"string\077");
lf[142]=C_h_intern(&lf[142],7,"version");
lf[143]=C_h_intern(&lf[143],8,"egg-name");
lf[144]=C_h_intern(&lf[144],24,"setup-api#extension-name");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007unknown");
lf[147]=C_h_intern(&lf[147],36,"setup-api#extension-name-and-version");
lf[148]=C_h_intern(&lf[148],28,"setup-api#standard-extension");
lf[149]=C_h_intern(&lf[149],27,"setup-api#install-extension");
lf[150]=C_h_intern(&lf[150],12,"file-exists\077");
lf[151]=C_h_intern(&lf[151],26,"pathname-replace-extension");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[154]=C_h_intern(&lf[154],3,"csc");
lf[155]=C_h_intern(&lf[155],8,"-dynamic");
lf[156]=C_h_intern(&lf[156],15,"-optimize-level");
lf[157]=C_h_intern(&lf[157],12,"-debug-level");
lf[158]=C_h_intern(&lf[158],20,"-emit-import-library");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\012import.scm");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003scm");
lf[162]=C_h_intern(&lf[162],15,"\003sysget-keyword");
lf[163]=C_h_intern(&lf[163],5,"\000info");
lf[164]=C_h_intern(&lf[164],6,"static");
lf[165]=C_h_intern(&lf[165],6,"macosx");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[167]=C_h_intern(&lf[167],18,"pathname-extension");
lf[168]=C_h_intern(&lf[168],16,"software-version");
lf[169]=C_h_intern(&lf[169],25,"setup-api#install-program");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[172]=C_h_intern(&lf[172],26,"\003sysload-dynamic-extension");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[177]=C_h_intern(&lf[177],24,"setup-api#install-script");
lf[178]=C_h_intern(&lf[178],4,"a+rx");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[183]=C_h_intern(&lf[183],3,"a+x");
lf[184]=C_h_intern(&lf[184],18,"pathname-directory");
lf[185]=C_h_intern(&lf[185],21,"setup-api#try-compile");
lf[186]=C_h_intern(&lf[186],4,"\000c++");
lf[187]=C_h_intern(&lf[187],22,"with-exception-handler");
lf[188]=C_h_intern(&lf[188],30,"call-with-current-continuation");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[191]=C_h_intern(&lf[191],6,"system");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\007 >nul: ");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[199]=C_h_intern(&lf[199],4,"conc");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\004 -o ");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[210]=C_h_intern(&lf[210],7,"display");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[213]=C_h_intern(&lf[213],13,"\000compile-only");
lf[214]=C_h_intern(&lf[214],5,"\000verb");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[216]=C_h_intern(&lf[216],8,"\000ldflags");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[218]=C_h_intern(&lf[218],7,"\000cflags");
lf[219]=C_h_intern(&lf[219],3,"\000cc");
lf[220]=C_h_intern(&lf[220],22,"setup-api#test-compile");
lf[221]=C_h_intern(&lf[221],22,"setup-api#find-library");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\017(); return 0; }");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\015int main() { ");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\003();");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\005char ");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\012extern \042C\042");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\022#ifdef __cplusplus");
lf[230]=C_h_intern(&lf[230],21,"setup-api#find-header");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\033>\012int main() { return 0; }\012");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\012#include <");
lf[233]=C_h_intern(&lf[233],20,"setup-api#version>=\077");
lf[234]=C_h_intern(&lf[234],13,"irregex-split");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[236]=C_h_intern(&lf[236],8,"string>\077");
lf[237]=C_h_intern(&lf[237],27,"setup-api#extension-version");
lf[238]=C_h_intern(&lf[238],12,"string-null\077");
lf[239]=C_h_intern(&lf[239],19,"setup-api#read-info");
lf[240]=C_h_intern(&lf[240],4,"read");
lf[241]=C_h_intern(&lf[241],26,"setup-api#remove-directory");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\004sudo");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010 rm -fr ");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\004SUDO");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[246]=C_h_intern(&lf[246],11,"delete-file");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[248]=C_h_intern(&lf[248],16,"delete-directory");
lf[249]=C_h_intern(&lf[249],16,"remove-directory");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[251]=C_h_intern(&lf[251],26,"setup-api#remove-extension");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000.shell command failed with nonzero exit status ");
lf[254]=C_h_intern(&lf[254],13,"string-append");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\037/usr/bin/env DYLD_LIBRARY_PATH=");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\021DYLD_LIBRARY_PATH");
lf[260]=C_h_intern(&lf[260],30,"setup-api#setup-error-handling");
lf[261]=C_h_intern(&lf[261],5,"reset");
lf[262]=C_h_intern(&lf[262],19,"print-error-message");
lf[263]=C_h_intern(&lf[263],18,"\003sysstandard-error");
lf[264]=C_h_intern(&lf[264],29,"\003syscurrent-exception-handler");
lf[265]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[268]=C_h_intern(&lf[268],14,"make-parameter");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[272]=C_h_intern(&lf[272],17,"\003syspeek-c-string");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\016chicken-status");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\021chicken-uninstall");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\017chicken-install");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[279]=C_h_intern(&lf[279],4,"exit");
lf[280]=C_h_intern(&lf[280],17,"current-directory");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[284]=C_h_intern(&lf[284],13,"chicken-setup");
lf[285]=C_h_intern(&lf[285],7,"windows");
lf[286]=C_h_intern(&lf[286],14,"build-platform");
lf[287]=C_h_intern(&lf[287],13,"software-type");
C_register_lf2(lf,288,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_3012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_3012,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+6);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_TRUE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3022,a[2]=t9,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t9))){
C_trace("setup-api.scm:326: installation-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[114]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[114]+1);
av2[1]=t10;
tp(2,av2);}}
else{
t11=t10;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_i_car(t9);
f_3022(2,av2);}}}

/* k4840 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4842,2,av);}
C_trace("setup-api.scm:612: g1377");
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4847,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4853,a[2]=t2,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:612: with-exception-handler");
t5=C_fast_retrieve(lf[187]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* map-loop448 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in ... */
static void C_fcall f_2798(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2798,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:271: g454");
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3989,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[5]))){
t3=((C_word*)t0)[5];
C_trace("setup-api.scm:481: check-filelist");
f_3271(t2,t3);}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[5]);
C_trace("setup-api.scm:481: check-filelist");
f_3271(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in k4647 in k4643 in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4651,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_nullp(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_i_car(t2);
if(C_truep(C_i_numberp(t5))){
t6=C_i_car(t3);
if(C_truep(C_i_numberp(t6))){
t7=t2;
t8=C_u_i_car(t7);
t9=t3;
t10=C_u_i_car(t9);
t11=C_i_greaterp(t8,t10);
if(C_truep(t11)){
t12=t1;{
C_word av2[2];
av2[0]=t12;
av2[1]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t12=t2;
t13=C_u_i_car(t12);
t14=t3;
t15=C_u_i_car(t14);
if(C_truep(C_i_nequalp(t13,t15))){
t16=t2;
t17=C_u_i_cdr(t16);
t18=t3;
t19=C_u_i_cdr(t18);
C_trace("setup-api.scm:572: loop");
t21=t1;
t22=t17;
t23=t19;
t1=t21;
t2=t22;
t3=t23;
goto loop;}
else{
t16=t1;{
C_word av2[2];
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}}
else{
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t6=C_i_car(t3);
t7=C_i_numberp(t6);
if(C_truep(t7)){
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4719,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t9=t2;
t10=C_u_i_car(t9);
t11=t3;
t12=C_u_i_car(t11);
C_trace("setup-api.scm:574: string>?");
t13=*((C_word*)lf[236]+1);{
C_word av2[4];
av2[0]=t13;
av2[1]=t8;
av2[2]=t10;
av2[3]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}}}}}

/* setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4820(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_4820,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_TRUE:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4987,a[2]=t1,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:607: file-exists?");
t8=C_fast_retrieve(lf[150]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_3979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_3979,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+6);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3989,a[2]=t1,a[3]=t2,a[4]=t7,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:480: setup-install-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[20]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t8;
tp(2,av2);}}

/* k2783 in for-each-loop396 in k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2785,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2775(t3,((C_word*)t0)[4],t2);}

/* k4892 in k4889 in k4886 in k4880 in k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_4894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4894,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4897,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:614: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4643 in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4645,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:565: version->list");
f_4582(t3,((C_word*)t0)[4]);}

/* k4895 in k4892 in k4889 in k4886 in k4880 in k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_4897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4897,2,av);}
C_trace("setup-api.scm:614: $system");
f_5073(((C_word*)t0)[2],t1);}

/* k4889 in k4886 in k4880 in k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_4891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4891,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:615: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}

/* k4647 in k4643 in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4649,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=t3,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4651(t5,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3365 in exify in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3367,2,av);}
if(C_truep(t1)){
if(C_truep(C_i_equalp(lf[171],t1))){
t2=C_fast_retrieve(lf[172]);
t3=C_fast_retrieve(lf[172]);
C_trace("setup-api.scm:378: pathname-replace-extension");
t4=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fast_retrieve(lf[172]);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
if(C_truep(C_i_equalp(lf[173],t1))){
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
C_trace("setup-api.scm:378: pathname-replace-extension");
t2=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[174];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
C_trace("setup-api.scm:378: pathname-replace-extension");
t2=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[175];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}
else{
C_trace("setup-api.scm:378: pathname-replace-extension");
t2=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}
else{
C_trace("setup-api.scm:378: pathname-replace-extension");
t2=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k4203 in k4197 in k4188 in setup-api#ensure-directory in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4205,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
C_trace("setup-api.scm:517: error");
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[182];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in ... */
static void C_ccall f_2767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2767,2,av);}
a=C_alloc(6);
t2=C_i_check_list_2(t1,lf[109]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=t4,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2775(t6,((C_word*)t0)[2],t1);}

/* k4636 in version->list in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4638(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4638,2,av);}
C_trace("setup-api.scm:563: irregex-split");
t2=C_fast_retrieve(lf[234]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[235];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2361 in k2355 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2363,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:191: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2364 in k2361 in k2355 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in ... */
static void C_ccall f_2366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2366,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:191: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[74];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2367 in k2364 in k2361 in k2355 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in ... */
static void C_ccall f_2369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2369,2,av);}
C_trace("setup-api.scm:191: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* g682 in k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_fcall f_3047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3047,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:339: make-pathname");
t4=C_fast_retrieve(lf[79]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3044 in walk in k3032 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3046,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3062,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:340: directory");
t4=C_fast_retrieve(lf[130]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:342: ensure-directory");
f_4183(t2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k2753 in k2750 in k2747 in k2741 in for-each-loop396 in k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_2755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2755,2,av);}
C_trace("setup-api.scm:269: ##sys#flush-output");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[110]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[110]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k2750 in k2747 in k2741 in for-each-loop396 in k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2752,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:269: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k3345 in map-loop736 in setup-api#check-filelist in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3347,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3322(t6,((C_word*)t0)[5],t5);}

/* k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in ... */
static void C_ccall f_2376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,4))){C_save_and_reclaim((void *)f_2376,2,av);}
a=C_alloc(20);
t2=C_mutate2((C_word*)lf[76]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate2((C_word*)lf[77]+1 /* (set! setup-api#register-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[80]+1 /* (set! setup-api#find-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2435,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5290,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=C_mpointer(&a,(void*)C_CHICKEN_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* setup-api#register-program in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_ccall f_2378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +7,c,2))){
C_save_and_reclaim((void*)f_2378,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+7);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:211: ->string");
t6=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_car(t3);
f_2382(2,av2);}}}

/* k4227 in k4209 in k4197 in k4188 in setup-api#ensure-directory in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_4229,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"setup-api#\052chmod-command\052"),lf[183],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:521: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* k2747 in k2741 in for-each-loop396 in k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2749,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:269: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2741 in for-each-loop396 in k2765 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2743,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[72]+1);
t3=*((C_word*)lf[72]+1);
t4=C_i_check_port_2(*((C_word*)lf[72]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[73]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:269: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[111];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[72]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
C_trace("setup-api.scm:270: $system");
f_5073(((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k2340 in k2337 in k2334 in k2331 in k2328 in k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in ... */
static void C_ccall f_2342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2342,2,av);}
C_trace("setup-api.scm:204: $system");
f_5073(((C_word*)t0)[2],t1);}

/* k2344 in k2334 in k2331 in k2328 in k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in ... */
static void C_ccall f_2346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2346,2,av);}
C_trace("setup-api.scm:205: ##sys#print");
t2=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4209 in k4197 in k4188 in setup-api#ensure-directory in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4211(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4211,2,av);}
a=C_alloc(3);
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:521: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}}

/* map-loop1257 in k4595 in version->list in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_fcall f_4602(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_4602,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_string_to_number(&a,2,t3,C_fix(10));
t5=(C_truep(t4)?t4:t3);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t11=t1;
t12=t9;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_3995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3995,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4103,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:483: make-pathname");
t4=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
av2[3]=lf[180];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3992,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3995,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:482: installation-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[114]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[114]+1);
av2[1]=t3;
tp(2,av2);}}

/* a4852 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4853,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:612: k1373");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k2348 in k2328 in k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in ... */
static void C_ccall f_2350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2350,2,av);}
C_trace("setup-api.scm:205: ##sys#print");
t2=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2355 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_ccall f_2357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2357,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[72]+1);
t3=*((C_word*)lf[72]+1);
t4=C_i_check_port_2(*((C_word*)lf[72]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[73]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:191: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[75];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[72]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_2257(2,av2);}}}

/* a4858 in a4852 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4859,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop736 in setup-api#check-filelist in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_3322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_3322,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
if(C_truep(C_i_stringp(t6))){
t7=t5;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3289,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t6))){
C_trace("setup-api.scm:372: every");
t8=C_fast_retrieve(lf[139]);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=*((C_word*)lf[140]+1);
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_3289(2,av2);}}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2723 in map-loop409 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2725,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2700(t6,((C_word*)t0)[5],t5);}

/* k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_3998,2,av);}
a=C_alloc(23);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4002,a[2]=t2,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[82]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4067,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_4067(t13,t9,((C_word*)t0)[2]);}

/* k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in ... */
static void C_ccall f_2321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_2321,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:205: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_retrieve2(lf[30],"setup-api#\052move-command\052");
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in ... */
static void C_ccall f_2327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2327,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:205: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k3001 in k2998 in k2995 in k2992 in k2989 in k2983 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3003,2,av);}
C_trace("setup-api.scm:315: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k2998 in k2995 in k2992 in k2989 in k2983 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3000,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:315: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[126];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2328 in k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in ... */
static void C_ccall f_2330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2330,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2350,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:205: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
tp(3,av2);}}

/* k2331 in k2328 in k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in ... */
static void C_ccall f_2333(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2333,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:205: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k2334 in k2331 in k2328 in k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in ... */
static void C_ccall f_2336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2336,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:206: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}

/* k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4262,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm:527: pathname-replace-extension");
t4=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[211];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2337 in k2334 in k2331 in k2328 in k2325 in k2319 in k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in ... */
static void C_ccall f_2339(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2339,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:205: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_4265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_4265,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[9],a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:529: with-output-to-file");
t5=C_fast_retrieve(lf[68]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_4268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_4268,2,av);}
a=C_alloc(20);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4429,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[6])?lf[193]:lf[194]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm:535: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t6;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* map-loop409 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in ... */
static void C_fcall f_2700(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2700,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:265: g415");
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* setup-api#extension-name in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4757,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4765,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:593: extension-name-and-version");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[147]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[147]+1);
av2[1]=t2;
tp(2,av2);}}

/* k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_4253,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4473,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:524: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[162]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[162]+1);
av2[1]=t3;
av2[2]=lf[214];
av2[3]=((C_word*)t0)[6];
av2[4]=t4;
tp(5,av2);}}

/* k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_4250,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4479,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:524: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[162]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[162]+1);
av2[1]=t3;
av2[2]=lf[216];
av2[3]=((C_word*)t0)[5];
av2[4]=t4;
tp(5,av2);}}

/* k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4259,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm:526: create-temporary-file");
t4=C_fast_retrieve(lf[71]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[212];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_4256,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4470,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:524: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[162]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[162]+1);
av2[1]=t3;
av2[2]=lf[213];
av2[3]=((C_word*)t0)[7];
av2[4]=t4;
tp(5,av2);}}

/* k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in ... */
static void C_ccall f_4280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4280,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[4],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:545: call-with-current-continuation");
t4=*((C_word*)lf[188]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in ... */
static void C_ccall f_4283(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4283,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:545: g1186");
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1953,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[6] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[7] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate2(&lf[8] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=lf[9] /* setup-api#*registered-programs* */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5315,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:86: software-type");
t8=C_fast_retrieve(lf[287]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in ... */
static void C_ccall f_4286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4286,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],C_fix(0));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_4271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4271,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
C_trace("setup-api.scm:543: print");
t5=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[189];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
C_trace("setup-api.scm:543: print");
t5=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[190];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_4274(2,av2);}}}

/* k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_4274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4274,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[5],a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:544: call-with-current-continuation");
t4=*((C_word*)lf[188]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1903 in k1900 in k1897 */
static void C_ccall f_1905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1905,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d1_toplevel(2,av2);}}

/* k3831 in k3813 in k3810 in k3807 in g990 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_3833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3833,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"setup-api#\052chmod-command\052"),lf[121],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:474: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1908,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_irregex_toplevel(2,av2);}}

/* k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_4277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4277,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:544: g1162");
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k1900 in k1897 */
static void C_ccall f_1902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1902,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1920,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* a4912 in a4906 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4913,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k3841 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3843,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:477: supply-version");
f_3431(t3,((C_word*)t0)[4],C_SCHEME_FALSE);}

/* k2169 in k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in ... */
static void C_ccall f_2171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2171,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:163: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[54];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2172 in k2169 in k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in ... */
static void C_ccall f_2174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2174,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:163: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2175 in k2172 in k2169 in k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in ... */
static void C_ccall f_2177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2177,2,av);}
a=C_alloc(4);
t2=C_mutate2(&lf[32] /* (set! setup-api#*ranlib-command* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:164: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4717 in loop in k4647 in k4643 in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4719,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[4];
t5=C_u_i_car(t4);
if(C_truep(C_i_string_equal_p(t3,t5))){
t6=((C_word*)t0)[3];
t7=C_u_i_cdr(t6);
t8=((C_word*)t0)[4];
t9=C_u_i_cdr(t8);
C_trace("setup-api.scm:577: loop");
t10=((C_word*)((C_word*)t0)[5])[1];
f_4651(t10,((C_word*)t0)[2],t7,t9);}
else{
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}

/* a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in ... */
static void C_ccall f_4292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4292,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t2,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4307,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:545: with-exception-handler");
t5=C_fast_retrieve(lf[187]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1929,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_files_toplevel(2,av2);}}

/* a4297 in a4291 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in ... */
static void C_ccall f_4298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4298,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4304,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:545: k1182");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* map-loop984 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_fcall f_3852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3852,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:469: g990");
t5=((C_word*)t0)[4];
f_3805(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1926,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1923,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_ports_toplevel(2,av2);}}

/* k3848 in k3841 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_3850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3850,2,av);}
C_trace("setup-api.scm:477: write-info");
f_2901(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k2179 in k2175 in k2172 in k2169 in k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in ... */
static void C_ccall f_2181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2181,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:164: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2185 in k2179 in k2175 in k2172 in k2169 in k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in ... */
static void C_ccall f_2187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2187,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:164: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[52];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1917,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d13_toplevel(2,av2);}}

/* k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1914,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* g1405 in k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_4927(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4927,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_string_equal_p(lf[245],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4937,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_4937(t5,t3);}
else{
t5=t2;
t6=t4;
f_4937(t6,C_u_i_string_equal_p(lf[247],t5));}}

/* k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1911,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_utils_toplevel(2,av2);}}

/* k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_2155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2155,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:162: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[55];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_2158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2158,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:162: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_4926,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li90),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4957,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4962,a[2]=t5,a[3]=t2,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4962(t7,t3,t1);}

/* walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_fcall f_4922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_4922,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:618: directory");
t4=C_fast_retrieve(lf[130]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4955 in k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4957,2,av);}
C_trace("setup-api.scm:627: delete-directory");
t2=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_4755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_4755,2,av);}
a=C_alloc(24);
t2=C_mutate2((C_word*)lf[147]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate2((C_word*)lf[144]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4757,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[237]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4767,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[239]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4798,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[241]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[251]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4995,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2(&lf[69] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5073,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[260]+1 /* (set! setup-api#setup-error-handling ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5154,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:662: user-install-setup");
f_2202(t10);}

/* k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_2161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2161,2,av);}
a=C_alloc(4);
t2=C_mutate2(&lf[31] /* (set! setup-api#*chmod-command* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:163: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in ... */
static void C_ccall f_2165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2165,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:163: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in ... */
static void C_ccall f_2133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2133,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:161: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2380 in setup-api#register-program in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2382,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2390,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:213: ->string");
t4=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in ... */
static void C_ccall f_2139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2139,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:161: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[56];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4899 in k4889 in k4886 in k4880 in k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_4901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4901,2,av);}
C_trace("setup-api.scm:614: ##sys#print");
t2=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4906 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_4907,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=t2,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:612: k1373");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* setup-api#check-filelist in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_fcall f_3271(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_3271,2,t1,t2);}
a=C_alloc(13);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(t2,lf[82]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3322,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li33),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3322(t11,t1,t2);}

/* k4903 in k4880 in k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_4905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4905,2,av);}
C_trace("setup-api.scm:614: ##sys#print");
t2=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4935 in g1405 in k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_fcall f_4937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_4937,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:622: make-pathname");
t3=C_fast_retrieve(lf[79]);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k1897 */
static void C_ccall f_1899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1899,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2145,2,av);}
a=C_alloc(4);
t2=C_mutate2(&lf[30] /* (set! setup-api#*move-command* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:162: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2142,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:161: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2388 in k2380 in setup-api#register-program in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in ... */
static void C_ccall f_2390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_2390,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t1,((C_word*)t0)[2]),C_retrieve2(lf[9],"setup-api#\052registered-programs\052"));
t3=C_mutate2(&lf[9] /* (set! setup-api#*registered-programs* ...) */,t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2149,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:162: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in ... */
static void C_ccall f_2113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2113,2,av);}
a=C_alloc(4);
t2=C_mutate2(&lf[28] /* (set! setup-api#*copy-command* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:160: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in ... */
static void C_ccall f_2110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2110,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:159: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in ... */
static void C_ccall f_2117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2117,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:160: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2989 in k2983 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2991,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:315: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2995 in k2992 in k2989 in k2983 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_2997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2997,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:315: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2992 in k2989 in k2983 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_2994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2994,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:315: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[127];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in ... */
static void C_ccall f_2126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2126,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:160: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in ... */
static void C_ccall f_2123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2123,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:160: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[57];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3287 in map-loop736 in setup-api#check-filelist in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3289,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_u_i_car(((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[3]);
t4=C_a_i_list2(&a,2,t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
C_trace("setup-api.scm:374: error");
t5=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[138];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}
else{
C_trace("setup-api.scm:374: error");
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[138];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}

/* k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in ... */
static void C_ccall f_2129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2129,2,av);}
a=C_alloc(4);
t2=C_mutate2(&lf[29] /* (set! setup-api#*remove-command* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:161: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2052 in setup-api#extra-nonfeatures in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in ... */
static void C_ccall f_2054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2054,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4944 in k4938 in k4935 in g1405 in k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_4946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4946,2,av);}
if(C_truep(t1)){
C_trace("setup-api.scm:624: walk");
t2=((C_word*)((C_word*)t0)[2])[1];
f_4922(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
C_trace("setup-api.scm:625: delete-file");
t2=C_fast_retrieve(lf[246]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k4938 in k4935 in g1405 in k4924 in walk in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_4940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4940,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:623: directory?");
t4=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a2973 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_2974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2974,2,av);}
t2=C_fast_retrieve(lf[122]);
C_trace("setup-api.scm:323: g639");
t3=C_fast_retrieve(lf[122]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2105 in k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2107(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2107,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:159: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[58];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3264 in setup-api#make-dest-pathname in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3266,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
C_trace("setup-api.scm:367: make-pathname");
t2=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k2099 in k2095 in setup-api#sudo-install in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_ccall f_2101(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2101,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:159: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_4240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +9,c,4))){
C_save_and_reclaim((void*)f_4240,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+9);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_get_keyword(lf[186],t3,C_SCHEME_FALSE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4247,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4485,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:524: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[162]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[162]+1);
av2[1]=t6;
av2[2]=lf[219];
av2[3]=t3;
av2[4]=t7;
tp(5,av2);}}

/* k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_4247,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4482,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:524: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[162]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[162]+1);
av2[1]=t3;
av2[2]=lf[218];
av2[3]=((C_word*)t0)[4];
av2[4]=t4;
tp(5,av2);}}

/* setup-api#extra-nonfeatures in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in ... */
static void C_ccall f_2044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +5,c,3))){
C_save_and_reclaim((void*)f_2044,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+5);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=t4;
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t6;
av2[2]=C_fast_retrieve(lf[27]);
av2[3]=t5;
C_apply(4,av2);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k3210 in k3206 in k3191 in k3188 in k3185 in setup-api#move-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3212,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[30],"setup-api#\052move-command\052"),((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:357: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
tp(3,av2);}}

/* k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in ... */
static void C_ccall f_2015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2015,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[21]+1 /* (set! setup-api#deployment-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:112: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[12],"setup-api#\052chicken-bin-path\052");
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3242 in setup-api#remove-file* in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3244,2,av);}
a=C_alloc(9);
t2=C_a_i_list(&a,2,C_retrieve2(lf[29],"setup-api#\052remove-command\052"),t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:359: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* setup-api#make-dest-pathname in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_fcall f_3246(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_3246,3,t1,t2,t3);}
a=C_alloc(5);
if(C_truep(C_i_listp(t3))){
t4=C_i_cadr(t3);
C_trace("setup-api.scm:364: make-dest-pathname");
t6=t1;
t7=t2;
t8=t4;
t1=t6;
t2=t7;
t3=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3266,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:365: absolute-pathname?");
t5=C_fast_retrieve(lf[132]);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in ... */
static void C_ccall f_2011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2011,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[20]+1 /* (set! setup-api#setup-install-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:111: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in ... */
static void C_ccall f_2019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2019,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[22]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:113: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2980 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_2982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_2982,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_a_i_list(&a,1,t1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2836,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("setup-api.scm:286: repository-path");
t6=C_fast_retrieve(lf[124]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_car(t4);
C_trace("setup-api.scm:287: make-pathname");
t7=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=t6;
av2[3]=t3;
av2[4]=lf[0];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* exify in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_3775(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_3775,2,t1,t2);}
a=C_alloc(8);
t3=(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))?lf[170]:C_SCHEME_FALSE);
t4=t1;
t5=t2;
t6=C_a_i_list(&a,1,t3);
t7=C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:C_i_car(t6));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3367,a[2]=t4,a[3]=t5,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:379: pathname-extension");
t11=C_fast_retrieve(lf[167]);{
C_word av2[3];
av2[0]=t11;
av2[1]=t10;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}

/* k2983 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2985,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=*((C_word*)lf[72]+1);
t3=*((C_word*)lf[72]+1);
t4=C_i_check_port_2(*((C_word*)lf[72]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[73]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:315: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[128];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[72]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_2908(2,av2);}}}

/* k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in ... */
static void C_ccall f_2023(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_2023,2,av);}
a=C_alloc(24);
t2=C_mutate2((C_word*)lf[23]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_mutate2((C_word*)lf[24]+1 /* (set! setup-api#extra-features ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2025,a[2]=t4,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate2((C_word*)lf[26]+1 /* (set! setup-api#extra-nonfeatures ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=t7,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t9=lf[28] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t10=lf[29] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t11=lf[30] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t12=lf[31] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t13=lf[32] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t14=lf[33] /* setup-api#*mkdir-command* */ =C_SCHEME_UNDEFINED;;
t15=C_mutate2(&lf[34] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2202,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[46]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5292,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:183: make-parameter");
t19=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t19;
av2[1]=t17;
av2[2]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}

/* k4427 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_4429(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4429,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-api.scm:541: print");
t4=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[192];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
C_trace("setup-api.scm:530: system");
t4=C_fast_retrieve(lf[191]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* setup-api#extra-features in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in ... */
static void C_ccall f_2025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +5,c,3))){
C_save_and_reclaim((void*)f_2025,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+5);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=t4;
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t6;
av2[2]=C_fast_retrieve(lf[25]);
av2[3]=t5;
C_apply(4,av2);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k2306 in k2290 in loop in a2281 in a2271 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in ... */
static void C_ccall f_2308(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2308,2,av);}
C_trace("setup-api.scm:200: write-line");
t2=C_fast_retrieve(lf[64]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2936 in k2918 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_2938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2938,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"setup-api#\052chmod-command\052"),lf[121],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:324: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* k2299 in k2290 in loop in a2281 in a2271 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in ... */
static void C_ccall f_2301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2301,2,av);}
C_trace("setup-api.scm:201: loop");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2288(t2,((C_word*)t0)[3]);}

/* a4409 in a4403 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in ... */
static void C_ccall f_4410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4410,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* setup-api#remove-file* in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_3228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3228,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:360: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=t2;
tp(3,av2);}}

/* k2312 in k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in ... */
static void C_ccall f_2314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2314,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:205: open-output-string");
t3=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2309 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_2311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_2311,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_list2(&a,2,t2,t2);
C_trace("setup-api.scm:203: patch");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[63]);
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[63]+1);
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
tp(5,av2);}}

/* k2961 in k2957 in k2942 in k2939 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_2963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2963,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[30],"setup-api#\052move-command\052"),((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:322: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
tp(3,av2);}}

/* a2964 in k2939 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_2965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2965,2,av);}
t2=C_fast_retrieve(lf[122]);
C_trace("setup-api.scm:321: g627");
t3=C_fast_retrieve(lf[122]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3789(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3789,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[6]))){
t3=((C_word*)t0)[6];
C_trace("setup-api.scm:459: check-filelist");
f_3271(t2,t3);}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[6]);
C_trace("setup-api.scm:459: check-filelist");
f_3271(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4880 in k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_4882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_4882,2,av);}
a=C_alloc(10);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4905,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:614: qs");
t7=C_fast_retrieve(lf[15]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k4886 in k4880 in k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_4888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4888,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:614: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[243];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in ... */
static void C_ccall f_2007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2007,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[19]+1 /* (set! setup-api#setup-verbose-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:110: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_2917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2917,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"setup-api#\052sudo\052"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2941,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:320: create-temporary-file");
t4=C_fast_retrieve(lf[71]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[4],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:323: with-output-to-file");
t4=C_fast_retrieve(lf[68]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in ... */
static void C_ccall f_2003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2003,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[18]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:109: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2911,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2982,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:317: repo-path");
f_4121(t4,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_2914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2914,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:318: ensure-directory");
f_4183(t3,t2,C_SCHEME_END_OF_LIST);}

/* k4870 in a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4872,2,av);}
a=C_alloc(5);
t2=(C_truep(t1)?t1:lf[242]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:614: open-output-string");
t5=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k3206 in k3191 in k3188 in k3185 in setup-api#move-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3208,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3212,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:357: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k2939 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_2941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2941,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[4],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:321: with-output-to-file");
t5=C_fast_retrieve(lf[68]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k2942 in k2939 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_2944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2944,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:322: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4862,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[3],a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:612: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a4867 in a4861 in a4846 in k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4868,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4872,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:613: get-environment-variable");
t3=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[244];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_3798,2,av);}
a=C_alloc(24);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3801,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[10],"setup-api#\052windows\052"))){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[5],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t9=C_i_check_list_2(((C_word*)t0)[6],lf[82]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3925,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=t7,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_3925(t13,t3,((C_word*)t0)[6]);}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[6];
f_3801(2,av2);}}}

/* k2033 in setup-api#extra-features in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in ... */
static void C_ccall f_2035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2035,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2918 in k2915 in k2912 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_2920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2920,2,av);}
a=C_alloc(3);
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:324: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}}

/* k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_3795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3795,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:461: make-pathname");
t4=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
av2[3]=lf[176];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3792,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:460: installation-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[114]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[114]+1);
av2[1]=t3;
tp(2,av2);}}

/* k4400 in k4390 in k4387 in k4381 in a4374 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in ... */
static void C_ccall f_4402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4402,2,av);}
C_trace("setup-api.scm:544: ##sys#print");
t2=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4403 in a4368 in a4353 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in ... */
static void C_ccall f_4404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_4404,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=t2,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:544: k1158");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k3904 in k3900 in g962 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_3906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_3906,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3900 in g962 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3902,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm:465: exify");
f_3775(t3,t4);}

/* k5313 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_5315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5315,2,av);}
t2=C_eqp(t1,lf[285]);
if(C_truep(t2)){
C_trace("setup-api.scm:87: build-platform");
t3=C_fast_retrieve(lf[286]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_1960(2,av2);}}}

/* k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2908,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:316: ->string");
t3=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_fcall f_2901(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,0,2))){
C_save_and_reclaim_args((void *)trf_2901,4,t1,t2,t3,t4);}
a=C_alloc(16);
t5=C_a_i_cons(&a,2,lf[120],t3);
t6=C_a_i_cons(&a,2,t5,t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2908,a[2]=t1,a[3]=t7,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2985,a[2]=t8,a[3]=t7,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:315: setup-verbose-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[19]);
C_word av2[2];
av2[0]=*((C_word*)lf[19]+1);
av2[1]=t9;
tp(2,av2);}}

/* k3518 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_3520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_3520,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3524,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:419: pathname-replace-extension");
t5=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
av2[3]=lf[152];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k3533 in k3526 in k3518 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_3535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_3535,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_3524(t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}
else{
t2=((C_word*)t0)[3];
f_3524(t2,C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST));}}

/* k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_3590,2,av);}
a=C_alloc(24);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3594,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[82]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3710,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3719,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_3719(t13,t9,((C_word*)t0)[3]);}

/* setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_4492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4492,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4500,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:552: open-output-string");
t5=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* map-loop956 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3925,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:463: g962");
t5=((C_word*)t0)[4];
f_3888(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3522 in k3518 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_fcall f_3524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_3524,2,t0,t1);}
a=C_alloc(8);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:423: supply-version");
f_3431(t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3526 in k3518 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_3528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3528,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:420: file-exists?");
t4=C_fast_retrieve(lf[150]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3581,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[5]))){
t3=((C_word*)t0)[5];
C_trace("setup-api.scm:430: check-filelist");
f_3271(t2,t3);}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[5]);
C_trace("setup-api.scm:430: check-filelist");
f_3271(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4441 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_4443(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_4443,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm:535: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[9];
tp(3,av2);}}

/* k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_fcall f_3598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3598,2,t0,t1);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:435: make-dest-pathname");
f_3246(t3,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_3594(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3594,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=t3;
f_3598(t5,C_u_i_car(t4));}
else{
t4=t3;
f_3598(t4,t2);}}

/* k4445 in k4441 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_4447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,7))){C_save_and_reclaim((void *)f_4447,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[206];
f_4451(2,av2);}}
else{
C_trace("setup-api.scm:538: conc");
t4=C_fast_retrieve(lf[199]);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[207];
av2[3]=C_retrieve2(lf[6],"setup-api#\052target-lib-home\052");
av2[4]=lf[208];
av2[5]=((C_word*)t0)[9];
av2[6]=lf[209];
av2[7]=C_retrieve2(lf[5],"setup-api#\052target-libs\052");
((C_proc)(void*)(*((C_word*)t4+1)))(8,av2);}}}

/* setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_3571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_3571,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+6);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3581,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:429: setup-install-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[20]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[20]+1);
av2[1]=t8;
tp(2,av2);}}

/* k4430 in k4427 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_4432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4432,2,av);}
C_trace("setup-api.scm:530: system");
t2=C_fast_retrieve(lf[191]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_3587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3587,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:432: repo-path");
f_4121(t2,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3584,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3587,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:431: repo-path");
f_4121(t3,C_SCHEME_END_OF_LIST);}

/* k2290 in loop in a2281 in a2271 in k2255 in setup-api#patch in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in ... */
static void C_ccall f_2292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_2292,2,av);}
a=C_alloc(7);
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2308,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:200: irregex-replace/all");
t4=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t1;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* a4481 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4482,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[217];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4484 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4485,2,av);}
if(C_truep(((C_word*)t0)[2])){
t2=C_retrieve2(lf[3],"setup-api#\052cxx\052");
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_retrieve2(lf[3],"setup-api#\052cxx\052");
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_retrieve2(lf[2],"setup-api#\052cc\052");
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_retrieve2(lf[2],"setup-api#\052cc\052");
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a3555 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3556,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4469 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4470,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4472 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4473,2,av);}
C_trace("setup-api.scm:525: setup-verbose-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[19]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[19]+1);
av2[1]=t1;
tp(2,av2);}}

/* a4478 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4479,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[215];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_3474(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,4))){
C_save_and_reclaim((void*)f_3474,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3487,a[2]=t1,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:408: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[162]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[162]+1);
av2[1]=t9;
av2[2]=lf[163];
av2[3]=t8;
av2[4]=t10;
tp(5,av2);}}

/* k3470 in k3455 in setup-api#supply-version in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3472,2,av);}
a=C_alloc(6);
t2=C_a_i_list(&a,2,lf[143],t1);
C_trace("setup-api.scm:400: cons*");
t3=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5213 in k5183 in a5168 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_5215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5215,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5219,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:588: ensure-string");
f_5192(t3,((C_word*)t0)[4]);}

/* k5217 in k5213 in k5183 in a5168 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_5219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_5219,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3455 in setup-api#supply-version in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_3457,2,av);}
a=C_alloc(11);
t2=C_a_i_list(&a,2,lf[142],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:402: extension-name");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[144]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[144]+1);
av2[1]=t4;
tp(2,av2);}}

/* k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_2622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_2622,2,av);}
a=C_alloc(18);
t2=(C_truep(t1)?lf[91]:lf[92]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2522,a[2]=t4,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:253: extra-features");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[24]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[24]+1);
av2[1]=t9;
tp(2,av2);}}

/* k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_2625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2625,2,av);}
a=C_alloc(7);
t2=(C_truep(t1)?lf[89]:lf[90]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:249: deployment-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[21]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[21]+1);
av2[1]=t4;
tp(2,av2);}}

/* k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2628,2,av);}
a=C_alloc(6);
t2=(C_truep(t1)?lf[87]:lf[88]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:248: host-extension");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[11]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[11]+1);
av2[1]=t4;
tp(2,av2);}}

/* k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_4521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4521,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[226];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_4527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4527,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[225];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_4524(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4524,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4518,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k3449 in g805 in setup-api#supply-version in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_3451,2,av);}
a=C_alloc(9);
t2=C_a_i_list(&a,2,lf[143],t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3514 in k3522 in k3518 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_3516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3516,2,av);}
C_trace("setup-api.scm:416: install-extension");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[149]);
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[149]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
tp(5,av2);}}

/* k2629 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2631,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[2];
f_2489(t4,(C_truep(t3)?lf[102]:lf[101]));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2640,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:244: feature?");
t4=C_fast_retrieve(lf[103]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[104];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k2632 in k2629 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2634,2,av);}
t2=((C_word*)t0)[2];
f_2489(t2,(C_truep(t1)?lf[101]:lf[102]));}

/* k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4512,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4515,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[227];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4509,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[228];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_3505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_3505,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm:418: pathname-replace-extension");
t3=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=lf[153];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(33,c,2))){C_save_and_reclaim((void *)f_3502,2,av);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_a_i_list(&a,7,lf[154],lf[155],lf[156],C_fix(3),lf[157],C_fix(0),((C_word*)t0)[7]);
t4=C_a_i_list1(&a,1,t3);
C_trace("setup-api.scm:415: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=t2;
av2[2]=t4;
tp(3,av2);}}

/* g805 in setup-api#supply-version in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_3439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_3439,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3451,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:396: extension-name");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[144]);
C_word av2[2];
av2[0]=*((C_word*)lf[144]+1);
av2[1]=t2;
tp(2,av2);}}

/* k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in ... */
static void C_ccall f_2681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_2681,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2692,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
t5=t3;
t6=t4;
if(C_truep(C_i_string_equal_p(t6,lf[85]))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2481,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:241: find-program");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[80]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[80]+1);
av2[1]=t8;
av2[2]=lf[105];
tp(3,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:259: string-prefix?");
t8=C_fast_retrieve(lf[107]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[108];
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}

/* a4463 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_4464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4464,2,av);}
C_trace("setup-api.scm:529: g1151");
t2=*((C_word*)lf[210]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4500,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[229];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4506,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* setup-api#supply-version in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_fcall f_3431(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_3431,3,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_assq(lf[142],t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3439,a[2]=t2,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:392: g805");
t5=t4;
f_3439(t5,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3457,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
if(C_truep(t3)){
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3403,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:387: extension-name-and-version");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[147]);
C_word av2[2];
av2[0]=*((C_word*)lf[147]+1);
av2[1]=t6;
tp(2,av2);}}}}

/* k3948 in map-loop956 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3950,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3925(t6,((C_word*)t0)[5],t5);}

/* k2690 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2692,2,av);}
a=C_alloc(3);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
C_trace("setup-api.scm:266: string-intersperse");
t4=C_fast_retrieve(lf[83]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
av2[3]=lf[84];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4449 in k4445 in k4441 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in setup-api#try-compile in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_4451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,16))){C_save_and_reclaim((void *)f_4451,2,av);}
t2=(C_truep(C_retrieve2(lf[10],"setup-api#\052windows\052"))?lf[195]:lf[196]);
t3=(C_truep(((C_word*)t0)[2])?lf[197]:lf[198]);
C_trace("setup-api.scm:531: conc");
t4=C_fast_retrieve(lf[199]);{
C_word *av2;
if(c >= 17) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(17);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=((C_word*)t0)[5];
av2[5]=lf[201];
av2[6]=((C_word*)t0)[6];
av2[7]=lf[202];
av2[8]=C_retrieve2(lf[4],"setup-api#\052target-cflags\052");
av2[9]=lf[203];
av2[10]=((C_word*)t0)[7];
av2[11]=lf[204];
av2[12]=((C_word*)t0)[8];
av2[13]=lf[205];
av2[14]=t1;
av2[15]=t2;
av2[16]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(17,av2);}}

/* k3959 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3961(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3961,2,av);}
a=C_alloc(3);
C_trace("setup-api.scm:461: ensure-directory");
f_4183(((C_word*)t0)[2],t1,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k4543 in k4540 in k4537 in k4534 in k4531 in k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in ... */
static void C_ccall f_4545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4545,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:552: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4546 in k4543 in k4540 in k4537 in k4534 in k4531 in k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in ... */
static void C_ccall f_4548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4548,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:553: conc");
t4=C_fast_retrieve(lf[199]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[222];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* g990 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3805,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3809,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=t3;
f_3809(t5,C_u_i_car(t4));}
else{
t4=t3;
f_3809(t4,t2);}}

/* k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3801(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_3801,2,av);}
a=C_alloc(23);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[2],a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t7=C_i_check_list_2(t1,lf[82]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3852,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=t5,a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_3852(t12,t8,t1);}

/* k2638 in k2629 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2640,2,av);}
if(C_truep(t1)){
C_trace("setup-api.scm:245: host-extension");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[11]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[11]+1);
av2[1]=((C_word*)t0)[2];
tp(2,av2);}}
else{
t2=((C_word*)t0)[3];
f_2489(t2,lf[101]);}}

/* k4540 in k4537 in k4534 in k4531 in k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in ... */
static void C_ccall f_4542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4542,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:552: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k4537 in k4534 in k4531 in k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in ... */
static void C_ccall f_4539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4539,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[223];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4534 in k4531 in k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in ... */
static void C_ccall f_4536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4536,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3807 in g990 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_fcall f_3809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_3809,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3812,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:471: make-dest-pathname");
f_3246(t3,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k3816 in k3813 in k3810 in k3807 in g990 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_3818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3818,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3813 in k3810 in k3807 in g990 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_3815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3815,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3833,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:474: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}}

/* k3810 in k3807 in g990 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_3812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_3812,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:472: copy-file");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[129]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[129]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
tp(4,av2);}}

/* a5291 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in ... */
static void C_ccall f_5292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5292,2,av);}
t2=C_fast_retrieve(lf[279]);
C_trace("setup-api.scm:183: g215");
t3=C_fast_retrieve(lf[279]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4531 in k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in ... */
static void C_ccall f_4533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4533,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[224];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_4530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4530,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:552: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k5288 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in ... */
static void C_ccall f_5290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5290,2,av);}
C_trace("setup-api.scm:225: reg");
f_2424(((C_word*)t0)[3],lf[278],t1);}

/* k5280 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in ... */
static void C_ccall f_5282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5282,2,av);}
C_trace("setup-api.scm:227: reg");
f_2424(((C_word*)t0)[3],lf[276],t1);}

/* k5284 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in ... */
static void C_ccall f_5286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5286,2,av);}
C_trace("setup-api.scm:226: reg");
f_2424(((C_word*)t0)[3],lf[277],t1);}

/* k4595 in version->list in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4597,2,av);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4602(t5,((C_word*)t0)[4],t1);}

/* k5272 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in ... */
static void C_ccall f_5274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5274,2,av);}
C_trace("setup-api.scm:229: reg");
f_2424(((C_word*)t0)[3],lf[274],t1);}

/* k5276 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in ... */
static void C_ccall f_5278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5278,2,av);}
C_trace("setup-api.scm:228: reg");
f_2424(((C_word*)t0)[3],lf[275],t1);}

/* k5268 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in ... */
static void C_ccall f_5270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5270,2,av);}
C_trace("setup-api.scm:230: reg");
f_2424(((C_word*)t0)[3],lf[273],t1);}

/* k5264 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in ... */
static void C_ccall f_5266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5266,2,av);}
C_trace("setup-api.scm:231: reg");
f_2424(((C_word*)t0)[3],lf[271],t1);}

/* k5260 in k5245 */
static void C_ccall f_5262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_5262,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[33],"setup-api#\052mkdir-command\052"),lf[117],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:310: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* version->list in setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_4582(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_4582,2,t1,t2);}
a=C_alloc(13);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4597,a[2]=t5,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4638,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:563: ->string");
t9=C_fast_retrieve(lf[78]);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k4575 in k4572 in k4569 in k4566 in k4560 in setup-api#find-header in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4577,2,av);}
C_trace("setup-api.scm:556: test-compile");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[220]);
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[220]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[213];
av2[4]=C_SCHEME_TRUE;
tp(5,av2);}}

/* setup-api#version>=? in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_4579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4579,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4582,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4645,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:564: version->list");
f_4582(t5,t2);}

/* k2610 in map-loop339 in k2520 in k2620 in k2623 in k2626 in k2487 in k2483 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_2612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2612,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2587(t6,((C_word*)t0)[5],t5);}

/* k4569 in k4566 in k4560 in setup-api#find-header in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_4571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4571,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:557: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[231];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4572 in k4569 in k4566 in k4560 in setup-api#find-header in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_4574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4574,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:557: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5245 */
static void C_ccall f_5247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5247,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:310: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k2664 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2666(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2666,2,av);}
a=C_alloc(3);
t2=(C_truep(t1)?C_retrieve2(lf[8],"setup-api#\052windows-shell\052"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:260: substring");
t4=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(2);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
C_trace("setup-api.scm:261: find-program");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[80]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[80]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}}

/* k3497 in k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(39,c,2))){C_save_and_reclaim((void *)f_3499,2,av);}
a=C_alloc(39);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_a_i_list(&a,9,lf[154],lf[155],lf[156],C_fix(3),lf[157],C_fix(1),((C_word*)t0)[7],lf[158],((C_word*)t0)[3]);
t5=C_a_i_list1(&a,1,t4);
C_trace("setup-api.scm:408: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=t3;
av2[2]=t5;
tp(3,av2);}}

/* k3494 in k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_3496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_3496,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm:413: make-pathname");
t4=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[7];
av2[4]=lf[159];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* f_5243 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_5243(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5243,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:309: verb");
f_2874(t3,t2);}

/* k2658 in k2664 in k2679 in smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2660,2,av);}
C_trace("setup-api.scm:260: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k3491 in k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_3493(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_3493,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm:412: make-pathname");
t4=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[6];
av2[4]=lf[160];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in ... */
static void C_ccall f_2668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,3))){C_save_and_reclaim((void *)f_2668,3,av);}
a=C_alloc(20);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2671,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=t3;
t9=C_i_check_list_2(t2,lf[82]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2798,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,a[6]=((C_word)li17),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_2798(t14,t10,t2);}

/* k3488 in k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3490(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3490,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm:411: make-pathname");
t4=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=t2;
av2[4]=lf[161];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3485 in setup-api#standard-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3487,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:410: ->string");
t4=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* f_5235 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_5235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5235,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5239,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:306: verb");
f_2874(t3,t2);}

/* smooth in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in ... */
static void C_ccall f_2671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_2671,3,av);}
a=C_alloc(17);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_fast_retrieve(lf[78]);
t8=C_i_check_list_2(t2,lf[82]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2700,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li14),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_2700(t13,t9,t2);}

/* k3698 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_3700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3700,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"setup-api#\052chmod-command\052"),lf[121],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:438: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* k5237 */
static void C_ccall f_5239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5239,2,av);}
C_trace("setup-api.scm:307: create-directory");
t2=C_fast_retrieve(lf[116]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4063 in k4038 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_4065,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"setup-api#\052chmod-command\052"),lf[178],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:493: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* k2879 in verb in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2881,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[72]+1);
t3=*((C_word*)lf[72]+1);
t4=C_i_check_port_2(*((C_word*)lf[72]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[73]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:303: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[115];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[72]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1040 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_4067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4067,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:484: g1046");
t5=((C_word*)t0)[4];
f_4002(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2885 in k2879 in verb in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_2887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2887,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:303: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in ... */
static void C_ccall f_1984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1984,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[13]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate2((C_word*)lf[14]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1986,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:106: current-directory");
t5=C_fast_retrieve(lf[280]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* setup-api#shellpath in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in ... */
static void C_ccall f_1986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1986,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1994,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:103: normalize-pathname");
t4=C_fast_retrieve(lf[16]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in ... */
static void C_ccall f_1981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1981,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
f_1984(2,av2);}}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_PREFIX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k4048 in k4041 in k4038 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_4050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4050,2,av);}
C_trace("setup-api.scm:494: write-info");
f_2901(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in ... */
static void C_ccall f_1974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1974,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
f_1977(2,av2);}}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[272]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_BIN_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 */
static void C_ccall f_1971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_1971,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
C_trace("setup-api.scm:95: make-pathname");
t3=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=lf[282];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_1974(2,av2);}}}

/* k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in ... */
static void C_ccall f_1977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1977,2,av);}
a=C_alloc(3);
t2=C_mutate2(&lf[12] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:99: get-environment-variable");
t4=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[281];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop885 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_3719(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3719,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-api.scm:433: g891");
t5=((C_word*)t0)[4];
f_3594(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3715 in k3708 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_3717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3717,2,av);}
C_trace("setup-api.scm:451: write-info");
f_2901(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3708 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3710,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:451: supply-version");
f_3431(t3,((C_word*)t0)[4],C_SCHEME_FALSE);}

/* k2888 in k2885 in k2879 in verb in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_2890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2890,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:303: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k2891 in k2888 in k2885 in k2879 in verb in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_2893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2893,2,av);}
C_trace("setup-api.scm:303: ##sys#flush-output");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[110]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[110]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k1992 in setup-api#shellpath in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in ... */
static void C_ccall f_1994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1994,2,av);}
C_trace("setup-api.scm:103: qs");
t2=C_fast_retrieve(lf[15]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in k1965 in k1961 in k1958 in k1951 in k1947 in k1943 in k1939 in k1935 in k1930 in k1927 in k1924 in k1921 in k1918 in k1915 in k1912 in k1909 in ... */
static void C_ccall f_1999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1999,2,av);}
a=C_alloc(3);
t2=C_mutate2(&lf[17] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:108: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[17],"setup-api#\052base-directory\052");
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4566 in k4560 in setup-api#find-header in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4568,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:557: ##sys#print");
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4090 in map-loop1040 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4092,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4067(t6,((C_word*)t0)[5],t5);}

/* k4560 in setup-api#find-header in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4562,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[49]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:557: ##sys#print");
t6=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[232];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* verb in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_fcall f_2874(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_2874,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:302: setup-verbose-mode");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[19]);
C_word av2[2];
av2[0]=*((C_word*)lf[19]+1);
av2[1]=t3;
tp(2,av2);}}

/* setup-api#find-header in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_4554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4554,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4562,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:557: open-output-string");
t4=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4550 in k4546 in k4543 in k4540 in k4537 in k4534 in k4531 in k4528 in k4525 in k4522 in k4519 in k4516 in k4513 in k4510 in k4507 in k4504 in k4498 in setup-api#find-library in k2858 in k2854 in k2850 in k2451 in ... */
static void C_ccall f_4552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4552,2,av);}
C_trace("setup-api.scm:551: test-compile");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[220]);
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[220]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[216];
av2[4]=t1;
tp(5,av2);}}

/* k3401 in setup-api#supply-version in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_3403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3403,2,av);}
if(C_truep(t1)){
if(C_truep(C_i_pairp(t1))){
t2=C_i_cadr(t1);
t3=C_i_equalp(lf[145],t2);
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?lf[146]:C_i_cadr(t1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[146];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[146];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3875 in map-loop984 in k3799 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_3877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3877,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3852(t6,((C_word*)t0)[5],t5);}

/* k4985 in setup-api#remove-directory in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4987,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[7],"setup-api#\052sudo\052"))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[3],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:612: call-with-current-continuation");
t4=*((C_word*)lf[188]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4922,a[2]=t3,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4922(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-api.scm:609: error");
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[249];
av2[3]=lf[250];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* k3634 in k3617 in k3611 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in ... */
static void C_ccall f_3636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3636,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:445: runtime-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[113]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[113]+1);
av2[1]=t3;
tp(2,av2);}}

/* k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in ... */
static void C_ccall f_2856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2856,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[113]+1 /* (set! setup-api#runtime-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:293: get-environment-variable");
t4=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[270];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in k1972 in k1969 in ... */
static void C_ccall f_2852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2852,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[112]+1 /* (set! setup-api#destination-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:290: make-parameter");
t4=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* g962 in k3796 in k3793 in k3790 in k3787 in setup-api#install-program in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_3888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3888,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3902,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
C_trace("setup-api.scm:465: exify");
f_3775(t3,t4);}
else{
C_trace("setup-api.scm:466: exify");
f_3775(t1,t2);}}

/* k2834 in k2980 in k2909 in k2906 in setup-api#write-info in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in ... */
static void C_ccall f_2836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2836,2,av);}
C_trace("setup-api.scm:287: make-pathname");
t2=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
av2[4]=lf[0];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4004 in g1046 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_fcall f_4006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_4006,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:486: make-dest-pathname");
f_3246(t3,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* g1046 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_fcall f_4002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4002,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4006,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=t3;
f_4006(t5,C_u_i_car(t4));}
else{
t4=t3;
f_4006(t4,t2);}}

/* k4007 in k4004 in g1046 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in ... */
static void C_ccall f_4009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4009,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:487: copy-file");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[129]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[129]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
tp(4,av2);}}

/* k3683 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_ccall f_3685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3685,2,av);}
a=C_alloc(3);
t2=C_eqp(t1,lf[165]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_equalp(t3,((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:442: pathname-extension");
t5=C_fast_retrieve(lf[167]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=((C_word*)t0)[4];
f_3646(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[4];
f_3646(t3,C_SCHEME_FALSE);}}

/* k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in ... */
static void C_ccall f_2860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(68,c,5))){C_save_and_reclaim((void *)f_2860,2,av);}
a=C_alloc(68);
t2=t1;
t3=C_mutate2((C_word*)lf[114]+1 /* (set! setup-api#installation-prefix ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2861,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[10],"setup-api#\052windows\052"))?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5235,a[2]=t4,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5243,a[2]=t4,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t6=C_mutate2((C_word*)lf[118]+1 /* (set! setup-api#create-directory/parents ...) */,t5);
t7=C_mutate2(&lf[119] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2901,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[129]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[133]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[134]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3228,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2(&lf[135] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2(&lf[136] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3271,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2(&lf[141] /* (set! setup-api#supply-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3431,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[148]+1 /* (set! setup-api#standard-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3474,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[149]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[169]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[177]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3979,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2(&lf[125] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2(&lf[123] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4183,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[185]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4240,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[220]+1 /* (set! setup-api#test-compile ...) */,C_fast_retrieve(lf[185]));
t22=C_mutate2((C_word*)lf[221]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4492,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[230]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4554,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2((C_word*)lf[233]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4579,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5169,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:580: make-parameter");
t27=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t27;
av2[1]=t25;
av2[2]=lf[269];
av2[3]=t26;
((C_proc)(void*)(*((C_word*)t27+1)))(4,av2);}}

/* setup-api#installation-prefix in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_2861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2861,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:295: destination-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[112]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[112]+1);
av2[1]=t2;
tp(2,av2);}}

/* k2863 in setup-api#installation-prefix in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_2865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2865,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_fast_retrieve(lf[13]));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5183 in a5168 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_fcall f_5185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_5185,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5192,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:588: ensure-string");
f_5192(t6,t2);}
else{
C_trace("setup-api.scm:590: error");
t2=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[267];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k4013 in k4010 in k4007 in k4004 in g1046 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_4015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4015,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4010 in k4007 in k4004 in g1046 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in ... */
static void C_ccall f_4012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_4012,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:489: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}}

/* k4038 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4040,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#\052windows-shell\052"))){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_4043(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:493: string-intersperse");
t5=C_fast_retrieve(lf[83]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[179];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k4041 in k4038 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4043,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:494: supply-version");
f_3431(t2,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k3644 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in ... */
static void C_fcall f_3646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_3646,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:443: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word av2[3];
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
f_3613(2,av2);}}}

/* k2821 in map-loop448 in setup-api#execute in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in k1975 in ... */
static void C_ccall f_2823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2823,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2798(t6,((C_word*)t0)[5],t5);}

/* k3191 in k3188 in k3185 in setup-api#move-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_3193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3193,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:357: shellpath");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[14]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[14]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* k3188 in k3185 in setup-api#move-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_3190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3190,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:356: ensure-directory");
f_4183(t3,t2,C_SCHEME_END_OF_LIST);}

/* k3638 in k3634 in k3617 in k3611 in k3605 in k3602 in k3599 in k3596 in g891 in k3588 in k3585 in k3582 in k3579 in setup-api#install-extension in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in ... */
static void C_ccall f_3640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3640,2,av);}
a=C_alloc(4);
if(C_truep(C_i_equalp(((C_word*)t0)[2],t1))){
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:234: runtime-prefix");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[113]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[113]+1);
av2[1]=t4;
tp(2,av2);}}}

/* a5168 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_5169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5169,3,av);}
a=C_alloc(4);
t3=C_i_not(t2);
t4=(C_truep(t3)?t3:C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=lf[265];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5185,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t2))){
t6=t2;
t7=C_u_i_length(t6);
t8=t5;
f_5185(t8,C_eqp(C_fix(2),t7));}
else{
t6=t5;
f_5185(t6,C_SCHEME_FALSE);}}}

/* k4028 in k4010 in k4007 in k4004 in g1046 in k3996 in k3993 in k3990 in k3987 in setup-api#install-script in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in ... */
static void C_ccall f_4030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_4030,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"setup-api#\052chmod-command\052"),lf[121],t1);
t3=C_a_i_list1(&a,1,t2);
C_trace("setup-api.scm:489: execute");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[81]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[81]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
tp(3,av2);}}

/* k5165 in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_5167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5167,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5158 in tmp11893 in setup-api#setup-error-handling in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in ... */
static void C_ccall f_5160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5160,2,av);}
C_trace("setup-api.scm:656: reset");
t2=C_fast_retrieve(lf[261]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3179 in k3175 in k3029 in k3026 in k3020 in setup-api#copy-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_3181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3181,2,av);}
C_trace("setup-api.scm:349: string-prefix?");
t2=C_fast_retrieve(lf[107]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* setup-api#move-file in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in k1979 in ... */
static void C_ccall f_3183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3183,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3187,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t2))){
t5=t2;
t6=t4;
f_3187(t6,C_u_i_car(t5));}
else{
t5=t4;
f_3187(t5,t2);}}

/* k4163 in k4160 in k4157 in k4151 in k4141 in k4135 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in ... */
static void C_ccall f_4165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4165,2,av);}
C_trace("setup-api.scm:505: make-pathname");
t2=C_fast_retrieve(lf[79]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4160 in k4157 in k4151 in k4141 in k4135 in setup-api#repo-path in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in ... */
static void C_ccall f_4162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4162,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm:507: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5150 in setup-api#$system in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_5152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5152,2,av);}
t2=C_eqp(t1,lf[165]);
if(C_truep(t2)){
C_trace("setup-api.scm:642: get-environment-variable");
t3=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[259];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5127(2,av2);}}}

/* setup-api#setup-error-handling in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_5154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5154,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5156,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate2((C_word*)lf[264]+1 /* (set! ##sys#current-exception-handler ...) */,t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* tmp11893 in setup-api#setup-error-handling in k4753 in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_5156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5156,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5160,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:655: print-error-message");
t4=C_fast_retrieve(lf[262]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=*((C_word*)lf[263]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4197 in k4188 in setup-api#ensure-directory in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4199,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm:516: directory?");
t3=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:519: create-directory/parents");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[118]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[118]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}}

/* k2188 in k2185 in k2179 in k2175 in k2172 in k2169 in k2163 in k2159 in k2156 in k2153 in k2147 in k2143 in k2140 in k2137 in k2131 in k2127 in k2124 in k2121 in k2115 in k2111 in k2108 in k2105 in ... */
static void C_ccall f_2190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2190,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm:164: get-output-string");
t3=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4191 in k4188 in setup-api#ensure-directory in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in ... */
static void C_ccall f_4193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4193,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4188 in setup-api#ensure-directory in k2858 in k2854 in k2850 in k2451 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 in k2374 in k2249 in k2021 in k2017 in k2013 in k2009 in k2005 in k2001 in k1997 in k1982 in ... */
static void C_ccall f_4190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_4190,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm:515: file-exists?");
t5=C_fast_retrieve(lf[150]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[484] = {
{"f_3187:setup_2dapi_2escm",(void*)f_3187},
{"f_3744:setup_2dapi_2escm",(void*)f_3744},
{"f_3619:setup_2dapi_2escm",(void*)f_3619},
{"f_3613:setup_2dapi_2escm",(void*)f_3613},
{"f_4143:setup_2dapi_2escm",(void*)f_4143},
{"f_3177:setup_2dapi_2escm",(void*)f_3177},
{"f_2197:setup_2dapi_2escm",(void*)f_2197},
{"f_2193:setup_2dapi_2escm",(void*)f_2193},
{"f_2282:setup_2dapi_2escm",(void*)f_2282},
{"f_2288:setup_2dapi_2escm",(void*)f_2288},
{"f_3607:setup_2dapi_2escm",(void*)f_3607},
{"f_3601:setup_2dapi_2escm",(void*)f_3601},
{"f_3604:setup_2dapi_2escm",(void*)f_3604},
{"f_2441:setup_2dapi_2escm",(void*)f_2441},
{"f_2447:setup_2dapi_2escm",(void*)f_2447},
{"f_2444:setup_2dapi_2escm",(void*)f_2444},
{"f_3677:setup_2dapi_2escm",(void*)f_3677},
{"f_3769:setup_2dapi_2escm",(void*)f_3769},
{"f_2737:setup_2dapi_2escm",(void*)f_2737},
{"f_1941:setup_2dapi_2escm",(void*)f_1941},
{"f_2453:setup_2dapi_2escm",(void*)f_2453},
{"f_2450:setup_2dapi_2escm",(void*)f_2450},
{"f_2459:setup_2dapi_2escm",(void*)f_2459},
{"f_5192:setup_2dapi_2escm",(void*)f_5192},
{"f_3661:setup_2dapi_2escm",(void*)f_3661},
{"f_2424:setup_2dapi_2escm",(void*)f_2424},
{"f_5102:setup_2dapi_2escm",(void*)f_5102},
{"f_5108:setup_2dapi_2escm",(void*)f_5108},
{"f_5105:setup_2dapi_2escm",(void*)f_5105},
{"f_2272:setup_2dapi_2escm",(void*)f_2272},
{"f_1945:setup_2dapi_2escm",(void*)f_1945},
{"f_1949:setup_2dapi_2escm",(void*)f_1949},
{"f_1960:setup_2dapi_2escm",(void*)f_1960},
{"f_2432:setup_2dapi_2escm",(void*)f_2432},
{"f_4183:setup_2dapi_2escm",(void*)f_4183},
{"f_2097:setup_2dapi_2escm",(void*)f_2097},
{"f_2435:setup_2dapi_2escm",(void*)f_2435},
{"f_2438:setup_2dapi_2escm",(void*)f_2438},
{"f_3110:setup_2dapi_2escm",(void*)f_3110},
{"f_1932:setup_2dapi_2escm",(void*)f_1932},
{"f_1937:setup_2dapi_2escm",(void*)f_1937},
{"f_3126:setup_2dapi_2escm",(void*)f_3126},
{"f_2253:setup_2dapi_2escm",(void*)f_2253},
{"f_2251:setup_2dapi_2escm",(void*)f_2251},
{"f_2257:setup_2dapi_2escm",(void*)f_2257},
{"f_1963:setup_2dapi_2escm",(void*)f_1963},
{"f_1967:setup_2dapi_2escm",(void*)f_1967},
{"f_3119:setup_2dapi_2escm",(void*)f_3119},
{"f_2228:setup_2dapi_2escm",(void*)f_2228},
{"f_3106:setup_2dapi_2escm",(void*)f_3106},
{"f_4321:setup_2dapi_2escm",(void*)f_4321},
{"f_4327:setup_2dapi_2escm",(void*)f_4327},
{"f_5131:setup_2dapi_2escm",(void*)f_5131},
{"f_5139:setup_2dapi_2escm",(void*)f_5139},
{"f_4780:setup_2dapi_2escm",(void*)f_4780},
{"f_4313:setup_2dapi_2escm",(void*)f_4313},
{"f_2202:setup_2dapi_2escm",(void*)f_2202},
{"f_2587:setup_2dapi_2escm",(void*)f_2587},
{"f_5120:setup_2dapi_2escm",(void*)f_5120},
{"f_5127:setup_2dapi_2escm",(void*)f_5127},
{"f_4798:setup_2dapi_2escm",(void*)f_4798},
{"f_4128:setup_2dapi_2escm",(void*)f_4128},
{"f_4307:setup_2dapi_2escm",(void*)f_4307},
{"f_4304:setup_2dapi_2escm",(void*)f_4304},
{"f_5111:setup_2dapi_2escm",(void*)f_5111},
{"f_5062:setup_2dapi_2escm",(void*)f_5062},
{"f_4121:setup_2dapi_2escm",(void*)f_4121},
{"f_5117:setup_2dapi_2escm",(void*)f_5117},
{"f_5114:setup_2dapi_2escm",(void*)f_5114},
{"f_4159:setup_2dapi_2escm",(void*)f_4159},
{"f_4153:setup_2dapi_2escm",(void*)f_4153},
{"f_5093:setup_2dapi_2escm",(void*)f_5093},
{"f_5099:setup_2dapi_2escm",(void*)f_5099},
{"f_4103:setup_2dapi_2escm",(void*)f_4103},
{"f_5047:setup_2dapi_2escm",(void*)f_5047},
{"f_4765:setup_2dapi_2escm",(void*)f_4765},
{"f_4767:setup_2dapi_2escm",(void*)f_4767},
{"f_4137:setup_2dapi_2escm",(void*)f_4137},
{"f_2542:setup_2dapi_2escm",(void*)f_2542},
{"f_2545:setup_2dapi_2escm",(void*)f_2545},
{"f_2485:setup_2dapi_2escm",(void*)f_2485},
{"f_2481:setup_2dapi_2escm",(void*)f_2481},
{"f_5073:setup_2dapi_2escm",(void*)f_5073},
{"f_4131:setup_2dapi_2escm",(void*)f_4131},
{"f_2489:setup_2dapi_2escm",(void*)f_2489},
{"f_5077:setup_2dapi_2escm",(void*)f_5077},
{"f_2551:setup_2dapi_2escm",(void*)f_2551},
{"f_2553:setup_2dapi_2escm",(void*)f_2553},
{"f_2522:setup_2dapi_2escm",(void*)f_2522},
{"f_2528:setup_2dapi_2escm",(void*)f_2528},
{"f_4962:setup_2dapi_2escm",(void*)f_4962},
{"f_4790:setup_2dapi_2escm",(void*)f_4790},
{"f_5080:setup_2dapi_2escm",(void*)f_5080},
{"f_4995:setup_2dapi_2escm",(void*)f_4995},
{"f_4999:setup_2dapi_2escm",(void*)f_4999},
{"f_4392:setup_2dapi_2escm",(void*)f_4392},
{"f_4395:setup_2dapi_2escm",(void*)f_4395},
{"f_2505:setup_2dapi_2escm",(void*)f_2505},
{"f_4383:setup_2dapi_2escm",(void*)f_4383},
{"f_2519:setup_2dapi_2escm",(void*)f_2519},
{"f_4398:setup_2dapi_2escm",(void*)f_4398},
{"f_4972:setup_2dapi_2escm",(void*)f_4972},
{"f_4375:setup_2dapi_2escm",(void*)f_4375},
{"f_3091:setup_2dapi_2escm",(void*)f_3091},
{"f_4389:setup_2dapi_2escm",(void*)f_4389},
{"f_5012:setup_2dapi_2escm",(void*)f_5012},
{"f_5017:setup_2dapi_2escm",(void*)f_5017},
{"f_5013:setup_2dapi_2escm",(void*)f_5013},
{"f_4360:setup_2dapi_2escm",(void*)f_4360},
{"f_2578:setup_2dapi_2escm",(void*)f_2578},
{"f_2959:setup_2dapi_2escm",(void*)f_2959},
{"f_4354:setup_2dapi_2escm",(void*)f_4354},
{"f_3077:setup_2dapi_2escm",(void*)f_3077},
{"f_4369:setup_2dapi_2escm",(void*)f_4369},
{"f_4366:setup_2dapi_2escm",(void*)f_4366},
{"f_2409:setup_2dapi_2escm",(void*)f_2409},
{"f_2405:setup_2dapi_2escm",(void*)f_2405},
{"f_2400:setup_2dapi_2escm",(void*)f_2400},
{"f_4342:setup_2dapi_2escm",(void*)f_4342},
{"f_4340:setup_2dapi_2escm",(void*)f_4340},
{"f_3067:setup_2dapi_2escm",(void*)f_3067},
{"f_3062:setup_2dapi_2escm",(void*)f_3062},
{"f_2775:setup_2dapi_2escm",(void*)f_2775},
{"f_5023:setup_2dapi_2escm",(void*)f_5023},
{"f_4333:setup_2dapi_2escm",(void*)f_4333},
{"f_4330:setup_2dapi_2escm",(void*)f_4330},
{"f_3055:setup_2dapi_2escm",(void*)f_3055},
{"f_3059:setup_2dapi_2escm",(void*)f_3059},
{"f_4348:setup_2dapi_2escm",(void*)f_4348},
{"f_4802:setup_2dapi_2escm",(void*)f_4802},
{"f_4809:setup_2dapi_2escm",(void*)f_4809},
{"f_4336:setup_2dapi_2escm",(void*)f_4336},
{"f_5005:setup_2dapi_2escm",(void*)f_5005},
{"f_3039:setup_2dapi_2escm",(void*)f_3039},
{"f_3037:setup_2dapi_2escm",(void*)f_3037},
{"f_3034:setup_2dapi_2escm",(void*)f_3034},
{"f_3031:setup_2dapi_2escm",(void*)f_3031},
{"f_5037:setup_2dapi_2escm",(void*)f_5037},
{"f_3028:setup_2dapi_2escm",(void*)f_3028},
{"f_3022:setup_2dapi_2escm",(void*)f_3022},
{"toplevel:setup_2dapi_2escm",(void*)C_toplevel},
{"f_3012:setup_2dapi_2escm",(void*)f_3012},
{"f_4842:setup_2dapi_2escm",(void*)f_4842},
{"f_4847:setup_2dapi_2escm",(void*)f_4847},
{"f_2798:setup_2dapi_2escm",(void*)f_2798},
{"f_3989:setup_2dapi_2escm",(void*)f_3989},
{"f_4651:setup_2dapi_2escm",(void*)f_4651},
{"f_4820:setup_2dapi_2escm",(void*)f_4820},
{"f_3979:setup_2dapi_2escm",(void*)f_3979},
{"f_2785:setup_2dapi_2escm",(void*)f_2785},
{"f_4894:setup_2dapi_2escm",(void*)f_4894},
{"f_4645:setup_2dapi_2escm",(void*)f_4645},
{"f_4897:setup_2dapi_2escm",(void*)f_4897},
{"f_4891:setup_2dapi_2escm",(void*)f_4891},
{"f_4649:setup_2dapi_2escm",(void*)f_4649},
{"f_3367:setup_2dapi_2escm",(void*)f_3367},
{"f_4205:setup_2dapi_2escm",(void*)f_4205},
{"f_2767:setup_2dapi_2escm",(void*)f_2767},
{"f_4638:setup_2dapi_2escm",(void*)f_4638},
{"f_2363:setup_2dapi_2escm",(void*)f_2363},
{"f_2366:setup_2dapi_2escm",(void*)f_2366},
{"f_2369:setup_2dapi_2escm",(void*)f_2369},
{"f_3047:setup_2dapi_2escm",(void*)f_3047},
{"f_3046:setup_2dapi_2escm",(void*)f_3046},
{"f_2755:setup_2dapi_2escm",(void*)f_2755},
{"f_2752:setup_2dapi_2escm",(void*)f_2752},
{"f_3347:setup_2dapi_2escm",(void*)f_3347},
{"f_2376:setup_2dapi_2escm",(void*)f_2376},
{"f_2378:setup_2dapi_2escm",(void*)f_2378},
{"f_4229:setup_2dapi_2escm",(void*)f_4229},
{"f_2749:setup_2dapi_2escm",(void*)f_2749},
{"f_2743:setup_2dapi_2escm",(void*)f_2743},
{"f_2342:setup_2dapi_2escm",(void*)f_2342},
{"f_2346:setup_2dapi_2escm",(void*)f_2346},
{"f_4211:setup_2dapi_2escm",(void*)f_4211},
{"f_4602:setup_2dapi_2escm",(void*)f_4602},
{"f_3995:setup_2dapi_2escm",(void*)f_3995},
{"f_3992:setup_2dapi_2escm",(void*)f_3992},
{"f_4853:setup_2dapi_2escm",(void*)f_4853},
{"f_2350:setup_2dapi_2escm",(void*)f_2350},
{"f_2357:setup_2dapi_2escm",(void*)f_2357},
{"f_4859:setup_2dapi_2escm",(void*)f_4859},
{"f_3322:setup_2dapi_2escm",(void*)f_3322},
{"f_2725:setup_2dapi_2escm",(void*)f_2725},
{"f_3998:setup_2dapi_2escm",(void*)f_3998},
{"f_2321:setup_2dapi_2escm",(void*)f_2321},
{"f_2327:setup_2dapi_2escm",(void*)f_2327},
{"f_3003:setup_2dapi_2escm",(void*)f_3003},
{"f_3000:setup_2dapi_2escm",(void*)f_3000},
{"f_2330:setup_2dapi_2escm",(void*)f_2330},
{"f_2333:setup_2dapi_2escm",(void*)f_2333},
{"f_2336:setup_2dapi_2escm",(void*)f_2336},
{"f_4262:setup_2dapi_2escm",(void*)f_4262},
{"f_2339:setup_2dapi_2escm",(void*)f_2339},
{"f_4265:setup_2dapi_2escm",(void*)f_4265},
{"f_4268:setup_2dapi_2escm",(void*)f_4268},
{"f_2700:setup_2dapi_2escm",(void*)f_2700},
{"f_4757:setup_2dapi_2escm",(void*)f_4757},
{"f_4253:setup_2dapi_2escm",(void*)f_4253},
{"f_4250:setup_2dapi_2escm",(void*)f_4250},
{"f_4259:setup_2dapi_2escm",(void*)f_4259},
{"f_4256:setup_2dapi_2escm",(void*)f_4256},
{"f_4280:setup_2dapi_2escm",(void*)f_4280},
{"f_4283:setup_2dapi_2escm",(void*)f_4283},
{"f_1953:setup_2dapi_2escm",(void*)f_1953},
{"f_4286:setup_2dapi_2escm",(void*)f_4286},
{"f_4271:setup_2dapi_2escm",(void*)f_4271},
{"f_4274:setup_2dapi_2escm",(void*)f_4274},
{"f_1905:setup_2dapi_2escm",(void*)f_1905},
{"f_3833:setup_2dapi_2escm",(void*)f_3833},
{"f_1908:setup_2dapi_2escm",(void*)f_1908},
{"f_4277:setup_2dapi_2escm",(void*)f_4277},
{"f_1902:setup_2dapi_2escm",(void*)f_1902},
{"f_1920:setup_2dapi_2escm",(void*)f_1920},
{"f_4913:setup_2dapi_2escm",(void*)f_4913},
{"f_3843:setup_2dapi_2escm",(void*)f_3843},
{"f_2171:setup_2dapi_2escm",(void*)f_2171},
{"f_2174:setup_2dapi_2escm",(void*)f_2174},
{"f_2177:setup_2dapi_2escm",(void*)f_2177},
{"f_4719:setup_2dapi_2escm",(void*)f_4719},
{"f_4292:setup_2dapi_2escm",(void*)f_4292},
{"f_1929:setup_2dapi_2escm",(void*)f_1929},
{"f_4298:setup_2dapi_2escm",(void*)f_4298},
{"f_3852:setup_2dapi_2escm",(void*)f_3852},
{"f_1926:setup_2dapi_2escm",(void*)f_1926},
{"f_1923:setup_2dapi_2escm",(void*)f_1923},
{"f_3850:setup_2dapi_2escm",(void*)f_3850},
{"f_2181:setup_2dapi_2escm",(void*)f_2181},
{"f_2187:setup_2dapi_2escm",(void*)f_2187},
{"f_1917:setup_2dapi_2escm",(void*)f_1917},
{"f_1914:setup_2dapi_2escm",(void*)f_1914},
{"f_4927:setup_2dapi_2escm",(void*)f_4927},
{"f_1911:setup_2dapi_2escm",(void*)f_1911},
{"f_2155:setup_2dapi_2escm",(void*)f_2155},
{"f_2158:setup_2dapi_2escm",(void*)f_2158},
{"f_4926:setup_2dapi_2escm",(void*)f_4926},
{"f_4922:setup_2dapi_2escm",(void*)f_4922},
{"f_4957:setup_2dapi_2escm",(void*)f_4957},
{"f_4755:setup_2dapi_2escm",(void*)f_4755},
{"f_2161:setup_2dapi_2escm",(void*)f_2161},
{"f_2165:setup_2dapi_2escm",(void*)f_2165},
{"f_2133:setup_2dapi_2escm",(void*)f_2133},
{"f_2382:setup_2dapi_2escm",(void*)f_2382},
{"f_2139:setup_2dapi_2escm",(void*)f_2139},
{"f_4901:setup_2dapi_2escm",(void*)f_4901},
{"f_4907:setup_2dapi_2escm",(void*)f_4907},
{"f_3271:setup_2dapi_2escm",(void*)f_3271},
{"f_4905:setup_2dapi_2escm",(void*)f_4905},
{"f_4937:setup_2dapi_2escm",(void*)f_4937},
{"f_1899:setup_2dapi_2escm",(void*)f_1899},
{"f_2145:setup_2dapi_2escm",(void*)f_2145},
{"f_2142:setup_2dapi_2escm",(void*)f_2142},
{"f_2390:setup_2dapi_2escm",(void*)f_2390},
{"f_2149:setup_2dapi_2escm",(void*)f_2149},
{"f_2113:setup_2dapi_2escm",(void*)f_2113},
{"f_2110:setup_2dapi_2escm",(void*)f_2110},
{"f_2117:setup_2dapi_2escm",(void*)f_2117},
{"f_2991:setup_2dapi_2escm",(void*)f_2991},
{"f_2997:setup_2dapi_2escm",(void*)f_2997},
{"f_2994:setup_2dapi_2escm",(void*)f_2994},
{"f_2126:setup_2dapi_2escm",(void*)f_2126},
{"f_2123:setup_2dapi_2escm",(void*)f_2123},
{"f_3289:setup_2dapi_2escm",(void*)f_3289},
{"f_2129:setup_2dapi_2escm",(void*)f_2129},
{"f_2054:setup_2dapi_2escm",(void*)f_2054},
{"f_4946:setup_2dapi_2escm",(void*)f_4946},
{"f_4940:setup_2dapi_2escm",(void*)f_4940},
{"f_2974:setup_2dapi_2escm",(void*)f_2974},
{"f_2107:setup_2dapi_2escm",(void*)f_2107},
{"f_3266:setup_2dapi_2escm",(void*)f_3266},
{"f_2101:setup_2dapi_2escm",(void*)f_2101},
{"f_4240:setup_2dapi_2escm",(void*)f_4240},
{"f_4247:setup_2dapi_2escm",(void*)f_4247},
{"f_2044:setup_2dapi_2escm",(void*)f_2044},
{"f_3212:setup_2dapi_2escm",(void*)f_3212},
{"f_2015:setup_2dapi_2escm",(void*)f_2015},
{"f_3244:setup_2dapi_2escm",(void*)f_3244},
{"f_3246:setup_2dapi_2escm",(void*)f_3246},
{"f_2011:setup_2dapi_2escm",(void*)f_2011},
{"f_2019:setup_2dapi_2escm",(void*)f_2019},
{"f_2982:setup_2dapi_2escm",(void*)f_2982},
{"f_3775:setup_2dapi_2escm",(void*)f_3775},
{"f_2985:setup_2dapi_2escm",(void*)f_2985},
{"f_2023:setup_2dapi_2escm",(void*)f_2023},
{"f_4429:setup_2dapi_2escm",(void*)f_4429},
{"f_2025:setup_2dapi_2escm",(void*)f_2025},
{"f_2308:setup_2dapi_2escm",(void*)f_2308},
{"f_2938:setup_2dapi_2escm",(void*)f_2938},
{"f_2301:setup_2dapi_2escm",(void*)f_2301},
{"f_4410:setup_2dapi_2escm",(void*)f_4410},
{"f_3228:setup_2dapi_2escm",(void*)f_3228},
{"f_2314:setup_2dapi_2escm",(void*)f_2314},
{"f_2311:setup_2dapi_2escm",(void*)f_2311},
{"f_2963:setup_2dapi_2escm",(void*)f_2963},
{"f_2965:setup_2dapi_2escm",(void*)f_2965},
{"f_3789:setup_2dapi_2escm",(void*)f_3789},
{"f_4882:setup_2dapi_2escm",(void*)f_4882},
{"f_4888:setup_2dapi_2escm",(void*)f_4888},
{"f_2007:setup_2dapi_2escm",(void*)f_2007},
{"f_2917:setup_2dapi_2escm",(void*)f_2917},
{"f_2003:setup_2dapi_2escm",(void*)f_2003},
{"f_2911:setup_2dapi_2escm",(void*)f_2911},
{"f_2914:setup_2dapi_2escm",(void*)f_2914},
{"f_4872:setup_2dapi_2escm",(void*)f_4872},
{"f_3208:setup_2dapi_2escm",(void*)f_3208},
{"f_2941:setup_2dapi_2escm",(void*)f_2941},
{"f_2944:setup_2dapi_2escm",(void*)f_2944},
{"f_4862:setup_2dapi_2escm",(void*)f_4862},
{"f_4868:setup_2dapi_2escm",(void*)f_4868},
{"f_3798:setup_2dapi_2escm",(void*)f_3798},
{"f_2035:setup_2dapi_2escm",(void*)f_2035},
{"f_2920:setup_2dapi_2escm",(void*)f_2920},
{"f_3795:setup_2dapi_2escm",(void*)f_3795},
{"f_3792:setup_2dapi_2escm",(void*)f_3792},
{"f_4402:setup_2dapi_2escm",(void*)f_4402},
{"f_4404:setup_2dapi_2escm",(void*)f_4404},
{"f_3906:setup_2dapi_2escm",(void*)f_3906},
{"f_3902:setup_2dapi_2escm",(void*)f_3902},
{"f_5315:setup_2dapi_2escm",(void*)f_5315},
{"f_2908:setup_2dapi_2escm",(void*)f_2908},
{"f_2901:setup_2dapi_2escm",(void*)f_2901},
{"f_3520:setup_2dapi_2escm",(void*)f_3520},
{"f_3535:setup_2dapi_2escm",(void*)f_3535},
{"f_3590:setup_2dapi_2escm",(void*)f_3590},
{"f_4492:setup_2dapi_2escm",(void*)f_4492},
{"f_3925:setup_2dapi_2escm",(void*)f_3925},
{"f_3524:setup_2dapi_2escm",(void*)f_3524},
{"f_3528:setup_2dapi_2escm",(void*)f_3528},
{"f_3581:setup_2dapi_2escm",(void*)f_3581},
{"f_4443:setup_2dapi_2escm",(void*)f_4443},
{"f_3598:setup_2dapi_2escm",(void*)f_3598},
{"f_3594:setup_2dapi_2escm",(void*)f_3594},
{"f_4447:setup_2dapi_2escm",(void*)f_4447},
{"f_3571:setup_2dapi_2escm",(void*)f_3571},
{"f_4432:setup_2dapi_2escm",(void*)f_4432},
{"f_3587:setup_2dapi_2escm",(void*)f_3587},
{"f_3584:setup_2dapi_2escm",(void*)f_3584},
{"f_2292:setup_2dapi_2escm",(void*)f_2292},
{"f_4482:setup_2dapi_2escm",(void*)f_4482},
{"f_4485:setup_2dapi_2escm",(void*)f_4485},
{"f_3556:setup_2dapi_2escm",(void*)f_3556},
{"f_4470:setup_2dapi_2escm",(void*)f_4470},
{"f_4473:setup_2dapi_2escm",(void*)f_4473},
{"f_4479:setup_2dapi_2escm",(void*)f_4479},
{"f_3474:setup_2dapi_2escm",(void*)f_3474},
{"f_3472:setup_2dapi_2escm",(void*)f_3472},
{"f_5215:setup_2dapi_2escm",(void*)f_5215},
{"f_5219:setup_2dapi_2escm",(void*)f_5219},
{"f_3457:setup_2dapi_2escm",(void*)f_3457},
{"f_2622:setup_2dapi_2escm",(void*)f_2622},
{"f_2625:setup_2dapi_2escm",(void*)f_2625},
{"f_2628:setup_2dapi_2escm",(void*)f_2628},
{"f_4521:setup_2dapi_2escm",(void*)f_4521},
{"f_4527:setup_2dapi_2escm",(void*)f_4527},
{"f_4524:setup_2dapi_2escm",(void*)f_4524},
{"f_4518:setup_2dapi_2escm",(void*)f_4518},
{"f_3451:setup_2dapi_2escm",(void*)f_3451},
{"f_3516:setup_2dapi_2escm",(void*)f_3516},
{"f_2631:setup_2dapi_2escm",(void*)f_2631},
{"f_2634:setup_2dapi_2escm",(void*)f_2634},
{"f_4512:setup_2dapi_2escm",(void*)f_4512},
{"f_4515:setup_2dapi_2escm",(void*)f_4515},
{"f_4509:setup_2dapi_2escm",(void*)f_4509},
{"f_3505:setup_2dapi_2escm",(void*)f_3505},
{"f_3502:setup_2dapi_2escm",(void*)f_3502},
{"f_3439:setup_2dapi_2escm",(void*)f_3439},
{"f_2681:setup_2dapi_2escm",(void*)f_2681},
{"f_4464:setup_2dapi_2escm",(void*)f_4464},
{"f_4500:setup_2dapi_2escm",(void*)f_4500},
{"f_4506:setup_2dapi_2escm",(void*)f_4506},
{"f_3431:setup_2dapi_2escm",(void*)f_3431},
{"f_3950:setup_2dapi_2escm",(void*)f_3950},
{"f_2692:setup_2dapi_2escm",(void*)f_2692},
{"f_4451:setup_2dapi_2escm",(void*)f_4451},
{"f_3961:setup_2dapi_2escm",(void*)f_3961},
{"f_4545:setup_2dapi_2escm",(void*)f_4545},
{"f_4548:setup_2dapi_2escm",(void*)f_4548},
{"f_3805:setup_2dapi_2escm",(void*)f_3805},
{"f_3801:setup_2dapi_2escm",(void*)f_3801},
{"f_2640:setup_2dapi_2escm",(void*)f_2640},
{"f_4542:setup_2dapi_2escm",(void*)f_4542},
{"f_4539:setup_2dapi_2escm",(void*)f_4539},
{"f_4536:setup_2dapi_2escm",(void*)f_4536},
{"f_3809:setup_2dapi_2escm",(void*)f_3809},
{"f_3818:setup_2dapi_2escm",(void*)f_3818},
{"f_3815:setup_2dapi_2escm",(void*)f_3815},
{"f_3812:setup_2dapi_2escm",(void*)f_3812},
{"f_5292:setup_2dapi_2escm",(void*)f_5292},
{"f_4533:setup_2dapi_2escm",(void*)f_4533},
{"f_4530:setup_2dapi_2escm",(void*)f_4530},
{"f_5290:setup_2dapi_2escm",(void*)f_5290},
{"f_5282:setup_2dapi_2escm",(void*)f_5282},
{"f_5286:setup_2dapi_2escm",(void*)f_5286},
{"f_4597:setup_2dapi_2escm",(void*)f_4597},
{"f_5274:setup_2dapi_2escm",(void*)f_5274},
{"f_5278:setup_2dapi_2escm",(void*)f_5278},
{"f_5270:setup_2dapi_2escm",(void*)f_5270},
{"f_5266:setup_2dapi_2escm",(void*)f_5266},
{"f_5262:setup_2dapi_2escm",(void*)f_5262},
{"f_4582:setup_2dapi_2escm",(void*)f_4582},
{"f_4577:setup_2dapi_2escm",(void*)f_4577},
{"f_4579:setup_2dapi_2escm",(void*)f_4579},
{"f_2612:setup_2dapi_2escm",(void*)f_2612},
{"f_4571:setup_2dapi_2escm",(void*)f_4571},
{"f_4574:setup_2dapi_2escm",(void*)f_4574},
{"f_5247:setup_2dapi_2escm",(void*)f_5247},
{"f_2666:setup_2dapi_2escm",(void*)f_2666},
{"f_3499:setup_2dapi_2escm",(void*)f_3499},
{"f_3496:setup_2dapi_2escm",(void*)f_3496},
{"f_5243:setup_2dapi_2escm",(void*)f_5243},
{"f_2660:setup_2dapi_2escm",(void*)f_2660},
{"f_3493:setup_2dapi_2escm",(void*)f_3493},
{"f_2668:setup_2dapi_2escm",(void*)f_2668},
{"f_3490:setup_2dapi_2escm",(void*)f_3490},
{"f_3487:setup_2dapi_2escm",(void*)f_3487},
{"f_5235:setup_2dapi_2escm",(void*)f_5235},
{"f_2671:setup_2dapi_2escm",(void*)f_2671},
{"f_3700:setup_2dapi_2escm",(void*)f_3700},
{"f_5239:setup_2dapi_2escm",(void*)f_5239},
{"f_4065:setup_2dapi_2escm",(void*)f_4065},
{"f_2881:setup_2dapi_2escm",(void*)f_2881},
{"f_4067:setup_2dapi_2escm",(void*)f_4067},
{"f_2887:setup_2dapi_2escm",(void*)f_2887},
{"f_1984:setup_2dapi_2escm",(void*)f_1984},
{"f_1986:setup_2dapi_2escm",(void*)f_1986},
{"f_1981:setup_2dapi_2escm",(void*)f_1981},
{"f_4050:setup_2dapi_2escm",(void*)f_4050},
{"f_1974:setup_2dapi_2escm",(void*)f_1974},
{"f_1971:setup_2dapi_2escm",(void*)f_1971},
{"f_1977:setup_2dapi_2escm",(void*)f_1977},
{"f_3719:setup_2dapi_2escm",(void*)f_3719},
{"f_3717:setup_2dapi_2escm",(void*)f_3717},
{"f_3710:setup_2dapi_2escm",(void*)f_3710},
{"f_2890:setup_2dapi_2escm",(void*)f_2890},
{"f_2893:setup_2dapi_2escm",(void*)f_2893},
{"f_1994:setup_2dapi_2escm",(void*)f_1994},
{"f_1999:setup_2dapi_2escm",(void*)f_1999},
{"f_4568:setup_2dapi_2escm",(void*)f_4568},
{"f_4092:setup_2dapi_2escm",(void*)f_4092},
{"f_4562:setup_2dapi_2escm",(void*)f_4562},
{"f_2874:setup_2dapi_2escm",(void*)f_2874},
{"f_4554:setup_2dapi_2escm",(void*)f_4554},
{"f_4552:setup_2dapi_2escm",(void*)f_4552},
{"f_3403:setup_2dapi_2escm",(void*)f_3403},
{"f_3877:setup_2dapi_2escm",(void*)f_3877},
{"f_4987:setup_2dapi_2escm",(void*)f_4987},
{"f_3636:setup_2dapi_2escm",(void*)f_3636},
{"f_2856:setup_2dapi_2escm",(void*)f_2856},
{"f_2852:setup_2dapi_2escm",(void*)f_2852},
{"f_3888:setup_2dapi_2escm",(void*)f_3888},
{"f_2836:setup_2dapi_2escm",(void*)f_2836},
{"f_4006:setup_2dapi_2escm",(void*)f_4006},
{"f_4002:setup_2dapi_2escm",(void*)f_4002},
{"f_4009:setup_2dapi_2escm",(void*)f_4009},
{"f_3685:setup_2dapi_2escm",(void*)f_3685},
{"f_2860:setup_2dapi_2escm",(void*)f_2860},
{"f_2861:setup_2dapi_2escm",(void*)f_2861},
{"f_2865:setup_2dapi_2escm",(void*)f_2865},
{"f_5185:setup_2dapi_2escm",(void*)f_5185},
{"f_4015:setup_2dapi_2escm",(void*)f_4015},
{"f_4012:setup_2dapi_2escm",(void*)f_4012},
{"f_4040:setup_2dapi_2escm",(void*)f_4040},
{"f_4043:setup_2dapi_2escm",(void*)f_4043},
{"f_3646:setup_2dapi_2escm",(void*)f_3646},
{"f_2823:setup_2dapi_2escm",(void*)f_2823},
{"f_3193:setup_2dapi_2escm",(void*)f_3193},
{"f_3190:setup_2dapi_2escm",(void*)f_3190},
{"f_3640:setup_2dapi_2escm",(void*)f_3640},
{"f_5169:setup_2dapi_2escm",(void*)f_5169},
{"f_4030:setup_2dapi_2escm",(void*)f_4030},
{"f_5167:setup_2dapi_2escm",(void*)f_5167},
{"f_5160:setup_2dapi_2escm",(void*)f_5160},
{"f_3181:setup_2dapi_2escm",(void*)f_3181},
{"f_3183:setup_2dapi_2escm",(void*)f_3183},
{"f_4165:setup_2dapi_2escm",(void*)f_4165},
{"f_4162:setup_2dapi_2escm",(void*)f_4162},
{"f_5152:setup_2dapi_2escm",(void*)f_5152},
{"f_5154:setup_2dapi_2escm",(void*)f_5154},
{"f_5156:setup_2dapi_2escm",(void*)f_5156},
{"f_4199:setup_2dapi_2escm",(void*)f_4199},
{"f_2190:setup_2dapi_2escm",(void*)f_2190},
{"f_4193:setup_2dapi_2escm",(void*)f_4193},
{"f_4190:setup_2dapi_2escm",(void*)f_4190},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding nonexported module bindings: setup-api#constant26 
o|hiding nonexported module bindings: setup-api#*cc* 
o|hiding nonexported module bindings: setup-api#*cxx* 
o|hiding nonexported module bindings: setup-api#*target-cflags* 
o|hiding nonexported module bindings: setup-api#*target-libs* 
o|hiding nonexported module bindings: setup-api#*target-lib-home* 
o|hiding nonexported module bindings: setup-api#*sudo* 
o|hiding nonexported module bindings: setup-api#*windows-shell* 
o|hiding nonexported module bindings: setup-api#*registered-programs* 
o|hiding nonexported module bindings: setup-api#*windows* 
o|hiding nonexported module bindings: setup-api#*chicken-bin-path* 
o|hiding nonexported module bindings: setup-api#*csc-options* 
o|hiding nonexported module bindings: setup-api#*base-directory* 
o|hiding nonexported module bindings: setup-api#*copy-command* 
o|hiding nonexported module bindings: setup-api#*remove-command* 
o|hiding nonexported module bindings: setup-api#*move-command* 
o|hiding nonexported module bindings: setup-api#*chmod-command* 
o|hiding nonexported module bindings: setup-api#*ranlib-command* 
o|hiding nonexported module bindings: setup-api#*mkdir-command* 
o|hiding nonexported module bindings: setup-api#windows-user-install-setup 
o|hiding nonexported module bindings: setup-api#unix-user-install-setup 
o|hiding nonexported module bindings: setup-api#windows-sudo-install-setup 
o|hiding nonexported module bindings: setup-api#unix-sudo-install-setup 
o|hiding nonexported module bindings: setup-api#user-install-setup 
o|hiding nonexported module bindings: setup-api#sudo-install-setup 
o|hiding nonexported module bindings: setup-api#ignore-errors 
o|hiding nonexported module bindings: setup-api#target-prefix 
o|hiding nonexported module bindings: setup-api#fixpath 
o|hiding nonexported module bindings: setup-api#make-setup-info-pathname 
o|hiding nonexported module bindings: setup-api#write-info 
o|hiding nonexported module bindings: setup-api#path-prefix? 
o|hiding nonexported module bindings: setup-api#make-dest-pathname 
o|hiding nonexported module bindings: setup-api#check-filelist 
o|hiding nonexported module bindings: setup-api#translate-extension 
o|hiding nonexported module bindings: setup-api#what-version 
o|hiding nonexported module bindings: setup-api#supply-version 
o|hiding nonexported module bindings: setup-api#repo-path 
o|hiding nonexported module bindings: setup-api#ensure-directory 
o|hiding nonexported module bindings: setup-api#$system 
S|applied compiler syntax:
S|  for-each		4
S|  map		10
S|  printf		4
S|  sprintf		14
o|eliminated procedure checks: 138 
o|specializations:
o|  1 (current-exception-handler procedure)
o|  1 (current-error-port)
o|  1 (string=? string string)
o|  1 (= fixnum fixnum)
o|  1 (length list)
o|  3 (zero? fixnum)
o|  3 (##sys#check-list (or pair list) *)
o|  14 (car pair)
o|  6 (cdr pair)
o|  2 (string-append string string)
o|  18 (##sys#check-output-port * * *)
(o e)|safe calls: 450 
o|safe globals: (setup-api#constant26) 
o|Removed `not' forms: 4 
o|inlining procedure: k2030 
o|inlining procedure: k2030 
o|inlining procedure: k2049 
o|inlining procedure: k2049 
o|inlining procedure: k2205 
o|contracted procedure: "(setup-api.scm:169) setup-api#windows-user-install-setup" 
o|inlining procedure: k2205 
o|contracted procedure: "(setup-api.scm:170) setup-api#unix-user-install-setup" 
o|inlining procedure: k2230 
o|propagated global variable: r22315322 setup-api#*sudo* 
o|inlining procedure: k2230 
o|contracted procedure: "(setup-api.scm:180) setup-api#sudo-install-setup" 
o|inlining procedure: k2218 
o|contracted procedure: "(setup-api.scm:175) setup-api#windows-sudo-install-setup" 
o|inlining procedure: k2218 
o|contracted procedure: "(setup-api.scm:176) setup-api#unix-sudo-install-setup" 
o|substituted constant variable: a2103 
o|substituted constant variable: a2104 
o|substituted constant variable: a2119 
o|substituted constant variable: a2120 
o|substituted constant variable: a2135 
o|substituted constant variable: a2136 
o|substituted constant variable: a2151 
o|substituted constant variable: a2152 
o|substituted constant variable: a2167 
o|substituted constant variable: a2168 
o|substituted constant variable: a2183 
o|substituted constant variable: a2184 
o|inlining procedure: k2198 
o|inlining procedure: k2198 
o|inlining procedure: k2258 
o|inlining procedure: k2293 
o|inlining procedure: k2293 
o|inlining procedure: k2258 
o|substituted constant variable: a2323 
o|substituted constant variable: a2324 
o|propagated global variable: out258262 ##sys#standard-output 
o|substituted constant variable: a2359 
o|substituted constant variable: a2360 
o|propagated global variable: out258262 ##sys#standard-output 
o|inlining procedure: k2413 
o|inlining procedure: k2413 
o|contracted procedure: "(setup-api.scm:266) setup-api#fixpath" 
o|inlining procedure: k2469 
o|substituted constant variable: setup-api#*csc-options* 
o|inlining procedure: k2555 
o|contracted procedure: "(setup-api.scm:254) g372381" 
o|substituted constant variable: a2538 
o|inlining procedure: k2555 
o|inlining procedure: k2589 
o|contracted procedure: "(setup-api.scm:251) g345354" 
o|substituted constant variable: a2515 
o|inlining procedure: k2589 
o|inlining procedure: k2632 
o|inlining procedure: k2632 
o|inlining procedure: k2469 
o|inlining procedure: k2702 
o|inlining procedure: k2702 
o|inlining procedure: k2777 
o|contracted procedure: "(setup-api.scm:263) g397433" 
o|propagated global variable: out436440 ##sys#standard-output 
o|substituted constant variable: a2745 
o|substituted constant variable: a2746 
o|inlining procedure: k2735 
o|propagated global variable: out436440 ##sys#standard-output 
o|inlining procedure: k2735 
o|inlining procedure: k2777 
o|inlining procedure: k2800 
o|inlining procedure: k2800 
o|inlining procedure: k2866 
o|inlining procedure: k2866 
o|propagated global variable: out579583 ##sys#standard-output 
o|substituted constant variable: a2883 
o|substituted constant variable: a2884 
o|inlining procedure: k2876 
o|propagated global variable: out579583 ##sys#standard-output 
o|inlining procedure: k2876 
o|inlining procedure: k2921 
o|inlining procedure: k2921 
o|propagated global variable: g627628 pp 
o|propagated global variable: g639640 pp 
o|consed rest parameter at call site: "(setup-api.scm:318) setup-api#ensure-directory" 2 
o|contracted procedure: "(setup-api.scm:317) setup-api#make-setup-info-pathname" 
o|consed rest parameter at call site: "(setup-api.scm:317) setup-api#repo-path" 1 
o|propagated global variable: out607611 ##sys#standard-output 
o|substituted constant variable: a2987 
o|substituted constant variable: a2988 
o|propagated global variable: out607611 ##sys#standard-output 
o|inlining procedure: k3041 
o|inlining procedure: k3069 
o|inlining procedure: k3069 
o|inlining procedure: k3041 
o|consed rest parameter at call site: "(setup-api.scm:342) setup-api#ensure-directory" 2 
o|contracted procedure: k3111 
o|inlining procedure: k3114 
o|inlining procedure: k3114 
o|contracted procedure: "(setup-api.scm:330) setup-api#path-prefix?" 
o|consed rest parameter at call site: "(setup-api.scm:356) setup-api#ensure-directory" 2 
o|inlining procedure: k3248 
o|inlining procedure: k3248 
o|inlining procedure: k3324 
o|contracted procedure: "(setup-api.scm:369) g742751" 
o|inlining procedure: k3278 
o|inlining procedure: k3278 
o|inlining procedure: k3293 
o|inlining procedure: k3293 
o|inlining procedure: k3324 
o|removed unused formal parameters: (a807) 
o|inlining procedure: k3436 
o|removed unused parameter to known procedure: a807 "(setup-api.scm:392) g805806" 
o|inlining procedure: k3436 
o|contracted procedure: "(setup-api.scm:399) setup-api#what-version" 
o|inlining procedure: k3398 
o|inlining procedure: k3398 
o|inlining procedure: k3413 
o|inlining procedure: k3413 
o|inlining procedure: k3530 
o|inlining procedure: k3530 
o|inlining procedure: k3614 
o|inlining procedure: k3614 
o|contracted procedure: k3623 
o|contracted procedure: "(setup-api.scm:447) setup-api#target-prefix" 
o|inlining procedure: k2460 
o|inlining procedure: k2460 
o|inlining procedure: k3641 
o|inlining procedure: k3641 
o|inlining procedure: k3665 
o|inlining procedure: k3665 
o|inlining procedure: k3576 
o|inlining procedure: k3721 
o|inlining procedure: k3721 
o|consed rest parameter at call site: "(setup-api.scm:432) setup-api#repo-path" 1 
o|consed rest parameter at call site: "(setup-api.scm:431) setup-api#repo-path" 1 
o|inlining procedure: k3753 
o|inlining procedure: k3753 
o|inlining procedure: k3576 
o|contracted procedure: "(setup-api.scm:455) setup-api#translate-extension" 
o|contracted procedure: k3371 
o|inlining procedure: k3368 
o|inlining procedure: k3380 
o|inlining procedure: k3380 
o|inlining procedure: k3368 
o|inlining procedure: k3816 
o|inlining procedure: k3816 
o|inlining procedure: k3784 
o|inlining procedure: k3854 
o|inlining procedure: k3854 
o|inlining procedure: k3890 
o|inlining procedure: k3890 
o|inlining procedure: k3927 
o|inlining procedure: k3927 
o|consed rest parameter at call site: "(setup-api.scm:461) setup-api#ensure-directory" 2 
o|inlining procedure: k3963 
o|inlining procedure: k3963 
o|inlining procedure: k3784 
o|inlining procedure: k4013 
o|inlining procedure: k4013 
o|inlining procedure: k3984 
o|inlining procedure: k4069 
o|inlining procedure: k4069 
o|consed rest parameter at call site: "(setup-api.scm:483) setup-api#ensure-directory" 2 
o|inlining procedure: k4105 
o|inlining procedure: k4105 
o|inlining procedure: k3984 
o|merged explicitly consed rest parameter: tmp10871088 
o|consed rest parameter at call site: "(setup-api.scm:510) setup-api#ensure-directory" 2 
o|inlining procedure: k4132 
o|inlining procedure: k4132 
o|substituted constant variable: a4155 
o|substituted constant variable: a4156 
o|merged explicitly consed rest parameter: tmp11141116 
o|inlining procedure: k4191 
o|inlining procedure: k4200 
o|inlining procedure: k4200 
o|inlining procedure: k4212 
o|inlining procedure: k4212 
o|inlining procedure: k4191 
o|substituted constant variable: a4323 
o|substituted constant variable: a4324 
o|substituted constant variable: a4385 
o|substituted constant variable: a4386 
o|inlining procedure: k4419 
o|inlining procedure: k4419 
o|inlining procedure: k4430 
o|inlining procedure: k4430 
o|inlining procedure: k4487 
o|propagated global variable: r44885460 setup-api#*cxx* 
o|inlining procedure: k4487 
o|propagated global variable: r44885461 setup-api#*cc* 
o|substituted constant variable: a4502 
o|substituted constant variable: a4503 
o|substituted constant variable: a4564 
o|substituted constant variable: a4565 
o|inlining procedure: k4604 
o|contracted procedure: "(setup-api.scm:560) g12631272" 
o|inlining procedure: k4592 
o|inlining procedure: k4592 
o|inlining procedure: k4604 
o|inlining procedure: k4653 
o|inlining procedure: k4653 
o|inlining procedure: k4668 
o|inlining procedure: k4683 
o|inlining procedure: k4683 
o|inlining procedure: k4668 
o|inlining procedure: k4720 
o|inlining procedure: k4720 
o|inlining procedure: k4775 
o|inlining procedure: k4775 
o|contracted procedure: k4828 
o|inlining procedure: k4825 
o|substituted constant variable: a4884 
o|substituted constant variable: a4885 
o|inlining procedure: k4929 
o|inlining procedure: k4929 
o|substituted constant variable: a4953 
o|inlining procedure: k4964 
o|inlining procedure: k4964 
o|inlining procedure: k4825 
o|inlining procedure: k5015 
o|inlining procedure: k5015 
o|inlining procedure: k5039 
o|inlining procedure: k5039 
o|inlining procedure: k5081 
o|inlining procedure: k5081 
o|substituted constant variable: a5095 
o|substituted constant variable: a5096 
o|inlining procedure: k5128 
o|inlining procedure: k5128 
o|inlining procedure: k5171 
o|inlining procedure: k5171 
o|inlining procedure: k5194 
o|inlining procedure: k5194 
o|substituted constant variable: a5229 
o|propagated global variable: g215216 exit 
o|replaced variables: 512 
o|removed binding forms: 297 
o|removed side-effect free assignment to unused variable: setup-api#*csc-options* 
o|substituted constant variable: r21995328 
o|substituted constant variable: r21995328 
o|propagated global variable: out258262 ##sys#standard-output 
o|inlining procedure: k2632 
o|propagated global variable: out436440 ##sys#standard-output 
o|converted assignments to bindings: (smooth404) 
o|propagated global variable: out579583 ##sys#standard-output 
o|propagated global variable: out607611 ##sys#standard-output 
o|substituted constant variable: r34145385 
o|substituted constant variable: r35315388 
o|substituted constant variable: r35315388 
o|removed call to pure procedure with unused result: "(setup-api.scm:408) get-keyword" 
o|substituted constant variable: r24615393 
o|substituted constant variable: r36665397 
o|inlining procedure: k3368 
o|propagated global variable: r33695534 ##sys#load-dynamic-extension 
o|propagated global variable: r33695534 ##sys#load-dynamic-extension 
o|inlining procedure: k3368 
o|inlining procedure: k3368 
o|inlining procedure: k3368 
o|converted assignments to bindings: (exify948) 
o|inlining procedure: k4191 
o|inlining procedure: k4191 
o|substituted constant variable: r44205450 
o|substituted constant variable: r44205450 
o|substituted constant variable: r44205452 
o|substituted constant variable: r44205452 
o|converted assignments to bindings: (version->list1253) 
o|substituted constant variable: r51725498 
o|substituted constant variable: r51955500 
o|converted assignments to bindings: (verb577) 
o|converted assignments to bindings: (reg307) 
o|simplifications: ((let . 5)) 
o|replaced variables: 23 
o|removed binding forms: 562 
o|Removed `not' forms: 1 
o|substituted constant variable: r26335510 
o|inlining procedure: k3290 
o|inlining procedure: k3407 
o|inlining procedure: k3407 
o|contracted procedure: k3482 
o|inlining procedure: k5200 
o|replaced variables: 8 
o|removed binding forms: 49 
o|removed conditional forms: 1 
o|Removed `not' forms: 1 
o|substituted constant variable: r32915592 
o|substituted constant variable: r32915592 
o|substituted constant variable: r32915592 
o|substituted constant variable: r34085596 
o|substituted constant variable: r34085597 
o|substituted constant variable: r33695536 
o|substituted constant variable: r33695538 
o|replaced variables: 2 
o|removed binding forms: 13 
o|removed conditional forms: 3 
o|removed binding forms: 7 
o|simplifications: ((if . 30) (##core#call . 264)) 
o|  call simplifications:
o|    not	2
o|    number?	3
o|    >
o|    =
o|    string->number
o|    ##sys#get-keyword
o|    ##sys#call-with-values	3
o|    ##sys#apply	3
o|    ##sys#fudge
o|    eq?	7
o|    assq	3
o|    equal?	6
o|    string?
o|    ##sys#cons	5
o|    ##sys#list	17
o|    string=?	3
o|    ##sys#check-list	11
o|    pair?	23
o|    ##sys#setslot	10
o|    ##sys#slot	38
o|    cons	22
o|    assoc
o|    cdr	5
o|    alist-cons
o|    list?	8
o|    list	22
o|    cadr	10
o|    eof-object?
o|    null?	26
o|    car	26
o|    apply	2
o|contracted procedure: k2037 
o|contracted procedure: k2027 
o|contracted procedure: k2056 
o|contracted procedure: k2046 
o|contracted procedure: k2233 
o|contracted procedure: k2239 
o|contracted procedure: k2261 
o|contracted procedure: k2268 
o|contracted procedure: k2278 
o|contracted procedure: k2296 
o|contracted procedure: k2352 
o|contracted procedure: k2384 
o|contracted procedure: k2391 
o|contracted procedure: k2410 
o|contracted procedure: k2420 
o|contracted procedure: k2673 
o|contracted procedure: k2676 
o|contracted procedure: k2686 
o|contracted procedure: k2696 
o|contracted procedure: k2472 
o|contracted procedure: k2491 
o|contracted procedure: k2495 
o|contracted procedure: k2499 
o|contracted procedure: k2507 
o|contracted procedure: k2523 
o|contracted procedure: k2530 
o|contracted procedure: k2546 
o|contracted procedure: k2558 
o|contracted procedure: k2561 
o|contracted procedure: k2564 
o|contracted procedure: k2572 
o|contracted procedure: k2580 
o|contracted procedure: k2592 
o|contracted procedure: k2595 
o|contracted procedure: k2598 
o|contracted procedure: k2606 
o|contracted procedure: k2614 
o|contracted procedure: k2651 
o|contracted procedure: k2705 
o|contracted procedure: k2708 
o|contracted procedure: k2711 
o|contracted procedure: k2719 
o|contracted procedure: k2727 
o|contracted procedure: k2759 
o|contracted procedure: k2762 
o|contracted procedure: k2768 
o|contracted procedure: k2780 
o|contracted procedure: k2790 
o|contracted procedure: k2794 
o|contracted procedure: k2803 
o|contracted procedure: k2806 
o|contracted procedure: k2809 
o|contracted procedure: k2817 
o|contracted procedure: k2825 
o|contracted procedure: k2897 
o|contracted procedure: k5256 
o|contracted procedure: k5252 
o|contracted procedure: k3008 
o|contracted procedure: k2903 
o|contracted procedure: k2932 
o|contracted procedure: k2928 
o|contracted procedure: k2953 
o|contracted procedure: k2949 
o|contracted procedure: k2840 
o|inlining procedure: k2834 
o|contracted procedure: k3162 
o|contracted procedure: k3014 
o|contracted procedure: k3156 
o|contracted procedure: k3017 
o|contracted procedure: k3141 
o|contracted procedure: k3023 
o|contracted procedure: k3072 
o|contracted procedure: k3082 
o|contracted procedure: k3086 
o|contracted procedure: k3100 
o|contracted procedure: k3096 
o|contracted procedure: k3127 
o|contracted procedure: k3134 
o|contracted procedure: k3137 
o|contracted procedure: k3147 
o|contracted procedure: k3202 
o|contracted procedure: k3198 
o|contracted procedure: k3213 
o|contracted procedure: k3220 
o|contracted procedure: k3223 
o|contracted procedure: k3238 
o|contracted procedure: k3234 
o|contracted procedure: k3251 
o|contracted procedure: k3258 
o|contracted procedure: k3273 
o|contracted procedure: k3315 
o|contracted procedure: k3327 
o|contracted procedure: k3330 
o|contracted procedure: k3333 
o|contracted procedure: k3341 
o|contracted procedure: k3349 
o|contracted procedure: k3281 
o|contracted procedure: k3299 
o|contracted procedure: k3290 
o|contracted procedure: k3309 
o|contracted procedure: k3433 
o|contracted procedure: k3445 
o|contracted procedure: k3462 
o|contracted procedure: k3466 
o|contracted procedure: k3416 
o|contracted procedure: k3427 
o|contracted procedure: k3407 
o|contracted procedure: k3564 
o|contracted procedure: k3476 
o|contracted procedure: k3558 
o|contracted procedure: k3479 
o|contracted procedure: k3510 
o|contracted procedure: k3530 
o|contracted procedure: k3544 
o|contracted procedure: k3540 
o|contracted procedure: k3552 
o|contracted procedure: k3548 
o|contracted procedure: k3762 
o|contracted procedure: k3573 
o|contracted procedure: k3591 
o|contracted procedure: k3608 
o|contracted procedure: k3630 
o|contracted procedure: k3655 
o|contracted procedure: k3651 
o|contracted procedure: k3662 
o|contracted procedure: k3679 
o|contracted procedure: k3668 
o|contracted procedure: k3694 
o|contracted procedure: k3690 
o|contracted procedure: k3701 
o|contracted procedure: k3705 
o|contracted procedure: k3724 
o|contracted procedure: k3727 
o|contracted procedure: k3730 
o|contracted procedure: k3738 
o|contracted procedure: k3746 
o|contracted procedure: k3756 
o|contracted procedure: k3753 
o|contracted procedure: k3972 
o|contracted procedure: k3771 
o|contracted procedure: k3781 
o|contracted procedure: k3389 
o|contracted procedure: k3358 
o|contracted procedure: k3377 
o|contracted procedure: k3383 
o|contracted procedure: k3802 
o|contracted procedure: k3827 
o|contracted procedure: k3823 
o|contracted procedure: k3834 
o|contracted procedure: k3838 
o|contracted procedure: k3857 
o|contracted procedure: k3860 
o|contracted procedure: k3863 
o|contracted procedure: k3871 
o|contracted procedure: k3879 
o|contracted procedure: k3885 
o|contracted procedure: k3893 
o|contracted procedure: k3908 
o|contracted procedure: k3912 
o|contracted procedure: k3918 
o|contracted procedure: k3930 
o|contracted procedure: k3933 
o|contracted procedure: k3936 
o|contracted procedure: k3944 
o|contracted procedure: k3952 
o|contracted procedure: k3966 
o|contracted procedure: k3963 
o|contracted procedure: k4114 
o|contracted procedure: k3981 
o|contracted procedure: k3999 
o|contracted procedure: k4024 
o|contracted procedure: k4020 
o|contracted procedure: k4031 
o|contracted procedure: k4035 
o|contracted procedure: k4059 
o|contracted procedure: k4055 
o|contracted procedure: k4072 
o|contracted procedure: k4075 
o|contracted procedure: k4078 
o|contracted procedure: k4086 
o|contracted procedure: k4094 
o|contracted procedure: k4108 
o|contracted procedure: k4105 
o|contracted procedure: k4176 
o|contracted procedure: k4123 
o|contracted procedure: k4167 
o|contracted procedure: k4233 
o|contracted procedure: k4185 
o|contracted procedure: k4223 
o|contracted procedure: k4219 
o|contracted procedure: k4242 
o|contracted procedure: k4422 
o|contracted procedure: k4437 
o|contracted procedure: k4453 
o|contracted procedure: k4457 
o|contracted procedure: k4584 
o|contracted procedure: k4607 
o|contracted procedure: k4610 
o|contracted procedure: k4613 
o|contracted procedure: k4621 
o|contracted procedure: k4629 
o|contracted procedure: k4589 
o|contracted procedure: k4656 
o|contracted procedure: k4662 
o|contracted procedure: k4749 
o|contracted procedure: k4671 
o|contracted procedure: k4708 
o|contracted procedure: k4677 
o|contracted procedure: k4680 
o|contracted procedure: k4689 
o|contracted procedure: k4745 
o|contracted procedure: k4711 
o|contracted procedure: k4726 
o|contracted procedure: k4791 
o|contracted procedure: k4769 
o|contracted procedure: k4772 
o|contracted procedure: k4810 
o|contracted procedure: k4988 
o|contracted procedure: k4822 
o|contracted procedure: k4873 
o|contracted procedure: k4932 
o|contracted procedure: k4967 
o|contracted procedure: k4977 
o|contracted procedure: k4981 
o|contracted procedure: k5000 
o|contracted procedure: k5027 
o|contracted procedure: k5030 
o|contracted procedure: k5042 
o|contracted procedure: k5052 
o|contracted procedure: k5056 
o|contracted procedure: k5063 
o|contracted procedure: k5084 
o|contracted procedure: k5143 
o|contracted procedure: k5174 
o|contracted procedure: k5177 
o|contracted procedure: k5186 
o|contracted procedure: k5189 
o|contracted procedure: k5197 
o|contracted procedure: k5200 
o|contracted procedure: k5223 
o|contracted procedure: k5306 
o|simplifications: ((let . 52)) 
o|removed binding forms: 240 
o|replaced variables: 104 
o|simplifications: ((if . 1)) 
o|removed binding forms: 52 
o|contracted procedure: k4625 
o|removed binding forms: 1 
o|customizable procedures: (reg307 k5183 ensure-string1321 g14701471 g14431450 for-each-loop14421454 g14051412 for-each-loop14041419 k4935 walk1399 version->list1253 loop1285 map-loop12571278 g10461055 map-loop10401068 k4004 g962971 map-loop956974 exify948 g990999 map-loop9841012 k3807 setup-api#check-filelist g891900 map-loop885927 setup-api#write-info k3596 k3644 k3522 setup-api#supply-version g805806 map-loop736763 setup-api#make-dest-pathname k3185 k3026 g682689 for-each-loop681692 walk672 setup-api#repo-path setup-api#ensure-directory verb577 map-loop448465 for-each-loop396472 map-loop409426 k2487 map-loop339357 map-loop366384 setup-api#$system loop267 setup-api#user-install-setup) 
o|calls to known targets: 144 
o|identified direct recursive calls: f_3246 1 
o|identified direct recursive calls: f_4602 1 
o|identified direct recursive calls: f_4651 1 
o|fast box initializations: 18 
o|fast global references: 85 
o|fast global assignments: 47 
o|dropping unused closure argument: f_5192 
o|dropping unused closure argument: f_2424 
o|dropping unused closure argument: f_4183 
o|dropping unused closure argument: f_2202 
o|dropping unused closure argument: f_4121 
o|dropping unused closure argument: f_5073 
o|dropping unused closure argument: f_3271 
o|dropping unused closure argument: f_3246 
o|dropping unused closure argument: f_3775 
o|dropping unused closure argument: f_2901 
o|dropping unused closure argument: f_3431 
o|dropping unused closure argument: f_4582 
o|dropping unused closure argument: f_2874 
*/
/* end of file */
